# -*- coding: UTF-8 -*-

import sys,re, ast 
import six
from six.moves import urllib_parse

import requests
from requests.compat import urlparse
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc, xbmcvfs
if six.PY3:
	basestring = str
	unicode = str
	xrange = range
	from resources.lib.cmf3 import parseDOM
else:
	from resources.lib.cmf2 import parseDOM

import resolveurl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(urllib_parse.parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.uiiumovies')

PATH			= addon.getAddonInfo('path')
if six.PY2:
	DATAPATH		= xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
else:
	DATAPATH		= xbmcvfs.translatePath(addon.getAddonInfo('profile'))

RESOURCES       = PATH+'/resources/'
FANART=RESOURCES+'../fanart.jpg'
ikona =RESOURCES+'../icon.png'
prawo =RESOURCES+'right.png'


exlink = params.get('url', None)
nazwa= params.get('title', None)
rys = params.get('image', None)

try:
	inflabel = ast.literal_eval(params.get('ilabel', None))
except:
	inflabel = params.get('ilabel', None)
	
page = params.get('page',[1])[0]

MAIN_URL ='https://uiiumovies.net/' 

UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0'
TIMEOUT=15

headers = {'User-Agent': UA,}
sess = requests.Session()

fsortv = addon.getSetting('fsortV')
fsortn = addon.getSetting('fsortN') if fsortv else 'default'

findexv = addon.getSetting('findexV')
findexn = addon.getSetting('findexN') if findexv else 'default'

fkatv = addon.getSetting('fkatV')
fkatn = addon.getSetting('fkatN') if fkatv else 'all'

frokv = addon.getSetting('frokV')
frokn = addon.getSetting('frokN') if frokv else 'all'

fkrajv = addon.getSetting('fkrajV')
fkrajn = addon.getSetting('fkrajN') if fkrajv else 'all'

fqualv = addon.getSetting('fqualV')
fqualn = addon.getSetting('fqualN') if fqualv else 'all'

fdata = addon.getSetting('fdata')


def build_url(query):
	return base_url + '?' + urllib_parse.urlencode(query)

def add_item(url, name, image, mode, itemcount=1, page=1,fanart=FANART, infoLabels=False,contextmenu=None,IsPlayable=False, folder=False):

	if six.PY3:	
		list_item = xbmcgui.ListItem(name)

	else:
		list_item = xbmcgui.ListItem(name, iconImage=image, thumbnailImage=image)
	if IsPlayable:
		list_item.setProperty("IsPlayable", 'True')	
		
	if not infoLabels:
		infoLabels={'title': name}	
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image,'icon': image,  'poster': image, 'banner': image, 'fanart': fanart})
	
	if contextmenu:
		out=contextmenu
		list_item.addContextMenuItems(out, replaceItems=True)
	else:
		out = []
		out.append(('Informacja', 'Action(Info)'),)
		list_item.addContextMenuItems(out, replaceItems=False)

	xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page, 'title':name,'image':image, 'ilabel':infoLabels}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	
#def home():
    
    #Pin()

#def Pin(cv=False):
#	passw = addon.getSetting("password")
	
#	if passw:
#		if cv:
#			result = xbmcgui.Dialog().input('Parental control, enter password:', str(passw), type=xbmcgui.INPUT_PASSWORD, option=xbmcgui.PASSWORD_VERIFY);
#			if result == passw:
#				add_item('', '[COLOR pink][B]Enter[/B][/COLOR]', ikona, "enter", folder=True)	
#			else:
#				xbmcgui.Dialog().notification('[COLOR red][B]Error[/B][/COLOR]', 'Incorrect password', xbmcgui.NOTIFICATION_INFO, 5000)
#				add_item('', '[COLOR pink][B]Enter password[/B][/COLOR]', ikona, "pin", folder=True)
#		else:
#			add_item('', '[COLOR pink][B]Enter password[/B][/COLOR]', ikona, "pin", folder=True)
#	else:
#		add_item('', '[COLOR pink][B]Setup Parental password[/B][/COLOR]', ikona, "setpin", folder=False)
#	if cv:
#		xbmcplugin.endOfDirectory(addon_handle)

#def SetPin():
#	query = xbmcgui.Dialog().input('Password', type=xbmcgui.INPUT_PASSWORD)
#	if query:
#		addon.setSetting("password",str(query)) 
#	else:
#		xbmcgui.Dialog().notification('[COLOR red][B]Error[/B][/COLOR]', 'No password entered', xbmcgui.NOTIFICATION_INFO, 5000)

#	xbmc.executebuiltin('Container.Refresh')

#def Enter():
def home():
	add_item('f', '[B]uiiumovies[/B]', ikona, "listsubmenu",fanart=FANART, folder=True)
	add_item('f', '[B]xxxmoviestream[/B]', ikona, "listmenuxxxmoviestream",fanart=FANART, folder=True)
	xbmcplugin.endOfDirectory(addon_handle)
	
def ListMenu2():
	add_item('https://xxxmoviestream.xyz/genres/porn-movies/page/1/', '[B]Movies[/B]', ikona, "listmovies",fanart=FANART, folder=True)
	add_item('https://xxxmoviestream.xyz/trending/page/1/', '[B]Trending movies[/B]', ikona, "listmovies",fanart=FANART, folder=True)
	add_item('genres', '[B]Genres[/B]', ikona, "listcategoryxxx",fanart=FANART, folder=True)
	add_item('studios', '[B]Studios[/B]', ikona, "listcategoryxxx",fanart=FANART, folder=True)
	add_item('f', '[B][COLOR lightgreen]Search[/COLOR][/B]', ikona, "search2",fanart=FANART, folder=True)
	xbmcplugin.endOfDirectory(addon_handle)
	
def ListMovies(url,pg):

	urlk = url

	if 'query:' in url:
		query = url.split(':')[-1]
		urlk = 'https://xxxmoviestream.xyz/search/'+query+'/page/1/' #url.replace('/?s=&','/?s=%s&'%(str(query)))

	urlk = re.sub('\/page\/\d+\/','/page/%s/'%int(pg),   urlk) 
	html=getUrlReqOk(urlk)

	if '"fas fa-chevron-right' in html:
		npage = True
	if 'query:' in url:
		links = parseDOM(html,'div', attrs={'class': "result\-item"})
		for link in links:
			
			href = parseDOM(link,'a', ret="href")[0]
			h3 = parseDOM(link,'div', attrs={'class': "title"})[0] #<div class="title">
			title = parseDOM(h3,'a')[0]
			imag = parseDOM(link,'img', ret="src")[0]
			add_item(name='[B]'+PLchar(title)+'[/B]', url=href, mode='listlinks2', image=imag, infoLabels={'plot':PLchar(title)},folder=True, IsPlayable=False)

	else:
		result = parseDOM(html,'div', attrs={'class': "items full"})[0]
		links = parseDOM(result,'article', attrs={'id': "post\-\d+"})
		for link in links:
			
			href = parseDOM(link,'a', ret="href")[0]
			h3 = parseDOM(link,'h3')[0]
			title = parseDOM(h3,'a')[0]
			imag = parseDOM(link,'img', ret="src")[0]
			add_item(name='[B]'+PLchar(title)+'[/B]', url=href, mode='listlinks2', image=imag, infoLabels={'plot':PLchar(title)},folder=True, IsPlayable=False)
	if links:
		if npage:
			add_item(name='[COLOR blue]>> next page >>[/COLOR]', url=url, mode='listmovies', image=prawo, infoLabels={'plot':'[COLOR blue]>> next page >>[/COLOR]'},folder=True, IsPlayable=False, page = int(pg)+1)
		xbmcplugin.endOfDirectory(addon_handle)

def ListCategXXX(id):
	html=getUrlReqOk('https://xxxmoviestream.xyz/')

	result = re.findall('>'+id+'<\/a>(.*?)<\/ul>', html,re.DOTALL+re.I)[0]
	hreftit = re.findall('href="([^"]+)">([^<]+)<',result,re.DOTALL)
	for href, title in hreftit:
		href = href+'page/1/'
		add_item(name='[B]'+PLchar(title)+'[/B]', url=href, mode='listmovies', image=ikona, infoLabels={'plot':PLchar(title)},folder=True, IsPlayable=False)
	if hreftit:

		xbmcplugin.endOfDirectory(addon_handle)

def ListSubmenu():
	sortn = fsortn
	katn = fkatn
	rokn = frokn
	qualn  = fqualn
	indexn  = findexn
	krajn = fkrajn

	

	
	add_item('f', '[B]Show content[/B]', ikona, "listcontent",fanart=FANART, folder=True)
	add_item('film',"-    [COLOR lightblue]index:[/COLOR] [B]"+indexn+'[/B]', ikona, "filtry:findex",fanart=FANART, folder=False)
	add_item('film',"-    [COLOR lightblue]order:[/COLOR] [B]"+sortn+'[/B]', ikona, "filtry:fsort",fanart=FANART, folder=False)
	
	add_item('film',"-    [COLOR lightblue]genre:[/COLOR] [B]"+katn+'[/B]', ikona, "filtry:fkat",fanart=FANART, folder=False)
	add_item('film',"-    [COLOR lightblue]release date:[/COLOR] [B]"+rokn+'[/B]', ikona, "filtry:frok",fanart=FANART, folder=False)
	add_item('film',"-    [COLOR lightblue]country:[/COLOR] [B]"+krajn+'[/B]', ikona, "filtry:fkraj",fanart=FANART, folder=False)
	add_item('film',"-    [COLOR lightblue]quality:[/COLOR] [B]"+qualn+'[/B]', ikona, "filtry:fqual",fanart=FANART, folder=False)
	add_item('f', '[B][COLOR khaki]>> clear all filters <<[/COLOR][/B]', ikona, "resetfiltr",fanart=FANART, folder=False)
	
	add_item('f', '[B][COLOR lightgreen]Search[/COLOR][/B]', ikona, "search",fanart=FANART, folder=True)

	xbmcplugin.endOfDirectory(addon_handle)

def ListContent(ss,pg):

	url = 'https://uiiumovies.net/page/6/?s=&search=advanced' + fdata

	url = re.sub('\/page\/\d+\/','/page/%s/'%int(pg),   url) 
	if 'query' in ss:
		query = ss.split(':')[-1]
		url = url.replace('/?s=&','/?s=%s&'%(str(query)))
	html=getUrlReqOk(url)
	npage = False
	if '"next page-numbers"' in html:
		npage = True
	result = parseDOM(html,'main', attrs={'id': "main"})[0]
	links = parseDOM(result,'article', attrs={'id': "post\-\d+"})
	for link in links:
		
		href = parseDOM(link,'a', ret="href")[0]
		h2 = parseDOM(link,'h2')[0]
		title = parseDOM(h2,'a')[0]
		imag = parseDOM(link,'img', ret="src")[0]

		durat = re.findall('<\/svg>([^<]+)<', link,re.DOTALL)

		if durat:
			if 'min' in durat[0]:
				durat = int(re.findall('(\d+)', durat[0],re.DOTALL)[0])*60
			else:
				durat = 1	
		else:
			durat = 1
		try:
			ql = parseDOM(link,'div', attrs={'class': "gmr\-quality.*?"})[0] 
			qual = re.findall('"tag">([^<]+)<',ql,re.DOTALL)[0]
		except:
			qual = ''	
		try:
			year = re.findall('(\((\d+)\))', title,re.DOTALL)[0]
			title = title.replace(year[0],'')
			year = year[1]
		except:
			year = ''
		
		add_item(name='[B]'+PLchar(title)+'[/B]', url=href, mode='listlinks', image=imag, infoLabels={'plot':PLchar(title),'year':year,'code':qual, 'duration':int(durat)},folder=True, IsPlayable=False)
	if links:
		if npage:
			add_item(name='[COLOR blue]>> next page >>[/COLOR]', url=ss, mode='listcontent', image=prawo, infoLabels={'plot':'[COLOR blue]>> next page >>[/COLOR]'},folder=True, IsPlayable=False, page = int(pg)+1)
		xbmcplugin.endOfDirectory(addon_handle)
def ListLinks2(url):
	html=getUrlReqOk(url)
	links = re.findall('<li class="hosts(.*?)<\/li>', html,re.DOTALL)

	l=1
	for link in links:

		href = re.findall('href="([^"]+)"',link,re.DOTALL)[0]
		if '?link=h' in href:
			href = href.split('?link=')[-1]
		host = urlparse(href).netloc

		tyt = '[B]'+nazwa+' - [COLOR gold][B]Link '+str(l)+'[/COLOR]' + ' [/B][[I]%s[/I]]'%str(host)

		add_item(name=tyt, url=href, mode='playvid', image=rys, infoLabels=inflabel,folder=False, IsPlayable=True)
		l+=1

	xbmcplugin.endOfDirectory(addon_handle)	

def ListLinks(url):
	
	html=getUrlReqOk(url)
	result = parseDOM(html,'div', attrs={'id': "download"})[0]
	links = re.findall('a\s*href\s*=\s*"([^"]+)"',result,re.DOTALL)
	l=1
	for link in links:
		host = urlparse(link).netloc

		tyt = '[B]'+nazwa+' - [COLOR gold][B]Link '+str(l)+'[/COLOR]' + ' [/B][[I]%s[/I]]'%str(host)

		add_item(name=tyt, url=link, mode='playvid', image=rys, infoLabels=inflabel,folder=False, IsPlayable=True)
		l+=1

	xbmcplugin.endOfDirectory(addon_handle)		
	
def PlayVid(url):
	error = None
	try:

		link = resolveurl.resolve(url)
		dfsfs=''
	except Exception as error:
		
		link = None
		pass
	
	if link:
		play_item = xbmcgui.ListItem(path=link)
		play_item.setArt({"fanart": FANART, "icon": rys, "thumb":rys, "poster":rys})
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)	
	else:
		msg = "[COLOR red][B]Can't resolve this link.[/B][/COLOR]"
		msg = error if error else msg
		xbmcgui.Dialog().notification('[COLOR red][B]Error[/B][/COLOR]', msg, xbmcgui.NOTIFICATION_INFO, 5000)


def ResetFilters():
	addon.setSetting("fdata","&post_type=movie")
	addon.setSetting("fsortV","")   
	addon.setSetting("fsortN","default")
	addon.setSetting("findexV","")   
	addon.setSetting("findexN","default")
	addon.setSetting("fkrajV","")   
	addon.setSetting("fkrajN","all")
	addon.setSetting("fqualV","")   
	addon.setSetting("fqualN","all")
	addon.setSetting("frokV","")   
	addon.setSetting("frokN","all")
	addon.setSetting("fkatV","")   
	addon.setSetting("fkatN","all")
	xbmc.executebuiltin('Container.Refresh')

def getUrlReqOk(url,ref='', content=True):	

	headersok = {
	'User-Agent': UA,
	'Accept': 'text/html',
	'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
	'Connection': 'keep-alive',
	'Referer': ref,}
	
	
	resp=sess.get(url, headers=headersok,verify=False)
	if content:
		content = resp.content
		if six.PY3:
			content = content.decode(encoding='utf-8', errors='strict') 
		return content
	else:
		content = resp.content
		if six.PY3:
			content = content.decode(encoding='utf-8', errors='strict') 
		return content, resp.url

def SetAllFilters():
	fsortv = addon.getSetting('fsortV')
	findexv = addon.getSetting('findexV')
	
	fkatv = addon.getSetting('fkatV')
	
	frokv = addon.getSetting('frokV')
	
	fkrajv = addon.getSetting('fkrajV')
	
	fqualv = addon.getSetting('fqualV')
	
	
	
	
	
	dataf = "&post_type=movie"+fsortv+findexv+fkrajv+fqualv+frokv+fkatv

	addon.setSetting('fdata',dataf)
	
	addon.setSetting('bezklik','true')		
	return	
		
def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&").replace('&#38;',"&")
	char = char.replace('&#039;',"'").replace('&#39;',"'")
	char = char.replace('&quot;','"').replace('&oacute;','ó').replace('&rsquo;',"'")
	char = char.replace('&nbsp;',".").replace('&amp;','&').replace('&eacute;','e')
	return char	
def PLcharx(char):
	char=char.replace("\xb9","ą").replace("\xa5","Ą").replace("\xe6","ć").replace("\xc6","Ć")
	char=char.replace("\xea","ę").replace("\xca","Ę").replace("\xb3","ł").replace("\xa3","Ł")
	char=char.replace("\xf3","ó").replace("\xd3","Ó").replace("\x9c","ś").replace("\x8c","Ś")
	char=char.replace("\x9f","ź").replace("\xaf","Ż").replace("\xbf","ż").replace("\xac","Ź")
	char=char.replace("\xf1","ń").replace("\xd1","Ń").replace("\x8f","Ź");
	return char	
	
	
def router(paramstring):
	params = dict(urllib_parse.parse_qsl(paramstring))
	if params:	
		mode = params.get('mode', None)

		if mode == 'playvid':
			PlayVid(exlink)	

		elif mode=='search':
			query = xbmcgui.Dialog().input(u'Search...', type=xbmcgui.INPUT_ALPHANUM)
			if query:	  
				query=query.replace(' ','+')
				ListContent('query:'+query, 1)
			else:
				pass
				
				
				
				
		elif mode == 'nic':
			return	
				
		elif mode == 'listcateg':
			ListCateg()
		elif mode =='enter':

			Enter()
				
		elif mode == 'listsubmenu':
			ListSubmenu()
			
		elif mode =='listcontent':
			ListContent(exlink,page)
			

			
		elif 'filtry' in mode:
			tt=mode.split(':')[-1]
			label=['all']
			value=['']
			if 'sort' in tt:
				label=['default']
				value=['']
				prs = "orderby"
				dd='order:'

			elif 'index' in tt:
				label=['default']
				value=['']
				prs = "index"
				dd='index:'
			elif 'kat' in tt:
				prs = "genre"
				dd='genre:'
			elif 'rok' in tt:
				prs = "movieyear"
				dd='year:'
			elif 'kraj' in tt:
				prs = "country"
				dd='country:'
			elif 'qual' in tt:
				prs = "quality"
				dd='quality:'

			html = getUrlReqOk(MAIN_URL)
			result = parseDOM(html,'select', attrs={'name': prs})[0]
			val_label = re.findall('value\s*=\s*"([^"]+)">([^<]+)<\/option>',result,re.DOTALL)
			for val,lab in val_label:
				value.append('&'+prs+'='+str(val))
				label.append(str(lab.lower()))

			sel = xbmcgui.Dialog().select('Select '+dd, label)

			if sel > -1:
				v = '%s'%value[sel] if value[sel] else ''
				n = label[sel]
				addon.setSetting(tt+'N',n)
				addon.setSetting(tt+'V',v)
				
				SetAllFilters()

				xbmc.executebuiltin('Container.Refresh()')	
		elif mode =='resetfiltr':
			ResetFilters()
			
		elif mode == 'listlinks':
			ListLinks(exlink)
			
		elif mode == 'listlinks2':
			ListLinks2(exlink)
			
		elif mode =='setpin':
			SetPin()
		elif mode =='pin':
			Pin(True)
			
		elif mode =='listmenuxxxmoviestream':
			ListMenu2()
			
		elif mode =='listcategoryxxx':
			ListCategXXX(exlink)
			
		elif mode =='listmovies':
			ListMovies(exlink,page)
			
		elif mode =='search2':
			query = xbmcgui.Dialog().input(u'Search...', type=xbmcgui.INPUT_ALPHANUM)
			if query:	  
				query=query.replace(' ','+')
				ListMovies('query:'+query, 1)
			else:
				pass
			
	else:
		home()
		xbmcplugin.endOfDirectory(addon_handle)	
if __name__ == '__main__':
	router(sys.argv[2][1:])