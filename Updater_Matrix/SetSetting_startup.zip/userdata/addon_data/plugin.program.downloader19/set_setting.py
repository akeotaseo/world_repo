﻿import xbmc, xbmcaddon
from updatervar import *

Dialog_U1                 = '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]'
Dialog_U4                 = '[B]Ολοκληρώθηκε με επιτυχία[/B]'

def set_setting():


    ###  plugin.program.downloader19   ###
    BG.update(20, Dialog_U1, 'Ενημέρωσης ρυθμίσεων...')
    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('addonsreposversion')=='0':
        xbmc.sleep(1000)
        setting_set_downloader19('addonsreposversion', '0')
        BG.update(25, Dialog_U1, 'Movie view επιλογή -MyFlix-...')
        xbmc.sleep(2000)



#            xbmc.executebuiltin("ReloadSkin()")

set_setting()
