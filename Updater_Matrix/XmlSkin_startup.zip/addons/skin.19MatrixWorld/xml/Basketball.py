import xbmc, xbmcgui



def Basketball():
    funcs = (click_1, click_2,)
    call = xbmcgui.Dialog().select('[B][COLOR orange]BASKETBALL[/COLOR][/B]',
['[COLOR=orange]Basketball / Microjen[/COLOR]  [COLORred][B]Daddylive[/COLOR][/B]',

 '[COLOR=orange]Basketball / Microjen[/COLOR]   [COLOR red]Live[COLOR white]TV.ru[/COLOR]'

 # '[COLOR=green]Volley[/COLOR] (Dracarys)'


 ])




    if call:
        if call < 1:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmcgui.Dialog().ok('[COLOR orange]BASKETBALL[/COLOR]', '[COLOR=orange](Microjen)[/COLOR][CR][CR]Επιλέγουμε την κατηγορία που μας ενδιαφέρει.')
    # xbmc.executebuiltin('RunScript("special://home/addons/skin.19MatrixWorld/xml/Dialog Spor/DialogDLvolley.py")')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=sched")')
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/?mode=showChannels&trType=Volleyball")')
    xbmcgui.Dialog().notification("[B][COLOR red]Daddylive[/COLOR][/B]", "[COLOR orange]BASKETBALL[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/DL.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png')
def click_2():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/set_setting_LivetvsxACE_off.py")')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/sporthd?description=Basketball&iconimage=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.video.microjen%5cresources%5clib%5cexternal%5csporthd%5cmedia%5clivetv.png&mode=livetvSX_events&name=Basketball%20(88)&url=sport%7cBasketball")')
    xbmcgui.Dialog().notification("[B][COLOR=orange]Microjen[/COLOR][/B]", "[COLOR darkorange]BASKETBALL[/COLOR]", sound=False, icon='special://home/addons/plugin.video.microjen/resources/lib/external/sporthd\media/livetv.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR=orange]Microjen[/COLOR][/B]", "[COLOR darkorange]BASKETBALL[/COLOR]", sound=False, icon='special://home/addons/plugin.video.microjen/resources/lib/external/sporthd\media/livetv.png')


Basketball()
