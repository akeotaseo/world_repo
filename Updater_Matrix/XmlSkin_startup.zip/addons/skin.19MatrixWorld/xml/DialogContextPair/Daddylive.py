import xbmc, xbmcgui, webbrowser


def daddyhd():
    dialog = xbmcgui.Dialog()
    funcs = (site1, site2)
    xbmcgui.Dialog().ok("[B][COLOR=orange]Daddylive[/COLOR][/B]", "Πατήστε Εντάξει για να μεταφερθείτε στο site https://daddyhd.com")
    call = dialog.select('[B][COLOR=orange]Daddylive[/COLOR][/B]',
    
['Μεταφερθείτε στο daddyhd'])

    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()


def site1():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://daddyhd.com/' ) )
    else: opensite = webbrowser . open('https://daddyhd.com/')

def site2():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://daddyhd.com/' ) )
    else: opensite = webbrowser . open('https://daddyhd.com/')


daddyhd()
