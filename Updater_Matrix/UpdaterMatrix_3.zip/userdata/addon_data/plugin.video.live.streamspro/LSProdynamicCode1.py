# -*- coding: utf-8 -*-
#$pyFunction
import xbmc
import xbmcaddon
import xbmcgui
def GetLSProData(page_data,Cookie_Jar,m):
    dialog = xbmcgui.Dialog()
    d = dialog.input('Buscar  Canal: ejemplo: Sky Sports', type=xbmcgui.INPUT_ALPHANUM).replace(" ", "+")
    return d
