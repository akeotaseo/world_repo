﻿# -*- coding: utf-8 -*-
import xbmc
import sys
import urllib.parse
import urllib.request
import re
import ssl
import xbmcgui
import xbmcplugin
import http.cookiejar


# Βασικές ρυθμίσεις
BASE_URL = "https://www.forecastweather.gr"
START_URL = BASE_URL + "/kameres.html"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
ADDON_HANDLE = int(sys.argv[1])

# Παράκαμψη SSL σφαλμάτων
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

# Setup Cookie Jar & Opener για σταθερή σύνδεση
cj = http.cookiejar.CookieJar()
opener = urllib.request.build_opener(
    urllib.request.HTTPCookieProcessor(cj),
    urllib.request.HTTPSHandler(context=ctx)
)

def get_html(url):
    try:
        req = urllib.request.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        req.add_header('Referer', BASE_URL)
        with opener.open(req, timeout=15) as response:
            return response.read().decode('utf-8', errors='ignore')
    except:
        return ""

def build_url(query):
    return sys.argv[0] + '?' + urllib.parse.urlencode(query)

def list_categories():
    html = get_html(START_URL)
    
    main_content = re.findall(r'<main.*?</main>', html, re.DOTALL)
    search_area = main_content[0] if main_content else html

    pattern = r'class="subcategory-img".*?href="([^"]+)".*?src="([^"]+)".*?<a[^>]*>([^<]+)</a>'
    matches = re.findall(pattern, search_area, re.DOTALL | re.IGNORECASE)

    seen = set()
    for link, img, title in matches:
        title = title.strip()
        if not title or link in seen: continue
        seen.add(link)

        full_link = BASE_URL + link if link.startswith('/') else link
        clean_img = img.split('#')[0].split('?')[0]
        full_img = BASE_URL + clean_img if clean_img.startswith('/') else clean_img
        
        url = build_url({'mode': 'list_cameras', 'link': full_link})
        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': full_img, 'icon': full_img, 'poster': full_img})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.setContent(ADDON_HANDLE, 'files')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)
    
    # VIEW WALL
    #xbmc.sleep(500) 
    #xbmc.executebuiltin('Container.SetViewMode(503)')

def list_cameras(url):
    html = get_html(url)
    # Αναζήτηση για τις επιμέρους κάμερες
    pattern = r'class="subcategory-img".*?href="([^"]+)".*?src="([^"]+)".*?<a[^>]*>([^<]+)</a>'
    matches = re.findall(pattern, html, re.DOTALL | re.IGNORECASE)

    if not matches:
        # Fallback αν οι κάμερες είναι σε απλή λίστα
        pattern = r'href="([^"]*kameres/[^"]+\.html)"[^>]*>(.*?)</a>'
        matches = re.findall(pattern, html, re.IGNORECASE)

    seen = set()
    for m in matches:
        if len(m) == 3:
            link, img, title = m
        else:
            link, title = m
            img = ""

        title = re.sub('<[^<]+?>', '', title).strip()
        if not title or link in seen or "kameres.html" in link: continue
        seen.add(link)

        full_link = BASE_URL + link if link.startswith('/') else link
        full_img = ""
        if img:
            full_img = BASE_URL + img if img.startswith('/') else img

        u = build_url({'mode': 'play', 'link': full_link, 'title': title})
        li = xbmcgui.ListItem(label=title)
        if full_img:
            li.setArt({'thumb': full_img, 'icon': full_img})
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'title': title})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_camera(url, title):
    html = get_html(url)
    
    # 1. m3u8 Stream
    m3u8 = re.findall(r'["\'](https?://[^"\']+\.m3u8[^"\']*)["\']', html)
    if m3u8:
        stream = m3u8[0].replace('\\', '')
        final = stream + '|User-Agent=' + urllib.parse.quote(USER_AGENT) + '&Referer=' + urllib.parse.quote(url)
        li = xbmcgui.ListItem(label=title, path=final)
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=li)
        return

    # 2. YouTube Fallback
    yt = re.search(r'youtube\.com/embed/([^"\?& ]+)', html)
    if yt:
        final = f"plugin://plugin.video.youtube/play/?video_id={yt.group(1)}"
        li = xbmcgui.ListItem(label=title, path=final)
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=li)
        return
        
    xbmcgui.Dialog().notification('Offline', 'Η κάμερα δεν εκπέμπει αυτή τη στιγμή', xbmcgui.NOTIFICATION_INFO)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring.lstrip('?')))
    mode = params.get('mode')

    if mode == 'list_cameras':
        list_cameras(params.get('link', ''))
    elif mode == 'play':
        play_camera(params.get('link', ''), params.get('title', 'Camera'))
    else:
        list_categories()

if __name__ == '__main__':
    router(sys.argv[2] if len(sys.argv) > 2 else "")