import base64
import re
import ast
import binascii
import codecs
import requests
from . import png

try:
    from Cryptodome.Cipher import AES
except:
    try:
        from Crypto.Cipher import AES
    except:
        from . import pyaes as AES


def unForge(html):
    try:
        js1u, js2u = re.findall(r'script.*?src="(http[^"]+\.js\?\d+)', html)
        img = re.findall(r'"data:image\/png;base64,(.*?)"', html)[0]
        rotlink = re.findall(r"{\s*\w+\('\w+',\s*'\w+',\s*'(\w+)'", html)[0]
        # print("JAIROOOOOOOOOOOOOOOOX    " + rotlink[0:50])

        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                   "Origin": "http://e1sd9z3.flashyvpn.pw"}

        js1 = requests.get(js1u, headers=headers).text
        js2 = requests.get(js2u, headers=headers).text
        if "xset=" not in js1:
            js1, js2 = js2, js1

        var1, arr, n = re.findall(r'var\s+(\w+)=\[(.*?)\];.*?}\(\1,(\w+)\)', js1)[0]
        arr = arr.replace("'", '').split(",")
        n = ast.literal_eval(n)

        for i in range(0, n):
            arr.append(arr.pop(0))

        xh = re.findall(r'(xset=.*hset=.*?[,;])', js1)[0]
        x, h = re.findall(r"\('(\w+)'\)\)?,", xh)

        xset = x if '0x' not in x else arr[ast.literal_eval(x)]
        hset = h if '0x' not in h else arr[ast.literal_eval(h)]

        rot = str.maketrans(xset, hset)
        enclink = str.translate(rotlink, rot)

        p = png.Reader(bytes=base64.b64decode(img))
        x, y, pixels, meta = p.read()
        pixels = list(pixels)

        keyvar = re.findall(r'=\s*forge\[.*?\].*?,(\w+)\);', js2)[0]
        coords = re.findall(r'%s=%s.*?(\(0x\w+[^\)]+\))' % (keyvar, keyvar), js2)
        coords = [ast.literal_eval(coord) for coord in coords]

        key = ""
        for coord in coords:
            key += chr(list(pixels[coord[1]])[coord[0] * 3 + 1])

        decipher = AES.new(key.encode(), AES.MODE_ECB)
        link = decipher.decrypt(binascii.unhexlify(enclink))
        link = codecs.decode(re.findall('([a-f0-9]+)', link.decode())[0], 'hex').decode()
        # print("JAIROOOOOOOOOOOOOOOOZ    " + link)
        return link
    except BaseException:
        # import traceback
        # traceback.print_exc()
        return None


def ss247dec(enclink, key):
    decipher = AES.new(key.encode(), AES.MODE_ECB)
    link = decipher.decrypt(binascii.unhexlify(enclink))
    link = codecs.decode(re.findall('([a-f0-9]+)', link.decode())[0], 'hex').decode()

# def s247dec(data, keyiv):
#     #lib.common.log("JairoX_Decrypt:" + data)
#     try:
#         keyiv = xor2(base64.b64decode(keyiv).decode(), 'sly6B89wqxt2N')
#         keyiv = json.loads(keyiv)
#         key = keyiv['k7'].encode()
#         iv = keyiv['i7'].encode()
#         ## AES-ECB
#         if len(key) == 32 and len(iv) < 4: #ord(iv) == 0:
#             decrypter = pyAES.Decrypter(pyAES.AESModeOfOperationECB(key))
#             decrypted = decrypter.feed(codecs.decode(data.strip(), 'hex'))
#             decrypted += decrypter.feed()
#         elif len(key) == 16 and len(iv) == 16:
#             decrypter = pyAES.Decrypter(pyAES.AESModeOfOperationCBC(key, iv))
#             decrypted = decrypter.feed(codecs.decode(data.strip(), 'hex'))
#             decrypted += decrypter.feed()
#         elif len(key) == 24 and len(iv) == 8:
#             decrypter = pyDes.triple_des(key, pyDes.CBC, iv)
#             decrypted = decrypter.decrypt(codecs.decode(data.strip(), 'hex'))
#         else:
#             return data

#         decrypted = codecs.decode(re.findall('([a-f0-9]+)', decrypted.decode())[0], 'hex').decode()
#         data = decrypted
#     except:
#         #  import traceback
#         #  traceback.print_exc()
#          pass
#     #lib.common.log("JairoX_Decrypt:" + data)
#     return data
