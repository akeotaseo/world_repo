'''
    Dailymotion_com - FIXED FOR KODI 21
'''

import six
from kodi_six import xbmcplugin, xbmcaddon, xbmcgui, xbmc, xbmcvfs
import sys
import re
import json
import datetime
import tempfile
import requests
from six.moves import urllib_parse, html_parser

pluginhandle = int(sys.argv[1])
addon = xbmcaddon.Addon()
addonID = addon.getAddonInfo('id')
_icon = addon.getAddonInfo('icon')
_fanart = addon.getAddonInfo('fanart')
_path = addon.getAddonInfo('path')
_ipath = '{0}/resources/images/'.format(_path)
_kodiver = float(xbmcaddon.Addon('xbmc.addon').getAddonInfo('version')[:4])

if hasattr(xbmcvfs, "translatePath"):
    translate_path = xbmcvfs.translatePath
else:
    translate_path = xbmc.translatePath
channelFavsFile = translate_path("special://profile/addon_data/{0}/{0}.favorites".format(addonID))
HistoryFile = translate_path("special://profile/addon_data/{0}/{0}.history".format(addonID))
cookie_file = translate_path("special://profile/addon_data/{0}/cookies".format(addonID))
pDialog = xbmcgui.DialogProgress()
familyFilter = '1'

if not xbmcvfs.exists('special://profile/addon_data/' + addonID + '/settings.xml'):
    addon.openSettings()

if addon.getSetting('family_filter') == 'false':
    familyFilter = '0'

force_mode = addon.getSetting("forceViewMode") == "true"
if force_mode:
    menu_mode = addon.getSetting("MenuMode")
    video_mode = addon.getSetting("VideoMode")

maxVideoQuality = addon.getSetting("maxVideoQuality")
downloadDir = addon.getSetting("downloadDir")
qual = ['240', '380', '480', '720', '1080', '1440', '2160']
maxVideoQuality = qual[int(maxVideoQuality)]
language = addon.getSetting("language")
languages = ["ar_ES", "br_PT", "ca_EN", "ca_FR", "de_DE", "es_ES", "fr_FR",
             "in_EN", "id_ID", "it_IT", "ci_FR", "my_MS", "mx_ES", "pk_EN",
             "ph_EN", "tr_TR", "en_GB", "en_US", "vn_VI", "kr_KO", "tw_TW"]
language = languages[int(language)]
dmUser = addon.getSetting("dmUser")
itemsPerPage = addon.getSetting("itemsPerPage")
itemsPage = ["25", "50", "75", "100"]
itemsPerPage = itemsPage[int(itemsPerPage)]
urlMain = "https://api.dailymotion.com"
_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36'


class MLStripper(html_parser.HTMLParser):
    def __init__(self):
        self.reset()
        self.fed = []

    def handle_data(self, d):
        self.fed.append(d)

    def get_data(self):
        return ''.join(self.fed)


def strip_tags(html):
    parser = html_parser.HTMLParser()
    html = parser.unescape(html)
    s = MLStripper()
    s.feed(html)
    return s.get_data()


def strip_tags2(text):
    clean = re.compile('<.*?>')
    return re.sub(clean, '', text)


def index():
    addDir(translation(30025), "{0}/videos?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&list=what-to-watch&no_live=1&limit={1}&family_filter={2}&localization={3}&page=1".format(urlMain, itemsPerPage, familyFilter, language), 'listVideos', "{0}what_to_watch.png".format(_ipath))
    addDir(translation(30015), "{0}/videos?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&sort=trending&no_live=1&limit={1}&family_filter={2}&localization={3}&page=1".format(urlMain, itemsPerPage, familyFilter, language), 'listVideos', "{0}trending.png".format(_ipath))
    addDir(translation(30016), "{0}/videos?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&featured=1&no_live=1&limit={1}&family_filter={2}&localization={3}&page=1".format(urlMain, itemsPerPage, familyFilter, language), 'listVideos', "{0}featured.png".format(_ipath))
    addDir(translation(30003), "{0}/videos?fields=id,thumbnail_large_url,title,views_last_hour&availability=1&live_onair=1&sort=visited-month&limit={1}&family_filter={2}&localization={3}&page=1".format(urlMain, itemsPerPage, familyFilter, language), 'listLive', "{0}live.png".format(_ipath))
    addDir(translation(30006), "", 'listChannels', "{0}channels.png".format(_ipath))
    addDir(translation(30007), "{0}/users?fields=username,avatar_large_url,videos_total,views_total&sort=popular&limit={1}&family_filter={2}&localization={3}&page=1".format(urlMain, itemsPerPage, familyFilter, language), 'listUsers', "{0}users.png".format(_ipath))
    addDir(translation(30002), "{0}/videos?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&search=&sort=relevance&limit={1}&family_filter={2}&localization={3}&page=1".format(urlMain, itemsPerPage, familyFilter, language), 'search', "{0}search.png".format(_ipath))
    addDir("{0} {1}".format(translation(30002), translation(30003)), "", 'livesearch', "{0}search_live.png".format(_ipath))
    addDir("{0} {1}".format(translation(30002), translation(30007)), "", 'usersearch', "{0}search_users.png".format(_ipath))
    addDir(translation(30115), "", "History", "{0}search.png".format(_ipath))
    if dmUser:
        addDir(translation(30034), "", "personalMain", "{0}my_stuff.png".format(_ipath))
    else:
        addFavDir(translation(30024), "", "favouriteUsers", "{0}favourite_users.png".format(_ipath))
    xbmcplugin.endOfDirectory(pluginhandle)
    xbmcplugin.setContent(pluginhandle, "addons")
    if force_mode:
        xbmc.executebuiltin('Container.SetViewMode({0})'.format(menu_mode))


def update_listitem(li, infoLabels):
    if isinstance(infoLabels, dict):
        labels = infoLabels.copy()
        if _kodiver >= 19.8:
            vtag = li.getVideoInfoTag()
            if labels.get('Title'):
                vtag.setTitle(labels['Title'])
            if labels.get('Plot'):
                vtag.setPlot(labels['Plot'])
            if labels.get('Duration'):
                vtag.setDuration(int(labels['Duration']))
            if labels.get('Aired'):
                vtag.setFirstAired(labels['Aired'])
            if labels.get('Episode'):
                vtag.setEpisode(int(labels['Episode']))
        else:
            li.setInfo(type='Video', infoLabels=labels)

    return


def make_listitem(name='', labels=None, path=''):
    if _kodiver >= 18.0:
        offscreen = True
        if name:
            li = xbmcgui.ListItem(name, offscreen=offscreen)
        else:
            li = xbmcgui.ListItem(path=path, offscreen=offscreen)
    else:
        if name:
            li = xbmcgui.ListItem(name)
        else:
            li = xbmcgui.ListItem(path=path)

    if isinstance(labels, dict):
        update_listitem(li, labels)
    return li


def personalMain():
    addDir(translation(30041), "{0}/user/{1}/videos?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&sort=recent&limit={2}&family_filter={3}&localization={4}&page=1".format(urlMain, dmUser, itemsPerPage, familyFilter, language), 'listVideos', "{0}videos.png".format(_ipath))
    addDir(translation(30035), "{0}/user/{1}/following?fields=username,avatar_large_url,videos_total,views_total&sort=popular&limit={2}&family_filter={3}&localization={4}&page=1".format(urlMain, dmUser, itemsPerPage, familyFilter, language), 'listUsers', "{0}contacts.png".format(_ipath))
    addDir(translation(30036), "{0}/user/{1}/subscriptions?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&sort=recent&limit={2}&family_filter={3}&localization={4}&page=1".format(urlMain, dmUser, itemsPerPage, familyFilter, language), 'listVideos', "{0}following.png".format(_ipath))
    addDir(translation(30037), "{0}/user/{1}/favorites?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&sort=recent&limit={2}&family_filter={3}&localization={4}&page=1".format(urlMain, dmUser, itemsPerPage, familyFilter, language), 'listVideos', "{0}favourites.png".format(_ipath))
    addDir(translation(30038), "{0}/user/{1}/playlists?fields=id,name,videos_total&sort=recent&limit={2}&family_filter={3}&localization={4}&page=1".format(urlMain, dmUser, itemsPerPage, familyFilter, language), 'listUserPlaylists', "{0}playlists.png".format(_ipath))
    xbmcplugin.endOfDirectory(pluginhandle)
    xbmcplugin.setContent(pluginhandle, 'addons')
    if force_mode:
        xbmc.executebuiltin('Container.SetViewMode({0})'.format(menu_mode))


def listUserPlaylists(url):
    content = getUrl2(url)
    content = json.loads(content)
    for item in content['list']:
        vid = item['id']
        title = item['name'].encode('utf-8') if six.PY2 else item['name']
        vids = item['videos_total']
        addDir("{0} ({1})".format(title, vids), urllib_parse.quote_plus("{0}_{1}_{2}".format(vid, dmUser, title)), 'showPlaylist', "{0}playlists.png".format(_ipath))
    if content['has_more']:
        currentPage = content['page']
        nextPage = currentPage + 1
        addDir("{0} ({1})".format(translation(30001), nextPage), url.replace("page={0}".format(currentPage), "page={0}".format(nextPage)), 'listUserPlaylists', "{0}next_page2.png".format(_ipath))
    xbmcplugin.setContent(pluginhandle, "episodes")
    xbmcplugin.endOfDirectory(pluginhandle)


def showPlaylist(pid):
    url = "{0}/playlist/{1}/videos?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&sort=recent&limit={2}&family_filter={3}&localization={4}&page=1".format(urlMain, pid, itemsPerPage, familyFilter, language)
    listVideos(url)


def favouriteUsers():
    xbmcplugin.addSortMethod(pluginhandle, xbmcplugin.SORT_METHOD_LABEL)
    if xbmcvfs.exists(channelFavsFile):
        with open(channelFavsFile, 'r') as fh:
            content = fh.read()
            match = re.compile('###USER###=(.+?)###THUMB###=(.*?)###END###', re.DOTALL).findall(content)
            for user, thumb in match:
                addUserFavDir(user, 'owner:{0}'.format(user), 'sortVideos1', thumb)
    xbmcplugin.endOfDirectory(pluginhandle)
    xbmcplugin.setContent(pluginhandle, "addons")
    if force_mode:
        xbmc.executebuiltin('Container.SetViewMode({0})'.format(menu_mode))


def listChannels():
    content = getUrl2("{0}/channels?family_filter={1}&localization={2}".format(urlMain, familyFilter, language))
    content = json.loads(content)
    for item in content['list']:
        cid = item['id']
        title = item['name'].encode('utf-8') if six.PY2 else item['name']
        desc = item['description'].encode('utf-8') if six.PY2 else item['description']
        addDir(title, 'channel:{0}'.format(cid), 'sortVideos1', '{0}channels.png'.format(_ipath), desc)
    xbmcplugin.endOfDirectory(pluginhandle)


def sortVideos1(url):
    item_type = url[:url.find(":")]
    gid = url[url.find(":") + 1:]
    if item_type == "group":
        url = "{0}/group/{1}/videos?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&sort=recent&limit={2}&family_filter={3}&localization={4}&page=1".format(urlMain, gid, itemsPerPage, familyFilter, language)
    else:
        url = "{0}/videos?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&{1}={2}&sort=recent&limit={3}&family_filter={4}&localization={5}&page=1".format(urlMain, item_type, gid, itemsPerPage, familyFilter, language)
    addDir(translation(30015), url.replace("sort=recent", "sort=trending"), 'listVideos', "{0}trending.png".format(_ipath))
    addDir(translation(30008), url, 'listVideos', "{0}most_recent.png".format(_ipath))
    addDir(translation(30009), url.replace("sort=recent", "sort=visited"), 'sortVideos2', "{0}most_viewed.png".format(_ipath))
    if item_type == "owner":
        addDir("- {0}".format(translation(30038)), "{0}/user/{1}/playlists?fields=id,name,videos_total&sort=recent&limit={2}&family_filter={3}&localization={4}&page=1".format(urlMain, gid, itemsPerPage, familyFilter, language), 'listUserPlaylists', "{0}playlists.png".format(_ipath))
    xbmcplugin.endOfDirectory(pluginhandle)
    xbmcplugin.setContent(pluginhandle, 'addons')
    if force_mode:
        xbmc.executebuiltin('Container.SetViewMode({0})'.format(menu_mode))


def sortVideos2(url):
    addDir(translation(30010), url.replace("sort=visited", "sort=visited-hour"), "listVideos", "{0}most_viewed.png".format(_ipath))
    addDir(translation(30011), url.replace("sort=visited", "sort=visited-today"), "listVideos", "{0}most_viewed.png".format(_ipath))
    addDir(translation(30012), url.replace("sort=visited", "sort=visited-week"), "listVideos", "{0}most_viewed.png".format(_ipath))
    addDir(translation(30013), url.replace("sort=visited", "sort=visited-month"), "listVideos", "{0}most_viewed.png".format(_ipath))
    addDir(translation(30014), url, 'listVideos', "{0}most_viewed.png".format(_ipath))
    xbmcplugin.endOfDirectory(pluginhandle)
    xbmcplugin.setContent(pluginhandle, 'addons')
    if force_mode:
        xbmc.executebuiltin('Container.SetViewMode({0})'.format(menu_mode))


def sortUsers1():
    url = "{0}/users?fields=username,avatar_large_url,videos_total,views_total&sort=popular&limit={1}&family_filter={2}&localization={3}&page=1".format(urlMain, itemsPerPage, familyFilter, language)
    addDir(translation(30040), url, 'sortUsers2', "")
    addDir(translation(30016), "{0}&filters=featured".format(url), 'sortUsers2', "")
    addDir(translation(30017), "{0}&filters=official".format(url), 'sortUsers2', "")
    addDir(translation(30018), "{0}&filters=creative".format(url), 'sortUsers2', "")
    xbmcplugin.endOfDirectory(pluginhandle)


def sortUsers2(url):
    addDir(translation(30019), url, 'listUsers', "")
    addDir(translation(30020), url.replace("sort=popular", "sort=commented"), 'listUsers', "")
    addDir(translation(30021), url.replace("sort=popular", "sort=rated"), 'listUsers', "")
    xbmcplugin.endOfDirectory(pluginhandle)


def listVideos(url):
    xbmcplugin.setContent(pluginhandle, 'episodes')
    content = getUrl2(url)
    content = json.loads(content)
    count = 1
    for item in content['list']:
        vid = item['id']
        title = item['title'].encode('utf-8') if six.PY2 else item['title']
        desc = strip_tags(item['description']).encode('utf-8') if six.PY2 else strip_tags2(item['description'])
        duration = item['duration']
        user = item['owner.username']
        date = item['taken_time']
        thumb = item['thumbnail_large_url']
        views = item['views_total']
        try:
            date = datetime.datetime.fromtimestamp(int(date)).strftime('%Y-%m-%d')
        except:
            date = ""
        temp = ("User: {0}  |  {1} Views  |  {2}".format(user, views, date))
        temp = temp.encode('utf-8') if six.PY2 else temp
        try:
            desc = "{0}\n{1}".format(temp, desc)
        except:
            desc = ""
        addLink(title, vid, 'playVideo', thumb.replace("\\", ""), user, desc, duration, date, count)
        count += 1
    if content['has_more']:
        currentPage = content['page']
        nextPage = currentPage + 1
        addDir("{0} ({1})".format(translation(30001), nextPage), url.replace("page={0}".format(currentPage), "page={0}".format(nextPage)), 'listVideos', "{0}next_page2.png".format(_ipath))
    xbmcplugin.endOfDirectory(pluginhandle)
    xbmcplugin.setContent(pluginhandle, "episodes")
    if force_mode:
        xbmc.executebuiltin('Container.SetViewMode({0})'.format(video_mode))


def listUsers(url):
    content = getUrl2(url)
    content = json.loads(content)
    for item in content['list']:
        if item['username']:
            user = item['username'].encode('utf-8') if six.PY2 else item['username']
            thumb = item['avatar_large_url']
            videos = item['videos_total']
            views = item['views_total']
            addUserDir(user, 'owner:{0}'.format(user), 'sortVideos1', thumb.replace("\\", ""), "Views: {0}\nVideos: {1}".format(views, videos))
    if content['has_more']:
        currentPage = content['page']
        nextPage = currentPage + 1
        addDir("{0} ({1})".format(translation(30001), nextPage), url.replace("page={0}".format(currentPage), "page={0}".format(nextPage)), 'listUsers', "{0}next_page.png".format(_ipath))
    xbmcplugin.endOfDirectory(pluginhandle)
    xbmcplugin.setContent(pluginhandle, "addons")
    if force_mode:
        xbmc.executebuiltin('Container.SetViewMode({0})'.format(menu_mode))


def listLive(url):
    content = getUrl2(url)
    content = json.loads(content)
    for item in content['list']:
        title = item['title'].encode('utf-8') if six.PY2 else item['title']
        vid = item['id']
        thumb = item['thumbnail_large_url']
        views = item['views_last_hour']
        addLiveLink(title, vid, 'playLiveVideo', thumb.replace("\\", ""), 'Views: {}'.format(views))
    if content['has_more']:
        currentPage = content['page']
        nextPage = currentPage + 1
        addDir("{0} ({1})".format(translation(30001), nextPage), url.replace("page={0}".format(currentPage), "page={0}".format(nextPage)), 'listLive', "{0}next_page2.png".format(_ipath))
    xbmcplugin.endOfDirectory(pluginhandle)
    xbmcplugin.setContent(pluginhandle, "episodes")
    if force_mode:
        xbmc.executebuiltin('Container.SetViewMode({0})'.format(menu_mode))


def playVideo(vid, live=False):
    data = getStreamUrl(vid)
    if not data:
        xbmcgui.Dialog().notification('Dailymotion', 'Αποτυχία λήψης ροής', _icon, 5000)
        return

    url = data['url']
    # Χρήση ενός πολύ βασικού User-Agent
    ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/121.0.0.0'
    
    # Κατασκευή του URL με headers για τον FFmpeg
    # Προσοχή: Χωρίς καθόλου κενά, μόνο τα απολύτως απαραίτητα
    headers = 'User-Agent=' + urllib_parse.quote(ua)
    headers += '&Referer=' + urllib_parse.quote('https://www.dailymotion.com/')
    
    if data.get('cookie'):
        headers += '&Cookie=' + urllib_parse.quote(data['cookie'])
    
    full_url = url + '|' + headers
    
    li = xbmcgui.ListItem(path=full_url)
    li.setMimeType('video/mp4') # Το δηλώνουμε ως MP4 ακόμα και αν είναι m3u8 για να παρακάμψουμε το ISA
    li.setContentLookup(False)
    
    # Επιβολή του εσωτερικού Player
    xbmcplugin.setResolvedUrl(pluginhandle, True, listitem=li)

def getStreamUrl(vid):
    session = requests.Session()
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/121.0.0.0',
        'Referer': 'https://www.dailymotion.com/'
    }
    
    try:
        # 1. Πρώτη κλήση για να πάρουμε τα βασικά cookies
        session.get("https://www.dailymotion.com/", headers=headers, timeout=5)
        
        # 2. Κλήση στο metadata API
        api_url = "https://www.dailymotion.com/player/metadata/video/{0}".format(vid)
        r = session.get(api_url, headers=headers, timeout=10)
        content = r.json()
        
        # Λήψη cookies
        cookie_dict = session.cookies.get_dict()
        cookie_str = "; ".join([f"{k}={v}" for k, v in cookie_dict.items()])
        
        qualities = content.get('qualities', {})
        
        # ΠΡΟΤΕΡΑΙΟΤΗΤΑ 1: MP4 (Δεν ζητάει σχεδόν ποτέ ISA)
        for q in ['1080', '720', '480', '380', '240']:
            if q in qualities:
                for source in qualities[q]:
                    if source.get('type') == 'video/mp4':
                        return {'url': source.get('url'), 'cookie': cookie_str}

        # ΠΡΟΤΕΡΑΙΟΤΗΤΑ 2: HLS (m3u8) - Μόνο αν δεν υπάρχει MP4
        if 'auto' in qualities:
            return {'url': qualities['auto'][0].get('url'), 'cookie': cookie_str}
            
    except Exception as e:
        xbmc.log("DAILYMOTION FINAL ERROR: " + str(e), xbmc.LOGERROR)
    
    return None


def addLink(name, url, mode, iconimage, user, desc, duration, date, nr):
    u = "{0}?url={1}&mode={2}".format(sys.argv[0], urllib_parse.quote_plus(url), mode)
    liz = make_listitem(name=name, labels={"Title": name, "Plot": desc, "Aired": date, "Duration": duration, "Episode": nr})
    liz.setArt({'thumb': iconimage, 'icon': _icon, 'poster': iconimage, 'fanart': _fanart})
    liz.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)


def addLiveLink(name, url, mode, iconimage, desc):
    u = "{0}?url={1}&mode={2}".format(sys.argv[0], urllib_parse.quote_plus(url), mode)
    liz = make_listitem(name=name, labels={"Title": name, "Plot": desc})
    liz.setArt({'thumb': iconimage, 'icon': _icon, 'poster': iconimage, 'fanart': _fanart})
    liz.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)


def addDir(name, url, mode, iconimage, desc=""):
    u = "{0}?url={1}&mode={2}".format(sys.argv[0], urllib_parse.quote_plus(url), mode)
    liz = make_listitem(name=name, labels={"Title": name, "Plot": desc})
    liz.setArt({'thumb': iconimage, 'icon': _icon, 'poster': iconimage, 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)


def addUserDir(name, url, mode, iconimage, desc):
    u = "{0}?url={1}&mode={2}".format(sys.argv[0], urllib_parse.quote_plus(url), mode)
    liz = make_listitem(name=name, labels={"Title": name, "Plot": desc})
    liz.setArt({'thumb': iconimage, 'icon': _icon, 'poster': iconimage, 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)


def addFavDir(name, url, mode, iconimage):
    u = "{0}?url={1}&mode={2}".format(sys.argv[0], urllib_parse.quote_plus(url), mode)
    liz = make_listitem(name=name, labels={"Title": name})
    liz.setArt({'thumb': iconimage, 'icon': _icon, 'poster': iconimage, 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)


def addUserFavDir(name, url, mode, iconimage):
    u = "{0}?url={1}&mode={2}".format(sys.argv[0], urllib_parse.quote_plus(url), mode)
    liz = make_listitem(name=name, labels={"Title": name})
    liz.setArt({'thumb': iconimage, 'icon': _icon, 'poster': iconimage, 'fanart': _fanart})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)


def translation(lid):
    return addon.getLocalizedString(lid)


def getUrl2(url):
    headers = {'User-Agent': _UA}
    r = requests.get(url, headers=headers)
    return r.text


def search(url):
    keyboard = xbmc.Keyboard('', translation(30002))
    keyboard.doModal()
    if keyboard.isConfirmed() and keyboard.getText():
        search_string = keyboard.getText()
        url2 = url.replace("&search=", "&search={0}".format(urllib_parse.quote_plus(search_string)))
        listVideos(url2)


def History():
    if xbmcvfs.exists(HistoryFile):
        with open(HistoryFile, 'r') as fh:
            content = fh.readlines()
            if len(content) > 0:
                # Simple implementation for History
                for line in content:
                    item = json.loads(line)
                    addDir(item['name'], item['url'], item['mode'], "{0}search.png".format(_ipath))
                xbmcplugin.endOfDirectory(pluginhandle)


params = dict(urllib_parse.parse_qsl(sys.argv[2][1:]))
mode = params.get('mode')
url = params.get('url')
name = params.get('name')

if mode == 'listVideos':
    listVideos(url)
elif mode == 'listLive':
    listLive(url)
elif mode == 'listUsers':
    listUsers(url)
elif mode == 'listChannels':
    listChannels()
elif mode == 'personalMain':
    personalMain()
elif mode == 'favouriteUsers':
    favouriteUsers()
elif mode == 'listUserPlaylists':
    listUserPlaylists(url)
elif mode == 'showPlaylist':
    showPlaylist(url)
elif mode == 'sortVideos1':
    sortVideos1(url)
elif mode == 'sortVideos2':
    sortVideos2(url)
elif mode == 'sortUsers1':
    sortUsers1()
elif mode == 'sortUsers2':
    sortUsers2(url)
elif mode == 'playVideo':
    playVideo(url)
elif mode == 'playLiveVideo':
    playVideo(url, live=True)
elif mode == 'search':
    search(url)
elif mode == 'History':
    History()
else:
    index()