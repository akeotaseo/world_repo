# -*- coding: utf-8 -*-
# Module: view
# Author: Zeltorix
# Created on: 2023.10.19
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Плагин для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
import sys
from urllib.parse import urlencode
from pathlib import Path

# Модули KODI
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


from web_api_request import headers


SORT_METHOD_ALBUM = 14
SORT_METHOD_ALBUM_IGNORE_THE = 15
SORT_METHOD_ARTIST = 11
SORT_METHOD_ARTIST_IGNORE_THE = 13
SORT_METHOD_BITRATE = 43
SORT_METHOD_CHANNEL = 41
SORT_METHOD_COUNTRY = 17
SORT_METHOD_DATE = 3
SORT_METHOD_DATEADDED = 21
SORT_METHOD_DATE_TAKEN = 44
SORT_METHOD_DRIVE_TYPE = 6
SORT_METHOD_DURATION = 8
SORT_METHOD_EPISODE = 24
SORT_METHOD_FILE = 5
SORT_METHOD_FULLPATH = 35
SORT_METHOD_GENRE = 16
SORT_METHOD_LABEL = 1
SORT_METHOD_LABEL_IGNORE_FOLDERS = 36
SORT_METHOD_LABEL_IGNORE_THE = 2
SORT_METHOD_LASTPLAYED = 37
SORT_METHOD_LISTENERS = 39
SORT_METHOD_MPAA_RATING = 31
SORT_METHOD_NONE = 0
SORT_METHOD_PLAYCOUNT = 38
SORT_METHOD_PLAYLIST_ORDER = 23
SORT_METHOD_PRODUCTIONCODE = 28
SORT_METHOD_PROGRAM_COUNT = 22
SORT_METHOD_SIZE = 4
SORT_METHOD_SONG_RATING = 29
SORT_METHOD_SONG_USER_RATING = 30
SORT_METHOD_STUDIO = 33
SORT_METHOD_STUDIO_IGNORE_THE = 34
SORT_METHOD_TITLE = 9
SORT_METHOD_TITLE_IGNORE_THE = 10
SORT_METHOD_TRACKNUM = 7
SORT_METHOD_UNSORTED = 40
SORT_METHOD_VIDEO_RATING = 19
SORT_METHOD_VIDEO_RUNTIME = 32
SORT_METHOD_VIDEO_SORT_TITLE = 26
SORT_METHOD_VIDEO_SORT_TITLE_IGNORE_THE = 27
SORT_METHOD_VIDEO_TITLE = 25
SORT_METHOD_VIDEO_USER_RATING = 20
SORT_METHOD_VIDEO_YEAR = 18


class View:
    __slots__ = []

    # Получите URL-адрес плагина в формате plugin://id_плагина.
    _url = sys.argv[0]
    # ID плагина
    id_plugin: str = _url.split("/")[2]
    # Получить заготовка плагина в виде целого числа.
    _handle: int = int(sys.argv[1])
    _kodi_version_major: int = int(xbmc.getInfoLabel("System.BuildVersion").split(".")[0])
    plugin_folder = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    library_folder = Path(Path(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))).parent.parent, "library")

    def convert_to_url(self, **kwargs) -> str:
        # Преобразование ключа и значения в ссылку данных для дополнения в виде URL
        return f"{self._url}/?{urlencode(kwargs)}"

    def reload(self, **kwargs):
        xbmc.executebuiltin(f"Container.Update({self.convert_to_url(**kwargs)})")

    @staticmethod
    def get_setting_str(api_key: str) -> str:
        return xbmcaddon.Addon().getSetting(api_key)

    @staticmethod
    def get_setting_bool(api_key: str) -> bool:
        return xbmcaddon.Addon().getSettingBool(api_key)

    @staticmethod
    def get_setting_int(api_key: str) -> int:
        return xbmcaddon.Addon().getSettingInt(api_key)

    @staticmethod
    def set_setting(id_: str, value: str) -> bool:
        xbmcaddon.Addon().setSetting(id=id_, value=value)
        return True

    @staticmethod
    def dialog_text_input(label: str = "Ввод текста") -> str:
        item = xbmcgui.Dialog().input(
            label,
            type=xbmcgui.INPUT_ALPHANUM)
        if len(item) > 2:
            return item

    @staticmethod
    def dialog_notification(heading: str, message: str, type_message: str = "info") -> None:
        if type_message == "warning":
            notification = xbmcgui.NOTIFICATION_WARNING
        elif type_message == "error":
            notification = xbmcgui.NOTIFICATION_ERROR
        elif type_message == "info":
            notification = xbmcgui.NOTIFICATION_INFO
        else:
            notification = xbmcgui.NOTIFICATION_INFO

        xbmcgui.Dialog().notification(
            heading=heading,
            message=message,
            icon=notification,
            time=5000,
        )

    @staticmethod
    def dialog_ok(heading: str, message: str) -> bool:
        return xbmcgui.Dialog().ok(heading=heading, message=message)

    @staticmethod
    def dialog_yesno(heading: str, message: str) -> bool:
        return xbmcgui.Dialog().yesno(heading=heading, message=message)

    @staticmethod
    def dialog_text_viewer(heading: str, message: str, monospace_font: bool = False) -> bool:
        return xbmcgui.Dialog().textviewer(heading=heading, text=message, usemono=monospace_font)

    @staticmethod
    def check_modules() -> None:
        def target_module(check_module: str) -> None:
            try:
                xbmcaddon.Addon(check_module)
            except (ModuleNotFoundError, RuntimeError):
                xbmcgui.Dialog().notification(
                    heading=f"Установка библиотеки {check_module}",
                    message=f"{check_module}",
                    icon=xbmcgui.NOTIFICATION_WARNING,
                    time=5000)
                xbmc.executebuiltin(f"RunPlugin('plugin://{check_module}')")

        target_module("inputstream.adaptive")
        target_module("script.module.beautifulsoup4")

    def output_logs(self,
                    message: str,
                    level: (xbmc.LOGDEBUG,
                            xbmc.LOGINFO,
                            xbmc.LOGWARNING,
                            xbmc.LOGERROR,
                            xbmc.LOGFATAL,
                            int) = xbmc.LOGERROR
                    ) -> None:
        """
        Вывод лога в журнал KODI.

        :param str message:  Сообщение для вывода в логи.
        :param int level:    Тип вывода логов, по умолчанию тип ОШИБКИ

        ===============  ===============  =========================
        Значение тестом  Значение числом  Описание
        ===============  ===============  =========================
        LOGDEBUG         0                Для дебагера
        LOGINFO          1                Для информационных
        LOGNOTICE        2                Для вывода оповещений
        LOGWARNING       3                Для вывода предупреждений
        LOGERROR         4                Для вывода ошибок
        LOGFATAL         5                Для вывода
        ===============  ===============  =========================
        Используются либо текстовые значение либо числовые
        """
        if level == xbmc.LOGERROR or level == 4 or level == xbmc.LOGFATAL or level == 5:
            xbmc.log(
                msg=f"{self.id_plugin}\n\n\n{message}\n\n\n",
                level=level
            )
        elif self.get_setting_bool("log"):
            xbmc.log(
                msg=f"{self.id_plugin}\n{message}\n",
                level=level
            )

    def play(self, data: (str, dict), manifest_type: (str, bool) = False) -> None:
        if type(data) is dict:
            path = data["link_play"]
            manifest_type = data["type"]
            if data.get("add_headers"):
                for header, value in data["add_headers"].items():
                    headers[header] = value
        else:
            path = data

        if manifest_type == "hls":
            mime_type = "application/x-mpegURL"
        elif manifest_type == "mdp":
            mime_type = "application/dash+xml"
        else:
            mime_type = "application/x-mpegURL"

        # Создаю элемент с указанием url для воспроизведения.
        play_item = xbmcgui.ListItem(path=path)

        if self.get_setting_bool("inputstream_adaptive") and manifest_type:
            # Использовать inputstream.adaptive для входящего медиапотока
            play_item.setProperty("inputstream", "inputstream.adaptive")
            # Тип манифеста медиапотока
            play_item.setProperty("inputstream.adaptive.manifest_type", manifest_type)
            # Подбор разрешения под экран
            play_item.setProperty("inputstream.adaptive.stream_selection_type", "adaptive")
            # Выбор разрешения в меню
            play_item.setProperty("inputstream.adaptive.stream_selection_type", "manual-osd")
            # Заголовки для загрузки манифестов и потоков (аудио/видео/субтитры) до KODI 20
            play_item.setProperty("inputstream.adaptive.stream_headers", urlencode(headers))

            if self._kodi_version_major >= 20:
                play_item.setProperty("inputstream.adaptive.manifest_headers", urlencode(headers))

            # Тип запрашиваемого контента
            play_item.setMimeType(mime_type)
            # Если отключено, запросы HEAD, например, для определения типа mime, не будут отправляться.
            play_item.setContentLookup(True)
            # Обновление манифеста, возможно это убирает баг с зависанием
            play_item.setProperty("inputstream.adaptive.manifest_update_parameter", "full")

        # Передача элемента в оболочку проигрывателя Kodi.
        xbmcplugin.setResolvedUrl(handle=self._handle, succeeded=True, listitem=play_item)

    def output(self, input_data: dict) -> None:
        if input_data.get("content"):
            # files, songs, artists, albums, movies, tvshows, episodes, musicvideos, videos, images, games
            xbmcplugin.setContent(self._handle, input_data["content"])
        else:
            xbmcplugin.setContent(self._handle, "videos")

        if input_data.get("category"):
            xbmcplugin.setPluginCategory(self._handle, input_data["category"])
        else:
            xbmcplugin.setPluginCategory(self._handle, "")

        if input_data.get("sort"):
            for sort in input_data["sort"]:
                xbmcplugin.addSortMethod(self._handle, sort)
        else:
            xbmcplugin.addSortMethod(self._handle, xbmcplugin.SORT_METHOD_NONE)

        if input_data.get("translate") and input_data["translate"]:
            list_item = xbmcgui.ListItem(label=input_data["translate"]["title"])
            vinfo = list_item.getVideoInfoTag()
            vinfo.setTitle(input_data["translate"]["title"])
            is_folder = False
            data_translate = f"{input_data['translate']['data']},{'|'.join(input_data['translate']['list'])}"
            url = self.convert_to_url(router=input_data["translate"]["router"], data=data_translate)
            xbmcplugin.addDirectoryItem(self._handle, url, list_item, is_folder)

        for item in input_data["list"]:
            list_item = xbmcgui.ListItem(label=item["title"])

            if item.get("context_menu"):
                list_item.addContextMenuItems(item["context_menu"])

            if self._kodi_version_major >= 20:
                vinfo = list_item.getVideoInfoTag()
                vinfo.setTitle(item["title"])
                if item.get("plot"):
                    vinfo.setPlot(item["plot"])
                if item.get("genres"):
                    vinfo.setGenres(item["genres"])
                if item.get("premiered"):
                    vinfo.setPremiered(item["premiered"])
                if item.get("duration"):
                    vinfo.setDuration(item["duration"])
                if item.get("episode"):
                    vinfo.setEpisode(item["episode"])
                if item.get("season"):
                    vinfo.setSeason(item["season"])
                vinfo.setMediaType("video")
            else:
                list_item.setInfo("video", {"title": item["title"]})
                if item.get("plot"):
                    list_item.setInfo("video", {"plot": item["plot"]})
                if item.get("genres"):
                    list_item.setInfo("video", {"genre": item["genres"]})
                if item.get("premiered"):
                    list_item.setInfo("video", {"premiered": item["premiered"]})
                list_item.setInfo("video", {"mediatype": "video"})

            if item.get("images"):
                list_item.setArt({"thumb": item["images"]})
                list_item.setArt({"icon": item["images"]})
                list_item.setArt({"fanart": item["images"]})

            if item.get("thumb"):
                list_item.setArt({"thumb": item["thumb"]})
            if item.get("poster"):
                list_item.setArt({"poster": item["poster"]})
            if item.get("banner"):
                list_item.setArt({"banner": item["banner"]})
            if item.get("fanart"):
                list_item.setArt({"fanart": item["fanart"]})
            if item.get("clearart"):
                list_item.setArt({"clearart": item["clearart"]})
            if item.get("clearlogo"):
                list_item.setArt({"clearlogo": item["clearlogo"]})
            if item.get("landscape"):
                list_item.setArt({"landscape": item["landscape"]})
            if item.get("icon"):
                list_item.setArt({"icon": item["icon"]})

            if item.get("select"):
                list_item.select(item["select"])

            # Внутренний переход есть
            is_folder: bool = True
            if item.get("not_folder"):
                is_folder: bool = False
            if item.get("play"):
                list_item.setProperty("IsPlayable", "true")
                # Переход внутрь не требуется, можно отключить
                is_folder: bool = False
            if not item.get("router") and not item.get("data"):
                is_folder: bool = False
            if item.get("router"):
                router = item["router"]
            else:
                router = ""
            url: str = self.convert_to_url(router=router)
            if item.get("data") and type(item["data"]) is dict:
                url: str = self.convert_to_url(router=router, **item["data"])
            elif item.get("data"):
                url: str = self.convert_to_url(router=router, data=item["data"])

            xbmcplugin.addDirectoryItem(self._handle, url, list_item, is_folder)

        xbmcplugin.endOfDirectory(self._handle)
