# -*- coding: utf-8 -*-

import xbmcgui, json, urllib, xbmcplugin, sys
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"

#Baseurl = 'https://xrysoi.pro/'


def menu_Old_series():
    addDir('[B][COLOR white]MacGyver[/COLOR][/B] |[B][COLORlime]1985–1992[/COLOR][/B]', 'http://tainio-mania.online/uploads/playlists/10036.txt', 90001, 'http://tainio-mania.co/uploads/mini/posterentrypage/f9/56b30232da42e372666b4550863e92.jpg', FANART, '')
    addDir('[COLOR white] Ανά έτος[/COLOR]', '', 46, 'https://xrysoi.pro/wp-content/uploads/2015/03/logo-GM.png', FANART, '')
    addDir('[COLOR white] Κατηγορίες[/COLOR]', '', 47, 'https://xrysoi.pro/wp-content/uploads/2015/03/logo-GM.png', FANART, '')
    addDir('[COLOR white] Αναζήτηση[/COLOR]', '', 45, 'https://www.freeiconspng.com/uploads/search-icon-png-22.png', FANART, '')
    views.selectView('menu', 'menu-view')


def Old_series():
    # openn.addDir('[B][COLOR white]Ο Ιησούς από τη Ναζαρέτ [/COLOR][/B] |[B][COLORlime]1977[/COLOR][/B]', 'http://tenies-online.club/engine/ajax/controller.php?mod=playlist&news_id=3942', 90002, 'http://tenies-online.club/uploads/mini/posterteniesarxiki/e4/f350add7754496202a177cdfc41282.jpg', addon.art,
    #              '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΤο μονοπάτι της ζωής του Ιησού Χριστού, από τη Γέννηση την Ανάληψη αναδημιουργούνται μέχρι την παραμικρή λεπτομέρεια. Η βιογραφία ενός πραγματικού προσώπου. Ακόμη και εκείνοι που είναι εξοικειωμένοι με το κείμενο της Καινής Διαθήκης σπάνια διακρίνουν ένα ιστορικό γεγονός - τόσο μακριά αυτές τις μέρες. Το προσκύνημα της Νεολαίας και της βάπτισης, το δώρο της εξεύρεσης μιας νέας διδασκαλίας, το κήρυγμα, οι μαθητές η προδοσία και το μαρτύριο - όλα αυτά τα ορόσημα της ιστορίας του υιού του ανθρώπου')
    openn.addDir('[B][COLOR white]MacGyver[/COLOR][/B] |[B][COLORlime]1985–1992[/COLOR][/B]', 'http://tainio-mania.co/uploads/playlists/10036.txt', 90001, 'http://tainio-mania.co/uploads/mini/posterentrypage/f9/56b30232da42e372666b4550863e92.jpg', addon.art,
                 '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΟ ΜακΓκάιβερ είναι ένας μυστικός πράκτορας με αποστολή να εξουδετερώνει όσους υπονομεύουν την παγκόσμια ειρήνη και δικαιοσύνη. Όμως, αυτό που τον κάνει ξεχωριστό είναι τα μέσα που χρησιμοποιεί για να αντιμετωπίσει τον εχθρό. Αντίθετα από τους άλλους πράκτορες, ο ΜακΓκάιβερ έχει στη διάθεσή του το τελειότερο και πιο αποτελεσματικό υπερ-όπλο, που δεν είναι άλλο από το επινοητικό μυαλό του. Αρνούμενος να χρησιμοποιήσει συμβατικά όπλα, με μόνη βοήθεια συνήθως έναν ελβετικό σουγιά και μονωτικές ταινίες, ο ΜακΓκάιβερ επιλέγει κάθε φορά τον πιο κατάλληλο συνδυασμό από γνώσεις χημείας, φυσικής και πρακτικής για να αντεπεξέλθει στις πιο δύσκολες συνθήκες ή για να παγιδέψει τον εχθρό. Και όσο πιο πολύ οι εχθροί υποτιμούν τις ανορθόδοξες μεθόδους του, τόσο πιο πολύ τα σχέδια τους κινδυνεύουν να αποτύχουν…')
    openn.addDir(
        '[B][COLOR white]' + addon.Lang(32067).encode('utf-8') + '[/COLOR][/B] |[B][COLORlime]1974-1983[/COLOR][/B]',
        'https://tainio-mania.online/uploads/playlists/2839.txt?v=1581172579', 90001,
        'http://tainio-mania.online/uploads/mini/posterarxiki/eb/e75f6fc512e3a111bcd37e2b97caa8.jpg', addon.art,
        '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΤο Μικρό Σπίτι Στο Λιβάδι (The Little House on the Prairie)ήταν μια σειρά αμερικανικής προέλευσης αυτοτελών ωριαίων (με τις διαφημίσεις) επεισοδίων του Ραδιοτηλεοπτικού Δικτύου ΝBC. Ξεκίνησε να προβάλλεται στις 11 Σεπτεμβρίου του 1974 και ολοκληρώθηκε στις 21 Μαρτίου του 1983. Στην τηλεοπτική περίοδο1982-83, με την αποχώρηση (και το μετέπειτα θάνατο απο καρκίνο) του Michael Landon, η σειρά βγήκε στον αέρα με τον τίτλο "Little House: A New Beginning". Επίσης, μια ακόμα τρίωρη ειδική σύνθεση επεισοδίων με τη μορφή τηλεταινίας μακράς διαρκείας που ονομάστηκε "The Little House Years" βγήκε στον αέρα το 1979. ')
    openn.addDir(
        '[B][COLOR white]' + addon.Lang(32068).encode('utf-8') + '[/COLOR][/B] |[B][COLORlime]1982[/COLOR][/B]',
        'http://tainio-mania.online/uploads/playlists/15005.txt', 90001, 'http://tainio-mania.co/uploads/mini/posterarxiki/ae/7c5659df7e71b88d71dd2d39dca20b.jpg',
        addon.art,
        '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΟ Michael Long, είναι ένας αστυνομικός, διώκτης του εγκλήματος, ο οποίος τραυματίστηκε σοβαρά επί του καθήκοντος. Με το πέρασμα του χρόνου και ανακτώντας τις δυνάμεις , με βοήθεια από ένα μυστηριώδη ευεργέτη, του προέδρου της εταιρίας Knight, ο Michael αναλαμβάνει πάλι τον ρόλο του διώκτη του εγκλήματος, αυτή τη φορά τελείως διαφορετικά από οτι είχε συνηθίσει . Με νέο πρόσωπο πλέον, προσλαμβάνεται από το ίδρυμα (FLAG), ώστε να βοηθά την αστυνομία να επιτελέσει το έργο της. Με πρωτοφανή εξοπλισμό, ένα σπορ αυτοκίνητο με ενσωματομένο επεξεργαστή που σκέφτεται και δρα, καθώς και το ίδρυμα, ο Michael Knight, ερευνά και οδηγεί στη φυλακή κακοποιούς, ένοχους για διάφορα παραπτώματα ή εγκλήματα. Υπότιτλοι: Ελληνικοί ')
    openn.addDir('[B][COLOR white]Miami Vice[/COLOR][/B] |[B][COLORlime]1984–1990[/COLOR][/B]',
                 'http://tainio-mania.online/uploads/playlists/10289.txt', 90001,
                 'http://tainio-mania.online/uploads/mini/posterarxiki/02/adc211bf16ac553a5fdeb235597ce0.jpg', addon.art,
                 '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nMiami Vice, μια δημοφιλές και καινοτόμα τηλεοπτική σειρά της δεκαετίας του 80.Δύο ντετέκτιβ της αστυνομίας που εργάζονται ως μυστικοί στην πόλη του Maimi κατά της πορνείας, την διακίνηση ναρκωτικών και των παράνομων όπλων που κινούνται στον υπόκοσμο του εγκλήματος της πόλης.Υπότιτλοι: Ελληνικοί')
    openn.addDir(
        '[B][COLOR white]' + addon.Lang(32069).encode('utf-8') + '[/COLOR][/B] |[B][COLORlime]1987–1997[/COLOR][/B]',
        'http://tainio-mania.online/uploads/playlists/1663.txt', 90001,
        'http://tainio-mania.online/uploads/mini/posterarxiki/c8/80d60d7a9398970443d8ff54db7526.jpg', addon.art,
        '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΟ Αλ Μπάντι είναι ένας μισάνθρωπος πωλητής γυναικείων υποδυμάτων με μια απαίσια ζωή!Μισεί την δουλειά του,η γυναίκα του είναι τεμπέλα,ο γιός του είναι άκρως δυσλειτουργικός ιδιαιτέρως με τις γυναίκες και η κόρη του είναι ένα καχύποπτο και ασύδοτο πλάσμα.Διασκεδάστε με την καθημερινότητά τους σε μια απίστευτη σειρά γέλιου απο το ανιμα φορουμ αποκλειστικά για εσάς.Η σειρά έχει κερδίσει 7 χρυσές σφαίρες και έχει προταθεί άλλες 21 φορές!')
    openn.addDir(
        '[B][COLOR white]' + addon.Lang(32070).encode('utf-8') + '[/COLOR][/B] |[B][COLORlime]1985–1989[/COLOR][/B]',
        'http://tenies-online.club/playlist/488.txt', 90001, 'http://tenies-online.club/uploads/mini/posterteniesarxiki/20/a5d9eec0b854e0d8bd5751c03fa059.jpg',
        addon.art,
        '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΈνα πρωί το διάσημο μοντέλο Maddie Hayes ξυπνάει και ξεκινά την βαρετή, χλιδάτη μέρα του, όπως έκανε και τις προηγούμενες μέρες, τα προηγούμενα χρόνια. Όμως κάτι δεν πάει καλά. Κάτι έχει αλλάξει. Κάτι που σύντομα η Μάντυ θα πρέπει να το αντιμετωπίσει: Ο λογιστής της υπέκλεψε όλη την περιουσία της και την έκανε για Βραζιλία. Αφού συνήλθε από το αρχικό σοκ, η δυναμική γυναίκα προσπαθεί να πάρει την κατάσταση στα χέρια της: Αποφασίζει να εκποιήσει όσες επιχειρήσεις ελέγχει και να επανεπενδύσει τα χρήματά της. Όταν όμως επισκέπτεται μια προβληματική εταιρεία ντετέκτιβ, ο καπάτσος διευθυντής της, ο David Addison, την διαβεβαιώνει ότι η εταιρεία μπορεί να αποφέρει κέρδη. Ότι αρκεί να χρησιμοποιήσουν την φήμη της σαν μοντέλο. Ότι μπορεί και η ίδια να γίνει ντετέκτιβ! Όπως καταλαβαίνετε, η Μάντυ υποκύπτει στα επιχειρήματα του Ντέιβιντ και η σειρά ξεκινά.')
    openn.addDir('[B][COLOR white]Shogun[/COLOR][/B] |[B][COLORlime]1980[/COLOR][/B]',
                 'http://tenies-online.club/engine/ajax/controller.php?mod=playlist&news_id=24492', 90002,
                 'http://teniesonline.ucoz.com/_ld/244/99248903.jpg', addon.art,
                 '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΗ σειρά ακολουθεί τις εμπειρίες του Tζον Μπλάκθορν στην Ιαπωνία στις αρχές του 17ου αιώνα. Μετά το ναυάγιο που είχε το πλοίο του Erasmus, κατά μήκος των ακτών της Ιαπωνίας… O Tζον Μπλάκθορν είναι ο άγγλος κυβερνήτης του πρώτου ολλανδικού πλοίου, που καταφέρνει να φτάσει στην Ιαπωνία, κατά λάθος βέβαια, αφού το πλοίο του φτάνει εκεί ουσιαστικά ακυβέρνητο εξαιτίας μιας φοβερής τρικυμίας...')
    openn.addDir(
        '[B][COLOR white]' + addon.Lang(32071).encode('utf-8') + '[/COLOR][/B] |[B][COLORlime]1994[/COLOR][/B]',
        'http://tainio-mania.co/uploads/playlists/20317.txt', 90001,
        'http://tainio-mania.co/uploads/mini/posterarxiki/44/eddc42cf97af1d70c43991e5848603.jpg', addon.art,
        '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΟ Ρεξ είναι ο αγαπημένος ήρωας όλων. Με το αλάνθαστο ένστικτό του, αλλά και την πρωτοφανή ευφυία του, έχει κερδίσει με το σπαθί του τη φήμη μιας ισχυρής τηλεοπτικής παρουσίας. Είναι αυτό που κάθε άνθρωπος επιθυμεί να εκπροσωπεί ένας σκύλος: ένα φίλο, ένα βοηθό, ένα σύντροφο άξιο εμπιστοσύνης.')
    openn.addDir('[B][COLOR white]Lois & Clark[/COLOR][/B] |[B][COLORlime]1993–1997[/COLOR][/B]',
                 'http://tainio-mania.co/uploads/playlists/9932.txt', 90001,
                 'http://tainio-mania.co/uploads/mini/posterarxiki/02/5211bd72f2ac39cd4cc1fc6cb57f95.jpg', addon.art,
                 '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΣταματάει σφαίρες με τα χέρια του, γλιτώνει αθώους πολίτες από τα σαγόνια του θανάτου και εκτοξεύει βόμβες, τοξικά χημικά και άλλα θανατηφόρα όπλα τρομοκρατών στο διάστημα. Αλλά όσο ατρόμητος και να είναι, μπροστά στον έρωτα λυγίζει. Ο Ντιν Κέιν και η Τέρι Χάτσερ επιστρέφουν για μια ακόμα συναρπαστική δεύτερη περίοδο με νέες περιπέτειες. Η δράση κυριαρχεί καθώς ο ανθρωπος Ατσάλι παλεύει με έναν μυστηριώδη Δάσκαλο της πολεμικής τέχνης Τσι, εξαπολύει τις σούπερ δυνάμεις ενάντια στα όπλα του «αναστημένου» μαφιόζου Αλ Καπόνε και αντιμετωπίζει ορδές τρελών επιστημόνων που τον προκαλούν με θανατηφόρες απειλές, ληστείες, φόνους και καταστροφές.')
    # openn.addDir(
    #     '[B][COLOR white]' + addon.Lang(32081).encode('utf-8') + '[/COLOR][/B] |[B][COLORlime]1982–1983[/COLOR][/B]',
    #     'https://gamatotv1.com/12608', 19,
    #     'http://teniesonline.ucoz.com/_ld/21/26948096.jpg', addon.art,
    #     '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΗ σειρά διαδραματίζεται στο Νότιο Ειρηνικό το 1938 και συγκεκριμένα στο φανταστικό νησί Μπόρα Γκόρα. Κεντρικός ήρωας είναι ο πιλότος Τζέηκ Κάτερ (Στέφεν Κόλινς), πρώην πιλότος μαχητικού που πλέον εκτελεί μεταφορές με το υδροπλάνο του, μια ασπροκκόκινη Grumman Goose, την οποία αποκαλεί χαϊδευτικά Χήνα (Cutters Goose). Πιστοί του σύντροφοι είναι ο καλόκαρδος αλκοολικός μηχανικός Κόρκυ (Τζεφ Μακέι) και ένα συμπαθές και πανέξυπνο τζακ ράσελ τεριέ με το όνομα Τζακ. Ο Τζακ έχει καλυμμένο το ένα του μάτι (αν και κάποτε είχε ένα ψεύτικο μάτι, το όποιο έχασε ο Τζέηκ σε μια παρτίδα πόκερ) και μπορεί να απαντά στους ανθρώπους γαβγίζοντας μια φορά για να πει «όχι» και δύο για πει «ναι». Η αγαπημένη του Τζέηκ είναι η Σάρα Γουάιτ (Κέιτλιν Ο Χίνεϊ). Τραγουδάει στο τοπικό μπαρ, αλλά στην πραγματικότητα είναι κατάσκοπος της αμερικανικής κυβέρνησης. Ο αιδεσιμότατος Γουίλι (Τζον Κάλβιν), που παρουσιάζεται ως ο κληρικός του νησιού, είναι στην πραγματικότητα επίσης κατάσκοπος. Αν και δουλεύει για τους Ναζί, πολλές φορές τα συμφέροντα του επεκτείνονται και στην αντίπαλη πλευρά.Ο Λούι (Ρον Μούντι στον πιλότο της σειράς, Ρόντι ΜακΝτάουελ στα υπόλοιπα επεισόδια) είναι ο Γάλλος διοικητής της Μπόρα Γκόρα και ιδιοκτήτης του τοπικού μπαρ. Η νέμεση του Τζέηκ είναι η Γιαπωνέζα πριγκίπισσα Κότζι (Μάρτα ΝτιΜπουά), μια γοητευτική και επικίνδυνη γυναίκα που έχει βλέψεις για τον Τζέηκ. Σκιά της πριγκίπισσας είναι ο αφοσιωμένος σωματοφύλακάς της, Τόντο (Τζον Φουτζιόκα), ένας πολεμιστής που ζει και ενεργεί με βάση τον κώδικα τιμής των σαμουράι, Μπουσίντο. Ο Χίτλερ στέλνει πράκτορες και από την Γκεστάπο και από τα ΣΣ για να πάρουν το αγαλματίδιο το οποίο είναι από ένα κράμα μετάλλων το οποίο θα χρησιμοποιήσει στους Πυραύλους του V1 kai V2 Ο τίτλος της σειράς προέρχεται από το από αυτόν τον θρύλο του χρυσό αγαλματίδιο του πιθήκου.')
    openn.addDir(
        '[B][COLOR white]' + addon.Lang(32072).encode('utf-8') + '[/COLOR][/B] |[B][COLORlime]1990–1996[/COLOR][/B]',
        'http://tenies-online.club/playlist/17471.txt', 90001,
        'http://tenies-online.club/uploads/mini/posterteniesarxiki/84/dec6f55efb1c01dbbc8857bfcff9a5.jpg', addon.art,
        '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΗ ήρεμη ζωή της πλούσιας οικογένειας των Μπανκς, που ζει στην αριστοκρατική περιοχή του Μπελ Ερ στην Καλιφόρνια, αναστατώνεται από έναν επεισοδιακό επισκέπτη. Ο αρχηγός της οικογένειας, Φίλιπ, δέχεται να φιλοξενήσει τον ατίθασο ανιψιό του, Γουίλ, από την Φιλαδέλφεια. Η μητέρα του Γουίλ θέλει το καλύτερο για τον γιο της, να πάρει σωστές αξίες και αρχές από τους επιτυχημένους συγγενείς τους. Ο Γουίλ έχει μεγαλώσει στους δρόμους της Φιλαδέλφεια και πολλές φορές οι συνήθειες του και ο τρόπος σκέψης του έρχονται σε σύγκρουση με τις αντιλήψεις της νέας του οικογένειας.')
    # openn.addDir(
    #     '[B][COLOR white]' + addon.Lang(32073).encode('utf-8') + '[/COLOR][/B] |[B][COLORlime]1964-1972[/COLOR][/B]',
    #     'http://teniesonline.ucoz.com/load/17-1-0-27040', 11, 'http://teniesonline.ucoz.com/_ld/270/16552931.jpg',
    #     addon.art,
    #     '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΗ ιστορία της Σαμάνθα, μιας μάγισσας που βαρέθηκε την οικογένειά της και μετακομίζει στη Γη προκειμένου να την ξεφορτωθεί. Εκεί, συναντάει τον Ντάρεν, έναν διαφημιστή, με τον οποίο ερωτεύεται και παντρεύεται... Μόνο που τα μάγια είναι λίγο δύσκολο να μην τους αναστατώσουν τη ζωή. Υπότιτλοι: Ελληνικοί ')
    openn.addDir('[B][COLOR white]I Dream of Jeannie [/COLOR][/B] |[B][COLORlime]1965-1970[/COLOR][/B]',
                 'http://tainio-mania.co/uploads/playlists/14623.txt', 90001,
                 'http://tainio-mania.co/uploads/mini/posterarxiki/96/c13e285a919e2cd07567f79ad5ab41.jpg', addon.art,
                 '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΗ κλασική κωμωδία “Το Τζίνι και η Τζίνη”, που αρχικά προβλήθηκε από το 1965 έως το 1970, παρουσιάζει την Barbara Eden ως Τζίνη, ένα τζίνι 2000 περίπου χρονών που απελευθερώθηκε από το μπουκάλι της, αφού το βρήκε σε ένα ερημονήσι ο αστροναύτης Τόνυ Νέλσον που υπηρετεί στη ΝΑSΑ, κατά τη διάρκεια μιάς αποστολής του. Αφού τον βοήθησε να επιστρέψει στο σπίτι του στη Φλόριντα, στο Κόκο Μπιτς, η Τζίνη πείθει τον Μέητζορ Νέλσον να γίνει ο νέος κύριος και αφέντης της.')
    # openn.addDir('[B][COLOR white]The Munsters[/COLOR][/B] |[B][COLORlime]1964-1966[/COLOR][/B] ',
    #              'http://tainio-mania.co/playlist/13974.txt', 90001, 'http://tainio-mania.co/_ld/139/36505817.jpg',
    #              addon.art,
    #              '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΜια οικογένεια φιλικών τέρατων έχουν περιπέτειες οποτε αρκετά συνειδητοποιούν γιατί οι άνθρωποι αντιδρούν σε αυτους τόσο παράξενα.')
    openn.addDir('[B][COLOR white]The Muppet Show[/COLOR][/B] |[B][COLORlime]1976-1978[/COLOR][/B]',
                 'http://tainio-mania.co/uploads/playlists/13868.txt', 90001, 'http://tainio-mania.co/uploads/mini/posterarxiki/c2/1529b3539dedc636edc481383908c7.jpg', addon.art,
                 '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΤο Μάπετ Σώου (The Muppet Show), ήταν τηλεοπτική σειρά στην οποία εμφανιζόταν ένας θίασος από μαριονέτες, τα Μάπετς, τις οποίες χειριζόντουσαν μαριονετίστες. Η σειρά δημιουργήθηκε από τον γνωστό μαριονετίστα και τηλεοπτικό παραγωγό Τζιμ Χένσον (Jim Henson), ο οποίος μαζί με την ομάδα του υπέγραφαν και την παραγωγή της. Κάθε επεισόδιο λαμβάνει χώρα στο «θέατρο των Μάπετς» όπου υποθετικά δίνουν την παράσταση τους τα Μάπετς και ο θεατής του επεισοδίου παρακολουθεί τα δρώμενα της σκηνής καθώς και των παρασκηνίων. Επίσης, σε κάθε επεισόδιο εμφανίζεται ένας άνθρωπος ως καλεσμένος ο οποίος παίζει ή και τραγουδάει μαζί με τις μαριονέτες σε σκετς. Το Μάπετ Σώου έγινε ιδιαίτερα δημοφιλές και εμφανίστηκαν μεγάλοι αστέρες του κινηματογράφου, της τηλεόρασης και της μουσικής σκηνής ως καλεσμένοι.')
    openn.addDir('[B][COLOR white]Battlestar Galactica[/COLOR][/B] |[B][COLORlime]1978[/COLOR][/B]', 'http://tainio-mania.co/uploads/playlists/20913.txt?v=1554117873',
                 90001, 'http://tainio-mania.co/uploads/mini/posterarxiki/8f/862aa2cb4c6c37bb268c99f29dbfe2.jpg', addon.art,
                 '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΟι ηγέτες δώδεκα ανθρώπινων αποικιών ετοιμάζονται να υπογράψουν μια ειρηνευτική σύμβαση με τους θανάσιμους εχθρούς τους, τους τερατόμορφους Σάιλονς. Την παραμονή, όμως, της υπογραφής, οι Σάιλονς τους επιτίθενται και καταστρέφουν τις περισσότερες από τις αποικίες. Όσα διαστημόπλοια διασώζονται από την καταστροφή, ακολουθούν το διαστημόπλοιο Battlestar Galactica σε μια αγωνιώδη έρευνα για την 13η «χαμένη» αποικία, έναν μακρινό πλανήτη με το όνομα, Γη... ')
    openn.addDir('[B][COLOR white]Batman [/COLOR][/B] |[B][COLORlime]1966–1968[/COLOR][/B]',
                 'http://tainio-mania.co/uploads/playlists/11367.txt?v=1554118145', 90001, 'http://tainio-mania.co/uploads/mini/posterarxiki/73/5857f4a6c0947f1aa28574ed4e78b3.jpg', addon.art,
                 '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΗ σειρά Batman εστιάζει στις περιπετειες του Batman και του Robin. Παρόλο που οι ζωές των Alter ego τους Bruce Wayne και Dick Grayson παρουσιάζονται τυπικά, και εν συντομία μόνο σε σχέση με τις επιχειρήσεις των Σουπερ Ηρώων. Το δυναμικό δίδυμο έρχεται ως ενίσχυση της αστυνομίας της Gotham City...')
    openn.addDir('[B][COLOR white]Galactica[/COLOR][/B] |[B][COLORlime]1980[/COLOR][/B]', 'http://tainio-mania.co/uploads/playlists/20838.txt', 90001,
                 'http://tainio-mania.co/uploads/mini/posterarxiki/d2/f34c4ad6701da99c899ed4de3b6f24.jpg', addon.art,
                 '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΟι Δωδεκα Αποικιες μαζι με το Γκαλακτικα μετα απο χρονια αναζητησης της 13ης Αποικιας, Γη, κοντευουν στο τελος του μακροχρονιου ταξιδιου τους. Επιτελους ανακαλυπτουν τη Γη, ομως τα νεα δεν ειναι και τοσο ευχαριστα. Η τεχνολογια στη Γη δεν ειναι τοσο αναπτυγμενη οσο περιμεναν και η Γη δεν μπορει να τους προστατεψει απο τους Cylons, οπως ηλπιζαν. Τωρα πρεπει να βοηθησουν τους ανθρωπους στη Γη να αναπτυχθουν τεχνολογικα, ωστε να μπορεσουν να αντιμετωπισουν τους Cylons και να μην καταστραφει η Γη απο τους Cylons, οπως οι Δωδεκα Αποικιες. ')
    openn.addDir('[B][COLOR white]Police Squad![/COLOR][/B] |[B][COLORlime]1982[/COLOR][/B]', 'http://tainio-mania.co/uploads/playlists/10406.txt', 90001, 'http://tainio-mania.co/uploads/mini/posterarxiki/dd/77b2d9600000a1bb0a107aaf99e18e.jpg', addon.art, '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΤο "Police Squad" του 1982. Η σειρά είναι ο "προθάλαμος" των ταινιών "Τρελές Σφαίρες" με το κλασσικό τρελό χιούμορ των ΖΑΖ (Zucker / Abrahams / Zucker).')
    openn.addDir('[B][COLOR white]Τα πουλιά πεθαίνουν τραγουδώντας[/COLOR][/B] |[B][COLORlime]1983[/COLOR][/B]', 'http://tainio-mania.co/uploads/playlists/19759s.txt', 90001, 'http://tainio-mania.co/uploads/mini/posterarxiki/34/a512c6fc61e519d280287756f9221f.jpg', addon.art,
                 '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΗ σειρά The Thorn Birds διαδραματίζεται στην Αυστραλία στις αρχές του 20ού αιώνα και αφηγείται την ιστορία της οικογένειας των Κλήρυ. Ο Πάντυ Κλήρυ μεταναστεύει μαζί με την οικογένειά του από τη Νέα Ζηλανδία στην Αυστραλία, για να δουλέψει στη Ντρογκήτα. Την τεράστια φάρμα με πρόβατα της πάμπλουτης αλλά δεσποτικής και άκληρης αδερφής του, Μαίρη Κάρσον, η οποία τρέφει μια ανομολόγητη αγάπη για τον γοητευτικό, νεαρό ιερέα Ράλφ Ντε Μπρικασάρ, που έχει σταλεί εκεί για τιμωρία από την Καθολική εκκλησία. Όμως, η μοίρα του Ραλφ θα δεθεί με την μονάκριβη κόρη της οικογένειας, τη Μέγκι, και ο απαγορευμένος από θείους και ανθρώπινους νόμους έρωτάς τους, θα σημαδέψει ολόκληρη τη ζωή τους.')
    openn.addDir('[B][COLOR white]Ταξιδιώτες Μέσα Στο Χρόνο[/COLOR][/B] |[B][COLORlime]1982–1983[/COLOR][/B]', 'http://tainio-mania.co/uploads/playlists/9915.txt', 90001, 'http://tainio-mania.co/uploads/mini/posterarxiki/b4/02480cbf9c6fcf8442c1af185bc223.jpg', addon.art,
                 '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΟ Φινέας Μπογκ είναι ένας ταξιδιώτης του χρόνου, που με τη βοήθεια ενός νεαρού αγοριού, του Τζέφρυ Τζόουνς , κατέχουν την συσκευή "Ομνι" που τους επιτρέπει να ταξιδεύουν στο χρόνο και να εξασφαλίζουν ότι η ιστορία θα εξελιχθεί όπως τη γνωρίζουμε.')
    openn.addDir('[B][COLOR white][/COLOR]Επιστροφή στην Εδέμ[/B] |[B][COLORlime]1983[/COLOR][/B]', 'http://tainio-mania.co/uploads/playlists/10569.txt', 90001, 'http://tainio-mania.co/uploads/mini/posterarxiki/05/51b98fcf0febf95f8b423f725d8f54.jpg', addon.art,
                 '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΗ Στεφανι είναι μια πλούσια κληρονόμος που παντρεύεται τον Γκρεγκ έναν γοητευτικό αλλά αδίστακτο παλιάνθρωπο.Δε γνωρίζει όμως πως ο σύζυγος της διατηρεί ερωτική σχέση με την καλύτερη της φίλητην Τζιλ και όχι μόνο αυτό αλλά σχεδιάζουν να τη δολοφονήσουν για να πάρουντην αμύθητη περιουσία της.Ένα βράδυ ο Γκρεγκ σπρώχνει τη Στεφανι σε ένα ποτάμι γεμάτο κροκόδειλους,η Στεφανι δέχεται επίθεση από έναν κροκόδειλο. Παρότι όμως όλοι τη θεωρούν νεκρή αυτή έχει επιζήσει αν και φρικτά παραμορφωμένη.Με τη βοήθεια ενός πλαστικού χειρούργου αποκτά νέο πρόσωπο γίνεται μια κούκλα βρίσκει δουλεία σαν μοντέλο και επιστρέφει για να πάρει εκδίκηση και την περιουσία της πίσω.')
    # openn.addDir('[B][COLOR white][/COLOR][/B] |[B][COLOR green][/COLOR][/B]', '', 90001, '', addon.art, '')
    # openn.addDir('[B][COLOR white]' +addon.Lang(32074).encode('utf-8')+ '[/COLOR][/B]','https://www.youtube.com/playlist?list=PLI4rJYaijkkDsB9tOTWFdl34joMOMSM6M',1,'http://shop.theukaddon.artdepot.co.uk/wp-content/uploads/2014/04/laurel-and-hardy-SONS-OF-THE-DESERT-Laurel-and-Hardy%E2%80%99s-classic-film-Poster-1933.jpg',addon.art,'[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΟι κωμωδίες τους απλές σε δράση, γίνονταν απολαυστικές από τις συνεχείς ανατροπές των καταστάσεων, τα εναλλασσόμενα γκαγκ. Ήρωες μικροαστικής προέλευσης, ήθελαν να γίνουν κοινωνικά σεβαστοί αλλά και αρεστοί. Φορούσαν αξιοπρεπή κοστούμια, σκληρά καπέλα και απευθύονταν ο ένας στον άλλον με την προσφώνηση μίστερ. Αποκτούσαν μία καθωσπρέπει απασχόληση ως μεταφορείς πιάνων ή πωλητές χριστουγεννιάτικων δέντρων κι αν στο τέλος τα έκαναν θάλασσα, αυτό δεν έβλαπτε παρά τους ίδιους.')
    # openn.addDir(
    #     '[B][COLOR white]' + addon.Lang(32075).encode('utf-8') + '[/COLOR][/B] |[B][COLORlime]1990[/COLOR][/B]',
    #     'http://magazino1.blogspot.gr/2015/05/ils-holgerson.html', 22,
    #     'https://www.discshop.se/img/front_large/70387/nils_holgersson_vol_1_4_disc.jpg', addon.art,
    #     '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΟ Νιλς Χόλγκερσον ήταν ένα τεμπέλικο δεκατετράχρονο αγόρι, που φορούσε ένα κόκκινο σκουφάκι και ζούσε σε ένα αγρόκτημα με τους φτωχούς γονείς του. Αυτό που του άρεσε ήταν να βασανίζει τα ζώα και να ταλαιπωρεί τους ανθρώπους. Μια μέρα το παράκανε με την κακή του συμπεριφορά, παίζοντας ένα άσχημο παιχνίδι σε έναν νάνο ')
    # openn.addDir(
    #     '[B][COLOR white]' + addon.Lang(32076).encode('utf-8') + '[/COLOR][/B] |[B][COLORlime]1981[/COLOR][/B]',
    #     'http://teniesonline.ucoz.com/load/5-1-0-182', 11, 'http://teniesonline.ucoz.com/_ld/1/78798331.jpg', addon.art,
    #     '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΗ σειρά ακολουθεί τις περιπέτειες του Οδυσσέα και του πληρώματος του στο Διάστημα. Οι θεοί τιμωρούν τον Οδυσσέα όταν στην προσπάθεια του να σώσει μια ομάδα παιδιών και το γιο του Τηλέμαχο, σκοτώνει τον Κύκλωπα. Το πλήρωμα του πέφτει σε λήθαργο και ο μόνος τρόπος να επιστρέψουν στη ζωή είναι να βρουν το βασίλειο του κάτω κόσμου. Μέχρι να φτάσει στον τελικό του προορισμό θα περιπλανηθεί στο αχανές διάστημα και θα συναντήσει πολλούς από τους ήρωες της Ελληνικής μυθολογίας. Μεταγλωτισμένο: στα Ελληνικά ')
    openn.addDir(
        '[B][COLOR white]' + addon.Lang(32077).encode('utf-8') + '[/COLOR][/B] |[B][COLORlime]1985–1989[/COLOR][/B]',
        'http://tainio-mania.co/uploads/playlists/20995.txt', 90001, 'http://tainio-mania.co/uploads/mini/posterarxiki/a2/ea20a8527900053faedfb6ce4fc102.jpg',
        addon.art,
        '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΟι Θάντερκατς είναι μία ομάδα ανθρωποειδών με αιλουροειδή χαρακτηριστικά από τον πλανήτη της Θαντέρα. Μετά την έκρηξη της Θαντέρα, οι Θάντερκατς φεύγουν στο διάστημα αναζητώντας νέο πλανήτη για να εγκατασταθούν, αλλά ο στόλος τους δέχεται επίθεση από τους εχθρούς τους, τα Μεταλλάγματα από τον πλανήτη Πλάνταρ, με αποτέλεσμα να καταστραφούν όλα τα σκάφη τους εκτός από τη ναυαρχίδα. Σε αυτή βρίσκεται το ξίφος των οιωνών το οποίο έχει το μάτι της Θαντέρα που αποτελεί την πηγή δύναμης των Θάντερκατς.Υπότιτλοι: Ελληνικοί ')
    openn.addDir(
        '[B][COLOR white]' + addon.Lang(32078).encode('utf-8') + '[/COLOR][/B] |[B][COLORlime]1987[/COLOR][/B]',
        'http://tenies-online.club/engine/ajax/controller.php?mod=playlist&news_id=19228', 90002, 'http://tenies-online.club/uploads/mini/posterteniesarxiki/9c/86b90ae649a79821ee15f0d87085ca.jpg',
        addon.art,
        '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΗ σειρά περιγράφει την υπέροχη ιστορία του ανθρώπινου σώματος. Πηγαίνουμε στον μικρόκοσμο που ξεκινά η ζωή: ο ίδιος ο πυρήνας του ανθρώπινου όντος, τα όργανά του και τα κύτταρα, όπου η ζωή αναπτύσσεται και διατηρείται. Οι ήρωές μας είναι οι υπερασπιστές του σώματος. Το "Παράσιτο" και ο "Νάνος" είναι επιθετικοί ιοί ή βακτήρια. Μεταγλωτισμένο στα: Ελληνικά')
    openn.addDir('[B][COLOR white]Candy Candy[/COLOR][/B] [B][COLOR limes](1976–1979)[/COLOR][/B]',
                 'http://tainio-mania.co/uploads/playlists/10057.txt', 90001,
                 'http://tainio-mania.co/uploads/mini/posterarxiki/1b/87e4c135ca4f649c46bd5fefe1abea.jpg', addon.art,
                 '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΗ σειρά έχει ως κεντρική ηρωίδα της την Κάντυ Γουάιτ Άρντλεϋ ή χαϊδευτικά Κάντυ, μιά όμορφη ξανθιά κοπέλα με φακίδες στη μύτη, που μεγάλωσε σ´ένα ορφανοτροφείο, το σπίτι Πόνυ, κοντά στη λίμνη Μίσιγκαν των Η.Π.Α. στις αρχές του 20ου αιώνα. Η κοπέλα αυτή ήταν αγοροκόριτσο που σκαρφάλωνε σε δέντρα και έκανε πολλές σκανδαλιές, μα όλοι την αγαπούσαν για την καλή της την καρδιά. Βρέθηκε όταν ήταν μωρό σ´ένα καλαθάκι, μαζί με τη φίλη της Άννυ, στην είσοδο του ορφανοτροφείου από την κυρία Πόνυ και την αδελφή Μαρία, μια κρύα νύχτα του χειμώνα. Θα ονομαστεί Κάντυ επειδή δίπλα της θα βρεθεί μια κούκλα που απάνω έχει την λέξη "Candy" γραμμένη με κόκκινο και θα πάρει το επώνυμό της από το χιόνι που την έσωσαν.')
    openn.addDir('[B][COLOR white]Kabamaru (Ninja Boy)[/COLOR][/B] [B][COLORlime](1983–1984)[/COLOR][/B]',
                 'http://tainio-mania.co/uploads/playlists/10409.txt', 90001,
                 'http://tainio-mania.co/uploads/mini/posterarxiki/6f/fd3ec5c57b370947583e2fe84fd71f.jpg', addon.art,
                 '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΜετά τον θάνατο του Saizou, του αυστηρού παππού του, ο Kabamaru που εκπαιδευόταν για να γίνει ένας iga ninja πιστέυει πως είναι επιτέλους ελέυθερος. Όμως την ημέρα της κηδείας εμφανίζεται μία περίεργη κυρία, η Ran Akoko, η οποία είναι δευθύντρια ενός σχολείου στο Tokyo. Η κυρία αυτή ισχυρίζεται πως γνώριζε τον Saizou, ο οποίος της έστειλε ένα γράμμα με το οποίο της ζητάει να φροντίσει τον εγγονό του. Έτσι ο Kabamaru πηγαίνει στο Tokyo και ξεκινούν οι περιπέτειες του. ')
    # openn.addDir('[B][COLOR white]' +addon.Lang(32079).encode('utf-8')+ '[/COLOR][/B] [B][COLOR green](1974)[/COLOR][/B]','http://gamatotv.co/group/heidi-a-girl-of-the-alps-1974',18,'http://teniesonline.ucoz.com/_ld/244/08339561.jpg',addon.art,'Ταξιδέψτε στις καταπράσινες Άλπεις και ζήστε αξέχαστες στιγμές παρέα με τη Χάιντι και τους φίλους της. H μικρή Χάιντι, μαζί με τη θεία της, την Ντέτε, επισκέπτονται τον παππού της Xάιντι που ζει μόνος του στα βουνά των Άλπεων. H θεία Nτέτε αποφάσισε να φύγει για την πόλη κι έτσι ο παππούς αναλαμβάνει τώρα να προσέχει και να συμβουλεύει τη Xάιντι στα πρώτα της βήματα. Πόσο όμορφη είναι η ζωή στις Άλπεις! H μικρή Xάιντι γνωρίζει εκεί τον Πέτερ, το μικρό βοσκό, και παίζει ξένοιαστη κάτω από τον καταγάλανο ουρανό, γνωρίζοντας μια καινούρια ζωή, γεμάτη όμορφες εκπλήξεις! Μεταγλωττισμένο στα: Ελληνικά ')
    # openn.addDir(
    #     '[B][COLOR white]' + addon.Lang(32080).encode('utf-8') + '[/COLOR][/B] |[B][COLORlime]1969–1978[/COLOR][/B]',
    #     'http://tenies-online.club/engine/ajax/controller.php?mod=playlist&news_id=14795', 17, 'http://tenies-online.club/uploads/mini/posterteniesarxiki/7b/98c43b8b67d9135b8c1f17743c3808.jpg',
    #     addon.art,
    #     '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nTι συμβαίνει όταν ένας δειλός σκύλος σε συνδυασμό με την ομάδα της Εταιρείας Μυστήριου Α.Ε. που απαρτίζεται από τον Σάγκι, τη Βέλμα, τη Δάφνη και τον Φρεντ μπλέκουν σε μια σειρά τρομακτικών καταστάσεων; Μεταγλωττισμένο στα: Ελληνικά Παραγωγή: 1969 Είδος Ταινίας: Κιν. σχέδια, Κωμωδία, Μυστήριο Σκηνοθέτης: Joe Ruby, Ken Spears Ηθοποιοί: Don Messick, Casey Kasem, Nicole Jaffe ')
    # addDir('The Dukes of Hazzard (1979–1985)','http://gamatotv.co/group/the-dukes-of-hazzard-1979-1985',19,'http://api.ning.com/files/2QN5aCZBKSbrzMDUOqRCduQ80-VqqO6YZo1Qeh421N2IxFHMuRNcIG7jYO56aiY2ZXDdUfaOpiI1Gpxuo5zjVgRvNf-pIwMw/MV5BNjg3MzA0MzM2NF5BMl5BanBnXkFtZTYwNjMwNjk4._V1_SX214_.jpg',addon.art,'Η τηλεοπτική σειρά ακολουθεί την ζωή δύο εξαδέλφων, του Bo και του Luke Duke, που ζουν σε μια πλασματική περιοχή του Hazzard, την Georgia, να συναγωνίζονται με μια «φτιαγμένη» Dodge Charger του 1969 (τον General Lee), τον Επίτροπο Boss Hogg που έχει στο πλάι του τον διεφθαρμένο σερίφη Rosco P. Coltrane. Ο Bo και ο Luke είναι καταδικασμένοι για παράνομη μεταφορά λαθραίου ποτού (που φτιάχνει ο θείος Jesse). Ζουν στην φάρμα του θείου Jesse και έχουν μαζί και την πανέμορφη εξαδέλφη τους την Daisy. Στην σειρά αυτή οι Dukes δεν έκαναν χρήση όπλων όπως θα ήταν αναμενόμενο, αλλά σε μερικές περιπτώσεις χρησιμοποιούσαν τόξα...')
    # openn.addDir('[B][COLOR white]Sport Billy[/COLOR][/B] |[B][COLORlime]1979-1980[/COLOR][/B]',
    #              'http://gamatotv.co/group/sport-billy-1979', 17,
    #              'http://api.ning.com/files/SC5tqKJCifg9S39kiJkW0QtS0nUb85xF*B2yEMPPGXiSeiV9P-HvWWQnTJAX67jrZ6T-QZBmN4EzRxlY*LP6E8QXwA69queS/MV5BY2Q5MWQxYTktNmNlZi00YjhkLWJlODUtMmQ4NmI0MzZjMjM0XkEyXkFqcGdeQXVyMTYzNTE3NDA._V1_.jpg',
    #              addon.art,
    #              '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nΗ σειρά είχε να κάνει με τις περιπέτειες του Σπορτ Μπίλλυ, ενός παιδιού που κατάγεται από τον πλανήτη Όλυμπος που βρίσκεται στην άλλη πλευρά του ήλιου και μοιάζει στη Γη.Το αγαπημένο του σπορ είναι το ποδόσφαιρο. Πάντα έχει μαζί του το κίτρινο βαλιτσάκι του, το οποίο περιέχει διάφορα εργαλεία ανάλογα με τις ανάγκες του Σπορτ Μπίλυ (από ρακέτα του τένις μέχρι αυτοκίνητο). Ο Σπορτ Μπίλυ πηγαίνει στη Γη με σκοπό να προωθήσει τον αθλητισμό και την ομαδική δουλειά. Θανάσιμη εχθρός του είναι η βασίλισσα Βάντα και ο βοηθός της ο Σάιντ. Η Βάντα έχει σκοπό να καταστρέψει όλα τα αθλήματα στο γαλαξία. Έχει δύο βοηθούς, τη Λίλυ και το σκύλο του το Γουίλυ. Σε κάθε επεισόδιο ταξιδεύουν στο χρόνο με το διαχρονόπλοιό του που μοιάζει με ρολόι πάνω σε ρουκέτες και σώζει κάποιο άθλημα από τα διαβολικά σχέδια της Βάντα.')
    openn.addDir('[B][COLOR white]The Pink Panther[/COLOR][/B] |[B][COLOR lime]1964-1980[/COLOR][/B]', 'http://tainio-mania.co/_ld/208/20806_The_Pink_Panthe.txt', 90001, 'http://tainio-mania.co/uploads/mini/posterarxiki/09/512815fdd8e881a2035cf86301e9fe.jpg', addon.art, '[B][COLOR green]***Περίληψη***[/COLOR][/B]\nThe Pink Panther Cartoon Collection (1964-1980)')
    # openn.addDir('[B][COLOR white][/COLOR][/B] |[B][COLOR green][/COLOR][/B]', '', 90001, '', addon.art, '')
    # openn.addDir('[B][COLOR white][/COLOR][/B] |[B][COLOR green][/COLOR][/B]', '', 90001, '', addon.art, '')
    # openn.addDir('[B][COLOR white][/COLOR][/B] |[B][COLOR green][/COLOR][/B]', '', 90001, '', addon.art, '')
    setView.setView('movies', 'movie-view')


def mi(url):  # 90001
    # cj = client.request('http://tainio-mania.co/', output='cookie')
    # xbmc.log("COOOKIES: {}".format(cj))
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'el-GR,el;q=0.8,en-US;q=0.5,en;q=0.3',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }

    params = (
        ('mod', 'playlist'),
    )
    # headers['Cookie'] = cj
    r = client.request(url, headers=headers)
    # xbmc.log("DATAAAAAAAAA: {}".format(r))
    data = json.loads(r)
    data = data['playlist']
    if 'Season' in str(data):
        for season in data:
            sname = season['comment']
            addDir(sname, json.dumps(season), 90003, ICON, FANART, '')

    else:
        for epi in data:
            name = epi['comment']
            durl = epi['file']
            durl += '|User-Agent=%s&Referer=%s' % (quote_plus(client.agent()), quote_plus(url))
            addLink(name, durl, ICON)


def season_mi(url):
    data = json.loads(url)
    episodes = data['playlist']
    for epi in episodes:
        name = epi['comment']
        durl = epi['file']
        durl += '|User-Agent=%s&Referer=%s' % (quote_plus(client.agent()), quote_plus(url))
        addLink(name, durl, ICON)


    # html2 = html['playlist']
    # c = (len(html2))
    # for i in range(c):
    #     try:
    #         html3 = html2[i]
    #         html4 = html3["playlist"]
    #         c1 = len(html4)
    #         for j in range(c1):
    #             html5 = html4[j]
    #             name = html5["comment"]
    #             durl = html5["file"]
    #             durl += '|User-Agent=%s&Referer=%s' % (urllib.quote_plus(client.agent()), urllib.quote_plus(url))
    #             addLink(name, durl, addon.icon)
    #     except:
    #         pass
    # else:
    #     try:
    #         for k in range(c):
    #             html6 = html2[k]
    #             name = html6["comment"]
    #             durl = html6["file"]
    #             durl += '|User-Agent=%s&Referer=%s' % (urllib.quote_plus(client.agent()), urllib.quote_plus(url))
    #             addLink(name, durl, addon.icon)
    #     except:
    #         pass


def addLink(name, url, ICON):
    name = name.replace('Episode', 'Επεισόδιο')
    # ok = True
    liz = xbmcgui.ListItem(name, ICON, FANART)
    liz.setInfo(type="Video", infoLabels={"Title": name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=liz)
    return ok


def mi1(url):  # 90002
    User_Agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36'
    headers = {'User-Agent': User_Agent}

    r = client.request(url, headers=headers)
    m = re.compile('<option value="(.+?)">(.+?)</option>').findall(r)
    for url, name in m:
        if "flashx" in url:
            continue
        openn.addDir(name, url, 200, addon.icon, addon.art, '')


def get_old19(url):
    c2 = 0
    p = openn.Open_Url(url)
    from resources.lib.modules import dom_parser as dom
    m = dom.parse_dom(p, 'a', req='href')
    m = [(i.attrs['href'], i.content) for i in m if 'streamcloud.eu' in i.attrs['href']]
    xbmc.log('LINKS: {}'.format(str(m)))
    for url, name in m:
        c = addon.Lang(32047).encode('utf-8')
        c2 = c2 + 1
        name = str(name).replace('amp;', '')
        name = name.replace('target="_blank">', '')
        openn.addDir('[B][COLOR white]%s[/COLOR][/B][B][COLOR white] %s[/COLOR][/B][B][COLOR green]%s[/COLOR][/B]' % (
                c2, c, name), url, 200, addon.icon, addon.art, '')
