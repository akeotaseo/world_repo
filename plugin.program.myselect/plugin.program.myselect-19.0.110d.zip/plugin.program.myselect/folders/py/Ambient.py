import xbmc, xbmcgui


def Ambient():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Ambient ~[/COLOR][/B]', 
['[B][COLOR=fuchsia]Ambient[/COLOR][/B]',
 '[B][COLOR=yellow]VIDEOS EMOCIONANTES[/COLOR][/B]',
 '[B][COLOR=yellow]VIDEOS PARA RELAXAR[/COLOR][/B]',
 '[COLOR ghostwhite][B]TV Windows & Art[/B][/COLOR]',
 '[COLOR white][B]Landscapes[/B][/COLOR]',
 '[COLOR sandybrown][B]Fireplace[/B][/COLOR]'])


    if call:
        if call < 0:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thecrew/?action=directory&content=addons&url=https%3a%2f%2fbitbucket.org%2fteam-crew%2fpurplehat%2fraw%2fmaster%2fambient.xml")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.theanonymous.nexus/?fanart=https%3a%2f%2fcld.pt%2fdl%2fdownload%2fbdf5d638-83ac-452b-9de5-210cbca8a429%2f284484.jpg&mode=1&name=%5bCOLOR%20orangered%5d%5bB%5d%e2%80%a2%5b%2fB%5d%5bCOLOR%20yellow%5d%20VIDEOS%20EMOCIONANTES%20%5bCOLOR%20blue%5d%5bB%5d%20ON%20%5b%2fB%5d%5b%2fCOLOR%5d&url=789ccb282929b0d2d7cfcdccc948cccbd72b28d14f2b29d08572f5ab524b8b4bcaf4a380947e98a78bab7fb09eabafbfb3a7bf9fa35f886b303631bd928a120005a91c7d")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.theanonymous.nexus/?fanart=https%3a%2f%2fcld.pt%2fdl%2fdownload%2fbdf5d638-83ac-452b-9de5-210cbca8a429%2f284484.jpg&mode=1&name=%5bCOLOR%20orangered%5d%5bB%5d%e2%80%a2%5b%2fB%5d%5bCOLOR%20yellow%5d%20VIDEOS%20PARA%20RELAXAR%20%20%5bCOLOR%20blue%5d%5bB%5d%20ON%20%5b%2fB%5d%5b%2fCOLOR%5d&url=789ccb282929b0d2d7cfcdccc948cccbd72b28d14f2b29d08572f5ab524b8b4bcaf4a380947e98a78bab7fb05e806390a35e90ab8f6384631036313dbd928a12001b781c63")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/get_list/http://fantazyrepo.uk/addonimages/fido.addon/fire/tvwindow.xml")')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/kodion/search/query/?q=Landscapes",return)')


def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/kodion/search/query/?q=Fireplace&search_type=playlist",return)')


Ambient()
