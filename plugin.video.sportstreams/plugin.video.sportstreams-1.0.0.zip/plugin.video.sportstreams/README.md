<h1>Sport Streams</h1>
<p>
České a slovenské sportovní přenosy z různých zdrojů:<br><br>

ČT4 Sport Plus (ČT4 Sport + extra přenosy)<br>
TVcom.cz (živé přenosy i archiv různých sportů a soutěží)<br>
Huste.tv (živé přenosy i archiv ze slovenských soutěží)<br>
Volej.tv (přenosy volejbalových soutěží)<br>
Ping-pong.tv (přenosy ze soutěží stolního tenisu<p>

v1.0.0 (26.06.2022)<br>
- první verze<br><br>
</p>
