﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

xbmcgui.Dialog().notification("ManaLAB", "Ρυθμίσεις υποτίτλων.", xbmcgui.NOTIFICATION_INFO, 7000, False)

xbmc.executebuiltin("ActivateWindowAndFocus(playersettings, -195,)")

xbmc.sleep(1000)
while xbmc.getCondVisibility("Window.isVisible(playersettings)") or xbmc.getCondVisibility("Window.isVisible(dialog)"):
    xbmc.sleep(100)
xbmc.executebuiltin("ReloadSkin")
xbmc.sleep(1000)
xbmc.executebuiltin("Action(Play)")
