﻿from updatervar import *

### Oi δριαδρομές ειναι στο updatrvar.py ###

# home            = translatePath('special://home/')     home + 'cache'
# user_path       = os.path.join(home, 'userdata/')      user_path + 'profiles.xml'
# data_path       = os.path.join(user_path, 'addon_data/')
# db_path         = os.path.join(user_path, 'Database/')


                                     #files

#xbmcvfs.delete('special://home/userdata/playercorefactory.xml')
                                     #players
#xbmc.sleep(200)
#xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/players/atla_oipeirates.json')

#xbmc.sleep(1000)



                                             #addons
delete_files = ['repository.test1', 'repository.709', 'repository.test2']



                                             #folders
#base_path = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.themoviedb.helper')

#dir_list = glob.iglob(os.path.join(base_path, "reconfigured_players"))
#for path in dir_list:
#    if os.path.isdir(path):
#        shutil.rmtree(path)


base_path = xbmcvfs.translatePath('special://home/userdata/addon_data')

#dir_list = glob.iglob(os.path.join(base_path, "json_list_files2"))
#for path in dir_list:
#    if os.path.isdir(path):
#        shutil.rmtree(path)


#base_path = xbmcvfs.translatePath('special://home/media/Downloads')

#dir_list = glob.iglob(os.path.join(base_path, "CartoonsGR"))
#for path in dir_list:
#    if os.path.isdir(path):
#        shutil.rmtree(path)



def check_del_dir():
    for path_list in delete_files:
        if exists(addons_path + '%s' % path_list) or exists('%s' % path_list):
            path_list = path_list.replace(UpdaterMatrix, '[B][COLOR lime] * [/COLOR][/B]').replace(addons_path, '[B][COLOR lime] * [/COLOR][/B]').replace(user_path, '[B][COLOR lime] * [/COLOR][/B]').replace(home, '[B][COLOR lime] * [/COLOR][/B]')
            del_dir()
            #BG.create('[B]Διαγραφή αχρείαστων αρχείων...[/B]', path_list)
            #BG.update(29, '[B]Διαγραφή αχρείαστων αρχείων...[/B]', path_list)
            #xbmc.sleep(4000)
            #BG.close()



def del_dir():#addons #addon_data
    for ad in addons_data_path:
     for rr in delete_files:
       dir_list = glob.iglob(os.path.join(ad, rr))
       for path in dir_list:
           if os.path.isdir(path):
               shutil.rmtree(path)
           if os.path.isfile(path):
              os.remove(path)


check_del_dir()