from audioaddict.main import run_addon
