# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import base64
#import json
#import random
import datetime
import time
from resources.lib import jsunpack
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.stream2watch')

mode = addon.getSetting('mode')
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0'
baseurl='https://live.xn--tream2watch-i9d.com' #https://live.ștream2watch.com/

def build_url(query):
    return base_url + '?' + urlencode(query)

def main_menu():
    '''
    hea={
    'User-Agent':UA,
    }
    resp=requests.get(baseurl,headers=hea).text
    resp_1=resp.split('<div class="sportovi">')
    resp_2=resp_1[0].split('\n')
    categs=[]
    for r in resp_2:
        if 'btn-link' in r:
            link=re.compile('href=\"([^"]+?)\"').findall(r)[0]
            img=re.compile('src=\"([^"]+?)\"').findall(r)[0]
            item=re.compile('title=\"([^"]+?)\"').findall(r)[0]
            categs.append([item,link,img])

    for c in categs:
        img=baseurl+c[2]
        li=xbmcgui.ListItem(c[0])
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': c[0],'sorttitle': c[0],'plot': ''})
        li.setArt({'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': img})
        url = build_url({'mode':'categs','link':c[1]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        
    #tv
    img='DefaultTVShows.png'
    li=xbmcgui.ListItem('TV Channels')
    li.setProperty("IsPlayable", 'false')
    li.setInfo(type='video', infoLabels={'title': 'TV Channels','sorttitle': 'TV Channels','plot': ''})
    li.setArt({'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': ''})
    url = build_url({'mode':'categs','link':'/tv-channels/'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle)
    '''
    '''
    categs=[
        ['Soccer','/schedule-soccer/','/soccer-ico.png'],
        ['Football (NFL)','/nfl-schedule/','/nfl-ico.png'],
        ['Basketball (NBA)','/schedule-basketball/','/basketball-ico.png'],
        ['Hockey (NHL)','/hockey-schedule/','/hockey-ico.png'],
        ['Baseball (MLB)','/baseball-schedule/','/baseball-ico.png'],
        ['Boxing','/boxing-schedule/','/boxing-ico.png'],
        ['Tennis','/tennis-schedule/','/tennis-ico.png'],
        ['Motorsports','/racing-schedule/','/motor-ico.png'],
        ['Rugby','/rugby-schedule/','/rugby-ico.png'],
        ['Golf','/golf-schedule/',''],
        ['UFC (MMA)','/ufc-schedule-2021/','/mma-ico.png'],
        ['WWE','/wwe-schedule/',''],
        ['Handball, Volleyball, Darts, more...','/other-schedule/',''],
        ['TV Channels','/tv-channels/','']
    ]
    '''
    hea={
        'User-Agent':UA,
    }
    resp=requests.get(baseurl,headers=hea).text
    categs=re.compile('catlinks oboj.*href=\"([^\"]+?)\">(.*)<').findall(resp)
    
    for c in categs:
        if c[1]=='TV Channels':
            u='/tv-channels/'
        else:
            u=c[0]
        img='OverlayUnwatched.png'
        li=xbmcgui.ListItem(c[1])
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': c[1],'sorttitle': c[1],'plot': ''})
        li.setArt({'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': img})
        url = build_url({'mode':'categs','link':u})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle)

def tvList():
    hea={
    'User-Agent':UA,
    }
    url=baseurl+'/tv-channels/'
    resp=requests.get(url,headers=hea).text
    resp_1=(resp.split('>TV CHANNELS<')[1]).split('pop-search')[0]
    categs_tv=re.compile('<strong>([^"]+?)</strong>').findall(resp_1)
    #print(categs_tv)

    resp_2=resp_1.split('<hr>')
    tv=[]
    for r in resp_2:
        if 'stream-box' in r:
            tv1=[]
            resp_3=r.split('</span></a></div></div>')
            for r3 in resp_3:
                if 'href' in r3:
                    #print(r3)
                    link,name=re.compile('<a href=\"([^\"]+?)\"><span class=\"title\">(.*)').findall(r3)[0]
                    logo=re.compile('src=\"([^"]+?)\"').findall(r3)[0]
                    tv1.append([name,link,logo])
            tv.append(tv1)

    addon.setSetting('channelData',str(tv))#array - dla każdej kategorii lista tv: [name,link,logo] #linki i logo - niepełne - dodać baseurl
    return categs_tv #array: kategorie stacji

def eventList(link):
    hea={
    'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0',
    }
    url=baseurl+link
    resp=requests.get(url,headers=hea).text
    resp_1=(resp.split('<table')[1]).split('</table')[0]
    resp_2=resp_1.split('</tr>')
    events=[]
    for r in resp_2:
        if 'stream-box' in r:
            r=r.replace('\n','')
            title=re.compile('c_display_title tdp\'>([^<]+?)</p>').findall(r)[0]
            time=re.compile('realtime.*>([^<]+?)</span').findall(r)[0]
            img=re.compile('src=\"([^"]+?)"').findall(r)[0].replace(' ','')
            link=re.compile('btn-xs\' href=\'([^\']+?)\'').findall(r)[0]
            events.append([title,time,link,img])
    return events #linki i img niepełne!

def utc_to_loc(Hutc):
	now_utc=datetime.datetime.utcnow()
	now_loc=datetime.datetime.now()
	timeDif=(now_loc-now_utc).seconds
	dateLoc=datetime.datetime(*(time.strptime(Hutc, '%H:%M')[0:6]))+datetime.timedelta(seconds=timeDif)
	Hloc=dateLoc.strftime('%H:%M')
	return Hloc

def itemList(link):
    items=[]
    if 'tv-channels' in link:
        items=tvList()
        for n,i in enumerate(items):
            li=xbmcgui.ListItem(i)
            li.setProperty("IsPlayable", 'false')
            li.setInfo(type='video', infoLabels={'title': i,'sorttitle': i,'plot': ''})
            li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': '', 'fanart': ''})
            url = build_url({'mode':'tvList','categId':str(n)})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    else:
        items=eventList(link)
        for i in items:
            img=baseurl+i[3]
            li=xbmcgui.ListItem(utc_to_loc(i[1])+ ' [B]'+i[0]+'[/B]')
            li.setProperty("IsPlayable", 'true')
            li.setInfo(type='video', infoLabels={'title': i[1]+ ' '+i[0],'sorttitle': i[0],'plot': ''})
            li.setArt({'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': img})
            url = build_url({'mode':'playSource','link':baseurl+i[2]})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)

def chanList(categId):
    tv=eval(addon.getSetting('channelData'))[int(categId)]
    for t in tv:
        if t[2].startswith('http'):
            img=t[2]
        else:
            img=baseurl+t[2]
        li=xbmcgui.ListItem(t[0])
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': t[0],'sorttitle': t[0],'plot': ''})
        li.setArt({'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':img})
        url = build_url({'mode':'playSource','link':t[1]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def getSource(link):

    hea={
    'User-Agent':UA,
    }
    url=''
    if link.startswith('http'):
        url=link
    else:
        url=baseurl+link
    resp=requests.get(url,headers=hea).text
    #print('resp')
    #print(resp)
    resp_1=resp.split('<div class="lala8">')
    #print('resp_1')
    #print(resp_1)
    strims=[]
    for i in range(1,len(resp_1)):
        r=resp_1[i]
        r=r.replace('\n','')
        name=re.compile('stream-title\">([^<]+?)<').findall(r)[0]
        name=name.replace('<strong>','').replace('</strong>','')
        link=re.compile('<a.*href=\'(.*)\' rel').findall(r)[0]
        if '/frames/' not in link: #tylko linki bez playerów VPN
            strims.append([name,link])

    data=strims
    #print('STRIMS')
    #print(data)
    nameStream=[]
    for d in data:
        nameStream.append(d[0])
    select = xbmcgui.Dialog().select('Źródła', nameStream)
    #print(nameStream)
    if select > -1:
        url_stream=data[select][1]
        print(url_stream)
        xbmcplugin.setContent(addon_handle, 'videos')
        playSource(url_stream)
    else:
        quit()
    return


def playSource(u):
    protocol=''
    url_stream=''#
    hea={
        'User-Agent':UA,
    }
    #u=u.replace('?stream=','').replace('?sid=','/')
    u=u.replace('=','/').replace('lala/index.php?stream','streams').replace('?sid','')
    print(u)
    resp=requests.get(u,headers=hea).text
    if ' playStream(\'iframe\'' in resp:
        url_1=re.compile('iframe\',\'(.*)\'\);.?').findall(resp)[0]
        url_1=url_1.replace(' ','')
        print(url_1)
        hea={
            'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0',
            'referer':u
        }
        resp=requests.get(url_1,headers=hea).text
        if 'wikisport.click' in url_1:#2022-07
            '''
            x=re.compile('atob\(\'(.*)\'\)').findall(resp)
            dec=base64.b64decode(x[0]).decode('utf-8')
            if dec.startswith('http'):
                dec=dec
            else:
                dec='http://wikisport.click'+dec
            '''
            if 'noob4cast' in resp:
                url_stream=noob4cast(resp,url_1)
            else:
                r1=resp.split('Clappr.Player')[1]
                x=re.compile('source: \"(.*)\"').findall(r1)[0]
                url_stream=x+'|Referer=http://wikisport.click&User-Agent='+UA
                heaPRX={
                    'user-agent':UA,
                    'referer':url_1
                }
                addon.setSetting('heaPRX',str(heaPRX))
                proxyport = addon.getSetting('proxyport')
                url_stream='http://127.0.0.1:%s/WIKISPORT='%(str(proxyport))+url_stream
        if 'freestreams-live' in url_1:
            x=re.compile('atob\(\'(.*)\'\)').findall(resp)
            url_stream=base64.b64decode(x[0]).decode('utf-8')+'|Referer=http://fb.freestreams-live1.com&User-Agent='+UA
        if 'daddylive.' in url_1:
            #http://lalastreams.me/streams/126017/1214361
            hea={
                'User-Agent':UA
            }
            resp=requests.get(url_1,headers=hea).text
            url_2=re.compile('iframe src=\"([^"]+?)\"').findall(resp)[0]
            hea={
                'User-Agent':UA,
                'referer':'https://daddylive.fun/'
            }
            resp=requests.get(url_2,headers=hea).text
            url_stream=re.compile('source:\'(.*)\',').findall(resp)[1]+'|Referer='+url_2+'&User-Agent='+UA
        if 'eplayer.click' in url_1:
            url_stream=_eplayer_click(url_1)
        if 'cdnz.one' in url_1 or 'cdn1.link' in url_1:
            fid=re.compile('fid=\'(.*)\'; v_w').findall(resp)[0]
            hea={
                'User-Agent':UA,
                'Referer':url_1
            }
            url='https://ragnaru.net/embed.php?player=embedded+&live='+fid
            resp=requests.get(url,headers=hea).text
            x=re.compile('return\(\[(.*)\]\.join', re.DOTALL).findall(resp)
            url_stream=x[0].replace('"','').replace('"','').replace('\\','').replace(',','')
            url_stream=url_stream+'|User-Agent='+UA+'&Referer='+url
        if 'sportsonline.to' in url_1:
            hea={'User-Agent':UA}
            resp=requests.get(url_1,headers=hea).text
            url_2=re.compile('iframe src=\"([^"]+?)\"').findall(resp)[0]
            hea={
                'user-agent':UA,
                'referer':url_1
            }
            resp=requests.get(url_2,headers=hea).text
            packed = re.compile('(eval\(function\(p,a,c,k,e,(?:r|d).*)').findall(resp)[0]
            unpacked=jsunpack.unpack(packed)
            url_stream=re.compile('src=\"([^"]+?)\"').findall(unpacked)[0]+'|Referer='+url_2+'&User-Agent='+UA
        if 'nba-streams.online' in url_1:
            x=re.compile('atob\(\'(.*)\'\)').findall(resp)
            url_stream=base64.b64decode(x[0]).decode('utf-8')+'|User-Agent='+UA
        if '2checksitea' in url_1:
            url_stream=re.compile('{source: \"(.*)\",').findall(resp)[0]+'|Referer='+url_1+'&User-Agent='+UA
        if 'leet365.cc' in url_1:
            url_2=re.compile('iframe.*src=\"([^"]+?)\"').findall(resp)[0]
            hea={
                'user-agent':UA,
                'referer':url_1
            }
            resp=requests.get(url_2,headers=hea).text
            packed = re.compile('(eval\(function\(p,a,c,k,e,(?:r|d).*)').findall(resp)
            unpacked=''
            for p in packed:
                unpacked += jsunpack.unpack(p)
            x=re.compile('src=\"([^"]+?)\"').findall(unpacked)
            url_stream=''
            for s in x:
                if 'm3u' in s:
                     url_stream=s+'|Referer='+url_2+'&User-Agent='+UA
                     break
        if 'cricfree' in url_1:
            url_2=re.compile('iframe.*src=\"([^"]+?)\"').findall(resp)[0]
            hea={
                'user-agent':UA,
                'referer':url_1
            }
            resp=requests.get(url_2,headers=hea).text
            if 'castfree.me' in resp:
                fid=re.compile('fid=\"([^"]+?)\"; v_w').findall(resp)[0]
                url_3='http://castfree.me/embed.php?player=embedded&live='+fid
                hea={
                    'user-agent':UA,
                    'referer':url_2
                }
                resp=requests.get(url_3,headers=hea).text
                x=re.compile('return\(\[(.*)\]\.join', re.DOTALL).findall(resp)
                y=x[0].replace('"','').replace('"','').replace('\\','').replace(',','')
                url_stream=y+'|Referer='+url_3+'&User-Agent='+UA
        if 'cdn.sportcast.life' in url_1: #2022-08
            print(resp)
            url_2=re.compile('iframe.*src=\"([^\"]+?)\"').findall(resp)[0]
            hea={
                'User-Agent':UA,
                'Referer':url_1
            }
            resp=requests.get(url_2,headers=hea).text
            url_3=re.compile('iframe src=\"([^\"]+?)\"').findall(resp)[0]
            if 'daddylive' in url_3:
                hea={
                    'User-Agent':UA,
                    'Referer':'https://daddylive.one'
                }
                resp=requests.get(url_3,headers=hea).text
                url_s=re.compile('source:\'([^\"]+?)\'').findall(resp)[-1]
                url_stream=url_s+'|Referer='+url_3+'&User-Agent='+UA
        if 'r-strm.blogspot' in url_1:#2022-07
            url_stream=url_1.split('s=')[-1]+'|Referer='+u+'&User-Agent='+UA
        if 'embedstream' in url_1:#2022-07
            url_stream=embedstream(url_1,u)
            protocol='isa_hls'
        if 'cricplay2' in url_1:
            if 'castfree.me' in resp:
                url_stream=castfree(resp,url_1)
            

    else:
        if 'sportcast.life' in resp:
            id_=re.compile('\?id=(.*)\"><').findall(resp)[0]
            url_stream='https://uload.ru.com/cdn/premium'+id_+'/chunks.m3u8'+'|Referer=https://player.licenses4.me/&User-Agent='+UA
        if 'eplayer.click' in resp:
            url_1=re.compile('iframe.*src=\"(.*)\"').findall(resp)[0]
            url_stream=_eplayer_click(url_1)
        if 'new Clappr.Player' in resp:
            url_stream=re.compile('source: \"([^"]+?)\"').findall(resp)[0]+'|Referer='+u+'&User-Agent='+UA
        if 'bestsolaris' in resp:
            print('bestsolaris')
            url_1=re.compile('iframe.*src=\"([^"]+?)\"').findall(resp)[0]
            hea={
                'user-agent':UA,
                'referer':u
            }
            resp=requests.get(url_1,headers=hea).text
            url_stream=re.compile('source: \"([^"]+?)\"').findall(resp)[0]
            proxyport = addon.getSetting('proxyport')
            url_stream='http://127.0.0.1:%s/BESTSOLARIS='%(str(proxyport))+url_stream
        if 'embedstream' in resp:#2022-07
            url_1=re.compile('iframe.*src=\'([^\']+?)\'').findall(resp)[0]
            url_stream=embedstream(url_1,u)
            protocol='isa_hls'
        if 'crichd' in resp:#2022-07
            url_1=re.compile('iframe.*src=\"([^\"]+?)\"').findall(resp)[0]
            if url_1.startswith('//'):
                url_1='http:'+url_1
            hea={
                'user-agent':UA,
                'referer':u
            }
            resp=requests.get(url_1,headers=hea).text
            if 'noob4cast' in resp:
                noob4cast(resp,url_1)
                

    print(url_stream)

    if 'BESTSOLARIS' in url_stream or 'akamaihd.net' in url_stream or protocol=='isa_hls':
        import inputstreamhelper
        is_helper = inputstreamhelper.Helper('hls')
        if is_helper.check_inputstream():
            play_item = xbmcgui.ListItem(path=url_stream)
            play_item.setProperty("IsPlayable", "true")
            play_item.setProperty('inputstream', is_helper.inputstream_addon)
            #play_item.setProperty('inputstream.adaptive.stream_headers', '')
            play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            play_item.setMimeType('application/vnd.apple.mpegurl')
            play_item.setContentLookup(False)
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        play_item = xbmcgui.ListItem(path=url_stream)
        play_item.setProperty("IsPlayable", "true")
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)


#RESOLVERS:
def _eplayer_click(url_1):
    url_stream=''
    hea={
        'User-Agent':UA
    }
    resp=requests.get(url_1,headers=hea).text
    url_2=re.compile('iframe.*src=\"(.*)\"').findall(resp)[0]
    hea={
        'User-Agent':UA,
        'referer':url_1
    }
    resp=requests.get(url_2,headers=hea).text
    url_3=re.compile('iframe.*src=\"([^"]+?)\">\"').findall(resp)[0]
    hea={
        'User-Agent':UA,
        'referer':url_2
    }
    resp=requests.get(url_3,headers=hea).text
    if 'fotbaltv.biz' in url_3:
        url_4=re.compile('iframe src=\"([^"]+?)\"').findall(resp)[0]
        hea={
            'user-agent':UA,
            'referer':url_3
        }
        resp=requests.get(url_4,headers=hea).text
        url_stream=url_4.replace(url_4.split('/')[-1],re.compile('source: \'(.*)\',').findall(resp)[0])+'|Referer='+url_4+'&User-Agent='+UA

    else:
        id_=url_3.split('id=')[-1]
        print(url_3)
        #print(resp)
        url_4=(re.compile('\.src=`(.*)`').findall(resp)[0]).split('$')[0]+id_
        hea={
            'User-Agent':UA,
            'referer':url_3
        }
        resp=requests.get(url_4,headers=hea).text
        url_stream=re.compile('source:\'(.*)\',').findall(resp)[1]+'|Referer='+url_4+'&User-Agent='+UA
    return url_stream

def embedstream(url_1,ref):#2022-07
    url_stream=''
    hea={
        'User-Agent':UA,
        'referer':ref
    }
    r1=requests.get(url_1,headers=hea).text
    pdettxt=re.compile('pdettxt = "([^\"]+?)\"').findall(r1)[0]
    zmid=re.compile('zmid = "([^\"]+?)\"').findall(r1)[0]
    pid=re.compile('pid = ([^;]+?);').findall(r1)[0]
    edm=re.compile('edm = \"([^\"]+?)\"').findall(r1)[0]
    u1="https://"+edm+"/sd0embed?v="+zmid
    data={
        'pid': pid,
        'ptxt': pdettxt.replace(' ','+')
    }
    hea={
        'user-agent':UA,
        'referer':'https://embedstream.me/',
        'origin':'https://embedstream.me'
    }
    r2=requests.post(u1,data=data,headers=hea).text
    skrypty = re.findall('<script>(.+?)<\/script>\\n',r2,re.DOTALL)
    payload = """function abs() {%s};\n abs()	"""
    a=''
    for skrypt in skrypty:
        if 'let' in skrypt and 'eval' in skrypt:
            a = payload%(skrypt)
            a = a[::-1].replace("eval"[::-1], "return"[::-1], 1)[::-1]
            break
    jsPayload = a 
    import js2py
    js2py.disable_pyimport()
    context = js2py.EvalJs()
               
    try:
        context.execute(jsPayload)
        response_content = context.eval(jsPayload)
        response_content = response_content if response_content else ''
    except Exception as e:
        response_content=''
    if 'function(h,u,n,t,e,r)' in response_content:
        from resources.lib import dehunt as dhtr
        ff=re.findall('function\(h,u,n,t,e,r\).*?}\((".+?)\)\)',response_content,re.DOTALL)[0]#.spli
        ff=ff.replace('"','')
        h, u, n, t, e, r = ff.split(',')
        cc = dhtr.dehunt (h, int(u), n, int(t), int(e), int(r))
        cc=cc.replace("\'",'"')
        fil = re.findall('file:\s*window\.atob\((.+?)\)',cc,re.DOTALL)[0]
        src = re.findall(fil+'\s*=\s*"(.+?)"',cc,re.DOTALL)[0]
        url_stream= base64.b64decode(src).decode('utf-8') + '|User-Agent='+UA+'&Referer='+u1+'&Origin=https://www.tvply.me/'
    return url_stream

def noob4cast(r,ref):#2022-07
    fid=re.compile('fid=\"([^\"]+?)\"').findall(r)[0]
    url='https://noob4cast.com/crichdwasi.php?player=embedded&live='+fid
    hea={
        'user-agent':UA,
        'referer':ref
    }
    resp=requests.get(url,headers=hea).text
    u=re.compile('return\(\[(.*)\]').findall(resp)[0]
    u1=u.replace('\"','').replace('\\','').replace(',','')
    return u1+'|Referer='+url+'&User-Agent='+UA

def castfree(r,ref):#2022-07
    fid=re.compile('fid=\"([^"]+?)\"; v_w').findall(r)[0]
    url='http://castfree.me/embed.php?player=embedded&live='+fid
    hea={
        'user-agent':UA,
        'referer':ref
    }
    resp=requests.get(url,headers=hea).text
    x=re.compile('return\(\[(.*)\]\.join', re.DOTALL).findall(resp)
    y=x[0].replace('"','').replace('"','').replace('\\','').replace(',','')
    return y+'|Referer='+url+'&User-Agent='+UA
    

mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='categs':
        link=params.get('link')
        itemList(link)

    if mode=='tvList':
        categId=params.get('categId')
        chanList(categId)

    if mode=='playSource':
        link=params.get('link')
        getSource(link)

