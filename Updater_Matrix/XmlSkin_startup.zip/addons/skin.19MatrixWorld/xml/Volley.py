import xbmc, xbmcgui



def Volley():
    funcs = (click_1, click_2,)
    call = xbmcgui.Dialog().select('[B][COLOR=blue]       VOLLEY[/COLOR][/B]',
['[COLOR=yellow]Volley  ([COLOR blue]Daddylive[/COLOR])',

 '[COLOR=blue]Volley  ([COLOR yellow]Microjen[/COLOR])'

 # '[COLOR=green]Volley[/COLOR] (Dracarys)'


 ])




    if call:
        if call < 1:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('RunScript("special://home/addons/skin.19MatrixWorld/xml/Dialog Spor/DialogDLvolley.py")')
def click_2():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/sporthd?description=Volleyball&iconimage=C%3a%5cPortableApps%5ckodi%5cMy%20Kodi%5cKodi%5cportable_data%5caddons%5cplugin.video.microjen%5cresources%5clib%5cexternal%5csporthd%5cmedia%5clivetv.png&mode=livetvSX_events&name=Volleyball%20(22)&url=sport%7cVolleyball")')
    xbmcgui.Dialog().notification("[B][COLOR=orange]Microjen[/COLOR][/B]", "[COLOR blue]VOLLEY[/COLOR][COLOR gold]BALL[/COLOR]", sound=False, icon='special://home/addons/plugin.video.microjen/resources/lib/external/sporthd\media/livetv.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR=orange]Microjen[/COLOR][/B]", "[COLOR blue]VOLLEY[/COLOR][COLOR gold]BALL[/COLOR]", sound=False, icon='special://home/addons/plugin.video.microjen/resources/lib/external/sporthd\media/livetv.png')


Volley()
