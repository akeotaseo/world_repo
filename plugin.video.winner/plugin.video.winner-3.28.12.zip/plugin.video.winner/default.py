# -*- coding: utf-8 -*-

import os
import xbmcgui,xbmc,xbmcvfs,xbmcaddon,xbmcplugin
from urllib.parse import urlencode, parse_qsl

runtime_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('Path'))


def get_url(**kwargs):
    return '{}?{}'.format(sys.argv[0], urlencode(kwargs))


def play_video(path):
    play_item = xbmcgui.ListItem()
    play_item.setPath(path)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=play_item)


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        pDialog = xbmcgui.DialogProgress()
        pDialog.create('Winner 3', 'Buscando eventos...')

        t = 100
        while not pDialog.iscanceled() and t > 0:
            pDialog.update(t, 'Buscando eventos para hoy...')
            xbmc.sleep(500)
            t -= 1

        pDialog.close()

        list_item = xbmcgui.ListItem(label='Eventos encontrados para hoy 28/12/2024')
        icon = os.path.join(runtime_path, 'resources', 'media', 'icon.jpg')
        list_item.setArt({'poster': icon, 'icon':icon, 'fanart': os.path.join(runtime_path, 'resources', 'media', 'fanart.jpg')})
        list_item.setProperty('IsPlayable', 'true')

        url = get_url(action='play')
        xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, list_item, False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif params['action'] == 'play':
        video = os.path.join(runtime_path, 'resources', 'media', 'sintonia.mp4')
        play_video(video)

        xbmc.sleep(1500)
        xbmcgui.Dialog().notification('Kodiadictos & La Taberna',
                                      'INOCENTE!!!! .... INOCENTE!!!! .... INOCENTE!!!! .... INOCENTE!!!! .... INOCENTE!!!! .... INOCENTE!!!! .... INOCENTE!!!! .... ',
                                      os.path.join(runtime_path, 'resources', 'media', 'icon.gif'))


if __name__ == '__main__':
    router(sys.argv[2][1:])


