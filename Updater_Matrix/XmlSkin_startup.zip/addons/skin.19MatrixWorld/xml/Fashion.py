import xbmc, xbmcgui


def Fashion():
    funcs = (click_1, click_2, click_3, click_4)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]       Fashion[/COLOR][/B]',
['[COLOR=grey]Fashion TV Player[/COLOR]',
 '[COLOR=grey]Fashion [/COLOR] MIDNIGHT SECRETS',
 '[COLOR aqua]Fashion Channel[/COLOR] ',
 '[COLOR=grey]Fashion[/COLOR]  playlistloaderworld'])


    if call:
        if call < 1:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.fashiontv.com/",return)')


def click_2():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.myiptvpro/?url=https%3A%2F%2Ffash1043.cloudycdn.services%2Fslive%2F_definst_%2Fftv_ftv_midnite_k1y_27049_midnite_secr_108_hls.smil%2Fplaylist.m3u8&mode=12&iconimage=http%3A%2F%2Ftv.team%2Fimages%2FchIcons%2F1643.png")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/channel/UCepVy23t8l-CEaASZzfo9Jg/")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloaderworld/?cache=0&epg&iconimage=DefaultTVShows.png&index=21&logos&mode=10&name=Fashion&url=https%3a%2f%2fraw.githubusercontent.com%2fIPTVSHARED%2fSTANTECH%2frefs%2fheads%2fmain%2fStantechTV.m3u&uuid=0")')




Fashion()
