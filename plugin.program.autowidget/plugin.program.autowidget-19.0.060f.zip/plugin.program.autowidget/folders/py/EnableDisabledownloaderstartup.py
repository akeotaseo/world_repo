import xbmc, xbmcgui


def EnableDisabledownloaderstartup():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=green]Enable[/COLOR][/B]/[B][COLOR=red]Disable[/COLOR]downloader_startup[/B]', 
['[COLOR=green]Enable Updater build[/COLOR]',
 '[COLOR=red]Disable Updater build[/COLOR]'])
 



    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




#def click_1():
#    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.apex_sports/?category=live_sport&amp;mode=search)')
#    xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology[/COLOR][/B]",'[COLOR white]Για την αναζήτηση αγώνων, πληκτρολογήστε την Ομάδα ή την Χώρα με λατινικούς χαρακτήρες ...[/COLOR]' , icon ='special://home/addons/skin.TechNEWSology/icon.png')

def click_1():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.downloader19/?description&fanart=C%3a%5cPortableApps%5ckodi%5cKodi%20World%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader19%5cfanart.jpg&icon=special%3a%2f%2fhome%2faddons%2fplugin.program.downloader19%2fresources%2fmedia%2fWorld.png&mode=30&name=E%ce%bd%ce%b5%cf%81%ce%b3%ce%bf%cf%80%ce%bf%ce%af%ce%b7%cf%83%ce%b7%20%ce%b1%cf%85%cf%84%cf%8c%ce%bc%ce%b1%cf%84%cf%89%ce%bd%20%ce%b5%ce%bd%ce%b7%ce%bc%ce%b5%cf%81%cf%8e%cf%83%ce%b5%cf%89%ce%bd%20%cf%84%ce%bf%cf%85%20Downloader%20Startup&name2&url&version",return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.downloader19/?description&fanart=C%3a%5cPortableApps%5ckodi%5cKodi%20World%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader19%5cfanart.jpg&icon=special%3a%2f%2fhome%2faddons%2fplugin.program.downloader19%2fresources%2fmedia%2fWorld.png&mode=29&name=%ce%91%cf%80%ce%b5%ce%bd%ce%b5%cf%81%ce%b3%ce%bf%cf%80%ce%bf%ce%af%ce%b7%cf%83%ce%b7%20%ce%b1%cf%85%cf%84%cf%8c%ce%bc%ce%b1%cf%84%cf%89%ce%bd%20%ce%b5%ce%bd%ce%b7%ce%bc%ce%b5%cf%81%cf%8e%cf%83%ce%b5%cf%89%ce%bd%20%cf%84%ce%bf%cf%85%20Downloader%20Startup&name2&url&version",return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=all&url=https%3a%2f%2fwww.cinemagia.ro%2ffilme%2f%3fpn%3d1",return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=ani&url=https%3a%2f%2fwww.cinemagia.ro%2ffilme%2f%3fpn%3d1",return)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=gen&url=https%3a%2f%2fwww.cinemagia.ro%2ffilme%2f%3fpn%3d1",return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=tari&url=https%3a%2f%2fwww.cinemagia.ro%2ffilme%2f%3fpn%3d1",return)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=all&url=https%3a%2f%2fwww.cinemagia.ro%2fseriale-tv%2f%3fpn%3d1",return)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=ani&url=https%3a%2f%2fwww.cinemagia.ro%2fseriale-tv%2f%3fpn%3d1",return)')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=gen&url=https%3a%2f%2fwww.cinemagia.ro%2fseriale-tv%2f%3fpn%3d1",return)')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=tari&url=https%3a%2f%2fwww.cinemagia.ro%2ffilme%2f%3fpn%3d1",return)')

EnableDisabledownloaderstartup()
