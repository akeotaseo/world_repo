﻿import xbmc, xbmcgui
def GREE_KTV():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('Action(Back)')
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('ActivateWindow(10000)')
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR white][B]--->[/B][/COLOR] [COLOR blue]GREEK TV 2 [/COLOR]", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png')
    xbmc.sleep(2000)
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.microjen/run_plug/plugin.video.live.streamspro%2F%3Fmode%3D1%26url%3Dhttps%3A%2F%2Fraw.githubusercontent.com%2Fiptv-org%2Fiptv%2Fmaster%2Fstreams%2Fgr.m3u%3F")')


    #xbmc.executebuiltin('Action(Back)')
    #xbmc.executebuiltin('Dialog.Close(all,true)')
    #xbmc.sleep(1000)

GREEK_TV()