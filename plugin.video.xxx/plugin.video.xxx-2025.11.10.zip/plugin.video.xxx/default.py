import sys
import urllib
import xbmcplugin
from lib.modules import MainMenu

def GetParams():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring) >= 2:
		params        = sys.argv[2]
		cleanedparams = params.replace('?','')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams ={}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]							
	return param
        
params = GetParams()
url  = None
name = None
mode = None
iconimage = None

try: url = urllib.parse.unquote_plus(params["url"])
except: pass

try: name = urllib.parse.unquote_plus(params["name"])
except: pass

try: iconimage = urllib.parse.unquote_plus(params["iconimage"])
except: pass

try: mode = int(params["mode"])
except: pass

print('Mode: ' + str(mode))
print('Name: ' + str(name))

from lib.modules import Common
from lib.sources import Favourites

from lib.sources import FreePornVideos
from lib.sources import HQPorner
from lib.sources import PornOne
from lib.sources import XHand
from lib.sources import XOZilla
from lib.sources import XTits

if mode == None or url == None or len(url) <1: MainMenu.Menu()

elif mode == 1: Common.Play(url)

elif mode == 3: Common.AddFavourites(url, name, iconimage)
elif mode == 4: Common.RemoveFavourites(url, name, iconimage)
elif mode == 5: Favourites.Browse()

#elif mode == 20: 
#elif mode == 21: 
#elif mode == 22: 
#elif mode == 23: 

elif mode == 30: FreePornVideos.Menu()
elif mode == 31: FreePornVideos.Browse(url)
elif mode == 32: FreePornVideos.Categories(url)
elif mode == 33: FreePornVideos.PlayStream(url)
elif mode == 34: FreePornVideos.Sites(url)

elif mode == 40: XTits.Menu()
elif mode == 41: XTits.Browse(url)
elif mode == 42: XTits.Categories(url)
elif mode == 43: XTits.PlayStream(url)

elif mode == 90: XHand.Menu()
elif mode == 91: XHand.Browse(url)
elif mode == 92: XHand.Categories(url)
elif mode == 93: XHand.PlayStream(url)

elif mode == 100: XOZilla.Menu()
elif mode == 101: XOZilla.Browse(url)
elif mode == 102: XOZilla.Categories(url)
elif mode == 103: XOZilla.PlayStream(url)

elif mode == 120: HQPorner.Menu()
elif mode == 121: HQPorner.Browse(url)
elif mode == 122: HQPorner.Categories(url)
elif mode == 123: HQPorner.PlayStream(url)

elif mode == 130: PornOne.Menu()
elif mode == 131: PornOne.Browse(url)
elif mode == 132: PornOne.Categories(url)
elif mode == 133: PornOne.PlayStream(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
