from codequick import Route, Listitem
from resources.lib.kedon import tb
@Route.register
def index_phim(plugin,**kwargs):
	yield Listitem.from_dict(**{'label': 'OPhim',
	'info': {'plot': tb},
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/ophim.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/ophim.png'},
	'callback': Route.ref('/resources/lib/mkd/onphim/ophim:index_ophim')})
	yield Listitem.from_dict(**{'label': 'TVHay',
	'info':{'plot':tb},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/tvh.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/tvh.png'},
	'callback': Route.ref('/resources/lib/mkd/onphim/tvhay:index_tvh')})
	yield Listitem.from_dict(**{'label': 'PhimMoi',
	'info':{'plot':tb},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/phimmoi.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/phimmoi.png'},
	'callback': Route.ref('/resources/lib/mkd/onphim/phimmoi:index_phimmoi')})
	yield Listitem.from_dict(**{'label': 'BiluTV',
	'info':{'plot':tb},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/bilutv.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/bilutv.png'},
	'callback': Route.ref('/resources/lib/mkd/onphim/bilu:index_bilu')})
	yield Listitem.from_dict(**{'label': 'Xem8Z',
	'info':{'plot':tb},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/x8z.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/x8z.png'},
	'callback': Route.ref('/resources/lib/mkd/onphim/xem8z:index_8z')})
	yield Listitem.from_dict(**{'label': 'TocAnime',
	'info':{'plot':tb},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/tocanm.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/tocanm.png'},
	'callback': Route.ref('/resources/lib/mkd/onphim/tocanm:index_tocanm')})
	yield Listitem.from_dict(**{'label': 'Fmovies',
	'info':{'plot':tb},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/fmovi.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/fmovi.png'},
	'callback': Route.ref('/resources/lib/mkd/onphim/fmovies:index_fm')})