---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

**Version Info**
Plugin Version:
Kodi Version:
Operating System:

**The Issue**
A clear and concise description of what you expected to happen.

**To Reproduce**
Steps to reproduce the behavior:
1. 
2. 
3. 
4. 

**Additional context**
Add any other context about the problem here.
