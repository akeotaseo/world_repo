plugin.video.co.bellesa
=======================

This addon provides seamless access to bellesa.co site.
Two versions are available - free and full.

| Feature         | free           | full                                    |
|-----------------|----------------|-----------------------------------------|
| Max resolution  | no (up to 720) | yes (based on server side availability) |
| Freeform search | no             | yes                                     |
| Search presets  | 1              | unlimited                               | 
| Pagination      | no             | yes                                     |

## Buy

Monero is preferred payment method currently, drop me an [email](fr33p0rt@protonmail.com)
to ask for different payment options.

## Third party software and other assets

### fanart.jpg
- based on 'Photo by Toni Cuenca from Pexels'
  - https://www.pexels.com/photo/two-woman-laying-down-on-pink-and-blue-floaters-565996/

### icon.png
- based on fonts
  - DejaVu Sans Condensed

### empty.mp4
- https://github.com/mathiasbynens/small/blob/master/Mpeg4.mp4

## Data collection

Software collects anonymous data about its usage.  
