# -*- coding: utf-8 -*-
import os, re, time, kanal, datetime, requests, sqlite3, threading, traceback, control, xbmc, json, sys
from sys import argv
from contextlib import contextmanager
if control.PY2:
	from urllib2 import HTTPError
	from urllib import quote_plus, urlencode, quote
	from urlparse import parse_qs, urlparse, urljoin, parse_qsl
else:
	from urllib.parse import quote_plus, urlencode, parse_qs, urlparse, urljoin, parse_qsl, quote
	from urllib.error import HTTPError
mirr = None
BASEURL = 'https://vjackson.info/'
MAX_SEARCH_HISTORY_ITEMS = control.getSettingInt('hystory')
DEBUG_HOSTERS = False
REPORT_CAPTURE_SCREENSHOTS = False

class Thread(threading.Thread):

    def __init__(self, target, *args):
        self._target = target
        self._args = args
        threading.Thread.__init__(self)

    def run(self):
        self._target(*self._args)

class Database(object):

    def __init__(self, basePath=None, filename=None):
        self.conn = None
        if basePath is None:
            basePath = control.transPath(control.addonInfo('profile')).encode('utf-8').decode('utf-8')
        self.basePath = basePath
        self.path = control.joinPath(basePath, filename)
        return

    def getConnection(self):
        if not self.conn:
            self.conn = self.onNewConnection()
        return self.conn

    def onNewConnection(self):
        if not control.exists(self.basePath):
            control.mkdirs(self.basePath)
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        return conn

    def cursor(self):
        return self.getConnection().cursor()

    def commit(self):
        self.getConnection().commit()

    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None
        return

    @contextmanager
    def singleConnectionCursor(self):
        conn = self.onNewConnection()
        try:
            cursor = conn.cursor()
            try:
                yield cursor
                conn.commit()
            finally:
                cursor.close()

        finally:
            conn.close()

def log(text):
	a = 'plugin.video.vavooto   '+repr(text)
	xbmc.log(a, xbmc.LOGINFO)

def index(params):
    #xbmcplugin.setContent(handle, 'VAVOO.TO')
    addDir2('Live', 'PVR', 'channels')
    addDir2('Suche', 'search', 'search', genre=params.get('genre', ''))
    addDir2('Filme', 'movies', 'indexMovie', genre=params.get('genre', ''))
    addDir2('Serien', 'series', 'indexSerie', genre=params.get('genre', ''))
    addDir2('Netflix', 'netflix', 'provider', name='netflix', genre=params.get('genre', ''))
    addDir2('Maxdome', 'maxdome', 'provider', name='maxdome', genre=params.get('genre', ''))
    addDir2('Amazon Prime', 'amazon', 'provider', name='amazon', genre=params.get('genre', ''))
    addDir2('Einstellungen', 'settings', 'setmenu')
    control.directory(control.handle, succeeded=True, cacheToDisc=True)

def setmenu(params):
	#xbmcplugin.setContent(handle, 'files')
	addDir2('VAVOO-EINSTELLUNGEN', 'settings', 'settings')
	if control.condVisibility('System.HasAddon("script.module.urlresolver")'):
		addDir2('RESOLVER-EINSTELLUNGEN', 'settings', 'settings', id="script.module.urlresolver")
	if control.condVisibility('System.HasAddon("pvr.iptvsimple")'):
		addDir2('PVR-EINSTELLUNGEN', 'settings', 'settings', id="pvr.iptvsimple")
	if control.condVisibility('System.HasAddon("inputstream.ffmpegdirect")'):
		addDir2('ffmpegdirect-Einstellungen', 'settings', 'settings', id="inputstream.ffmpegdirect")
	control.directory(control.handle, succeeded=True, cacheToDisc=True)

def indexMovie(params):
    #xbmcplugin.setContent(handle, 'movies')
    addDir2('Neu hinzugefügt', 'new2', 'directory', function='all', type='movie', order='created', direction='desc', genre=params.get('genre', ''))
    addDir2('Neuerscheinungen', 'new2', 'directory', function='collection', type='movie', name='release_date/' + getLocale({}), direction='desc', genre=params.get('genre', ''))
    addDir2('Genres', 'genres', 'tag', category='genre', type='movie', genre=params.get('genre', ''))
    addDir2('Länder', 'genres', 'tag', category='country', type='movie', genre=params.get('genre', ''))
    addDir2('Weitere Listen', 'genres', 'listMovie', genre=params.get('genre', ''))
    addDir2('Einstellungen', 'settings', 'setmenu', genre=params.get('genre', ''))
    control.directory(control.handle, succeeded=True, cacheToDisc=True)

def listMovie(params):
    #xbmcplugin.setContent(handle, 'movies')
    addDir2('Wird gerade angesehen (trakt.tv)', 'new2', 'directory', function='collection', type='movie', name='trakt.tv/movie/trending', direction='asc', genre=params.get('genre', ''))
    addDir2('Derzeit beliebt (IMDB)', 'top', 'directory', function='collection', type='movie', name='imdb.com/movie/popular', genre=params.get('genre', ''))
    addDir2('Derzeit beliebt (TheMovieDB)', 'top', 'directory', function='collection', type='movie', name='themoviedb.org/popularity', direction='desc', genre=params.get('genre', ''))
    addDir2('Derzeit beliebt (trakt.tv)', 'top', 'directory', function='collection', type='movie', name='trakt.tv/movie/watched', direction='asc', genre=params.get('genre', ''))
    addDir2('Top (Moviepilot)', 'top', 'directory', function='collection', type='movie', name='moviepilot.de/movie/best', genre=params.get('genre', ''))
    addDir2('Top (IMDB)', 'top', 'directory', function='collection', type='movie', name='imdb.com/rating', direction='desc', genre=params.get('genre', ''))
    addDir2('Top (TheMovieDB)', 'top', 'directory', function='collection', type='movie', name='themoviedb.org/vote_average', genre=params.get('genre', ''))
    addDir2('Top (trakt.tv)', 'top', 'directory', function='collection', type='movie', name='trakt.tv/movie/popular', direction='asc', genre=params.get('genre', ''))
    addDir2('Bewertungen (IMDB)', 'top', 'directory', function='collection', type='movie', name='imdb.com/votes', direction='desc', genre=params.get('genre', ''))
    addDir2('Bewertungen (TheMovieDB)', 'top', 'directory', function='collection', type='movie', name='themoviedb.org/vote_count', genre=params.get('genre', ''))
    addDir2('Gerade im Kino (kinox.to)', 'top', 'directory', function='collection', type='movie', name='kinox.to/movie/cinema', genre=params.get('genre', ''))
    addDir2('Gerade im Kino (film.at)', 'top', 'directory', function='collection', type='movie', name='film.at/movie/cinema', genre=params.get('genre', ''))
    addDir2('Gerade im Kino (Moviepilot)', 'top', 'directory', function='collection', type='movie', name='moviepilot.de/movie/cinema', genre=params.get('genre', ''))
    addDir2('Neue Filme (Netflix)', 'new2', 'directory', function='collection', type='movie', name='justwatch.com/de/netflix/new', order='collection', direction='desc', genre=params.get('genre', ''))
    addDir2('Beliebte Filme (Netflix)', 'top', 'directory', function='collection', type='movie', name='justwatch.com/de/netflix/popular', order='collection', direction='asc', genre=params.get('genre', ''))
    addDir2('Neue Filme (Amazon Prime)', 'new2', 'directory', function='collection', type='movie', name='justwatch.com/de/amazon/new', order='collection', direction='desc', genre=params.get('genre', ''))
    addDir2('Beliebte Filme (Amazon Prime)', 'top', 'directory', function='collection', type='movie', name='justwatch.com/de/amazon/popular', order='collection', direction='asc', genre=params.get('genre', ''))
    addDir2('Neue Filme (Maxdome)', 'new2', 'directory', function='collection', type='movie', name='justwatch.com/de/maxdome/new', order='collection', direction='desc', genre=params.get('genre', ''))
    addDir2('Beliebte Filme (Maxdome)', 'top', 'directory', function='collection', type='movie', name='justwatch.com/de/maxdome/popular', order='collection', direction='asc', genre=params.get('genre', ''))
    control.directory(control.handle, succeeded=True, cacheToDisc=True)

def indexSerie(params):
    #xbmcplugin.setContent(handle, 'tvshows')
    addDir2('Neu hinzugefügt', 'new2', 'directory', function='all', type='serie', order='created', direction='desc', genre=params.get('genre', ''))
    addDir2('Neuerscheinungen', 'new2', 'directory', function='collection', type='serie', name='release_date/' + getLocale({}), direction='desc', genre=params.get('genre', ''))
    addDir2('Neue Episoden', 'new2', 'collectionEpisodes', type='serie', name='release_date/' + getLocale({}), direction='desc', genre=params.get('genre', ''))
    if not params.get('genre', ''):
        addDir2('Genres', 'genres', 'tag', category='genre', type='serie', genre=params.get('genre', ''))
    addDir2('Länder', 'genres', 'tag', category='country', type='serie', genre=params.get('genre', ''))
    addDir2('Weitere Listen', 'genres', 'listSerie', genre=params.get('genre', ''))
    addDir2('Einstellungen', 'settings', 'setmenu', genre=params.get('genre', ''))
    control.directory(control.handle, succeeded=True, cacheToDisc=True)

def listSerie(params):
    #xbmcplugin.setContent(handle, 'tvshows')
    addDir2('Wird gerade angesehen (trakt.tv)', 'new2', 'directory', function='collection', type='serie', name='trakt.tv/serie/trending', direction='asc', genre=params.get('genre', ''))
    addDir2('Derzeit beliebte (TheMovieDB)', 'top', 'directory', function='collection', type='serie', name='themoviedb.org/popularity', direction='desc', genre=params.get('genre', ''))
    addDir2('Derzeit beliebt (trakt.tv)', 'top', 'directory', function='collection', type='serie', name='trakt.tv/serie/watched', direction='asc', genre=params.get('genre', ''))
    addDir2('Top (Moviepilot)', 'top', 'directory', function='collection', type='serie', name='moviepilot.de/serie/best', genre=params.get('genre', ''))
    addDir2('Top (IMDB)', 'top', 'directory', function='collection', type='serie', name='imdb.com/rating', direction='desc', genre=params.get('genre', ''))
    addDir2('Top (TheMovieDB)', 'top', 'directory', function='collection', type='serie', name='themoviedb.org/vote_average', direction='desc', genre=params.get('genre', ''))
    addDir2('Top (trakt.tv)', 'top', 'directory', function='collection', type='serie', name='trakt.tv/serie/popular', direction='asc', genre=params.get('genre', ''))
    addDir2('Bewertungen (IMDB)', 'top', 'directory', function='collection', type='serie', name='imdb.com/votes', direction='desc', genre=params.get('genre', ''))
    addDir2('Bewertungen (TheMovieDB)', 'top', 'directory', function='collection', type='serie', name='themoviedb.org/vote_count', direction='desc', genre=params.get('genre', ''))
    addDir2('Neue Serien (Netflix)', 'new2', 'directory', function='collection', type='serie', name='justwatch.com/de/netflix/new', order='collection', direction='desc', genre=params.get('genre', ''))
    addDir2('Beliebte Serien (Netflix)', 'top', 'directory', function='collection', type='serie', name='justwatch.com/de/netflix/popular', order='collection', direction='asc', genre=params.get('genre', ''))
    addDir2('Neue Serien (Amazon Prime)', 'new2', 'directory', function='collection', type='serie', name='justwatch.com/de/amazon/new', order='collection', direction='desc', genre=params.get('genre', ''))
    addDir2('Beliebte Serien (Amazon Prime)', 'top', 'directory', function='collection', type='serie', name='justwatch.com/de/amazon/popular', order='collection', direction='asc', genre=params.get('genre', ''))
    addDir2('Neue Serien (Maxdome)', 'new2', 'directory', function='collection', type='serie', name='justwatch.com/de/maxdome/new', order='collection', direction='desc', genre=params.get('genre', ''))
    addDir2('Beliebte Serien (Maxdome)', 'top', 'directory', function='collection', type='serie', name='justwatch.com/de/maxdome/popular', order='collection', direction='asc', genre=params.get('genre', ''))
    control.directory(control.handle, succeeded=True, cacheToDisc=True)

def provider(params):
    name = params['name']
    #xbmcplugin.setContent(handle, 'files')
    addDir2('Neue Filme', 'new2', 'directory', function='collection', type='movie', name='justwatch.com/de/' + name + '/new', order='collection', direction='desc', genre=params.get('genre', ''))
    addDir2('Neue Serien', 'new2', 'directory', function='collection', type='serie', name='justwatch.com/de/' + name + '/new', order='collection', direction='desc', genre=params.get('genre', ''))
    addDir2('Beliebte Filme', 'top', 'directory', function='collection', type='movie', name='justwatch.com/de/' + name + '/popular', order='collection', direction='asc', genre=params.get('genre', ''))
    addDir2('Beliebte Serien', 'top', 'directory', function='collection', type='serie', name='justwatch.com/de/' + name + '/popular', order='collection', direction='asc', genre=params.get('genre', ''))
    addDir2('Einstellungen', 'settings', 'setmenu', genre=params.get('genre', ''))
    control.directory(control.handle, succeeded=True, cacheToDisc=True)

def channel(params):
    progress = control.progressDialog()
    try:
        progress.create('VAVOO.TO', 'Der Stream wird gestartet...')
        progress.update(25)
        from urlresolver import resolve
        resolvedUrl = resolve(params['url'])
        if '|' not in resolvedUrl:
            resolvedUrl += '|'
        resolvedUrl += '&seekable=0'
        progress.update(50)
        o = control.item()
        o.setInfo('Video', {'title': params['title'], 'Seekable': 'false'})
        o.setLabel(params['title'])
        o.setArt({'thumb':params['thumb']})
        o.setPath(resolvedUrl)
        o.setProperty('IsPlayable', 'true')
        o.setProperty('IsNotSeekable', 'true')
        o.setProperty('Seekable', 'false')
        control.setResolvedUrl(control.handle, True, o)
        progress.update(75)
    finally:
        if progress:
            progress.close()

def handle_wait(time_to_wait, kanal, heading="Abbrechen zur manuellen Auswahl", text1="Starte Stream in  : ", text2="STARTE  : "):
    progress = control.progressDialog
    create = progress.create(heading, text2+kanal)
    secs=0
    percent=0
    increment = int(100 / time_to_wait)
    cancelled = False
    while secs < time_to_wait:
        secs += 1
        percent = increment*secs
        secs_left = str((time_to_wait - secs))
        if control.getKodiVersion() < 19:progress.update(percent,text2+kanal,text1+str(secs_left))
        else:progress.update(percent,text2+kanal+"\n"+text1+str(secs_left))
        xbmc.sleep(1000)
        if (progress.iscanceled()):
            cancelled = True
            break
    if cancelled == True:
        progress.close()
        return False
    else:
        progress.close()
        return True

def livePlay(name):
	m = kanal.main()[name]
	if len(m) > 1:
		if control.getSettingInt('auto') == 0 or control.getSettingInt('auto') == 1 and handle_wait(control.getSettingInt('count'), name):
			n = m[0]
		else:
			cap=[]
			i = 0
			while i < len(m):
				i+=1
				cap.append('STREAM'+' '+str(i))
			index = control.dialog.select('', cap)
			if index < 0:
				return
			n = m[index]
	else:
		n = m[0]
	o = control.item(name)
	o.setPath(n + '?n=1&b=5&vavoo_auth=' + getAuthSignature() + '|User-agent=VAVOO/2.6')
	if control.condVisibility('System.HasAddon("inputstream.ffmpegdirect")'):
		o.setMimeType("video/mp2t")
		o.setProperty("inputstream", "inputstream.ffmpegdirect")
		o.setProperty("inputstream.ffmpegdirect.is_realtime_stream", "true")
		o.setProperty("inputstream.ffmpegdirect.stream_mode", "timeshift")
	o.setProperty('IsPlayable', 'true')
	control.setResolvedUrl(control.handle, True, o)
			
def channels(params):
    for name in kanal.main():
        url = control.getPluginUrl({'name': name})
        o = control.item(name)
        o.setInfo(type='Video', infoLabels={'Title': name})
        o.setProperty('IsPlayable', 'true')
        o.setProperty('selectaction', 'play')
        control.addItem(control.handle, url, o, isFolder=False)
        control.addSortMethod(control.handle, control.SORT_METHOD_LABEL)
    control.directory(control.handle, succeeded=True, cacheToDisc=False)

ITEM_TYPES = {'movie': 'Film', 'serie': 'Serie'}
LANGUAGE_OPTIONS = ('all', 'de', 'en')
LOCALE_OPTIONS = ('de', 'en')
RESOLUTION_OPTIONS = ('all', 'hd', 'sd')
STREAM_SELECT_OPTIONS = ('hosters2', 'auto', 'grouped')
PLAYBACK_RESOLUTION_OPTIONS = ('Highest', '1080p', '720p', '480p', '360p', 'Manual')
LANGUAGE_CODES = {'de': 'DE', 'en': 'EN'}
LANGUAGE_NAMES = {'de': {'de': 'Deutsch', 'en': 'Englisch'}, 'en': {'de': 'German', 'en': 'English'}}
HOSTER_ALIASES = {}
HOSTER_ALIASES_SHORT = {}
URLRESOLVER_SET_QUALITY = {}

def getLanguage(params):
    if 'language' in params:
        return params['language']
    return LANGUAGE_OPTIONS[int(control.getSetting('language'))]

def getLocale(params):
    if 'locale' in params:
        return params['locale']
    return LOCALE_OPTIONS[int(control.getSetting('locale'))]

def getHosters(params):
    return

def getResolution(params):
    if 'resolution' in params:
        return params['resolution']
    return RESOLUTION_OPTIONS[int(control.getSetting('resolution') or 1)]

def getPlaybackResolution():
    return PLAYBACK_RESOLUTION_OPTIONS[int(control.getSetting('playback_resolution') or 0)]

def getStreamSelect():
    return STREAM_SELECT_OPTIONS[int(control.getSetting('stream_select') or 0)]
    
def prepareListItem(urlParams, params, e, addTypename=False, isPlayable=False, callback=None):
    infos = {}
    properties = {}

    def getMeta(*paths, **kwargs):
        for path in paths:
            f = e
            for p in path:
                try:
                    f = f[p]
                except (KeyError, TypeError):
                    f = None
                    break

            if f:
                return f

        return kwargs.get('default', None)

    def setInfo(key, value):
        if value:
            infos[key] = value

    def setProperty(key, value):
        if value:
            properties[key] = value

    def setInfoPeople(key, value):
        if value:
            setInfo(key, value)

    title = e['title']
    attrs = []
    if addTypename:
        attrs.append(ITEM_TYPES[e['type']])
    if attrs:
        title += ' (' + (', ').join(attrs) + ')'
    if 'channelName' in e:
        title = '[B]' + e['channelName'] + '[/B]: ' + title
    setInfo('title', title)
    setInfo('originaltitle', getMeta(('original_title', )))
    setInfo('year', e['year'])
    media = e['media']
    art = {'thumb': getMeta(('images', 'thumb'), default='DefaultVideo.png'), 
       'poster': getMeta(('images', 'poster'), default='DefaultVideo.png'), 
       'banner': getMeta(('images', 'banner')), 
       'fanart': getMeta(('images', 'fanart')), 
       'clearart': getMeta(('images', 'clearart')), 
       'clearlogo': getMeta(('images', 'clearlogo')), 
       'landscape': getMeta(('images', 'still'))}

    def updateInfos(data):
        setInfo('plot', data.get('plot', None))
        setInfo('code', data.get('imdb', None))
        setInfo('premiered', data.get('release_date', None))
        setInfo('rating', data.get('rating', None))
        setInfo('votes', data.get('votes', None))
        return

    updateInfos(e)
    if e['type'] == 'serie':
        if 'get' in e:
            season = e['get']['season']
            episode = e['get']['episode']
        elif 'episode' in e:
            season = e['episode']['season']
            episode = e['episode']['episode']
            setInfo('TVShowTitle', 'Season %s Episode %s' % (season, episode))
        else:
            season = params.get('season')
            episode = params.get('episode')
        if season is not None and 'seasons' in e:
            setInfo('season', season)
            setInfo('episode', episode)
            season = getMeta(('seasons', season))
            if season:
                if 'get' not in e:
                    setProperty('TotalEpisodes', len(season.get('episodes', [])))
                season_title = season.get('name', None)
                if season_title and season_title.startswith('Staffel '):
                    season_title = None
                setProperty('SeasonTitle', season_title)
                media = season['media']
                poster = season.get('poster', None)
                if poster:
                    art['poster'] = poster
                    art['thumb'] = poster
                media = season['media']
                updateInfos(season)
                episode = season.get('episodes', {}).get(episode, None)
                if episode:
                    episode_title = episode.get('name', None)
                    if episode_title and episode_title.startswith('Episode '):
                        episode_title = None
                    setInfo('TVShowTitle', episode_title)
                    media = season['media']
                    thumb = episode.get('still', None)
                    if thumb:
                        art['thumb'] = thumb
                        art['landscape'] = thumb
                    updateInfos(episode)
    language = getLanguage(params)
    if language == 'all':
        urlParams['languages'] = (',').join(media['languages'])
        setProperty('Languages', (',').join(media['languages']))
    else:
        urlParams['languages'] = language
    if 'hd' in media['resolutions']:
        setProperty('ResolutionQuality', 'HD')
    genres = set()
    for g in getMeta(('genres', )) or tuple():
        genres.add(g)

    genres = (', ').join(sorted(genres))
    setInfo('genre', genres)
    countries = set()
    for g in getMeta(('countries', )) or tuple():
        countries.add(g)

    countries = (', ').join(sorted(countries))
    setInfo('country', countries)
    setInfoPeople('cast', getMeta(('cast', )))
    setInfoPeople('credits', getMeta(('credits', )))
    value = getMeta(('directors', ))
    if value:
        setInfo('director', value[0])
    value = getMeta(('writers', ))
    if value:
        setInfo('writer', value[0])
    trailer = getMeta(('trailers', ))
    if trailer:
        setInfo('trailer', trailer[(-1)]['url'])
    else:
        setInfo('trailer', control.getPluginUrl({'action': 'trailer', 'name': title.encode('utf-8')}))
    setProperty('selectaction', 'info')
    if isPlayable:
        setProperty('IsPlayable', 'true')
    contextMenuItems = []
    if callback:
        callback(urlParams, params, e, isPlayable, properties, contextMenuItems)
    return (infos, properties, art, media, contextMenuItems)

def createListItem(*args, **kwargs):
    o = kwargs.pop('o', None)
    infos, properties, art, media, contextMenuItems = prepareListItem(*args, **kwargs)
    if o is None:
        o = control.item()
    o.setInfo('Video', infos)
    o.setLabel(infos['title'])
    o.addContextMenuItems(contextMenuItems, False)
    for key, value in properties.items():
        value = str(value)
        o.setProperty(key, value)

    if art:
        o.setArt(art)
        if art['thumb']:
            o.setArt({'thumb':art['thumb']})
    return (o, media)

def createDirectory(function, type, params, data, sortByHD=True):
    if type == 'series':
        content = 'tvshows'
    else:
        content = 'movies'
    #xbmcplugin.setContent(control.handle, content)
    items = []
    for i, e in enumerate(data):
        if e['type'] == 'movie':
            isPlayable = True
            isFolder = False
            action = 'get'
        else:
            isPlayable = False
            isFolder = True
            action = 'seasons'
        addTypename = True if type == 'all' and not function.startswith('collection') else False
        urlParams = {'action': action, 'id': str(e['id'])}
        o, media = createListItem(urlParams, params, e, addTypename, isPlayable=isPlayable)
        if sortByHD and 'hd' in media['resolutions']:
            order = 0
        else:
            order = 1
        items.append((order, i, urlParams, o, media, isFolder))

    for _, __, urlParams, o, media, isFolder in sorted(items):
        control.addItem(control.handle, control.getPluginUrl(urlParams), o, isFolder)

def addNextPage(params, **kwargs):
    params = dict(params)
    params.update(kwargs)
    params['page'] = int(params.get('page', 1)) + 1
    addDir('>>> Weiter', control.getPluginUrl(params))

def directory(params, sortByHD=True):
    function = params.pop('function', 'all')
    data = makeRequest(function, params=params, cache=1800)
    createDirectory(function, params.get('type', 'all'), params, data, sortByHD)
    if data and len(data) >= 50:
        addNextPage(params, action='directory', function=function)
    control.directory(control.handle, succeeded=True, cacheToDisc=True)

class search(object):
    db = None

    def __init__(self, params):
        history = self.getHistory()
        if 'query' in params:
            params['query'] = params['query']
            if params.get('exact') == 'true' and not params['query'].startswith('"'):
                params['query'] = '"' + params['query'] + '"'
            if params['query'] == '-':
                oKeyboard = xbmc.Keyboard(history[0] if history else '')
                oKeyboard.doModal()
                if not oKeyboard.isConfirmed():
                    self.index(history)
                    return
                params['query'] = oKeyboard.getText().strip()
                if not params['query']:
                    self.index(history)
                    return
                params['query'] = params['query']
            elif 'delete' in params:
                c = self.getDatabase().cursor()
                try:
                    try:
                        c.execute('DELETE FROM search_history WHERE query=?', [params['query']])
                        self.db.commit()
                    except Exception:
                        import traceback
                        traceback.print_exc()

                finally:
                    c.close()

                self.index(self.getHistory())
                return
            if params.get('history', 'true') == 'true':
                c = self.getDatabase().cursor()
                try:
                    try:
                        c.execute('REPLACE INTO search_history (query, t) VALUES (?, ?)', [
                         params['query'], int(time.time())])
                        self.db.commit()
                    except Exception:
                        import traceback
                        traceback.print_exc()

                finally:
                    c.close()

            params['function'] = 'all'
            params['query'] = params['query'].encode('utf-8')
            directory(params, sortByHD=False)
        else:
            self.index(history)

    def getDatabase(self):
        if not self.db:
            self.db = Database(filename='vjackson.db')
            c = self.db.cursor()
            try:
                try:
                    c.execute('CREATE TABLE IF NOT EXISTS search_history (query TEXT PRIMARY KEY, t INTEGER)')
                    self.db.commit()
                except Exception:
                    import traceback
                    traceback.print_exc()

            finally:
                c.close()

        return self.db

    def getHistory(self):
        c = self.getDatabase().cursor()
        result = []
        try:
            try:
                c.execute('SELECT query FROM search_history ORDER BY t DESC')
                for query, in c:
                    result.append(query)

                for query in result[MAX_SEARCH_HISTORY_ITEMS - 1:]:
                    c.execute('DELETE FROM search_history WHERE query=?', [query])

                self.db.commit()
            except Exception:
                import traceback
                traceback.print_exc()

        finally:
            c.close()

        return result

    def index(self, history):
        addDir2('Neue Suche', 'search', 'search', query='-')
        for query in history:
            url = control.getPluginUrl({'action': 'search', 'query': query.encode('utf-8')})
            liz = control.item(query)
            liz.setArt({'icon':'DefaultFolder.png', 'thumb':getIcon('query')})
            liz.setInfo(type='Video', infoLabels={'Title': query})
            ctx = [('Löschen', 'ActivateWindow(Videos,' + url + '&delete=1)')]
            liz.addContextMenuItems(ctx, False)
            control.addItem(control.handle, url, liz, isFolder=True)

        addDir2('Einstellungen', 'settings', 'settings')
        control.directory(control.handle, succeeded=True, cacheToDisc=False)

def tag(params):
    #xbmcplugin.setContent(control.handle, 'seasons')
    data = makeRequest('tags', params, addLanguage=False, add_locale=False, addHosters=False, addResolution=False, cache=10800)
    urlParams = {'action': 'directory', 'function': 'all', 'type': params.pop('type', 'all'), 'genre': params.pop('genre', '')}
    for i in sorted(data):
        icon = None
        o = control.item(i)
        #o.setArt({'icon':icon, 'thumb':icon})
        urlParams2 = dict(urlParams)
        urlParams2[params['category']] = i
        control.addItem(control.handle, control.getPluginUrl(urlParams2), o, isFolder=True)
    control.directory(control.handle, succeeded=True, cacheToDisc=True)

def getParamsLanguage(params, forceDialog=False):
    languages = params.pop('languages').split(',')
    if len(languages) == 1 and not forceDialog:
        params['language'] = languages[0]
    else:
        locale = getLocale(params)
        captions = [ LANGUAGE_NAMES[locale][lang] for lang in languages ]
        index = control.dialog.select('Sprache wählen', captions)
        if index < 0:
            return
        for key, value in LANGUAGE_NAMES[locale].items():
            if value == captions[index]:
                params['language'] = key
                break
        else:
            raise ValueError('Could not find language %s' % captions[index])

def seasons(params):
    id = int(params['id'])
    getParamsLanguage(params)
    data = makeRequest('get', params, cache=300)
    if len(data['seasons']) == 1:
        params['season'] = list(data['seasons'].keys())[0]
        episodes(params)
        return
    #xbmcplugin.setContent(control.handle, 'seasons')
    urlParams = {'action': 'episodes', 'id': str(id), 'language': params['language']}
    for i in sorted(map(int, list(data['seasons'].keys()))):
        params['season'] = str(i)
        urlParams['season'] = str(i)
        o, media = createListItem(urlParams, params, data)
        o.setLabel('Season ' + str(i))
        control.addItem(control.handle, control.getPluginUrl(urlParams), o, isFolder=True)
    control.directory(control.handle, succeeded=True, cacheToDisc=True)

def episodes(params):
    if 'language' not in params:
        getParamsLanguage(params)
    #xbmcplugin.setContent(control.handle, 'episodes')
    id = int(params['id'])
    season = int(params.pop('season'))
    data = makeRequest('get', params, cache=300)
    seasons = {int(k):v for k, v in data['seasons'].items()}
    urlParams = {'action': 'get', 'id': str(id), 'language': params['language']}
    selected = None
    for i in sorted(map(int, seasons[season]['episodes'])):
        params['season'] = str(season)
        params['episode'] = str(i)
        urlParams['season'] = str(season)
        urlParams['episode'] = str(i)
        o, media = createListItem(urlParams, params, data, isPlayable=True)
        o.setLabel('Season ' + str(season) + ' Episode ' + str(i))
        if params.get('activateEpisode') == params['episode']:
            o.select(True)
            selected = o
        control.addItem(control.handle, control.getPluginUrl(urlParams), o, isFolder=False)

    if selected:
        selected.select(True)
    control.directory(control.handle, succeeded=True, cacheToDisc=True)

def collectionEpisodes(params):
    #xbmcplugin.setContent(control.handle, 'episodes')
    result = makeRequest('collection/episodes', params)
    setLanguage = getLanguage(params)
    for data in result:
        params['season'] = data['episode']['season']
        params['episode'] = data['episode']['episode']
        if setLanguage == 'all':
            languages = (',').join(data['media']['languages'])
        else:
            languages = setLanguage
        urlParams = {'action': 'episodes', 
           'id': str(data['id']), 
           'languages': languages, 
           'season': str(params['season']), 
           'activateEpisode': str(params['episode'])}
        o, media = createListItem(urlParams, params, data)
        control.addItem(control.handle, control.getPluginUrl(urlParams), o, isFolder=True)
    control.directory(control.handle, succeeded=True, cacheToDisc=True)

RESOLUTION_GROUPS = {'hd': 'HD', 'original': 'Original', 'sd': ''}
RESOLUTION_PRIORITIES = ['hd','original','sd']
KODI_LANGUAGE_TRANSLATION = {'': 'none', 'ger': 'de', 'eng': 'en'}

class Player(xbmc.Player):
    pass

class get(object):

    def __init__(self, params):
        self.params = params
        self.selectedParts = {}
        self.db = None
        self.mirrorsTried = 0
        try:
            self.run()
        except Exception:
            import traceback
            traceback.print_exc()
            raise

        return

    def getDatabase(self):
        if not self.db:
            self.db = Database(filename='vjackson.db')
            c = self.db.cursor()
            try:
                try:
                    c.execute('CREATE TABLE IF NOT EXISTS hoster_weights (hoster TEXT, t INTEGER)')
                    self.db.commit()
                except Exception:
                    import traceback
                    traceback.print_exc()

            finally:
                c.close()

        return self.db

    def getHosterWeights(self):
        weights = {}
        c = self.getDatabase().cursor()
        try:
            try:
                c.execute('DELETE FROM hoster_weights WHERE t<?', [int(time.time()) - 604800])
                c.execute('SELECT hoster, COUNT(*) FROM hoster_weights')
                self.getDatabase().commit()
                for hoster, weight in c:
                    if hoster:
                        weights[hoster] = weight

            except Exception:
                import traceback
                traceback.print_exc()

        finally:
            c.close()

        return weights

    def getStreamSelect(self):
        return getStreamSelect()

    def setSuccessfulConnection(self, hoster):
        c = self.getDatabase().cursor()
        try:
            try:
                c.execute('INSERT INTO hoster_weights (hoster, t) VALUES (?, ?)', [hoster, int(time.time())])
                self.getDatabase().commit()
            except Exception:
                import traceback
                traceback.print_exc()

        finally:
            c.close()

    def setVideoDetails(self, mirror, link, url):
        data = {'url': url, 
           'resolution': str(xbmc.getInfoLabel('VideoPlayer.VideoResolution')) + 'p', 
           'language': KODI_LANGUAGE_TRANSLATION.get(xbmc.getInfoLabel('VideoPlayer.AudioLanguage'), ''), 
           'subtitles': KODI_LANGUAGE_TRANSLATION.get(xbmc.getInfoLabel('VideoPlayer.SubtitlesLanguage'), '')}
        makeBackgroundRequest('link/info', data, cache=None)
        return

    def init(self):
        self.player = Player()
        self.player.stop()
        if not self.params.get('language'):
            getParamsLanguage(self.params)
        self.data = makeRequest('get', self.params, cache=300)
        return False

    def allowMultiparts(self):
        return True

    def run(self):
        if self.init():
            return
        else:
            self.mirrors = self.data['get']['links']
            weights = self.getHosterWeights()
            SUPERWEIGHTS = {'clipboard.cc': 5, 
               'kinoger.com': 4, 
               'openload.co': 3, 
               'streamango.com': 2, 
               'streamcloud.eu': 1}
            self.groups = []
            groupsById = {}
            for i, mirror in enumerate(self.mirrors):
                if not self.allowMultiparts() and mirror['parts'] > 1:
                    continue
                resolution = RESOLUTION_GROUPS.get(mirror['resolution'], mirror['resolution'])
                mirror['caption'] = HOSTER_ALIASES.get(mirror['hoster'], mirror['hoster'])
                mirror['attrs'] = []
                if resolution:
                    mirror['attrs'].append(resolution)
                if mirror['parts'] > 1:
                    mirror['attrs'].append(str(mirror['parts']) + ' Parts')
                if mirror['attrs']:
                    mirror['caption'] += ' (%s)' % (', ').join(mirror['attrs'])
                mirror['weight'] = SUPERWEIGHTS.get(mirror['hoster'], 0) * 10000000 + mirror['quality'] * 10000 + weights.get(mirror['hoster'], 0) * 1
                log('WEIGHT = %s /// %s %s %s /// %s %s' % (
                 mirror['weight'],
                 mirror['quality'],
                 SUPERWEIGHTS.get(mirror['hoster'], 0),
                 weights.get(mirror['hoster'], 0),
                 mirror['hoster'], mirror['resolution']))
                id = '%s-%s' % (resolution, mirror['parts'])
                mirror['groupId'] = id
                if id not in groupsById:
                    attrs = []
                    attrs.append(resolution or 'Stream')
                    if mirror['parts'] > 1:
                        attrs.append(str(mirror['parts']) + ' Parts')
                    group = {'caption': (', ').join(attrs), 'mirrors': []}
                    try:
                        priority = RESOLUTION_PRIORITIES.index(resolution.lower())
                    except ValueError:
                        priority = 999

                    group['priority'] = '%02i-%03i-%03i' % (mirror['parts'], priority, i)
                    self.groups.append(group)
                    groupsById[id] = group
                groupsById[id]['mirrors'].append(mirror)

            self.mirrors = []
            self.groups = list(sorted(self.groups, key=lambda x: x['priority']))
            for group in self.groups:
                n = len(group['mirrors'])
                if n == 1:
                    group['caption'] += ' (%s Mirror)' % n
                else:
                    group['caption'] += ' (%s Mirrors)' % n
                group['mirrors'] = list(sorted(group['mirrors'], key=lambda m: -m['weight']))
                self.mirrors.extend(group['mirrors'])

            getHosters(self.params)
            self.streamSelect = self.getStreamSelect()
            if self.streamSelect == 'grouped':
                heading = 'Qualität wählen'
                captions = [ mirror['caption'] for mirror in self.groups ]
            elif self.streamSelect == 'hosters':
                heading = 'Hoster wählen'
                captions = [ mirror['caption'] for mirror in self.mirrors ]
            elif self.streamSelect == 'hosters2':
                heading = 'Hoster wählen'
                captions = []
                for i, mirror in enumerate(self.mirrors):
                    attrs = [
                     HOSTER_ALIASES_SHORT.get(mirror['hoster'], mirror['hoster'])]
                    attrs += mirror['attrs']
                    mirror['caption'] = 'Mirror %s (%s)' % (i + 1, (', ').join(attrs))
                    mirror['short_caption'] = 'Mirror %s (%s)' % (i + 1, HOSTER_ALIASES_SHORT.get(mirror['hoster'], mirror['hoster']))
                    captions.append(mirror['caption'])

            elif self.streamSelect != 'auto':
                raise RuntimeError('Invalid value for streamSelect: %s' % self.streamSelect)
            if self.streamSelect != 'auto':
                index = control.dialog.select(heading, captions)
                if index < 0:
                    return
            else:
                index = 0
            if self.streamSelect == 'grouped':
                self.mirrors = self.groups[index]['mirrors']
            elif self.streamSelect == 'hosters':
                mirror = self.mirrors[index]
                group = groupsById[mirror['groupId']]
                self.mirrors = group['mirrors'][group['mirrors'].index(mirror):]
            elif self.streamSelect == 'hosters2':
                self.mirrors = self.mirrors[index:]
            if self.streamSelect in ('hosters', 'hosters2') and not control.getSettingBool('auto_try_next_stream'):
                self.mirrors = [
                 self.mirrors[0]]
            from urlresolver import load_external_plugins
            from urlresolver.resolver import ResolverError
            load_external_plugins()

            def getmod(name):
                for rn in (name, 'urlresolver.' + name, 'urlresolver.plugins.' + name):
                    try:
                        return sys.modules[rn]
                    except Exception:
                        pass

            if False and 'smoozed' in sys.modules:
                r = getmod('smoozed').SmoozedResolver
                if not hasattr(r, '_isPatched'):
                    r._isPatched = True


                class Dummy:

                    @classmethod
                    def get_setting(cls, key):
                        if key == 'enabled':
                            return 'true'
                        return '1'

                def get_media_url(self, *args, **kwargs):
                    try:
                        return self._old_get_media_url(*args, **kwargs)
                    except HTTPError as e:
                        raise ResolverError('Resolve failed: %s' % e)
                    except Exception:
                        raise

                ignore_hosters = ('streamcloud', 'nowvideo', 'openload', 'streamango',
                                  'streamcherry', 'flashx')

                def valid_url(self, url, host):
                    if self._old_valid_url(url, host):
                        if any(x in host for x in ignore_hosters):
                            return False
                        if any(x in url for x in ignore_hosters):
                            return False
                        return True
                    return False

                def get_all_hosters(self, *args, **kwargs):
                    try:
                        content = control.getcache("plugin.video.vavooto.smhoster")
                        if content:
                            return list(map(re.compile, json.loads(content)))
                        content = self._old_get_all_hosters(*args, **kwargs)
                        control.setcache("plugin.video.vavooto.smhoster", json.dumps([x.pattern for x in content]), expiration=datetime.timedelta(seconds=1800))
                        return content
                    except Exception:
                        raise

                def get_hosts(self, *args, **kwargs):
                    try:
                        return self._old_get_hosts(*args, **kwargs)
                    except Exception:
                        raise

                r.get_setting = Dummy.get_setting
                r._old_get_media_url = r.get_media_url
                r._old_valid_url = r.valid_url
                r._old_get_all_hosters = r.get_all_hosters
                r._old_get_hosts = r.get_hosts
                r.get_media_url = get_media_url
                r.valid_url = valid_url
                r.get_all_hosters = get_all_hosters
                r.get_hosts = get_hosts

            def rb2_get_media_url(self, host, media_id):
                if 'WEBSOCKET_CLIENT_CA_BUNDLE' not in os.environ:
                    from requests import certs
                    os.environ['WEBSOCKET_CLIENT_CA_BUNDLE'] = certs.where()
                from urlresolver.plugins.lib.helpers import pick_source
                opts = '|' + ('&').join([ key + '=' + quote(value) for key, value in result['headers'].items() ])
                return pick_source([ (x.get('quality', ''), x['url'] + opts) for x in result['urls'] ])

            def rb2_patch(name, classname):
                if name in sys.modules:
                    r = getattr(getmod(name), classname)
                    if not hasattr(r, '_isPatched'):
                        r._isPatched = True
                        r.get_media_url = rb2_get_media_url

            if False and 'openload' in sys.modules:
                r = sys.modules['openload'].OpenLoadResolver
                if not hasattr(r, '_isPatched'):
                    r._isPatched = True

                    def new_get_media_url(self, host, media_id):
                        import requests
                        session = requests.session()
                        t = session.get('https://api.openload.co/1/file/dlticket', params={'file': media_id, 'login': 'c255c81fad52a08f', 'key': 'lc7xiQ46'}).json()['result']['ticket']
                        return session.get('https://api.openload.co/1/file/dl', params={'file': media_id, 'ticket': t}).json()['result']['url']

                    r.get_media_url = new_get_media_url
            rb2_patch('streamcherry', 'StreamcherryResolver')
            rb2_patch('streamango', 'StreamangoResolver')
            rb2_patch('openload', 'OpenLoadResolver')
            self.initProgress()
            try:
                try:
                    self.findMirror()
                except ValueError:
                    return
            finally:
                if self.progress is not None:
                    self.progress.close()
                    self.progress = None

            return

    def showFailedNotification(self):
        control.execute('Notification(%s,%s,%s,%s)' % (
         'VAVOO.TO',
         'Beim aufrufen des Streams ist ein Fehler aufgetreten',
         5000,
         control.addonInfo('icon')))

    def initProgress(self):
        self.progress = control.progressDialog
        self.progress.create('VAVOO.TO', 'Der Stream wird gestartet...')

    def checkCanceled(self):
        if self.progress.iscanceled():
            raise ValueError('CANCELED')

    def getMirrorPart(self, mirror, link):
        availableParts = tuple(sorted(map(int, list(link.get('parts', "").keys()))))
        if len(availableParts) > 1:
            captions = []
            parts = []
            urls = []
            for p, url in sorted([(
             int(x[0]), x[1]) for x in list(link['parts'].items())]):
                captions.append('Part %s' % p)
                parts.append(p)
                urls.append(url)

            partIndex = self.selectedParts.get(availableParts, None)
            if partIndex is None:
                partIndex = control.dialog.select('Part für einen %s-teiligen Mirror wählen' % mirror['parts'], captions)
                if partIndex < 0:
                    raise ValueError('CANCELED')
                self.selectedParts[availableParts] = partIndex
        else:
            parts = list(link['parts'].keys())
            urls = list(link['parts'].values())
            partIndex = 0
        try:
            part = parts[partIndex]
            url = urls[partIndex]
        except Exception:
            part = None
            url = None

        return (part, url)

    def setMirrorProgress(self, step, *args, **kwargs):
        STEPS_PER_MIRROR = 5
        current = step
        total = STEPS_PER_MIRROR
        self.progress.update(int(current * (100.0 / total)), *args, **kwargs)
        self.checkCanceled()

    def findMirror(self):
        global mirr
        for self.mirrorIndex, mirror in enumerate(self.mirrors):
            if self.mirrorIndex == 0:
                mirr = mirror.get('short_caption', mirror['caption'])
                lines = ('Die Wiedergabe wird gestartet mit :'+mirr)
            else:
                lines = ('%s fehlgeschlagen' % mirr + '\nVersuche %s...' % mirror.get('short_caption', mirror['caption']))
            self.setMirrorProgress(0, lines)
            params = dict(self.params)
            params.update(mirror)
            link = makeRequest('link', params, cache=None)
            self.setMirrorProgress(1)
            if not link:
                log('Empty link returned')
                continue
            try:part, url = self.getMirrorPart(mirror, link)
            except:pass
            self.checkCanceled()
            if url is None:
                continue
            url = url.replace('https://nullrefer.com/?', '')
            resolvedUrl = self.resolveUrl(mirror, link, url)
            if not resolvedUrl:
                continue
            self.setMirrorProgress(2)
            if self.tryMirror(mirror, link, part, url, resolvedUrl):
                return

        raise ValueError('FAILED')
        return

    def resolveUrl(self, mirror, link, url):
        log('Resolving URL: %s' % url)
        cacheKey = url
        originalUrl = url
        if mirror['hoster'] in URLRESOLVER_SET_QUALITY:
            key = '%s_quality' % URLRESOLVER_SET_QUALITY[mirror['hoster']]
            value = control.getSetting('playback_resolution')
            cacheKey += '///' + value
            if control.getSetting(key, 'script.module.urlresolver') != value:
                control.setSetting(key, value, 'script.module.urlresolver')
        cachedUrl = None
        if cachedUrl:
            log('Got resolved URL from cache: %s' % cachedUrl)
            return cachedUrl
        else:
            url = self.resolveUrl1(link, originalUrl)
            if url:
                control.setcache("plugin.video.vavooto."+cacheKey, url, expiration=datetime.timedelta(seconds=300))
                return url
            if url is False:
                log('Reporting not working URL: %s' % url)
                makeBackgroundRequest('link/offline', {'url': originalUrl}, cache=None)
            return

    def resolveUrl1(self, link, url):
        log('Resolving URL 1: %s' % url)
        try:
            from urlresolver import resolve
            from urlresolver.resolver import ResolverError
            return resolve(url)
        except ResolverError:
            import traceback
            traceback.print_exc()
            return
        except Exception as e:
            import traceback
            traceback.print_exc()
            return

        return

    def tryMirror(self, mirror, link, part, url, resolvedUrl):
        log('Trying resolved URL: %s' % resolvedUrl)
        try:
            if '|' not in resolvedUrl:
                resolvedUrl += '|'
            if '&User-Agent' not in resolvedUrl:
                resolvedUrl += '&User-Agent=' + quote('Mozilla/5.0 (Windows; U; Windows NT 5.1; de-DE; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
            resolvedUrl += '&VAVOOTOREPORT=' + quote('?' + control.convertPluginParams({'id': self.data['id'], 
               'type': self.data['type'], 
               'language': self.params['language'], 
               'season': str(self.params.get('season', -1)), 
               'episode': str(self.params.get('episode', -1)), 
               'part': part, 
               'url': url}))
            if mirror['parts'] > 1:
                resolvedUrl += '&VAVOOTOMULTIPART'
            o, media = createListItem(self.params, self.params, self.data, isPlayable=True)
            o.setPath(resolvedUrl)
            self.player.play(resolvedUrl, o)
            self.mirrorsTried += 1

            def infostr():
                try:
                    return 'step=%s, playing=%s, time=%s URL: %s' % (
                     step, self.player.isPlaying(),
                     self.player.isPlaying() and self.player.getTime(),
                     urlparse(resolvedUrl).netloc)
                except RuntimeError as e:
                    return

            step = 1
            STEP_TIMEOUT = 45
            abortReason = ''
            t = time.time()
            try:
                sleep = 10
                while not abortReason:
                    log('Player running: %s' % infostr())
                    if self.progress and self.progress.iscanceled():
                        abortReason = 'canceled'
                    elif step == 1:
                        if self.player.isPlaying():
                            self.setMirrorProgress(3)
                            step = 2
                        elif time.time() - t > STEP_TIMEOUT:
                            abortReason = 'timeout'
                    elif step == 2:
                        if xbmc.getInfoLabel('VideoPlayer.VideoResolution'):
                            self.setMirrorProgress(3, 'Viel Spaß mit VAVOO!')
                            self.player.stop()
                            sleep = 100
                            step = 3
                        elif not self.player.isPlaying():
                            abortReason = 'died'
                    elif step == 3:
                        if not self.player.isPlaying():
                            control.setResolvedUrl(control.handle, True, o)
                            t = time.time()
                            step = 4
                    elif step == 4:
                        if self.player.isPlaying():
                            self.setMirrorProgress(4)
                            step = 5
                        elif time.time() - t > STEP_TIMEOUT:
                            abortReason = 'timeout'
                    elif step == 5:
                        if not self.player.isPlaying():
                            abortReason = 'stopped'
                        elif self.player.getTime() > 0.0:
                            resolution = xbmc.getInfoLabel('VideoPlayer.VideoResolution')
                            if resolution:
                                self.setVideoDetails(mirror, link, url)
                                self.setSuccessfulConnection(mirror['hoster'])
                                if self.progress is not None:
                                    self.progress.close()
                                    self.progress = None
                                sleep = 1000
                                step = 6
                    elif step == 6:
                        if not self.player.isPlaying():
                            abortReason = 'stopped'
                    else:
                        raise RuntimeError('Unknow step: %r' % step)
                    if not abortReason:
                        xbmc.sleep(sleep)

                log('Player stopped: reason=%s, %s' % (abortReason, infostr()))
            finally:
                self.player.stop()

            if abortReason in ('canceled', 'stopped'):
                return True
            if step >= 4:
                raise RuntimeError('Stream died! reason=%s, %s' % (abortReason, infostr()))
            return False
        except Exception as e:
            traceback.print_exc()
            return False

        return

def addDir(name, url, iconimage='DefaultFolder.png', isFolder=True, isPlayable=False):
    liz = control.item(name)
    liz.setArt({'icon':iconimage, 'thumb':iconimage})
    liz.setInfo(type='Video', infoLabels={'Title': name})
    if isPlayable:
        liz.setProperty('IsPlayable', 'true')
    control.addItem(control.handle, url, liz, isFolder=isFolder)

def addDir2(name_, icon_, action, **params):
    params['action'] = action
    addDir(name_, control.getPluginUrl(params), getIcon(icon_))

def getIcon(name):
    return control.transPath('special://home/addons/plugin.video.vavooto/resources/' + name + '.png')

SESSION = None

def getSession():
    if SESSION is None:
        import requests
        globals()['SESSION'] = requests.session()
    return SESSION

def makeBackgroundRequest(*args, **kwargs):

    class Thread(threading.Thread):

        def run(self):
            makeRequest(*args, **kwargs)

    Thread().start()

def makeRequest(*args, **kwargs):
    data = _makeRequest(*args, **kwargs)
    return data

def getAuthSignature():
	vec = {"vec": "9frjpxPjxSNilxJPCJ0XGYs6scej3dW/h/VWlnKUiLSG8IP7mfyDU7NirOlld+VtCKGj03XjetfliDMhIev7wcARo+YTU8KPFuVQP9E2DVXzY2BFo1NhE6qEmPfNDnm74eyl/7iFJ0EETm6XbYyz8IKBkAqPN/Spp3PZ2ulKg3QBSDxcVN4R5zRn7OsgLJ2CNTuWkd/h451lDCp+TtTuvnAEhcQckdsydFhTZCK5IiWrrTIC/d4qDXEd+GtOP4hPdoIuCaNzYfX3lLCwFENC6RZoTBYLrcKVVgbqyQZ7DnLqfLqvf3z0FVUWx9H21liGFpByzdnoxyFkue3NzrFtkRL37xkx9ITucepSYKzUVEfyBh+/3mtzKY26VIRkJFkpf8KVcCRNrTRQn47Wuq4gC7sSwT7eHCAydKSACcUMMdpPSvbvfOmIqeBNA83osX8FPFYUMZsjvYNEE3arbFiGsQlggBKgg1V3oN+5ni3Vjc5InHg/xv476LHDFnNdAJx448ph3DoAiJjr2g4ZTNynfSxdzA68qSuJY8UjyzgDjG0RIMv2h7DlQNjkAXv4k1BrPpfOiOqH67yIarNmkPIwrIV+W9TTV/yRyE1LEgOr4DK8uW2AUtHOPA2gn6P5sgFyi68w55MZBPepddfYTQ+E1N6R/hWnMYPt/i0xSUeMPekX47iucfpFBEv9Uh9zdGiEB+0P3LVMP+q+pbBU4o1NkKyY1V8wH1Wilr0a+q87kEnQ1LWYMMBhaP9yFseGSbYwdeLsX9uR1uPaN+u4woO2g8sw9Y5ze5XMgOVpFCZaut02I5k0U4WPyN5adQjG8sAzxsI3KsV04DEVymj224iqg2Lzz53Xz9yEy+7/85ILQpJ6llCyqpHLFyHq/kJxYPhDUF755WaHJEaFRPxUqbparNX+mCE9Xzy7Q/KTgAPiRS41FHXXv+7XSPp4cy9jli0BVnYf13Xsp28OGs/D8Nl3NgEn3/eUcMN80JRdsOrV62fnBVMBNf36+LbISdvsFAFr0xyuPGmlIETcFyxJkrGZnhHAxwzsvZ+Uwf8lffBfZFPRrNv+tgeeLpatVcHLHZGeTgWWml6tIHwWUqv2TVJeMkAEL5PPS4Gtbscau5HM+FEjtGS+KClfX1CNKvgYJl7mLDEf5ZYQv5kHaoQ6RcPaR6vUNn02zpq5/X3EPIgUKF0r/0ctmoT84B2J1BKfCbctdFY9br7JSJ6DvUxyde68jB+Il6qNcQwTFj4cNErk4x719Y42NoAnnQYC2/qfL/gAhJl8TKMvBt3Bno+va8ve8E0z8yEuMLUqe8OXLce6nCa+L5LYK1aBdb60BYbMeWk1qmG6Nk9OnYLhzDyrd9iHDd7X95OM6X5wiMVZRn5ebw4askTTc50xmrg4eic2U1w1JpSEjdH/u/hXrWKSMWAxaj34uQnMuWxPZEXoVxzGyuUbroXRfkhzpqmqqqOcypjsWPdq5BOUGL/Riwjm6yMI0x9kbO8+VoQ6RYfjAbxNriZ1cQ+AW1fqEgnRWXmjt4Z1M0ygUBi8w71bDML1YG6UHeC2cJ2CCCxSrfycKQhpSdI1QIuwd2eyIpd4LgwrMiY3xNWreAF+qobNxvE7ypKTISNrz0iYIhU0aKNlcGwYd0FXIRfKVBzSBe4MRK2pGLDNO6ytoHxvJweZ8h1XG8RWc4aB5gTnB7Tjiqym4b64lRdj1DPHJnzD4aqRixpXhzYzWVDN2kONCR5i2quYbnVFN4sSfLiKeOwKX4JdmzpYixNZXjLkG14seS6KR0Wl8Itp5IMIWFpnNokjRH76RYRZAcx0jP0V5/GfNNTi5QsEU98en0SiXHQGXnROiHpRUDXTl8FmJORjwXc0AjrEMuQ2FDJDmAIlKUSLhjbIiKw3iaqp5TVyXuz0ZMYBhnqhcwqULqtFSuIKpaW8FgF8QJfP2frADf4kKZG1bQ99MrRrb2A="}
	url = 'https://www.vavoo.tv/api/box/ping2'
	req = requests.post(url, data=vec).json()
	return req['response'].get('signed')

def _makeRequest(function, params, data=None, files=None, addLanguage=True, add_locale=True, addHosters=True, addResolution=True, cache=1800):
    t = time.time()
    params = dict(params)
    params.pop('action', None)
    if addLanguage:
        params['language'] = getLanguage(params)
    if add_locale and 'locale' not in params:
        params['locale'] = getLocale(params)
    if addHosters and 'hosters' not in params:
        params['hosters'] = getHosters(params)
    if addResolution and 'resolution' not in params:
        params['resolutions'] = getResolution(params)
    params['vavoo_auth'] = getAuthSignature()
    cacheKey = function + '?' + ('&').join([ str(key) + '=' + str(value) for key, value in sorted(params.items()) ])
    contentcache = control.getcache("plugin.video.vavooto."+cacheKey)
    if contentcache:
    	content = contentcache
    elif data is None and files is None:
        response = getSession().get(BASEURL + function, params=params)
        content = response.json()
        if cache and response.status_code in (200, 201, 301, 302):
        	control.setcache("plugin.video.vavooto."+cacheKey, content, expiration=datetime.timedelta(seconds=cache))
    else:
        response = getSession().post(BASEURL + function, params=params, data=data, files=files)
        content = response.json()
        if cache and response.status_code in (200, 201, 301, 302):
        	control.setcache("plugin.video.vavooto."+cacheKey, content, expiration=datetime.timedelta(seconds=cache))
    return content

def main():
		params = dict(parse_qsl(argv[2].replace('?','')))
		action = params.get('action', '')
		tv = params.get('name', '')
		if not params:
			index(params)
		elif tv and not action:
			livePlay(params['name'])
		elif action == 'trailer':
			import trailer
			trailer.play(params.get('name'), params.get('url'))
		elif action == 'renew':
			kanal.main(new=True)
		elif action == 'choose':
			kanal.choose()
		elif action == 'settings':
			control.openSetting(params.get('id', ''))
		else:
			globals()[params['action']](params)