# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
icon_xrysoi = 'https://xrysoi.pro/wp-content/uploads/2015/03/logo-GM.png'

Baseurl = 'https://xrysoi.pro/'

def menu():
    addDir('[COLOR white]Ανά έτος[/COLOR]', '', 52, icon_xrysoi, FANART, '')
    addDir('[COLOR white]Κατηγορίες[/COLOR]', '', 51, icon_xrysoi, FANART, '')
    addDir('[COLOR white]Ξένες Σειρές[/COLOR]', Baseurl + '?s=series', 53, icon_xrysoi, FANART, '')
    addDir('[COLOR white]Πρόσφατες καταχωρήσεις[/COLOR]', Baseurl + 'category/tainiesonline/2022/', 44, icon_xrysoi, FANART, '')
    addDir('[COLOR white]Με ελληνικούς υπότιτλους[/COLOR]', Baseurl + 'category/category/1greeksubs/', 44, icon_xrysoi, FANART, '')
    addDir('[COLOR white]Αναζήτηση ...[/COLOR]', '', 45, icon_xrysoi, FANART, '')
#    views.selectView('menu', 'menu-view')

def menu_genre(): #51
    addDir('[COLOR white]Western[/COLOR]', Baseurl + 'category/category/western/', 44, icon_xrysoi, FANART, '')
    addDir('[COLOR white]Collection[/COLOR]', Baseurl + 'category/category/collection/', 44, icon_xrysoi, FANART, '')
    addDir('[COLOR white]Tainiesonline[/COLOR]', Baseurl + 'category/category/tainiesonline/', 44, icon_xrysoi, FANART, '')
    addDir('[COLOR white]Χριστουγεννιάτικες[/COLOR]', Baseurl + 'category/category/x-mas/', 44, icon_xrysoi, FANART, '')
    addDir('[COLOR white]Bollywood[/COLOR]', Baseurl + 'category/category/bollywood/', 44, icon_xrysoi, FANART, '')
    addDir('[COLOR white]Anime[/COLOR]', Baseurl + 'category/category/anime/', 44, icon_xrysoi, FANART, '')
    addDir('[COLOR white]Animemovies[/COLOR]', Baseurl + 'category/category/animemovies/', 44, icon_xrysoi, FANART, '')
#    views.selectView('menu', 'menu-view')


def menu_year(): #52
    addDir('[COLOR white]2022[/COLOR]', Baseurl + 'category/tainiesonline/2022/', 44, icon_xrysoi, FANART, '')
    addDir('[COLOR white]2021[/COLOR]', Baseurl + 'category/tainiesonline/2021/', 44, icon_xrysoi, FANART, '')
    addDir('[COLOR white]2020[/COLOR]', Baseurl + 'category/tainiesonline/2020/', 44, icon_xrysoi, FANART, '')
    addDir('[COLOR white]2019[/COLOR]', Baseurl + 'category/tainiesonline/2019/', 44, icon_xrysoi, FANART, '')
    addDir('[COLOR white]2018[/COLOR]', Baseurl + 'category/tainiesonline/2018/', 44, icon_xrysoi, FANART, '')
    addDir('[COLOR white]2017[/COLOR]', Baseurl + 'category/tainiesonline/2017/', 44, icon_xrysoi, FANART, '')
    addDir('[COLOR white]2016[/COLOR]', Baseurl + 'category/tainiesonline/2016/', 44, icon_xrysoi, FANART, '')
    addDir('[COLOR white]2013-2015[/COLOR]', Baseurl + 'category/tainiesonline/new-good/', 44, icon_xrysoi, FANART, '')
#    views.selectView('menu', 'menu-view')


def xrysoimovies(url): #44
    p = client.request(url)
    try:
        m = re.compile('<div class=moviefilm>.+?<a href=(.+?)>.+?<img src=(.+?) alt="(.+?)".+?title=', re.DOTALL).findall(p)
    except IndexError:
        m = re.compile('<div class="moviefilm">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)".+?title=', re.DOTALL).findall(p)
    for url, icon, name in m:
        name = name.replace('-)',')')
        name = name.split('&#038;')[0].split('&#8217;')[0].split('&#8211;')[0]
        icon = icon.replace('-119x125', '')
        addDir(' [B][COLOR white]%s[/COLOR][/B]' % name, url, 43, icon, FANART, '')
    try:
        m = re.compile('class=nextpostslink rel=next href=(.+?)>»</a>').findall(p)[0]
        addDir(' [B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 44, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
    views.selectView('movies', 'movie-view')


def xrysoimovies_search(url): #53
    p = client.request(url)
    try:
        m = re.compile('<div class=moviefilm>.+?<a href=(.+?)>.+?<img src=(.+?) alt="(.+?)".+?title=', re.DOTALL).findall(p)
    except IndexError:
        m = re.compile('<div class="moviefilm">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)".+?title=', re.DOTALL).findall(p)
    for url, icon, name in m:
        name = name.replace('-)',')')
        name = name.split('&#038;')[0].split('&#8217;')[0].split('&#8211;')[0]
        icon = icon.replace('-119x125', '')
        addDir(' [B][COLOR white]%s[/COLOR][/B]' % name, url, 43, icon, FANART, '')
    try:
        m = re.compile('class=nextpostslink rel=next href="(.+?)">»</a>').findall(p)[0]
        addDir(' [B][COLOR=lime]Επόμενη σελίδα [COLOR=white]>>[/COLOR][/B]', m, 53, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
    views.selectView('movies', 'movie-view')


def get_links(name, url, iconimage, description): #45
    p = client.request(url)
    m = re.compile('href=(.+?)\s+').findall(p)
    link_list = ['aparat', 'flashx', 'hdvid', 'vidd',
                 'vidoza', 'vidlox', 'estream', 'clipwatching', 'thevideo', 'vidzi']
    for url in m:
        if any(x in url for x in link_list):
            name = url
            name = name.split('.')[0]
            name = name.replace('http://', '[B]Πάροχος...[/B]')
            name = name.replace('https://', '[B]Πάροχος...[/B]')
            addDir(name, url, 100, iconimage, FANART, str(description))
    else:
        m2 = re.compile('<iframe.+?src=(.+?)\s+').findall(p)
        for url in m2:
            if 'youtube' in url:
                Trailer = '[COLOR=lime]Τρέιλερ[/COLOR]'
                addDir(Trailer, url, 100, iconimage, FANART, str(description))


def search(url):
    keyb = xbmc.Keyboard('', 'Search')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = 'https://xrysoi.pro/?s=' + search
        xrysoimovies_search(url)

def xrysoiseries(url): #49
    p = requests.get(url)
    try:
        m = re.compile('<div class=moviefilm>.+?<a href=(.+?)>.+?<img src=(.+?) alt="(.+?)".+?title=', re.DOTALL).findall(p)
    except IndexError:
        m = re.compile('<div class="moviefilm">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)".+?title=',
                       re.DOTALL).findall(p)
    for url, icon, name in m:
        if '-)' in name:
            name = name.replace('-)',')')
            name = name.split('&#038;')[0]
            name = name.split('&#8217;')[0]
            name = name.split('&#8211;')[0]
            icon = icon.replace('-119x125','')
            addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 48, icon, FANART, '')
    try:
        np=re.compile('a class=nextpostslink rel=next href=(.+?)>»</a>').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', np, 49, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except:
        pass
    views.selectView('movies', 'movie-view')

def get_hdvids(url): #48
    c = 'Επεισόδιο..'
    p = client.request(url)
    m =re.compile('<a href=(.+?)>(.+?)</a>',re.DOTALL).findall(p)
    for url,name in m:
        if 'hdvid.tv' in url:
            c = 'Επεισόδιο...'

#            openn.addDir('[B][COLOR gold] %s[/COLOR][/B][B][COLOR blue]%s[/COLOR][/B]'%(c,name),url,200,addon.icon,addon.art,'')
            addDir('[B][COLOR gold] %s[/COLOR][/B][B][COLOR blue]%s[/COLOR][/B]'%(c,name), url, 100, icon, FANART,'')

def search_series(): #50
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = 'https://xrysoi.pro/?s=' + search
                xrysoiseries(url)
