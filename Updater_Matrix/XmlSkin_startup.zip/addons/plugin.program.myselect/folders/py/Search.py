import xbmc, xbmcgui
xbmcgui.Dialog().notification("[B][COLOR orange]Σε περίπτωση [B]Σφάλματος...[/COLOR][/B]", "[COLOR grey]Κάντε πρώτα μια αναζήτηση μέσα απο το Πρόσθετο που σας ενδιαφέρει.[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/Search.png')

def search():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Search[/COLOR][/B]', 
['[B][COLOR=white]Search [COLOR=blue]Movies [/COLOR][/B]',
 '[B][COLOR=white]Search [COLOR=green]Series [/COLOR][/B]'
 ])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




#def click_1():
#    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.apex_sports/?category=live_sport&amp;mode=search)')
#    xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology[/COLOR][/B]",'[COLOR white]Για την αναζήτηση αγώνων, πληκτρολογήστε την Ομάδα ή την Χώρα με λατινικούς χαρακτήρες ...[/COLOR]' , icon ='special://home/addons/skin.TechNEWSology/icon.png')

def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/SearchTk/Search_movies.py")')

def click_2():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/SearchTk/Search_tvshows.py")')


search()
