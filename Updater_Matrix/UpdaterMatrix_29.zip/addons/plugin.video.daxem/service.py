from xbmc import getInfoLabel, Player, Monitor
from xbmcvfs import translatePath
from time import sleep
from pickle import load, dump
from collections import OrderedDict
import os
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), 'plugin.video.daxem')
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def save_last_watch(data):
    if not data:
        return
    cache_id, query = data
    content = read_file('daxem.pkl') or OrderedDict()
    if content and next(iter(content.items())) == (cache_id, query):
        return
    content[cache_id] = query
    content.move_to_end(cache_id, last=False)
    while len(content) > 50:
        content.popitem(last=True)
    write_file('daxem.pkl', content)
def on_playback_started():
    path = getInfoLabel('Player.FilenameAndPath')
    title = getInfoLabel('Player.Title')
    if not path.startswith('plugin://') or not title:
        return
    save_last_watch((title, path))
player = Player()
while not Monitor().abortRequested():
    if player.isPlaying():
        on_playback_started()
    sleep(1)