# -*- coding: utf-8 -*-

import requests, json
from lib import scrapers, logger
from lib.broadcaster_result import BroadcasterResult


def play(search):
    res = BroadcasterResult()

    channels = {"SMRTV": 0, "SMRTVS": 1}
    url = ""

    if search in channels:
        requrl = "https://catchup.acdsolutions.it/jstag/videoplayerLiveFluid/TV?ch={}".format(channels[search])
        data = requests.get(requrl).text
        matchedJson = scrapers.findSingleMatch(data, r"'playerElement',([^)]+)")

        if matchedJson:
            _json = json.loads(matchedJson)
            url = _json["sources"][0]["src"]

    if url:
        res.Url = url
        # res["header"] = "user-agent={}".format(utils.USER_AGENT)
        res.ManifestType = "hls"

    return res
