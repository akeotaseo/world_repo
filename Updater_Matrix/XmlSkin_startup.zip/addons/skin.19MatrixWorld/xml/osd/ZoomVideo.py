﻿import xbmc

def ZoomVideo():
    # xbmc.executebuiltin("Action(Close)")

    # xbmc.sleep(100)
    # xbmc.executebuiltin("Action(aspectratio)")
    # xbmc.sleep(100)
    # xbmc.executebuiltin("Action(aspectratio)")
    # xbmc.sleep(100)
    
    # xbmc.executebuiltin("Action(aspectratio)")
    # xbmc.sleep(100)
    
    
    
    xbmc.executebuiltin("ActivateWindowAndFocus(osdvideosettings)")
    xbmc.executebuiltin("Action(Pause)")
    xbmc.sleep(500)
    if xbmc.getCondVisibility('system.platform.android'):
        xbmc.executebuiltin('SendClick(-176)')
    else:
        xbmc.executebuiltin('SendClick(-175)')

    while xbmc.getCondVisibility("Window.IsVisible(osdvideosettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")

ZoomVideo()
