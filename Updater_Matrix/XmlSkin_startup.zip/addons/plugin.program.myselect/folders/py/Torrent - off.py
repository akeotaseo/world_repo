import xbmc, xbmcgui


def torrent():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11)
    call = xbmcgui.Dialog().select('[B][COLOR=red]Torrent[/COLOR][/B]/[B][COLOR=green]Hosters[/COLOR][/B]', 
['[COLOR=orange]Elementum[/COLOR]*',
 '[COLOR=white]Αναζήτηση σε[/COLOR][COLOR=red] Torrent[/COLOR]',
 '[COLOR=white]Aναζήτηση σε[COLOR=green] Hosters[/COLOR]',
 '[B][COLOR=red]Ταινίες[/COLOR][/B]',
 '[B][COLOR=red]Ταινίες[COLOR=blue] Έτος[/COLOR][/B]',
 '[B][COLOR=red]Ταινίες[COLOR=yellow] Κατηγορία[/COLOR][/B]',
 '[B][COLOR=red]Ταινίες[COLOR=purple] Χώρα[/COLOR][/B]',
 '[B][COLOR=red]Σειρές[/COLOR][/B]',
 '[B][COLOR=red]Σειρές[COLOR=blue] Έτος[/COLOR][/B]',
 '[B][COLOR=red]Σειρές[COLOR=yellow] Κατηγορία[/COLOR][/B]',
 '[B][COLOR=red]Σειρές[COLOR=purple] Χώρα[/COLOR][/B]'])
 



    if call:
        if call < 0:
            return
        func = funcs[call-11]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




#def click_1():
#    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.apex_sports/?category=live_sport&amp;mode=search)')
#    xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology[/COLOR][/B]",'[COLOR white]Για την αναζήτηση αγώνων, πληκτρολογήστε την Ομάδα ή την Χώρα με λατινικούς χαρακτήρες ...[/COLOR]' , icon ='special://home/addons/skin.TechNEWSology/icon.png')

def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.elementum/",return)')
    
def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?Stype=torrs&action=searchSites",return)')
    
def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?Stype=sites&action=searchSites",return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=all&url=https%3a%2f%2fwww.cinemagia.ro%2ffilme%2f%3fpn%3d1",return)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=ani&url=https%3a%2f%2fwww.cinemagia.ro%2ffilme%2f%3fpn%3d1",return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=gen&url=https%3a%2f%2fwww.cinemagia.ro%2ffilme%2f%3fpn%3d1",return)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=tari&url=https%3a%2f%2fwww.cinemagia.ro%2ffilme%2f%3fpn%3d1",return)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=all&url=https%3a%2f%2fwww.cinemagia.ro%2fseriale-tv%2f%3fpn%3d1",return)')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=ani&url=https%3a%2f%2fwww.cinemagia.ro%2fseriale-tv%2f%3fpn%3d1",return)')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=gen&url=https%3a%2f%2fwww.cinemagia.ro%2fseriale-tv%2f%3fpn%3d1",return)')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=tari&url=https%3a%2f%2fwww.cinemagia.ro%2ffilme%2f%3fpn%3d1",return)')

torrent()
