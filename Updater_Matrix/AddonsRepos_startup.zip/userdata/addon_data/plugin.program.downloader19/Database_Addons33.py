﻿from updatervar import *
import db


def addon_database():
    db.addon_database(Database_Addons33, 1, True)

Database_Addons33 = [('repository.Worldolympic', 'repository.World'),
                     ('repository.World', 'repository.World'),



                     ('plugin.video.watchnixtoons2', 'repository.Worldolympic'),
                     ('plugin.video.rumble', 'repository.Worldolympic'),

                     ('plugin.program.downloaderstartup', 'repository.Worldolympic'),


                     ('plugin.video.macvod', 'repository.Worldolympic'),
                     ('plugin.video.rumble', 'repository.Worldolympic'),
                     ('plugin.program.simple.favourites', 'repository.Worldolympic'),
                     ('script.embuary.info', 'repository.Worldolympic'),

                     ('script.black.bars.never', 'repository.World'),
                     ('script.kelebek', 'repository.World'),
                     ('script.luar', 'repository.World'),
                     ('plugin.video.stalker', 'repository.World'),


                     ('plugin.video.duffyou', 'repository.gkobu'),
                     ('plugin.video.youtube', 'repository.gkobu'),
                     ('script.extendedinfo', 'repository.gkobu'),
                     ('plugin.video.f4mTester', 'repository.gkobu'),
                     ('script.video.F4mProxy', 'repository.gkobu'),
                     ('plugin.video.live.streamspro', 'repository.gkobu'),
                     ('plugin.video.lookmovietomb', 'repository.gkobu'),
                     ('plugin.video.fmoviesto', 'repository.gkobu'),
                     ('plugin.video.sporthdme', 'repository.gkobu'),
                     ('plugin.video.cartoonsgr', 'repository.gkobu'),
                     ('plugin.video.gratis', 'repository.gkobu'),
                     ('plugin.video.lookmovietomb', 'repository.gkobu'),
                     ('plugin.video.thetvapp', 'repository.gkobu'),


                     #('script.module.inputstreamhelper', 'repository.xbmc.org'),
                     ('script.module.inputstreamhelper', 'repository.aliunde'),
                     #('script.module.inputstreamhelper', 'repository.slyguy.inputstreamhelper'),



                     ('plugin.video.zeltorix.worldcams.tv', 'repository.zeltorix'),
                     ('script.module.zeltorix.packages', 'repository.zeltorix'),
                     ('script.module.zeltorix.utilitys', 'rrepository.zeltorix'),



                     ('repository.slyguy.inputstreamhelper', 'repository.slyguy'),

                     ('weather.gismeteo', 'repository.xbmc.org'),

                     ('plugin.video.vnmedia', 'repository.vmfmatrix'),
                     ('repository.vmfmatrix', 'repository.vmfmatrix'),

                     ('repository.709', 'repository.709'),
                     ('repository.909', 'repository.909'),
                     ('script.module.accountmgr', 'repository.709'),
                     ('script.module.acctview', 'repository.709'),


                     #('plugin.video.daddylive', 'repository.World'),
                     #('plugin.video.daddylive', 'repository.thecrew'),
                     #('plugin.video.daddylive', 'repository.aliunde'),
                     ('plugin.video.daddylive', 'repository.dexe'),

                     ('repository.castagnait', 'repository.castagnait'),


                     ('plugin.video.torquelite', 'repository.gearheads2'),

                     ('plugin.video.KODIvertiDO', 'repository.KODIvertiDO_TEAM'),
                     ('plugin.video.vavooto', 'repository.michaz'),
                     

                     ('repository.cMaNWizard', 'repository.cMaNWizard'),
                     ('plugin.video.quicksilver', 'repository.cMaNWizard'),
                     ('script.module.quicksilverscrapers', 'repository.cMaNWizard'),
                     ('script.quicksilver.artwork', 'repository.cMaNWizard'),

                     ('script.module.jetextractors', 'repository.loop'),

                     ('repository.rays.files', 'repository.rays.files'),

                     ('repository.Parrot', 'repository.Parrot'),


                     ('repository.alado.tv', 'repository.alado.tv'),
                     ('plugin.video.train.mac.again', 'repository.alado.tv'),

                     ('repository.roooar', 'repository.roooar'),
                     ('repository.dexe', 'repository.dexe'),
                     ('plugin.video.BauBauVavoo', 'repository.dexe'),
                     ('plugin.video.GreenKlikPremium', 'repository.dexe'),


                     ('repository.cocoscrapers', 'repository.cocoscrapers'),
                     ('script.module.cocoscrapers', 'repository.cocoscrapers'),



                     ('repository.chainsrepo', 'repository.chainsrepo'),
                     ('plugin.video.homelander', 'repository.chainsrepo'),
                     ('script.module.homelanderscrapers', 'repository.chainsrepo'),
                     ('script.homelander.artwork', 'repository.chainsrepo'),


                     ('repository.subskip', 'repository.subskip'),


                     ('repository.lekma', 'repository.lekma'),
                     ('plugin.video.invidious', 'repository.lekma'),

                     ('skin.xonfluence', 'hellyrepo.kodi'),



                     ('repository.Worldrepo', 'repository.World')]


addon_database()
