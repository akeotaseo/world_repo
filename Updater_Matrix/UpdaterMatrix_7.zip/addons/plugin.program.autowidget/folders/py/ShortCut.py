import xbmc, xbmcgui


def ShortCut():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Mix~[/COLOR][/B]', 
['[B][COLOR=white]Ταινιες - Προβολές[/COLOR][/B] (blacklodge)',
 '[B][COLOR=white]Σειρές -  Με πολλούς ψήφους[/COLOR][/B] (blacklodge)',
 '[B][COLOR=white]LIVE EVENTS[/COLOR][/B] (sporthdme)',
 '[B][COLOR=white][B]AGENDA VECDN[/COLOR][/B] (black ghost)',
 '[B][COLOR=white]Xrysoi - Παιδικά Μεταγλωτισμένα[/COLOR][/B] (mj-cartoonsgr)',
 '[B][COLOR=white]Xrysoi - Παιδικά Υπότιτλοι[/COLOR][/B] (mj-cartoonsgr)',
 '[B][COLOR=white]Ζωντανή Τηλεόραση[/COLOR][/B] (AliveGR)',
 '[B][COLOR=white]Sophisticated[/COLOR][/B] (eradio)',
 '[B][COLOR=white]Αναζήτηση[/COLOR][/B] (YouTube)'])


    if call:
        if call < 0:
            return
        func = funcs[call-9]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.blacklodge/?action=movies&url=trending")') 

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.blacklodge/?action=tvshows&url=views")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sporthdme/?description&iconimage=special://home/addons%5cplugin.video.sporthdme%5cicon.png&mode=5&name=%5bB%5d%5bCOLOR%20white%5dLIVE%20EVENTS%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2f1.livesoccer.sx%2f")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?iconimage=http%3a%2f%2fbgapp.live%2fblack%2fimg%2fdeportes.png&mode=17&regexs=%7b%27makelist3%27%3a%20%7b%27name%27%3a%20%27makelist3%27%2c%20%27listrepeat%27%3a%20%27%5cn%3ctitle%3e%5bB%5d%5bmakelist3.param1%5d%20%5b%2fB%5d%3c%2ftitle%3e%5cn%3clink%3e%24doregex%5bchdeco%5d%7cReferer%3dhttps%3a%2f%2fvikistream.com%2f%26amp%3bOrigin%3dhttps%3a%2f%2fvikistream.com%3c%2flink%3e%5cn%3cthumbnail%3ehttp%3a%2f%2fbgapp.live%2fblack%2fimg%2fdeportes.png%3c%2fthumbnail%3e%5cn%27%2c%20%27expres%27%3a%20%27%22(.%2a%3f)-(.%2a%3f)%22%27%2c%20%27page%27%3a%20%27http%3a%2f%2fbgapp.live%2fblack%2fvecdn.php%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27chdeco%27%3a%20%7b%27name%27%3a%20%27chdeco%27%2c%20%27expres%27%3a%20%27%24pyFunction%3a%5c%27%24doregex%5bch%5d%5c%27.replace(%5c%27%22%5c%27%2c%5c%27%5c%27).replace(%5c%27%2c%5c%27%2c%5c%27%5c%27).replace(%5c%27%5c%5c%2f%5c%27%2c%5c%27%2f%5c%27)%27%2c%20%27page%27%3a%20None%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27ch%27%3a%20%7b%27name%27%3a%20%27ch%27%2c%20%27expres%27%3a%20%27return%5c%5c(%5c%5c%5b(.%2a%3f)%5c%5c%5d%27%2c%20%27page%27%3a%20%27https%3a%2f%2fvikistream.com%2fembed2.php%3fplayer%3ddesktop%26live%3d%24doregex%5bfid%5d%27%2c%20%27referer%27%3a%20%27https%3a%2f%2fcdn1.link%2f%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27fid%27%3a%20%7b%27name%27%3a%20%27fid%27%2c%20%27expres%27%3a%20%22fid%3d%27(.%2a%3f)%27%22%2c%20%27page%27%3a%20%27%5bmakelist3.param2%5d%27%2c%20%27referer%27%3a%20%27https%3a%2f%2fcdn1.link%2f%27%2c%20%27cookiejar%27%3a%20%27%27%7d%7d&url=%24doregex%5bmakelist3%5d",return)')
    
def click_5():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.microjen/run_plug/plugin.video.cartoonsgr%2F%3Fdescription%26amp%3Biconimage%3Dnone%26amp%3Bmode%3Dxrysoiposts%26amp%3Bname%3D%2520%26amp%3Burl%3Dhttps%3A%2F%2Fxrysoi.pro%2Fcategory%2F%25ce%25ba%25ce%25b9%25ce%25bd-%25cf%2583%25cf%2587%25ce%25ad%25ce%25b4%25ce%25b9%25ce%25b1%2F")')

def click_6():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.microjen/run_plug/plugin.video.cartoonsgr%2F%3Fdescription%26amp%3Biconimage%3Dnone%26amp%3Bmode%3Dxrysoiposts%26amp%3Bname%3D%2520%26amp%3Burl%3Dhttps%3A%2F%2Fxrysoi.pro%2Fcategory%2F%25ce%25ba%25ce%25b9%25ce%25bd-%25cf%2583%25cf%2587%25ce%25ad%25ce%25b4%25ce%25b9%25ce%25b1-subs%2F")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.AliveGR/?action=live_tv&title=%ce%96%cf%89%ce%bd%cf%84%ce%b1%ce%bd%ce%ae%20%ce%a4%ce%b7%ce%bb%ce%b5%cf%8c%cf%81%ce%b1%cf%83%ce%b7")')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10502,"plugin://plugin.audio.eradio.gr/?action=radios&title=Sophisticated&url=http%3a%2f%2feradio.mobi%2fcache%2f1%2f1%2fmedialist_categoryID11.json")')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/kodion/search/list/")')

ShortCut()
