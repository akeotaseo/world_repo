# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests
import re
from ..utils.browser import Firefox
from ..utils.resolve import Resolver

class DaddyLive(Resolver):
    def __init__(self):
        pass
    
    def grab(self, channel):
        firefox = Firefox()
        url = f"https://streamservicehd.click/premiumtv/livetvon.php?id={channel}"
        firefox.addHeader("Referer", "https://livetvon.click")
        
        attempts = 0
        while attempts <= 3:
            attempts += 1

            resp = requests.get(url, headers=firefox.headers)
            match = re.findall(r"^(?!\/\/)source:\'(.*?)\'", resp.text, re.MULTILINE)
            
            for m in match:
                if "m3u8" in m:
                    firefox.addHeader("Referer", "https://streamservicehd.click/")
                    return m, firefox.headers

        return "", {}
            
