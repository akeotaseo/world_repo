import xbmc, xbmcgui


def GRmac():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select('[B][COLOR=blue] GR[CR]  mac [/COLOR][/B]', 
['[B][COLOR=white]tv.premiumplus.tv[/COLOR][/B]',
 '[B][COLOR=white]cam.access.ly[/COLOR][/B]',
 '[B][COLOR=white]line.linewings.com[/COLOR][/B]',
 '[B][COLOR=white]line.protv.cc[/COLOR][/B]',
 '[B][COLOR=white]technologycloud.eu[/COLOR][/B]',
 '[B][COLOR=white]Πρόγραμμα Τηλεόρασης[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmcgui.Dialog().notification("[B][COLOR blue]GR[/COLOR][/B] m3u8", "[COLOR orange]http://tv.premiumplus.tv:80[/COLOR]", sound=False, icon='https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Flag_of_Greece.svg/510px-Flag_of_Greece.svg.png')
    xbmc.sleep(2000)
    xbmcgui.Dialog().notification("[B][COLOR green]lists / Channels[/COLOR][/B]", "[COLOR orange]They don't always work[/COLOR]", sound=False, icon='special://home/addons/plugin.video.playlistloaderworld/local/doestworkalltime.png')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloaderworld/?cache=0&epg&iconimage=special://home/addons%5cplugin.video.playlistloaderworld%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bx%5d&url=special%3a%2f%2fhome%2faddons%2fplugin.video.playlistloaderworld%2flocal%2fGR.m3u8&uuid=cf9d6939-bc4a-4e85-9c26-98a83e59b38e")')

def click_2():
    xbmcgui.Dialog().notification("[B][COLOR blue]GR[/COLOR][/B] m3u8", "[COLOR orange]http://cam.access.ly:80[/COLOR]", sound=False, icon='https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Flag_of_Greece.svg/510px-Flag_of_Greece.svg.png')
    xbmc.sleep(2000)
    xbmcgui.Dialog().notification("[B][COLOR green]lists / Channels[/COLOR][/B]", "[COLOR orange]They don't always work[/COLOR]", sound=False, icon='special://home/addons/plugin.video.playlistloaderworld/local/doestworkalltime.png')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloaderworld/?cache=0&epg&iconimage=special://home/addons%5cplugin.video.playlistloaderworld%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bx%5d&url=special%3a%2f%2fhome%2faddons%2fplugin.video.playlistloaderworld%2flocal%2fGR2.m3u8&uuid=cf9d6939-bc4a-4e85-9c26-98a83e59b38e")')

def click_3():
    xbmcgui.Dialog().notification("[B][COLOR blue]GR[/COLOR][/B] m3u8", "[COLOR orange]http://line.linewings.com:80[/COLOR]", sound=False, icon='https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Flag_of_Greece.svg/510px-Flag_of_Greece.svg.png')
    xbmc.sleep(2000)
    xbmcgui.Dialog().notification("[B][COLOR green]lists / Channels[/COLOR][/B]", "[COLOR orange]They don't always work[/COLOR]", sound=False, icon='special://home/addons/plugin.video.playlistloaderworld/local/doestworkalltime.png')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloaderworld/?cache=0&epg&iconimage=special://home/addons%5cplugin.video.playlistloaderworld%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bx%5d&url=special%3a%2f%2fhome%2faddons%2fplugin.video.playlistloaderworld%2flocal%2fGR3.m3u8&uuid=cf9d6939-bc4a-4e85-9c26-98a83e59b38e")')

def click_4():
    xbmcgui.Dialog().notification("[B][COLOR blue]GR[/COLOR][/B] m3u8", "[COLOR orange]http://line.protv.cc[/COLOR]", sound=False, icon='https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Flag_of_Greece.svg/510px-Flag_of_Greece.svg.png')
    xbmc.sleep(2000)
    xbmcgui.Dialog().notification("[B][COLOR green]lists / Channels[/COLOR][/B]", "[COLOR orange]They don't always work[/COLOR]", sound=False, icon='special://home/addons/plugin.video.playlistloaderworld/local/doestworkalltime.png')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloaderworld/?cache=0&epg&iconimage=special://home/addons%5cplugin.video.playlistloaderworld%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bx%5d&url=special%3a%2f%2fhome%2faddons%2fplugin.video.playlistloaderworld%2flocal%2fGR4.m3u8&uuid=cf9d6939-bc4a-4e85-9c26-98a83e59b38e")')
    xbmc.sleep(2000)
    xbmcgui.Dialog().notification("[B][COLOR green]lists / Channels[/COLOR][/B]", "[COLOR orange]They don't always work[/COLOR]", sound=False, icon='special://home/addons/plugin.video.playlistloaderworld/local/doestworkalltime.png')
def click_5():
    xbmcgui.Dialog().notification("[B][COLOR blue]GR[/COLOR][/B] m3u8", "[COLOR orange]http://technologycloud.eu[/COLOR]", sound=False, icon='https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Flag_of_Greece.svg/510px-Flag_of_Greece.svg.png')
    xbmc.sleep(2000)
    xbmcgui.Dialog().notification("[B][COLOR green]lists / Channels[/COLOR][/B]", "[COLOR orange]They don't always work[/COLOR]", sound=False, icon='special://home/addons/plugin.video.playlistloaderworld/local/doestworkalltime.png')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloaderworld/?cache=0&epg&iconimage=special://home/addons%5cplugin.video.playlistloaderworld%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bx%5d&url=special%3a%2f%2fhome%2faddons%2fplugin.video.playlistloaderworld%2flocal%2fGR4.m3u8&uuid=cf9d6939-bc4a-4e85-9c26-98a83e59b38e")')

def click_6():
    xbmc.executebuiltin('Action(Back)')
