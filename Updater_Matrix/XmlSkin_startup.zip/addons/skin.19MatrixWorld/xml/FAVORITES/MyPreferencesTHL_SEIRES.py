import xbmc, xbmcgui
xbmcgui.Dialog().notification("[COLOR orange]Προτιμήσεις Σειρές[/COLOR]", "Ανακατεύθυνση...", sound=False, icon='special://home/addons/plugin.program.mypreferences/icon.png')

xbmc.executebuiltin('ActivateWindow(10000)')
xbmc.sleep(4000)
xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.program.mypreferences/?label=2.THL.SEIRES TV&mode=400&path=special%3A%2F%2Fprofile%2Faddon_data%2Fplugin.program.mypreferences%5C2.THL.SEIRES",return)')
