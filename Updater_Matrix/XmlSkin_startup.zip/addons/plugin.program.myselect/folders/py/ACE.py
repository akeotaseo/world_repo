import os, xbmc, xbmcgui, webbrowser, xbmcaddon

def ACE():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=blue]~ ACE ~[/COLOR][/B]', 
['[B][COLOR=lime]Αce Stream[/COLOR][/B]',

'[I][B][COLOR=blue]install ΑceStream[/COLOR][/B][/I]'
 ])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def click_1():
    xbmcgui.Dialog().ok('[B][COLOR blue]ACE[/COLOR][/B]', '[COLOR green]Πρώτα ανοίξτε [/COLOR] [COLOR chocolate]το Ace Stream Media[/COLOR] (σε Windows)[CR][CR]Αν αποτύχει η αναπαραγωγή, δοκιμάστε ξανά.')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.myselect/?group=14ace-14&mode=group&refresh&reload")')



def click_2():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]www.acestream.org[/COLOR]', 'Εγκαταστήστε το [B][COLOR=blue]ACE STREAM[/COLOR][/B] για το λειτουργικό σας σύστημα...',
        
                                        nolabel='[B][COLOR white]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR=blue]ACE STREAM[/COLOR][/B]')
    
    if choice == 1: menuoptions()
    if choice == 0: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/ACE.py")')
    
    

def menuoptions():
    dialog = xbmcgui.Dialog()
    funcs = (
        function1, function2
    )
        
    call = dialog.select('[B][COLOR=blur]ACE STREAM[/COLOR][/B]',
    [
    'Ανακατεύθυνση σε https://www.acestream.org',
    '[COLOR white][COLOR blueviolet]Ace Stream Media Mod ver3.3.1.48.0(android/arm)[/COLOR][/COLOR]'])

    # dialog.selectreturns
    #   0 -> escape pressed
    #   1 -> first item
    #   2 -> second item
    if call:
        # esc is not pressed
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()

def function1():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.acestream.org/' ) )
    else:
        opensite = webbrowser . open('https://www.acestream.org/')


def function2():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=apkinstall&name=%5BCOLOR+blueviolet%5DAce+Stream+Media+Mod+ver3.3.1.48.0%28android%2Farm%29%5B%2FCOLOR%5D&url=https%3A%2F%2Fgknwizard.eu%2Frepo%2Fwizard%2Fapks%2FAceStream_MOD_ver3-3.1.48.0-armv7.apk")')

def VPN():

        choice = xbmcgui.Dialog().yesno('[B][COLOR red]ΠΡΟΣΟΧΗ![/COLOR][/B]', '[B][COLOR orange]Για τα AceStream links συνιστάται χρήση VPN![/COLOR][/B]',
                                        # yeslabel='[B][COLOR lime]Ok[/COLOR][/B]', nolabel='[B][COLOR orange]Άκυρο[/COLOR][/B]')
                                        yeslabel='[COLOR lime]Ok[/COLOR]', nolabel='[COLOR orange]Άκυρο[/COLOR]')
        if choice == 1: Livetv_setMj_on(), ACE()
        if choice == 0: Livetv_setMj_off()


def Platform():


    if not xbmc.getCondVisibility('System.Platform.Windows') or xbmc.getCondVisibility('System.Platform.Android'): xbmc.executebuiltin('ActivateWindow(10000)'), xbmcgui.Dialog().notification("[COLOR red]Το λειτουργεικό σας σύστημα[/COLOR]", "[COLOR red]δεν υποστηρίζει[CR][/COLOR][COLOR=blue]ACE Streams[/COLOR]", sound=True, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime1.png')
    else: VPN()
    


def Livetv_setMj_on():
    addon_microjen       = xbmcaddon.Addon('plugin.video.microjen')
    setting_microjen     = addon_microjen.getSetting
    setting_set_microjen = addon_microjen.setSetting
    if not setting_microjen('enable_ace_links')=='true':
        xbmc.sleep(1000)
        setting_set_microjen('enable_ace_links', 'true')


def Livetv_setMj_off():
    addon_microjen       = xbmcaddon.Addon('plugin.video.microjen')
    setting_microjen     = addon_microjen.getSetting
    setting_set_microjen = addon_microjen.setSetting
    if not setting_microjen('enable_ace_links')=='false':
        xbmc.sleep(1000)
        setting_set_microjen('enable_ace_links', 'false')

Platform()

