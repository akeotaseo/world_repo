from re import sub, compile


class CleanText:
    @staticmethod
    def clear_html_tags(raw_html):
        return " ".join(sub(compile("<.*?>|&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});"), " ", raw_html).split())
