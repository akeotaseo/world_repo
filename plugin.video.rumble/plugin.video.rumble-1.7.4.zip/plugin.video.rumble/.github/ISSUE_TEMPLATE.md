<!--- Provide a general summary of the issue in the **Title** above -->
<!--- Before you open an issue, please check if a similar issue already exists or has been closed before. --->

#### Your Environment
<!--- Include as many relevant details about the environment you experienced the issue in -->
* Plugin Version:
* Kodi Version:
* Operating System:

#### Issue
<!--- Provide a more detailed introduction to the issue itself -->
<!--- Also please check relevant logs (https://kodi.wiki/view/Log_file) -->

#### Steps to Reproduce
<!--- steps of how to reproduce this issue if relevant -->
1.
2.
3.
4.
