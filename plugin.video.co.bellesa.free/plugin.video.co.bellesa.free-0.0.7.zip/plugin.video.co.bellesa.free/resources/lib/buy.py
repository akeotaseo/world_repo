# -*- coding: utf-8 -*-

# Author/Copyright: fr33p0rt <fr33p0rt@protonmail.com>
# License: Freeware (licensed to use and redistribute)

import os
import xbmc
import xbmcaddon

xbmc.executebuiltin("ShowPicture(%s)" % os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'buy', 'buy-main.png'))
