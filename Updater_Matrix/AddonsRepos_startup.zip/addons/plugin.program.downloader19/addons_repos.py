
ADDONS_REPOS = [('repository.Worldolympic', 'repository.World'),
                     ('repository.World', 'repository.World'),
                     ('plugin.video.watchnixtoons2', 'repository.thecrew'),
                     ('plugin.video.live.streamspro', 'repository.Worldolympic'),
                     ('plugin.video.macvod', 'repository.Worldolympic'),
                     ('plugin.video.rumble', 'repository.Worldolympic'),
                     ('repository.castagnait', 'repository.castagnait'),
                     ('plugin.program.downloader', 'repository.gkobu'),
                     
                     ('script.realdebridsite', 'repository.Worldolympic'),
                     ('service.World.Build', 'repository.Worldolympic'),
                     
                     ('script.kelebek', 'repository.World'),
                     ('script.luar', 'repository.World'),
                     
                     ('plugin.video.neo.tv', 'repository.7Plus'),
                     
                     ('plugin.video.daddylive', 'repository.World'),
                     
                     ('repository.roooar', 'repository.roooar'),
                     ('repository.dexe', 'repository.dexe'),
                     ('plugin.video.BauBauVavoo', 'repository.dexe'),
                     ('plugin.video.GreenKlikPremium', 'repository.dexe'),
                     
                     ('plugin.video.atlas', 'repository.atlas'),
                     
                     ('plugin.video.invidious', 'repository.lekma'),
                     
                     ('repository.Kpoodle20', 'repository.Kpoodle20'),
                     ('repository.diggz', 'repository.diggz'),
                     ('repository.matrix', 'repository.matrix'),
                     
                     ('script.extendedinfo', 'repository.gkobu'),
                     ('repository.Worldrepo', 'repository.World')]