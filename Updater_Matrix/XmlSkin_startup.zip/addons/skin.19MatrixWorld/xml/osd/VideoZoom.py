﻿import xbmc
#  Ratio
def videozoom():
    if xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin("ActivateWindowAndFocus(osdvideosettings)")
        xbmc.sleep(500)
    if xbmc.getCondVisibility('system.platform.android'):
        xbmc.executebuiltin('SendClick(-177)')
    else:
        xbmc.executebuiltin('SendClick(-176)')

    while xbmc.getCondVisibility("Window.IsVisible(osdvideosettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")



    if not xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin("ActivateWindowAndFocus(osdvideosettings)")
        xbmc.executebuiltin("Action(Pause)")
        xbmc.sleep(500)
    if xbmc.getCondVisibility('system.platform.android'):
        xbmc.executebuiltin('SendClick(-177)')
    else:
        xbmc.executebuiltin('SendClick(-176)')

    while xbmc.getCondVisibility("Window.IsVisible(osdvideosettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")

videozoom()
