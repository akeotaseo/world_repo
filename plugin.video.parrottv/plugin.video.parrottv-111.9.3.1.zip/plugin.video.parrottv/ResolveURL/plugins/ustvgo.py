# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests
import random
from ..utils.browser import Firefox
from ..utils.resolve import Resolver

class USTVGO(Resolver):
    def __init__(self):
        self.accessCode = "PM6Xg4pUzngAxvZBa0PKFg6ZlVRsOfvw"
        self.proxyServers = """
            http://cjdpsxvlgqiidunhfgz.orgfree.com
            http://gttxvrrdpckhmyeolrdys.orgfree.com
            http://thafe.orgfree.com
            http://gfjzppvxy.orgfree.com
            http://ncnwhozmnvac.orgfree.com
            http://aftcfxawfavag.orgfree.com
            http://cgmiqnayzunzsnmzjxlkcmw.orgfree.com
            http://hokywfuaxypgrfiyz.orgfree.com
            http://kxhubkaqcwgvuorei.orgfree.com
            http://vcvfxlcqdaehxgwvxuj.orgfree.com
            http://fjcygfnmuswhxvqapwiuau.orgfree.com
            http://wqmxeazdg.orgfree.com
            http://ajtfjsoifgd.orgfree.com
            http://sfuvoeqyppjalbwdgpjmg.orgfree.com
            http://gguqsumdxqifmjwvfsx.orgfree.com
            http://hjgjrzoduchkf.orgfree.com
            http://vcouhpzvwopmsuibb.orgfree.com
            http://gudmlgpvttf.orgfree.com
            http://shmimhauymrmnuy.orgfree.com
            http://haypbdmluzyqjkembmj.orgfree.com
            http://nibfuxptmqmgdokjb.orgfree.com
            http://ahepwsrnptcatab.orgfree.com
            http://qmtamsrutv.orgfree.com
            http://cuttoaxxdvlnlrssidpp.orgfree.com
            http://wtdjzsgrxcgfavwqgczmk.orgfree.com
            http://bstvgfk.orgfree.com
            http://ouqgdn.orgfree.com
            http://mluidnumxzi.orgfree.com
            http://bhobrpxpdpzegihbpiieslb.orgfree.com
            http://dwevbxnrffoxuvkhlusa.orgfree.com
            http://xyygqilplbu.orgfree.com
            http://zuiffoqzqpviiyeftnyblmi.orgfree.com
            http://ewnxjvlibjbejyckdc.orgfree.com
            http://kbnzhnahrczyjwrwquwpvj.orgfree.com
            http://csslt.orgfree.com
            http://fwnzu.orgfree.com
            http://axtguinzortzerpazxes.orgfree.com
            http://rdnwmxyczvciebhujkjg.orgfree.com
            http://czecedwvgzocjdhu.orgfree.com
            http://fkdpzjxwmbxugwdtsupy.orgfree.com
            http://ggobcpe.orgfree.com
            http://sxtphg.orgfree.com
            http://nyznakuwyrfotblvvnhmjxav.orgfree.com
            http://jjexnu.orgfree.com
            http://xrdajuvbap.orgfree.com
            http://fehlmzn.orgfree.com
            http://cligdgbkrtfjc.orgfree.com
            http://urwsbocdydvfqcvdnjsbpjutb.orgfree.com
            http://zmeytcnvpocxbbmfmh.orgfree.com
            http://vlnwwssygvrsai.orgfree.com
            http://ylxayofof.orgfree.com
            http://iswkygebgxbiuxnfmng.orgfree.com
            http://gocwsxlledica.orgfree.com
        """.replace(" ", "").split("\n")
        self.proxyServers.remove('')


    def grab(self, channel):
        firefox = Firefox()
        firefox.addHeader('Referer', 'http://ustvgo.tv/')
        url = "https://ustvgo.tv/player.php?stream=" + channel
        resp = requests.get(url, headers=firefox.headers).text

        if "hls_src" in resp:
            return resp.replace('\n', '').split("var hls_src='")[1].split("'")[0], firefox.headers


        random.shuffle(self.proxyServers)

        firefox.addHeader("Authorization", f"Code {self.accessCode}")

        for server in self.proxyServers:
            #if self.accessCode in requests.get(f"{server}/index.php", headers=firefox.headers).text:
            if requests.get(f"{server}/index.php", headers=firefox.headers).status_code in range(200, 400):
                return f"{server}/grab.php?c={channel}", firefox.headers

        return "", {}
    
        