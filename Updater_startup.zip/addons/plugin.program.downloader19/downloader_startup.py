﻿import os, xbmc, xbmcgui, xbmcvfs, xbmcaddon
from updatervar import *
#from resources.lib.modules.delete_addons import del_dir
from resources.lib.GUIcontrol import txt_updater
from resources.lib.modules import db, addonsEnable
from resources.lib.modules.addonsEnable import enable_addons
from resources.lib.modules.installer_addons import installAddon
from resources.lib.GUIcontrol.txt_updater import get_skinshortcutsversion

skinshortcuts_version = get_skinshortcutsversion()

Database_Addons33 = [('plugin.video.fmoviesto', 'repository.mbebe'),
                     ('plugin.video.subsmovies', 'repository.mbebe'),
                     ('plugin.program.downloader19', 'repository.World'),
                     ('plugin.video.cartoonsgr', 'repository.bugatsinho'),
                     ('vkkodi.repo', 'vkkodi.repo')]

addon_themoviedb       = xbmcaddon.Addon('plugin.video.themoviedb.helper')
setting_themoviedb     = addon_themoviedb.getSetting
setting_set_themoviedb = addon_themoviedb.setSetting

def Updater_Matrix():
    BG.create(Dialog_U1, Dialog_U2)
    xbmc.sleep(500)
    BG.update(5, Dialog_U1, Dialog_U6)
    installAddon()
    xbmc.sleep(5000)
    BG.update(25, Dialog_U1, Dialog_U6)

    xbmc.sleep(5000)
    db.addon_database(Database_Addons33, 1, True)
    xbmc.sleep(5000)
    BG.update(30, Dialog_U1, 'Εισαγωγή αποθετηρίων στο Database/Addons33...')

###########################################################################

    if not os.path.exists(UpdaterMatrix_path):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_1)
        xbmc.sleep(5000)
        BG.update(33, Dialog_U1, Dialog_U6)

#    if not os.path.exists(UpdaterMatrix_path2):
#        xbmc.sleep(1000)
#        xbmc.executebuiltin(UpdaterMatrix_2)
#        xbmc.sleep(5000)
#        BG.update(36, Dialog_U1, Dialog_U6)

###########################################################################


    BG.update(40, Dialog_U1, 'Διαγραφή αχρείαστων αρχείων...')
#    del_dir()                                     ### delete addons ands files ###

    if os.path.exists(UpdaterMatrix_path3): xbmcvfs.delete(UpdaterMatrix_path3), xbmc.sleep(1000)
    if os.path.exists(UpdaterMatrix_path4): xbmcvfs.delete(UpdaterMatrix_path4), xbmc.sleep(1000)


    BG.update(50, Dialog_U1, Dialog_U2)

    xbmc.sleep(5000)
    addonsEnable.enable_addons()
    BG.update(75, Dialog_U1, 'Ενεργοποίηση πρόσθετων...')
    xbmc.sleep(10000)
    BG.update(80, Dialog_U1, Dialog_U6)

    if skinshortcuts_version > int(setting('skinshortcutsversion')):
        xbmc.executebuiltin(skinshortcuts_menu)
        xbmc.sleep(8000)
        BG.update(96, Dialog_U1, 'Ενημέρωση στο μενού του skin...')
        xbmc.sleep(4000)

        if setting_themoviedb('widgets_nextpage')=='false':
            setting_set_themoviedb('widgets_nextpage', 'true')
            xbmc.sleep(3000)
            BG.update(99, Dialog_U1, 'Ενεργοποίηση next page των widgets')
            xbmc.sleep(5000)
            BG.update(100, Dialog_U4, 'Θα ακολουθήσει επαναφόρτωση κελύφους')
            xbmc.sleep(8000)
            BG.update(100, Dialog_U4, Dialog_U5)
            xbmc.executebuiltin("ReloadSkin()")
        else:
            xbmc.sleep(5000)
            BG.update(100, Dialog_U4, 'Θα ακολουθήσει επαναφόρτωση κελύφους')
            xbmc.sleep(8000)
            BG.update(100, Dialog_U4, Dialog_U5)
            xbmc.executebuiltin("ReloadSkin()")
    setting_set('skinshortcutsversion', str(skinshortcuts_version))

    if setting_themoviedb('widgets_nextpage')=='false':
        BG.update(97, Dialog_U1, 'Ενεργοποίηση next page των widgets')
        setting_set_themoviedb('widgets_nextpage', 'true')
        xbmc.sleep(3000)
        BG.update(100, Dialog_U4, 'Θα ακολουθήσει επαναφόρτωση κελύφους')
        xbmc.sleep(5000)
        BG.update(100, Dialog_U4, Dialog_U5)
        xbmc.sleep(2000)
        xbmc.executebuiltin("ReloadSkin()")

    xbmc.sleep(5000)
    BG.update(100, Dialog_U4, Dialog_U5)
#    dialog.notification(Dialog_U7, Dialog_U5, icon_Build, sound=False)
#    installAddon()
    xbmc.sleep(5000)
    BG.update(100, Dialog_U4, Dialog_U5)

    BG.close()
    xbmcvfs.delete(downloader_startup_delete)

Updater_Matrix()
