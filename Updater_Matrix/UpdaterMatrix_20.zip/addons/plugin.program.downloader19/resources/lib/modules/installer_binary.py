import os, xbmc, xbmcgui
from updatervar import *

addon_path = translatePath('special://home/addons')

def Installer_Binary_Addons():
    funcs = (action_1, action_2, action_3, action_4, action_5, action_6, action_7)
    selection = xbmcgui.Dialog().select('[B][COLOR=orange]                             Εγκατάσταση Binary Addons[/COLOR][/B]', 
['[B][COLOR=white]SFTP support[/COLOR][/B]',
 '[B][COLOR=white]Rar archive support[/COLOR][/B]',
 '[B][COLOR=white]Archive support[/COLOR][/B]',
 '[B][COLOR=white]Inputstream Adaptive[/COLOR][/B]',
 '[B][COLOR=white]RTMP Input[/COLOR][/B]',
 '[B][COLOR=white]Inputstream FFmpeg Direct[/COLOR][/B]',
 '[B][COLOR=white]Spectrum[/COLOR][/B]'])

    if selection:
        if selection < 0:
            return 
        func = funcs[selection-7]
        return func()
    else:
        func = funcs[selection]
        return func()
    return 

def action_1():
    xbmc.executebuiltin('InstallAddon(vfs.sftp)')
    xbmc.sleep(100)
    xbmc.executebuiltin('SendClick(11)')
    dir_list = glob.iglob(os.path.join(addon_path, "vfs.sftp"))
    for path in dir_list:
        if os.path.exists(addon_path): xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology Updater-Tools[/COLOR][/B]", "[COLOR white]Το πρόσθετο είναι εγκατεστημένο![/COLOR]", icon_Build)

def action_2():
    xbmc.executebuiltin('InstallAddon(vfs.rar)')
    xbmc.sleep(100)
    xbmc.executebuiltin('SendClick(11)')
    dir_list = glob.iglob(os.path.join(addon_path, "vfs.rar"))
    for path in dir_list:
        if os.path.exists(addon_path): xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology Updater-Tools[/COLOR][/B]", "[COLOR white]Το πρόσθετο είναι εγκατεστημένο![/COLOR]", icon_Build)

def action_3():
    xbmc.executebuiltin('InstallAddon(vfs.libarchive)')
    xbmc.sleep(100)
    xbmc.executebuiltin('SendClick(11)')
    dir_list = glob.iglob(os.path.join(addon_path, "vfs.libarchive"))
    for path in dir_list:
        if os.path.exists(addon_path): xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology Updater-Tools[/COLOR][/B]", "[COLOR white]Το πρόσθετο είναι εγκατεστημένο![/COLOR]", icon_Build)

def action_4():
    xbmc.executebuiltin('InstallAddon(inputstream.adaptive)')
    xbmc.sleep(100)
    xbmc.executebuiltin('SendClick(11)')
    dir_list = glob.iglob(os.path.join(addon_path, "inputstream.adaptive"))
    for path in dir_list:
        if os.path.exists(addon_path): xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology Updater-Tools[/COLOR][/B]", "[COLOR white]Το πρόσθετο είναι εγκατεστημένο![/COLOR]", icon_Build)

def action_5():
    xbmc.executebuiltin('InstallAddon(inputstream.rtmp)')
    xbmc.sleep(100)
    xbmc.executebuiltin('SendClick(11)')
    dir_list = glob.iglob(os.path.join(addon_path, "inputstream.rtmp"))
    for path in dir_list:
        if os.path.exists(addon_path): xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology Updater-Tools[/COLOR][/B]", "[COLOR white]Το πρόσθετο είναι εγκατεστημένο![/COLOR]", icon_Build)

def action_6():
    xbmc.executebuiltin('InstallAddon(inputstream.ffmpegdirect)')
    xbmc.sleep(100)
    xbmc.executebuiltin('SendClick(11)')
    dir_list = glob.iglob(os.path.join(addon_path, "inputstream.ffmpegdirect"))
    for path in dir_list:
        if os.path.exists(addon_path): xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology Updater-Tools[/COLOR][/B]", "[COLOR white]Το πρόσθετο είναι εγκατεστημένο![/COLOR]", icon_Build)

def action_7():
    xbmc.executebuiltin('InstallAddon(visualization.spectrum)')
    xbmc.sleep(100)
    xbmc.executebuiltin('SendClick(11)')
    dir_list = glob.iglob(os.path.join(addon_path, "visualization.spectrum"))
    for path in dir_list:
        if os.path.exists(addon_path): xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology Updater-Tools[/COLOR][/B]", "[COLOR white]Το πρόσθετο είναι εγκατεστημένο![/COLOR]", icon_Build)

Installer_Binary_Addons()

