import os, xbmc, xbmcgui

def InstallTheThunder ():
        choice = xbmcgui.Dialog().yesno('[B][COLOR red]ΠΡΟΣΟΧΗ![/COLOR][/B]', '                Το πρόσθετο έχει και συνδέσμους Torrent. [CR]                    Το χρησιμοποιείτε με δική σας ευθύνη. [CR]                                   ',
                                        yeslabel='[B][COLOR lime]Ok[/COLOR][/B]', nolabel='[B][COLOR orange]Άκυρο[/COLOR][/B]')
        if choice == 1: (xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thethunder/")'),
                         )

InstallTheThunder ()
