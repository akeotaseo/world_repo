import xbmc, xbmcgui


def rockcrusher():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13)
    call = xbmcgui.Dialog().select('[B][COLOR=red]~ Rockcrusher ~[/COLOR][/B]', 
['[B][COLOR=white][COLOR dodgerblue]Strikes Auto Zone[/COLOR][/COLOR][/B]',
 '[B][COLOR=white][COLOR gray]Strikes Music Vids[/COLOR][/COLOR][/B]',
 '[B][COLOR=white][COLOR magenta]DreamZBeats[/COLOR][/COLOR][/B]',
 '[B][COLOR=white][COLOR magenta]Skuff TV[/COLOR][/COLOR][/B]',
 '[B][COLOR=white][COLOR red]BRAIN DRAIN[/COLOR][/COLOR][/B]',
 '[B][COLOR=white][COLOR red]CRIME SCENE[/COLOR][/COLOR][/B]',
 '[B][COLOR=white][COLOR red]Fight[COLOR silver]Tube[/COLOR][/COLOR][/B]',
 '[B][COLOR=white][COLOR red]GearZ[/COLOR][/COLOR][/B]',
 '[B][COLOR=white][COLOR red]Rock[COLOR silver] Concert[/COLOR][/COLOR][/B]',
 '[B][COLOR=white][COLOR red]Strikes AllSportz Recaps[/COLOR][/COLOR][/B]',
 '[B][COLOR=white][COLOR red]Strikes Movie Zone[/COLOR][/COLOR][/B]',
 '[B][COLOR=white][COLOR red]VMAXX[/COLOR][/COLOR][/B]',
 '[B][COLOR=white][COLOR red]X Games[/COLOR][/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-13]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.AutoZone/")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.MusicVids/")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.DreamZBeats/")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.SkuffTV/")')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.BRAIN_DRAIN/")')
    
def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.CRIME_SCENE/")')
    
def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.FightTube/")')
    
def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.GearZ/")')
    
def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.RockConcert/")')
    
def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.AllSportzRecaps/")')
    
def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.Movie_Zone/")')
    
def click_12():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.VMAXX/")')
    
def click_13():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.XGames/")')
    
    
rockcrusher()
    
    
