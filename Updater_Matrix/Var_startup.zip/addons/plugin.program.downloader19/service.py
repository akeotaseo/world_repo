﻿import os, xbmc, xbmcgui, xbmcvfs, shutil, glob
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')

# xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":1}}')
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":2}}')


xbmc.sleep(5000)
xbmcgui.Dialog().notification("[B][COLOR orange]...[/COLOR][/B]", "   ", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/autoexec.png')
xbmc.sleep(4000)
xbmcgui.Dialog().notification("[COLOR white]Έναρξη World Updater...[/COLOR]", "[B][COLOR orange]Καλώς ήρθατε![/COLOR][/B]", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/World.png')

# xbmc.sleep(1000)
# xbmc.executebuiltin("ReloadSkin()")
from resources.lib.modules import check

from updatervar import *




if __name__ == '__main__':
	if not setting('updaterversion') == 'false':
		xbmcgui.Dialog().notification("[B][COLOR orange]Ελεγχος για ενημερώσεις[/COLOR][/B]", "...", icon='special://home/addons/plugin.program.downloader19/icon.gif', sound=False)
		xbmc.sleep(5000)
		check.notifyT()
		check.autoenable()
		check.var()
		check.delete()
		check.installation()
		check.players()
		check.zip1()
		check.zip2()
		check.zip3()
		check.zip4()
		check.zip5()
		check.pvr()
		check.setsetting()
		check.database()
		check.xmlskin()
		# xbmc.sleep(5000)
		check.UpdateAddonRepos()



	else:
		dialog.notification('[B][COLOR orange]Καλά να περάσετε![/COLOR][/B]', Dialog_not_Updater, icon_Build, sound=False)
		check.UpdateAddonRepos()

	monitor = xbmc.Monitor()

	while not monitor.abortRequested():
		if monitor.waitForAbort(2*60*60):#διάστημα 2ωρών μεταξύ των ενημερώσεων
			break
		xbmc.executebuiltin('UpdateAddonRepos()')
		dialog.notification('Υπηρεσία ενημέρωσης', 'Εκκίνηση ενημερώσεων προσθέτων', icon_auto, sound=False)
