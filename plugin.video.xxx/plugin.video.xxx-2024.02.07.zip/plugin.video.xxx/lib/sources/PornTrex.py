import re
import xbmcaddon
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

def Menu():
	addDir('Latest Videos',      'https://www.porntrex.com/latest-updates/', 151, 'special://home/addons/plugin.video.xxx/resources/art/porntrex.png')
	addDir('Most Viewed Videos', 'https://www.porntrex.com/most-popular/',   151, 'special://home/addons/plugin.video.xxx/resources/art/porntrex.png')
	addDir('Top Rated Videos',   'https://www.porntrex.com/top-rated/',      151, 'special://home/addons/plugin.video.xxx/resources/art/porntrex.png')
	addDir('Categories',         'https://www.porntrex.com/categories/',     152, 'special://home/addons/plugin.video.xxx/resources/art/porntrex.png')

def Browse(url):
	r = OpenURL(url)
	m = re.compile('<li class="screenshot-item active" data-src=".+?"></li><li class="screenshot-item " data-src=".+?"></li><li class="screenshot-item " data-src=".+?"></li><li class="screenshot-item " data-src=".+?"></li><li class="screenshot-item " data-src="(.+?)"></li><li class="screenshot-item " data-src=".+?"></li><li class="screenshot-item " data-src=".+?"></li><li class="screenshot-item " data-src=".+?"></li><li class="screenshot-item " data-src=".+?"></li><li class="screenshot-item " data-src=".+?"></li></ul></a><span class="ico-fav-0 " title="Add to Favourites" data-fav-video-id=".+?" data-fav-type="0"></span><span class="ico-fav-1 " title="Watch Later" data-fav-video-id=".+?" data-fav-type="1"></span><div class="hd-text-icon text video-item-submitted"><span class="quality">.+?</span> <span class=".+?">.+?</span></div><div class="viewsthumb">.+?</div><div class="durations"><i class="fa fa-clock-o"></i>(.+?)</div><p class="inf"><a href="(.+?)" title="(.+?)" >').findall(r)
	m = re.compile('').findall(r)
	for thumb, time, url, title in m:
		import random
		if thumb.startswith('http'): thumb = thumb
		else: thumb = 'https:' + thumb
		random_id = random.randint(0,1000000)
		url = '%s&random_id=%s' % (url, str(random_id))
		if Setting('show_time') == 'true': title = '[B](%s)[/B] %s' % (time.replace(' ', ''), title)
		addVideo(title, url, 153, thumb)
	n = re.compile('<li class="next"><a href="(.+?)" data-action').findall(r)
	for page in n:
		if 'porntrex' not in page:
			page = 'https://www.porntrex.com' + page
		addDir('Next page >', page, 151, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	Common.SetView()
		
def Categories(url):
	r = OpenURL(url)
	#m = re.compile('<a class="item" href="(.+?)" title="(.+?)">').findall(r)
	m = re.compile('<a class="item" href="(.+?)" title="(.+?)">\n								<div class="img">\n																			<img class="thumb" src="(.+?)" alt=".+?"/>').findall(r)
	for url, title, thumb in m:
		if thumb.startswith('http'): thumb = thumb
		else: thumb = 'https:' + thumb
		if '/categories/' in url and title != 'Categories':
			addDir(title, url, 151, thumb)
	
def PlayStream(url):
	if 'random_id=' in url:
		url = re.compile('(.+?)&random_id').findall(url)[0]
	r = OpenURL(url)
	if 'video_alt_url2' in r:
		m = re.compile('video_alt_url2: \'(.+?)\'').findall(r)
		for url in m:
			Play(url)
	elif 'video_alt_url' in r:
		m = re.compile('video_alt_url: \'(.+?)\'').findall(r)
		for url in m:
			Play(url)
	else:
		m = re.compile('video_url: \'(.+?)\'').findall(r)
		for url in m:
			Play(url)
	
