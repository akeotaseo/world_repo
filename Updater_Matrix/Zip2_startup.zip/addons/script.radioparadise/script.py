from resources.lib.script import run_script


if __name__ == '__main__':
    run_script()
