#! /usr/bin/env python3
import sys,os,xbmcaddon,xbmcplugin,xbmcgui,xbmc

__addon__ =  xbmcaddon.Addon()
__addon_path__ = __addon__.getAddonInfo('path')

def __add_item__(title,url,icon,plot,is_folder=False):
    item=xbmcgui.ListItem(title,path=url)
    item.setInfo(type='video',infoLabels={'Title':title,'Plot':plot} )
    item.setArt({'thumb': icon, 'thumb':icon, 'fanart':__get_image__('fanart.jpg')})
    item.setProperty('IsPlayable','true')
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=item,isFolder=is_folder)

def __get_image__(image):
    return os.path.join(__addon_path__, 'resources', 'icons', image)

def __get_youtube_live_stream__(channel_id):### is_folder = False and is_playable == True ###
    return'plugin://plugin.video.youtube/play/?channel_id=%s&live=1' % channel_id

def __get_youtube_video__(video_id):### is_folder = False and is_playable == True ###
    return'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id

def __get_youtube_playlist__(playlist_id):### is_folder = True and is_playable == True ###
    return'plugin://plugin.video.youtube/playlist/%s/' % playlist_id

def __get_youtube_channel__(channel_id):### is_folder = True and is_playable == True ###
    return'plugin://plugin.video.youtube/channel/%s/' % channel_id

def __get_youtube_search__(search_text):### is_folder = True and is_playable == True ###
    return'plugin://plugin.video.youtube/search/?q=%s' % search_text
 
def __end_of_directory__():
    xbmcplugin.endOfDirectory(handle=int(sys.argv[1]),succeeded=True,updateListing=False,cacheToDisc=False)