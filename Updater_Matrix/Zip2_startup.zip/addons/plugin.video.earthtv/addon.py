﻿#!/usr/bin/python
# -*- coding: utf-8 -*-

#  earthTV Addon
#  Features: iPad Mode, Depth Logic, "Show All" Option

import sys
import urllib.parse
import re
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# --- CONSTANTS ---
ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
HANDLE = int(sys.argv[1])
BASEURL = 'https://www.earthtv.com'

# iPad User-Agent for stable streams
UA = 'iPad'
HEADERS = {
    'User-Agent': UA,
    'Referer': BASEURL
}

class EarthTV(object):

    def show_main_menu(self):
        xbmcplugin.setContent(HANDLE, 'files')

        # 1. The World LIVE
        self.add_item('[COLOR red]The World LIVE (24/7 Channel)[/COLOR]', BASEURL + '/en', is_folder=False)
        
        # 2. Fetch Regions automatically
        url = BASEURL + '/en/webcams'
        try:
            r = requests.get(url, headers=HEADERS, timeout=15)
            html = r.text
            
            regions_match = re.search(r'<ul\s+class="dropdown-menu"\s+aria-labelledby="region-dropdown">(.*?)</ul>', html, re.DOTALL)
            
            if regions_match:
                content = regions_match.group(1)
                link_pattern = r'<a\s+href="([^"]+)">([^<]+)</a>'
                
                for m in re.finditer(link_pattern, content):
                    link = m.group(1)
                    name = m.group(2).strip()
                    
                    if "All" in name: continue
                    
                    full_link = BASEURL + link
                    self.add_item('[COLOR white]' + name + '[/COLOR]', full_link, is_folder=True)
                    
        except:
            xbmcgui.Dialog().notification(ADDON_NAME, 'Error loading menu', xbmcgui.NOTIFICATION_ERROR)

        xbmcplugin.endOfDirectory(HANDLE)


    def list_content(self, url, force_show=False):
        xbmcplugin.setContent(HANDLE, 'files')
        
        try:
            r = requests.get(url, headers=HEADERS, timeout=15)
        except:
            xbmcgui.Dialog().notification(ADDON_NAME, 'Connection Error', xbmcgui.NOTIFICATION_ERROR)
            return

        html = r.text
        
        # --- DEPTH LOGIC ---
        path = urllib.parse.urlparse(url).path
        parts = [p for p in path.split('/') if p]
        
        depth = 0
        if 'webcams' in parts:
            idx = parts.index('webcams')
            depth = len(parts) - (idx + 1)
            
        # Depth 1: Region (Europe)
        # Depth 2: Country (Germany)
        # Depth 3: City (Berlin)

        subcategories = []
        cameras = []
        
        # 1. SUB-CATEGORIES SEARCH
        # Ψάχνουμε υποκατηγορίες ΜΟΝΟ αν δεν έχουμε πατήσει "Show All" (force_show)
        # και αν δεν είμαστε ήδη σε πόλη (depth < 3)
        if depth < 3 and not force_show:
            
            # A. Countries
            if depth == 1:
                c_match = re.search(r'<ul\s+class="dropdown-menu"\s+aria-labelledby="country-dropdown">(.*?)</ul>', html, re.DOTALL)
                if c_match:
                    self.parse_links(c_match.group(1), subcategories, '[COLOR gold]', '[/COLOR]')

            # B. Cities
            elif depth == 2:
                city_match = re.search(r'<ul\s+class="dropdown-menu"\s+aria-labelledby="city-dropdown">(.*?)</ul>', html, re.DOTALL)
                if city_match:
                    self.parse_links(city_match.group(1), subcategories, '[COLOR cyan]', '[/COLOR]')

        # 2. CAMERAS SEARCH
        # Εμφάνιση αν: Δεν υπάρχουν υποκατηγορίες OR βάθος >=3 OR έχουμε πατήσει "Show All"
        should_show_cameras = (len(subcategories) == 0) or (depth >= 3) or force_show or ('page=' in sys.argv[2] if len(sys.argv)>2 else False)

        if should_show_cameras:
            cam_pattern = r'<div class="place video-thumb">.*?<a href="(?P<href>[^"]+)".*?<img src="(?P<src>[^"]+)".*?alt="(?P<alt>[^"]+)".*?</div>'
            for m in re.finditer(cam_pattern, html, re.DOTALL):
                href = m.group('href')
                src = m.group('src')
                title = m.group('alt')
                if src.startswith('//'): src = 'https:' + src
                full_link = BASEURL + href
                cameras.append((title, full_link, src))

        # --- RENDER ---
        
        # Αν είμαστε σε Χώρα (Depth 2) και βρήκαμε Πόλεις, αλλά ΔΕΝ έχουμε πατήσει force_show
        if subcategories and depth == 2 and not force_show:
            
            # *** NEW: ADD "SHOW ALL" OPTION AT TOP ***
            # Προσθήκη επιλογής που ξαναφορτώνει την ίδια σελίδα αλλά με force_show=true
            self.add_item('[COLOR yellow]>> SHOW ALL CAMERAS (All Country)[/COLOR]', url, is_folder=True, extra_params={'force_show': 'true'})
            
            # Μετά εμφανίζουμε τις πόλεις
            for title, link in subcategories:
                self.add_item(title, link, is_folder=True)
                
        elif subcategories and depth < 3:
             # Για Regions (Depth 1) απλά δείχνουμε τις χώρες
             for title, link in subcategories:
                self.add_item(title, link, is_folder=True)

        else:
            # Δείχνουμε τις κάμερες
            for title, link, thumb in cameras:
                self.add_item(title, link, is_folder=False, icon=thumb)

        # Pagination
        next_match = re.search(r'<a class="btn btn-default next" href="([^"]+)"', html)
        if next_match:
            next_link = BASEURL + next_match.group(1)
            # Αν έχουμε πατήσει "Show All", πρέπει και η επόμενη σελίδα να κρατήσει την επιλογή
            extra = {'force_show': 'true'} if force_show else None
            self.add_item('[I]>> Next Page[/I]', next_link, is_folder=True, extra_params=extra)

        xbmcplugin.endOfDirectory(HANDLE)

    def parse_links(self, html_content, target_list, prefix, suffix):
        link_pattern = r'<a\s+href="([^"]+)">([^<]+)</a>'
        for m in re.finditer(link_pattern, html_content):
            link = m.group(1)
            name = m.group(2).strip()
            if "All" in name: continue
            full_link = BASEURL + link
            target_list.append((prefix + name + suffix, full_link))

    def resolve_video(self, url):
        try:
            r = requests.get(url, headers=HEADERS, timeout=15)
        except:
            self.resolve_error('Connection failed')
            return

        html = r.text
        token_match = re.search(r'(?:token=|token:)\s*[\'"](?P<token>[a-zA-Z0-9\.\-_]{15,})[\'"]', html)

        if not token_match:
            self.resolve_error('Token not found')
            return

        token = token_match.group('token')
        api_url = 'https://dapi-de.earthtv.com/api/v1/media.getPlayerConfig?playerToken=' + token
        
        try:
            r_api = requests.get(api_url, headers=HEADERS, timeout=15)
            data = r_api.json()
        except:
            self.resolve_error('API failed')
            return
        
        if 'streamUris' in data and 'hls' in data['streamUris']:
            stream_url = data['streamUris']['hls']
            # Pipe headers for Kodi ffmpeg
            headers_suffix = '|User-Agent=' + urllib.parse.quote(UA) + '&Referer=' + urllib.parse.quote(BASEURL)
            final_url = stream_url + headers_suffix
            
            li = xbmcgui.ListItem(path=final_url)
            li.setProperty('inputstream', '')
            li.setProperty('inputstreamaddon', '')
            xbmcplugin.setResolvedUrl(HANDLE, True, li)
        else:
            self.resolve_error('Stream not found')

    # --- HELPERS ---
    def add_item(self, title, url, is_folder, icon='', extra_params=None):
        li = xbmcgui.ListItem(label=title)
        if icon: li.setArt({'thumb': icon, 'icon': icon})
        
        if not is_folder:
            li.setProperty('IsPlayable', 'true')
            li.setInfo('video', {'title': title})
            
        u = sys.argv[0] + '?url=' + urllib.parse.quote(url)
        u += '&mode=folder' if is_folder else '&mode=play'
        
        # Add extra parameters if needed (like force_show)
        if extra_params:
            for k, v in extra_params.items():
                u += '&%s=%s' % (k, v)
            
        xbmcplugin.addDirectoryItem(HANDLE, u, li, isFolder=is_folder)

    def resolve_error(self, msg):
        li = xbmcgui.ListItem()
        xbmcplugin.setResolvedUrl(HANDLE, False, li)
        xbmcgui.Dialog().notification(ADDON_NAME, msg, xbmcgui.NOTIFICATION_ERROR)

# --- ENTRY POINT ---
if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    url = params.get('url')
    mode = params.get('mode')
    
    # Διαβάζουμε αν έχουμε ζητήσει "Show All"
    force_show = params.get('force_show') == 'true'
    
    addon = EarthTV()
    
    if mode == 'play':
        addon.resolve_video(url)
    elif mode == 'folder':
        addon.list_content(url, force_show)
    else:
        addon.show_main_menu()