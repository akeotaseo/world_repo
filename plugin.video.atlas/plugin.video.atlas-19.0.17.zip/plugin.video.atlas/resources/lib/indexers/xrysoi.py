# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
XRYSOI = control.setting('xrysoi.domain') or 'https://xrysoi.pro/'

Baseurl = 'https://xrysoi.pro/'

def menu():
    addDir('[COLOR white]Αναζήτηση ...[/COLOR]', '', 45, ART + 'search.png', FANART, '')
    addDir('[COLOR white]Νέες 2022[/COLOR]', Baseurl + 'category/tainiesonline/2022/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Ανά Έτος[/COLOR]', '', 52, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Κατηγορίες[/COLOR]', '', 51, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Ξένες Σειρές[/COLOR]', 'https://xrysoi.pro/category/%ce%be%ce%ad%ce%bd%ce%b5%cf%82-%cf%83%ce%b5%ce%b9%cf%81%ce%ad%cf%82/', 49, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Ελληνικές Ταινίες[/COLOR]', 'https://xrysoi.pro/category/%ce%b5%ce%bb%ce%bb-%cf%84%ce%b1%ce%b9%ce%bd%ce%af%ce%b5%cf%82/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Μεταγλωττισμένα[/COLOR]', 'https://xrysoi.pro/category/%ce%ba%ce%b9%ce%bd-%cf%83%cf%87%ce%ad%ce%b4%ce%b9%ce%b1/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Με ελληνικούς υπότιτλους[/COLOR]', Baseurl + 'category/category/1greeksubs/', 44, ART + 'xrysoi.png', FANART, '')
#    views.selectView('menu', 'menu-view')

def menu_genre(): #51
    addDir('[COLOR white]Ελλ-ταινίες[/COLOR]', 'https://xrysoi.pro/category/%ce%b5%ce%bb%ce%bb-%cf%84%ce%b1%ce%b9%ce%bd%ce%af%ce%b5%cf%82/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Περιπέτεια-Δράσης[/COLOR]', 'https://xrysoi.pro/category/%ce%b4%cf%81%ce%ac%cf%83%ce%b7%cf%82/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Κωμωδίες[/COLOR]', 'https://xrysoi.pro/category/%ce%ba%cf%89%ce%bc%cf%89%ce%b4%ce%af%ce%b5%cf%82/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Θρίλερ[/COLOR]', 'https://xrysoi.pro/category/%ce%b8%cf%81%ce%af%ce%bb%ce%b5%cf%81/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Τρόμου[/COLOR]', 'https://xrysoi.pro/category/%cf%84%cf%81%cf%8c%ce%bc%ce%bf%cf%85/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Επ-φαντασίας[/COLOR]', 'https://xrysoi.pro/category/%ce%b5%cf%80-%cf%86%ce%b1%ce%bd%cf%84%ce%b1%cf%83%ce%af%ce%b1%cf%82/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Φαντασίας[/COLOR]', 'https://xrysoi.pro/category/%cf%86%ce%b1%ce%bd%cf%84%ce%b1%cf%83%ce%af%ce%b1%cf%82/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Έγκλημα[/COLOR]', 'https://xrysoi.pro/category/%ce%ad%ce%b3%ce%ba%ce%bb%ce%b7%ce%bc%ce%b1/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Μυστήριο[/COLOR]', 'https://xrysoi.pro/category/%ce%bc%cf%85%cf%83%cf%84%ce%ae%cf%81%ce%b9%ce%bf/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Πολέμου[/COLOR]', 'https://xrysoi.pro/category/%cf%80%ce%bf%ce%bb%ce%ad%ce%bc%ce%bf%cf%85/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Γουέστερν[/COLOR]', 'https://xrysoi.pro/category/western/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Δράμα[/COLOR]', 'https://xrysoi.pro/category/%ce%b4%cf%81%ce%ac%ce%bc%ce%b1/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Ρομαντικές[/COLOR]', 'https://xrysoi.pro/category/%cf%81%ce%bf%ce%bc%ce%b1%ce%bd%cf%84%ce%b9%ce%ba%ce%ad%cf%82/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Ντοκιμαντέρ[/COLOR]', 'https://xrysoi.pro/category/%ce%bd%cf%84%ce%bf%ce%ba%ce%b9%ce%bc%ce%b1%ce%bd%cf%84%ce%ad%cf%81/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Χριστουγιεννιάτικες[/COLOR]', 'https://xrysoi.pro/category/x-mas/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Φιλμογραφίες[/COLOR]', 'https://xrysoi.pro/category/%cf%86%ce%b9%ce%bb%ce%bc%ce%bf%ce%b3%cf%81%ce%b1%cf%86%ce%af%ce%b5%cf%82/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Bollywood[/COLOR]', Baseurl + 'category/category/bollywood/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Anime-series[/COLOR]', Baseurl + 'category/category/anime/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Anime-movies[/COLOR]', Baseurl + 'category/category/animemovies/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]Συλλογές[/COLOR]', 'https://xrysoi.pro/category/collection/', 44, ART + 'xrysoi.png', FANART, '')
#    views.selectView('menu', 'menu-view')


def menu_year(): #52
    addDir('[COLOR white]2022[/COLOR]', Baseurl + 'category/tainiesonline/2022/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]2021[/COLOR]', Baseurl + 'category/tainiesonline/2021/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]2020[/COLOR]', Baseurl + 'category/tainiesonline/2020/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]2019[/COLOR]', Baseurl + 'category/tainiesonline/2019/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]2018[/COLOR]', Baseurl + 'category/tainiesonline/2018/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]2017[/COLOR]', Baseurl + 'category/tainiesonline/2017/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]2016[/COLOR]', Baseurl + 'category/tainiesonline/2016/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[COLOR white]2013-2015[/COLOR]', Baseurl + 'category/tainiesonline/new-good/', 44, ART + 'xrysoi.png', FANART, '')
#    views.selectView('menu', 'menu-view')


def xrysoimovies(url): #44
    hdrs = {'Referer': XRYSOI,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    try:
        m = re.compile('<div class=moviefilm>.+?<a href=(.+?)>.+?<img src=(.+?) alt="(.+?)".+?title=', re.DOTALL).findall(p)
    except IndexError:
        m = re.compile('<div class="moviefilm">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)".+?title=', re.DOTALL).findall(p)
    for url, icon, name in m:
        name = name.replace('-)',')').replace('- )',')')
        name = name.split('&#038;')[0].split('&#8217;')[0].split('&#8211;')[0]
        icon = icon.replace('-119x125', '')
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 43, icon, FANART, '')
    try:
        m = re.compile('<link rel=next href=(.+?)>').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 44, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
#    views.selectView('movies', 'movie-view')


def xrysoimovies_search(url): #53
    hdrs = {'Referer': XRYSOI,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    try:
        m = re.compile('<div class=moviefilm>.+?<a href=(.+?)>.+?<img src=(.+?) alt="(.+?)".+?title=', re.DOTALL).findall(p)
    except IndexError:
        m = re.compile('<div class="moviefilm">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)".+?title=', re.DOTALL).findall(p)
    for url, icon, name in m:
        name = name.replace('-)',')').replace('- )',')')
        name = clear_Title(name)
     #   name = name.split('&#038;')[0].split('&#8217;')[0].split('&#8211;')[0]
        icon = icon.replace('-119x125', '')
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 43, icon, FANART, '')
    try:
        m = re.compile('class=nextpostslink rel=next href="(.+?)">»</a>').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα [COLOR=white]>>[/COLOR][/B]', m, 53, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass


def get_links(name, url, iconimage, description): #43
    hdrs = {'Referer': XRYSOI,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m2 = re.compile('<iframe.+?src=(.+?)\s+').findall(p)
    for url in m2:
        if 'youtube' in url:
            Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
            addDir(Trailer, url, 100, ART + 'youtube.png', FANART, str(description))
    else:
        m = re.compile('href=(.+?)\s+').findall(p)
        t = re.compile('<h1><a href=.+?title="(.+?)" target=blank;>').findall(p)
        link_list = ['aparat', 'flashx', 'hdvid', 'vidd', 'vidoza', 'vidlox', 'estream', 'clipwatching', 'thevideo', 'vidzi']
        for url in m:
            for name in t:
                if any(x in url for x in link_list):
                    name = clear_Title(name)
                    addDir(name, url, 100, iconimage, FANART, str(description))


def get_links_series(name, url, iconimage, description): #54
    hdrs = {'Referer': XRYSOI,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m2 = re.compile('<iframe.+?src=(.+?)\s+').findall(p)
    for url in m2:
        if 'youtube' in url:
            Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
            addDir(Trailer, url, 100, ART + 'youtube.png', FANART, str(description))
    else:
         m = re.compile('<a href=(.+?)>(.+?)</a>').findall(p)
         t = re.compile('<h1><a href=.+?title="(.+?)" target=blank;>').findall(p)
         link_list = ['aparat', 'flashx', 'hdvid', 'vidd', 'vidoza', 'vidlox', 'estream', 'clipwatching', 'thevideo', 'vidzi']
         for url, epi in m:
            for name in t:
                epi = ' | Επεισόδιο ' + epi
            #    name = name + epi
                name = clear_Title(name)
                if any(x in url for x in link_list):
                    if 'Peaky Blinders' in name:
                        addDir(name, url, 100, iconimage, FANART, str(description))
                    elif 'The Blacklist' in name:
                        addDir(name, url, 100, iconimage, FANART, str(description))
                    else:
                        addDir((name+epi), url, 100, iconimage, FANART, str(description))


def search(url):
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = 'https://xrysoi.pro/?s=' + search
        xrysoimovies_search(url)


def xrysoiseries(url): #49
    hdrs = {'Referer': XRYSOI,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    try:
        m = re.compile('<div class=moviefilm>.+?<a href=(.+?)>.+?<img src=(.+?) alt="(.+?)".+?title=', re.DOTALL).findall(p)
    except IndexError:
        m = re.compile('<div class="moviefilm">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)".+?title=',
                       re.DOTALL).findall(p)
    for url, icon, name in m:
    #    if '-)' in name:
        name = name.replace('- )',')')

        name = clear_Title(name)
        icon = icon.replace('-119x125','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 54, icon, FANART, '')
    try:
        np=re.compile('a class=nextpostslink rel=next href=(.+?)>»</a>').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', np, 49, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except:
        pass
#    views.selectView('movies', 'movie-view')

def get_hdvids(url): #48
    c = 'Επεισόδιο..'
    p = client.request(url)
    m =re.compile('<a href=(.+?)>(.+?)</a>',re.DOTALL).findall(p)
    for url,name in m:
        if 'hdvid.tv' in url:
            c = 'Επεισόδιο...'
            addDir('[B][COLOR gold] %s[/COLOR][/B][B][COLOR blue]%s[/COLOR][/B]'%(c,name), url, 100, icon, FANART,'')

def search_series(): #50
        keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = 'https://xrysoi.pro/?s=' + search
                xrysoiseries(url)

def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')

    txt = txt.replace('(2005– )', '(2005)').replace('(2011– )', '(2011)').replace('(2017–)', '(2017)').replace('-)', ')').replace('- )', ')')
    txt = txt.replace('(TV Series 2011) Greek Subs', '').replace('Tv Series ', '').replace('TV Series ', '')
    txt = txt.replace('(Tv Series 2010)', '(2010)').replace(' (Tv Series 2010- )', '(2010)').replace(' (Tv Series 2011)', '(2011)').replace('(Tv Series 2011)', '(2011)')
    txt = txt.replace(' (Tv Series 2013)', '').replace('(Tv Series 2013)', '').replace('(TV Series 2013)', '').replace(' (TV Series 2013- )', '').replace('(TV Series 2013– )', '(2013)')
    txt = txt.replace(' (Tv Series 2006)', '').replace(' (Tv Series 2011- )', '').replace('(2013– )', '(2013)')
    return txt

