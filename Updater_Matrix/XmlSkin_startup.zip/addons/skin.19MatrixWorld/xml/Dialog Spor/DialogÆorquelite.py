﻿import xbmc, xbmcgui

def DialogΤorquelite():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/pvr_sport_search/search/Motorsport?include=14")')
    xbmcgui.Dialog().notification("[B][COLOR lime]Τorquelite[/COLOR][/B]", "[COLOR yellow]Today's Motorsport Schedule[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/Torque Lite.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR lime]Τorquelite[/COLOR][/B]", "[COLOR yellow]Today's Motorsport Schedule[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/Torque Lite.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR lime]Τorquelite[/COLOR][/B]", "[COLOR yellow]Today's Motorsport Schedule[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/Torque Lite.png')

DialogΤorquelite()
