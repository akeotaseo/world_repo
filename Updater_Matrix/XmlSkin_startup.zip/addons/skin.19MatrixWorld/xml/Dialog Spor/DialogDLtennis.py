﻿import xbmc, xbmcgui

def DialogDL():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/?mode=showChannels&trType=Tennis")')
    xbmcgui.Dialog().notification("[B][COLOR red]Daddylive[/COLOR][/B]", "[COLOR yellow]TENNIS[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/tennis.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR red]Daddylive[/COLOR][/B]", "[COLOR yellow]TENNIS[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/tennis.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR red]Daddylive[/COLOR][/B]", "[COLOR yellow]TENNIS[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/tennis.png')
DialogDL()
