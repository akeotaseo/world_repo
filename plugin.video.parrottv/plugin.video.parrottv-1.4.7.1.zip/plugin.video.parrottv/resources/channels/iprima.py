# Credits: https://github.com/cache-sk/plugin.video.freeview.sk

import requests

class iPrima:
    def __init__(self):
        self.ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'
        self.base = "http://p.xf.cz/iprima.php?ch="
        self.cnnprimanews = "https://api.play-backend.iprima.cz/api/v1/products/id-p650443/play"
    
    def grab(self,channel):
        headers = {'User-Agent': self.ua}
        if channel == "cnn":
            url = requests.get(self.cnnprimanews, headers=headers).json()['streamInfos'][0]['url']
        else:
            url = self.base + channel
        return url, headers