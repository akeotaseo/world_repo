import re
import xbmcaddon
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

def Menu():
	addDir('Latest Videos',      'https://mangovideo.pw/latest-updates/1/', 11, 'special://home/addons/plugin.video.xxx/resources/art/mangovideo.png')
	addDir('Top Rated Videos',   'https://mangovideo.pw/top-rated/',        11, 'special://home/addons/plugin.video.xxx/resources/art/mangovideo.png')
	addDir('Most Viewed Videos', 'https://mangovideo.pw/most-popular/',     11, 'special://home/addons/plugin.video.xxx/resources/art/mangovideo.png')
	addDir('Random Videos',      'RANDOM',                                  11, 'special://home/addons/plugin.video.xxx/resources/art/mangovideo.png')

def Browse(url):
	if url == 'RANDOM':
		import random
		page = random.randint(20,700)
		link = random.randint(0,2)
		if link == 0: url = 'https://mangovideo.pw/latest-updates/%s/' % str(page)
		if link == 1: url = 'https://mangovideo.pw/top-rated/%s/'      % str(page)
		if link == 2: url = 'https://mangovideo.pw/most-popular/%s/'   % str(page)
	r = OpenURL(url)
	r = r.replace('\n', '')
	r = r.replace('	', '')
	m = re.compile('<div class="item  ">(.+?)</a></div>').findall(r)
	for i in m:
		url   = re.compile('<a href="(.+?)"').findall(i)[0]
		thumb = re.compile('data-original="(.+?)"').findall(i)[0]
		time  = re.compile('<div class="duration">(.+?)</div>').findall(i)[0]
		title = re.compile('title="(.+?)"').findall(i)[0]
		if Setting('show_time') == 'true': title = '[B](%s)[/B] %s' % (time, title)
		items = []
		filters = ['Transexual', 'Gay', 'Bisexual', 'Bi ', 'Bi-Sexual', 'TS ', 'Tranny', 'Shemale']
		for filter in filters:
			if filter in title:
				pass
			else:
				if url not in items:
					thumb = thumb.replace('320x240/1.jpg', 'preview.jpg')
					import random
					random_id = random.randint(0,1000000)
					streamurl = '%s&random_id=%s' % (url, str(random_id))
					addVideo(title, streamurl, 13, thumb)
					items.append(url)
	n = re.compile('<li class="next"><a href="(.+?)"').findall(r)
	for page in n:
		addDir('Next page >', 'https://mangovideo.pw' + page, 11, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	Common.SetView()

def Categories(url):
	r = OpenURL(url)
	m = re.compile('<a class="item" href="https://mangovideo\.pw/categories/(.+?)/" title="(.+?)">').findall(r)
	for content_id, title in m:
		addDir(title, 'https://mangovideo.pw/categories/%s/' % content_id, 11, 'special://home/addons/plugin.video.xxx/resources/art/mangovideo.png')
	
def PlayStream(url):
	if 'random_id=' in url:
		url = re.compile('(.+?)&random_id').findall(url)[0]
	r = OpenURL(url)
	m = re.compile('<div id="contentdown" class="tab-content hidden">(.+?)</div>').findall(r)
	for url in m:
		Play(url)

