
ADDONS_REPOS = [('repository.Worldolympic', 'repository.World'),
                ('repository.World', 'repository.World'),
                ('repository.Worldrepo', 'repository.World')]