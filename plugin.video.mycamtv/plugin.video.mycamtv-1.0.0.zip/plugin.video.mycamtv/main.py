import os
import sys
from urllib.parse import urlencode, parse_qsl

import xbmc
import xbmcgui
import xbmcplugin
from xbmcaddon import Addon
from xbmcvfs import translatePath

import json
import requests

# Get the plugin url in plugin:// notation.
URL = sys.argv[0]
# Get a plugin handle as an integer number.
HANDLE = int(sys.argv[1])
# Get addon base path
ADDON_PATH = translatePath(Addon().getAddonInfo('path'))
ICONS_DIR = os.path.join(ADDON_PATH, 'resources', 'images', 'icons')
FANART_DIR = os.path.join(ADDON_PATH, 'resources', 'images', 'fanart')

settingsURL = 'https://mctapi.com/kodi.php?version=1.0.0'
settingsResponse = requests.get(settingsURL)
settings = json.loads(settingsResponse.content)

VIEW_MODE = 500





def get_url(**kwargs):
    return '{}?{}'.format(URL, urlencode(kwargs))


def list_main(sublisting, title):
    url = 'https://mctapi.com/list.php?'+sublisting
    html = requests.get(url)
    main_list = json.loads(html.content)
    xbmcplugin.setPluginCategory(HANDLE, title)
    xbmcplugin.setContent(HANDLE, 'videos')


    for index, item in enumerate(main_list):
        list_item = xbmcgui.ListItem(label=item['id'])
        list_item.setArt({'icon': item['icon'], 'fanart': item['fanart']})
        info_tag = list_item.getVideoInfoTag()
        info_tag.setMediaType('video')
        info_tag.setTitle(item['name'])
        if item['type'] == 'sublist':
            url = get_url(action='sublisting', list=item['filter'], title=item['name'])
        else:
            url = get_url(action='listing', api_filter=item['filter'], offset=0, title=item['name'])
        is_folder = True
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, is_folder)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)
    xbmc.executebuiltin('Container.SetViewMode(%d)' % VIEW_MODE)


def list_videos(api_filter,offset,title):
    xbmcplugin.setPluginCategory(HANDLE, title)
    xbmcplugin.setContent(HANDLE, 'videos')
    url = 'https://mctapi.com/api.php?' + api_filter + '&limit=' + str(settings['limit']) + '&skip=' + str(offset)
    html = requests.get(url)
    videos = json.loads(html.content)
    for video in videos:
        list_item = xbmcgui.ListItem(label=video['id'])
        list_item.setArt({'poster': video['live_image'],'fanart': 'https://mctapi.com/images/fanart.jpg'})
        info_tag = list_item.getVideoInfoTag()
        info_tag.setMediaType('video')
        info_tag.setTitle(video['name'])
        list_item.setProperty('IsPlayable', 'true')
        url = get_url(action='play', id=video['id'])
        is_folder = False
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, is_folder)

    list_item = xbmcgui.ListItem(label='Next Page')
    list_item.setArt({'icon': 'https://mctapi.com/images/next.png', 'fanart': 'https://mctapi.com/images/fanart.jpg'})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setMediaType('video')
    info_tag.setTitle('Next Page')
    url = get_url(action='listing', api_filter=api_filter, offset=settings['limit'] + int(offset), title=title)
    is_folder = True
    xbmcplugin.addDirectoryItem(HANDLE, url, list_item, is_folder)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)
    xbmc.executebuiltin('Container.SetViewMode(%d)' % VIEW_MODE)



def play_video(id):
    play_item = xbmcgui.ListItem(offscreen=True)
    play_item.setPath('https://mctapi.com/stream.php?id=' + id)
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)


def router(paramstring):
    params = dict(parse_qsl(paramstring))

    if not params:
        list_main('', 'Adult Live Webcams')
    elif params['action'] == 'listing':
        list_videos(params['api_filter'], offset=params['offset'], title=params['title'])
    elif params['action'] == 'play':
        play_video(params['id'])
    elif params['action'] == 'sublisting':
        list_main(sublisting=params['list'], title=params['title'])
    else:
        raise ValueError(f'Invalid paramstring: {paramstring}!')


if __name__ == '__main__':
    router(sys.argv[2][1:])
