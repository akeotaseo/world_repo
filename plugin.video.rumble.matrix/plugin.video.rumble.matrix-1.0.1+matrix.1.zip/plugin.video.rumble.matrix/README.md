I forked this from https://github.com/OnePlayHD/OneRepo as they had the GPL in their repo, but for whatever reason had the code for this addon obfuscated...so I deobfuscated, and fixed the regex for scraping stream URLs. 

I don't really want to maintain this addon and would love if someone out there would fork it and take the wheel from here, this code is a bit of a mess.

Credit goes to the original authors.
