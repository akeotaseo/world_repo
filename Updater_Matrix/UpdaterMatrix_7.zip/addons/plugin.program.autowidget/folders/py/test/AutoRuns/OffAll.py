﻿import xbmc



xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.downloader/stopservice",return)')