# -*- coding: utf-8 -*-

import xbmcgui, xbmc, os, sys
from lib import logger, config
from inputstreamhelper import Helper

if sys.version_info[0] >= 3:
    from xbmcvfs import translatePath
else:
    from xbmc import translatePath

from xbmcaddon import Addon
dialog = xbmcgui.Dialog()

ADDON_ID_PVR = 'pvr.iptvsimple'
ADDON_ID_LOGUPLOADER  = 'script.kodi.loguploader'
ADDON_ID_XMLTODICT    = 'script.module.xmltodict'
ADDON_ID_INPUTSTREAM  = 'inputstream.adaptive'
ADDON_ID_WEBPDB = 'script.module.web-pdb'
ADDON_ID_BOTTLE = 'script.module.bottle'

def install():
    ret = install_inputstream()
    install_widevine()
    if ret:
        dialog.notification( config.getString(30000), config.getString(30121) )

def install_log_uploader():
    return install_addon(ADDON_ID_LOGUPLOADER)

def install_pvr():
    return install_addon(ADDON_ID_PVR, 'PVR Simple Client', True)

def install_xml2dict():
    return install_addon(ADDON_ID_XMLTODICT)

def install_inputstream():
    return install_addon(ADDON_ID_INPUTSTREAM)

def install_widevine():
    if not Helper('mpd', drm='widevine').check_inputstream():
        Helper('mpd', drm='widevine').install_widevine()

def install_web_pdb():
    rc = None
    if install_addon(ADDON_ID_WEBPDB) and install_addon(ADDON_ID_BOTTLE):
        webpdb = Addon(ADDON_ID_WEBPDB) 
        bottle = Addon(ADDON_ID_BOTTLE)
        rc = config.translatePath(os.path.join(webpdb.getAddonInfo('Path'), 'libs')), config.translatePath(os.path.join(bottle.getAddonInfo('Path'), 'lib'))
    return rc

def install_addon(addonId, addonName='', askActivation=False):
    # Check if an addon is installed, if it doesn't, ask to install it.
    isInstalled = xbmc.getCondVisibility('System.HasAddon({})'.format(addonId))
    isActive = False

    if(not isInstalled):
        logger.info("{} seems to be not installed".format(addonId))
        xbmc.executebuiltin('InstallAddon({})'.format(addonId), wait=True)
        isInstalled = xbmc.getCondVisibility('System.HasAddon({})'.format(addonId))

    if isInstalled:
        try:
            # Check if it's active
            isActive = Addon(id=addonId) != None
        except:
            # if it's not active ask to activate it
            activate = True
            if askActivation:
                if not addonName:
                    addonName = addonId
                activate = dialog.yesno(config.getString(30000), config.getString(30111).format(addonName))
            if activate:
                xbmc.executeJSONRPC('{{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": {{ "addonid": "{}", "enabled": true }}}}'.format(addonId))
                isActive = Addon(id=addonId)

    return isInstalled and isActive
