import re, os, random, html
import xbmcaddon, xbmcvfs
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

Thumb   = 'special://home/addons/plugin.video.xxx/resources/art/goodporn.png'

def Browse():
	file = xbmcvfs.translatePath(os.path.join('special://userdata/addon_data/plugin.video.xxx', 'favourites.xml'))
	items = Common.OpenFile(file)
	videos = []
	entries = re.compile('<i title="(.+?)" icon="(.+?)" url="(.+?)" />').findall(items)
	for title, icon, url in entries:
		videos.append(
			{
				'title': title,
				'icon': icon,
				'url': url
			}
		)
	
	if Setting('rec_random') == 'true': random.shuffle(videos)
	for i in videos:
		if 'hqporner.com' in i['url']: mode = 123
		elif 'pornone.com' in i['url']: mode = 133
		elif 'xhand.com' in i['url']: mode = 93
		elif 'xtits.com' in i['url']: mode = 43
		elif 'xozilla.com' in i['url']: mode = 103
		elif 'freepornvideos.xxx' in i['url']: mode = 33
		else: Common.RemoveFavourites(i['url'], i['title'], i['icon'])
		
		if Setting('rec_watched') == 'true': url = '%s&random_id=%s' % (i['url'], RandomID())
		else: url = '%s&random_id=%s' % (i['url'], '00000')
		addVideo(html.unescape(i['title']), url, mode, i['icon'])
	
	Common.SetView()
	
def RandomID():
	import random
	random_id = str(random.randint(0,1000000))
	return random_id