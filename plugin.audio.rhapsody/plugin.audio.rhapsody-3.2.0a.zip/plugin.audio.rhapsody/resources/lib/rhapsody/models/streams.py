from rhapsody.models.metadata import *
from rhapsody import exceptions


class Detail(object):
    def __init__(self, data):
        self.streams = [Stream(x) for x in data['streams']]


class Stream(object):
    def __init__(self, data):
        self.format = Format(data['format'])
        self.url = data['url']
        self.token_server_url = data.get('tokenServerUrl')
        self.cdn_token = data.get('cdnToken')
        self.certificate_uri = data.get('certificateUri')


class Format(object):
    def __init__(self, data):
        self.name = data['name']
        self.bitrate = data['bitrate']
        self.sample_bits = data['sampleBits']
        self.sample_rate = data['sampleRate']


class Streams(MetadataDetail):
    FORMAT_AAC = 'AAC'
    FORMAT_AAC_PLUS = 'AAC PLUS'
    FORMAT_MP3 = 'MP3'
    # FORMAT_FLAC = 'FLAC'
    BITRATE_64 = 64
    BITRATE_128 = 128
    BITRATE_192 = 192
    BITRATE_320 = 320
    # BITRATE_44100 = 44100
    QUALITIES = (
        (FORMAT_AAC_PLUS, BITRATE_64),
        (FORMAT_MP3, BITRATE_128),
        (FORMAT_AAC, BITRATE_192),
        (FORMAT_AAC, BITRATE_320),
        # (FORMAT_FLAC, BITRATE_44100),
    )

    PROTOCOL_HLS = 'hls'
    PROTOCOL_MPD = 'mpd'

    DRM_FAIRPLAY = 'fairplay'
    DRM_PLAYREADY = 'playready'
    DRM_WIDEVINE = 'widevine'

    url_base = 'streams'
    detail_class = Detail
    cache_timeout = 600
    version = 'v2.2'

    def detail(self, obj_id, qualtity=None, **kwargs):
        if qualtity is None:
            qualtity = self.QUALITIES[0]

        protocol = kwargs.get('protocol', '')
        drm = kwargs.get('drm', '')

        audio_format, bitrate = qualtity

        if protocol and audio_format == self.FORMAT_MP3:
            raise exceptions.StreamingFormatUnsupportedError

        if not self._api.is_authenticated():
            raise exceptions.StreamingRightsError

        if drm:
            self.cache_timeout = 0

        params = kwargs.get('params', dict())
        params.update({
            'track': obj_id,
            'format': qualtity[0],
            'bitrate': qualtity[1],
            'catalog': self._api.account.catalog,
            'protocol': protocol,
            'drm': drm,
        })
        return super(Streams, self).detail(None, params=params)
