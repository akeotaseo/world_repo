from http.server import BaseHTTPRequestHandler
from socketserver import TCPServer
from urllib.parse import parse_qs, urlparse, urlencode,quote,unquote
#import base64
import re
import socket
from contextlib import closing
import requests
import sys
import xbmcaddon, xbmc, xbmcgui
addon = xbmcaddon.Addon('plugin.video.stream2watch')

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0'

class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):

    def do_HEAD(self):

        self.send_response(200)
        self.end_headers()

    def do_GET(self):
        """Handle http get requests, used for manifest"""

        path = self.path
        if 'BESTSOLARIS'in(self.path) and '.m3u8' in (self.path):#
            url=self.path.split('BESTSOLARIS=')[-1]
            try:
                result = requests.get(url, verify=False, timeout = 30).content
                result = result.decode(encoding='utf-8', errors='strict')
                replaceFROM = "https://playback.svcs.mlb.com/silk/events/"
                replaceTO = "http://bestsolaris.com/mlbkey.php?url="
                manifest_data = result.replace(replaceFROM,replaceTO)

                self.send_response(200)
                self.send_header('Content-type', 'application/x-mpegURL')
                self.end_headers()
                self.wfile.write(manifest_data.encode(encoding='utf-8', errors='strict'))
            except Exception:
                self.send_response(500)
                self.end_headers()

        if (self.path).endswith('.ts') and 'BESTSOLARIS=' in (self.path):#
            url=(self.path).split('BESTSOLARIS=')[-1]
            result=requests.get(url, verify=False, timeout = 30).content

            self.send_response(200)
            self.send_header('Content-type', 'application/vnd.apple.mpegurl')
            self.end_headers()

            self.wfile.write(result)

        else:

            return

    #def do_POST(self):


def find_free_port():
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
        s.bind(('', 0))
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        addon.setSetting('proxyport',str(s.getsockname()[1]))
        return s.getsockname()[1]


address = '127.0.0.1'  # Localhost

port = find_free_port()
server_inst = TCPServer((address, port), SimpleHTTPRequestHandler)
# The follow line is only for test purpose, you have to implement a way to stop the http service!
server_inst.serve_forever()