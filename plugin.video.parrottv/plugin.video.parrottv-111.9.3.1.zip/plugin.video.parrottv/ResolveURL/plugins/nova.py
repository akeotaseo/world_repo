# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests
from ..utils.browser import Firefox
from ..utils.resolve import Resolver
from ..utils.common import genIP

class Nova(Resolver):
    def __init__(self):
        self.channels = {
            'nova':'https://media.cms.nova.cz/embed/nova-live?autoplay=1',
            'novafun':'https://media.cms.nova.cz/embed/nova-fun-live?autoplay=1',
            'novacinema':'https://media.cms.nova.cz/embed/nova-cinema-live?autoplay=1',
            'novaaction':'https://media.cms.nova.cz/embed/nova-action-live?autoplay=1',
            'novalady':'https://media.cms.nova.cz/embed/nova-lady-live?autoplay=1',
            'novagold':'https://media.cms.nova.cz/embed/nova-gold-live?autoplay=1'
        }

    def grab(self, channel):
        if channel not in self.channels: return 'Channel not found'
        firefox = Firefox()
        firefox.addHeader("Referer", "https://tv.nova.cz/")

        hlsurl = ""
        attempts = 0
        while attempts <= 10:
            firefox.addHeader("X-Forwarded-For", genIP("CZ"))
            r = requests.get(self.channels[channel], headers=firefox.headers)
            if "processAdTagModifier" in r.text:
                hlsurl = r.text.split('processAdTagModifier({"tracks":{"HLS":[{"src":"')[1].split('","')[0].replace('\/','/')
                firefox.addHeader("Referer", self.channels[channel])
                return hlsurl, firefox.headers
            attempts += 1
        return "", {}