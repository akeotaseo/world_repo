### service.py
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import os
import sys

ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')
ADDON_PATH = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
LIB_PATH = os.path.join(ADDON_PATH, 'resources', 'lib')
sys.path.append(LIB_PATH)

from epg import start_background_epg_load, ADDON_DATA_PATH

def ensure_epg_folder():
    if not xbmcvfs.exists(ADDON_DATA_PATH):
        xbmc.log("[EPG] Folder inexistent. Îl creez înainte de start_background_epg_load.", xbmc.LOGINFO)
        try:
            xbmcvfs.mkdirs(ADDON_DATA_PATH)
        except Exception as e:
            xbmc.log(f"[EPG] Eroare mkdirs: {e}. Încearcă os.makedirs...", xbmc.LOGWARNING)
            try:
                os.makedirs(ADDON_DATA_PATH, exist_ok=True)
                xbmc.log("[EPG] Folder creat cu os.makedirs.", xbmc.LOGINFO)
            except Exception as ose:
                xbmc.log(f"[EPG] Eroare os.makedirs: {ose}", xbmc.LOGERROR)


class EPGService(xbmc.Monitor):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.started = False
        self.addon = xbmcaddon.Addon()

    def onSettingsChanged(self):
        pass

    def onScreensaverActivated(self):
        pass

    def onScreensaverDeactivated(self):
        pass

    def onXBMCStarted(self):
        if not self.started and self.addon.getSettingBool("load_epg_at_startup"):
            xbmc.log(f"[{ADDON_ID}] Serviciul EPG pornit la startul Kodi.", xbmc.LOGINFO)
            xbmcgui.Dialog().notification("OHA", "Încărcare EPG la pornire...", xbmcgui.NOTIFICATION_INFO, 3000)
            show_progress("Se încarcă EPG...", start_background_epg_load)
            self.started = True
        elif not self.started:
            xbmc.log(f"[{ADDON_ID}] Încărcarea EPG la startul Kodi este dezactivată.", xbmc.LOGINFO)
            self.started = True

def show_progress(message, func):
    xbmc.executebuiltin('ActivateWindow(busydialog)')
    xbmc.log(f"[EPG] {message}", xbmc.LOGINFO)
    try:
        ensure_epg_folder()
        func()
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialog)')

if __name__ == '__main__':
    monitor = EPGService()
    while not monitor.abortRequested():
        if not monitor.started and xbmc.getCondVisibility('Window.IsVisible(Home)'):
            monitor.onXBMCStarted()
        xbmc.sleep(1000)
    xbmc.log(f"[{ADDON_ID}] Serviciul EPG oprit.", xbmc.LOGINFO)
    xbmcgui.Dialog().notification("OHA", "Serviciul EPG s-a oprit.", xbmcgui.NOTIFICATION_INFO, 3000)
