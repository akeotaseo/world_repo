# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests
import random
from string import ascii_lowercase, ascii_uppercase, digits
import uuid
import time
from ..utils.browser import Firefox
from ..utils.resolve import Resolver
from ..utils.localstorage import readFromStorage, writeToStorage
from ..utils.common import genIP


ALPHABET = ascii_lowercase + ascii_uppercase + digits

def emailGenerator():
    email = ""
    for i in range(random.randint(5,13)):
        email += random.choice(ALPHABET)
    email += "@gmail.com"
    return email

def passwordGenerator():
    password = ""
    for i in range(22):
        password += random.choice(ALPHABET)
    return password

class SweetTV(Resolver):
    def __init__(self):
        self.UUID = str(uuid.uuid4())
        self.versionString = "3.1.04"
        self.device = "1;22;0;2;3.1.04"
        self.firefox = Firefox()
        self._initHeaders()

    def _initHeaders(self):
        sweetHeaders = {}
        sweetHeaders["Accept"] = "application/json, text/plain, */*"
        sweetHeaders["Accept-Language"] = "en"
        sweetHeaders["Content-Type"] = "application/json"
        sweetHeaders["X-Device"] = self.device
        sweetHeaders["Origin"] = "https://sweet.tv"
        sweetHeaders["Referer"] = "https://sweet.tv/"
        self.firefox.addHeaders(sweetHeaders)

    def getM3U8(self, token, channelID):
        url = "https://api.sweet.tv/TvService/OpenStream.json"
        self.firefox.addHeader("Authorization", "Bearer " + token)
        data = '{"channel_id":"'+str(channelID)+'","accept_scheme":["HTTP_HLS"],"multistream":true}'
        resp = requests.post(url, headers=self.firefox.headers, data=data).json()
        address = resp["http_stream"]["host"]["address"]
        port = resp["http_stream"]["host"]["port"]
        url = resp["http_stream"]["url"]
        hlsUrl = "http://{address}:{port}{url}".format(address=address, port=port, url=url)
        return hlsUrl

    # Idk why but this site uses one api for login and register
    def login(self, email, password):
        url = "https://api.sweet.tv/SigninService/Email.json"
        self.firefox.removeHeader("Authorization")
        data = '{"device":{"type":"DT_Web_Browser","application":{"type":"AT_SWEET_TV_Player"},"model":"'+self.firefox.ua+'","firmware":{"versionCode":1,"versionString":"'+self.versionString+'"},"uuid":"'+self.UUID+'","supported_drm":{"widevine_modular":true}},"email":"'+email+'","password":"'+password+'"}'
        resp = requests.post(url, headers=self.firefox.headers, data=data).json()
        return {'refresh_token': resp['refresh_token'], 'access_token': resp['access_token'], 'expires_in': int(time.time()) + (3 * 60 * 60)}

    def genCreds(self):
        email = emailGenerator()
        password = passwordGenerator()
        if self.username and self.password:
            email = self.username
            password = self.password
        resp = self.login(email, password)
        # Now + 6 days
        expire = int(time.time()) + (6 * 24 * 60 * 60)
        jsonf = {
            'email': email,
            'password': password,
            'expire': expire
        }
        writeToStorage("SweetTVcreds", jsonf, p=self.parent.data_file)
        return resp['access_token']

    def grab(self, channel):
        self.firefox.addHeader("X-Forwarded-For", genIP("SK"))
        token = ""
        if readFromStorage("SweetTVcreds", p=self.parent.data_file) != "":
            creds = readFromStorage("SweetTVcreds", p=self.parent.data_file)
            if time.time() > creds['expire']:
                token = self.genCreds()
            else:
                token = self.login(creds['email'], creds['password'])['access_token']
        else:
            token = self.genCreds()
        hlsUrl = self.getM3U8(token, channel)

        if 'Authorization' not in self.firefox.headers: self.firefox.addHeader('Authorization', 'Bearer ' + token)
        return hlsUrl, self.firefox.headers
