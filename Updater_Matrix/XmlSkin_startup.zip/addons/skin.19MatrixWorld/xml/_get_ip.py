import xbmc
import xbmcgui
import urllib.request
import json
import sys

# Αποτροπή διπλών εκτελέσεων (π.χ. σε ReloadSkin)
if xbmcgui.Window(10000).getProperty('IPServiceRunning') == 'true':
    sys.exit()

xbmcgui.Window(10000).setProperty('IPServiceRunning', 'true')
monitor = xbmc.Monitor()

def get_ip_data():
    try:
        req = urllib.request.Request('http://ip-api.com/json/', headers={'User-Agent': 'Mozilla/5.0'})
        response = urllib.request.urlopen(req, timeout=5).read().decode('utf8')
        data = json.loads(response)
        
        # Καθαρός διαχωρισμός επιτυχίας / απρόσμενης απάντησης
        if data.get('status') == 'success':
            xbmcgui.Window(10000).setProperty('MyWANIP', data.get('query', 'N/A'))
            xbmcgui.Window(10000).setProperty('MyCountry', data.get('country', ''))
        else:
            xbmcgui.Window(10000).setProperty('MyWANIP', 'N/A')
            xbmcgui.Window(10000).setProperty('MyCountry', '')
            
    except Exception:
        xbmcgui.Window(10000).setProperty('MyWANIP', 'Σφάλμα')
        xbmcgui.Window(10000).setProperty('MyCountry', '')

# Το ΜΟΝΑΔΙΚΟ request που θα γίνει κατά την εκκίνηση του Kodi
get_ip_data()

# Αθόρυβη λούπα παρασκηνίου
while not monitor.abortRequested():
    if xbmcgui.Window(10000).getProperty('TriggerIPCheck') == 'true':
        xbmcgui.Window(10000).clearProperty('TriggerIPCheck')
        get_ip_data() # Τρέχει μόνο όταν επιστρέφεις στο Home
        
    # Έλεγχος κάθε 3 δευτερόλεπτα (Ελαφρύτερο για τη CPU)
    if monitor.waitForAbort(3):
        break

# Καθαρισμός κατά το κλείσιμο του Kodi
xbmcgui.Window(10000).clearProperty('IPServiceRunning')