import sys, json
import xbmc, xbmcgui
import xbmcplugin
import xbmcvfs, xbmcaddon
import os, re
import json
import requests
import six
import webbrowser

try:
    from sqlite3 import dbapi2 as database
except BaseException:
    from pysqlite2 import dbapi2 as database
from urllib.parse import unquote_plus
from resources.lib.modules import client
from resources.lib.modules import cache
from resources.lib.modules import control
from resources.lib.modules import init
from resources.lib.modules import views
from resources.lib.modules import domparser as dom
from resources.lib.modules.control import addDir
from resources.lib.modules import utils
from resources.lib.modules.params import p
from resources.lib.modules import yt_playlists
from resources.lib.modules.parser import Parser
from six.moves.urllib_parse import urlparse, urlencode, urljoin, unquote, unquote_plus, quote, quote_plus, parse_qsl

BASEURL = 'https://tenies-online1.gr/genre/kids/'  # 'https://paidikestainies.online/'
GAMATO = control.setting('gamato.domain') or 'http://gamatotv.info/'  # 'https://gamatokid.com/'
Teniesonline = control.setting('tenies.domain') or 'https://tenies-online1.gr/'
XRYSOI = control.setting('xrysoi.domain') or 'https://xrysoi.pro/'
GAMATOMOVIES = control.setting('gamatomovies.domain') or 'https://gamatomovies.gr/'
ANYMOVIES = control.setting('anymovies.domain') or 'https://www.downloads-anymovies.co/'
OIPEIRATES = control.setting('oipeirates.domain') or 'https://oipeirates.club/'
TAINIOMANIA = control.setting('tainio-mania.domain') or 'https://tainio-mania.online/'
MYVIDEOLINKS = control.setting('myvideolinks.domain') or 'https://to.myvideolinks.net/'
COOLMOVIEZONE = control.setting('coolmoviezone') or 'https://coolmoviezone.watch/'

ADDON = xbmcaddon.Addon()
ADDON_DATA = ADDON.getAddonInfo('profile')
ADDON_PATH = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART = ADDON.getAddonInfo('fanart')
ICON = ADDON.getAddonInfo('icon')
ID = ADDON.getAddonInfo('id')
NAME = ADDON.getAddonInfo('name')
VERSION = ADDON.getAddonInfo('version')
Lang = control.lang#ADDON.getLocalizedString
Dialog = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"

addon_id = xbmcaddon.Addon().getAddonInfo('id')
translatePath = xbmcvfs.translatePath
addon_id = xbmcaddon.Addon().getAddonInfo('id')
addon = xbmcaddon.Addon(addon_id)
addoninfo = addon.getAddonInfo
addon_version = addoninfo('version')
addon_name = addoninfo('name')
addon_icon = addoninfo("icon")
addon_fanart = addoninfo("fanart")
addon_profile = translatePath(addoninfo('profile'))
addon_path = translatePath(addoninfo('path'))
setting = addon.getSetting
setting_set = addon.setSetting
local_string = addon.getLocalizedString
home = translatePath('special://home/')
dialog = xbmcgui.Dialog()
dp = xbmcgui.DialogProgress()
addons_path = os.path.join(home, 'addons/')
user_path = os.path.join(home, 'userdata/')
data_path = os.path.join(user_path, 'addon_data/')
packages = os.path.join(addons_path, 'packages/')
resources = os.path.join(addon_path, 'resources/')
xml_folder = os.path.join(resources, 'xml/')
yt_xml = xml_folder + 'main.json'
yt1_xml = xml_folder + 'kids.json'
yt2_xml = xml_folder + 'doc.json'
yt3_xml = xml_folder + 'greek.json'
yt4_xml = xml_folder + 'omades.json'
yt5_xml = xml_folder + 'fishing.json'

user_agent = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36'
headers = {'User-Agent': user_agent}
handle = int(sys.argv[1])
addDir2 = utils.addDir

xbmc.log(str(p.get_params()),xbmc.LOGDEBUG)


def Main_addDir():
    addDir('[B][COLOR white]' + Lang(32002) + ' ...[/COLOR][/B]', '', 6, ART + 'search.png', FANART, '')
    addDir('[B][COLOR white]Ξένες Ταινίες[/COLOR][/B]', '', 10, 'http://i.imgur.com/cTv0fXe.png', FANART, '')
    addDir('[B][COLOR white]Ξένες Σειρές[/COLOR][/B]', '', 11, 'http://i.imgur.com/ypLPk5x.png', FANART, '')
    addDir('[B][COLOR white]Παιδική Χαρά[/COLOR][/B]', '', 80, 'http://i.imgur.com/T8NlaOf.png', FANART, '')
    addDir('[B][COLOR white]Ελληνικές Ταινίες[/COLOR][/B]', '', 13, 'http://i.imgur.com/QGC87GD.png', FANART, '')
    addDir('[B][COLOR white]Ασπρόμαυρες Ταινίες[/COLOR][/B]', '', 104, 'http://i.imgur.com/cTv0fXe.png', FANART, '')
    addDir('[B][COLOR white]Ντοκιμαντέρ[/COLOR][/B]', '', 81, 'http://i.imgur.com/jTaJF0B.png', FANART, '')
    addDir('[B][COLOR white]Ομάδες[/COLOR][/B]', '', 64, 'http://i.imgur.com/edOpGQt.png', FANART, '')
    addDir('[B][COLOR white]Ψάρεμα[/COLOR][/B]', '', 65, 'https://i.imgur.com/9SvI277.png', FANART, '')
    downloads = True if control.setting('downloads') == 'true' and (
            len(control.listDir(control.setting('movie.download.path'))[0]) > 0 or
            len(control.listDir(control.setting('tv.download.path'))[0]) > 0) else False
    if downloads:
        addDir('[B][COLOR white]Downloads[/COLOR][/B]', '', 40, 'https://i.imgur.com/2cPUPkf.png', FANART, '')
    addDir('[B][COLOR white]' + Lang(32020) + '[/COLOR][/B]', '', 17, 'https://i.imgur.com/2cPUPkf.png', FANART, '')
    addDir('[B][COLOR white]' + Lang(32021) + '[/COLOR][/B]', '', 9, 'https://i.imgur.com/2cPUPkf.png', FANART, '')
    addDir('[B][COLOR white]' + Lang(32019) + ': [COLOR lime]%s[/COLOR][/B]' % vers, '', 'bug', ICON, FANART, '')


def Movies_maim():
    addDir('[B][COLOR white]' + Lang(32002) + ' ...[/COLOR][/B]', '', 6, ART + 'search.png', FANART, '')
    addDir('[B][COLOR white]Νέες -[COLOR coral] Tainio-mania[/COLOR][/B]', TAINIOMANIA + 'load/tainies-2022/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR white]Έτος -[COLOR coral] Tainio-mania[/COLOR][/B]', '', 86, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR white]Κατηγορίες -[COLOR coral] Tainio-mania[/COLOR][/B]', '', 87, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR white]Νέες -[COLOR gold] Xrysoi[/COLOR][/B]', XRYSOI + 'category/tainiesonline/2022/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR white]Έτος -[COLOR gold] Xrysoi[/COLOR][/B]', '', 52, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR white]Κατηγορίες -[COLOR gold] Xrysoi[/COLOR][/B]', '', 51, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR white]Νέες -[COLOR blue] Gamato[/COLOR][/B]', GAMATO + 'release/2022/', 2, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR white]Έτος -[COLOR blue] Gamato[/COLOR][/B]', GAMATO + 'movies/', 22, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR white]Κατηγορίες -[COLOR blue] Gamato[/COLOR][/B]', GAMATO + 'movies/', 23, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR white]Νέες (Δημοφιλείς) -[COLOR deeppink] GamatoMovies[/COLOR][/B]', GAMATOMOVIES + 'tainies/slider/', 122, ART + 'gamatomovies.png', FANART, '')
    addDir('[B][COLOR white]Τελευταίες Προσθήκες -[COLOR deeppink] GamatoMovies[/COLOR][/B]', GAMATOMOVIES + 'tainies/online/', 122, ART + 'gamatomovies.png', FANART, '')
    addDir('[B][COLOR white]Έτος -[COLOR deeppink] GamatoMovies[/COLOR][/B]', GAMATOMOVIES + 'tainies/online/', 124, ART + 'gamatomovies.png', FANART, '')
    addDir('[B][COLOR white]Κατηγορίες -[COLOR deeppink] GamatoMovies[/COLOR][/B]', GAMATOMOVIES + 'movies/', 125, ART + 'gamatomovies.png', FANART, '')
    addDir('[B][COLOR white]Νέες -[COLOR purple] Anymovies[/COLOR][/B]', 'https://www.downloads-anymovies.co/movies/search.php?zoom_query=2022', 94, ART + 'anymovies.png', FANART, '')
    addDir('[B][COLOR white]Έτος -[COLOR purple] Anymovies[/COLOR][/B]', '', 91, ART + 'anymovies.png', FANART, '')
    addDir('[B][COLOR white]Κατηγορίες -[COLOR purple] Anymovies[/COLOR][/B]', '', 92, ART + 'anymovies.png', FANART, '')
    addDir('[B][COLOR white]Ταινίες -[COLOR cyan] Coolmoviezone[/COLOR][/B]', 'https://coolmoviezone.watch/movies/', 109, ART + 'coolmoviezone.png', FANART, '')
    addDir('[B][COLOR white]Έτος -[COLOR cyan] Coolmoviezone[/COLOR][/B]', '', 107, ART + 'coolmoviezone.png', FANART, '')
    addDir('[B][COLOR white]Κατηγορίες -[COLOR cyan] Coolmoviezone[/COLOR][/B]', '', 108, ART + 'coolmoviezone.png', FANART, '')
    addDir('[B][COLOR white]2022 -[COLOR tomato] Myvideolinks[/COLOR][/B]', 'https://to.myvideolinks.net/category/movies-download/2022/', 102, ART + 'myvideolinks.png', FANART, '')
    addDir('[B][COLOR white]Older -[COLOR tomato] Myvideolinks[/COLOR][/B]', 'https://to.myvideolinks.net/category/movies/older-movies/', 102, ART + 'myvideolinks.png', FANART, '')
    addDir('[B][COLOR white]3D Ταινίες -[COLOR tomato] Myvideolinks[/COLOR][/B]', 'https://to.myvideolinks.net/category/movies/3-d/', 102, ART + 'myvideolinks.png', FANART, '')
    addDir('[B][COLOR white]Έτος -[COLOR red] OiPeirates[/COLOR][/B]', 'https://oipeirates.club/genre/2020/', 97, ART + 'oipeirates.png', FANART, '')
    addDir('[B][COLOR white]Κατηγορίες -[COLOR red] OiPeirates[/COLOR][/B]', 'https://oipeirates.club/genre/2020/', 98, ART + 'oipeirates.png', FANART, '')
    addDir('[B][COLOR white]Έτος -[COLOR green] Tainiesonline[/COLOR][/B]', Teniesonline, 36, ART + 'tainiesonline.png', FANART, '')
    addDir('[B][COLOR white]Κατηγορίες -[COLOR green] Tainiesonline[/COLOR][/B]', Teniesonline, 37, ART + 'tainiesonline.png', FANART, '')
    addDir('[B][COLOR white]Περισσότερες προβολές -[COLOR green] Tainiesonline[/COLOR][/B]', Teniesonline + 'trending/', 34, ART + 'tainiesonline.png', FANART, '')
    addDir('[B][COLOR white]Υψηλότερη βαθμολογία -[COLOR green] Tainiesonline[/COLOR][/B]', Teniesonline + 'ratings/', 34, ART + 'tainiesonline.png', FANART, '')


def Series_maim():
    addDir('[B][COLOR white]' + Lang(32002) + ' ...[/COLOR][/B]', '', 6, ART + 'search.png', FANART, '')
    addDir('[B][COLOR white]Ξένες Σειρές -[COLOR coral] Tainio-mania[/COLOR][/B]', TAINIOMANIA + 'load/seir/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR white]Ξένες Σειρές -[COLOR gold] Xrysoi[/COLOR][/B]', 'https://xrysoi.pro/category/%ce%be%ce%ad%ce%bd%ce%b5%cf%82-%cf%83%ce%b5%ce%b9%cf%81%ce%ad%cf%82/', 49, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR white]Ξένες Σειρές -[COLOR blue] Gamato[/COLOR][/B]', GAMATO + 'tvshows/', 4, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR white]Ξένες Σειρές -[COLOR deeppink] GamatoMovies[/COLOR][/B]', GAMATOMOVIES + 'tainies/tv-series/', 126, ART + 'gamatomovies.png', FANART, '')
    addDir('[B][COLOR white]Ξένες Σειρές -[COLOR red] OiPeirates[/COLOR][/B]', 'https://oipeirates.club/genre/seires/', 112, ART + 'oipeirates.png', FANART, '')
    addDir('[B][COLOR white]Ξένες Σειρές -[COLOR coral] Myvideolinks[/COLOR][/B]', 'https://to.myvideolinks.net/category/tv-shows/', 102, ART + 'myvideolinks.png', FANART, '')
    addDir('[B][COLOR white]Ξένες Σειρές (Complete Seasons)-[COLOR coral] Myvideolinks[/COLOR][/B]', 'https://to.myvideolinks.net/category/tv-shows/complete-seasons/', 102, ART + 'myvideolinks.png', FANART, '')
    addDir('[B][COLOR white]Ξένες Σειρές -[COLOR cyan] Coolmoviezone[/COLOR][/B]', 'https://coolmoviezone.watch/category/tv-series/', 114, ART + 'coolmoviezone.png', FANART, '')
    addDir('[B][COLOR white]Anime Σειρές -[COLOR gold] Xrysoi[/COLOR][/B]', 'https://xrysoi.pro/category/category/anime/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR white]Anime Σειρές -[COLOR blue] Gamato[/COLOR][/B]', GAMATO + 'genre/anime/', 4, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR white]Anime Σειρές -[COLOR red] OiPeirates[/COLOR][/B]', 'https://oipeirates.club//genre/anime/', 96, ART + 'oipeirates.png', FANART, '')


def Greek_maim():
    addDir('[B][COLOR white]' + Lang(32002) + ' ...[/COLOR][/B]', '', 6, ART + 'search.png', FANART, '')
    addDir('[B][COLOR white]Ελλ. Ταινίες You[COLOR red]Tube[/COLOR][/B]', '', 63, ART + 'youtube.png', FANART, '')
    addDir('[B][COLOR white]Ελληνικές Ταινίες -[COLOR gold] Xrysoi[/COLOR][/B]', 'https://xrysoi.pro/category/%ce%b5%ce%bb%ce%bb-%cf%84%ce%b1%ce%b9%ce%bd%ce%af%ce%b5%cf%82/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR white]Ελληνικές Ταινίες -[COLOR coral] Tainio-mania[/COLOR][/B]', TAINIOMANIA + 'load/ellhnik_tain_e/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR white]Ελληνικές Ταινίες -[COLOR deeppink] GamatoMovies[/COLOR][/B]', GAMATOMOVIES + 'tainies/elliniki-tainia/', 122, ART + 'gamatomovies.png', FANART, '')
    addDir('[B][COLOR white]Ελληνικές Ταινίες -[COLOR red] OiPeirates[/COLOR][/B]', 'https://oipeirates.club/genre/ell-tainies/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[B][COLOR white]Ελληνικές Ταινίες -[COLOR green] Tainiesonline[/COLOR][/B]', 'https://tenies-online1.gr/genre/ellinikes/', 34, ART + 'tainiesonline.png', FANART, '')


def kids_menu():
    addDir('[B][COLOR white]' + Lang(32002) + ' ...[/COLOR][/B]', '', 6, ART + 'search.png', FANART, '')
    addDir('[B][COLOR white]Παιδικά You[COLOR red]Tube[/COLOR][/B]', '', 61, ART + 'youtube.png', FANART, '')
    addDir('[B][COLOR white]Παιδικά μεταγλωττισμένα[COLOR gold] Xrysoi[/COLOR][/B]', 'https://xrysoi.pro/category/%ce%ba%ce%b9%ce%bd-%cf%83%cf%87%ce%ad%ce%b4%ce%b9%ce%b1/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR white]Παιδικά με υπότιτλους[COLOR gold] Xrysoi[/COLOR][/B]', 'https://xrysoi.pro/category/%ce%ba%ce%b9%ce%bd-%cf%83%cf%87%ce%ad%ce%b4%ce%b9%ce%b1-subs/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR white]Παιδικά μεταγλωττισμένα[COLOR coral] Tainio-mania[/COLOR][/B]', TAINIOMANIA + 'load/metaglwtismena-paidika-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR white]Κινούμενα σχέδια[COLOR coral] Tainio-mania[/COLOR][/B]', TAINIOMANIA + 'load/kino_mena_sch_dia/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR white]Παιδικά μεταγλωττισμένα[COLOR blue] Gamato[/COLOR][/B]', GAMATO + 'genre/gamato/', 4, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR white]Παιδικά με υπότιτλους[COLOR blue] Gamato[/COLOR][/B]', GAMATO + 'genre/κινούμενα-σχέδια/', 4, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR white]Κινούμενα σχέδια[COLOR deeppink] GamatoMovies[/COLOR][/B]', GAMATOMOVIES + 'tainies/animation/', 122, ART + 'gamatomovies.png', FANART, '')
    addDir('[B][COLOR white]Παιδικά μεταγλωττισμένα[COLOR red] OiPeirates[/COLOR][/B]', 'https://oipeirates.club/genre/kin-sxedia/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[B][COLOR white]Παιδικά με υπότιτλους[COLOR red] OiPeirates[/COLOR][/B]', 'https://oipeirates.club/genre/kin-sxedia-subs/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[B][COLOR white]Παιδικά μεταγλωττισμένα[COLOR green] Tainiesonline[/COLOR][/B]', 'https://tenies-online1.gr/genre/kids/', 34, ART + 'tainiesonline.png', FANART, '')
    addDir('[B][COLOR white]Κινούμενα σχέδια[COLOR green] Tainiesonline[/COLOR][/B]', 'https://tenies-online1.gr/genre/κινούμενα-σχέδια/', 34, ART + 'tainiesonline.png', FANART, '')
    addDir('[B][COLOR white]Ταινίες Anime [COLOR gold]Xrysoi[/COLOR][/B]', 'https://xrysoi.pro/category/category/animemovies/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR white]Σειρές Anime [COLOR gold]Xrysoi[/COLOR][/B]', 'https://xrysoi.pro/category/category/anime/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR white]Ταινίες Anime [COLOR blue] Gamato[/COLOR][/B]', GAMATO + 'genre/animation/', 4, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR white]Σειρές Anime...[COLOR blue] Gamato[/COLOR][/B]', GAMATO + 'genre/anime/', 4, ART + 'gamato.png', FANART, '')


def documentary_menu():
    addDir('[B][COLOR white]' + Lang(32002) + ' ...[/COLOR][/B]', '', 6, ART + 'search.png', FANART, '')
    addDir('[B][COLOR white]Ντοκιμαντέρ You[COLOR red]Tube[/COLOR][/B]', '', 62, ART + 'youtube.png', FANART, '')
    addDir('[B][COLOR white]Ντοκιμαντέρ[COLOR red] Ntokimanter[/COLOR][/B]', '', 117, ART + 'ntokimanter.png', FANART, '')
    addDir('[B][COLOR white]Ντοκιμαντέρ[COLOR coral] Tainio-mania[/COLOR][/B]', TAINIOMANIA + 'load/ntokimant_r/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR white]Ντοκιμαντέρ[COLOR gold] Xrysoi[/COLOR][/B]', 'https://xrysoi.pro/category/%ce%bd%cf%84%ce%bf%ce%ba%ce%b9%ce%bc%ce%b1%ce%bd%cf%84%ce%ad%cf%81/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR white]Ντοκιμαντέρ[COLOR blue] Gamato[/COLOR][/B]', GAMATO + 'genre/%ce%bd%cf%84%ce%bf%ce%ba%cf%85%ce%bc%ce%b1%ce%bd%cf%84%ce%ad%cf%81/', 4, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR white]Ντοκιμαντέρ[COLOR deeppink] GamatoMovies[/COLOR][/B]', GAMATOMOVIES + 'tainies/documentary/', 122, ART + 'gamatomovies.png', FANART, '')
    addDir('[B][COLOR white]Ντοκιμαντέρ[COLOR purple] Anymovies[/COLOR][/B]', 'https://www.downloads-anymovies.co/movies/search.php?zoom_query=Documentary', 94, ART + 'anymovies.png', FANART, '')
    addDir('[B][COLOR white]Ντοκιμαντέρ[COLOR cyan] Coolmoviezone[/COLOR][/B]', COOLMOVIEZONE + 'category/documentary/', 114, ART + 'coolmoviezone.png', FANART, '')
    addDir('[B][COLOR white]Ντοκιμαντέρ[COLOR red] OiPeirates[/COLOR][/B]', 'https://oipeirates.club/genre/documentary/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[B][COLOR white]Ντοκιμαντέρ[COLOR green] Tainiesonline[/COLOR][/B]', 'https://tenies-online1.gr/genre/ntokimanter/', 34, ART + 'tainiesonline.png', FANART, '')


def gamato_genre():
    addDir('[COLOR white]Δράση[/COLOR]', GAMATO + 'genre/%ce%b4%cf%81%ce%ac%cf%83%ce%b7/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Περιπέτεια[/COLOR]', GAMATO + 'genre/%cf%80%ce%b5%cf%81%ce%b9%cf%80%ce%ad%cf%84%ce%b5%ce%b9%ce%b1/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Αστυνομική[/COLOR]', GAMATO + 'genre/%ce%b1%cf%83%cf%84%cf%85%ce%bd%ce%bf%ce%bc%ce%b9%ce%ba%ce%ae/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Επ. Φαντασίας[/COLOR]', GAMATO + 'genre/%ce%b5%cf%80-%cf%86%ce%b1%ce%bd%cf%84%ce%b1%cf%83%ce%af%ce%b1%cf%82/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Πολεμική[/COLOR]', GAMATO + 'genre/%cf%80%ce%bf%ce%bb%ce%b5%ce%bc%ce%b9%ce%ba%ce%ae/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Western[/COLOR]', GAMATO + 'genre/western/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Δράμα[/COLOR]', GAMATO + 'genre/%ce%b4%cf%81%ce%ac%ce%bc%ce%b1/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Θρίλερ[/COLOR]', GAMATO + 'genre/%ce%b8%cf%81%ce%af%ce%bb%ce%b5%cf%81/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Ιστορική[/COLOR]', GAMATO + 'genre/%ce%b9%cf%83%cf%84%ce%bf%cf%81%ce%b9%ce%ba%ce%ae/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Κινούμενα σχέδια[/COLOR]', GAMATO + 'genre/%ce%ba%ce%b9%ce%bd%ce%bf%cf%8d%ce%bc%ce%b5%ce%bd%ce%b1-%cf%83%cf%87%ce%ad%ce%b4%ce%b9%ce%b1/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Κωμωδία[/COLOR]', GAMATO + 'genre/%ce%ba%cf%89%ce%bc%cf%89%ce%b4%ce%af%ce%b1/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Μεταγλωτισμένα[/COLOR]', GAMATO + 'genre//gamato/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Μουσική[/COLOR]', GAMATO + 'genre/%ce%bc%ce%bf%cf%85%cf%83%ce%b9%ce%ba%ce%ae/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Μυστηρίου[/COLOR]', GAMATO + 'genre/%ce%bc%cf%85%cf%83%cf%84%ce%b7%cf%81%ce%af%ce%bf%cf%85/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Ντοκιμαντέρ[/COLOR]', GAMATO + 'genre/%ce%bd%cf%84%ce%bf%ce%ba%cf%85%ce%bc%ce%b1%ce%bd%cf%84%ce%ad%cf%81/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Οικογενειακή[/COLOR]', GAMATO + 'genre/%ce%bf%ce%b9%ce%ba%ce%bf%ce%b3%ce%b5%ce%bd%ce%b5%ce%b9%ce%b1%ce%ba%ce%ae/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Ρομαντική[/COLOR]', GAMATO + 'genre/%cf%81%ce%bf%ce%bc%ce%b1%ce%bd%cf%84%ce%b9%ce%ba%ce%ae/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Τρόμου[/COLOR]', GAMATO + 'genre/%cf%84%cf%81%cf%8c%ce%bc%ce%bf%cf%85/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Φαντασίας[/COLOR]', GAMATO + 'genre/%cf%86%ce%b1%ce%bd%cf%84%ce%b1%cf%83%ce%af%ce%b1%cf%82/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Film-Noir[/COLOR]', GAMATO + 'genre/film-noir/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Χριστουγεννιάτικες[/COLOR]', GAMATO + 'genre/christmas/', 4, ART + 'gamato.png', FANART, '')


def gamato_years():
    addDir('[COLOR white]2022[/COLOR]', GAMATO + 'release/2022', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2021[/COLOR]', GAMATO + 'release/2021', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2020[/COLOR]', GAMATO + 'release/2020', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2019[/COLOR]', GAMATO + 'release/2019', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2018[/COLOR]', GAMATO + 'release/2018', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2017[/COLOR]', GAMATO + 'release/2017', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2016[/COLOR]', GAMATO + 'release/2016', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2015[/COLOR]', GAMATO + 'release/2015', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2014[/COLOR]', GAMATO + 'release/2014', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2013[/COLOR]', GAMATO + 'release/2013', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2012[/COLOR]', GAMATO + 'release/2012', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2011[/COLOR]', GAMATO + 'release/2011', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2010[/COLOR]', GAMATO + 'release/2010', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2009[/COLOR]', GAMATO + 'release/2009', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2008[/COLOR]', GAMATO + 'release/2008', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2007[/COLOR]', GAMATO + 'release/2007', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2006[/COLOR]', GAMATO + 'release/2006', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2005[/COLOR]', GAMATO + 'release/2005', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2004[/COLOR]', GAMATO + 'release/2004', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2003[/COLOR]', GAMATO + 'release/2003', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2002[/COLOR]', GAMATO + 'release/2002', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2001[/COLOR]', GAMATO + 'release/2001', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]2000[/COLOR]', GAMATO + 'release/2000', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1999[/COLOR]', GAMATO + 'release/1999', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1998[/COLOR]', GAMATO + 'release/1998', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1997[/COLOR]', GAMATO + 'release/1997', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1996[/COLOR]', GAMATO + 'release/1996', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1995[/COLOR]', GAMATO + 'release/1995', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1994[/COLOR]', GAMATO + 'release/1994', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1993[/COLOR]', GAMATO + 'release/1993', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1992[/COLOR]', GAMATO + 'release/1992', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1991[/COLOR]', GAMATO + 'release/1991', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1990[/COLOR]', GAMATO + 'release/1990', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1989[/COLOR]', GAMATO + 'release/1989', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1988[/COLOR]', GAMATO + 'release/1988', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1987[/COLOR]', GAMATO + 'release/1987', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1986[/COLOR]', GAMATO + 'release/1986', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1985[/COLOR]', GAMATO + 'release/1985', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1984[/COLOR]', GAMATO + 'release/1984', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1983[/COLOR]', GAMATO + 'release/1983', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1982[/COLOR]', GAMATO + 'release/1982', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1981[/COLOR]', GAMATO + 'release/1981', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1980[/COLOR]', GAMATO + 'release/1980', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1979[/COLOR]', GAMATO + 'release/1979', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1978[/COLOR]', GAMATO + 'release/1978', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1977[/COLOR]', GAMATO + 'release/1977', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1976[/COLOR]', GAMATO + 'release/1976', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1975[/COLOR]', GAMATO + 'release/1975', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1974[/COLOR]', GAMATO + 'release/1974', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1973[/COLOR]', GAMATO + 'release/1973', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1972[/COLOR]', GAMATO + 'release/1972', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1971[/COLOR]', GAMATO + 'release/1971', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1970[/COLOR]', GAMATO + 'release/1970', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1969[/COLOR]', GAMATO + 'release/1969', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1968[/COLOR]', GAMATO + 'release/1968', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1967[/COLOR]', GAMATO + 'release/1967', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1966[/COLOR]', GAMATO + 'release/1966', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1965[/COLOR]', GAMATO + 'release/1965', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1964[/COLOR]', GAMATO + 'release/1964', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1963[/COLOR]', GAMATO + 'release/1963', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1962[/COLOR]', GAMATO + 'release/1962', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1961[/COLOR]', GAMATO + 'release/1961', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1960[/COLOR]', GAMATO + 'release/1960', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1959[/COLOR]', GAMATO + 'release/1959', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1958[/COLOR]', GAMATO + 'release/1958', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1957[/COLOR]', GAMATO + 'release/1957', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1956[/COLOR]', GAMATO + 'release/1956', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1955[/COLOR]', GAMATO + 'release/1955', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1954[/COLOR]', GAMATO + 'release/1954', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1953[/COLOR]', GAMATO + 'release/1953', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1952[/COLOR]', GAMATO + 'release/1952', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1951[/COLOR]', GAMATO + 'release/1951', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1950[/COLOR]', GAMATO + 'release/1950', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1949[/COLOR]', GAMATO + 'release/1949', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1948[/COLOR]', GAMATO + 'release/1948', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1947[/COLOR]', GAMATO + 'release/1947', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1946[/COLOR]', GAMATO + 'release/1946', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1945[/COLOR]', GAMATO + 'release/1945', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1944[/COLOR]', GAMATO + 'release/1944', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1943[/COLOR]', GAMATO + 'release/1943', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1942[/COLOR]', GAMATO + 'release/1942', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1941[/COLOR]', GAMATO + 'release/1941', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1940[/COLOR]', GAMATO + 'release/1940', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1939[/COLOR]', GAMATO + 'release/1939', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1938[/COLOR]', GAMATO + 'release/1938', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1937[/COLOR]', GAMATO + 'release/1937', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1936[/COLOR]', GAMATO + 'release/1936', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1935[/COLOR]', GAMATO + 'release/1935', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1934[/COLOR]', GAMATO + 'release/1934', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1933[/COLOR]', GAMATO + 'release/1933', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1932[/COLOR]', GAMATO + 'release/1932', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1931[/COLOR]', GAMATO + 'release/1931', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1930[/COLOR]', GAMATO + 'release/1930', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1929[/COLOR]', GAMATO + 'release/1929', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1928[/COLOR]', GAMATO + 'release/1928', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1927[/COLOR]', GAMATO + 'release/1927', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1926[/COLOR]', GAMATO + 'release/1926', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1925[/COLOR]', GAMATO + 'release/1925', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1924[/COLOR]', GAMATO + 'release/1924', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1923[/COLOR]', GAMATO + 'release/1923', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1922[/COLOR]', GAMATO + 'release/1922', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1921[/COLOR]', GAMATO + 'release/1921', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]1920[/COLOR]', GAMATO + 'release/1920', 4, ART + 'gamato.png', FANART, '')


def MainYoutube(_xml):
    xml = Parser(_xml)
    items = xml.get_list()
    video_ids = []
    for item in json.loads(items)['items']:
        link = item.get('link')
        if 'video/' in link or 'youtu.be/' in link:
            video_ids.append(link.split('/')[-1])
        elif link.endswith('.json'):
            if link.startswith('http'):
                addDir2(item.get('title','Unknown'), item.get('link',''), 56, item.get('icon', addon_icon), item.get('fanart', addon_fanart), item.get('summary','Playlists from Youtube'))
            else:
                addDir2(item.get('title','Unknown'),xml_folder+item.get('link',''), 56, item.get('icon', addon_icon), item.get('fanart', addon_fanart), item.get('summary','Playlists from Youtube'))
        else:
            addDir2(item.get('title','Unknown'),item.get('link',''), 59, item.get('icon', addon_icon), item.get('fanart', addon_fanart), item.get('summary','Playlists from Youtube'))
    video_list = yt_playlists.get_videos(video_ids)
    try:
        for title, video_id, icon, description, duration, date in video_list:
            yt_playlists.addDir2(title, 'plugin://plugin.video.youtube/play/?video_id=%s'%video_id,3,icon, icon, description, duration=duration, date='Date Published: '+str(date)+'\n', isFolder=False)
    except:
        pass


def yt_playlist(link):
    if link.startswith('http'):
        if 'list=' in link:
            link = link.split('list=')[-1]
    elif link.startswith('plugin'):
        link = link.split('playlist/')[-1].replace('/','')
    yt_playlists.get_playlist_items(link)

def yt_channel(_id):
    yt_playlists.ch_playlists(_id)

def play_video(title, link, iconimage):
    video = unquote_plus(link)
    liz = xbmcgui.ListItem(title)
    liz.setInfo('video', {'Title': title})
    liz.setArt({'thumb': iconimage, 'icon': iconimage})
    xbmc.Player().play(video,liz)


def year(url):
    r = cache.get(client.request, 120, url)
    r = client.parseDOM(r, 'div', attrs={'id': 'moviehome'})[0]
    r = client.parseDOM(r, 'div', attrs={'class': 'filtro_y'})[0]
    r = client.parseDOM(r, 'li')
    for post in r:
        try:
            url = client.parseDOM(post, 'a', ret='href')[0]
            year = client.parseDOM(post, 'a')[0].encode('utf-8')
        except IndexError:
            year = '[N/A]'

        addDir('[B][COLOR white]%s[/COLOR][/B]' % year, url, 5, ART + 'movies.jpg', FANART, '')
#    views.selectView('menu', 'menu-view')


def Get_TV_Genres(url):  # 7
    r = cache.get(client.request, 120, url)
    r = client.parseDOM(r, 'div', attrs={'id': 'serieshome'})[0]
    r = client.parseDOM(r, 'div', attrs={'class': 'categorias'})[0]
    r = client.parseDOM(r, 'li', attrs={'class': 'cat-item.+?'})
    for post in r:
        try:
            url = client.parseDOM(post, 'a', ret='href')[0]
            name = client.parseDOM(post, 'a')[0]
            name = re.sub(r'\d{4}', '', name)
            items = client.parseDOM(post, 'span')[0].encode('utf-8')
        except BaseException:
            pass
        name = clear_Title(name) + ' ([COLORlime]' + items + '[/COLOR])'
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 5, ART + 'tvshows.jpg', FANART, '')
#    views.selectView('menu', 'menu-view')


def year_TV(url):
    r = cache.get(client.request, 120, url)
    r = client.parseDOM(r, 'div', attrs={'id': 'serieshome'})[0]
    r = client.parseDOM(r, 'h3', attrs={'class': 'g1-gamma g1-gamma-1st entry-title'})[0]
    r = client.parseDOM(r, 'h3')
    for post in r:
        try:
            url = client.parseDOM(post, 'a', ret='href')[0]
            year = client.parseDOM(post, 'a')[0].encode('utf-8')
        except BaseException:
            pass
        addDir('[B][COLOR white]%s[/COLOR][/B]' % year, url, 5, ART + 'tvshows.jpg', FANART, '')
#    views.selectView('menu', 'menu-view')


def Get_random(url):  # 8
    r = client.request(url)
    r = client.parseDOM(r, 'div', attrs={'id': 'slider1'})[0]
    r = client.parseDOM(r, 'div', attrs={'class': 'item'})
    for post in r:
        try:
            url = client.parseDOM(post, 'a', ret='href')[0]
            icon = client.parseDOM(post, 'img', ret='src')[0]
            name = client.parseDOM(post, 'span', attrs={'class': 'ttps'})[0].encode('utf-8')
            name = re.sub('\d{4}', '', name)
        except BaseException:
            pass
        try:
            year = client.parseDOM(post, 'span', attrs={'class': 'ytps'})[0].encode('utf-8')
        except BaseException:
            year = 'N/A'

        name = clear_Title(name)
        if '/ ' in name:
            name = name.split('/ ')
            name = name[1] + ' ([COLOR lime]' + year + '[/COLOR])'
        elif '\ ' in name:
            name = name.split('\ ')
            name = name[1] + ' ([COLOR lime]' + year + '[/COLOR])'
        else:
            name = name + ' ([COLOR lime]' + year + '[/COLOR])'
        if 'tvshows' in url or 'syllogh' in url:
            addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 11, icon, FANART, '')
        else:
            addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 10, icon, FANART, '')
#    views.selectView('menu', 'menu-view')


def Get_epoxiakes(url):  # 19
    try:
        r = client.request(url)
        r = client.parseDOM(r, 'div', attrs={'id': 'slider2'})[0]
        if r is None:
            control.infoDialog('Δεν υπάρχουν διαθέσιμοι τίτλοι αυτήν την περίοδο', NAME, ICON, 7000)
        else:
            r = client.parseDOM(r, 'div', attrs={'class': 'item'})
    except BaseException:
        r = []

    for post in r:
        try:
            url = client.parseDOM(post, 'a', ret='href')[0]
            icon = client.parseDOM(post, 'img', ret='src')[0]
            name = client.parseDOM(post, 'span', attrs={'class': 'ttps'})[0].encode('utf-8')
            name = re.sub(r'\d{4}', '', name)
        except BaseException:
            pass
        try:
            year = client.parseDOM(post, 'span', attrs={'class': 'ytps'})[0].encode('utf-8')
        except BaseException:
            year = 'N/A'

        name = clear_Title(name)
        if '/ ' in name:
            name = name.split('/ ')
            name = name[1] + ' ([COLOR lime]' + year + '[/COLOR])'
        elif '\ ' in name:
            name = name.split('\ ')
            name = name[1] + ' ([COLOR lime]' + year + '[/COLOR])'
        else:
            name = name + ' ([COLOR lime]' + year + '[/COLOR])'
        if 'tvshows' in url or 'syllogh' in url:
            addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 11, icon, FANART, '')
        else:
            addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 10, icon, FANART, '')
#    views.selectView('menu', 'menu-view')


def Get_content(url):  # 5
    r = cache.get(client.request, 4, url)
    data = client.parseDOM(r, 'div', attrs={'id': 'mt-\d+'})
    for post in data:
        try:
            url = client.parseDOM(post, 'a', ret='href')[0]
            icon = client.parseDOM(post, 'img', ret='src')[0]
            name = client.parseDOM(post, 'span', attrs={'class': 'tt'})[0]
            name = re.sub(r'\d{4}', '', name)
            desc = client.parseDOM(post, 'span', attrs={'class': 'ttx'})[0]
        except BaseException:
            pass
        try:
            year = client.parseDOM(post, 'span', attrs={'class': 'year'})[0].encode('utf-8')
        except BaseException:
            year = 'N/A'
        try:
            calidad = client.parseDOM(post, 'span', attrs={'class': 'calidad2'})[0].encode('utf-8')
            calidad = calidad.replace('Μεταγλωτισμένο', 'Μετ').replace('Ελληνικοί Υπότιτλοι', 'Υποτ')
            if '/' in calidad:
                calidad = Lang(32014)
            elif 'Προσ' in calidad:
                calidad = Lang(32017)
            elif calidad == 'Μετ':
                calidad = Lang(32015)
            else:
                calidad = Lang(32016)
        except BaseException:
            calidad = 'N/A'

        desc = clear_Title(desc)
        name = clear_Title(name)
        if '/ ' in name:
            name = name.split('/ ')
            name = name[1] + ' ([COLORlime]' + year + '[/COLOR])'
        elif '\ ' in name:
            name = name.split('\ ')
            name = name[1] + ' ([COLORlime]' + year + '[/COLOR])'
        else:
            name = name + ' ([COLORlime]' + year + '[/COLOR])'
        if 'tvshows' in url or 'syllogh' in url:
            addDir('[B][COLOR white]{0} [{1}][/COLOR][/B]'.format(name, calidad), url, 11, icon, FANART, desc)
        else:
            addDir('[B][COLOR white]{0} [{1}][/COLOR][/B]'.format(name, calidad), url, 10, icon, FANART, desc)
    try:
        np = re.compile('class="pag_b"><a href="(.+?)"', re.DOTALL).findall(r)
        for url in np:
            page = re.compile('page/(\d+)/', re.DOTALL).findall(url)[0]
            page = '[B][COLOR lime]' + page + '[B][COLOR white])[/B][/COLOR]'
            addDir('[B][COLOR gold]>>>' + Lang(32011) + '[/COLOR] [COLOR white](%s' % page, url, 5,
                   ART + 'next.jpg', FANART, '')
    except BaseException:
        pass
#    views.selectView('menu', 'menu-view')


def get_tenies_online_links(url):
    urls = []

    headers = {'User-Agent': client.randomagent(),
               'Referer': url}
    #r = client.request(url)
    r = requests.get(url).text
    try:
        frames = client.parseDOM(r, 'div', {'id': 'playeroptions'})[0]
        frames = dom.parse_dom(frames, 'li', attrs={'class': 'dooplay_player_option'},
                               req=['data-post', 'data-nume', 'data-type'])
        for frame in frames:
            post = 'action=doo_player_ajax&post=%s&nume=%s&type=%s' % \
                   (frame.attrs['data-post'], frame.attrs['data-nume'], frame.attrs['data-type'])
            if '=trailer' in post: continue
            p_link = 'https://tenies-online1.gr/wp-admin/admin-ajax.php'

            #flink = client.request(p_link, post=post, headers=headers)
            flink = requests.post(p_link, data=post, headers=headers).text
            flink = client.parseDOM(flink, 'iframe', ret='src')[0]

            host = __top_domain(flink)
            urls.append((flink, host))
        # xbmc.log('FRAMES-LINKs: %s' % urls)
    except BaseException:
        pass

    try:
        extra = client.parseDOM(r, 'div', attrs={'class': 'links_table'})[0]
        extra = dom.parse_dom(extra, 'td')
        extra = [dom.parse_dom(i.content, 'img', req='src') for i in extra if i]
        extra = [(i[0].attrs['src'], dom.parse_dom(i[0].content, 'a', req='href')) for i in extra if i]
        extra = [(re.findall('domain=(.+?)$', i[0])[0], i[1][0].attrs['href']) for i in extra if i]
        for item in extra:
            url = item[1]
            if 'paidikestainies' in url:
                continue
            if 'tenies-online' in url:
                url = client.request(url, output='geturl', redirect=True)
            else:
                url = url

            host = item[0]

            urls.append((url, host))
        # xbmc.log('EXTRA-LINKs: %s' % urls)
    except BaseException:
        pass

    return urls


def __top_domain(url):
    elements = urlparse(url)
    domain = elements.netloc or elements.path
    domain = domain.split('@')[-1].split(':')[0]
    regex = "(?:www\.)?([\w\-]*\.[\w\-]{2,3}(?:\.[\w\-]{2,3})?)$"
    res = re.search(regex, domain)
    if res: domain = res.group(1)
    domain = domain.lower()
    return domain


# def Trailer(url):
#     lcookie = cache.get(_Login, 4, BASEURL)
#     OPEN = cache.get(client.request, 4, url, True, True, False, None, None, None, False, None, None, lcookie)
#     patron = 'class="youtube_id.+?src="([^"]+)".+?></iframe>'
#     trailer_link = find_single_match(OPEN, patron)
#     trailer_link = trailer_link.replace('//www.', 'http://')
#     return trailer_link


def search_menu():  # 6
    addDir(' Νέα αναζήτηση...', 'new', 26, ART + 'search.png', FANART, '')

    dbcon = database.connect(control.searchFile)
    dbcur = dbcon.cursor()

    try:
        dbcur.execute("""CREATE TABLE IF NOT EXISTS Search (url text, search text)""")
    except BaseException:
        pass

    dbcur.execute("SELECT * FROM Search ORDER BY search")

    lst = []

    delete_option = False
    for (url, search) in dbcur.fetchall():
        search = six.ensure_str(search, errors='replace')
        if 'tainiomania' in url:
            _url = 'https://tainio-mania.online/?story=' + search + '&titleonly=3&do=search&subaction={}'.format(quote_plus(search))
            domain = '[COLOR coral]TAINIO-MANIA[/COLOR]'
        elif 'gamato' in url:
            _url = GAMATO + "?s={}".format(quote_plus(search))
            domain = '[COLOR green]GAMATO[/COLOR]'
        elif 'xrysoi' in url:
            _url = XRYSOI + "?s={}".format(quote_plus(search))
            domain = '[COLOR gold]XRYSOI[/COLOR]'
        elif 'gamatomovies' in url:
            _url = GAMATOMOVIES + "?s={}".format(quote_plus(search))
            domain = '[COLOR green]GAMATOMOVIES[/COLOR]'
        elif 'oipeirates' in url:
            _url = OIPEIRATES + "?s={}".format(quote_plus(search))
            domain = '[COLOR red]OIPEIRATES[/COLOR]'
        elif 'coolmoviezone' in url:
            _url = COOLMOVIEZONE + "?s={}".format(quote_plus(search))
            domain = '[COLOR cyan]COOLMOVIEZONE[/COLOR]'
        elif 'myvideolinks' in url:
            _url = MYVIDEOLINKS + "?s={}".format(quote_plus(search))
            domain = '[COLOR tomato]MYVIDEOLINKS[/COLOR]'
        elif 'anymovies' in url:
            _url = ANYMOVIES + "search.php?zoom_query={}".format(quote_plus(search))
            domain = '[COLOR purple]ANYMOVIES[/COLOR]'
        else:
            _url = Teniesonline + "?s={}".format(quote_plus(search))
            domain = '[COLOR blue]TENIES-ONLINE[/COLOR]'
        title = '[B]%s[/B] - [COLOR gold][B]%s[/COLOR][/B]' % (search, domain)
        delete_option = True
        addDir(title, _url, 26, ART + 'search.png', FANART, '')
        lst += [(search)]
    dbcur.close()

    if delete_option:
        addDir(Lang(32039), '', 29, ICON, FANART, '')
  #  views.selectView('movies', 'movie-view')


def Search2(url):  # 266
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
    keyb.doModal()
    if keyb.isConfirmed():
        search = quote_plus(keyb.getText())
        if six.PY2:
            term = unquote_plus(search).decode('utf-8')
        else:
            term = unquote_plus(search)

        dbcon = database.connect(control.searchFile)
        dbcur = dbcon.cursor()

        dp = xbmcgui.Dialog()

        select = dp.select('                                       Επιλογή Ιστότοπου',
                          ['[COLOR coral][B]                                                      Tainio-mania[/COLOR][/B]',
                           '[COLOR green][B]                                                          Gamato[/COLOR][/B]',
                           '[COLOR gold][B]                                                   Xrysoi - [COLOR white]Ταινίες[/COLOR][/B]',
                           '[COLOR gold][B]                                                    Xrysoi - [COLOR white]Σειρές[/COLOR][/B]',
                           '[COLOR deeppink][B]                                                    GamatoMovies - [COLOR white]Ταινίες[/COLOR][/B]',
                           '[COLOR deeppink][B]                                                    GamatoMovies - [COLOR white]Σειρές[/COLOR][/B]',
                           '[COLOR red][B]                                                         OiPeirates[/COLOR][/B]',
                           '[COLOR cyan][B]                                                    Coolmoviezone[/COLOR][/B]',
                           '[COLOR tomato][B]                                                       Myvideolinks[/COLOR][/B]',
                           '[COLOR purple][B]                                                         Anymovies[/COLOR][/B]',
                           '[COLOR blue][B]                                                      Tenies-Online[/COLOR][/B]'])

        if select == 0:
            from resources.lib.indexers import tainiomania
            url = 'https://tainio-mania.online/?story=' + search + '&titleonly=3&do=search&subaction=search'.format(search)
            dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
            dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
            dbcon.commit()
            dbcur.close()
            tainiomania.tainiomania(url)

        elif select == 1:
            url = GAMATO + "?s={}".format(search)
            dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
            dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
            dbcon.commit()
            dbcur.close()
            Search_gamato(url)

        elif select == 2:
            from resources.lib.indexers import xrysoi
            url = XRYSOI + "?s={}".format(search)
            dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
            dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
            dbcon.commit()
            dbcur.close()
            xrysoi.xrysoimovies_search(url)

        elif select == 3:
            from resources.lib.indexers import xrysoi
            url = XRYSOI + "?s={}".format(search)
            dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
            dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
            dbcon.commit()
            dbcur.close()
            xrysoi.xrysoimovies_search_series(url)

        elif select == 4:
            from resources.lib.indexers import gamatomovies
            url = GAMATOMOVIES + "?s={}".format(search)
            dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
            dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
            dbcon.commit()
            dbcur.close()
            gamatomovies.gamatomovies(url)

        elif select == 5:
            from resources.lib.indexers import gamatomovies
            url = GAMATOMOVIES + "?s={}".format(search)
            dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
            dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
            dbcon.commit()
            dbcur.close()
            gamatomovies.gamatomoviestv(url)

        elif select == 6:
            from resources.lib.indexers import oipeirates
            url = OIPEIRATES + "?s={}".format(search)
            dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
            dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
            dbcon.commit()
            dbcur.close()
            oipeirates.oipeirates(url)

        elif select == 7:
            from resources.lib.indexers import coolmoviezone
            url = COOLMOVIEZONE + "index.php?s={}".format(search)
            dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
            dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
            dbcon.commit()
            dbcur.close()
            coolmoviezone.coolmoviezone_2(url)

        elif select == 8:
            from resources.lib.indexers import myvideolinks
            url = MYVIDEOLINKS + "?s={}".format(search)
            dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
            dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
            dbcon.commit()
            dbcur.close()
            myvideolinks.myvideolinks(url)

        elif select == 9:
            from resources.lib.indexers import anymovies
            url = ANYMOVIES + "search.php?zoom_query={}".format(search)
            dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
            dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
            dbcon.commit()
            dbcur.close()
            anymovies.anymovies(url)

        elif select == 10:
            from resources.lib.indexers import teniesonline
            url = Teniesonline + "?s={}".format(search)
            dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
            dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
            dbcon.commit()
            dbcur.close()
            teniesonline.search(url)

        else:
            return
    else:
        return



def Search(url):  # 26
    if url == 'new':
        keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
        keyb.doModal()
        if keyb.isConfirmed():
            search = quote_plus(keyb.getText())
            if six.PY2:
                term = unquote_plus(search).decode('utf-8')
            else:
                term = unquote_plus(search)

            dbcon = database.connect(control.searchFile)
            dbcur = dbcon.cursor()

            dp = xbmcgui.Dialog()

            select = dp.select('                                       Επιλογή Ιστότοπου',
                              ['[COLOR coral][B]                                                      Tainio-mania[/COLOR][/B]',
                               '[COLOR green][B]                                                          Gamato[/COLOR][/B]',
                               '[COLOR gold][B]                                                   Xrysoi - [COLOR white]Ταινίες[/COLOR][/B]',
                               '[COLOR gold][B]                                                    Xrysoi - [COLOR white]Σειρές[/COLOR][/B]',
                               '[COLOR deeppink][B]                                             GamatoMovies - [COLOR white]Ταινίες[/COLOR][/B]',
                               '[COLOR deeppink][B]                                             GamatoMovies - [COLOR white]Σειρές[/COLOR][/B]',
                               '[COLOR red][B]                                                         OiPeirates[/COLOR][/B]',
                               '[COLOR cyan][B]                                                    Coolmoviezone[/COLOR][/B]',
                               '[COLOR tomato][B]                                                       Myvideolinks[/COLOR][/B]',
                               '[COLOR purple][B]                                                         Anymovies[/COLOR][/B]',
                               '[COLOR blue][B]                                                      Tenies-Online[/COLOR][/B]'])

            if select == 0:
                from resources.lib.indexers import tainiomania
                url = 'https://tainio-mania.online/?story=' + search + '&titleonly=3&do=search&subaction=search'.format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                tainiomania.tainiomania(url)

            elif select == 1:
                url = GAMATO + "?s={}".format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                Search_gamato(url)

            elif select == 2:
                from resources.lib.indexers import xrysoi
                url = XRYSOI + "?s={}".format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                xrysoi.xrysoimovies_search(url)

            elif select == 3:
                from resources.lib.indexers import xrysoi
                url = XRYSOI + "?s={}".format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                xrysoi.xrysoimovies_search_series(url)

            elif select == 4:
                from resources.lib.indexers import gamatomovies
                url = GAMATOMOVIES + "?s={}".format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                gamatomovies.gamatomovies(url)

            elif select == 5:
                from resources.lib.indexers import gamatomovies
                url = GAMATOMOVIES + "?s={}".format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                gamatomovies.gamatomoviestv(url)

            elif select == 6:
                from resources.lib.indexers import oipeirates
                url = OIPEIRATES + "?s={}".format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                oipeirates.oipeirates(url)

            elif select == 7:
                from resources.lib.indexers import coolmoviezone
                url = COOLMOVIEZONE + "index.php?s={}".format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                coolmoviezone.coolmoviezone_2(url)

            elif select == 8:
                from resources.lib.indexers import myvideolinks
                url = MYVIDEOLINKS + "?s={}".format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                myvideolinks.myvideolinks(url)

            elif select == 9:
                from resources.lib.indexers import anymovies
                url = ANYMOVIES + "search.php?zoom_query={}".format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                anymovies.anymovies(url)

            elif select == 10:
                from resources.lib.indexers import teniesonline
                url = Teniesonline + "?s={}".format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                teniesonline.search(url)

            else:
                return
        else:
            return

    else:
        if 'tainiomania' in url:
            from resources.lib.indexers import tainiomania
            tainiomania.search(url)
        elif 'gamato' in url:
            Search_gamato(url)
        elif 'xrysoi' in url:
            from resources.lib.indexers import xrysoi
            xrysoi.search(url)
        elif 'gamatomovies' in url:
            from resources.lib.indexers import gamatomovies
            gamatomovies.search(url)
        elif 'oipeirates' in url:
            from resources.lib.indexers import oipeirates
            oipeirates.search(url)
        elif 'coolmoviezone' in url:
            from resources.lib.indexers import coolmoviezone
            coolmoviezone.search(url)
        elif 'myvideolinks' in url:
            from resources.lib.indexers import myvideolinks
            myvideolinks.search(url)
        elif 'anymovies' in url:
            from resources.lib.indexers import anymovies
            anymovies.search(url)
        elif 'teniesonline' in url:
            from resources.lib.indexers import teniesonline
            teniesonline.search(url)
#    views.selectView('menu', 'menu-view')


def Del_search(url):
    control.busy()
    search = url.split('s=')[1].decode('utf-8')

    dbcon = database.connect(control.searchFile)
    dbcur = dbcon.cursor()
    dbcur.execute("DELETE FROM Search WHERE search = ?", (search,))
    dbcon.commit()
    dbcur.close()
    xbmc.executebuiltin('Container.Refresh')
    control.idle()


def download(name, iconimage, url):
    from resources.lib.modules import control
    control.busy()
    import json
    if url is None:
        control.idle()
        return

    try:

        url = evaluate(url)
        # xbmc.log('URL-EVALUATE: %s' % url)
    except Exception:
        control.idle()
        xbmcgui.Dialog().ok(NAME, 'Download failed', 'Your service can\'t resolve this hoster', 'or Link is down')
        return
    try:
        headers = dict(parse_qsl(url.rsplit('|', 1)[1]))
    except BaseException:
        headers = dict('')
    control.idle()
    title = re.sub('\[.+?\]', '', name)
    content = re.compile('(.+?)\s+[\.|\(|\[]S(\d+)E\d+[\.|\)|\]]', re.I).findall(title)
    transname = title.translate(None, '\/:*?"<>|').strip('.')
    transname = re.sub('\[.+?\]', '', transname)
    levels = ['../../../..', '../../..', '../..', '..']
    if len(content) == 0:
        dest = control.setting('movie.download.path')
        dest = control.transPath(dest)
        for level in levels:
            try:
                control.makeFile(os.path.abspath(os.path.join(dest, level)))
            except:
                pass
        control.makeFile(dest)
        dest = os.path.join(dest, transname)
        control.makeFile(dest)
    else:
        dest = control.setting('tv.download.path')
        dest = control.transPath(dest)
        for level in levels:
            try:
                control.makeFile(os.path.abspath(os.path.join(dest, level)))
            except:
                pass
        control.makeFile(dest)
        tvtitle = re.sub('\[.+?\]', '', content[0])
        transtvshowtitle = tvtitle.translate(None, '\/:*?"<>|').strip('.')
        dest = os.path.join(dest, transtvshowtitle)
        control.makeFile(dest)
        dest = os.path.join(dest, 'Season %01d' % int(content[0][1]))
        control.makeFile(dest)
    control.idle()
    # ext = os.path.splitext(urlparse(url).path)[1]

    ext = os.path.splitext(urlparse(url).path)[1][1:]
    # xbmc.log('URL-EXT: %s' % ext)
    if not ext in ['mp4', 'mkv', 'flv', 'avi', 'mpg']: ext = 'mp4'
    dest = os.path.join(dest, transname + '.' + ext)
    headers = quote_plus(json.dumps(headers))
    # xbmc.log('URL-HEADERS: %s' % headers)

    from resources.lib.modules import downloader
    control.idle()
    downloader.doDownload(url, dest, name, iconimage, headers)


def downloads_root():
    movie_downloads = control.setting('movie.download.path')
    tv_downloads = control.setting('tv.download.path')
    cm = [(control.lang(32007),
           'RunPlugin(plugin://plugin.video.atlas/?mode=17)'),
          (control.lang(32008), 'RunPlugin(plugin://plugin.video.atlas/?mode=9)')]
    if len(control.listDir(movie_downloads)[0]) > 0:
        item = control.item(label='Movies')
        item.addContextMenuItems(cm)
        item.setArt({'icon': ART + 'movies.jpg', 'fanart': FANART})
        xbmcplugin.addDirectoryItem(int(sys.argv[1]), movie_downloads, item, True)

    if len(control.listDir(tv_downloads)[0]) > 0:
        item = control.item(label='Tv Shows')
        item.addContextMenuItems(cm)
        item.setArt({'icon': ART + 'tvshows.jpg', 'fanart': FANART})
        xbmcplugin.addDirectoryItem(int(sys.argv[1]), tv_downloads, item, True)

    control.content(int(sys.argv[1]), 'videos')
    control.directory(int(sys.argv[1]))
#    views.selectView('menu', 'menu-view')


######################
####  GAMATOKIDS  ####
######################

def get_gam_genres(url):  # 3
    try:

        r = requests.get(url).text
        r = client.parseDOM(r, 'li', attrs={'id': r'menu-item-\d+'})[1:]
        # xbmc.log('POSTs: {}'.format(r))
        # r = client.parseDOM(r, 'div', attrs={'class': 'categorias'})[0]
        # r = client.parseDOM(r, 'li', attrs={'class': 'cat-item.+?'})
        for post in r:
            try:
                # xbmc.log('POST: {}'.format(post))
                url = client.parseDOM(post, 'a', ret='href')[0]
                name = client.parseDOM(post, 'a')[0]
                name = clear_Title(name)
                if 'facebook' in url or 'imdb' in url:
                    continue
                # xbmc.log('NAME: {} | URL: {}'.format(name, url))
                addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 4, ART + 'movies.jpg', FANART, '')
            except BaseException:
                pass

    except BaseException:
        pass
#    views.selectView('menu', 'menu-view')


def Search_gamato(url):  # 19
    control.busy()
    data = r = requests.get(url).text
    posts = client.parseDOM(data, 'div', attrs={'class': 'result-item'})
    for post in posts:
        link = client.parseDOM(post, 'a', ret='href')[0]
        poster = client.parseDOM(post, 'img', ret='src')[0].encode('utf-8', 'ignore')
        title = client.parseDOM(post, 'img', ret='alt')[0]
        title = clear_Title(title)
        try:
            year = client.parseDOM(post, 'span', attrs={'class': 'year'})[0]
            desc = client.parseDOM(post, 'div', attrs={'class': 'contenido'})[0]
            desc = re.sub('<.+?>', '', desc)
            desc = clear_Title(desc)
        except IndexError:
            year = 'N/A'
            desc = 'N/A'

        addDir('[B][COLOR white]{0} [{1}][/COLOR][/B]'.format(title, year), link, 12, poster, FANART, str(desc))

    try:
    #    np = client.parseDOM(data, 'a', ret='href', attrs={'class': 'arrow_pag'})[-1]
        np = client.parseDOM(data, 'link', ret='href', attrs={'rel': "next"})[-1]
    #    page = np.split('/')[-1]
        title = '[B][COLOR=lime]Επόμενη σελίδα [COLOR=white]>>[/COLOR][/B]'
        addDir(title, np, 19, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except IndexError:
        pass
    control.idle()
#    views.selectView('menu', 'menu-view')


def gamato_kids(url):  # 4
    data = requests.get(url).text
    posts = client.parseDOM(data, 'article', attrs={'id': 'post-\d+'})
    for post in posts:
        try:
            plot = re.findall('''texto["']>(.+?)</div> <div''', post, re.DOTALL)[0]
        except IndexError:
            plot = client.parseDOM(post, 'div', attrs={'class': 'texto'})[0]
        if len(plot) < 1:
            plot = 'N/A'
        desc = client.replaceHTMLCodes(plot)
        desc = six.ensure_str(desc, encoding='utf-8')
        try:
            title = client.parseDOM(post, 'h4')[0]
            year = re.findall(r'<span>.*?\s*(\d{4})</span>', post, re.DOTALL)[0]
            if not (len(year) == 4 and year.isdigit()):
                year = 'N/A'
        except IndexError:
            title = client.parseDOM(post, 'img', ret='alt')[0]
            year = 'N/A'
        year = '[COLORlime]{}[/COLOR]'.format(year)
        title = clear_Title(title)
        link = client.parseDOM(post, 'a', ret='href')[0]
        link = clear_Title(link)
        poster = client.parseDOM(post, 'img', ret='src')[0]
        poster = clear_Title(poster)

        addDir('[B][COLOR white]{0} [{1}][/COLOR][/B]'.format(title, year), link, 12, poster, FANART, desc)
    try:
    #    np = client.parseDOM(data, 'a', ret='href', attrs={'class': 'arrow_pag'})[-1]
        np = client.parseDOM(data, 'link', ret='href', attrs={'rel': "next"})[-1]
        np = clear_Title(np)
    #    page = np[-2] if np.endswith('/') else re.findall(r'page/(\d+)/', np)[0]
        title = '[B][COLOR=lime]Επόμενη σελίδα [COLOR=white]>>[/COLOR][/B]'
        addDir(title, np, 4, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except IndexError:
        pass
#    views.selectView('menu', 'menu-view')


def gamato_notvshows(url):  # 2
    data = requests.get(url).text
    posts = client.parseDOM(data, 'article', attrs={'id': 'post-\d+'})
    for post in posts:
        try:
            plot = re.findall('''texto["']>(.+?)</div> <div''', post, re.DOTALL)[0]
        except IndexError:
            plot = client.parseDOM(post, 'div', attrs={'class': 'texto'})[0]
        if len(plot) < 1:
            plot = 'N/A'
        desc = client.replaceHTMLCodes(plot)
        desc = six.ensure_str(desc, encoding='utf-8')
        try:
            title = client.parseDOM(post, 'h4')[0]
            year = re.findall(r'<span>.*?\s*(\d{4})</span>', post, re.DOTALL)[0]
            if not (len(year) == 4 and year.isdigit()):
                year = 'N/A'
        except IndexError:
            title = client.parseDOM(post, 'img', ret='alt')[0]
            year = 'N/A'
        year = '[COLORlime]{}[/COLOR]'.format(year)
        title = clear_Title(title)
        link = client.parseDOM(post, 'a', ret='href')[0]
        link = clear_Title(link)
        poster = client.parseDOM(post, 'img', ret='src')[0]
        poster = clear_Title(poster)
        if 'tvshows' in link:
            continue
        addDir('[B][COLOR white]{0} [{1}][/COLOR][/B]'.format(title, year), link, 12, poster, FANART, desc)
    try:
    #    np = client.parseDOM(data, 'a', ret='href', attrs={'class': 'arrow_pag'})[-1]
        np = client.parseDOM(data, 'link', ret='href', attrs={'rel': "next"})[-1]
        np = clear_Title(np)
    #    page = np[-2] if np.endswith('/') else re.findall(r'page/(\d+)/', np)[0]
        title = '[B][COLOR=lime]Επόμενη σελίδα [COLOR=white]>>[/COLOR][/B]'
        addDir(title, np, 2, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except IndexError:
        pass


def gamatokids_top(url):  # 21
    data = requests.get(url).text
    posts = client.parseDOM(data, 'article', attrs={'class': 'w_item_a'})
    for post in posts:
        try:
            title = client.parseDOM(post, 'h3')[0]
            title = clear_Title(title)
            link = client.parseDOM(post, 'a', ret='href')[0]
            poster = client.parseDOM(post, 'img', ret='src')[0]
            year = client.parseDOM(post, 'span', attrs={'class': 'wdate'})[0]

            addDir('[B][COLOR white]{0} [{1}][/COLOR][/B]'.format(title, year), link, 12, poster, FANART,
                   'Προτεινόμενα')
        except IndexError:
            pass
#    views.selectView('menu', 'menu-view')


def gamato_links(url, name, poster):  # 12
    # try:
        url = quote(url, ':/.')
        # xbmc.log('URLLLL2: {}'.format(url))

        data = six.ensure_text(client.request(url))
        # xbmc.log('DATA: {}'.format(str(data)))
        try:
            desc = client.parseDOM(data, 'div', attrs={'itemprop': 'description'})[0]
            desc = clear_Title(desc)
        except IndexError:
            desc = 'N/A'

        # try:
        #     # Playerjs({id:"playerjs14892",file:"https://gamato1.com/s/Aladdin%20and%20the%20King%20of%20Thieves%201996.mp4"})
        #     link = re.findall(r'''Playerjs\(\{.+?file\s*:\s*['"](.+?\.mp4)['"]\}''', data, re.DOTALL)[0]
        #     link = quote(link, ':/.')
        #     # link += '|User-Agent={}&Referer={}'.format(quote(client.agent()), quote(url))
        #     xbmc.log('FRAME1: {}'.format(str(link)))
        # except IndexError:
        # try:
        try:
            match = re.findall(r'''file\s*:\s*['"](.+?)['"],poster\s*:\s*['"](.+?)['"]\}''', data, re.DOTALL)[0]
            link, _poster = match[0], match[1]
        except IndexError:
            # 'http://gamatotv2.com/kids/jwplayer/?source=http%3A%2F%2F161.97.109.217%2FSonic%2520%2520%2520-%2520Gamato%2520%2520.mp4&id=16449&type=mp4
            link = re.findall(r'''/jwplayer/\?source=(.+?)&id=''', data, re.DOTALL)[0]

        # xbmc.log('FRAME2: {}'.format(str(link)))
        # except IndexError:
        #     frame = client.parseDOM(data, 'div', attrs={'id': r'option-\d+'})[0]
        #     frame = client.parseDOM(frame, 'iframe', ret='src')[0]
        #     xbmc.log('FRAME3: {}'.format(str(frame)))
        #
        #     if 'cloud' in frame:
        #         # sources: ["http://cloudb.me/4fogdt6l4qprgjzd2j6hymoifdsky3tfskthk76ewqbtgq4aml3ior7bdjda/v.mp4"],
        #         match = client.request(frame, referer=url)
        #         # xbmc.log('MATCH3: {}'.format(match))
        #         if 'meta name="robots"' in match:
        #             cloudid = frame.split('html?')[-1].split('=')[0]
        #             cloud = 'http://cloudb2.me/embed-{}.html?auto=1&referer={}'.format(cloudid, url)
        #             match = client.request(cloud)
        #         try:
        #             from resources.lib.modules import jsunpack
        #             if jsunpack.detect(match):
        #                 match = jsunpack.unpack(match)
        #             match = re.findall(r'sources:\s*\[[\'"](.+?)[\'"]\]', match, re.DOTALL)[0]
        #             # match += '|User-Agent=%s&Referer=%s' % (quote(client.agent()), frame)
        #         except IndexError:
        #             from resources.lib.modules import jsunpack as jsun
        #             if jsun.detect(match):
        #                 match = jsun.unpack(match)
        #                 match = re.findall(r'sources:\s*\[[\'"](.+?)[\'"]\]', match, re.DOTALL)[0]
        #                 # match += '|User-Agent=%s&Referer=%s' % (quote(client.agent()), frame)
        #     else:
        #         match = frame
        #     link, _poster = match, poster
        link = unquote_plus(link)
        # xbmc.log('Finally LINK: {}'.format(link))
        try:
            fanart = client.parseDOM(data, 'div', attrs={'class': 'g-item'})[0]
            fanart = client.parseDOM(fanart, 'a', ret='href')[0]
        except IndexError:
            fanart = FANART
        try:
            trailer = client.parseDOM(data, 'iframe', ret='src')
            trailer = [i for i in trailer if 'youtube' in i][0]
            addDir('[B][COLOR lime]Τρέιλερ[/COLOR][/B]', trailer, 100, iconimage, fanart, str(desc))
        except IndexError:
            pass

        addDir(name, link, 100, poster, fanart, str(desc))
    # except BaseException:
    #     return
#    views.selectView('menu', 'menu-view')


def get_links(name, url, iconimage, description):
    hdrs = {'Referer': GAMATO,
            'User-Agent': client.agent()}
    data = requests.get(url, headers=hdrs).text
    if 'streamzz' in data:
        site = '[B][COLOR=white]Για να ανοίξουν τα links [COLOR=lime]Streamzz [COLOR=white]πατήστε πρώτα εδώ![CR]Έπειτα επιστρέψτε στο επεισόδιο που επιθυμείτε.[/COLOR][/B]'
        addDir(site, url, 82, ART + 'streamz.png', FANART, str(description))
    if 'Trailer' in data:
        try:
            flink = client.parseDOM(data, 'iframe', ret='src', attrs={'class': 'rptss'})[0]
        except IndexError:
            try:
                # http://gamatotv.info/wp-json/dooplayer/v1/post/45755?type=movie&source=trailer
                ylink = ' http://gamatotv.info/wp-json/dooplayer/v1/post/{}?type=movie&source=trailer'
                #li id='player-option-trailer'
                yid = client.parseDOM(data, 'li', ret='data-post', attrs={'id': 'player-option-trailer'})[0]
                flink = ylink.format(yid)
                flink = client.request(flink)
                flink = json.loads(flink)['embed_url']
            except IndexError:
                flink = ''

        if 'youtu' in flink:
            addDir('[B][COLOR lime]Τρέιλερ[/COLOR][/B]', flink, 100, ART + 'youtube.png', FANART, '')
        else:
            addDir('[B][COLOR orange]Δεν υπάρχει διαθέσιμο Τρέιλερ[/COLOR][/B]', '', 100, ART + 'youtube.png', FANART, '')

    else:
        addDir('[B][COLOR orange]Δεν υπάρχει διαθέσιμο Τρέιλερ[/COLOR][/B]', '', 100, ART + 'youtube.png', FANART, '')

    try:
        if 'tvshows' not in url:
            try:
                try:
                    frame = client.parseDOM(data, 'iframe', ret='src', attrs={'class': 'metaframe rptss'})[0]
                except IndexError:
                    get_vid = 'http://gamatotv.info/wp-json/dooplayer/v1/post/{}?type=movie&source=1'
                    id = client.parseDOM(data, 'li', ret='data-post', attrs={'id': 'player-option-1'})[0]
                    frame = client.request(get_vid.format(id))
                    frame = json.loads(frame)['embed_url']
                if 'coverapi' in frame:
                    html = requests.get(frame).text
                    post_url = 'https://coverapi.store/engine/ajax/controller.php'
                    postdata = re.findall(r'''data: \{mod: 'players', news_id: '(\d+)'\},''', html, re.DOTALL)[0]
                    # xbmc.log('POSR-DATA: {}'.format(str(postdata)))
                    postdata = {'mod': 'players',
                                'news_id': postdata}
                    hdrs = {'Origin': 'https://coverapi.store',
                            'Referer': frame,
                            'User-Agent': client.agent()}
                    post_html = requests.post(post_url, data=postdata, headers=hdrs).text.replace('\\', '')
                    # xbmc.log('POSR-HTML: {}'.format(str(post_html)))
                    frame = re.findall(r'''file:\s*['"](http.+?)['"]''', post_html, re.DOTALL)[0]
                    title = '{} | [B]{}[/B]'.format(name, 'Gamato')
                    addDir(title, frame, 100, iconimage, FANART, str(description))
                elif '/jwplayer/?source' in frame:
                    frame = re.findall(r'''/jwplayer/\?source=(.+?)&id=''', frame, re.DOTALL)[0]
                    # xbmc.log('FRAME-JWPLAYER: {}'.format(str(frame)))
                    # frame = unquote_plus(frame)
                    title = '{} | [B]{}[/B]'.format(name, 'Gamato')
                    addDir(title, frame, 100, iconimage, FANART, str(description))
                else:
                    host = GetDomain(frame)
                    title = '{} | [B]{}[/B]'.format(name, host.capitalize())
                    addDir(title, frame, 100, iconimage, FANART, str(description))
            except IndexError:
                pass
            try:
                frames = client.parseDOM(data, 'tr', {'id': r'link-\d+'})
                frames = [(client.parseDOM(i, 'a', ret='href', attrs={'target': '_blank'})[0],
                           client.parseDOM(i, 'img', ret='src')[0],
                           client.parseDOM(i, 'strong', {'class': 'quality'})[0]) for i in frames if frames]
                for frame, domain, quality in frames:
                    host = domain.split('=')[-1]
                    host = six.ensure_str(host, 'utf-8')
                    # if 'Μεταγλωτισμένο' in info.encode('utf-8', 'ignore'):
                    #     info = '[Μετ]'
                    # elif 'Ελληνικοί' in info.encode('utf-8', 'ignore'):
                    #     info = '[Υπο]'
                    # elif 'Χωρίς' in info.encode('utf-8', 'ignore'):
                    #     info = '[Χωρίς Υπ]'
                    # else:
                    #     info = '[N/A]'
                    quality = 'SD'
                    title = '{} | [B]{}[/B] | ({})'.format(name, host.capitalize(), quality)
                    addDir(title, frame, 100, iconimage, FANART, str(description))
            except BaseException:
                pass
        else:
            get_links2(name, url, iconimage, description)
           # data = client.parseDOM(data, 'table', attrs={'class': 'easySpoilerTable'})
           # seasons = [dom.parse_dom(i, 'a', {'target': '_blank'}, req='href') for i in str(data)[:-1] if i]
           # episodes = []
           # for season in seasons:
           #     for epi in season:
           #         title = clear_Title(epi.content.replace('&#215;', 'x'))
           #         frame = epi.attrs['href']
           #         episodes.append((title, frame))

           # for title, frame in episodes:
           #     addDir(title, frame, 100, iconimage, FANART, str(description))

    except BaseException:
        title = '[B][COLOR white]Δεν υπάρχει διαθέσιμο link[/COLOR][/B]'
        addDir(title, '', 'bug', iconimage, FANART, str(description))
#    views.selectView('menu', 'menu-view')


def get_links2(name, url, iconimage, description): #120
    hdrs = {'Referer': GAMATO,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<a href="(.+?)">(.+?)</a>').findall(p)
    t = re.compile('<title>(.+?)</title>').findall(p)
#    t = re.compile('<b class="variante">Original title</b>\s<span class="valor">(.+?)</span>').findall(p)
    link_list = ['streamzz', 'voe', 'aparat', 'flashx', 'hdvid', 'vidd','vidoza', 'vidlox', 'estream', 'clipwatching', 'thevideo', 'vidzi']
    for url, epi in m:
        for name in t:
    #        epi = ' | ' + epi
            name = name.replace('| Gamato: Ταινίες online με ελληνικους υποτιτλους', '')
            name = clear_Title(name)
    #        name = name + epi
            if any(x in url for x in link_list):
                addDir(name, url, 100, iconimage, FANART, str(description))


########################################

def find_single_match(data, patron, index=0):
    try:
        matches = re.findall(patron, data, flags=re.DOTALL)
        return matches[index]
    except IndexError:
        return ""


def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    return txt


def Open_settings():
    control.openSettings()


def cache_clear():
    cache.clear(withyes=False)


def search_clear():
    cache.delete(control.searchFile, withyes=False)
    control.refresh()
    control.idle()


def resolve(name, url, iconimage, description):
    liz = xbmcgui.ListItem(name)
    host = url
    if 'gosafedomain' in host:
        host = requests.get(host, allow_redirects=False).headers['Location']
    if '/links/' in host:
        try:
            frame = client.request(host)
            host = client.parseDOM(frame, 'a', {'id': 'link'}, ret='href')[0]

        except BaseException:
            host = requests.get(host, allow_redirects=False).headers['Location']
    else:
        host = host

    # try resolveurl first:
    stream_url = evaluate(host)
    if not stream_url:
        if host.split('|')[0].endswith('.mp4') and 'clou' in host:
            stream_url = host + '|User-Agent=%s&Referer=%s' % (quote_plus(client.agent(), ':/'), GAMATO)
            name = name
        elif host.endswith('.mp4') and 'vidce.net' in host:
            stream_url = host + '|User-Agent={}'.format(quote_plus(client.agent()))
        elif host.endswith('.mp4'):
            stream_url = host + '|User-Agent=%s&Referer=%s' % (quote_plus(client.agent(), ':/'), GAMATO)
        # stream_url = requests.get(host, headers=hdr).url
        elif '/aparat.' in host:
            try:
                from resources.lib.resolvers import aparat
                stream_url = aparat.get_video(host)
                stream_url, sub = stream_url.split('|')
                liz.setSubtitles([sub])
            except BaseException:
                stream_url = evaluate(host)
        # elif '/clipwatching.' in host:
        #     xbmc.log('HOST: {}'.format(host))
        #     # try:
        #     data = requests.get(host).text
        #     xbmc.log('DATA: {}'.format(data))
        #     try:
        #         sub = client.parseDOM(data, 'track', ret='src', attrs={'label': 'Greek'})[0]
        #         xbmc.log('SUBS: {}'.format(sub))
        #         liz.setSubtitles([sub])
        #     except IndexError:
        #         pass
        #
        #     stream_url = re.findall(r'''sources:\s*\[\{src:\s*['"](.+?)['"]\,''', data, re.DOTALL)[0]
        #     xbmc.log('HOST111: {}'.format(stream_url))
        #
        #
        #     # except BaseException:
        #     #     stream_url = evaluate(stream_url)
        elif 'coverapi' in host:
            html = requests.get(host).text
            # xbmc.log('ΠΟΣΤ_html: {}'.format(html))
            postdata = re.findall(r'''['"]players['"], news_id: ['"](\d+)['"]}''', html, re.DOTALL)[0]
            # xbmc.log('ΠΟΣΤ_html: {}'.format(postdata))
            postdata = {'mod': 'players',
                        'news_id': str(postdata)}
            post_url = 'https://coverapi.store/engine/ajax/controller.php'
            post_html = requests.post(post_url, data=postdata).text.replace('\\', '')
            # xbmc.log('ΠΟΣΤ_ΔΑΤΑ: {}'.format(post_html))
            stream_url = re.findall(r'''file\s*:\s*['"](.+?)['"]''', post_html, re.DOTALL)[0]
            # xbmc.log('ΠΟΣΤ_URL: {}'.format(stream_url))
            if 'http' in stream_url:
                stream_url = stream_url + '|User-Agent=iPad&Referer={}&verifypeer=false'.format('https://coverapi.store/')
            else:
                playlist_url = 'https://coverapi.store/' + stream_url
                data = requests.get(playlist_url).json()
                # xbmc.log('ΠΟΣΤ_ΔΑΤΑ: {}'.format(data))
                comments = []
                streams = []

                data = data['playlist']
                for dat in data:
                    url = dat['file']
                    com = dat['comment']
                    comments.append(com)
                    streams.append(url)

                if len(comments) > 1:
                    dialog = xbmcgui.Dialog()
                    ret = dialog.select('[COLORgold][B]ΔΙΑΛΕΞΕ ΠΗΓΗ[/B][/COLOR]', comments)
                    if ret == -1:
                        return
                    elif ret > -1:
                        host = streams[ret]
                        # xbmc.log('@#@HDPRO:{}'.format(host))User-Agent=iPad&verifypeer=false
                        stream_url = host + '|User-Agent=iPad&Referer={}&verifypeer=false'.format('https://coverapi.store/')
                    else:
                        return

                else:
                    host = streams[0]
                    stream_url = host + '|User-Agent=iPad&Referer={}&verifypeer=false'.format('https://coverapi.store/')

    else:
        name = name.split(' [B]|')[0]
    try:
        liz.setArt({"icon": iconimage, "thumb": iconimage, "fanart": fanart})
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
        liz.setProperty("IsPlayable", "true")
        liz.setPath(str(stream_url))
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except BaseException:
        control.infoDialog(Lang(32012), NAME)


def evaluate(host):
    import resolveurl
    try:
        url = None
        if 'openload' in host:
            try:
                from resources.lib.resolvers import openload
                oplink = openload.get_video_openload(host)
                url = resolveurl.resolve(oplink) if oplink == '' else oplink
            except BaseException:
                url = resolveurl.resolve(host)

        elif resolveurl.HostedMediaFile(host):
            url = resolveurl.resolve(host)

        return url
    except BaseException:
        return


def GetDomain(url):
    elements = urlparse(url)
    domain = elements.netloc or elements.path
    domain = domain.split('@')[-1].split(':')[0]
    regex = r"(?:www\.)?([\w\-]*\.[\w\-]{2,3}(?:\.[\w\-]{2,3})?)$"
    res = re.search(regex, domain)
    if res:
        domain = res.group(1)
    domain = domain.lower()
    return domain


def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()

def site_streamzz():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://streamzz.to/x5f333dd3f45ecd88de33d3d1a24da533' ) )
    else: opensite = webbrowser . open('https://streamzz.to/x5f333dd3f45ecd88de33d3d1a24da533')


#name = p.get_name()
#url = p.get_url()
#mode = p.get_mode()
icon = p.get_icon()
#fanart = p.get_fanart()
#description = p.get_description()


params = init.params
mode = params.get('mode')
name = params.get('name')
iconimage = params.get('iconimage')
fanart = params.get('fanart')
description = params.get('description')
url = params.get('url')

try:
    url = unquote_plus(params["url"])
except BaseException:
    pass
try:
    name = unquote_plus(params["name"])
except BaseException:
    pass
try:
    iconimage = unquote_plus(params["iconimage"])
except BaseException:
    pass
try:
    mode = int(params["mode"])
except BaseException:
    pass
try:
    fanart = unquote_plus(params["fanart"])
except BaseException:
    pass
try:
    description = unquote_plus(params["description"])
except BaseException:
    pass

xbmc.log('{}: {}'.format(str(ID), str(VERSION)))
xbmc.log('{}: {}'.format('Mode', str(mode)))
xbmc.log('{}: {}'.format('URL', str(url)))
xbmc.log('{}: {}'.format('Name', str(name)))
xbmc.log('{}: {}'.format('ICON', str(iconimage)))


################################################


if mode is None:
    Main_addDir()


###############GAMATO##########################

elif mode == 2:
    gamato_notvshows(url)

#elif mode == 3:
#    get_gam_genres(url)

elif mode == 3:
    play_video(name, url, icon)

elif mode == 4:
    gamato_kids(url)

elif mode == 12:
    get_links(name, url, iconimage, description)
    # gamato_links(url, name, iconimage)

elif mode == 120:
    get_links2(name, url, iconimage, description)
    # gamato_links

elif mode == 18:
    keyb = xbmc.Keyboard('', Lang(32002))
    keyb.doModal()
    if keyb.isConfirmed():
        search = quote_plus(keyb.getText())
        url = GAMATO + "?s={}".format(search)
        Search_gamato(url)
    else:
        pass

elif mode == 19:
    Search_gamato(url)

elif mode == 20:
    gamato_menu()

elif mode == 21:
    gamatokids_top(url)

elif mode == 22:
    gamato_years()

elif mode == 23:
    gamato_genre()

###############################################
elif mode == 5:
    Get_content(url)

elif mode == 6:
    search_menu()

elif mode == 7:
    Get_TV_Genres(url)

elif mode == 8:
    Get_random(url)

elif mode == 9:
    cache_clear()

elif mode == 10:
    Movies_maim()

elif mode == 11:
    Series_maim()

elif mode == 13:
    Greek_maim()

#elif mode == 13:
#    Peliculas()

elif mode == 14:
    Series()

elif mode == 15:
    year(url)

elif mode == 16:
    year_TV(url)

elif mode == 17:
    Open_settings()

elif mode == 19:
    Get_epoxiakes(url)

elif mode == 26:
    Search(url)

elif mode == 266:
    Search2(url)

elif mode == 28:
    Del_search(url)

elif mode == 29:
    search_clear()

###############METAGLOTISMENO#################

elif mode == 30:
    from resources.lib.indexers import teniesonline
    teniesonline.menu()

elif mode == 33:
    from resources.lib.indexers import teniesonline
    teniesonline.get_links(name, url, iconimage, description)

elif mode == 34:
    from resources.lib.indexers import teniesonline
    teniesonline.metaglotismeno(url)

elif mode == 35:
    from resources.lib.indexers import teniesonline

    keyb = xbmc.Keyboard('', Lang(32002))
    keyb.doModal()
    if keyb.isConfirmed():
        search = quote_plus(keyb.getText())
        url = Teniesonline + "?s={}".format(search)
        teniesonline.search(url)
    else:
        pass

elif mode == 36:
    from resources.lib.indexers import TainiesOnline_year
    TainiesOnline_year.tainiesonline_year()
    
elif mode == 37:
    from resources.lib.indexers import TainiesOnline_genre
    TainiesOnline_genre.tainiesonline_genre()

##############################################

elif mode == 40:
    downloads_root()

elif mode == 41:
    download(name, iconimage, url)

#######################XRYSOI#################

elif mode == 42:
    from resources.lib.indexers import xrysoi
    xrysoi.menu()

elif mode == 43:
    from resources.lib.indexers import xrysoi
    xrysoi.get_links(name, url, iconimage, description)

elif mode == 44:
    from resources.lib.indexers import xrysoi
    xrysoi.xrysoimovies(url)

elif mode == 45:
    from resources.lib.indexers import xrysoi
    xrysoi.search(url)

elif mode == 46:
    from resources.lib.indexers import Xrysoi_year
    Xrysoi_year.xrysoi_year()

elif mode == 47:
    from resources.lib.indexers import Xrysoi_genre
    Xrysoi_genre.xrysoi_genre()

#elif mode == 48:
#    from resources.lib.indexers import xrysoi
#    xrysoi.get_hdvids(url)

elif mode == 49:
    from resources.lib.indexers import xrysoi
    xrysoi.xrysoiseries(url)

elif mode == 50:
    from resources.lib.indexers import xrysoi
    xrysoi.search_series()

elif mode == 51:
    from resources.lib.indexers import xrysoi
    xrysoi.menu_genre()

elif mode == 52:
    from resources.lib.indexers import xrysoi
    xrysoi.menu_year()

elif mode == 53:
    from resources.lib.indexers import xrysoi
    xrysoi.xrysoimovies_search(url)

elif mode == 54:
    from resources.lib.indexers import xrysoi
    xrysoi.get_links_series(name, url, iconimage, description)

elif mode == 55:
    from resources.lib.indexers import xrysoi
    xrysoi.xrysoimovies_search_series(url)

####################YOUTUBE###################

elif mode == 56:
    MainYoutube(url)

elif mode == 58:
    yt_channel(url)

elif mode == 59:
    yt_playlist(url)

elif mode == 60:
    MainYoutube(yt_xml)

elif mode == 61:
    MainYoutube(yt1_xml)

elif mode == 62:
    MainYoutube(yt2_xml)

elif mode == 63:
    MainYoutube(yt3_xml)

elif mode == 64:
    MainYoutube(yt4_xml)

elif mode == 65:
    MainYoutube(yt5_xml)

###################################################

elif mode == 80:
    kids_menu()

elif mode == 81:
    documentary_menu()

elif mode == 82:
    site_streamzz()

###################TAINIOMANIA######################

elif mode == 85:
    from resources.lib.indexers import tainiomania
    tainiomania.search(url)

elif mode == 86:
    from resources.lib.indexers import tainiomania
    tainiomania.menu_year()

elif mode == 87:
    from resources.lib.indexers import tainiomania
    tainiomania.menu_genre()

elif mode == 88:
    from resources.lib.indexers import tainiomania
    tainiomania.get_links(name, url, iconimage, description)

elif mode == 89:
    from resources.lib.indexers import tainiomania
    tainiomania.tainiomania(url)

###################ANYMOVIES######################

elif mode == 90:
    from resources.lib.indexers import anymovies
    anymovies.search(url)

elif mode == 91:
    from resources.lib.indexers import anymovies
    anymovies.menu_year()

elif mode == 92:
    from resources.lib.indexers import anymovies
    anymovies.menu_genre()

elif mode == 93:
    from resources.lib.indexers import anymovies
    anymovies.get_links(name, url, iconimage, description)

elif mode == 94:
    from resources.lib.indexers import anymovies
    anymovies.anymovies(url)

###################OIPEIRATES#####################

elif mode == 95:
    from resources.lib.indexers import oipeirates
    oipeirates.search(url)

elif mode == 96:
    from resources.lib.indexers import oipeirates
    oipeirates.oipeirates(url)

elif mode == 97:
    from resources.lib.indexers import oipeirates
    oipeirates.menu_year()

elif mode == 98:
    from resources.lib.indexers import oipeirates
    oipeirates.menu_genre()

elif mode == 99:
    from resources.lib.indexers import oipeirates
    oipeirates.get_links(name, url, iconimage, description)

elif mode == 111:
    from resources.lib.indexers import oipeirates
    oipeirates.get_links_series(name, url, iconimage, description)

elif mode == 112:
    from resources.lib.indexers import oipeirates
    oipeirates.oipeirates_series(url)

######################RESOLVE#######################

elif mode == 100:
    resolve(name, url, iconimage, description)


####################MYVIDEOLINKS###################

elif mode == 101:
    from resources.lib.indexers import myvideolinks
    myvideolinks.search(url)

elif mode == 102:
    from resources.lib.indexers import myvideolinks
    myvideolinks.myvideolinks(url)

elif mode == 103:
    from resources.lib.indexers import myvideolinks
    myvideolinks.get_links(name, url, iconimage, description)

elif mode == 1040:
    from resources.lib.indexers import myvideolinks
    myvideolinks.get_links_series(name, url, iconimage, description)


####################BNWMOVIES###################

elif mode == 104:
    from resources.lib.indexers import bnwmovies
    bnwmovies.menu_genre()

elif mode == 105:
    from resources.lib.indexers import bnwmovies
    bnwmovies.bnwmovies(url)

elif mode == 106:
    from resources.lib.indexers import bnwmovies
    bnwmovies.get_links(name, url, iconimage, description)

################COOLMOVIEZONE###################

elif mode == 107:
    from resources.lib.indexers import coolmoviezone
    coolmoviezone.menu_year()

elif mode == 108:
    from resources.lib.indexers import coolmoviezone
    coolmoviezone.menu_genre()

elif mode == 109:
    from resources.lib.indexers import coolmoviezone
    coolmoviezone.coolmoviezone(url)

elif mode == 110:
    from resources.lib.indexers import coolmoviezone
    coolmoviezone.get_links(name, url, iconimage, description)

elif mode == 113:
    from resources.lib.indexers import coolmoviezone
    coolmoviezone.search(url)

elif mode == 114:
    from resources.lib.indexers import coolmoviezone
    coolmoviezone.coolmoviezone_2(url)

elif mode == 115:
    from resources.lib.indexers import coolmoviezone
    coolmoviezone.get_links_search(name, url, iconimage, description)

elif mode == 116:
    from resources.lib.indexers import coolmoviezone
    coolmoviezone.coolmoviezone_search(url)

###################NTOKIMANTER.GR###################

elif mode == 117:
    from resources.lib.indexers import ntokimanter
    ntokimanter.menu_genre()

elif mode == 118:
    from resources.lib.indexers import ntokimanter
    ntokimanter.ntokimanter(url)

elif mode == 119:
    from resources.lib.indexers import ntokimanter
    ntokimanter.get_links(name, url, iconimage, description)

###################GAMATOMOVIES###################

elif mode == 121:
    from resources.lib.indexers import gamatomovies
    gamatomovies.search(url)

elif mode == 122:
    from resources.lib.indexers import gamatomovies
    gamatomovies.gamatomovies(url)

elif mode == 123:
    from resources.lib.indexers import gamatomovies
    gamatomovies.get_links(name, url, iconimage, description)

elif mode == 124:
    from resources.lib.indexers import gamatomovies
    gamatomovies.menu_year()

elif mode == 125:
    from resources.lib.indexers import gamatomovies
    gamatomovies.menu_genre()

elif mode == 126:
    from resources.lib.indexers import gamatomovies
    gamatomovies.gamatomoviestv(url)

elif mode == 127:
    from resources.lib.indexers import gamatomovies
    gamatomovies.season_tv(url)

elif mode == 129:
    from resources.lib.indexers import gamatomovies
    gamatomovies.epi_tv(url)

elif mode == 130:
    from resources.lib.indexers import gamatomovies
    gamatomovies.get_links_tv(name, url, iconimage, description)

#xbmcplugin.endOfDirectory(int(sys.argv[1]))

xbmcplugin.endOfDirectory(handle)