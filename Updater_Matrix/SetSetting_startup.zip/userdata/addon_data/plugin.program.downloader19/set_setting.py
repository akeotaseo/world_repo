﻿import xbmc, xbmcaddon
from updatervar import *

Dialog_U1                 = '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]'
Dialog_U4                 = '[B]Ολοκληρώθηκε με επιτυχία[/B]'

def set_setting():


    ###  ===Homelander===   ###
    #BG.update(30, Dialog_U1, 'Ενημέρωσης ρυθμίσεων...')
    #addon_homelander     = xbmcaddon.Addon('plugin.video.homelander')
    #setting_homelander     = addon_homelander.getSetting
    #setting_set_homelander = addon_homelander.setSetting
    #if setting_homelander('subtitles')=='false':
        #xbmc.sleep(1000)
        #setting_set_homelander('subtitles', 'true')
        #BG.update(33, Dialog_U1, 'Ενεργοποίηση υποτίτλων Homelander...')
        #xbmc.sleep(2000)
        #setting_set_homelander('subtitles.lang.1', 'Greek')
        #setting_set_homelander('subtitles.lang.2', 'English')
        #BG.update(39, Dialog_U1, 'Επιλογή κύριας γλώσσας υποτίτλων σε Ελληνικά...')
        #xbmc.sleep(2000)
    #if setting_homelander('providers.lang')=='English':
        #xbmc.sleep(1000)
        #setting_set_homelander('providers.lang', 'Greek+English')
        #BG.update(45, Dialog_U1, 'Επιλογή παρόχων σε Greek+English...')
        #xbmc.sleep(2000)
        
    addon_myiptv       = xbmcaddon.Addon('plugin.video.myiptv')
    setting_myiptv     = addon_myiptv.getSetting
    setting_set_myiptv = addon_myiptv.setSetting
    if not setting_myiptv('player_type')=='0':
        xbmc.sleep(500)
        setting_set_myiptv('player_type', '1')

    BG.create(Dialog_U1, Dialog_U4)
    xbmc.sleep(1000)
    BG.update(100, Dialog_U1, Dialog_U4)
    BG.close()
#            xbmc.executebuiltin("ReloadSkin()")

set_setting()
