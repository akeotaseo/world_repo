# -*- coding: utf-8 -*-

import os
import re, json

import urllib.parse as urlparse
import requests
import codecs

import ssl
from urllib3.poolmanager import PoolManager
from requests.adapters import HTTPAdapter

import socket
import time
from http.cookiejar import LWPCookieJar, MozillaCookieJar
from html import unescape
from .fileUtils import fileExists, setFileContent, getFileContent
from . import datetimeUtils as dt
from collections import OrderedDict

import lib.common



#------------------------------------------------------------------------------
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
socket.setdefaulttimeout(30)

#use ipv4 only
origGetAddrInfo = socket.getaddrinfo

def getAddrInfoWrapper(host, port, family=0, socktype=0, proto=0, flags=0):
    return origGetAddrInfo(host, port, socket.AF_INET, socktype, proto, flags)

# replace the original socket.getaddrinfo by our version
socket.getaddrinfo = getAddrInfoWrapper


#------------------------------------------------------------------------------


'''
    REQUEST classes
'''


class TLS12HttpAdapter(HTTPAdapter):
    """"Transport adapter that forces the use of TLS v1.2"""
    def init_poolmanager(self, connections, maxsize, block=False):
        self.poolmanager = PoolManager(
            num_pools=connections, maxsize=maxsize,
            block=block, ssl_version=ssl.PROTOCOL_TLSv1_2)


class BaseRequest(object):
    def __init__(self, cookie_file=None):
        self.cookie_file = cookie_file
        self.UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        self.s = requests.Session()
        self.s.cookies = LWPCookieJar(self.cookie_file)  # MozillaCookieJar(self.cookie_file) 
        if fileExists(self.cookie_file):
            self.s.cookies.load(ignore_discard=True)
        self.s.headers.update({"User-Agent": self.UA})
        self.s.headers.update({"Accept-Encoding": "gzip, deflate"})  # requests can't handle br
        self.s.headers.update({"Accept-Language": "en-US,en;q=0.9,de;q=0.8,es;q=0.7"})
        self.s.headers.update({"Upgrade-Insecure-Requests": "1"})
        self.url = ""

    def fixurl(self, url):
        # url is unicode (quoted or unquoted)
        try:
            # url is already quoted
            url = url.encode('ascii').decode()
        except:
            # quote url if it is unicode
            parsed_link = urlparse.urlsplit(url)
            parsed_link = parsed_link._replace(netloc=parsed_link.netloc.encode('idna').decode(),
                                               path=urlparse.quote(parsed_link.path.encode('utf-8').decode()),
                                               query=urlparse.quote(parsed_link.query.encode('utf-8').decode(),safe='+?=&'),
                                               fragment=urlparse.quote(parsed_link.fragment.encode('utf-8').decode())
                                               )
            url = parsed_link.geturl().encode('ascii').decode()
        # url is str (quoted)
        return url

    # 30x response redirect location
    def getLocation(self, url):
        if '|' in url:
            sp = url.split('|')
            url = sp[0]
            headers = dict(urlparse.parse_qsl(sp[1]))
            self.s.headers = headers
        r = self.s.get(url, allow_redirects=False, timeout=20)
        if 'Location' in r.headers:
            rloc = r.headers['Location']
        else:
            rloc = url
        return rloc

    def getSource(self, url, form_data, referer, xml=False, mobile=False, redir=True):
        url = self.fixurl(url)

        if not referer:
            referer = url
        else:
            referer = self.fixurl(referer.replace('wizhdsports.be', 'wizhdsports.is').replace('ibrod.tv', 'www.ibrod.tv').replace('livetv123.net', 'livetv742.me'))

        self.s.headers.update({'Referer': referer})

        if '|' in url:  # override/update headers if piped to url
            sp = url.split('|')
            url = sp[0]
            headers = dict(urlparse.parse_qsl(sp[1]))
            self.s.headers.update(headers)

        if 'liveonlinetv247' in urlparse.urlsplit(url).netloc:
            mobile = True

        if mobile:
            self.s.headers.update({'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36'})

        if xml:
            self.s.headers['X-Requested-With'] = 'XMLHttpRequest'

        if 'cndhlsstream.pw' in urlparse.urlsplit(url).netloc:
            del self.s.headers['Accept-Encoding']
        if 'skstream.tv' in urlparse.urlsplit(url).netloc:
            del self.s.headers['Accept-Encoding']
        if 'bstream.tech' in urlparse.urlsplit(url).netloc:
            del self.s.headers['Accept-Encoding']
        if 'bcast.site' in urlparse.urlsplit(url).netloc:
            del self.s.headers['Accept-Encoding']
        if 'bcast.pw' in urlparse.urlsplit(url).netloc:
            del self.s.headers['Accept-Encoding']
        if 'live247.online' in urlparse.urlsplit(url).netloc:
            del self.s.headers['Accept-Encoding']
        if 'indexstream.tv' in urlparse.urlsplit(url).netloc:
            del self.s.headers['Accept-Encoding']
        
        if 'streamlive.to' in urlparse.urlsplit(url).netloc:
            self.s.verify = False

        if 'vipleague' in url or 'strikeout' in url or 'homerun' or 'nbastream' in url:
            #self.s.verify = False
            pass

        if 'vipstand.pm' in url or 'vipstand.st' in url:
            self.s.verify = False
        
        if 'bypassed' in url or 'livecamtv.me' in url or 'seelive.me' in url or 'tvply.me' in url or 'nolive.me' in url:
            self.s.verify = False

        if 'firstonetv' in url: 
            self.s.verify = False

        if 'vaughn.live' in url:
            self.s.verify = False
        
        if 'ustreamix' in url:
            self.s.verify = False

        if 'vergol' in url or 'vercanales' in url:
            self.s.verify = False

        if 'telerium.tv' in url or 'cdn4.us' in url:
            self.s.verify = False

        if 'player.jokehd' in url:
            redir = False

        if 'airhdx.com' in url:
            self.s.verify = False

        if 'mylivesport.ru' in url:
            self.s.verify = False

        if 'livestreamapi.ru' in url:
            self.s.verify = False

        if 'live.telelatinohd.com' in url:
            self.s.verify = False

        if re.search(r'telerium\.tv.*?m3u8', url) is not None:
            self.s.headers['Cookie'] = 'volumen=0;'
            self.s.headers.update({'Host': 'telerium.tv'})
        if re.search(r'teleriumtv\.net', url) is not None:
            self.s.headers["Cookie"] = "volume=0;"
        if re.search(r'netspor.*?\/live.txt', url) is not None:
            self.s.headers['Cookie'] = 'cookieSecure=aa8c2d6c6be738b6132895f6a1aad90e;'
        if re.search(r'sportscentral.io\/new-api\/matches', url) is not None:
            url = url + '?date=%s' % (dt.convTimestamp(dt.getUnixTimestamp(), '%Y-%m-%d'))            

        if 'auth.livecamtv' in url:
            self.s.headers.update({"Origin": "https://www.seelive.me"})

        if 'livestreamapi.ru/api/get.php' in url:
            self.s.headers.update({"Referer": "https://live-sport24.com/"})

        if "seckeyserv.me" in url or "walletkeyslocker.me" in url:
            self.s.mount("https://", TLS12HttpAdapter()) #force TLS1.2
            self.s.headers.update({"Origin": "https://www.niaomea.me"})

        if "streamlive.to" in url:
            self.s.mount("https://", TLS12HttpAdapter())

        if "www.soccerfan.biz/page.php" in url:
            self.s.headers.update({"Referer": "https://pipipopo.me/"})

        # if re.search(r'https:\/\/flowcablevision.com\/\w+\.php', url) != None:
        if "https://flowcablevision.com" in url:
            self.s.verify = False

        if "https://flowcablevision.com/online.php?" in url:
            self.s.headers.update({"Referer": "http://lacalleochotv.org/"})

        if "primetubsub.xyz/premiumtv/daddylive.php" in url:
            self.s.headers.update({"Referer": "https://daddylive.eu/"})

        if "vipbitcoins.com/page.php?hash=" in url:
            self.s.headers.update({"Referer": "https://livetvspecial.top/"})

        if "southmasalapic.com/page.php?hash=" in url:
            self.s.headers.update({"Referer": "https://favoritegames.xyz/"})

        if "iscooler.com/page.php?hash=" in url:
            self.s.headers.update({"Referer": "https://togotv.cyou/"})

        if "streamservicehd.click" in url and "livetvon" in url:
            self.s.headers.update({"Referer": "https://livetvon.click/mylive/"})

        if 'visiblesafe.com/page.php' in url:
            self.s.headers['Referer'] = 'https://playermyplayer.me/'

        if 'darsalam.net/page.php' in url:
            self.s.headers['Referer'] = 'https://erostvnow.xyz/'

        if 'top.worldcupglory.com' in url:
            url = url.replace('top.worldcupglory.com', 'top.crackstreamsfree.com')

        if re.search(r'photocall\.(?:tv|xyz).*?_[fm]\?', url) != None:
            self.s.headers.update({"Referer": url})
            url = re.sub(r'_[fm]', '', url)

        if "https://api.production.k8s.y3o.tv/naboo/zattoo/streams/" in url:
            mandaurl = url.replace("naboo", "mandalore/validation")
            mandaurl = mandaurl.replace("stream_type=dash_widevine", "preflight=true")
            try:
                pftoken = requests.get(mandaurl,
                                    headers = {"User-Agent": self.UA,
                                                "Origin": "https://yallo.tv", 
                                                "X-Tenant": "yallo"}
                                    ).json()["preflight_token"]
                url = url + "&preflight_token={}".format(pftoken)
            except:
                import traceback
                traceback.print_exc()


        #if 'strikeout' in urlparse.urlsplit(url).netloc:
            #self.s.headers.update({'Upgrade-Insecure-Requests': '1'})
            #self.s.headers.update({'Host': 'zoomtv.me'})
            # self.s.headers.update({'Accept' : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'})
            # self.s.headers.update({'Accept-Language' : 'en-US,en;q=0.8,de;q=0.6,es;q=0.4'})
            #self.s.headers.update({'Accept-Encoding': 'gzip, deflate'})
            #self.s.headers.update({'Connection' : 'keep-alive'})
            # self.s.headers.update({'Origin': 'http://www.strikeout.co'})
            # self.s.headers.update({'Content-Type': 'application/x-www-form-urlencoded'})
            
        
        if form_data:
            #zo**tv
            #if 'uagent' in form_data[0]:
               #form_data[0] = ('uagent',urllib.quote(self.s.headers['User-Agent']))
                #if len(form_data) > 4 and 'Cookie' in form_data[4]:
                    #headers['Cookie'] = form_data[4][1]
                    #del form_data[4]
                   
                #headers['Content-Type'] = 'application/x-www-form-urlencoded'
                #headers['User-Agent'] = self.s.headers['User-Agent']
                #lib.common.log("JairoX10:" + form_data[0][1])
            if 'firstonetv' in url and len(form_data) > 0:    
                # tmp_data = dict(form_data)
                # cookies = str(tmp_data['cookie'])
                # cookies = cookies.replace('___', ';')
                cookies = requests.utils.dict_from_cookiejar(self.s.cookies)
                evercookie = {'evercookie_cache': '', 'evercookie_etag': '', 'evercookie_png': '', 'f1tvuvid': ''}
                cookies.update(evercookie)
                cookiestr = "; ".join(["=".join([key, str(val)]) for key, val in cookies.items()])
                self.s.headers['Cookie'] = cookiestr
                # tmp_data.pop('cookie')
                # form_data = tmp_data.items()
            
            if 'tvply.me' in url and len(form_data) > 0:
                #cookies = requests.utils.dict_from_cookiejar(self.s.cookies)
                #cookies.update('rcavds=4;')
                self.s.headers['Cookie'] = 'zkun=Y; rcavds=2'
                self.s.headers['Origin'] = 'https://www.vipstand.pm'
            
            if ('niaomea.me' in url or 'sinvida.me' in url) and len(form_data) > 0:
                self.s.headers['Cookie'] = 'tamedy=4; _pshflg=~'
                self.s.headers['Origin'] = 'https://www.vipstand.pm'
            
            if 'stream2watch.sx/calls/get/source' in url:
                self.s.headers['X-Requested-With'] = 'XMLHttpRequest'
                self.s.headers['Origin'] = 'https://hd-tv.stream2watch.sx'
                self.s.headers['Referer'] = 'https://hd-tv.stream2watch.sx/'
            if 'https://klubsports.click/live/player2' in url:
                self.s.headers['Referer'] = 'https://klubsports.click/'

            if 'streamlive.to/channelsPages' in url:
                self.s.headers['X-Requested-With'] = 'XMLHttpRequest'
            if not isinstance(form_data, dict):
                form_data = {t[0]: t[1] for t in form_data} # convert to dict

            r = self.s.post(url, data=form_data, timeout=(5, 20))
  
        else:
            try:
                r = self.s.get(url, timeout=(5, 20), allow_redirects=redir)
                if r.status_code in [429, 503]:
                    try:
                        import cloudscraper2
                        scraper = cloudscraper2.create_scraper(sess=self.s)                    
                        r = scraper.get(url, headers=self.s.headers)
                    except:
                        pass
                    #lib.common.log("JairoX_CFScrape:    %d"%r.status_code)

            except requests.exceptions.RequestException as ex:
                lib.common.log("Requests error: " + str(ex))
                return 'pass'
            except:
                # import traceback
                # traceback.print_exc()
                return 'getSource error'
        
        #many utf8 encodings are specified in HTTP body not headers and requests only checks headers, maybe use html5lib
        #https://github.com/kennethreitz/requests/issues/2086
        if 'streamlive.to' in urlparse.urlsplit(url).netloc \
        or 'sport365.live' in urlparse.urlsplit(url).netloc \
        or 'vipleague' in urlparse.urlsplit(url).netloc \
        or 'cinestrenostv.tv' in urlparse.urlsplit(url).netloc \
        or 'batmanstream.com' in urlparse.urlsplit(url).netloc \
        or 'dailydeports.pw' in urlparse.urlsplit(url).netloc \
        or 'sportsembed.su' in urlparse.urlsplit(url).netloc \
        or 'telelatinohd.com' in urlparse.urlsplit(url).netloc \
        or 'sportcategory.com' in urlparse.urlsplit(url).netloc:
            r.encoding = 'utf-8'
        if 'lfootball.ws' in urlparse.urlsplit(url).netloc:
            r.encoding = 'windows-1251'

        response = r.text

        # if 'dailydeports.pw' in urlparse.urlsplit(url).netloc and 'Schedule' in response:
        #     try:
        #         #page = unicode(response, 'utf-8')
        #         page = response #.decode('utf8')
        #         items = re.findall(r'(?s)<font.+?b>(http[^<]+).+?font>([^<]+)', page)
        #         res = ""
        #         for item in items:
        #             titles = re.findall(r'(\d+:\d+)\s+([^\n]+)', item[1])
        #             for title in titles:
        #                 res+='<url>%s</url><time>%s</time><event>%s</event>\n'%(item[0],title[0],title[1])
        #         response = res
        #     except:
        #          pass
            #lib.common.log("JairoWebUtils:    %s"%response)

        # if re.search(r'netspor.*?\/live.txt', url) != None:
        #     js = json.loads(response)
        #     response=''
        #     for c in js:
        #         response+='id=%s@@@event=%s@@@sport=%s@@@other=%s@@@country=%s@@@time=%s@@@live=%s@@@\n'%(
        #             c['id'], c['baslik'], c['turu'], 
        #             (c['3'] if len(c['3'])>2 else c['turu']), 
        #             (c['bayrak'].upper() if len(c['bayrak'])==2 else '00'), 
        #             c['tarih'], ('1' if 'live' in c else '0'))
        #         #response = response.encode("utf-8") 

        #if re.search(r'darsh.sportsvideo.net\/api\/top-matches-soccerstreams', url) != None:
        if re.search(r'sportscentral.io\/new-api\/matches', url) != None:
            js = json.loads(response)
            response = ''
            data = []
            today = dt.convTimestamp(dt.getUnixTimestamp(),'%Y-%m-%d')
            for c in js:
                liga = c['name']
                logo = c['logo']
                sport = "soccer"  # c['type']
                for e in c['events']:
                    logo = c['logo']
                    status = e['status']['type']
                    if status != 'finished' and e['startDate'] == today:
                        data.append({'liga': liga, 'logo': logo, 'time': e['startTime'], 'status': status, 'sport': sport,
                                'ts': e['startTimestamp'], 'event': e['homeTeam']['name'] + " vs. " + e['awayTeam']['name'], 
                                # 'link':e['eventLink'].replace('sportsvideo.net/watch', 'darsh.sportsvideo.net/api/event/soccerstreams')
                                'link': 'https://sportscentral.io/streams-table/%s/soccer?new-ui=1&origin=redi1.soccerstreams.net' % e["id"]
                                })

            data = sorted(data, key=lambda x: x['ts'])
            for c in data:
                response += 'liga=%s@@@logo=%s@@@time=%s@@@event=%s@@@link=%s@@@status=%s@@@sport=%s@@@\n' % (c['liga'], c['logo'],
                                                                                c['ts'], c['event'], c['link'], c['status'], c['sport'])

        if "live-sports-stream.net/schedule" in url:
            secs = re.findall(r'<b>\s*Channel\s+(\d+)(.*?)iframe\s+src="([^"]+)', response, re.S)
            lst = []
            for sec in secs:
                events = re.findall(r'(\d+:\d+)\s*-\s*(.*?)\n', sec[1])
                for event in events:
                    lst.append((event[0], event[1], sec[0], sec[2]))

            lst = sorted(lst, key=lambda x: time.strptime(x[0], "%H:%M"))
            response_ = ""
            for l in lst:
                response_ += "@@@".join(l) + "@@@\n"

            response = response_

        if "https://liveon.sx/list" in url:
            try:
                section = re.findall(r'<table class="styled-table1">(.*?)</div>\s*</div>)', response, re.S)[0]
            except:
                section = response
            items = re.findall(r'<div\s+class="d[12]">.*?<td>.*?<a\s+href="https[^"]+\/(\w+)".*?<div class="left\d"\s*>(.*?)<\/div>', section, re.S)
            lst = []
            for item in items:
                events = re.findall(r'(\d+:\d+)\s+(.*?)[$\n\r]', item[1])
                for event in events:
                    lst.append((event[0], event[1], item[0]))
            lst = sorted(lst, key=lambda x: time.strptime(x[0], "%H:%M"))
            response_ = ""
            for l in lst:
                response_ += "@@@".join(l) + "@@@\n"

            response += "<br /><br /><br />"
            response += response_

        if "https://dlhd.sx/schedule/schedule-generated.json" in url:
            try:
                response_ = ""
                response = json.loads(response)
                for day in response:
                    response_ += "<day={}>".format(re.findall(r'^(.*?)\s*-', day)[0])
                    for cat in response[day]:
                        response_ += "<cat={}>".format(cat)
                        events = json.dumps(response[day][cat])
                        response_ += "<events>{}</events>".format(events)
                        response_ += "</cat>"
                    response_ += "</day>"

                response = response_
            except:
                pass

        if 'beget=begetok' in response:  # av
            _cookie = requests.cookies.create_cookie('beget', 'begetok', domain=urlparse.urlsplit(url).netloc, path='/')
            self.s.cookies.set_cookie(_cookie)
            r = self.s.get(url, headers=self.s.headers, timeout=20)
            response = r.text

        if 'fromCharCode,sucuri_cloudproxy_js' in response:  # sebn
            from sucuri import sucuri_decode
            sucuri_name, sucuri_value = sucuri_decode(response)
            sucuri_cookie = requests.cookies.create_cookie(sucuri_name, sucuri_value, domain=urlparse.urlsplit(url).netloc, path='/',
                                                           discard=False, expires=(time.time() + 86400))
            self.s.cookies.set_cookie(sucuri_cookie)
            r = self.s.get(url, headers=self.s.headers, timeout=20)
            response = r.text

        if 'streamlive.to/channelsPages' in url:
            try:
                response = json.loads(response)["html"]
            except:
                pass

        if 'https://api.jokerlivestream.vip' in url:
            try:
                tomorrow = dt.datetime.datetime.today() + dt.datetime.timedelta(days=1)
                midnight = dt.datetime.datetime(tomorrow.year, tomorrow.month, tomorrow.day, 0, 0, 0)
                endtime = dt.datetime.datetime.today() + dt.datetime.timedelta(hours=12)
                response = json.loads(response)
                if "collection" in response:
                    data_ = response["collection"]
                #api doesn't return collection if less than 2 pages of events -> get page 1 from json url
                else:
                    sport = form_data["sport_name"]
                    r = self.s.get("https://www.jokerlivestream.vip/_next/data/A-ESjVmhwJxBdcZxusJzK/en/{}.json?gameMatchName={}".format(sport, sport), headers=self.s.headers, timeout=20)
                    response = r.text
                    response = json.loads(response)
                    data_ = response["pageProps"]["events"]

                data_ = [i for i in data_ if i["start_time"] < endtime.timestamp()]
                response["collection"] = data_
                response = json.dumps(response, ensure_ascii=False)
            except:
                #import traceback
                #traceback.print_exc()
                pass

        if 'mpd.php?id=' in url and 'https://latele-envivo.com/mpd.php?id=' in self.s.headers["Referer"]:
            id = re.findall(r'\?id=(.+)', self.s.headers["Referer"])[0]
            try:
                # use double curly brackets or double % if needed as pattern with format
                data_ = re.findall(r'if\s+\(id\s*==\s*"{0}"\)\s*({{.*?}})'.format(id), response, re.S)[0]
            except:
                #import traceback
                #traceback.print_exc()
                pass
            response = 'https://latele-envivo.com\n\n' + data_

        if "https://sport247.live/assets/events.json" in url:
            try:
                response = response.replace('\\u00a0',' ')
                data_ = json.loads(response)
                for it in data_:
                    pair = it["home"] 
                    pair = pair if it["away"] == "" else "{} vs {}".format(pair, it["away"])
                    it["pair"] = pair.replace("vs", "-")
                    pair = pair.replace(" ", "-").replace("/", "-").lower()
                    for s in it["streams"]:
                        if "http" in s["ch"]:
                            link = s["ch"]
                            s["ch"] = "CDN"
                        elif s["ch"].isnumeric():
                            link = "http://h5.365streams.world/{}/{}?player={}".format(it["type"].lower().replace(" ", "-"),
                                                                            pair.replace("'", ""),
                                                                            s["ch"])
                        s["link"] = link
                response = json.dumps(data_)

            except:
                import traceback
                traceback.print_exc()
                pass

        if 'https://yallo.tv' in url:
            try:                
                self.s.headers.update({'Origin': 'https://yallo.tv', 'X-Tenant': 'yallo'})
                self.s.headers.pop('Referer')
                userid = self.s.post("https://api.production.k8s.y3o.tv/kamino/users/anonymous/", data={}).json()["id"]
                token = self.s.get("https://api.production.k8s.y3o.tv/kamino/auth/login?user_id={}&device_type_name=webclient".format(userid)).json()["client_jwt_token"]
                self.s.headers.update({"Authorization": "Bearer {}".format(token)})
                tenant = self.s.get("https://api.production.k8s.y3o.tv/kamino/users/me").json()["tenant"]["id"]
                self.s.headers.pop("Authorization")
                categ = self.s.get("https://data.production.web.y3o.tv/channel-groups/tenants/{}/de/full.json".format(tenant)).json()["result"]
                chs = self.s.get("https://data.production.web.y3o.tv/channel/full.json").json()["result"]
                #epg = self.s.get("https://data.production.web.y3o.tv/epg/day/{}/full.json".format(dt.datetime.datetime.now().strftime('%Y-%m-%d'))).json()["result"]

                hour = dt.datetime.timedelta(hours=1)
                now = dt.datetime.datetime.now() - hour
                epg = []
                for i in range(1, 5):
                    epg_ = self.s.get("https://data.production.web.y3o.tv/epg/timeframes/v2/{}/{}/full.json".
                            format(now.strftime('%Y-%m-%d'), urlparse.quote(now.strftime('%Y-%m-%dT%H:00:00+00:00')))).json()["result"]
                    epg += epg_
                    now += hour

                def getepg(epg, id):
                    ts = int(dt.datetime.datetime.now().timestamp())
                    epg = [e for e in epg if e["channel"]["id"] == id and e["actual_start_sec"] >= ts - 7200]
                    epg = [e for n, e in enumerate(epg) if e not in epg[n + 1:]]  # remove duplicates
                    epg = sorted(epg, key=lambda x: x["actual_start_sec"])
                    epgstr = "^^CR$$"
                    for e in epg:
                        epgstr += "^^COLOR=blue$${}:^^/COLOR$$ {}".format(dt.datetime.datetime.fromtimestamp(e["actual_start_sec"]).strftime("%H:%M"),
                                                e["asset"]["title"]["en"] if "en" in e["asset"]["title"] 
                                                    and e["asset"]["title"]["en"] != "" 
                                                    and e["asset"]["title"]["en"] is not None 
                                                    else e["asset"]["title"]["de"]
                                                )
                        epgstr += "^^CR$$"

                    return epgstr

                catchns = []
                for cat in categ:
                    if cat["name"] not in ["All", "MySports"]:
                        channels = []
                        for chan in cat["channels"]:
                            for c in chs:
                                if chan["channel"]["id"] == c["id"]:
                                    channels.append({
                                                    "id": c["id"],
                                                    "sname": c["short_name"],
                                                    "name": c["long_name"]["en"],
                                                    "logo": c["logos"][0]["url"],
                                                    "url": c["naboo_urls"]["streams"],
                                                    "token": token,
                                                    "plot": getepg(epg, c["id"])
                                                    })

                        catchns.append({"name": cat["display_name"]["en"],
                                        "displaynames": cat["display_name"],
                                        "channels": channels})

                response = json.dumps(catchns)
            except:
                # import traceback
                # traceback.print_exc()
                pass

        if len(response) > 10:
            self.s.cookies.save(ignore_discard=True)

        self.s.close()

        return unescape(response)


#------------------------------------------------------------------------------

class DemystifiedWebRequest(BaseRequest):

    def __init__(self, cookiePath):
        super(DemystifiedWebRequest, self).__init__(cookiePath)

    def getSource(self, url, form_data, referer='', xml=False, mobile=False, demystify=False):
        data = super(DemystifiedWebRequest, self).getSource(url, form_data, referer, xml, mobile)
        if not data:
            return None

        if not demystify:
            # remove comments
            r = re.compile('<!--.*?(?!//)--!*>', re.IGNORECASE + re.DOTALL + re.MULTILINE)
            m = r.findall(data)
            if m:
                for comment in m:
                    data = data.replace(comment, '')
        else:
            from . import decryptionUtils as crypt
            data = crypt.doDemystify(data)

        return data

#------------------------------------------------------------------------------


class CachedWebRequest(DemystifiedWebRequest):

    def __init__(self, cookiePath, cachePath):
        super(CachedWebRequest, self).__init__(cookiePath)
        self.cachePath = cachePath
        self.cachedSourcePath = os.path.join(self.cachePath, 'page.html')
        self.currentUrlPath = os.path.join(self.cachePath, 'currenturl')
        self.lastUrlPath = os.path.join(self.cachePath, 'lasturl')
        self.lastAccessTime = os.path.join(self.cachePath, 'lastaccess')

    def __setLastUrl(self, url):
        setFileContent(self.lastUrlPath, url)
        setFileContent(self.lastAccessTime, str(time.time()).split('.')[0])

    def __getCachedSource(self):
        try:
            data = getFileContent(self.cachedSourcePath)
        except:
            pass
        return data

    def __getLastUrl(self):
        return getFileContent(self.lastUrlPath)

    def __getLastAccessTime(self):
        return getFileContent(self.lastAccessTime)

    def getSource(self, url, form_data, referer='', xml=False, mobile=False, ignoreCache=False, demystify=False, timeout=0):
        if 'tvone.xml' in url:
            self.cachedSourcePath = url
            data = self.__getCachedSource()
            return data
        if '.r.de.a2ip.ru' in url:
            parsed_link = urlparse.urlsplit(url)
            parsed_link = parsed_link._replace(netloc=codecs.decode(parsed_link.netloc.replace('.r.de.a2ip.ru',''), 'rot13'))
            url = parsed_link.geturl()
        if 'calls/get/source' in url:
            ignoreCache = True
        if re.search(r'netspor.*?\/en/channel/watch', url) != None:
            ignoreCache = False
            timeout = 30
            demystify = True
        if 'nowlive.pro' in url:
            demystify = True
        if re.search(r'jokerlivestream\.\w+\/.*?-live-stream(?:ing)?-\d+.html', url) != None:
            demystify = True
        # if 'vipleague' in url:
        #     ignoreCache = False
        #     timeout = 30
        if 'mlbstream.io' in url:
            ignoreCache = False
            timeout = 30
        if 'telerium.tv/streams' in url or 'teleriumtv.net/streams' in url:
            ignoreCache = True
        if 'cricfree.io/ch' in url:
            ignoreCache = False 
            timeout = 10
        if '1stream.top' in url:
            demystify = False
        if 'yallo.tv/' in url:
            ignoreCache = False
            timeout = 60

        # if 'live-stream.fun/onlineplayer.php' in url:
        #     demystify = True

        __minpassed = 0
        if timeout > 0:
            try:
                t1 = int(self.__getLastAccessTime())
                t2 = int(str(time.time()).split('.')[0])
                __minpassed = int((t2 - t1) / 60)
            except:
                pass

        if url == self.__getLastUrl() and not ignoreCache and timeout > __minpassed:
            data = self.__getCachedSource()
        else:
            data = super(CachedWebRequest, self).getSource(url, form_data, referer, xml, mobile, demystify)            
            if data:
                # Cache url
                self.__setLastUrl(url)
                # Cache page
                setFileContent(self.cachedSourcePath, data)        

        return data


class WSCLient:
    #websocket client ... maybe implement parser command for this later
    def __init__(self):
        # super(WSCLient, self).__init__()
        # self.s = requests.Session()
        # self.s.headers.update({'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36'})
        # self.s.headers.update({'Accept-Encoding': 'gzip, deflate'})
        pass

    def getSS365(self, url):
        #solution for ss365
        try:
            #import websocket
            from websocket import create_connection
            # websocket.enableTrace(True)         
            # url_ = urlparse.urlsplit(url)
            # sport_ = url_.query.split('=')[1]
            # r = self.s.get('http://sportstream-365.com/').text
            # #tagz = re.findall(r'tagz\s*=\s*"([^"]+)', r)[0]
            # self.s.headers['X-Requested-With'] = 'XMLHttpRequest'
            # neg = self.s.post('http://sportstream-365.com/signcon/negotiate?negotiateVersion=1', data=None).text
            # neg = json.loads(neg)
            # connid = neg['connectionToken']
            # wsurl = "ws://sportstream-365.com/signcon?id=%s"%connid
            # ws = create_connection(wsurl)
            # ws.send('{"protocol":"json","version":1}\x1E')
            # ws.recv()
            # ws.send('{"arguments":[{"partner":2,"lng":"en","typegame":3}],"invocationId":"0","streamIds":[],"target":"ConnectClient","type":1}\x1E')
            # ws.recv()
            # ws.send('{"arguments":["%s","en",24],"invocationId":"1","streamIds":[],"target":"GetFeed","type":1}\x1E'%sport_)
            ws = create_connection(url,
                                   headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                                            'Origin': 'https://365livesport.pro'
                                            })
            ws.send('{"data":{"task":"Feed","action":"SetLang","data":{"lang":2}}}')
            result = ws.recv()
            ws.send('{"data":{"task":"Odd","action":"GetPartners","data":{}}}')
            result = ws.recv()
            ws.send('{"data":{"task":"Feed","action":"Highlight","data":{"lang":2,"sport_id":1}}}')
            result = ws.recv()
            
        except:
            # import traceback,sys
            # traceback.print_exc(file = sys.stdout)
            result = 'error'
            
        finally:
            ws.close()
            # self.s.close()
            # result = result.split('\x1E')[0]
            try:
                result = json.loads(result)
                result = result['data']
                finalevents = []
                for event in result["events"]:
                    event_ = OrderedDict()
                    try:
                        event_["id"] = event["id"]
                        event_["time"] = event["time"]
                        event_["sport_id"] = event["sport_id"]
                        event_["url"] = "<365livesport>" + event["description"]["hls"] + "</365livesport>" if "hls" in event["description"] else ""
                        event_["team1"] = event["team1"]
                        event_["team2"] = event["team2"]
                        event_["is_live"] = event["is_live"]
                        event_["league_id"] = event["league_id"]
                        lname = [league["name"] for league in result["leagues"] if league["id"] == event["league_id"]][0]
                    except:
                        lname = ""
                    event_["league_name"] = lname
                    finalevents.append(event_)
                finalevents = sorted(finalevents, key=lambda x: x["time"])
                result["SDevents"] = finalevents
                result = json.dumps(result)
            except:
                result = result.replace('\\', '')

            # result = result.replace('"isAuth":false},','"isAuth":false,"tagz":"%s"},'%tagz)
            # result = result.replace('"isAuth":false}]','"isAuth":false,"tagz":"%s"}]'%tagz)
            result = codecs.decode(result, "unicode_escape")
            # lib.common.log("JairoooooX_WS:    %s"%repr(result))
            return result
