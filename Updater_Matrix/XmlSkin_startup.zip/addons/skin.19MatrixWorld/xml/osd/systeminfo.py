﻿def systeminfo():
    if xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin("Action(Close)")
        xbmc.executebuiltin("ActivateWindowAndFocus(systeminfo)")
        xbmc.sleep(500)
    while xbmc.getCondVisibility("Window.IsVisible(systeminfo)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")



    if not  xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin("Action(Close)")
        xbmc.executebuiltin("ActivateWindowAndFocus(systeminfo)")
        xbmc.executebuiltin("Action(Pause)")
        xbmc.sleep(500)
    while xbmc.getCondVisibility("Window.IsVisible(systeminfo)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")

systeminfo()
