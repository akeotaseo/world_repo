import kodi_bitchute

if __name__ == '__main__':
    kodi_bitchute.plugin.run()
