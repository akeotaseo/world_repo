def logo_00(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3dVxSCwVlihLwHe80P5Y-E3ubz451tqyHFOLJFARkVFvsQHKOHEFVtifUFHNCW5NVbj-g30_DiOUy9ce15O3ZEqMteZLZiR1qwDIXdAjqxX7J77Horfjcp7EJ86WfVQO2wge80X8Ptn1NvncVnhfSZp=s950-no"
    

def logo_01(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3cXdZWKJ4tImSKlCSbBM6A7bG2ntgGdBoKshDo18-0KVEW5Np7FsOk_Rpg_FvgrC-qzx7HxSz8Es6SZQrEkU29M-tnIOil_VrS8r44eIrYH7Sp3htJtNoT2MQoHubCGHkIiYJKaRdU5u3GQ-U6sNwL5=s950-no"
    

def logo_02(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3cJ3161sL852DPCzC_LFIwWyX9LT2k5GjtvapCX8zjNM7L9Q4UDl6vAiuDkxkQQCJqkM-vKScV6AlAn0E69g8mk8RIizikt5Wd60Z0heM2SK5UQ2EBznT_4IXY0haVvkvajv0Bj_b1g0LW7kGwkpPG7=s950-no"
    

def logo_03(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3eDX6r8V1EY2wI2z3lOQe6OPkjjTKQrFFDqhAG8S9DNXtp0fAgGjL5jyST5IOd_DKby_WmoUi56mRQeO6SXyefgU2lC8iQWTiXOQ_nkU1jwFio_YUwfxxxt1BD_snvpSC7rXb7QwGd0RcvLoT31tC3t=s950-no"
    
def logo_04(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3ebEt4nRWm7-MP9h1cUhLGGdNSrSu3a95E_BWMYJV7EBIt3nufEaC6PRzRRR5tI6-A3QiEMaQz9-4M2qNdUiaQWo1gkrAxxW8kTyVmsxsKqL3u5_xFJFEbvd9OvWCcm_napgXmq-_MZcBQqVmuryWqS=s950-no"
 
 
def logo_05(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3e1-Ro2ll1I-C3FauqFWUOFZDlmtMT7JB9I0SWfU3hzXoAOc4hKbdQyKrdsb2N8DZu6DP00zA2nuPJaT6Ay1eWC4K7i43w52q0EOFyBjayCBvmFw-UNofDfvz1t5L-HQ9Szvv_B_MbENAi55z83ckq3=s950-no"
 
     
def logo_06(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3d20ZdHpqNJz9-WVf8vAqR6EMVP5SCA3SpBHH1i1GEK3EBjDbhBzMK5DOwcdfaza9oFLPrhF-JCzsqQXsmrhmkp9_WDxpKMD619r3gIjB2wsUgue0RIsQRekK1zU7MG9FK8JVUcE0Ly71yBkSy5uXYc=s950-no"
 
 
def logo_07(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3fxDO2RG0k1t__cDWGCWf9V07tV0JbPFNQKNwB2T3boCTf0DvqNcD6mXWw2ZfqLuw-WIAFDOR9WXkK7QmLA8BhT8LbmRzeZQNCn_fBVIasa0uv2kqbNDqsuZihndCpaDfht6OjTrebhEfaiMfn2nGwZ=s950-no"
 
     
def logo_08(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3fa_b1yvtViocq--DP6OaGR1lHN-UBzKiuQIOa6EOFuhEYCAm2aQwZB4FgpIsqDiEqp0xWnmcceY4XfUZhqY2N0g5QP992v1_OajLe5cyGeiN-UlyQblf-_OCU_Ug-D4NvTd3sHtdkIrYPLIk_wNo9L=s950-no"
 
 
def logo_09(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3eTnhe7Bn495oBwTiaRBC4N3prgxQuPquIZscPspxgxyHKvO2DfXHw1cyKCpdXz4b2grwPuPL0ckxkqHzT9ODsxEelEq4nrH3ObFE9FrhwAoHVcG85vB1SMooqfLdcH1uvyVs-H7311gMRJFrKB6hDt=s950-no"
 
     
def logo_10(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3c9-L9LbaawWSd2Cl9efMEhpnTXq6cXTPmvWhmWLQbkodtW0F0DkUHN4wZ1R-aYnIR2Tm1RAGNyyFOwh3XFd3ydjq1s_uf8k3znWmqSu_Af_T4UZ3UCm4beQC7FGC0VtQKnQfx3saVb9LIIETu2CAaU=s950-no"
 
 
def logo_11(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3dJPxlGVw6Uza3ucar7b3LAnFZ5stJCc9TIXez2jPq2dpNdQIBRnJPIm32jNXJxpRIblHrtpuIJJ2NRGE3z9CYWfzGg7j1zSK27tuU6bIPIiyCg2Ob2JMZEkenBgC0xA0VMGauNv9Js4nVI6xYHxN1B=s950-no"
 
     
def logo_12(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3cKz2M3lrBwguLO1criZkL7N6jWff1x0qebSjzzTP7aGpAnBpHRUuLgKhc5DyZ5UTXISBL7zbiHYMAfm1Wkl170yi9NmZkXLTHrn0QSVX1Fwiixa3EgroqiTFiMBWjIE3Exg5ofSZmoBknLHs63WAKh=s950-no"
 
 
def logo_13(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3cdF9ltttuoTXSvjB1Xr2yfn5RAdr1Ci4UIanVS_o1-I4H1Vzrjz5GxrWXPYc0i0LHuBGiSiMcf6EftK_BiGmDSrdmSM4E5f0728J08HqrHUV9BqlHQ6zpSqKztHRjfVWgi-lpLz2SOhDW9uGwVWX1x=s950-no"
 

def logo_duffyou_youtube3(params):
    return "https://lh3.googleusercontent.com/pw/AM-JKLXkldr8lJfGwlKBJw6urPsaPy8kqMOIZyiMzhzos3fz54D0qYjoMp5jLRTHKxgttKEZF0GnVGLImRmuWom-n2jBNeLzFmQQpj08Md3VALm3td1QPuID8LnS7gLCmnT7pJIPHcOHmUNDZZ1QBCEncl-M=w478-h248-no"
    
