import sys
import os
import xbmcplugin
import xbmcgui
import xbmcvfs
import xbmcaddon
import urllib.parse
import resolveurl
from resources.lib.parser import extract_page_movies, base_url, get_cached_movies, cache_movies, extract_categories, search_movies
import html  # Import pentru decodificarea entităților HTML
import json  # Import pentru gestionarea JSON
from urllib.parse import urlparse, urlunparse

# Setările addon-ului
addon_handle = int(sys.argv[1])
addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')

# Directorul de cache
cache_dir = xbmcvfs.translatePath(os.path.join(addon.getAddonInfo('path'), 'cache'))
if not os.path.exists(cache_dir):
    os.makedirs(cache_dir)

# URL-ul de bază al addon-ului
addon_url = sys.argv[0]

def build_url(query):
    return addon_url + '?' + urllib.parse.urlencode(query)

def replace_domain(url, old_domain, new_domain):
    parsed = urlparse(url)
    if old_domain in parsed.netloc:
        # Înlocuiește netloc-ul cu noul domeniu
        new_netloc = parsed.netloc.replace(old_domain, new_domain)
        parsed = parsed._replace(netloc=new_netloc)
        return urlunparse(parsed)
    return url

def list_categories():
    xbmcplugin.setPluginCategory(addon_handle, addon_name)
    xbmcplugin.setContent(addon_handle, 'addons')

    categories = extract_categories(base_url)
    for category in categories:
        list_item = xbmcgui.ListItem(label=category['name'])
        url = build_url({'action': 'list_category', 'category': category['url'], 'page': 1})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)

    # Adăugăm opțiunea de căutare
    search_item = xbmcgui.ListItem(label='Search')
    search_url = build_url({'action': 'search'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=search_url, listitem=search_item, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def list_movies(category_url, page=1):
    xbmcplugin.setPluginCategory(addon_handle, addon_name)
    xbmcplugin.setContent(addon_handle, 'movies')

    cache_file = os.path.join(cache_dir, f"{category_url.replace('/', '_')}_page_{page}.json")
    movies = get_cached_movies(cache_file)
    if not movies:
        page_url = f"{category_url}/page/{page}/"
        movies = extract_page_movies(page_url)
        cache_movies(movies, cache_file)

    for movie in movies:
        list_item = xbmcgui.ListItem(label=movie['Title'])
        list_item.setInfo('video', {
            'title': movie['Title'],
            'genre': movie['Genre'],
            'plot': movie['Description'],
            'year': movie['Release Date'][:4]
        })
        list_item.setArt({'poster': movie['Poster'], 'thumb': movie['Poster']})
        list_item.setProperty('IsPlayable', 'true')

        # Transmitem lista de URL-uri video ca JSON și includem titlul
        video_urls_json = json.dumps(movie['Videos'])
        url = build_url({'action': 'play', 'video': video_urls_json, 'title': movie['Title']})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)

    # Adăugăm un item pentru următoarea pagină
    next_page_url = build_url({'action': 'list_category', 'category': category_url, 'page': page + 1})
    list_item = xbmcgui.ListItem(label='Next Page >>')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=next_page_url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def search_movies_action(query):
    xbmcplugin.setPluginCategory(addon_handle, addon_name)
    xbmcplugin.setContent(addon_handle, 'movies')

    movies = search_movies(query)

    for movie in movies:
        list_item = xbmcgui.ListItem(label=movie['Title'])
        list_item.setInfo('video', {
            'title': movie['Title'],
            'genre': movie['Genre'],
            'plot': movie['Description'],
            'year': movie['Release Date'][:4]
        })
        list_item.setArt({'poster': movie['Poster'], 'thumb': movie['Poster']})
        list_item.setProperty('IsPlayable', 'true')

        # Transmitem lista de URL-uri video ca JSON și includem titlul
        video_urls_json = json.dumps(movie['Videos'])
        url = build_url({'action': 'play', 'video': video_urls_json, 'title': movie['Title']})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)

def play_video(video_urls_json, movie_title):
    try:
        # Convertim șirul JSON la listă
        video_urls = json.loads(video_urls_json)
    except json.JSONDecodeError:
        xbmcgui.Dialog().ok(addon_name, 'Eroare la procesarea URL-urilor video.')
        return

    if not video_urls or video_urls == ["N/A"]:
        xbmcgui.Dialog().notification(addon_name, 'Nicio sursă video disponibilă.', xbmcgui.NOTIFICATION_ERROR, 5000)
        return

    # Dacă există o singură sursă, redă direct
    if len(video_urls) == 1:
        resolved_url = resolveurl.resolve(video_urls[0])
        if resolved_url:
            play_item = xbmcgui.ListItem(path=resolved_url)
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
            return
        else:
            xbmcgui.Dialog().notification(addon_name, 'Nu s-a putut rezolva sursa video.', xbmcgui.NOTIFICATION_ERROR, 5000)
            return

    # Dacă sunt mai multe surse, afișează un dialog pentru selecție
    dialog = xbmcgui.Dialog()
    options = []
    for idx, url in enumerate(video_urls, 1):
        # Personalizează etichetele în funcție de sursa URL-ului
        if "mixdrop" in url:
            label = f"Sursă {idx} - Mixdrop"
        elif "waaw.ac" in url:
            label = f"Sursă {idx} - Waaw.ac"
        else:
            label = f"Sursă {idx} - {urllib.parse.urlparse(url).netloc}"
        options.append(label)

    # Afișează dialogul de selecție
    ret = dialog.select('Selectează sursa video', options)

    if ret == -1:
        # Utilizatorul a anulat selecția
        xbmc.log('Utilizatorul a anulat selecția sursei video.', xbmc.LOGINFO)
        return
    else:
        selected_url = video_urls[ret]
        resolved_url = resolveurl.resolve(selected_url)
        if resolved_url:
            play_item = xbmcgui.ListItem(path=resolved_url)
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
        else:
            xbmcgui.Dialog().notification(addon_name, 'Nu s-a putut rezolva sursa video selectată.', xbmcgui.NOTIFICATION_ERROR, 5000)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    if params:
        if params['action'] == 'list_category':
            list_movies(params['category'], int(params.get('page', 1)))
        elif params['action'] == 'play':
            play_video(params['video'], params.get('title', ''))
        elif params['action'] == 'search':
            keyboard = xbmc.Keyboard('', 'Search Movies')
            keyboard.doModal()
            if keyboard.isConfirmed():
                query = keyboard.getText()
                search_movies_action(query)
    else:
        list_categories()

if __name__ == '__main__':
    router(sys.argv[2][1:])
