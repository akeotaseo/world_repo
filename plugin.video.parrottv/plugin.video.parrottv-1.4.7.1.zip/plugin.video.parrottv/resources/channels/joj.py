# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests
import re
from bs4 import BeautifulSoup

class JOJ:
    def __init__(self):
        self.ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36"
        self.channels = {
            'joj': 'https://live.joj.sk/',
            'plus': 'https://plus.joj.sk/live',
            'wau': 'https://wau.joj.sk/live'
        }

    def grab(self, channel):
        headers = {'User-Agent': self.ua}
        if channel == "sport":
            url = "https://live.cdn.joj.sk/live/hls/rik-540.m3u8"
        elif channel == "family":
            url = "http://nn.geo.joj.sk/hls/family-540.m3u8"
        else:
            session = requests.Session()
            headers = {}
            headers.update(headers)
            response = session.get(self.channels[channel], headers=headers)
            html = BeautifulSoup(response.content, features="html.parser")
            
            player = None
            items = html.find_all('iframe',{},True)
            if len(items) > 0:
                for iframe in items:
                    if 'https://media.joj.sk/' in iframe['src']:
                        player = iframe['src']
                        break
                
            headers = {'Referer':self.channels[channel]}
            headers.update(headers)
            response = session.get(player, headers=headers)
            
            content = response.content
            try:
                content = content.decode('utf-8')
            except AttributeError:
                pass
            matches = re.search('"hls": "(.*)"', content)
            url = matches.group(1)
        return url, headers