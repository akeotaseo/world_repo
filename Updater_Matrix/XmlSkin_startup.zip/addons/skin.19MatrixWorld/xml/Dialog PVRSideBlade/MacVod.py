﻿import xbmc, xbmcgui

def MacVod():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.macvod/")')
    xbmcgui.Dialog().notification("[B][COLOR red]Mac Vod[/COLOR][/B]", "   ", sound=False, icon='special://home/addons\plugin.video.macvod\icon.png')
    xbmc.sleep(4000)
MacVod()
