from conf.common import CommonResolver


class Deliriousholistic(CommonResolver):

    def set_servers(self):
        return ['deliriousholistic.net']

    def find_stream(self):
        return [r"var src=\"([^\"]+)\""]
