﻿import xbmc, xbmcgui
xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[B][COLOR deepskyblue]•[/COLOR] [COLOR white]SPORT[/COLOR] [/B]", sound=False, icon='special://home/addons\plugin.video.thegroove360\icon.gif')
# xbmc.sleep(1000)
# xbmc.executebuiltin('Dialog.Close(all,true)')
# xbmc.executebuiltin('Action(Back)')
# xbmc.executebuiltin('Dialog.Close(all,true)')
# xbmc.executebuiltin('ActivateWindow(Home)')

xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thegroove360/thegroove/php_script_loader%3Fscripter%3Drisroom%26path%3Dsport.xml")')
