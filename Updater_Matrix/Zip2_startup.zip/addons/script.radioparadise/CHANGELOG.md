## v2.2.0

- Add Beyond channel

## v2.1.2

- Add Serenity to Auto Play options
- Fix metadata handling

## v2.1.1

- Improve metadata handling

## v2.1.0

- Add Serenity channel

## v2.0.1

- Use new metadata API

## v2.0.0

- Updates for Kodi v20
- Improve metadata handling

## v1.0.5

- Rename World/Etc mix to Global

## v1.0.4

- Update logos
- Improve metadata error handling

## v1.0.3

- Add mix selection by script parameter

## v1.0.2

- Handle missing stream metadata

## v1.0.1

- Restart playback automatically

## v1.0.0

- Initial release
