﻿import xbmc



xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.themoviedb.helper/",return)')