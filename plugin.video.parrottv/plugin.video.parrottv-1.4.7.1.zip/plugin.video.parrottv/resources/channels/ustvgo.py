# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests
import xbmcaddon

class USTVGO:
    def __init__(self):
        self.ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:99.0) Gecko/20100101 Parrot/2022'
        self.Addon = xbmcaddon.Addon()

    def grab(self, channel):
        headers = {'User-Agent': self.ua}
        hlsurl = ""
        if self.Addon.getSetting('USTVGOproxy') == 'true':
            proxy = self.Addon.getSetting('USTVGOproxyURL')
            if not proxy.endswith('/'): proxy += '/'
            hlsurl = proxy + "gen.php?c=" + channel
        else:
            headers.update({'Referer': 'http://ustvgo.tv/'})
            url = "https://ustvgo.tv/player.php?stream=" + channel
            hlsurl = requests.get(url, headers=headers).text.replace('\n', '').split("var hls_src='")[1].split("'")[0]
        return hlsurl, headers