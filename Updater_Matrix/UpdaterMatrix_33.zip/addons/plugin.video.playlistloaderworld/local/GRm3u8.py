﻿import xbmc, xbmcgui, xbmcvfs
xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[B][COLOR silver]DaddyLive V2[/COLOR][/B]--->[COLOR orange]Basketball[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/Basketball.png')

xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloaderworld/?cache=0&epg&iconimage=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloaderworld%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5b5%5d&url=C%3a%5cUsers%5cAkis%5cDownloads%5cGR.m3u8&uuid=4aed0f9e-1b81-46ae-ad51-ff9bb621c74a")')


