﻿import xbmc, xbmcgui, xbmcvfs

xbmcgui.Dialog().notification("[B][COLOR blue]GR[/COLOR][/B]", "[COLOR orange]m3u8[/COLOR]", sound=False, icon='https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Flag_of_Greece.svg/510px-Flag_of_Greece.svg.png')

xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloaderworld/?cache=0&epg&iconimage=special://home/addons%5cplugin.video.playlistloaderworld%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bx%5d&url=special%3a%2f%2fhome%2faddons%2fplugin.video.playlistloaderworld%2flocal%2fGR.m3u8&uuid=cf9d6939-bc4a-4e85-9c26-98a83e59b38e")')


