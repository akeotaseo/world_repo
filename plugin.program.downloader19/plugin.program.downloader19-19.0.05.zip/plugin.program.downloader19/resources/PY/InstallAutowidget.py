﻿import os, xbmc, xbmcvfs, xbmcgui

def installautowidget(): 
         xbmc.executebuiltin('InstallAddon(plugin.program.autowidget)')
         xbmc.sleep(100)
         xbmc.executebuiltin('SendClick(11)')
         addon_path = xbmc.translatePath('special://home/addons')

        

installautowidget()
