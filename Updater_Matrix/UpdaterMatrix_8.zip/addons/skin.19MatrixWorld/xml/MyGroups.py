﻿import xbmc

def MyGroups():
    xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.program.autowidget/?mode=group&refresh&reload,return)")


MyGroups()
