import xbmc, xbmcgui


def Fashion():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]       Fashion[/COLOR][/B]',
['[COLOR=grey]Fashion TV Player[/COLOR]',
'[COLOR=grey]Fashion [/COLOR] MIDNIGHT SECRETS',
 '[COLOR=grey]Fashion[/COLOR]  playlistloaderworld'])


    if call:
        if call < 1:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.fashiontv.com/",return)')


def click_2():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.myiptvpro/?url=https%3A%2F%2Ffash1043.cloudycdn.services%2Fslive%2F_definst_%2Fftv_ftv_midnite_k1y_27049_midnite_secr_108_hls.smil%2Fplaylist.m3u8&mode=12&iconimage=http%3A%2F%2Ftv.team%2Fimages%2FchIcons%2F1643.png")')


def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloaderworld/?cache=0&epg&iconimage=DefaultTVShows.png&index=70&logos&mode=10&name=Fashion&url=https%3a%2f%2fdl.dropbox.com%2fscl%2ffi%2fur595ef4cqmfst951kboh%2f.NET_2.m3u%3frlkey%3d0cw1ficfrq0m6yg2udh16qn78%26st%3dmi2d2yud.m3u&uuid=0")')




Fashion()
