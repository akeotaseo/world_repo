﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def DialogCocoScrapers():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]SerenProviders[/COLOR][/B]', 'Για να λειτουργήσει τα πρόσθετο [B][COLOR white] Seren[/COLOR][/B][CR]πρέπει να γίνει εγκατάσταση των[CR][B]Seren Providers[/B][CR]Για να συνεχίσετε πατήστε [B][COLOR orange]Seren Providers[/COLOR][/B][CR]',
                                        nolabel='[B][COLOR white]Πίσω[/COLOR][/B]',yeslabel='[B][COLOR orange]Seren Providers[/COLOR][/B]')

        if choice == 1: xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.downloader/seren_package_install",return)')
        if choice == 0: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/CocoScrapersSeren/CocoScrapersSeren.py")'),]
DialogCocoScrapers()
