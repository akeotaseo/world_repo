import sys
import urllib
import xbmcplugin
from lib.modules import MainMenu

def GetParams():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring) >= 2:
		params        = sys.argv[2]
		cleanedparams = params.replace('?','')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams ={}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]							
	return param
        
params = GetParams()
url  = None
name = None
mode = None
iconimage = None

try: url = urllib.parse.unquote_plus(params["url"])
except: pass

try: name = urllib.parse.unquote_plus(params["name"])
except: pass

try: iconimage = urllib.parse.unquote_plus(params["iconimage"])
except: pass

try: mode = int(params["mode"])
except: pass

print('Mode: ' + str(mode))
print('Name: ' + str(name))

from lib.modules import Common
from lib.sources import LiveChannels
from lib.sources import CollectionOfBestPorn
from lib.sources import GoodPorn
from lib.sources import HogTV
from lib.sources import HQPorner
from lib.sources import MangoVideo
from lib.sources import PornHat
from lib.sources import PornoHD
from lib.sources import PornOne
from lib.sources import XCum
from lib.sources import XHamster
from lib.sources import XHand
from lib.sources import XOZilla
from lib.sources import XTits
from lib.sources import ZBPorn
from lib.sources import PornTrex
from lib.sources import Favourites
from lib.sources import XNXX

if mode == None or url == None or len(url) <1: MainMenu.Menu()

elif mode == 1: Common.Play(url)

elif mode == 2: LiveChannels.Menu()
elif mode == 3: Common.AddFavourites(url, name, iconimage)
elif mode == 4: Common.RemoveFavourites(url, name, iconimage)
elif mode == 5: Favourites.Browse()

elif mode == 10: MangoVideo.Menu()
elif mode == 11: MangoVideo.Browse(url)
elif mode == 12: MangoVideo.Categories(url)
elif mode == 13: MangoVideo.PlayStream(url)

elif mode == 20: PornoHD.Menu()
elif mode == 21: PornoHD.Browse(url)
elif mode == 22: PornoHD.Categories(url)
elif mode == 23: PornoHD.PlayStream(url)

elif mode == 30: XCum.Menu()
elif mode == 31: XCum.Browse(url)
elif mode == 32: XCum.Categories(url)
elif mode == 33: XCum.PlayStream(url)

elif mode == 40: XTits.Menu()
elif mode == 41: XTits.Browse(url)
elif mode == 42: XTits.Categories(url)
elif mode == 43: XTits.PlayStream(url)

elif mode == 50: ZBPorn.Menu()
elif mode == 51: ZBPorn.Browse(url)
elif mode == 52: ZBPorn.Categories(url)
elif mode == 53: ZBPorn.PlayStream(url)
elif mode == 54: ZBPorn.Channels(url)

elif mode == 60: PornHat.Menu()
elif mode == 61: PornHat.Browse(url)
elif mode == 62: PornHat.Categories(url)
elif mode == 63: PornHat.PlayStream(url)

elif mode == 70: GoodPorn.Menu()
elif mode == 71: GoodPorn.Browse(url)
elif mode == 72: GoodPorn.Categories(url)
elif mode == 73: GoodPorn.PlayStream(url)

elif mode == 80: HogTV.Menu()
elif mode == 81: HogTV.Browse(url)
elif mode == 82: HogTV.Categories(url)
elif mode == 83: HogTV.PlayStream(url)

elif mode == 90: XHand.Menu()
elif mode == 91: XHand.Browse(url)
elif mode == 92: XHand.Categories(url)
elif mode == 93: XHand.PlayStream(url)

elif mode == 100: XOZilla.Menu()
elif mode == 101: XOZilla.Browse(url)
elif mode == 102: XOZilla.Categories(url)
elif mode == 103: XOZilla.PlayStream(url)

elif mode == 110: XHamster.Menu()
elif mode == 111: XHamster.Browse(url)
elif mode == 112: XHamster.Categories(url)
elif mode == 113: XHamster.PlayStream(url)

elif mode == 120: HQPorner.Menu()
elif mode == 121: HQPorner.Browse(url)
elif mode == 122: HQPorner.Categories(url)
elif mode == 123: HQPorner.PlayStream(url)

elif mode == 130: PornOne.Menu()
elif mode == 131: PornOne.Browse(url)
elif mode == 132: PornOne.Categories(url)
elif mode == 133: PornOne.PlayStream(url)

elif mode == 140: CollectionOfBestPorn.Menu()
elif mode == 141: CollectionOfBestPorn.Browse(url)
elif mode == 142: CollectionOfBestPorn.Categories(url)
elif mode == 143: CollectionOfBestPorn.PlayStream(url)

elif mode == 150: PornTrex.Menu()
elif mode == 151: PornTrex.Browse(url)
elif mode == 152: PornTrex.Categories(url)
elif mode == 153: PornTrex.PlayStream(url)

elif mode == 160: XNXX.Menu()
elif mode == 161: XNXX.Browse(url)
elif mode == 162: XNXX.Categories(url)
elif mode == 163: XNXX.PlayStream(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
