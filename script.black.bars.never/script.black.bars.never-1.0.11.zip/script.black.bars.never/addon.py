from resources.lib.blackbarsnever import Main

if (__name__ == "__main__"):
    Main()