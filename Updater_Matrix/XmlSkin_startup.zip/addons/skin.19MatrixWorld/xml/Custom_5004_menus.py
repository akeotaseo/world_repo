﻿import xbmc, xbmcgui

def Custom_5004_menus():
    # xbmc.sleep(500)
    xbmcgui.Dialog().ok('[B][COLOR blue]Disable Main Menus[/COLOR][/B]', 'Απενεργοποιήστε Κατηγορίες απο το [B]Κεντρικό Μενού[/B][CR]που δεν σας ενφιαφέρουν.')
    xbmcgui.Dialog().notification("[B][COLOR orange]Choose Menus[/COLOR][/B]", "[B][COLOR white]Σε μελλοντική ενημέρωση του Skin οι κατηγορίες θα ενεργοποιηθούν ξανά.[/COLOR][/B]", sound=True, icon='special://home/addons/skin.19MatrixWorld/media/enabledisable.png')

    xbmc.executebuiltin('ActivateWindow(5004)')
Custom_5004_menus()
