Video plugin for http://www.seirsanduk.com/.

Readme for Kodi - plugin.video.seirsanduk.r1 - plugin created by zinobg [at] gmail.com

I created this addon to be able to watch online TV via Kodi on my Raspberry pi3. It is tested on Kodi for Windows as well. 

Requires: script.module.xbmcswift2

How to install:
    1. Copy the zip file plugin.video.seirsanduk.r1.zip to a directory, where Kodi server has access 
    2. Run Kodi and go to System -> Add-ons
    3. From Add-ons menu select -> Install from zip file
    4. Select the zip file plugin.video.seirsanduk.r1.zip
    5. SEIRSANDUK R1 add-on will appear in the video addon list