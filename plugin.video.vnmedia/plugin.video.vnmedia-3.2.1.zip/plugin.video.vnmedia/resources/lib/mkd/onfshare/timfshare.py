from codequick import Script, Route, Listitem, Resolver
from resources.lib.kedon import getlinkphongblack, postlinktimfs, getlinkvnm, getlink, quangcao, __addonnoti__, tb, yttk, get_info_fs
from concurrent.futures import ThreadPoolExecutor, as_completed
from bs4 import BeautifulSoup
from xbmcgui import DialogProgressBG
from urllib.parse import quote_plus
from xbmcaddon import Addon
from json import loads
from functools import lru_cache
import re
@lru_cache(maxsize=None)
def get_tkfs1(search_query):
	return getlinkphongblack(f'http://phongblack.me/search.php?author=phongblack&search={search_query}', 'http://www.google.com', -1)
@lru_cache(maxsize=None)
def get_tkfs2(search_query):
	return postlinktimfs(f'https://api.timfshare.com/v1/string-query-search?query={search_query}', 'https://timfshare.com/', -1)
@lru_cache(maxsize=None)
def get_tkfs3(search_query):
	return getlinkvnm(f'http://thuvienhd.com/?feed=fsharejson&search={search_query}', 'https://thuvienhd.com/')
@lru_cache(maxsize=None)
def get_tkfs4():
	return getlinkvnm(f'http://thuvienhd.com/?feed=fsharejson&search=', 'https://thuvienhd.com/')
@lru_cache(maxsize=None)
def process_fs(url):
	try:
		data = get_info_fs(url)
		return url, data
	except:
		return url, None
@Route.register
def searchfs(plugin, search_query=None, **kwargs):
	yield []
	if search_query is None:
		pass
	else:
		search_query = quote_plus(search_query)
		dp = DialogProgressBG()
		dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
		with ThreadPoolExecutor(4) as ex:
			f1 = ex.submit(get_tkfs1, search_query)
			f2 = ex.submit(get_tkfs2, search_query)
			f3 = ex.submit(get_tkfs3, search_query)
			f4 = ex.submit(get_tkfs4)
			result_f1 = f1.result()
			result_f2 = f2.result()
			result_f3 = f3.result()
			result_f4 = f4.result()
		dp.update(50)
		try:
			if result_f3 is not None and result_f4 is not None:
				if f3.result().content != f4.result().content:
					kqtvhd = f3.result().json()
					for t in kqtvhd:
						item = Listitem()
						item.label = t['title']
						item.info['plot'] = f'{t["title"]}\n{tb}'
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = yttk(t['title'])
						item.art['thumb'] = item.art['fanart'] = t['image']
						item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_link'), t['id'])
						yield item
		except:
			if result_f3 is not None and result_f4 is not None:
				if f3.result().content != f4.result().content:
					text = f3.result().text
					data = re.sub(r'<(.*?)\n','',text)
					jsm = loads(data)
					for t in jsm:
						item = Listitem()
						item.label = t['title']
						item.info['plot'] = f'{t["title"]}\n{tb}'
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = yttk(t['title'])
						item.art['thumb'] = item.art['fanart'] = t['image']
						item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_link'), t['id'])
						yield item
		try:
			rj = result_f1.json()['items']
			d = (k for k in rj if k['is_playable'] is False)
			for m in d:
				mota = f"{m['info']['plot']}\n{tb}" if 'info' in m else tb
				path = m['path']
				if '/file/' in path:
					item = Listitem()
					item.label = m['label']
					link = re.search(r"url=(\S+)", path)[1]
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(m['label'])
					item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
					item.info['plot'] = mota
					if Addon().getSetting('taifshare') == 'true':
						item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
					item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
					item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, m['label'])
					yield item
				elif '/folder/' in path:
					item = Listitem()
					item.label = m['label']
					link = re.search(r"url=(\S+)", path)[1]
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(m['label'])
					item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
					item.info['plot'] = mota
					item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
					item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link, 0)
					yield item
		except:
			pass
		try:
			j = result_f2.json()
			rj = j['data']
			m = (k for k in rj if 'data' in j)
			for k in m:
				item = Listitem()
				item.label = k['name']
				item.info['plot'] = tb
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = yttk(k['name'])
				item.art['thumb'] = f"https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={k['url']}&qzone=1&margin=1&size=400x400&ecc=L"
				item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
				item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', k['url'])
				if 'folder' in k['url']:
					item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), k['url'], 0)
				else:
					item.info['size'] = k['size']
					if Addon().getSetting('taifshare') == 'true':
						item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', k['url'])
					item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), k['url'], k['name'])
				yield item
		except:
			pass
		dp.update(100)
		dp.close()
@Route.register
def index_pdx(plugin, **kwargs):
	yield toptoday()
	yield topweek()
	yield toprated()
	yield toprevenue()
	yield topchieurap()
	yield toppopular()
	yield Listitem.from_dict(**{'label': 'Đề xuất',
	'info':{'plot':tb},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/dexuat.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/dexuat.png'},
	'callback': index_hn})
	dulieu = {
	'Đặc sắc': -1,
	'Hành động': 76,
	'Phiêu lưu': 86,
	'Hình sự': 77,
	'Trinh thám': 106,
	'Võ thuật': 111,
	'Rùng rợn': 98,
	'Huyền bí': 80,
	'Kinh dị': 81,
	'Viễn tưởng': 109,
	'Hài hước': 74,
	'Lãng mạn': 82,
	'Thần thoại': 100,
	'Cổ trang': 71,
	'Phim TVB': 108,
	'Phim bộ Hàn': 89,
	'Phim bộ Mỹ': 91,
	'Lồng tiếng': 84,
	'Hoạt hình': 78
	}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.info['plot'] = tb
		item.art['thumb'] = item.art['fanart'] = f'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/dexuat.png'
		item.set_callback(hdo_page, dulieu[k])
		yield item
@Route.register
def index_hn(plugin, **kwargs):
	resptvhd = get_tkfs3('')
	try:
		kqtvhd = resptvhd.json()
		for t in kqtvhd:
			item = Listitem()
			item.label = t['title']
			item.info['plot'] = f'{t["title"]}\n{tb}'
			item.info['mediatype'] = 'movie'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(t['title'])
			item.art['thumb'] = item.art['fanart'] = t['image']
			item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_link'), t['id'])
			yield item
	except:
		text = resptvhd.text
		data = re.sub(r'<(.*?)\n','',text)
		jsm = loads(data)
		for dem, t in enumerate(jsm):
			item = Listitem()
			item.label = t['title']
			item.info['plot'] = f'{t["title"]}\n{tb}'
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(t['title'])
			item.art['thumb'] = item.art['fanart'] = t['image']
			item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_link'), t['id'])
			yield item
@Route.register
def hdo_page(plugin, idp=None, **kwargs):
	yield []
	if idp is None:
		pass
	else:
		trangtiep = f'https://thuvienhd.com/?feed=rss&exclude_cats=250004&category={idp}&posts_per_page=100'
		resp = getlink(trangtiep, trangtiep, 1000)
		if (resp is not None):
			soup = BeautifulSoup(resp.content, 'html.parser')
			soups = soup.select('item')
			for k in soups:
				item = Listitem()
				item.label = k.select_one('title').get_text(strip=True)
				mota = k.select_one('description').get_text(strip=True)
				anh = k.select_one('enclosure')['url']
				item.info['plot'] = mota
				item.info['mediatype'] = 'movie'
				item.art['thumb'] = item.art['fanart'] = anh
				item.set_callback(hdo_link, k.select_one('id').get_text(strip=True), mota, anh)
				yield item
		else:
			yield quangcao()
@Route.register
def hdo_link(plugin, idk=None, mota=None, anh=None, **kwargs):
	yield []
	if idk is None or mota is None or anh is None:
		pass
	else:
		t = f'https://thuvienhd.com/?feed=rss&id={idk}'
		r = getlink(t, t, 1000)
		if (r is not None):
			dialog = DialogProgress()
			dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
			soup = BeautifulSoup(r.content, 'html.parser')
			soups = soup.select('item fshare link')
			urls =[k['url'] for k in soups]
			length = len(urls)
			if length>0:
				count = 0
				with ThreadPoolExecutor(length) as ex:
					future_to_url = (ex.submit(process_fs, url) for url in urls)
					ac = as_completed(future_to_url)
					for future in ac:
						link, data = future.result()
						if data is not None:
							if (dialog.iscanceled()):
								break
							count += 1
							done = int((count/length)*100)
							dialog.update(done, f'Đang giải mã {length} dữ liệu...\nLoading... [COLOR yellow]{done} %[/COLOR]')
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = mota
							item.info['mediatype'] = 'episode'
							item.info['rating'] = 10.0
							item.info['trailer'] = yttk(data[0])
							item.art['thumb'] = item.art['fanart'] = anh
							item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
							if 'folder' in link:
								item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link, 0)
							else:
								item.info['size'] = data[1]
								if Addon().getSetting('taifshare') == 'true':
									item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
								item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, data[0])
							yield item
			else:
				yield quangcao()
			dialog.close()
		else:
			yield quangcao()
@lru_cache(maxsize=None)
def toptoday():
	item = Listitem()
	item.label = 'TOP VNM hôm nay'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/most_played.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:trendview'), 'day', 1)
	return item
@lru_cache(maxsize=None)
def topweek():
	item = Listitem()
	item.label = 'TOP VNM tuần này'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/most_played.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:trendview'), 'week', 1)
	return item
@lru_cache(maxsize=None)
def toprated():
	item = Listitem()
	item.label = 'VNM xếp hạng'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/top_rated.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:trendview'), 'top_rated', 1)
	return item
@lru_cache(maxsize=None)
def toprevenue():
	item = Listitem()
	item.label = 'TOP doanh thu'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/trending.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:trendview'), 'revenue', 1)
	return item
@lru_cache(maxsize=None)
def topchieurap():
	item = Listitem()
	item.label = 'TOP phòng vé'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/imdbchieurap.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:trendview'), 'now_playing', 1)
	return item
@lru_cache(maxsize=None)
def toppopular():
	item = Listitem()
	item.label = 'TOP Thịnh hành IMDb'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/imdbthinhhanh.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:trendview'), 'popular', 1)
	return item