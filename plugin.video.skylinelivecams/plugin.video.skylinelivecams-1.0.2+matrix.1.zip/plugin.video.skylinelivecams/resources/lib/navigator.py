﻿# -*- coding: utf-8 -*-

from .common import *


def mainMenu():
	for TITLE, PATH in [(30601, {'mode': 'listFavorites'}), (30602, {'mode': 'listCameras', 'url': LANG_URL, 'extras': 'CASUALCAM'}),
		(30603, {'mode': 'listCameras', 'url': NEWS_URL, 'extras': 'NEWEST'}), (30604, {'mode': 'listCameras', 'url': TOPS_URL, 'extras': 'POPULAR'}),
		(30605, {'mode': 'listPages', 'url': LANG_URL, 'extras': 'COUNTRIES'}), (30606, {'mode': 'listPages', 'url': LANG_URL, 'extras': 'CATEGORIES'})]:
		addDir(PATH, create_entries({'Title': translation(TITLE), 'Image': f"{artpic}favourites.png" if TITLE == 30601 else icon}), folder=False if TITLE == 30602 else True)
	addDir({'mode': 'clear_storage'}, create_entries({'Title': translation(30607).format(CACHE_PERIOD), 'Image': f"{artpic}remove.png"}), False)
	if enableADJUSTMENT:
		addDir({'mode': 'aConfigs'}, create_entries({'Title': translation(30610), 'Image': f"{artpic}settings.png"}), False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listPages(TARGET, EXTRA): 
	debug_MS("(navigator.listPages) ------------------------------------------------ START = listPages -----------------------------------------------")
	debug_MS(f"(navigator.listPages) ### URL = {TARGET} ### EXTRA = {EXTRA} ###")
	COMBI_PAGES = []
	req = getContent(TARGET)
	converted = clear_unknown(req) # Declare unknown Encodings in Request-results (from bs4 import UnicodeDammit)
	htmlPage = BeautifulSoup(converted, 'html.parser')
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listPages[1]) $$$$$ PRETTIFIED-SOUP : {htmlPage.prettify()} $$$$$")
	debug_MS("++++++++++++++++++++++++")
	if EXTRA == 'COUNTRIES':
		cats = htmlPage.find('div', class_='dropdown mega-dropdown live')
	else:
		cats = htmlPage.find('div', class_='dropdown-menu mega-dropdown-menu cat')
	ARTICLES = cats.find_all('a', href=True)
	for item in ARTICLES:
		adress, photo = item['href'], icon
		if not adress.endswith('.html'):
			continue
		title = item.get_text() # In countries the Title is hidden in Link-Text, extract it with: 'get_text()'
		SORTING = cleanUmlaut(title)
		name = translation(30621).format(title)
		if EXTRA == 'COUNTRIES' and not 'live' in title.lower():
			category = translation(30622).format(title)
			photo = f"{flagpic}{adress.split('/')[-1].replace('.html', '')}.png" if xbmcvfs.exists(f"{flagpic}{adress.split('/')[-1].replace('.html', '')}.png") else icon
		else: category = translation(30623).format(title)
		desc = item.find('p', class_='subt')
		plot = f"{desc.text}..." if desc and not desc.text.endswith(('.', '!', '?')) else f"{desc.text[:-1]}..." if desc and desc.text.endswith((',', ';')) else desc.text if desc else ""
		link = f"{BASE_URL}{adress}" if adress.startswith('/') else f"{BASE_URL}/{adress}" if not adress.startswith(('http', '/')) else adress
		if item.find('img') and item.find('img').get('src'):
			photo = f"https:{item.img['src']}" if item.img['src'].startswith('//') else item.img['src']
		photo = photo.replace('/live', '/social').replace('.webp', '.jpg') if re.search(r'/live[0-9]+', photo) else photo
		COMBI_PAGES.append([name, SORTING, category, photo, link, plot])
	for name, SORTING, category, photo, link, plot in sorted(COMBI_PAGES, key=lambda cs: cs[1]):
		addDir({'mode': 'listCameras', 'url': link, 'extras': EXTRA, 'selection': category}, create_entries({'Title': name, 'Image': photo, 'Plot': plot}))
		debug_MS(f"(navigator.listPages[2]) ##### NAME : {name} || THUMB : {photo} || LINK : {link} #####")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listCameras(TARGET, PAGE, POS, EXTRA, CAT):
	debug_MS("(navigator.listCameras) ------------------------------------------------ START = listCameras -----------------------------------------------")
	debug_MS(f"(navigator.listEpisodes) ### URL : {TARGET} ### PAGE = {PAGE} ### LIMIT = {LIMITATION} ### POSITION = {POS} ### EXTRA = {EXTRA} ### CATEGORY = {CAT} ###")
	counter, HASMORE = 0, False
	COMBI_FIRST, COMBI_LINKS, COMBI_SECOND, COMBI_THIRD, COMBI_WIDGET, COMBI_FOURTH, RESULT_ONE, RESULT_TWO, COMPLETING, SENDING = ([] for _ in range(10))
	DEFAULT = 0 if int(PAGE) == 1 else int(PAGE) - 1
	MINIMUM = int(DEFAULT)*int(LIMITATION) + 1
	MAXIMUM = int(PAGE)*int(LIMITATION) if EXTRA != 'CASUALCAM' else 50
	HIGHER = True if EXTRA not in ['CASUALCAM', 'FAVORITES'] and int(PAGE) > 1 else False
	if enableBACK and PLACEMENT == 0 and HIGHER is True:
		addDir({'mode': 'callingMain'}, create_entries({'Title': translation(30624), 'Image': f"{artpic}backmain.png"}))
	if isinstance(TARGET, (dict, list)):
		for item in TARGET:
			LINK_1, TITLE_1, PHOTO_1, DESC_1 = item['IDENTiTY'], item['name'], item['photo'], item['plot']
			WEATHER_1 = LINK_1.replace('webcam/', 'weather/')
			counter += 1
			COMBI_FIRST.append([int(counter), LINK_1, TITLE_1, PHOTO_1, DESC_1])
			COMBI_WIDGET.append([int(counter), LINK_1, f"{WEATHER_1[:WEATHER_1.rfind('/')]}.html"])
			COMBI_LINKS.append([int(counter), LINK_1, LINK_1])
	else:
		if not xbmcvfs.exists(tempDATA) and not os.path.exists(tempDATA):
			xbmcvfs.mkdirs(tempDATA)
		SWEEP = urlparse(TARGET)
		PAGES_DATA = f"{SWEEP.path.replace('/', '_').replace('.html', '')}.json"
		PAGES_PATH = os.path.join(tempDATA, PAGES_DATA)
		if xbmcvfs.exists(PAGES_PATH):
			for root, dirs, files in os.walk(tempDATA):
				for names in files:
					filename = os.path.join(root, names).encode('utf-8').decode('utf-8')
					try:
						if os.path.exists(filename):
							if os.path.getmtime(filename) < time.time() - (60*60*CACHE_PERIOD): # Check if CACHED-File exists and remove CACHED-File after 'CACHE_PERIOD' Hours
								os.unlink(filename)
					except: pass
			xbmc.sleep(500)
		if not xbmcvfs.exists(PAGES_PATH) or EXTRA == 'CASUALCAM':
			DATA_ONE = getContent(TARGET)
			converted = clear_unknown(DATA_ONE) # Declare unknown Encodings in Request-results (from bs4 import UnicodeDammit)
			htmlPage = BeautifulSoup(converted, 'html.parser')
			debug_MS("++++++++++++++++++++++++")
			debug_MS(f"(navigator.listCameras[1]) $$$$$ PRETTIFIED-SOUP : {htmlPage.prettify()} $$$$$")
			debug_MS("++++++++++++++++++++++++")
			cams = htmlPage.find('div', class_='content')
			MOVIES = cams.find_all('a', href=True)
			for video in MOVIES:
				adress, PICTURE = video['href'], icon
				if not adress.endswith('.html'):
					continue
				HEADLINE = video.img['alt'] if video.find('img') and video.find('img').get('alt') else None
				if HEADLINE is None: continue
				STORY = video.find('p', class_='subt')
				DESCRIPT = f"{STORY.text}..." if STORY and not STORY.text.endswith(('.', '!', '?')) else f"{STORY.text[:-1]}..." if STORY and STORY.text.endswith((',', ';')) else STORY.text if STORY else ""
				WEBLINK = f"{BASE_URL}{adress}" if adress.startswith('/') else f"{BASE_URL}/{adress}" if not adress.startswith(('http', '/')) else adress
				if video.find('img') and video.find('img').get('src'):
					PICTURE = f"https:{video.img['src']}" if video.img['src'].startswith('//') else video.img['src']
				PICTURE = PICTURE.replace('/live', '/social').replace('.webp', '.jpg') if re.search(r'/live[0-9]+', PICTURE) else PICTURE
				counter += 1
				COMPLETING.append({'number': counter, 'IDENTiTY': WEBLINK, 'name': HEADLINE, 'photo': PICTURE, 'plot': DESCRIPT})
			preserve(PAGES_PATH, COMPLETING)
			xbmc.sleep(500)
		if xbmcvfs.exists(PAGES_PATH):
			for item in preserve(PAGES_PATH):
				if item['number'] != 0 and MINIMUM <= item['number'] <= MAXIMUM:
					NUMBER_1, LINK_1, TITLE_1, PHOTO_1, DESC_1 = item['number'], item['IDENTiTY'], item['name'], item['photo'], item['plot']
					WEATHER_1 = LINK_1.replace('webcam/', 'weather/')
					COMBI_FIRST.append([int(NUMBER_1), LINK_1, TITLE_1, PHOTO_1, DESC_1])
					COMBI_WIDGET.append([int(NUMBER_1), LINK_1, f"{WEATHER_1[:WEATHER_1.rfind('/')]}.html"])
					COMBI_LINKS.append([int(NUMBER_1), LINK_1, LINK_1])
				if EXTRA != 'CASUALCAM' and item['number'] != 0 and item['number'] > MAXIMUM:
					HASMORE = True
	if COMBI_FIRST:
		if showWEATHER is True:
			COMBI_SECOND = listWeather(COMBI_WIDGET)
			RESULT_ONE = [aw + bw for aw in COMBI_FIRST for bw in COMBI_SECOND if aw[1] == bw[1]] # Merging List1 and List2 – if the ID matches !!!
			RESULT_ONE += [cw for cw in COMBI_FIRST if all(dw[1] != cw[1] for dw in COMBI_SECOND)] # The remaining items from List1 - if the ID does not appear in List2 !!!
		else: RESULT_ONE = COMBI_FIRST
	if COMBI_LINKS:
		COMBI_THIRD = getMultiData(COMBI_LINKS)
		if COMBI_THIRD:
			#log("++++++++++++++++++++++++")
			#log(f"(navigator.listCameras[2]) XXXXX COMBI_THIRD-02 : {COMBI_THIRD} XXXXX")
			#log("++++++++++++++++++++++++")
			for meter, WLINK_3, CONT_3, elem in COMBI_THIRD:
				if elem is not None:
					PHOTO_3, (TAGLINE_3, VIEWS_3, RATED_3, NUMBERS_3, LOGO_3, YOUTUBE_3, STREAM_3) = icon, (None for _ in range(7))
					corrected = clear_unknown(elem) # Declare unknown Encodings in Request-results (from bs4 import UnicodeDammit)
					contentPage = BeautifulSoup(corrected, 'html.parser')
					record = contentPage.find('div', class_='content')
					NAME = record.find('h1')
					TITLE_3 = NAME.text if NAME is not None else 'UNKNOWN'
					TEASER = record.find('h2')
					TAGLINE_3 = TEASER.text if TEASER is not None else None
					if TAGLINE_3 and len(TAGLINE_3) > 125:
						TAGLINE_3 = f"{TAGLINE_3[:125]}..."
					FLAGPART = WLINK_3.split('webcam/')[1].split('/')[0]
					REGIONS = [span.string for span in record.find_all('span', itemprop='name')]
					if len(REGIONS) > 1:
						LOCATION_3 = f"{REGIONS[1]}, {REGIONS[0]}" if REGIONS[1] != REGIONS[0] else REGIONS[0]
						COUNTRY_3 = REGIONS[0]
					else: LOCATION_3, COUNTRY_3 = FLAGPART, FLAGPART
					SERVALUE = record.find('span', id='servertime')
					TIME_3 = SERVALUE.string if SERVALUE is not None else '--:--'
					DESVALUE = record.find('div', class_='descr')
					DESC_3 = f"{DESVALUE.text[:700]}..." if DESVALUE and not DESVALUE.text[:700].endswith(('.', '!', '?')) else f"{DESVALUE.text[:699]}..." if DESVALUE and DESVALUE.text[:700].endswith((',', ';')) else DESVALUE.text[:700] if DESVALUE else ""
					VIECOUNT = record.find('span', id='v_now')
					VIEWS_3 = VIECOUNT.text if VIECOUNT is not None else None
					RATVALUE = record.find('span', itemprop='ratingValue')
					RATED_3 = RATVALUE.text if RATVALUE is not None else None
					RATCOUNT = record.find('span', itemprop='ratingCount')
					NUMBERS_3 = RATCOUNT.text if RATCOUNT is not None else None
					if contentPage.find('meta', property='og:image') and contentPage.find('meta', property='og:image').get('content'):
						PHOTO_3 = contentPage.find('meta', property='og:image').get('content')
					PHOTO_3 = PHOTO_3.replace('/live', '/social').replace('.webp', '.jpg') if re.search(r'/live[0-9]+', PHOTO_3) else PHOTO_3
					LOGO_3 = f"{flagpic}{FLAGPART}.png" if xbmcvfs.exists(f"{flagpic}{FLAGPART}.png") else None
					if re.search(r'https://www.youtube.com/iframe', corrected):
						SOURCE = re.compile(r''',videoId:["']([^"']+)["'],''', re.S).findall(corrected) # ,videoId:'SJ7dRgcEvBs',
						YOUTUBE_3 = SOURCE[0] if SOURCE and len(SOURCE[0]) > 0 else None
					else:
						SOURCE = re.compile(r''',source:["']([^"']+)["'],''', re.S).findall(corrected) #  ,source:'livee.m3u8?a=1kthl1f6neoehp6fq44bq2o4e0',
						STREAM_3 = f"https://hd-auth.skylinewebcams.com/{SOURCE[0].replace('livee', 'live')}" if SOURCE and len(SOURCE[0]) > 0 else None
					WORKS_3 = False if YOUTUBE_3 is None and STREAM_3 is None else True
					COMBI_FOURTH.append([int(meter), WLINK_3, WORKS_3, TITLE_3, TAGLINE_3, LOCATION_3, COUNTRY_3, TIME_3, VIEWS_3, RATED_3, NUMBERS_3, PHOTO_3, LOGO_3, DESC_3, STREAM_3, YOUTUBE_3])
	if COMBI_FOURTH and RESULT_ONE:
		RESULT_TWO = [ew + fw for ew in RESULT_ONE for fw in COMBI_FOURTH if ew[1] == fw[1]] # Merging List1 and List2 – if the LINK matches !!!
		for xev in sorted(RESULT_TWO, key=lambda ems: int(ems[0])): # List1 = 0-11 or 0-7 || List2 = 12-15 or empty || List3 = 16-29 or 12-25
			debug_MS("---------------------------------------------")
			debug_MS(f"(navigator.listCameras[3]) ### Anzahl : {len(xev)} || Eintrag : {xev} ###")
			operation = 'adding'
			'''
			STANDARD and FAVORITEN:
				Liste-1 = Number1, Link1, Title1, Photo1, Desc1 = xev[0], xev[1], xev[2], xev[3], xev[4]
				Liste-2 = Number2, Link2, temperature, condition = xev[5], xev[6], xev[7], xev[8]
				Liste-3 = Number3, Link3, works, Title3, tagline, LocationComplete, CountryTitle, CountryTime, viewers, rating, voting, Photo3, Logo3, Desc3, directstream, youtubestream = xev[9], xev[10], xev[11], xev[12], xev[13], xev[14], xev[15], xev[16], xev[17], xev[18], xev[19], xev[20], xev[21], xev[22], xev[23], xev[24]
			'''
			if len(xev) >= 25: ### List1+List2+List3 is greater than or equal to number:25 ###
				Number1, Link1, Title1, Photo1, Desc1 = xev[0], xev[1], xev[2], xev[3], xev[4]
				Number2, Link2, temperature, condition = xev[5], xev[6], xev[7], xev[8]
				Number3, Link3, works, Title3, tagline, LocationComplete, CountryTitle, CountryTime, viewers, rating, voting, Photo3, Logo3, Desc3, directstream, youtubestream = xev[9], xev[10], xev[11], xev[12], xev[13], xev[14], xev[15], xev[16], xev[17], xev[18], xev[19], xev[20], xev[21], xev[22], xev[23], xev[24]
			elif len(xev) <= 21: ### List1+List3 is less than or equal to number:21 and List2 is OFF ###
				Number1, Link1, Title1, Photo1, Desc1 = xev[0], xev[1], xev[2], xev[3], xev[4]
				Number2, Link2, temperature, condition = (None for _ in range(4))
				Number3, Link3, works, Title3, tagline, LocationComplete, CountryTitle, CountryTime, viewers, rating, voting, Photo3, Logo3, Desc3, directstream, youtubestream = xev[5], xev[6], xev[7], xev[8], xev[9], xev[10], xev[11], xev[12], xev[13], xev[14], xev[15], xev[16], xev[17], xev[18], xev[19], xev[20]
			else: continue
			country = CountryTitle.replace('-', ' ').title()
			if CountryTitle and WEB_LANG in ['de', 'en']:
				for tt in (('Albania', translation(32101)), ('Argentina', translation(32102)), ('Australia', translation(32103)), ('Austria', translation(32104)), ('Belarus', translation(32105)),
					('Belgique', translation(32106)), ('Bosnia And Herzegovina', translation(32107)), ('Brasil', translation(32108)), ('Cabo Verde', translation(32109)), ('Canada', translation(32110)),
					('Caribbean Netherlands', translation(32111)), ('Cyprus', translation(32112)), ('Czech Republic', translation(32113)), ('Dominican Republic', translation(32114)), ('Egypt', translation(32115)),
					('Ellada', translation(32116)), ('Espana', translation(32117)), ('Faroe Islands', translation(32118)), ('France', translation(32119)), ('Hrvatska', translation(32120)),
					('Hungary', translation(32121)), ('Iceland', translation(32122)), ('Ireland', translation(32123)), ('Italia', translation(32124)), ('Kenya', translation(32125)),
					('Maledives', translation(32126)), ('Mexico', translation(32127)), ('Morocco', translation(32128)), ('Netherlands', translation(32129)), ('Norge', translation(32130)),
					('Philippines', translation(32131)), ('Poland', translation(32132)), ('Repubblica Di San Marino', translation(32133)), ('Romania', translation(32134)), ('Seychelles', translation(32135)),
					('Slovenija', translation(32136)), ('South Africa', translation(32137)), ('Turkey', translation(32138)), ('United Arab Emirates', translation(32139)), ('United Kingdom', translation(32140)),
					('United States', translation(32141)), ('Us Virgin Islands', translation(32142)), ('Zambia', translation(32143)), ('Zanzibar', translation(32144))):
					country = country.replace(*tt)
			if works is True and (directstream or youtubestream):
				ACTION, name = {'mode': 'playCODE', 'IDENTiTY': Link1}, translation(30625).format(Title3)
				prefix = translation(30626).format(LocationComplete, CountryTime, viewers) if viewers else translation(30627).format(LocationComplete, CountryTime)
			elif works is False or (directstream is None and youtubestream is None):
				ACTION, name = {'mode': 'blankFUNC', 'IDENTiTY': Link1}, translation(30628).format(Title3)
				prefix = translation(30629).format(LocationComplete, CountryTime, viewers) if viewers else translation(30630).format(LocationComplete, CountryTime)
			else: continue
			image = Photo1 if Photo1 != icon else Photo3
			logo = Logo3 if Logo3 else None
			FULL_DESC = Desc3 if len(Desc3) > len(Desc1) else Desc1
			FULL_TAGS = tagline if tagline and not tagline in FULL_DESC else None
			weather = translation(30631).format(temperature, condition) if temperature and condition else '[CR]'
			DescriptionLong = prefix+weather+FULL_DESC
			debug_MS(f"(navigator.listCameras[3]) ##### POS : {Number1} || NAME : {name} || LINK : {Link1} || COUNTRY : {country} #####")
			debug_MS(f"(navigator.listCameras[3]) ##### THUMB : {image} || SKY_VIDEO : {directstream} || YOUTUBE : {youtubestream} #####")
			FETCH_UNO = context = {'Streaming': Link1, 'Clearname': Title3, 'Title': name, 'Tagline': FULL_TAGS, 'plot_long': DescriptionLong, 'plot_short': Desc1, \
				'Country': country, 'Rating': rating, 'Voting': voting, 'Studio': 'Skylinewebcams', 'Mediatype': 'movie', 'Image': image, 'Logo': logo}
			if EXTRA != 'FAVORITES':
				if xbmcvfs.exists(FAVORIT_FILE) and os.stat(FAVORIT_FILE).st_size > 0:
					for article in preserve(FAVORIT_FILE):
						if article.get('Streaming') == Link1: operation = 'skipping'
			elif EXTRA == 'FAVORITES': operation = 'removing'
			if EXTRA != 'CASUALCAM':
				addDir(ACTION, create_entries(FETCH_UNO), False, context, operation, HIGHER)
			SENDING.append({'filtrate': Link1, 'name': name, 'photo': image, 'plot': DescriptionLong, 'directLINK': directstream, 'youtubeID': youtubestream})
		preserve(WORKS_FILE, SENDING)
		if EXTRA != 'CASUALCAM' and HASMORE is True:
			debug_MS(f"(navigator.listCameras[4]) PAGES ### NOW GET NEXTPAGE ... No.{int(PAGE)+1} ... ###")
			FETCH_DUE = create_entries({'Title': translation(30640).format(int(PAGE)+1), 'Image': f"{artpic}nextpage.png"})
			addDir({'mode': 'listCameras', 'url': TARGET, 'page': int(PAGE)+1, 'position': int(MAXIMUM)+1, 'extras': EXTRA, 'selection': CAT}, FETCH_DUE)
	else:
		debug_MS(f'(navigator.listCameras) ##### NO CAMERA_LIST - NO ENTRY FOR: "{EXTRA}" FOUND #####')
		return dialog.notification(translation(30525), translation(30526).format(EXTRA), icon, 10000)
	if EXTRA == 'CASUALCAM' and SENDING:
		VideoCode = next(filter(lambda cxs: (cxs.get('directLINK', None) or cxs.get('youtubeID', None)), SENDING), None)
		if VideoCode: return playCODE(VideoCode['filtrate'])
	debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def listWeather(MURLS):
	COMBI_DETAILS, COMBI_WEATHER = ([] for _ in range(2))
	COMBI_DETAILS = getMultiData(MURLS)
	if COMBI_DETAILS:
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.listWeather[2]) XXXXX COMBI_DETAILS-02 : {COMBI_DETAILS} XXXXX")
		#log("++++++++++++++++++++++++")
		for number, WLINK_2, WEATHER_2, each in COMBI_DETAILS:
			if each is not None:
				TEMP_2, COND_2 = (None for _ in range(2))
				cleared = clear_unknown(each) # Declare unknown Encodings in Request-results (from bs4 import UnicodeDammit)
				weatherPage = BeautifulSoup(cleared, 'html.parser')
				predict = weatherPage.find('div', class_='cast today')
				DEGREES = predict.find('span', class_='degrees')
				TEMP_2 = DEGREES.text if DEGREES else None
				FORETEXT = predict.find('p', class_='foretext')
				if FORETEXT and WEB_LANG in ['de', 'en']:
					COND_2 = ' '.join(FORETEXT.text.split(' ')[:2])
				elif FORETEXT and WEB_LANG not in ['de', 'en']:
					COND_2 = FORETEXT.text
				debug_MS(f"(navigator.listWeather[2]) ##### POS : {number} || TEMPERATURE : {TEMP_2} || CONDITION : {COND_2} #####")
				COMBI_WEATHER.append([int(number), WLINK_2, TEMP_2, COND_2])
	return COMBI_WEATHER

def playCODE(ORIGIN): # https://hd-auth.skylinewebcams.com/live.m3u8?a=aaki37oq67e624gn8qee12n5f2
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS(f"(navigator.playCODE) ### SKYLINE_LINK : {ORIGIN} ###")
	STREAM, UNSOLVED, (YOUTUBE, SKYLINE, FINAL_URL) = 'UNKNOWN', 'COOKIE=PHPSESSID NOT FOUND', (False for _ in range(3))
	for elem in preserve(WORKS_FILE):
		if elem['filtrate'] != '00' and elem['filtrate'] == ORIGIN:
			FULL_TITLE, CLEAR_TITLE = re.sub(r'(\[/?B\])', '', elem['name']), re.sub(r'(\[.*?\]|■  )', '', elem['name'])
			SMALL_TITLE, PHOTO, PLOT = ' '.join(CLEAR_TITLE.split(' ')[:4])+' ...', elem['photo'], elem['plot']
			SKYLINE, YOUTUBE = elem['directLINK'], elem['youtubeID']
			debug_MS(f"(navigator.playCODE[1]) ### WORK_FILE-Line : {elem} ###")
	if YOUTUBE:
		debug_MS(f"(navigator.playCODE[2]) ***** TAKE - REDIRECTED : plugin://plugin.video.youtube/play/?video_id={YOUTUBE} || (Youtube-Redirect) *****")
		TEST_URL = getContent(f"https://www.youtube.com/oembed?format=json&url=http://www.youtube.com/watch?v={YOUTUBE}", queries='TRACK', ORG='https://www.youtube.com', REF='https://www.youtube.com/', timeout=20)
		if TEST_URL.status_code in [200, 201, 202] and re.search(r'''["']provider_url["']:["']https://www.youtube.com/["']''', TEST_URL.text):
			STREAM, FINAL_URL = 'YOUTUBE', f"plugin://plugin.video.youtube/play/?video_id={YOUTUBE}"
	if not FINAL_URL and SKYLINE:
		DATA_ONE = getContent(ORIGIN, queries='TRACK')
		PHP_SESSID = DATA_ONE.cookies.get('PHPSESSID') if DATA_ONE.status_code in [200, 201, 202, 300, 301, 302] and 'PHPSESSID' in DATA_ONE.cookies else None
		if PHP_SESSID:
			STREAM, UNSOLVED = 'SKYLINE', f"https://hd-auth.skylinewebcams.com/live.m3u8?a={PHP_SESSID}|{urlencode({'User-Agent': getRandom(), 'Referer': BASE_URL+'/'}, safe='/:?=&')}"
			TEST_URL = getContent(UNSOLVED, queries='TRACK', timeout=20)
			FINAL_URL = UNSOLVED if TEST_URL.status_code in [200, 201, 202, 300, 301, 302] else False
		debug_MS(f"(navigator.playCODE[2]) ***** TAKE - DIRECT : {UNSOLVED} || (Skyline-Direct) *****")
	if FINAL_URL:
		log(f"(navigator.playCODE) {STREAM}_stream : {FINAL_URL}")
		LPM = xbmcgui.ListItem(FULL_TITLE, path=FINAL_URL, offscreen=True)
		if PLOT in ['', 'None', None]: PLOT = ' '
		if KODI_ov20:
			LPM.getVideoInfoTag().setTitle(FULL_TITLE), LPM.getVideoInfoTag().setPlot(PLOT), LPM.getVideoInfoTag().setStudios(['Skylinewebcams'])
		else: LPM.setInfo('Video', {'Title': FULL_TITLE, 'Plot': PLOT, 'Studio': 'Skylinewebcams'})
		LPM.setArt({'icon': icon, 'thumb': PHOTO, 'poster': PHOTO})
		if xbmc.getCondVisibility('System.HasAddon(inputstream.ffmpegdirect)') and SKYLINE and STREAM == 'SKYLINE':
			IA_NAME = 'inputstream.ffmpegdirect'
			LPM.setMimeType('application/vnd.apple.mpegurl'), LPM.setContentLookup(False), LPM.setProperty('inputstream', IA_NAME)
			LPM.setProperty(f'{IA_NAME}.open_mode', 'ffmpeg')
			LPM.setProperty(f'{IA_NAME}.manifest_type', 'hls')
			LPM.setProperty(f'{IA_NAME}.is_realtime_stream', 'false')
			LPM.setProperty('http-reconnect', 'true')
		xbmc.Player().play(item=FINAL_URL, listitem=LPM)
		xbmc.sleep(8000)
		if not xbmc.getCondVisibility('Window.IsVisible(fullscreenvideo)') and not xbmc.Player().isPlaying():
			return dialog.notification(translation(30527).format(SMALL_TITLE), translation(30528), icon, 15000)
	else:
		if YOUTUBE:
			failing(f"(navigator.playCODE) $$$$$ Playback of the stream is NOT possible; the Stream-URL on the *skylinewebcams.com* website is BROKEN or OFFLINE !!! $$$$$\n $$$$$ TITLE : {CLEAR_TITLE} || YOUTUBE-ID : {YOUTUBE} $$$$$")
		elif SKYLINE:
			failing(f"(navigator.playCODE) $$$$$ Playback of the stream is NOT possible; the Stream-URL on the *skylinewebcams.com* website is BROKEN or OFFLINE !!! $$$$$\n $$$$$ TITLE : {CLEAR_TITLE} || VIDEO : {SKYLINE} $$$$$")
		return dialog.notification(translation(30527).format(SMALL_TITLE), translation(30529), icon, 15000)

def listFavorites():
	debug_MS("(navigator.listFavorites) ------------------------------------------------ START = listFavorites -----------------------------------------------")
	WATCHING = []
	if xbmcvfs.exists(FAVORIT_FILE) and os.stat(FAVORIT_FILE).st_size > 0: # List all LIVE cameras in favourites - go directly to the 'listCameras' folder
		for snippet in sorted(preserve(FAVORIT_FILE), key=lambda vsx: cleanUmlaut(vsx.get('Clearname', 'zorro')).lower()):
			debug_MS(f"(navigator.listFavorites[1]) ##### NAME : {snippet.get('Clearname')} || LINK : {snippet.get('Streaming')} || THUMB : {snippet.get('Image')} #####")
			WATCHING.append({'IDENTiTY': snippet.get('Streaming'), 'name': snippet.get('Clearname'), 'photo': snippet.get('Image'), 'region': snippet.get('country'), 'plot': snippet.get('plot_short')})
		if WATCHING:
			return listCameras(WATCHING, 1, 0, 'FAVORITES', 'Favourites')
	return dialog.notification(translation(30530), translation(30531), icon, 10000)

def favorit_construct(**kwargs):
	TOPS = []
	if xbmcvfs.exists(FAVORIT_FILE) and os.stat(FAVORIT_FILE).st_size > 0:
		TOPS = preserve(FAVORIT_FILE)
	if kwargs['action'] == 'ADD':
		del kwargs['mode']; del kwargs['action']; del kwargs['plot_long']; del kwargs['Studio']
		TOPS.append({key: value for key, value in kwargs.items() if value not in ['', 'None', None]})
		preserve(FAVORIT_FILE, TOPS)
		xbmc.sleep(500)
		dialog.notification(translation(30532), translation(30533).format(kwargs['Clearname']), icon, 10000)
	elif kwargs['action'] == 'DEL':
		TOPS = [xs for xs in TOPS if xs.get('Streaming') != kwargs.get('Streaming')]
		if len(TOPS) == 0:
			xbmcvfs.delete(FAVORIT_FILE)
		elif len(TOPS) >= 1:
			preserve(FAVORIT_FILE, TOPS)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30532), translation(30534).format(kwargs['Clearname']), icon, 10000)

def addDir(params, listitem, folder=True, context={}, handling='default', higher=False):
	uws, entries = build_mass(params), []
	listitem.setPath(uws)
	if enableBACK and PLACEMENT == 1 and higher is True:
		entries.append([translation(30650), f"RunPlugin({build_mass({'mode': 'callingMain'})})"])
	if handling == 'adding' and context:
		entries.append([translation(30651), f"RunPlugin({build_mass({**context, **{'mode': 'favorit_construct', 'action': 'ADD'}})})"])
	if handling == 'removing' and context:
		entries.append([translation(30652), f"RunPlugin({build_mass({**context, **{'mode': 'favorit_construct', 'action': 'DEL'}})})"])
	if len(entries) > 0: listitem.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
