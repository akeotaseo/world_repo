from codequick import Route, Listitem, Resolver
from resources.lib.kedon import getlinkvnm, getlink, replace_all, tb, stream, referer, quangcao
from datetime import datetime
from json import loads
from bs4 import BeautifulSoup
from functools import lru_cache
import re, sys
@lru_cache(maxsize=None)
def saoke():
	url = 'http://mannhan.net'
	r = getlinkvnm(url, url)
	try:
		return BeautifulSoup(r.content, 'html.parser').select_one('main a[target="_blank"]')['href']
	except:
		sys.exit()
@Route.register
def index_saoke(plugin, **kwargs):
	yield []
	url = saoke()
	resp = getlink(url, url, 400)
	if (resp is not None):
		hostsPlayer = re.search(r'hostsPlayer:\["(.*?)"', resp.text)
		refplay = f'https://{hostsPlayer[1]}' if hostsPlayer else url
		ll = re.search(r'(?<=,lives=)(.*?)(?=<)', resp.text)[1]
		nd = re.sub(r'([{,:])(\w+)([},:])', r'\1"\2"\3',ll)
		thaythe = {
			"'[":"[",
			"]'":"]"
			}
		m = loads(replace_all(thaythe, nd))
		for k in m:
			item = Listitem()
			item.info['plot'] = tb
			item.art['thumb'] = item.art['fanart'] = k['league']['picture'] if k['league'].get('picture') else 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/unnamed.jpg'
			tenm = f"{datetime.fromtimestamp(int(k['time'])/1000).strftime('%H:%M %d/%m')}: {k['title'].split(':')[1].strip()}"
			item.label = tenm
			item.set_callback(list_saoke, k['_id'], tenm)
			yield item
@Route.register
def list_saoke(plugin, idsk=None, ten=None, **kwargs):
	yield []
	if idsk is None or ten is None:
		pass
	else:
		url = saoke()
		resp = getlink(url, url, 400)
		if (resp is not None) and ('.m3u8' in resp.text):
			hostsPlayer = re.search(r'hostsPlayer:\["(.*?)"', resp.text)
			refplay = f'https://{hostsPlayer[1]}' if hostsPlayer else url
			ll = re.search(r'(?<=,lives=)(.*?)(?=<)', resp.text)[1]
			nd = re.sub(r'([{,:])(\w+)([},:])', r'\1"\2"\3',ll)
			thaythe = {
				"'[":"[",
				"]'":"]"
				}
			m = loads(replace_all(thaythe, nd))
			for k in m:
				if idsk in str(k):
					streams = [
						('hlsUrls', 'shareBanner', 'blv'),
						('hlsUrlsManNhan', 'shareBannerManNhan', 'blvManNhan'),
						('hlsUrlsBongLive', 'shareBannerBongLive', 'blvBongLive'),
						('hlsUrlsBongNhua', 'shareBannerBongNhua', 'blvBongNhua')
					]
					for stream_key, banner_key, blv_key in streams:
						if stream_key in k:
							ks = k[stream_key]
							stream_list = (p for p in ks if p['url'])
							for stream_item in stream_list:
								item = Listitem()
								item.info['plot'] = tb
								item.art['thumb'] = item.art['fanart'] = k[banner_key]
								tenm = f'{stream_item["name"]} - {ten} ({k[blv_key]})' if k[blv_key] else f'{stream_item["name"]} - {ten}'
								item.label = tenm
								item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{stream(stream_item["url"])}{referer(refplay)}', tenm, '')
								yield item
		else:
			yield quangcao()