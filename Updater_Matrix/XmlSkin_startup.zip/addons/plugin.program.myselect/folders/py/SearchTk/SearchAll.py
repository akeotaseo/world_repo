import xbmc, xbmcgui


def SearchAll():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Αναζήτηση ...[/COLOR][/B]',
['[COLOR=white]Movies[/COLOR]',
 '[COLOR=orange]TvShows[/COLOR]',
 '[COLOR=green]Sports[/COLOR]',
 '[COLOR=grey]Music[/COLOR]',
 '[COLOR=yellow]Kids[/COLOR]',
 '[COLOR=blue]Greek[/COLOR]',
 '[COLOR=red]Tube[/COLOR]',
 '[B][COLOR red]<---                                                                      [COLOR grey]Back[/COLOR][/B]'])



    if call:
        if call < 1:
            return
        func = funcs[call-8]
        return func()
    else:
        func = funcs[call]
        return func()
    return 





def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/SearchTk/Search_movies.py")')


def click_2():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/SearchTk/Search_tvshows.py")')

def click_3():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/SearchSports.py")')

def click_4():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/SearchTk/Search_music.py")')

def click_5():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/SearchTk/Search_kids.py")')

def click_6():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/SearchTk/Search_greek.py")')

def click_7():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/SearchTk/SearchTube.py")')

def click_8():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/ShortCut.py")')


SearchAll()
