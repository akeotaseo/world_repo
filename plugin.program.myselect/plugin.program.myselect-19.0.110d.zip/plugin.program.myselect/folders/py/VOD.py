import xbmc, xbmcgui

def vod():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ StalkerVod ~[/COLOR][/B]', 
['[B][COLOR=white]VOD[/COLOR][/B]',
 '[B][COLOR=white]SERIES[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.stalkervod/?action=vod&page=1&update_listing=False",return))')
    xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/plugin.video.macvod/DialogPleaseWait/doestworkalltime.png')
    xbmc.sleep(4000)

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.stalkervod/?action=series&page=1&update_listing=False",return)')
    xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/doestworkalltime.png')
    
    


vod()
