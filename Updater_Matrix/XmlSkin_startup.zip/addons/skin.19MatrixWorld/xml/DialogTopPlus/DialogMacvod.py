﻿import xbmc, xbmcgui
xbmc.executebuiltin('Dialog.Close(all,true)')
xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.macvod/?action=xtreamcodes&extra&page&plot&thumbnail=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.macvod%5cicon.png&title=%5bB%5d%5bCOLOR%20orange%5dServers%20-%20Xtream%20Codes%5b%2fCOLOR%5d%5b%2fB%5d&url")')
xbmcgui.Dialog().notification("[B][COLOR orange]Keep calm and just wait[/COLOR][/B]", "[COLOR green]Περιμένετε...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/Pleasewait.png')
xbmc.sleep(4000)
xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png')
xbmc.sleep(4000)
xbmcgui.Dialog().notification("[B][COLOR deeppink]Macvod[/COLOR][/B]", "IPTV", sound=False, icon='special://home/addons/plugin.video.macvod/icon.png')
xbmc.sleep(4000)



