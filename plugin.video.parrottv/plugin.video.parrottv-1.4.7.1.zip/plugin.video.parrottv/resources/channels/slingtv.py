# Credits to madtitansports <3
# Never gonna give you up guys
# Also check 'em out, they do have nice selection of channels

import requests
import inputstreamhelper
import xbmcgui
import xbmcplugin
import random
import sys
try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote

class SlingTV:
    def __init__(self, handle):
        self.UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) ' \
             'Chrome/69.0.3497.100 Safari/537.36'
        self.HEADERS = {
            'Accept': '*/*',
            'Origin': 'https://www.sling.com',
            'User-Agent': self.UA,
            'Content-Type': 'application/json;charset=UTF-8',
            'Referer': 'https://www.sling.com',
            'Accept-Language': 'en-US,en;q=0.9'
        }
        self.handle = handle
        self.useCustomProxy = self.useProxy()
        self.Servers = [
            "https://AttractiveHollowHypermedia.serveronetwo.repl.co",
            "https://OrangePleasantJava.serveronetwo.repl.co",
            "https://MistySlightGraphicslibrary.serveronetwo.repl.co",
            "https://HelplessWideCones.serveronetwo.repl.co",
            "https://KnowledgeableIntentRepo.serveronetwo.repl.co",
            "https://ImmaculateBusyRuntimelibrary.serveronetwo.repl.co",
            "https://SympatheticFrontApplicationprogram.serveronetwo.repl.co",
            "https://ProductiveKnowingPortablesoftware.serveronetwo.repl.co",
            "https://InbornGenuineEmacs.serveronetwo.repl.co"
        ]
        self.ProxyServer = random.choice(self.Servers)

    def useProxy(self):
        ip = requests.get("https://api.my-ip.io/ip").text
        data = requests.get("https://ipinfo.io/{}/json".format(ip))
        return data.json()['country'] != 'US'

    def getPlaylist(self, playlist_url):
        if self.useCustomProxy:
            playlist_url = "{ProxyServer}/normal?url={playlist_url}".format(ProxyServer=self.ProxyServer, playlist_url=playlist_url)
        response = requests.get(playlist_url, headers=self.HEADERS, verify=True)
        if response is not None and response.status_code == 200:
            video = response.json()

            if video is None or 'message' in video: return
            if 'playback_info' not in video: return
            mpd_url = video["playback_info"]["dash_manifest_url"]
            for clip in video['playback_info']['clips']:
                if clip['location'] != '':
                    qmx_url = clip['location']
                    break
            if "UNKNOWN" not in mpd_url:
                if self.useCustomProxy:
                    qmx_url = "{ProxyServer}/normal?url={qmx_url}".format(ProxyServer=self.ProxyServer, qmx_url=qmx_url)
                response = requests.get(qmx_url, headers=self.HEADERS, verify=True)
                if response is not None and response.status_code == 200:
                    qmx = response.json()
                    if 'message' in qmx: return
                    lic_url = ''
                    if 'encryption' in qmx:
                        lic_url = qmx['encryption']['providers']['widevine']['proxy_url']
                         
                    if lic_url != '':   
                        payload = '{"channel_id": "6f6788bea06243da873b8b3450b4aaa0", "env": "production", "message": [D{SSM}], "user_id": "fcdda172-0060-11eb-b722-0a599a2ac821"}'
                        licenseKey = ""
                        if self.useCustomProxy:
                            licenseKey = '{ProxyServer}/drm|Content-Type=text/plain&User-Agent={UA}|{qotedPayload}|'.format(ProxyServer=self.ProxyServer, UA=self.UA, qotedPayload=quote(payload))
                        else:
                            licenseKey = "https://p-drmwv.movetv.com/widevine/proxy|Content-Type=text/plain&User-Agent={UA}|{qPayload}|".format(UA=self.UA, qPayload=quote(payload))
        asset_id = ''
        if 'entitlement' in video and 'asset_id' in video['entitlement']:
            asset_id = video['entitlement']['asset_id']
        elif 'playback_info' in video and 'asset' in video['playback_info'] and 'guid' in video['playback_info']['asset']:
            asset_id = video['playback_info']['asset']['guid']
        start_time = video["playback_info"]["linear_info"]["anchor_time"]
        return {
            "url": mpd_url.replace("http://", "https://"),
            "licenseKey": licenseKey,
            "asset_id": asset_id,
            "start_time": start_time
        }

    def getChannelURL(self, channel):
        list = requests.get("https://cbd46b77.cdn.cms.movetv.com/cms/publish3/domain/summary/ums/1.json", headers=self.HEADERS).json()
        for item in list["channels"]:
            if item["title"] == channel: return item["qvt_url"]

    def grab(self, channel):
        json = self.getPlaylist(self.getChannelURL(channel))
        isHelper = inputstreamhelper.Helper("mpd", drm="widevine")
        mpdUrl = json["url"]
        if self.useCustomProxy:
            mpdUrl = "{ProxyServer}/playlist?url={mpdUrl}".format(ProxyServer=self.ProxyServer, mpdUrl=mpdUrl)
        if isHelper.check_inputstream():
            li = xbmcgui.ListItem("Stream", path=mpdUrl)
            if sys.version_info[0] == 2:
                li.setProperty('inputstreamaddon','inputstream.adaptive') #kodi 18
            else:
                li.setProperty('inputstream','inputstream.adaptive') #kodi 19
            li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            li.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
            li.setProperty('inputstream.adaptive.license_key', json["licenseKey"])
            li.setMimeType('application/dash+xml')
            li.setContentLookup(False)
            xbmcplugin.setResolvedUrl(self.handle, True, li)
        else:
            xbmcgui.Dialog().ok("Error", "No inputstream helper found")