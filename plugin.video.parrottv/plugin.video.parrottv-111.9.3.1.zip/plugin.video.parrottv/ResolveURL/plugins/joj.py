# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests
import re
from bs4 import BeautifulSoup
from ..utils.browser import Firefox
from ..utils.resolve import Resolver

class JOJ(Resolver):
    def __init__(self):
        self.channels = {
            'joj': 'https://live.joj.sk/',
            'plus': 'https://plus.joj.sk/live',
            'wau': 'https://wau.joj.sk/live',
            'joj24': 'https://live.cdn.joj.sk/live/andromeda/joj_news-404.m3u8'
        }

    def grab(self, channel):
        firefox = Firefox()
        if channel == "family":
            return "http://nn.geo.joj.sk/hls/family-540.m3u8", firefox.headers

        session = requests.Session()
        response = session.get(self.channels[channel], headers=firefox.headers)
        html = BeautifulSoup(response.content, features="html.parser")
            
        player = None
        items = html.find_all('iframe',{},True)
        if len(items) > 0:
            for iframe in items:
                if 'https://media.joj.sk/' in iframe['src']:
                    player = iframe['src']
                    break
                
        firefox.addHeader('Referer', self.channels[channel])
        response = session.get(player, headers=firefox.headers)
            
        content = response.content
        try:
            content = content.decode('utf-8')
        except AttributeError:
            pass
        matches = re.search('"hls": "(.*)"', content)
        url = matches.group(1)
        return url, firefox.headers