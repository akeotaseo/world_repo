# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests

class NovaSport:
    def __init__(self):
        self.ua = "Dalvik/2.1.0 (Linux; U; Android 5.1.1; AFTT Build/LVY48F)"
        self.base = "https://magictv.licenses4.me//embedkeys/cz{}"

    def grab(self, channel):
        headers = {'User-Agent': self.ua}
        headers.update({'Referer': 'https://livetv.video/'})
        url = self.base.format(channel)
        resp = requests.get(url, headers=headers).text
        return resp

    