# -*- coding: utf-8 -*-

import re
import requests
import base64
from six.moves.urllib_parse import parse_qs, urlencode, quote_plus
from resources.lib.modules import api_keys
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import source_utils
from resources.lib.modules import log_utils

import json
import xbmcgui

class source:
	def __init__(self):
		self.priority = 1
		self.language = ['en', 'el']
		self.domains = ['mediafusion.elfhosted.com']
		self.base_link = 'https://mediafusion.elfhosted.com/D-KbFjcL7shV3nF5URsgpERXNhL_XBJ6EGht2NKLbvhYMLLTuwVx8FHavz5BasCyB08p-V9MJANcKlNPclL-8LtdZBPO8CMGPa3J6LlhUpzYz40qfgeazG45o_GTAbMd_7Z8PTgAr9BO7FBlz8XO6k9R4eEMZJ8MicI6vu4uC4aEFFCTbiKArUDobe7TPVYyT5-z6RDm-w80PG-RopSD5-fpJToKkfSdRsUmQQFDrsOHejjaFrcJJzhgc-Tv3rPSJiho4M2PZlwASLofIx5qDBQQ'
		self.movieSearch_link = '/stream/movie/%s.json'
		self.tvSearch_link = '/stream/series/%s:%s:%s.json'
		self.aliases = []

	def movie(self, imdb, tmdb, title, localtitle, aliases, year):
		try:
			self.aliases.extend(aliases)
			url = {'imdb': imdb, 'title': title, 'aliases': aliases, 'year': year}
			url = urlencode(url)
			return url
		except:
			return

	def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
		try:
			self.aliases.extend(aliases)
			url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
			url = urlencode(url)
			return url
		except:
			return

	def episode(self, url, imdb, tvdb, title, premiered, season, episode):
		try:
			if url is None: return

			url = parse_qs(url)
			url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
			url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
			url = urlencode(url)
			return url
		except:
			return

	def sources(self, url, hostDict, hostprDict):
		sources = []
		try:
			try:
				data = parse_qs(url)
				data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

				title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
				year = data['year']
				imdb = data['imdb']
				if 'tvshowtitle' in data:
					season = data['season']
					episode = data['episode']
					hdlr = 'S%02dE%02d' % (int(season), int(episode))
					url = '%s%s' % (self.base_link, self.tvSearch_link % (imdb, season, episode))
				else:
					url = '%s%s' % (self.base_link, self.movieSearch_link % imdb)
					hdlr = year
				results = client.request(url, timeout='7')
				files = json.loads(results)['streams']
			except:
				log_utils.log('mediafusion_exc', 1)
				return sources

			if files:
				for file in files:
					try:
						if '⚡️' in file['name']:
							file_types = ('.mkv', '.mp4', '.avi', '.m4v', '.wmv')
							name = file['behaviorHints']['filename']
							if not name.endswith(file_types): continue
							if not source_utils.is_match(name, title, hdlr, self.aliases): continue
							url = file['url']
							hash = re.compile('/playback/(.+?)/.+?').findall(url)[0]
							dsize = file['behaviorHints']['videoSize']
							isize = self.format_bytes(dsize)
							quality, info = source_utils.get_release_quality(name)
							info.insert(0, isize)
							info = ' | '.join(info)
							if quality == 'cam' and not 'tvshowtitle' in data: continue
							excluded = control.excludedStrings
							if any(fs in name.lower() for fs in excluded): continue
							sources.append(
								{
									'source': 'direct', 
									'hash': hash,
									'quality': quality, 
									'language': 'en', 
									'url': url, 
									'info': info, 
									'direct': True, 
									'debridonly': False, 
									'name': name, 
									'size': dsize
								}
							)
					except:
						log_utils.log('torrentio_exc', 1)
						pass

			return sources
		except:
			log_utils.log('torrentio_exc', 1)
			return sources

	def resolve(self, url):
		return url
	
	def format_bytes(self, size):
		for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
			if size < 1024:
				return f"{size:.2f} {unit}"
			size /= 1024
		return f"{size:.2f} PB"

