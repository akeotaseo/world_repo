# -*- coding: utf-8 -*-
import re
import sys
import requests
import xbmc, xbmcplugin,xbmcgui,xbmcaddon
import urllib
try:
  import urllib.request
except:
  import urllib2
import base64
import os
import codecs
import xbmcvfs

KodiV = xbmc.getInfoLabel('System.BuildVersion')
KodiV = int(KodiV[:2])


__addon__ = xbmcaddon.Addon()
if KodiV >= 19:
    __cwd__ = xbmcvfs.translatePath( __addon__.getAddonInfo('path') )
    covidimg = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources/imgs', 'covidimg.png' ) )
    sportimg = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources/imgs', 'sportimg.png' ) )
    bntimg = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources/imgs', 'bntimg.png' ) )
    novaimg = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources/imgs', 'novaimg.png' ) )
    img78 = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources/imgs', '78img.png' ) )
    tvonlineimg = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources/imgs', 'tvonlineimg.png' ) )
    tvliveimg = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources/imgs', 'tvliveimg.png' ) )
    tvplayerimg = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources/imgs', 'tvplayerimg.png' ) )
    tvmaniaimg = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources/imgs', 'tvmaniaimg.png' ) )
    alfabassimg = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources/imgs', 'alfabassimg.png' ) )
    balkantvimg = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources/imgs', 'balkantvimg.png' ) )
    worldtvimg = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources/imgs', 'worldtvimg.png' ) )
    shadowimg = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources/imgs', 'shadowimg.png' ) )
    torrentimg = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources/imgs', 'torrentimg.png' ) )
    fanatimg = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources/imgs', 'fanatimg.png' ) )
    smarttvnewsimg = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources/imgs', 'smarttvnewsimg.png' ) )
    bnt1 = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources/imgs', 'bnt1.png' ) )
    bnt2 = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources/imgs', 'bnt2.png' ) )
    bnt3 = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources/imgs', 'bnt3.png' ) )
    bnt4 = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources/imgs', 'bnt4.png' ) )
else:
    __cwd__ = xbmc.translatePath( __addon__.getAddonInfo('path') ).decode('utf-8')
    covidimg = xbmc.translatePath( os.path.join( __cwd__, 'resources/imgs', 'covidimg.png' ) ).decode('utf-8')
    sportimg = xbmc.translatePath( os.path.join( __cwd__, 'resources/imgs', 'sportimg.png' ) ).decode('utf-8')
    bntimg = xbmc.translatePath( os.path.join( __cwd__, 'resources/imgs', 'bntimg.png' ) ).decode('utf-8')
    novaimg = xbmc.translatePath( os.path.join( __cwd__, 'resources/imgs', 'novaimg.png' ) ).decode('utf-8')
    img78 = xbmc.translatePath( os.path.join( __cwd__, 'resources/imgs', '78img.png' ) ).decode('utf-8')
    tvonlineimg = xbmc.translatePath( os.path.join( __cwd__, 'resources/imgs', 'tvonlineimg.png' ) ).decode('utf-8')
    tvliveimg = xbmc.translatePath( os.path.join( __cwd__, 'resources/imgs', 'tvliveimg.png' ) ).decode('utf-8')
    tvplayerimg = xbmc.translatePath( os.path.join( __cwd__, 'resources/imgs', 'tvplayerimg.png' ) ).decode('utf-8')
    tvmaniaimg = xbmc.translatePath( os.path.join( __cwd__, 'resources/imgs', 'tvmaniaimg.png' ) ).decode('utf-8')
    alfabassimg = xbmc.translatePath( os.path.join( __cwd__, 'resources/imgs', 'alfabassimg.png' ) ).decode('utf-8')
    balkantvimg = xbmc.translatePath( os.path.join( __cwd__, 'resources/imgs', 'balkantvimg.png' ) ).decode('utf-8')
    worldtvimg = xbmc.translatePath( os.path.join( __cwd__, 'resources/imgs', 'worldtvimg.png' ) ).decode('utf-8')
    shadowimg = xbmc.translatePath( os.path.join( __cwd__, 'resources/imgs', 'shadowimg.png' ) ).decode('utf-8')
    torrentimg = xbmc.translatePath( os.path.join( __cwd__, 'resources/imgs', 'torrentimg.png' ) ).decode('utf-8')
    fanatimg = xbmc.translatePath( os.path.join( __cwd__, 'resources/imgs', 'fanatimg.png' ) ).decode('utf-8')
    smarttvnewsimg = xbmc.translatePath( os.path.join( __cwd__, 'resources/imgs', 'smarttvnewsimg.png' ) ).decode('utf-8')
    bnt1 = xbmc.translatePath( os.path.join( __cwd__, 'resources/imgs', 'bnt1.png' ) ).decode('utf-8')
    bnt2 = xbmc.translatePath( os.path.join( __cwd__, 'resources/imgs', 'bnt2.png' ) ).decode('utf-8')
    bnt3 = xbmc.translatePath( os.path.join( __cwd__, 'resources/imgs', 'bnt3.png' ) ).decode('utf-8')
    bnt4 = xbmc.translatePath( os.path.join( __cwd__, 'resources/imgs', 'bnt4.png' ) ).decode('utf-8')

checkepg = ['0']

def chepg(ch):
    ch.append('1')
    ch.remove('0') 

#BNT
bntchannels = ['','bnt2','bnt3','bnt4']
bntchlogo = [bnt1,bnt2,bnt3,bnt4]


#seirsanduk
header_string='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0'
BASE_SEIR = [base64.b64decode('aHR0cHM6Ly93d3cuc2Vpci1zYW5kdWsuY29tLw=='),base64.b64decode('aHR0cDovL3NlaXJzYW5kdWsub25saW5lLw=='),
             base64.b64decode('aHR0cDovL3NlaXJzYW5kdWsuY29tLw=='), base64.b64decode('aHR0cDovL3d3dy5zZWlyc2FuZHVrLnVzLw=='),
             base64.b64decode('aHR0cDovL3d3dy5zZWlyc2FuZHVrLm9ubGluZS8='), base64.b64decode('aHR0cDovL3d3dy5zZWlyc2FuZHVrLmNvbS8='),
             base64.b64decode('aHR0cHM6Ly9zZWlyc2FuZHVrLnVz'), base64.b64decode('aHR0cHM6Ly9zZWlyc2FuZHVrLm9ubGluZS8='),
             base64.b64decode('aHR0cHM6Ly9zZWlyc2FuZHVrLmNvbS8='), base64.b64decode('aHR0cHM6Ly93d3cuc2VpcnNhbmR1ay51cy8='),
             base64.b64decode('aHR0cHM6Ly93d3cuc2VpcnNhbmR1ay5vbmxpbmUv'), base64.b64decode('aHR0cHM6Ly93d3cuc2VpcnNhbmR1ay5jb20v'),
             base64.b64decode('aHR0cDovL3NlaXJzYW5kdWsudXMv')]
def openUrl(url):
    if KodiV >= 19:
        req=urllib.request.Request(url)
    else:
        req=urllib2.Request(url)
    req.add_header('User-Agent',header_string)
    if KodiV >= 19:
        response=urllib.request.urlopen(req)
    else:
        response=urllib2.urlopen(req)
    source=response.read()
    response.close()
    return source

    
#bgplayer
baseurl_bgplayer = base64.b64decode("aHR0cHM6Ly9hcGkuYmd0dmxpdmUuY29tL2NoYW5uZWxz")


#shadow tv
baseurlShTV = base64.b64decode("aHR0cDovL3d3dy5zZHctbmV0Lm1lLw==")
suburlShTV = base64.b64decode("Y2F0ZWdvcmllcy8=")

#fanattv
baseurl_fanat = base64.b64decode("aHR0cDovL2ZhbmF0LnR2Lw==")


#alfabass
baseurl_alfabass = base64.b64decode("aHR0cDovL2FsZmFiYXNzLXR2ZnJlZS5kby5hbS8=")

#world channels
baseurl_deti = base64.b64decode("aHR0cDovL3J1dHYubWUvdHZwYy9iYXNlL2RldGkuYmF6")
baseurl_xxx = base64.b64decode("aHR0cDovL3J1dHYubWUvdHZwYy9iYXNlLzE4cC5iYXo=")
baseurl_sport = base64.b64decode("aHR0cDovL3J1dHYubWUvdHZwYy9iYXNlL3Nwb3J0LmJheg==")
baseurl_razv = base64.b64decode("aHR0cDovL3J1dHYubWUvdHZwYy9iYXNlL3JhenYuYmF6")
baseurl_news = base64.b64decode("aHR0cDovL3J1dHYubWUvdHZwYy9iYXNlL25ld3MuYmF6")
baseurl_muz = base64.b64decode("aHR0cDovL3J1dHYubWUvdHZwYy9iYXNlL211ei5iYXo=")
baseurl_film = base64.b64decode("aHR0cDovL3J1dHYubWUvdHZwYy9iYXNlL2ZpbG0uYmF6")
baseurl_pozn = base64.b64decode("aHR0cDovL3J1dHYubWUvdHZwYy9iYXNlL3Bvem4uYmF6")


#smarttvnews
baseurl_smarttvnews = base64.b64decode("aHR0cHM6Ly9zbWFydHR2bmV3cy5ydS9hcHBzL2lwdHZjaGFubmVscy5tM3U=")


#sports tv    
livespurl = 'https://api.livesports24.online/gethost'
try:
    responsel = requests.get(livespurl,timeout=2)
    livesp = responsel.content
except:
    livesp = '185-8-178-138.livesports24.online' 
    

#Nova HD
nova_url = base64.b64decode("aHR0cHM6Ly9ub3ZhLmJnL2xpdmU=")
nova_epg_url = base64.b64decode("aHR0cHM6Ly9ub3ZhLmJnL3NjaGVkdWxl") 
nova_news_url = base64.b64decode("aHR0cHM6Ly9ub3ZhLmJnL2xpdmUvbmV3cw==")
nova_news_epg_url = base64.b64decode("aHR0cHM6Ly9ub3ZhLmJnL3NjaGVkdWxlL2luZGV4Lzc=") 

def takeThurd(elem):
    return elem[2]

def takeSecond(elem):
    return elem[1]

def CATEGORIES():
          addDir('BG TV Online','http://google.bg',4,'',tvonlineimg,'','')
          #addDir('BG TV Player',baseurl_bgplayer,4,'',tvplayerimg,'','')
          addDir('Alfabass Free TV (BG)',baseurl_alfabass,4,'',alfabassimg,'','')
          addDir('БНТ','http://tv.bnt.bg/',4,'',bntimg,'','')
          addDir('Nova TV',nova_url,4,'',novaimg,'','')
          addDir('World Channels (World)',baseurl_news,4,'',worldtvimg,'','')
          #addDir('Fanat TV (Russia)',baseurl_fanat,4,'',fanatimg,'','')
          addDir('SmartTVnews (Russia)',baseurl_smarttvnews,4,'',smarttvnewsimg,'','')
          addDir('ShadowNet TV (World)',baseurlShTV,4,'',shadowimg,'','')


def SUBCATEGORIES(name,url,mode):

    if name== 'БНТ':
          s = requests.Session()
          countch = 0
          countlogo = 0
          for link in bntchannels:
              thumb = bntchlogo[countlogo]
              countlogo = countlogo + 1
              countch = countch + 1
              url1 = url+link  
              response = requests.get(url1)  
              r = response.content
              
              if KodiV >= 19:
                  match_cdn = re.search('src="(.+?)".+?frameborder="0"',r.decode('utf-8'))
              else:
                  match_cdn = re.search('src="(.+?)".+?frameborder="0"',r)
              if match_cdn:
                  cdn_url = match_cdn.group(1)
                  checkhttp = re.search('http', cdn_url)
                  if checkhttp:
                      pass
                  else:
                      cdn_url = 'http:' + cdn_url
                  headers = {
                                'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
                                'Referer': url1
                            }
                  r_play = s.post(cdn_url, headers=headers)
                  match_play = re.search("sdata.src = '(.+?)';",r_play.text)
                  urlPlay = match_play.group(1)
                  addLink('БНТ '+str(countch),urlPlay,2,'',thumb)
              response.close()
          
          
          
    if name== 'Nova TV':
        #Nova TV
          chepg(checkepg)
          response_epg = requests.get(nova_epg_url)
          r_epg = response_epg.content
          if KodiV >= 19:
              desctemp=r_epg.decode('utf-8').replace('\n','')
          else:
              desctemp=r_epg.replace('\n','')
          desctemp=desctemp.replace('\r','')
          desctemp=desctemp.replace('\t','')
          matchdesc = re.compile('timeline-hour">(.+?)</div>.+?TVLiveBroadcasts-click" href=".+?">(.+?)</a>').findall(desctemp)
          desc=''
          for stime, ttitle in matchdesc:
            stime = stime.strip()
            ttitle = ttitle.strip()
            desc=desc+'[COLOR CC00FF00]'+stime+'[/COLOR]'+'\n'+ttitle+'\n'
                
          headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3282.186 Safari/537.36'}
          s = requests.Session()
          r = s.get(url, headers=headers)
          match=re.findall('src="//(i.cdn.bg.+?)"', r.text)
          new_url = "https://"+match[0]
          headers_new={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3282.186 Safari/537.36', 'Referer':url}
          r = s.get(new_url,headers=headers_new)
          channel = re.findall("_sdata.src = '(https:.+?)';", r.text)
          play_url = channel[0]
          addLink(name,play_url,2,desc,'https://bgtvnews.files.wordpress.com/2014/09/nova-tv-logo.png')
        
        #Nova News
          #chepg(checkepg)
          response_epg = requests.get(nova_news_epg_url)
          r_epg = response_epg.content
          if KodiV >= 19:
              desctemp=r_epg.decode('utf-8').replace('\n','')
          else:
              desctemp=r_epg.replace('\n','')
          desctemp=desctemp.replace('\r','')
          desctemp=desctemp.replace('\t','')
          matchdesc = re.compile('timeline-hour">(.+?)</div>.+?<h2>(.+?)</h2>').findall(desctemp)
          desc=''
          for stime, ttitle in matchdesc:
            stime = stime.strip()
            ttitle = ttitle.strip()
            desc=desc+'[COLOR CC00FF00]'+stime+'[/COLOR]'+'\n'+ttitle+'\n'
                
          headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3282.186 Safari/537.36'}
          s = requests.Session()
          r = s.get(nova_news_url, headers=headers)
          match=re.findall('src="//(i.cdn.bg.+?)"', r.text)
          new_url = "https://"+match[0]
          headers_new={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3282.186 Safari/537.36', 'Referer':nova_news_url}
          r = s.get(new_url,headers=headers_new)
          channel = re.findall('src: "(.+?)"', r.text)
          play_url = channel[0]
          findhttp = re.search('http', play_url)
          if findhttp:
                pass
          else:
                play_url = play_url.replace('//','')
                play_url = 'http://'+play_url
          addLink('Nova News',play_url,2,desc,'https://nstatic.nova.bg/files/nova/images/schedule/desktop/selected/novanews.svg')
          
    
    
    if name== 'BG TV Online':
        checkOK = 0
        countch = 0
        name=''
        match=[]
        try:
            for link in BASE_SEIR:
                try:
                    if KodiV >= 19:
                        source_main=openUrl(link.decode('utf-8'))
                    else:
                        source_main=openUrl(link)
                    source=source_main
                    checkOK = 0
                except:
                    checkOK = 1
                if checkOK == 0:
                    if KodiV >= 19:                
                        match=re.compile('<li id=.+?<a href="(.+?)"><img src="(.+?)"  alt="(.+?)"/>').findall(source.decode('utf-8')) 
                    else:
                        match=re.compile('<li id=.+?<a href="(.+?)"><img src="(.+?)"  alt="(.+?)"/>').findall(source)
                    for url_chann,thumbnail,name in match:
                        if KodiV >= 19:                                 
                            thumbnail=link.decode('utf-8')+thumbnail
                        else:
                            thumbnail=link+thumbnail                                      
                        findhttp = re.search('http',url_chann)                             
                        if findhttp:                                                       
                           pass                                                            
                        else:
                            if KodiV >= 19:                                                              
                                url_chann = link.decode('utf-8')[:-1] + url_chann
                            else:
                                url_chann = link[:-1] + url_chann
                            urlsplit = url_chann.split('/')
                            if len(urlsplit) == 4:
                              pass
                            else:
                              url_chann = urlsplit[0]+"//"+urlsplit[4]+"/"+urlsplit[5]                          
                        name = name.replace(' Online','')                                  
                        countch = countch + 1                                              
                        name = str(countch) + '. ' + name                                  
                        addDir(name,url_chann,1,'',thumbnail,'','')
                    if match:
                        break
                else:
                    pass                     
        except:
            addDir('===== В момента няма достъп до източника! =====','',1,'','DefaultFolder.png','','')
        if checkOK == 1:
            addDir('===== В момента няма достъп до източника! =====','',1,'','DefaultFolder.png','','')
        else:
            pass
              
              
    if name== 'World Channels (World)':
          addDir("News channels",baseurl_news,1,'','https://prospectphotography.net/john_mcdaniel/wp-content/uploads/2017/02/news-icon.png','','')
          addDir("Sport channels",baseurl_sport,1,'','https://upload.wikimedia.org/wikipedia/commons/d/db/Sports_portal_bar_icon.png','','')
          addDir("Kid's channels",baseurl_deti,1,'','https://png.pngtree.com/png-vector/20190811/ourlarge/pngtree-kids-ride-paper-plane-vector-illustration-png-image_1687067.jpg','','')
          addDir("Music channels",baseurl_muz,1,'','https://p.kindpng.com/picc/s/166-1667324_graphic-design-music-notes-hd-png-download.png','','')
          addDir("Movie channels",baseurl_film,1,'','https://www.pngitem.com/pimgs/m/301-3014574_popcorn-cinema-png-download-movie-popcorn-transparent-background.png','','')
          addDir("Scientific channels",baseurl_pozn,1,'','https://upload.wikimedia.org/wikipedia/en/c/cd/March_for_Science.png','','')
          addDir("Entertainment channels",baseurl_razv,1,'','https://www.3edgetechnologies.com/images/media-icon.png','','')
          addDir("XXX channels",baseurl_xxx,1,'','https://upload.wikimedia.org/wikipedia/commons/thumb/1/19/Pornproject_logo.svg/640px-Pornproject_logo.svg.png','','')
                          
    
    
    if name== 'ShadowNet TV (World)':
          response = requests.get(baseurlShTV)
          r = response.content
          if KodiV >= 19:
              matchCatShTV = re.compile('<a href="http://www.sdw-net.me/categories/(.+?)">(.+?)</a>').findall(r.decode('utf-8'))
          else:
              matchCatShTV = re.compile('<a href="http://www.sdw-net.me/categories/(.+?)">(.+?)</a>').findall(r)
          for link,title in matchCatShTV:
              url = baseurlShTV.decode('utf-8')+suburlShTV.decode('utf-8')+link
              title = title
              addDir(title,url,1,'','DefaultFolder.png','','')
          response.close()
          
    
    if name== 'Fanat TV (Russia)':
          response = requests.get(baseurl_fanat)
          r = response.content
          if KodiV >= 19:
              matchCat = re.compile('<li class="channels"><a href="(.+?)">(.+?)</a>').findall(r.decode('utf-8'))
          else:
              matchCat = re.compile('<li class="channels"><a href="(.+?)">(.+?)</a>').findall(r)
          for link,title in matchCat:
              url = link
              title = title
              addDir(title,url,1,'','DefaultFolder.png','','')
          response.close()
          
          
    if name== 'Alfabass Free TV (BG)':
          response = requests.get(baseurl_alfabass)
          r = response.content
          if KodiV >= 19:
              matchCat = re.compile('<a href="http(.+?)"><span>(.+?)</span>').findall(r.decode('utf-8'))
          else:
              matchCat = re.compile('<a href="http(.+?)"><span>(.+?)</span>').findall(r)
          matchCat.sort(key=takeSecond)
          for link,title in matchCat:
              checkload = re.search('/load/',link)
              if checkload:
                  pass
              else:
                  url = 'http' + link
                  addDir(title,url,1,'','DefaultFolder.png','','')
          response.close()
          
    if name== 'SmartTVnews (Russia)':
          response = requests.get(baseurl_smarttvnews)
          r = response.content
          if KodiV >= 19:
              rep = r.decode('utf-8').replace('#EXTVLCOPT:','')
          else:
              rep = r.replace('#EXTVLCOPT:','')
          rep = rep.replace('http-user-agent=smartlabs\r\n','')
          rep = rep.replace('network-caching=1000\r\n','')
          match = re.compile('EXTINF:-1,(.+?)\r\n(.+?)\s').findall(rep)
          match.sort()
          #countCh = 0
          for name,link in match:
              url = link
              title = name
              checktitle = re.search('===(.+?)',title)
              if checktitle:
                  pass
              else:
                  #countCh = countCh + 1
                  #title = str(countCh) + ". " + title
                  addLink(title,url,2,'','')
          response.close()
          
def INDEXPAGES(name,url,mode,count,groupID):
            
      #seirsanduk    
      matchSeir = re.search('televizora',url)
      matchSeir1 = re.search('seir',url)
      matchSeir2 = re.search('televizia',url)
      desc="Samo Beroe"
      if matchSeir or matchSeir1 or matchSeir2:
          thumbnail = iconimage
          chepg(checkepg)
          checkcdn = 0
          name_check = name
          url1 = url
          urlrep = url1.split('/')
          tempname = name_check.split('.')
          tempname = tempname[1][1:] + ' Online'
          tempname = tempname.lower()
          for link in BASE_SEIR:
              try:
                  if KodiV >= 19:
                      newurl=link.decode('utf-8')+urlrep[3]
                  else:
                      newurl=link+urlrep[3]
                  channel_source=openUrl(newurl)
                  if KodiV >= 19:
                      findname = re.search('Permanent Link to (.+?)"', channel_source.decode('utf-8'))
                  else:
                      findname = re.search('Permanent Link to (.+?)"', channel_source)
                  if findname:
                      tempname1 = findname.group(1)
                      tempname1 = tempname1.lower()
                      if re.search(tempname,tempname1):
                          if KodiV >= 19:
                              desctemp=channel_source.decode('utf-8').replace('\n','')
                          else:
                              desctemp=channel_source.replace('\n','')
                          desctemp=desctemp.replace('\r','')
                          desctemp=desctemp.replace('\t','')
                          matchdesc=re.compile('<div class="time">(.+?)</div>.+?<div class="title">(.+?)</div>').findall(desctemp)
                          desc=''
                          for timeing, descr in matchdesc:
                              desc=desc+'[COLOR CC00FF00]'+timeing+'[/COLOR]'+'\n'+descr+'\n'
                          if KodiV >= 19:
                              match_link_01=re.search('file:"(.+?)",', channel_source.decode('utf-8'))
                          else:
                              match_link_01=re.search('file:"(.+?)",', channel_source)
                          name_01='PLAY: '+name
                          if match_link_01:
                              url_01 = match_link_01.group(1)
                              checkfile = newurl.split('/')
                              chek = checkfile[3].replace('-online','')
                              chek = chek.replace('?id=','')
                              findfile = re.search(chek, url_01)
                              url_01 = url_01.replace('10.10.0.20','cdn76.kirizi.xyz')
                              if findfile:
                                  xbmc.log('Play Seir: %s' % newurl,  xbmc.LOGDEBUG)
                                  addLink(name_01,url_01,2,desc,thumbnail)
                                  checkcdn = 1
                              else:
                                  pass
                          else:
                              pass
                      else:
                          pass
                          
                      #player 1    
                      if KodiV >= 19:
                          findplayer1 = re.search('\?player=1', channel_source.decode('utf-8'))
                      else:
                          findplayer1 = re.search('\?player=1', channel_source)
                      if findplayer1:
                            newurl1 = newurl + '?player=1'
                            channel_source1 = openUrl(newurl1)
                            
                            try:
                                match_link_01=re.search('file:"(.+?)",', channel_source1.decode('utf-8'))
                            except:
                                match_link_01=re.search('file:"(.+?)",', channel_source1)
                                    
                            name_01='PLAY: '+name
                            if match_link_01:
                                url_01 = match_link_01.group(1)
                                checkfile = newurl1.split('/')
                                chek = checkfile[3].replace('-online?player=1','')
                                chek = chek.replace('?id=','')
                                findfile = re.search(chek, url_01)
                                url_01 = url_01.replace('10.10.0.20','cdn76.kirizi.xyz')
                                if findfile:
                                    xbmc.log('Play Seir: %s' % newurl1,  xbmc.LOGDEBUG)
                                    addLink(name_01,url_01,2,desc,thumbnail)
                                    checkcdn = 1
                                else:
                                    pass
                            else:
                                pass
                      else:
                            pass
                            
                      #player 2    
                      if KodiV >= 19:
                          findplayer1 = re.search('\?player=2', channel_source.decode('utf-8'))
                      else:
                          findplayer1 = re.search('\?player=2', channel_source)
                      if findplayer1:
                            newurl2 = newurl + '?player=2'
                            channel_source2 = openUrl(newurl2)
                            
                            try:
                                match_link_01=re.search('file:"(.+?)",', channel_source2.decode('utf-8'))
                            except:
                                match_link_01=re.search('file:"(.+?)",', channel_source2)
                                    
                            name_01='PLAY: '+name
                            if match_link_01:
                                url_01 = match_link_01.group(1)
                                checkfile = newurl2.split('/')
                                chek = checkfile[3].replace('-online?player=2','')
                                chek = chek.replace('?id=','')
                                findfile = re.search(chek, url_01)
                                url_01 = url_01.replace('10.10.0.20','cdn76.kirizi.xyz')
                                if findfile:
                                    xbmc.log('Play Seir: %s' % newurl2,  xbmc.LOGDEBUG)
                                    addLink(name_01,url_01,2,desc,thumbnail)
                                    checkcdn = 1
                                else:
                                    pass
                            else:
                                pass
                      else:
                            pass
                  else:
                      pass
              except:
                  pass
                        

      #world channels
      matchWC = re.search('rutv.me',url)
      if matchWC:
          #try:
              if KodiV >= 19:
                  response = urllib.request.urlopen(url, timeout=1)
              else:
                  response = urllib2.urlopen(url, timeout=1)
              r_basbah = response.read()
              if KodiV >= 19:
                  r_basbah = r_basbah.decode('utf-8').replace('\n','\n\n')
              else:
                  r_basbah = r_basbah.replace('\n','\n\n')
              r_basbah = "\n" + r_basbah + "\n"
              r_basbah = r_basbah.replace('\r','')
              match = re.compile('\n(.+?)\n\nhttp(.+?)\n').findall(r_basbah)
              match.sort()
              chnom = 0
              for name,link in match:
                  chnom = chnom + 1
                  play_url = "http" + link + "|verifypeer=false&User-Agent=Mozilla/5.0"
                  title = str(chnom) + ". " + name
                  addLink(title,play_url,2,'','')
          #except:
              #addDir('===== В момента няма достъп до източника! =====','',1,'','DefaultFolder.png','','')

      
      #phoenixreborn
      matchPR = re.search('phoenix',url)
      if matchPR:
          response = requests.get(url)
          r = response.content
          match = re.compile('#EXTINF: -1.+?name="(.+?)" tvg-logo="(.+?)" group-title="(.+?)",.+?\n(.+?)\s').findall(r)
          match.sort()
          groupname=name
          for name,thumb,group,link in match:
              if groupname==group:
                  url_play = link
                  thumbnail = thumb
                  addLink(name,url_play,2,'',thumbnail)
          response.close()

            
      
      #shadow tv
      matchSH = re.search('sdw-net.me',url)
      if matchSH:
            responseCh = requests.get(url)
            rCh = responseCh.content
       
            name = ''
            #first page channels
            if KodiV >= 19:
                matchCh = re.compile('<a href="(.+?)"  ><img src="(.+?)" alt="(.+?)" /></a>').findall(rCh.decode('utf-8'))
            else:
                matchCh = re.compile('<a href="(.+?)"  ><img src="(.+?)" alt="(.+?)" /></a>').findall(rCh)
            
            #check for more pages
            if KodiV >= 19:
                matchPages = re.search('<li class="ActivePage">1</li>(.+?)\n', rCh.decode('utf-8'))
            else:
                matchPages = re.search('<li class="ActivePage">1</li>(.+?)\n', rCh)
            if matchPages:
                match2 = []
                pages = matchPages.group(1)
                findPages = re.compile('<li><a href="(.+?)">.+?</a></li>').findall(pages)
                for page in findPages:
                    responsePg = requests.get(page)
                    rPg = responsePg.content
                    if KodiV >= 19:
                        matchChP = re.compile('<a href="(.+?)"  ><img src="(.+?)" alt="(.+?)" /></a>').findall(rPg.decode('utf-8'))
                    else:
                        matchChP = re.compile('<a href="(.+?)"  ><img src="(.+?)" alt="(.+?)" /></a>').findall(rPg)
                    match2 = match2 + matchChP
                matchCh = matchCh + match2
            matchCh.sort(key=takeThurd)
                
            for link,thumb,title in matchCh:
                if name != title:
                    IndexURL = link
                    responsePlay = requests.get(IndexURL)
                    rPlay = responsePlay.content
                    hdr = {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
                           'Referer':IndexURL,
                           'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.4.600'}
                    if KodiV >= 19:
                        findPlay = re.search("<iframe src='(.+?)'", rPlay.decode('utf-8'))
                    else:
                        findPlay = re.search("<iframe src='(.+?)'", rPlay)
                    if findPlay:
                        playPage = findPlay.group(1)
                        if KodiV >= 19:
                            req = urllib.request.Request(playPage, headers=hdr)
                            page = urllib.request.urlopen(req)
                        else:
                            req = urllib2.Request(playPage, headers=hdr)
                            page = urllib2.urlopen(req)
                        rPage = page.read()
                        if KodiV >= 19:
                            pagePlay = re.search('{source: "(.+?)",', rPage.decode('utf-8'))
                        else:
                            pagePlay = re.search('{source: "(.+?)",', rPage)
                        if pagePlay:
                            PlayURL = pagePlay.group(1)
                            try:
                                responseURL = requests.get(PlayURL, timeout = 0.5)
                                rPlayURL = responseURL.content
                                if rPlayURL:
                                    url = PlayURL
                                    name = title
                                    thumbnail = thumb       
                                    addLink(name,url,2,'',thumbnail)
                            except:
                                pass
                                
      
      
      #fanat tv
      matchFanat = re.search('fanat.tv',url)
      if matchFanat:
            responseCh = requests.get(url)
            rCh = responseCh.content
            if KodiV >= 19:
                rCh = rCh.decode('utf-8')
            else:
                pass
            rCh = rCh.replace('\r','')
            rCh = rCh.replace('\n','')
            rCh = rCh.replace('\t','')
            matchCh = re.compile('<a href="(.+?)"><div class="product col-md-3 col-sm-3 col-xs-6"><div><img src="(.+?)" class="img-responsive" alt=""></div><p>(.+?)</p>').findall(rCh)
            matchCh.sort(key=takeThurd)
            for link,thumbnail,title in matchCh:
                checklink = re.search('<p',link)
                checkimg = re.search('<p',thumbnail)
                checkname = re.search('<p',title)
                if checklink or checkimg or checkname:
                    pass
                else:
                    url = link
                    name = title
                    if KodiV >= 19:
                        thumbnail = baseurl_fanat.decode('utf-8') + thumbnail
                    else:
                        thumbnail = baseurl_fanat + thumbnail
                    responsePlay = requests.get(url)
                    rPlay = responsePlay.content
                    if KodiV >= 19:
                        matchPlay = re.search('file: "(.+?)"', rPlay.decode('utf-8'))
                    else:
                        matchPlay = re.search('file: "(.+?)"', rPlay)
                    if matchPlay:
                        url = matchPlay.group(1)
                        addLink(name,url,2,'',thumbnail)
                    else:
                        if KodiV >= 19:
                            matchPlay = re.search('file:"(.+?)"', rPlay.decode('utf-8'))
                        else:
                            matchPlay = re.search('file:"(.+?)"', rPlay)
                        if matchPlay:
                            url = matchPlay.group(1)
                            addLink(name,url,2,'',thumbnail)
                    
                
      #alfabass
      matchAlfabass = re.search('alfabass-tvfree',url)
      if matchAlfabass:
          response = requests.get(url)
          r = response.content
          if KodiV >= 19:
              matchFile = re.compile('file:"(.+?)",').findall(r.decode('utf-8'))
          else:
              matchFile = re.compile('file:"(.+?)",').findall(r)
          titleNum = 0
          if matchFile:
              for link in matchFile:
                  url = link                        
                  try:
                      response = requests.get(url)    
                      titleNum = titleNum + 1
                      name = 'Stream ' + str(titleNum)              
                      addLink(name,url,2,'','DefaultFolder.png') 
                  except:
                      pass                                        
          else:
              pass
          if KodiV >= 19:
              matchFile2 = re.compile("'file': '(.+?)',").findall(r.decode('utf-8'))
          else:
              matchFile2 = re.compile("'file': '(.+?)',").findall(r)
          if matchFile2:
              for link in matchFile2:
                  url = link
                  titleNum = titleNum + 1
                  name = 'Stream ' + str(titleNum)
                  addLink(name,url,2,'','DefaultFolder.png')
          else:
              pass
          if KodiV >= 19:
              matchFile3 = re.compile('src="(.+?)"> </video>').findall(r.decode('utf-8'))
          else:
              matchFile3 = re.compile('src="(.+?)"> </video>').findall(r)
          if matchFile3:
                for link in matchFile3:
                    url = link
                    titleNum = titleNum + 1
                    name = 'Stream ' + str(titleNum)
                    addLink(name,url,2,'','DefaultFolder.png')
          else:
              pass
          if KodiV >= 19:
              matchFile4 = re.compile("'file':'(.+?)',").findall(r.decode('utf-8'))
          else:
              matchFile4 = re.compile("'file':'(.+?)',").findall(r)
          if matchFile4:
               for link in matchFile4:
                    url = link
                    titleNum = titleNum + 1
                    name = 'Stream ' + str(titleNum)
                    addLink(name,url,2,'','DefaultFolder.png')
          else:
              pass
          if KodiV >= 19:
              matchFile5 = re.compile("file: '(.+?)',").findall(r.decode('utf-8'))
          else:
              matchFile5 = re.compile("file: '(.+?)',").findall(r)
          if matchFile5:
                for link in matchFile5:
                    url = link
                    titleNum = titleNum + 1
                    name = 'Stream ' + str(titleNum)
                    addLink(name,url,2,'','DefaultFolder.png')
          else:
              pass
              
def PLAY(url):
        link = url
        if KodiV >= 19:
            li = xbmcgui.ListItem(path=link)
        else:
            li = xbmcgui.ListItem(iconImage=iconimage, thumbnailImage=iconimage, path=link)
        li.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage })
        li.setInfo('video', { 'title': name })
        try:
          xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
        except:
          xbmc.executebuiltin("Notification('Error','Missing video!')")          
		
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


def addDir(name,url,mode,plot,iconimage,count,groupID):
        if KodiV >= 19:
            u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)+"&count="+str(count)+"&groupID="+str(groupID)
            liz=xbmcgui.ListItem(name)
        else:
            u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&count="+str(count)+"&groupID="+str(groupID)
            liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        ok=True
        liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage })
        liz.setInfo( type="Video", infoLabels={ "Title": name, "plot": plot } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addLink(name,url,mode,plot,iconimage):
        if KodiV >= 19:
            u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
            liz=xbmcgui.ListItem(name)
        else:
            u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
            liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        ok=True
        liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage })
        liz.setInfo( type="Video", infoLabels={ "Title": name, "plot": plot } )
        liz.setProperty("IsPlayable" , "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok   

params=get_params()
url=None
name=None
iconimage=None
mode=None
count=None
groupID=None

if KodiV >= 19:
    try:
            url=urllib.parse.unquote_plus(params["url"])
    except:
            pass
    try:
            name=urllib.parse.unquote_plus(params["name"])
    except:
            pass
    try:
            iconimage=urllib.parse.unquote_plus(params["iconimage"])
    except:
            pass
    try:
            mode=int(params["mode"])
    except:
            pass
    try:
            count=int(params["count"])
    except:
            pass
    try:
            groupID=int(params["groupID"])
    except:
            pass
else:            
    try:
            url=urllib.unquote_plus(params["url"])
    except:
            pass
    try:
            name=urllib.unquote_plus(params["name"])
    except:
            pass
    try:
            iconimage=urllib.unquote_plus(params["iconimage"])
    except:
            pass
    try:
            mode=int(params["mode"])
    except:
            pass
    try:
            count=int(params["count"])
    except:
            pass
    try:
            groupID=int(params["groupID"])
    except:
            pass

if mode==None or url==None or len(url)<1:
        print ("")
        CATEGORIES()

elif mode==4:
        print (""+url)
        SUBCATEGORIES(name,url,mode)

elif mode==1:
        print (""+url)
        INDEXPAGES(name,url,mode,count,groupID)

elif mode==2:
        print (""+url)
        PLAY(url)

if checkepg[0] == '0':       
    xbmcplugin.setContent(int(sys.argv[1]), '')
    xbmc.executebuiltin('Container.SetViewMode(55)')
else:
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmc.executebuiltin('Container.SetViewMode(50)')
xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=True)