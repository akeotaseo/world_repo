import os
import json
import time
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import xbmc
import re
import resolveurl as urlresolver
import sys
import requests
from bs4 import BeautifulSoup
import urllib.parse

# Constants
base_url = "https://www3.fsonline.app/"
filme_url = f"{base_url}film/"
seriale_url = f"{base_url}seriale/"
addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
cache_dir = xbmcvfs.translatePath(addon.getAddonInfo('profile'))

# Create cache directory if it doesn't exist
if not os.path.exists(cache_dir):
    os.makedirs(cache_dir)

# Cache functions
def load_cache(filename, expiration):
    cache_path = os.path.join(cache_dir, filename)
    if os.path.exists(cache_path):
        file_age = time.time() - os.path.getmtime(cache_path)
        if file_age < expiration:
            with open(cache_path, 'r') as cache_file:
                return json.load(cache_file)
    return None

def save_cache(data, filename):
    cache_path = os.path.join(cache_dir, filename)
    with open(cache_path, 'w') as cache_file:
        json.dump(data, cache_file)

# Function to add menu items
def add_directory_item(name, query, is_folder=True, icon=None, description=None):
    plugin_url = f"{sys.argv[0]}?{query}"
    li = xbmcgui.ListItem(label=name)
    li.setInfo('video', {'title': name, 'plot': description})
    if icon:
        li.setArt({'thumb': icon, 'icon': icon, 'fanart': icon})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=plugin_url, listitem=li, isFolder=is_folder)

# Main menu function
def main_menu():
    add_directory_item("Filme", "action=list_films", is_folder=True, icon="special://home/addons/plugin.video.fsonline/resources/icons/movies.png")
    add_directory_item("Seriale", "action=list_series", is_folder=True, icon="special://home/addons/plugin.video.fsonline/resources/icons/tv.png")
    add_directory_item("Căutare", "action=search", is_folder=True, icon="special://home/addons/plugin.video.fsonline/resources/icons/search.png")
    xbmcplugin.endOfDirectory(addon_handle)

# List films with pagination and cache
def list_films(page=1):
    cache_filename = f"films_page_{page}.json"
    cached_data = load_cache(cache_filename, expiration=86400)
    if cached_data:
        display_items(cached_data)
        add_next_page_button("list_films", page + 1)
        return

    current_url = f"{filme_url}page/{page}/"
    xbmc.log(f"Accessing film page URL: {current_url}", level=xbmc.LOGINFO)

    response = requests.get(current_url)
    soup = BeautifulSoup(response.content, 'html.parser')
    movies = soup.find('div', {'id': 'archive-content'}).find_all('article', class_='item movies')

    items = []
    for movie in movies:
        title = movie.find('h3').text
        url = movie.find('a')['href']
        image_url = movie.find('img')['data-src']
        description = get_movie_description(url)

        items.append({"name": title, "query": f"action=play&url={url}", "is_folder": False, "icon": image_url, "description": description})

    save_cache(items, cache_filename)
    display_items(items)
    add_next_page_button("list_films", page + 1)

# List series with pagination and cache
def list_series(page=1):
    cache_filename = f"series_page_{page}.json"
    cached_data = load_cache(cache_filename, expiration=86400)
    if cached_data:
        display_items(cached_data)
        add_next_page_button("list_series", page + 1)
        return

    current_url = f"{seriale_url}page/{page}/"
    xbmc.log(f"Accessing series page URL: {current_url}", level=xbmc.LOGINFO)

    response = requests.get(current_url)
    soup = BeautifulSoup(response.content, 'html.parser')
    series = soup.find('div', {'id': 'archive-content'}).find_all('article', class_='item tvshows')

    items = []
    for serie in series:
        title = serie.find('h3').text
        url = serie.find('a')['href']
        image_url = serie.find('img')['data-src']
        status = serie.find('span', class_='tobeornot').text
        description = get_series_description(url)

        items.append({"name": f"{title} [{status}]", "query": f"action=list_seasons&url={url}", "is_folder": True, "icon": image_url, "description": description})

    save_cache(items, cache_filename)
    display_items(items)
    add_next_page_button("list_series", page + 1)

# Function to display items in Kodi
def display_items(items):
    for item in items:
        add_directory_item(item["name"], item["query"], is_folder=item["is_folder"], icon=item.get("icon"), description=item.get("description"))
    xbmcplugin.endOfDirectory(addon_handle)

# Function to add "Next Page" button
def add_next_page_button(action, page):
    add_directory_item("Next Page", f"action={action}&page={page}", is_folder=True)

# Continue with season, episode listing, and play functions with caching for season and episode data
def extract_season_number(season_text):
    match = re.search(r'\bSezonul\s+(\d+)\b', season_text)
    return int(match.group(1)) if match else float('inf')

def list_seasons(url):
    cache_filename = f"seasons_{re.sub(r'[^a-zA-Z0-9]', '_', url)}.json"
    cached_data = load_cache(cache_filename, expiration=86400)
    if cached_data:
        display_items(cached_data)
        return

    xbmc.log(f"Accessing season URL: {url}", level=xbmc.LOGINFO)
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    seasons = soup.find('div', class_='content-season').find_all('article', class_='item season')

    items = []
    for season in sorted(seasons, key=lambda s: extract_season_number(s.find('h3').text)):
        season_title = season.find('h3').text
        season_url = season.find('a')['href']
        season_image_url = season.find('img')['src']
        items.append({"name": season_title, "query": f"action=list_episodes&url={season_url}", "is_folder": True, "icon": season_image_url})

    save_cache(items, cache_filename)
    display_items(items)

def extract_episode_number(episode_text):
    match = re.search(r'\bEpisodul\s+(\d+)\b', episode_text)
    return int(match.group(1)) if match else float('inf')

def list_episodes(url):
    cache_filename = f"episodes_{re.sub(r'[^a-zA-Z0-9]', '_', url)}.json"
    cached_data = load_cache(cache_filename, expiration=86400)
    if cached_data:
        display_items(cached_data)
        return

    xbmc.log(f"Accessing episode URL: {url}", level=xbmc.LOGINFO)
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    episodes_section = soup.find('div', class_='content-season')
    episodes = episodes_section.find_all('article', class_='item episodes') if episodes_section else []

    items = []
    for episode in sorted(episodes, key=lambda e: extract_episode_number(e.find('h3').text)):
        title = episode.find('h3').text.strip()
        episode_url = episode.find('a')['href']
        image_url = episode.find('img')['src']
        items.append({"name": title, "query": f"action=play_episode&url={episode_url}", "is_folder": False, "icon": image_url})

    save_cache(items, cache_filename)
    display_items(items)

# Functions for getting movie and series descriptions
def get_movie_description(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    wp_content = soup.find('div', class_='wp-content')
    return wp_content.find('p').text if wp_content else "Descriere indisponibilă."

def get_series_description(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    info_box = soup.find('div', id='info')
    description_tag = info_box.find('div', class_='wp-content').find('p') if info_box else None
    return description_tag.text if description_tag else "Descriere indisponibilă."

# Function to handle redirects
def follow_redirect(url, referer):
    headers = {'User-Agent': 'Mozilla/5.0', 'Referer': referer}
    response = requests.get(url, headers=headers)
    xbmc.log(f"Redirect final URL: {response.url}", level=xbmc.LOGINFO)
    return response.url

# Funcție pentru selectarea sursei video
def select_source(sources):
    source_labels = [f"{name}" for name, url in sources]
    selected_index = xbmcgui.Dialog().select("Alege sursa video", source_labels)
    if selected_index != -1:
        selected_source = sources[selected_index][1]
        xbmc.log(f"Sursa selectată: {selected_source}", level=xbmc.LOGINFO)
        if "iframe" in selected_source:
            selected_source = follow_redirect(selected_source, referer=base_url)
        resolved_url = urlresolver.resolve(selected_source)
        return resolved_url, extract_subtitle_url(selected_source)
    return None, None

# Funcție pentru extragerea URL-ului subtitrării
def extract_subtitle_url(video_url):
    parsed_url = urllib.parse.urlparse(video_url)
    query_params = urllib.parse.parse_qs(parsed_url.query)
    subtitle_url = query_params.get('c1_file', [None])[0]
    if subtitle_url:
        xbmc.log(f"Subtitrare găsită: {subtitle_url}", level=xbmc.LOGINFO)
    return subtitle_url

# Funcție generală pentru redarea videoclipurilor (filme și episoade)
def play_media(url):
    xbmc.log(f"Redare media la URL: {url}", level=xbmc.LOGINFO)
    sources = get_sources(url)  # Obține sursele video pentru url-ul furnizat (film sau episod)
    if sources:
        # Permite utilizatorului să selecteze sursa dorită
        selected_source, subtitle_url = select_source(sources)
        if selected_source:
            # Creează ListItem pentru redare și adaugă subtitrarea dacă există
            li = xbmcgui.ListItem(path=selected_source)
            if subtitle_url:
                li.setSubtitles([subtitle_url])
            xbmc.Player().play(selected_source, li)
        else:
            xbmc.log("Nicio sursă validă selectată sau redirecționare eșuată.", level=xbmc.LOGERROR)
    else:
        xbmc.log("Nu s-au găsit surse video pentru acest conținut.", level=xbmc.LOGERROR)

# Funcție pentru obținerea surselor video pentru un episod
def get_episode_sources(url):
    xbmc.log(f"Obținerea surselor video pentru episodul: {url}", level=xbmc.LOGINFO)
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')

    # Extragem movie-id din atributul 'movie-id' al div-ului show_player_lazy
    movie_id_tag = soup.find('div', {'id': 'show_player_lazy'})
    if not movie_id_tag or 'movie-id' not in movie_id_tag.attrs:
        xbmc.log("Nu s-a găsit movie-id pentru acest episod.", level=xbmc.LOGERROR)
        return None

    movie_id = movie_id_tag['movie-id']
    headers = {
        "referer": url,
        "x-requested-with": "XMLHttpRequest",
    }
    payload = {
        "action": "lazy_player",
        "movieID": movie_id,
    }

    post_response = requests.post(f"{base_url}wp-admin/admin-ajax.php", headers=headers, data=payload)
    post_soup = BeautifulSoup(post_response.content, 'html.parser')

    sources = []
    options = post_soup.find_all('li', class_='dooplay_player_option')
    for option in options:
        source_url = option['data-vs']
        source_name = option.get_text(strip=True)
        sources.append((source_name, source_url))

    return sources

# Funcție generală pentru obținerea surselor video
def get_sources(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    movie_id_tag = soup.find('div', {'id': 'show_player_lazy'})
    if not movie_id_tag:
        xbmc.log("ID-ul filmului sau episodului nu a fost găsit", level=xbmc.LOGERROR)
        return None

    movie_id = movie_id_tag['movie-id']
    return get_sources_from_ajax(movie_id, url)

# Funcție pentru extragerea surselor video din playeroptions
def extract_video_sources(response_text):
    soup = BeautifulSoup(response_text, 'html.parser')
    sources = []
    player_options = soup.find('div', id='playeroptions')
    if player_options:
        for option in player_options.find_all('li', class_='dooplay_player_option'):
            source_url = option['data-vs']
            source_name = option.find('span').text
            sources.append((source_name, source_url))
            xbmc.log(f"Sursa video disponibilă: {source_name} - {source_url}", level=xbmc.LOGINFO)
    return sources

# Funcție comună pentru obținerea surselor video de la admin-ajax.php
def get_sources_from_ajax(movie_id, ref_url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Origin': base_url,
        'Referer': ref_url,
        'X-Requested-With': 'XMLHttpRequest'
    }
    data = {
        'action': 'lazy_player',
        'movieID': movie_id
    }
    video_response = requests.post(f"{base_url}wp-admin/admin-ajax.php", headers=headers, data=data)
    if video_response.status_code == 200:
        return extract_video_sources(video_response.text)
    else:
        xbmc.log("Nu s-a putut obține sursa video", level=xbmc.LOGERROR)
        return []

# Funcție pentru căutare
def search(query=None, page=1):
    if not query:
        # Solicităm input utilizatorului pentru termenul de căutare
        keyboard = xbmc.Keyboard('', 'Introduceți termenul de căutare')
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
        else:
            return  # Ieșire dacă nu a fost introdus nimic

    search_url = f"{base_url}?s={urllib.parse.quote(query)}&page={page}"
    xbmc.log(f"Accesare URL pentru căutare: {search_url}", level=xbmc.LOGINFO)

    response = requests.get(search_url)
    soup = BeautifulSoup(response.content, 'html.parser')
    results = soup.find('div', {'class': 'search-page'}).find_all('article', class_=['item', 'movies', 'tvshows'])

    for result in results:
        title = result.find('h3').text
        url = result.find('a')['href']
        image_url = result.find('img')['src']
        category = "movies" if "movies" in result['class'] else "tvshows"
        status = result.find('span', class_='qualityy' if category == 'movies' else 'tobeornot').text

        # Add as playable item if it is a movie, or list episodes if it's a series
        if category == "movies":
            description = get_movie_description(url)
            add_directory_item(
                name=f"{title} [{status}]",
                query=f"action=play&url={url}",
                is_folder=False,
                icon=image_url,
                description=description
            )
        elif category == "tvshows":
            description = get_series_description(url)
            add_directory_item(
                name=f"{title} [{status}]",
                query=f"action=list_seasons&url={url}",
                is_folder=True,
                icon=image_url,
                description=description
            )

    # Add a "Next Page" button for pagination if there are more results
    add_directory_item(
        name="Next Page",
        query=f"action=search&query={urllib.parse.quote(query)}&page={page + 1}",
        is_folder=True
    )

    xbmcplugin.endOfDirectory(addon_handle)

# Router pentru a gestiona acțiunile
def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    if params:
        if params['action'] == 'list_films':
            page = int(params.get('page', 1))  # Default to page 1 if not specified
            list_films(page=page)
        elif params['action'] == 'list_series':
            page = int(params.get('page', 1))  # Default to page 1 if not specified
            list_series(page=page)
        elif params['action'] == 'list_seasons':
            list_seasons(params['url'])
        elif params['action'] == 'list_episodes':
            list_episodes(params['url'])
        elif params['action'] == 'play':
            play_media(params['url'])  # Înlocuiește play_video cu play_media
        elif params['action'] == 'play_episode':
            play_media(params['url'])  # Înlocuiește play_episode cu play_media
        elif params['action'] == 'search':
            query = params.get('query')
            page = int(params.get('page', 1))
            search(query=query, page=page)
    else:
        main_menu()

if __name__ == '__main__':
    router(sys.argv[2][1:])
