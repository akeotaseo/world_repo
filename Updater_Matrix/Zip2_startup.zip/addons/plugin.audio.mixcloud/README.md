# KODI Mixcloud Plugin

### Developer:
  - jackyNIX

### Contributors:
  - Bochi
  - SilentException
  - fleshgolem
  - gordielachance
  - understatement
  - peat80
  - ronan-ln

### Current version: 
  3.0.3
  - Nexus

### Features:
  - Profile
    - Followings
    - Followers
    - Favorites
    - History
    - Uploads
    - Listen later
    - Playlists
  - Browse
    - Categories
  - Search
    - Cloudcasts
    - Users
    - Search history
  - Play cloudcasts
    - Mixcloud resolver
    - Offliberty resolver
    - Mixcloud-Downloader resolver (broken)
  - Thumbnails
  - History
    - Profile
    - Local
  - Localisation
    - English
    - Dutch
    - French
    - German
