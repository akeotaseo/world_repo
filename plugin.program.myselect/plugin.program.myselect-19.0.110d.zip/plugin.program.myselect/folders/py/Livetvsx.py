import xbmc, xbmcgui



def Livetvsx():
    funcs = (click_1, click_2, click_3, click_4, click_5)
    call = xbmcgui.Dialog().select('[B][COLOR=blue]      Livetv[/COLOR][/B][B][COLOR=red]sx[/COLOR][/B]',
['[COLOR=white]Live TV[/COLOR] [COLOR=grey](sd)[/COLOR]',


 '[COLOR=white]Live TV[/COLOR] [COLOR=purple](vstream)[/COLOR]',

 '[COLOR=white]RojLive TT[/COLOR] [COLOR green](Dracarys)[/COLOR]',

 '[COLOR=white]Live TV[/COLOR] [COLOR silver](apex_sports)[/COLOR]',



 '[B][COLOR red]<---                                                                      [COLOR grey]Back[/COLOR][/B]'
 ])







    if call:
        if call < 1:
            return
        func = funcs[call-5]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsdevil/?item=title%3dLiveTV.ru%26director%3dLiveTV.ru%26icon%3dC%253A%255CPortableApps%255Ckodi%255Ckodi%2bWorld%2b21%255CKodi%255Cportable_data%255Caddons%255Cplugin.video.sportsdevil%255Cresources%255Cimages%255Clivetv_ru.png%26url%3dlivesports%252Flivetv.ru.cfg%26type%3drss%26genre%3dLive%2bSports%26definedIn%3dlivesports.cfg&mode=1")')


def click_2():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vstream/?function=showMovies&sFav=showMovies&site=livetv&siteUrl=%2ffrx%2fallupcoming%2f&title=Live%20TV")')
def click_3():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dracarys/?category=live_sport&mode=open_site&site=livetv")')


def click_4():
    
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.apex_sports/?category=live_sport&mode=open_site&site=livetv")')



def click_5():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/Live_Now.py")')
Livetvsx()
