import xbmc, xbmcgui
xbmcgui.Dialog().notification("[COLOR orange]Προτιμήσεις Ταινίες[/COLOR]", "Ανακατεύθυνση...", sound=False, icon='special://home/addons/plugin.program.mypreferences/icon.png')

xbmc.executebuiltin('ActivateWindow(10000)')
xbmc.sleep(4000)
xbmc.executebuiltin('Dialog.Close(all,true)')
xbmc.sleep(500)
xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.program.mypreferences/?label=1.TAINIES TV&mode=400&path=special%3A%2home%2Fuserdata%2Faddon_data%2Fplugin.program.mypreferences%5C1.TAINIES")')
