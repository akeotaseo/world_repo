# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Sourced From Online Templates And Guides
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Thanks To: Google Search For This Template
# modified by: MUSICHALL
#------------------------------------------------------------

import os
import sys
PY3 = sys.version_info[0] >= 3
'''
if ( PY3 ):
	import plugintools_3
else:
	import plugintools_2
'''
import plugintools
import xbmc,xbmcaddon
#from addon.common.addon import Addon


addonID = 'plugin.video.musichall'
#addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_search = "plugin://plugin.video.youtube/kodion/search/list/" 
YOUTUBE_playlist_ID_1 = "PLSyCRkPeE-W0Yd6UutqVt7jKgsrSWwBnc" 
YOUTUBE_playlist_ID_01 = "PLSyCRkPeE-W0pV49lqXA5Pe-VlA19sgyD"   
YOUTUBE_playlist_ID_2 = "PLSyCRkPeE-W26b_hGZIoO7XfsH3licNU2" 
YOUTUBE_playlist_ID_02 = "PLSyCRkPeE-W3vNKwXAkFnjOACpxSpVJ_2"   
YOUTUBE_playlist_ID_3 = "PL4o29bINVT4EG_y-k5jGoOu3-Am8Nvi10"    
YOUTUBE_playlist_ID_4 = "PLMC9KNkIncKtPzgY-5rmhvj7fax8fdxoj"    
YOUTUBE_playlist_ID_5 = "PLe_mU5sgHnNTzIMMSz7JsyXLFDcrMW0Ep"    
YOUTUBE_playlist_ID_6 = "PLB8HqqmpyIBcPirb5lDm-ol01trE6dOuM"   
YOUTUBE_playlist_ID_7 = "PL3485902CC4FB6C67"    
YOUTUBE_playlist_ID_8 = "PLZN_exA7d4RVmCQrG5VlWIjMOkMFZVVOc"   
YOUTUBE_playlist_ID_9 = "PLhd1HyMTk3f5PzRjJzmzH7kkxjfdVoPPj"    
YOUTUBE_playlist_ID_10 = "PL6Lt9p1lIRZ311J9ZHuzkR5A3xesae2pk" 
YOUTUBE_playlist_ID_11 = "PL_86NZWyc0FsJF98CRytnzItb5EXMQOne"  
YOUTUBE_playlist_ID_12 = "PL7dWoRZfPDhp9Zh9hGlAM6uYn7QYz9zE-"   
YOUTUBE_playlist_ID_13 = "PLT97TNIfVc4k6u4vhaUHlnejTwnCuCBCe"  
YOUTUBE_playlist_ID_14 = "PL7dWoRZfPDhp9Zh9hGlAM6uYn7QYz9zE-"  
YOUTUBE_playlist_ID_15 = "PL4XLEC-MUq2uP2OhrGWdOErGUDrEquhqi"  
YOUTUBE_playlist_ID_16 = "PLOuAaPDGy5br7qCO28VX5AzTq4_hmGKDX"  
YOUTUBE_playlist_ID_17 = "PLo3pNg0eiPc_jQ_jhD8P4UoiOE6vmGdU6"  
YOUTUBE_playlist_ID_18 = "PLdS6GqghzS68QVNnOSU2_MSmTFbeLLMjp"  
YOUTUBE_playlist_ID_19 = "PLSYbV1H4VkCcHi33SC1mldSDi8vrYlfCm"   
YOUTUBE_playlist_ID_20 = "PL1av4CQniLB0dk5LnfWQhBUcRlzo2jBYB"   
YOUTUBE_playlist_ID_21 = "PLFE06A24F924AADB0"   
YOUTUBE_playlist_ID_22 = "PLw6p6PA8M2miu0w4K1g6vQ1BHUBeyM4"   
YOUTUBE_playlist_ID_23 = "PLNjVKDn-Jmf6MJ56EPkd0qtYjml3nkQ4X"  
YOUTUBE_playlist_ID_24 = "PL11Wnnyw47LpkF3McMjHwG0HZ23CcfYUX"  
YOUTUBE_playlist_ID_25 = "PLD15AF3F721D9841B"  
YOUTUBE_playlist_ID_26 = "PLA_I2ay5YcUUKiZshI4cgp9fTOS-Q6B1E"  
YOUTUBE_playlist_ID_27 = "PLGUwEHGA8vYx5f9h7kBX-7ajQ4l2dz5Np"  
YOUTUBE_playlist_ID_28 = "PLz1LeT5FVsBsZYX2J5yhW8tHuTsRdlAKb"  
YOUTUBE_playlist_ID_29 = "PL3eLsFJDQqDeoCf4U6v4WqJpIem9wPsuB"   
YOUTUBE_playlist_ID_30 = "PL3OPG8Q1fcHfckwr3RJjEFdC17plumnrk"   
YOUTUBE_playlist_ID_31 = "PL0cR6Rwd6cZ_NFddNfqUY9Pr-tdua1hH-"   
YOUTUBE_playlist_ID_32 = "PLdSAKz5rcwnzE7ahB8I1B1uf32ZcAA4Xp"  
YOUTUBE_playlist_ID_33 = "PL54835teYYB6TXx0j37rArlHeS2Nzi9Fw"  
YOUTUBE_playlist_ID_34 = "PLVwXkzK42QWpYvaIk_g7RpNyN0v_mDys1"   
YOUTUBE_playlist_ID_35 = "PLg0miFvQna78NnuHxMGgGomvhx7AzPsrq"  
YOUTUBE_playlist_ID_36 = "PLcM4ZwI542CriszmMjt8HSOJ-dVzKo3O3"   
YOUTUBE_playlist_ID_37 = "PL20422B75F11401A9"  
YOUTUBE_playlist_ID_38 = "PLC90FB71F6ECE17F3"  
YOUTUBE_playlist_ID_39 = "PL08MW4hWrm0IgjVeAiyONMnXGi6XIXX_8" 
YOUTUBE_playlist_ID_40 = "PLFB42B657AC475437"   
YOUTUBE_playlist_ID_41 = "PLi7ihgkEws7S0Dwxxyxb7SJyd2FU5VaoX"  
YOUTUBE_playlist_ID_42 = "PL4ED12F0E006F3FB5"  
YOUTUBE_playlist_ID_43 = "PLH3uWI-RMnujGh1_eWrxjeJlOs8LsFW2a"  
YOUTUBE_playlist_ID_44 = "PLUB47gDSghxHXzrES8stEO1IoUWNaDtjo"   
YOUTUBE_playlist_ID_45 = "PLoc2h0J0pKbjKURh9b0XGfHkMMQIEqx3j"  
YOUTUBE_playlist_ID_46 = "PLMdr_HKbn4ph0bMRzVkPdiLtPLC0xwHQv"  
YOUTUBE_playlist_ID_47 = "PLkqz3S84Tw-TgiHX8wa-bFAscdC-0pe1k"  
YOUTUBE_playlist_ID_48 = "PLlD0ifA9koz8HDvUpo3gE63iNYC_GPp4i"   
YOUTUBE_playlist_ID_49 = "PLSYbV1H4VkCcF4nR9pimgJl9n2YCtiJCm"  
YOUTUBE_playlist_ID_50 = "PLxI6IWh7Z6boU_sZm25NTBxPI2tS5ODko"  
YOUTUBE_playlist_ID_51 = "PL8F6B0753B2CCA128"  
YOUTUBE_playlist_ID_52 = "PL2140A0411C65DD13"   
YOUTUBE_playlist_ID_53 = "PLPbMT4wSxX88oU7uYThLcvUI98PUp1bQ2"   
YOUTUBE_playlist_ID_54 = "PLSYbV1H4VkCeCiimiKQ7VijAAHiDoE134"  
YOUTUBE_playlist_ID_55 = "PLTC7VQ12-9rZRMqzpt9t69WxbcBBcMA5N"  
YOUTUBE_playlist_ID_56 = "PLYAYp5OI4lRLf_oZapf5T5RUZeUcF9eRO"   
YOUTUBE_playlist_ID_57 = "PLOzQFWHEFankpJykvzRJ6W5mF81ojL9I5"   
YOUTUBE_playlist_ID_58 = "PLinS5uF49IBrTL7y97OOWRilvdv9RCtD5"  
YOUTUBE_playlist_ID_59 = "PLk-_AvR22RueziRgt5GVuirih223y1UNJ"  
YOUTUBE_playlist_ID_60 = "PLxhnpe8pN3TmtjcQM7zcYAKhQXPdOHS3Y"   
YOUTUBE_playlist_ID_61 = "PL_htyEpQ9NirGqcnTjexvkL1FgdAb1DIP"  
YOUTUBE_playlist_ID_62 = "PLKl-ToKj7DF79wPmya9szDKHU548iKw7N"   
YOUTUBE_playlist_ID_63 = "PLwY9l4M25GOJqIx-Dn-PmYs1KjPd80-1N"  
YOUTUBE_playlist_ID_64 = "PLYVjGTi85afrX2JuWV2_ylym4ykyguiSn"   
YOUTUBE_playlist_ID_65 = "PLuIIZwlpW-BDRwb_Djx47oKDPwSTo37il"  
YOUTUBE_playlist_ID_66 = "PLZ_Hv3CS1vLczLHKKZ-k-YAtt_BocRXjl"  
YOUTUBE_playlist_ID_67 = "PLUTHONkXwksFV41KpZRHS0g7wAUsXNWi1"   
YOUTUBE_playlist_ID_68 = "PLoSFsEOMUSmvu78SR8lpN9qPfhcWlJoh4"  
YOUTUBE_playlist_ID_69 = "PL5xAy4Ufl2T7W9KJHMIZ1zsyeKxFWF1WI"  
YOUTUBE_playlist_ID_70 = "PL6E0fb5idtvomtP6HmaXrIxQM_5dq1Ich"  
YOUTUBE_playlist_ID_71 = "PLA_I2ay5YcUVJbVT8tb-cZQ6pGJHWlnHH"  
YOUTUBE_playlist_ID_72 = "PLSYbV1H4VkCclm8e7Aa3eWFOv6fo7FA_N"   
YOUTUBE_playlist_ID_73 = "PL7D7DF7BCD7BB6397"  
YOUTUBE_playlist_ID_74 = "PLa0YPE0ViQnTWP80UMzn7cVVwuQDijNmf"   
YOUTUBE_playlist_ID_75 = "PLq3UZa7STrbq6UOCFWEHDCbJTgCzSJOqp"  
YOUTUBE_playlist_ID_76 = "PL1A37E3EDA9CEA8D8"   
YOUTUBE_playlist_ID_77 = "PL9mzuSwws3ukqDOPHXTWT92wUJalcg00f"  
YOUTUBE_playlist_ID_78 = "PLXl9q53Jut6nqEPU4yf1F4FTDeQpe32RU"   
YOUTUBE_playlist_ID_79 = "PLK43LLsFwaZl5st2nzGGTimDPmSsngmrY"  
YOUTUBE_playlist_ID_80 = "PLA_I2ay5YcUV2lA5AgUvJZIh-1z0k4s0U" 
YOUTUBE_playlist_ID_81 = "PL3io0GaKtmBZH3DStmaT_2ausUWfA205A"  
YOUTUBE_playlist_ID_82 = "PL64G6j8ePNur3kXmRujUMAJBqcIf3Ru_L"  
YOUTUBE_playlist_ID_83 = "PL26411A62E4BD430F"  
YOUTUBE_playlist_ID_84 = "PLJu1mQyIUo9vv7pr-_kAJhw8Zq7EpWnlC"   
YOUTUBE_playlist_ID_85 = "PL3FGWwglq6wYrwFDDqVVhZMhWsGJyKxxS"   
YOUTUBE_playlist_ID_86 = "PL6ll17AuXo1LdCKcxyVUPKmcWpASnHbAE"  
YOUTUBE_playlist_ID_87 = "PLX5GPCxRpKOSYvZ864eNlH_q5IStw3fBq"   
YOUTUBE_playlist_ID_88 = "PLSYbV1H4VkCczQ9RIAjx_0EZunWjDB6xy"   
YOUTUBE_playlist_ID_89 = "PL7VzovHQUUKo0dOMY90BdBhJGVYlU1BfY"  
YOUTUBE_playlist_ID_90 = "PLxT_qtS_HofDRJpNAuruxYJ7eXQ17MMfD"  
YOUTUBE_playlist_ID_91 = "PLQkQfzsIUwRYxu4vbVopqbcuudw0G1R2e"   
YOUTUBE_playlist_ID_92 = "PLCHaaulQJI-ys37w4ctXmDboYBWoF1mmm"  
YOUTUBE_playlist_ID_93 = "PLm7wnjUQm_FAMNxPGqLKZnuu5PAMhHkb-" 
YOUTUBE_playlist_ID_94 = "PLw6p6PA8M2miu0w4K1g6vQ1BHUBeyM4_-" 
YOUTUBE_playlist_ID_95 = "PLvLB0DOy9-LdCFQPgiizgdLcd0Vxfb4h1"   
YOUTUBE_playlist_ID_96 = "PLEegDkopZ-SrsOX75F__4rdER10UYFH8H"   
YOUTUBE_playlist_ID_97 = "PL84EC9ACDAF6B300C"  
YOUTUBE_playlist_ID_98 = "PL2E6D867EB67A3481" 
YOUTUBE_playlist_ID_99 = "PLA_I2ay5YcUUKiZshI4cgp9fTOS-Q6B1E"   
YOUTUBE_playlist_ID_100 = "PLeC7VLq1hoVxXVp5Lzu9LyMppHSq5koXw"  
YOUTUBE_playlist_ID_101 = "PLnOSH5j1sQh_y5ig-oAjet8VrsQnYnY9P"   
YOUTUBE_playlist_ID_102 = "PL9KifGoS3P-TWwlbEx7OYjstrBHgpdm7z"  
YOUTUBE_playlist_ID_103 = "PL3B47D2B724FD4824"  
YOUTUBE_playlist_ID_104 = "PLukp_BtPsQyUdtHQOYvbCESjXu73Mc2Pd"  
YOUTUBE_playlist_ID_105 = "PLJmzdqLGl_E7CbbYpSgH3Gi-rZyvgxr-6"   
YOUTUBE_playlist_ID_106 = "PLhEeP9J9zuhQxeDJhV-5wWEkqzWQpLZK8"  
YOUTUBE_playlist_ID_107 = "PLC-4Xib-LOrcAzmtQmQTI1ofQajX3Lapr"   
YOUTUBE_playlist_ID_108 = "PLFgm_LJYNEttRTuvpr2qnZ3n697sWcHli"  
YOUTUBE_playlist_ID_109 = "PLzkJGO1JtnC7dI3u-LeREsxuJPiAjJimm"  
YOUTUBE_playlist_ID_110 = "PLBA986EF6C0FAA1D9"  
YOUTUBE_playlist_ID_111 = "PLVQ2GDDQBo9UFH9gPlAmEaMDmY6YsbANf"   
YOUTUBE_playlist_ID_112 = "PL388C6956B2EE2189"   
YOUTUBE_playlist_ID_113 = "PL370681250BF00BC3"  
YOUTUBE_playlist_ID_114 = "PL_XY-y6Et_zw1LyZn8hoSGLfmQ5n5QTKn"   
YOUTUBE_playlist_ID_115 = "PLmo4pBukfRoN8SB5RKvfiY9CTl9pI_IFc"   
YOUTUBE_playlist_ID_116 = "PLabJQI0gItOgdGnnxZ5cnww8zYVYSblNH"  
YOUTUBE_playlist_ID_117 = "PL91801CA691D86F9B"   
YOUTUBE_playlist_ID_118 = "PL5D52CC59B62A204A"  
YOUTUBE_playlist_ID_119 = "PL4QNnZJr8sRNKjKzArmzTBAlNYBDN2h-J"  
YOUTUBE_playlist_ID_120 = "PLwWVOy05xAK-px3Z5tWq3NV_5Qp0AEk6b"  
YOUTUBE_playlist_ID_121 = "PLt0efFL_7wt-O5zIYMNphKfGPQi6P9DUt"  
YOUTUBE_playlist_ID_122 = "PLNRm4Qyy2MDWV2xY_K_7kUzcCcv8yrBJg"  
YOUTUBE_playlist_ID_123 = "PLX9U3Rv7Wy7Wbi3iV2uxFo8BOVHjIehUc"   
YOUTUBE_playlist_ID_124 = "PLSRh2BX6ao7P7E0KVcyZ-rYqhTaVVoZrW"   
YOUTUBE_playlist_ID_125 = "PL0C258FE8916ECCB1"   
YOUTUBE_playlist_ID_126 = "PLmS86t_jmQvbpeehASz2Tosvj7d1VN-ZE"  
YOUTUBE_playlist_ID_127 = "PLSt6PZ2gsMLLa4kUHAJxEqaiBzv6lKp4v"  
YOUTUBE_playlist_ID_128 = "PLnUDHJz-31cHA_wlL6dx2mtS23_iqQBGj"   
YOUTUBE_playlist_ID_129 = "PLic91mhoPnxHgzij9We-plBNJo3j1rd8B"   
YOUTUBE_playlist_ID_130 = "PLFR04WQ_ARyQ-xzAX1dJXOUEdsHM9Sr"   
YOUTUBE_playlist_ID_131 = "PLIVbZhwLbExKoDlYntZV_Y1c3bZYz7hAs"   
YOUTUBE_playlist_ID_132 = "PLsC90_43kf5UB_wuLYrtRLG-J8YAPgMCh"  
YOUTUBE_playlist_ID_133 = "PLyUKaKIB05bQuG4s7AgxZ7-j04Ct_Nw82"  
YOUTUBE_playlist_ID_134 = "PLlYKDqBVDxX0Qzmoi2-vvHJjOAy3tRPQ_"   
YOUTUBE_playlist_ID_135 = "PLGBuKfnErZlDI1LRP7ANgsa09x0CrIT6b"   
YOUTUBE_playlist_ID_136 = "PL6EF50C0B0EE0394B"   
YOUTUBE_playlist_ID_137 = "PLcUqPeI0P9OzpYK1UBbeAApBHkEXONi5K"   
YOUTUBE_playlist_ID_138 = "PLyORnIW1xT6wBFoOxTh__8a3dFzbgHYrw"   
YOUTUBE_playlist_ID_139 = "PL1dawt09wsD2gWUa25VF-o2VM8xFisn9r"  
YOUTUBE_playlist_ID_140 = "PLJd7utaEK5kCa1WNGqAFKxgf0MLVegthK"   
YOUTUBE_playlist_ID_141 = "PLmdwo0nDs2HnT8BlW8MuPJ9a9xthJjOvo"   
YOUTUBE_playlist_ID_142 = "PLqc7q6_aVtEedhZhephOsn3lYeoGTdb45"   
YOUTUBE_playlist_ID_143 = "PLDIoUOhQQPlXr63I_vwF9GD8sAKh77dWU"   
YOUTUBE_playlist_ID_144 = "PL1C555E0FCE0DE629"   
YOUTUBE_playlist_ID_145 = "PLqGkpApxFsX_jRp4sDFz9_gwztqqpDZ2U"   
YOUTUBE_playlist_ID_146 = "PL47423FF1E03177A8"   
YOUTUBE_playlist_ID_147 = "PLGtW_kt2Ks8Kv1dBqJjTVlCOBVBN0jR2x"   
YOUTUBE_playlist_ID_148 = "PLaLWNpJCbH_r_0jG3o4r_kUtLB1gUFUdX"  
YOUTUBE_playlist_ID_149 = "PLyjgHc47unfT3BIZo5uEt2a-2TWKy54sU"  
YOUTUBE_playlist_ID_150 = "PLyDDMmF7xacYISTUmhO3bW1A5eaTqqQLU"   
YOUTUBE_playlist_ID_151 = "PLI_7Mg2Z_-4IzxbySOWX5xNT7vDV2HCgG"   
YOUTUBE_playlist_ID_152 = "PLgP_WFDJWjxSgClOt0zBSwiofDIbTLjFj"   
YOUTUBE_playlist_ID_153 = "PL0Ea63JLhmBZFPgxGlOa_QqnR02YYIbxj"   
YOUTUBE_playlist_ID_154 = "PLT0PWRx_9kWsZNX5Rgf8DDFcyAu-zP7C9"   
YOUTUBE_playlist_ID_155 = "PLD58ECddxRngHs9gZPQWOCAKwV1hTtYe4" 
YOUTUBE_playlist_ID_156 = "PLcUqPeI0P9OzpYK1UBbeAApBHkEXONi5K"   
YOUTUBE_playlist_ID_157 = "PLnMN8r-C6UXvv4G6u_MlUoyHLSV2pExKt"   
YOUTUBE_playlist_ID_158 = "PLFoFu8Ubv_K9xY_uhIgPlTCE9YJTeD7Yv"   
YOUTUBE_playlist_ID_159 = "PL539EAB0AAC7115D6"   
YOUTUBE_playlist_ID_160 = "PLVyGBw9rxZW5TdmxxIcbFdwIvDzL9hmTv"
YOUTUBE_playlist_ID_161 = "PLSrd6av4d9FB38oJzinkYo8pKKy75BB75"   
YOUTUBE_playlist_ID_162 = "PL1391237437761842"   
YOUTUBE_playlist_ID_163 = "PLFNoV4a_DdP9B7nKmHzai4ISsN2eqE8qd"   
YOUTUBE_playlist_ID_164 = "PL6F2E55E6C55E3D5C"   
YOUTUBE_playlist_ID_165 = "PL00406755CBB598E4"
YOUTUBE_playlist_ID_166 = "PLop8VH45f9THwLpL0k5E0YJLK6OJRVAzX"   
YOUTUBE_playlist_ID_167 = "PLp5Ie3eol3uMHxW3X2Hai286cbRz9Ieox"   
YOUTUBE_playlist_ID_168 = "PLUFcxlFae4DnP9NIQQ5LQLg4Mx7gwg3XS"   
YOUTUBE_playlist_ID_169 = "PLkpBMluoHSysEDsA9EqpuUSrCHonWYTCx"   
YOUTUBE_playlist_ID_170 = "PLE95D2AF80B98128A"
YOUTUBE_playlist_ID_171 = "PLrnf2axPSKTczDHyYHh1IjNwRdBsqtNUc"   
YOUTUBE_playlist_ID_172 = "PLEXox2R2RxZJwar7F90A4myvLFaNnAbF8"   
YOUTUBE_playlist_ID_173 = "PL1s6OeN3vk7tizc6Aw_X9E41KB0rMZaun"   
YOUTUBE_playlist_ID_174 = "PLgP_WFDJWjxTRPJtV4DV99lGB92rq5we_"   
YOUTUBE_playlist_ID_175 = "PLLDlq9PuU6JfoK6hgy1dmGMdfRLjs8CsJ"
YOUTUBE_playlist_ID_176 = "PL463FB203BC5D8EC5"   
YOUTUBE_playlist_ID_177 = "PL8C21E6E62BC8A8A5"   
YOUTUBE_playlist_ID_178 = "PL1z-GMlijJafEHDMomXf6XOZGI5t1F5MW"   
YOUTUBE_playlist_ID_179 = "PLu9Vz-S8dcTFRigm63_S_bIQ3z_NvdOX9"   
YOUTUBE_playlist_ID_180 = "PLovpXliBbRss40lCvrKevsLcWgcE-xuZM"   
YOUTUBE_playlist_ID_181 = "PL366DECE00BAB19C3"   
YOUTUBE_playlist_ID_182 = "PL8VbTOsQGdVX1Tudt0UOPXmHVwiNIM65z"   
YOUTUBE_playlist_ID_183 = "PL4gRHIfKL8DQya0XJzTkvBCFfklFpEWBd"   
YOUTUBE_playlist_ID_184 = "PL57F368ABE19E6FF2"   
YOUTUBE_playlist_ID_185 = "PLj9Qm0ntwRlIkVaCDDkJu4GZViNmL6Fhl"   
YOUTUBE_playlist_ID_186 = "PL12A5B8B4A1F506DB"
YOUTUBE_playlist_ID_187 = "PL15DB3F186EC6E958"   
YOUTUBE_playlist_ID_188 = "PLRgFSnfiHYbISNOAmZaTuycFRBC8gLguz"   
YOUTUBE_playlist_ID_189 = "PLMEZyDHJojxOOz4VZh2Gt5QQaK8bAxQlM"   
YOUTUBE_playlist_ID_190 = "PLpMUJrYyZ562siCuou1Yh-99IhCgmXFAE"   
YOUTUBE_playlist_ID_191 = "PLAE767E2C26EB00D0"   
YOUTUBE_playlist_ID_192 = "PLRIBrCahDV_OEFbTncTT07nFscbBjdBNz"   
YOUTUBE_playlist_ID_193 = "PLllUJyv_BmsswsoCB35HGvZdIDgvpyX-9"   
YOUTUBE_playlist_ID_194 = "PL0584DD2033D1086E"   
YOUTUBE_playlist_ID_195 = "PL9CE015AC978E88FE"   
YOUTUBE_playlist_ID_196 = "PL7E0B0B126525E358"   
YOUTUBE_playlist_ID_197 = "PLeC3KXKbXai6aTB6cU9em_7GRkFg7juDg"   
YOUTUBE_playlist_ID_198 = "PLC0DD13A1FB960F3B"   
YOUTUBE_playlist_ID_199 = "PLA9iOvQBvAVku6TCer7bVojGprtMK2vt7"   
YOUTUBE_playlist_ID_200 = "PLC440F892363574D8" 
YOUTUBE_playlist_ID_201 = "PLrKtgKTQpf4N-SgnWulfsb2t_a7_hAQLz"   
YOUTUBE_playlist_ID_202 = "PLH22-xSMERQpEWdqQbcaCP0kNutOr1Az8"   
YOUTUBE_playlist_ID_203 = "PL_imCSk1tVkrvmt9sRXjC0qNAWHfMTd2S"   
YOUTUBE_playlist_ID_204 = "PLAAB4A49331A7D7E7"   
YOUTUBE_playlist_ID_205 = "PL0LafXFmvfJxn4Dj-NlP3lKa_WBXE1b9u"   
YOUTUBE_playlist_ID_206 = "PL1D3254DC1A2192DB"   
YOUTUBE_playlist_ID_207 = "PLgpb1OoASakpNUwnJyUbbHtOwDWEg3F6"   
YOUTUBE_playlist_ID_208 = "PLED03B2E1FC47994B"   
YOUTUBE_playlist_ID_209 = "PLZJclMlxrlQjZbdnrfdHnybQkfcxuYrrv"   
YOUTUBE_playlist_ID_210 = "PLtgmCD5wbB8NGQQ5Qqth9uWIvvgpvHV4n"   
YOUTUBE_playlist_ID_211 = "PLB88AE4A3A7B45DB8"
YOUTUBE_playlist_ID_1331 = "PL5BNaoYrNzWOPFmlg5F7TA9mFVn42RSER"
YOUTUBE_playlist_ID_212 = "PLVMTgzzMzyq_PidMRACn-ifykQxR4IlUR"   
YOUTUBE_playlist_ID_213 = "PL79E4245F0137AA18"   
YOUTUBE_playlist_ID_214 = "PL6CD0C8E936F9D2B1"   
YOUTUBE_playlist_ID_215 = "PLE572452B578F4B90"   
YOUTUBE_playlist_ID_216 = "PL702C290EA963E487"   
YOUTUBE_playlist_ID_217 = "PLfWVgaByq8qnE-XgmxPaa_F0uEsbex_mv"   
YOUTUBE_playlist_ID_218 = "PLcWc2gCo2k_b22siNj8Mueh8IGCwB1SlJ"   
YOUTUBE_playlist_ID_219 = "PL5B408043A1CBA476"   
YOUTUBE_playlist_ID_220 = "PLVgGT_m10yKIIcafib3W7rSDYLxQMgBMB"   
YOUTUBE_playlist_ID_221 = "PLriE5FcoFSQ5Xd-cz_qVpFuxCMIzAQ3l8"   
YOUTUBE_playlist_ID_222 = "PLZNjddY6GSNMONX0iQvtAff3w5B5hSYpU"   
YOUTUBE_playlist_ID_223 = "PLA50904415C9A55C7"   
YOUTUBE_playlist_ID_224 = "PLbfluqsV6sopOQ-6UUBR84LH5CJOJ-Qrj"   
YOUTUBE_playlist_ID_225 = "PLniulnHY2D_tc_BMPmhWFpOSKO0DL1KyC" 
YOUTUBE_playlist_ID_226 = "PL3C91B863301E250F"   
YOUTUBE_playlist_ID_227 = "PL574FBF341B72DAD5"   
YOUTUBE_playlist_ID_228 = "PLZEQ-5ryd32SZE2qS_9vHcUy64j-VNvBI"   
YOUTUBE_playlist_ID_229 = "PLvz78UNxtDruCicAvERgXFk2XVgiBn_4y"   
YOUTUBE_playlist_ID_230 = "PLCD354CC986E6EEFB"   
YOUTUBE_playlist_ID_231 = "PLgO5hdZN3QEezisE8Yh8DoLo7AKa7iU5V"   
YOUTUBE_playlist_ID_232 = "PLaLEDUEJDVW7v9K_DVjh0Ztr3xStkusFd"   
YOUTUBE_playlist_ID_233 = "PLC787958DD0D029F7"   
YOUTUBE_playlist_ID_234 = "PLIhLN7Z5xAvFXp0cqoWPHYt2XR4Q9o_RQ"   
YOUTUBE_playlist_ID_235 = "PL54D3F57300A406FA"   
YOUTUBE_playlist_ID_236 = "PL9A75E2D7D7F7EDB0"
YOUTUBE_playlist_ID_237 = "PLDulVecyRMFu-dHBbG2Q34VbwGJFJi1a6"   
YOUTUBE_playlist_ID_238 = "PL9O0WzI1PE_kRQAmirYyAZZmB4efi5y47"   
YOUTUBE_playlist_ID_239 = "PLNGA8uZjCGaVwUsHIV_KODTptbIfLSNTj"   
YOUTUBE_playlist_ID_240 = "PLAtuHZ7V5lmvmLtBmU8fQ8rOKLoJz39s4"   
YOUTUBE_playlist_ID_241 = "PLcVBgoDlDE9Zk_EZTFeEghMgMm-Lrqvbs"   
YOUTUBE_playlist_ID_242 = "PLAED3B191D3475000"   
YOUTUBE_playlist_ID_1332 = "PLmkVH97Tfm54Mnh89A1spmdcMAaoTU2ML" 
YOUTUBE_playlist_ID_243 = "PLer6HEZnCnBsDub85LC8JqpD-5Z0cn5BN"   
YOUTUBE_playlist_ID_244 = "PL61E0653CBB2EE166"   
YOUTUBE_playlist_ID_245 = "PL3CF12D3F9D2AF98C"   
YOUTUBE_playlist_ID_246 = "PLB4A16B73E6B770F8"   
YOUTUBE_playlist_ID_247 = "PLReI40KGodv4AQ6_v7gO92ezfX81kFSYy"   
YOUTUBE_playlist_ID_248 = "PLwph6LWZvBqV0gO08ymr_z-2YQinmPAe0"   
YOUTUBE_playlist_ID_249 = "PL1MMYn9UvtEDeIizXwFs22wQ-9M-pPtzP"   
YOUTUBE_playlist_ID_250 = "PLQsoGpd-IvXDsEZpwiMkm0gy8LNY2SZMG" 
YOUTUBE_playlist_ID_251 = "PL-hvaaoSDXQJpFhQYRkEjc_Zh4Sd65c-e"   
YOUTUBE_playlist_ID_252 = "PLQGrRTjQT3n8i34NHwvBVkgVDFW7yWLJP"   
YOUTUBE_playlist_ID_253 = "PLH6S8OjNLi-IRZYaUcmgCxmjiATDJQgqc"   
YOUTUBE_playlist_ID_254 = "PL9tY0BWXOZFtSsWJiobWz7RJuNpyGem5o"   
YOUTUBE_playlist_ID_255 = "PL5viewcavnJRLBTzfr2lotjfbBec_WfsO"   
YOUTUBE_playlist_ID_256 = "PLRBqtmUVTq9ojbbWzzPUYRbbE_KiolSmN"   
YOUTUBE_playlist_ID_257 = "PL8384361C552AE037"   
YOUTUBE_playlist_ID_258 = "PL9tY0BWXOZFv7G2CZp_v2rD-YxoFek5mw"   
YOUTUBE_playlist_ID_259 = "PLdv4Q1bUw92mbNJaH2ZfxstbT3yzg5TSf"   
YOUTUBE_playlist_ID_260 = "PLqRG33kmyQ-bQh1h_xu2A3iGlAIXtLBIC"   
YOUTUBE_playlist_ID_261 = "PLMCTxUMSkPJvmJdn46YSM9ON1ZJnDWsaE"
YOUTUBE_playlist_ID_262 = "PLVgGT_m10yKI5TeXQSaolhacnaRrPYAgU"   
YOUTUBE_playlist_ID_263 = "PL4471CADD811E98AC"   
YOUTUBE_playlist_ID_264 = "PLX8S4ptxX3CHezw1JDnwAH7CZLFGpj0z-"   
YOUTUBE_playlist_ID_265 = "PLkQgYGT4OQxQepqr92Fq2WPZoGPLSzn4v"   
YOUTUBE_playlist_ID_266 = "PL1D12230C0AB77258"   
YOUTUBE_playlist_ID_267 = "PLA5C96BE314DFBFE1"   
YOUTUBE_playlist_ID_268 = "PLUjtkJHrtwwMZhO_wzqqRqTU6dxHfda48"   
YOUTUBE_playlist_ID_269 = "PL1315ADEE7591C789"   
YOUTUBE_playlist_ID_270 = "PLcrQPzTzzkny2fYRlkhcFaCP6dlIyWYla"   
YOUTUBE_playlist_ID_271 = "PLSSFaMhDbnSgZif1XFj9DoLBM8nXI-VaV"   
YOUTUBE_playlist_ID_272 = "PL46F0DA8FEE3D05EC"   
YOUTUBE_playlist_ID_273 = "PL356E76935BD3436D"   
YOUTUBE_playlist_ID_274 = "PLluQRbJkwPWLDgzdDq7B7G-_QgKJNRxyH"   
YOUTUBE_playlist_ID_275 = "PLH583WMsSz85HljEkmsdJeF4-OWjwg6By" 
YOUTUBE_playlist_ID_276 = "PLkjxy7rAU7-fmfF6v-uJ1GlLk8WQv7M7U"   
YOUTUBE_playlist_ID_277 = "PLeOrAymWvmKv0pIEiWQIghn8j20Tk4qh_"   
YOUTUBE_playlist_ID_278 = "PLED95D4508CADA5BD"   
YOUTUBE_playlist_ID_279 = "PL_JoceHzJP227aLkv3lxDEI-_pgWJoGP1"   
YOUTUBE_playlist_ID_280 = "PLXLXo07HMXlj6swhszmAX54CNYWRONg76"   
YOUTUBE_playlist_ID_281 = "PL8Lpw39GxwbN5LUfSWw6l1zk-0x9qdoU6"   
YOUTUBE_playlist_ID_282 = "PLA910D381CD5AF74E"   
YOUTUBE_playlist_ID_283 = "PLVsyHu2yDLkzdYcDjz8yqw84CmcYZGCIt"   
YOUTUBE_playlist_ID_284 = "PL686F2F3A5367E6AF"   
YOUTUBE_playlist_ID_285 = "PL6AA65AC8EF2C778A"   
YOUTUBE_playlist_ID_286 = "PLognobB2_kXNs0xgH6wuhs2NfY4SxuOo4"
YOUTUBE_playlist_ID_287 = "PL8966944989656177"   
YOUTUBE_playlist_ID_288 = "PL4637097E6C3B9FFA"   
YOUTUBE_playlist_ID_289 = "PL1B208F7389718B08"   
YOUTUBE_playlist_ID_290 = "PL3DF195124B30541F"   
YOUTUBE_playlist_ID_291 = "PL8i09dj_8lqJFAqzj-HC65_PflY4fXZBe"   
YOUTUBE_playlist_ID_292 = "PLbfvV7Jk4y2GN1LMUijSaEcpmJCgShESI"   
YOUTUBE_playlist_ID_293 = "PLbAXYi_3XRupWmH2RsJhVSxUyDrgxiMzo"   
YOUTUBE_playlist_ID_294 = "PLYl_uowvUetAztlFeZE246wLsMhAt20T3"   
YOUTUBE_playlist_ID_295 = "PL9EA66637B199D004"   
YOUTUBE_playlist_ID_296 = "PL297bVu19DjKWZ-FL4bS9yoTRahZ7r0tf"   
YOUTUBE_playlist_ID_297 = "PLkvGdzRIKQcHNQFDtxv_e9s2ztevQlTIp"   
YOUTUBE_playlist_ID_298 = "PL72D7EDFFBD267A94"   
YOUTUBE_playlist_ID_299 = "PL4X0crpaJ94UK9iL_IFKcgpQkjwoP_TG5"   
YOUTUBE_playlist_ID_300 = "PLHjrfqfZxtq8Dq2PU3fWn8zK2clcduzfH" 
YOUTUBE_playlist_ID_301 = "PLE0FDCC00FF662791"   
YOUTUBE_playlist_ID_302 = "PL3ZhygAxAIEKh_uDisE_YTzMgkHSI2ADP"   
YOUTUBE_playlist_ID_303 = "PLA621DF4DA8243B5A"   
YOUTUBE_playlist_ID_304 = "PLtclzMEXudoOKKQkaoZ2S5-NY023gzFIR"   
YOUTUBE_playlist_ID_305 = "PLCnZ3VflDNT8TiIZwzSaU3sht2sgsr0w-"   
YOUTUBE_playlist_ID_306 = "PL2761826E95AA8627"   
YOUTUBE_playlist_ID_307 = "PL08713D57D31A4EC2"   
YOUTUBE_playlist_ID_308 = "PL2YQ9CDud0V6fc9xvSveHKd969jPUG8HH"   
YOUTUBE_playlist_ID_309 = "PLETRs3ajB8Y66Lq829xq-0grC8P0_k7hg"   
YOUTUBE_playlist_ID_310 = "PLtiMAzVCLC1CZhSwPdysLeB-KLMemRU_A"   
YOUTUBE_playlist_ID_311 = "PLLVPM-EDnX_kqmoIisQKs1ZNzGlQkddPH"
YOUTUBE_playlist_ID_312 = "PL282E56F9AEB053AD"   
YOUTUBE_playlist_ID_313 = "PL1F9mvbjP-UKdjsIf1-_CKPwmYDbJrgzU"   
YOUTUBE_playlist_ID_314 = "PLVT2cNxYuqywN78mv0rW6WVNa5C00QZOD"   
YOUTUBE_playlist_ID_315 = "PLEoQn-F0DgbCp0rWizm5H9jmzetBS-Z3v"   
YOUTUBE_playlist_ID_316 = "PLA8ACC4996D23A2D1"   
YOUTUBE_playlist_ID_317 = "PLelje9VYgWJxeAGveMKFFMHeDjhBHWm6w"   
YOUTUBE_playlist_ID_318 = "PLM2u4LcB9Qs8jxo1g9MJq-jRTKY4-V78e"   
YOUTUBE_playlist_ID_319 = "PL1223A48250584FA6"   
YOUTUBE_playlist_ID_320 = "PLPk5QlXG46mOxwuS6sq_4GxPa2IBVdCcw"   
YOUTUBE_playlist_ID_321 = "PLnb8ASKvc3bqQ7-jtO6L8OBjstvcAyCOU"   
YOUTUBE_playlist_ID_322 = "PLA0291DBAF0331F72"   
YOUTUBE_playlist_ID_323 = "PLMEZyDHJojxMYcmDeTKrusu36pheSLe_e"   
YOUTUBE_playlist_ID_324 = "PLnb8ASKvc3bqDw5KhlqvG87O8qM_kxwAw"   
YOUTUBE_playlist_ID_325 = "PLMEZyDHJojxOivUPWX1aasnKcpau8WZfP" 
YOUTUBE_playlist_ID_326 = "PL33B94EFA1AC7B225"   
YOUTUBE_playlist_ID_327 = "PLrf3rQKRuYFsX8EDIFODvmFC3655vTGbc"   
YOUTUBE_playlist_ID_328 = "PLIM_aEL234yTWEQcrqBWzdk_Ey6K05c2U"   
YOUTUBE_playlist_ID_329 = "PLX5_So5n4FY8zDaePEDZckealfQGlM3CW"   
YOUTUBE_playlist_ID_330 = "PLgaFNC_I_Zkl_-m5UgZVHNCekltAPm4ZI"   
YOUTUBE_playlist_ID_331 = "PLq3UZa7STrbpK7EpASU0uS4cx9g1if1ar"   
YOUTUBE_playlist_ID_332 = "PLby7aGz-99NE3LzT--kcwrJLq84RQV8Qj"   
YOUTUBE_playlist_ID_333 = "PLA2FC1F0D486E46CD"   
YOUTUBE_playlist_ID_334 = "PLaymMHeZocbZoudV5AhAsPMj2LYziFUvi"   
YOUTUBE_playlist_ID_335 = "PL73A333D40E72257B"   
YOUTUBE_playlist_ID_336 = "PLAE1CBD6C535383E7"
YOUTUBE_playlist_ID_337 = "PL6BTofJsuqJqvlhSM-YqEc93VvPMB3QWI"   
YOUTUBE_playlist_ID_338 = "PLC9FA360F254A23DB"   
YOUTUBE_playlist_ID_339 = "PLk6PQK9TLQcjGx57PPCj-rtbbxoHSgKBN"   
YOUTUBE_playlist_ID_340 = "PLRaF-uDStGYKfmsCeTNwrvrD8ou8nJXS0"   
YOUTUBE_playlist_ID_341 = "PLMKA5kzkfqk2GEImRCIqGqWmQvKYygUhG"   
YOUTUBE_playlist_ID_342 = "PLDAD12B2D8D1A6F27"   
YOUTUBE_playlist_ID_343 = "PLOtQlPby_DM9wyWgSsbYtLXcgDlobHvCg"   
YOUTUBE_playlist_ID_344 = "PL9t6nPQdrrKydft7kSeJ_LcVogfMqBj-v"   
YOUTUBE_playlist_ID_345 = "PL23A11132CD8400CD"   
YOUTUBE_playlist_ID_346 = "PL_UCDs2ps_73D9qOeYUE36HvGd4wyrG40"   
YOUTUBE_playlist_ID_347 = "PLAADGdv4DJW5e0O_RwmRUZDCRJU8rSwfG"   
YOUTUBE_playlist_ID_348 = "PLcVBgoDlDE9a-n25UuoASV2yKH-PRRUTT"   
YOUTUBE_playlist_ID_349 = "PLACC1097D7C4230C3"   
YOUTUBE_playlist_ID_350 = "PL6570579D0CF62486" 
YOUTUBE_playlist_ID_351 = "PLCCAB3C8590D69DC1"   
YOUTUBE_playlist_ID_352 = "PLIhLN7Z5xAvEURXboGP6niaIzlcw-o9Dd"   
YOUTUBE_playlist_ID_353 = "PL9RNWjHqrSKn75gfF9Hpg_xFfrCdJvBKC"   
YOUTUBE_playlist_ID_354 = "PLXhfRoiJBIisw1fw-lXan125yhXkwcIT8"   
YOUTUBE_playlist_ID_355 = "PLA06D691B470692F7"   
YOUTUBE_playlist_ID_356 = "PL71A9E09DEF0CE017"   
YOUTUBE_playlist_ID_357 = "PLAB88CF3B8B281FBE"   
YOUTUBE_playlist_ID_358 = "PLYAgTyCt4-2Y2PHuvfkMsJ51rReesuATp"   
YOUTUBE_playlist_ID_359 = "PLEc7XU_sm7I_43VFm5WQXJRbMiHgQVbjw"   
YOUTUBE_playlist_ID_360 = "PL2E846F203F5D963F"   
YOUTUBE_playlist_ID_361 = "PL4NdvF1C74HSXGbM02yrbzQHE9bGB-zVP"
YOUTUBE_playlist_ID_362 = "PLF4BDF2E98AC6ACD2"   
YOUTUBE_playlist_ID_363 = "PLB78DD4B32344E269"   
YOUTUBE_playlist_ID_364 = "PLWSt2DnFGE9s6xFE6t30MRqupz5-VD1ql"   
YOUTUBE_playlist_ID_365 = "PLC8198E08BB1AB8AA"   
YOUTUBE_playlist_ID_366 = "PLmBrIbV68uaA1fMSSGV0JBznRV5WIlrvn"   
YOUTUBE_playlist_ID_367 = "PL9tY0BWXOZFtEo1b8IQpwQ1g775FIYh7r"   
YOUTUBE_playlist_ID_368 = "PLp3o6lwxnqMkm9dUECwqVBQY0IN6n1wH_"   
YOUTUBE_playlist_ID_369 = "PLL1g3RhI-vhlLejU0uTYgzpvomdsqmBQH"   
YOUTUBE_playlist_ID_370 = "PLfIsADRe5x-mcah6DL3B_IVfl8K6R_0QX"   
YOUTUBE_playlist_ID_371 = "PLh_5LL6VRZMYElA9INhiLJyy9zL2icHTc"   
YOUTUBE_playlist_ID_372 = "PL119816F23E12BCCB"   
YOUTUBE_playlist_ID_373 = "PLE5E950E00A8A23C2"   
YOUTUBE_playlist_ID_374 = "PL301D7644A9253C61"   
YOUTUBE_playlist_ID_375 = "PLWdWnbKPnT0R0I7GEP73-rHSz4qTuDsyt" 
YOUTUBE_playlist_ID_376 = "PL5D7C0F235DD66CEB"   
YOUTUBE_playlist_ID_377 = "PL21tX2h3EFZcoAvEITJnImhomzSdCj__O"   
YOUTUBE_playlist_ID_378 = "PL7C80D90FB59806FE"   
YOUTUBE_playlist_ID_379 = "PL82D5EAE2E85B22DA"   
YOUTUBE_playlist_ID_380 = "PLC6707556C37C4FDF"   
YOUTUBE_playlist_ID_381 = "PL_yH9Q5syvqhPtzRtUO-H3wKvl7EcdjMT"   
YOUTUBE_playlist_ID_382 = "PLqRDo7HR1AcyCNef39aYYsQhgFKMr7FpW"   
YOUTUBE_playlist_ID_383 = "PLbnF-C61Hi8u5fS2TGhp-nT62GOHTCpZR"   
YOUTUBE_playlist_ID_384 = "PL84EDE1A11AEFCCB8"   
YOUTUBE_playlist_ID_385 = "PLeU-9LrH2xOFXTREjOECDc9ViPQJwSvti"   
YOUTUBE_playlist_ID_386 = "PLDFot90ZSkC_sZIpSGGSoqkd0lvsipn6K"
YOUTUBE_playlist_ID_387 = "PLBiUXsOXYmCbx0FGEbR3i_yWOx2iOBRvf"   
YOUTUBE_playlist_ID_388 = "PL6vqo3BZ396WARJmJZbkhKsYzGrhCA9Rj"   
YOUTUBE_playlist_ID_389 = "PLLsIO2RaTOnWg3COG30DB36Rm19Ro9393"   
YOUTUBE_playlist_ID_390 = "PL545EBEA68E51289A"   
YOUTUBE_playlist_ID_391 = "PL49DB01A161111570"   
YOUTUBE_playlist_ID_392 = "PLvu8wCghVq058TUcWJATbEVA6yPjZsA1r"   
YOUTUBE_playlist_ID_393 = "PLQ7GKO_eJjw04rj-RmtZiJfbys0romkWi"   
YOUTUBE_playlist_ID_394 = "PLeiUnYpf86URvNV3UlXmJonVbgnJKlvrc"   
YOUTUBE_playlist_ID_395 = "PLBFE3CE3C9D2DA2A4"   
YOUTUBE_playlist_ID_396 = "PLrTrS3x8ShRI-ztkAewW2g57ukRbJuPG-"   
YOUTUBE_playlist_ID_397 = "PLZo-SRqPbntvkbMnWv1lsIqG6JH5oB3-n"   
YOUTUBE_playlist_ID_398 = "PLCF5A3089449F9206"   
YOUTUBE_playlist_ID_399 = "PL8269CD636FCD1878"   
YOUTUBE_playlist_ID_400 = "PL9FFC42356C3C87AD" 
YOUTUBE_playlist_ID_401 = "PL490CD25236E0824B"   
YOUTUBE_playlist_ID_402 = "PLGYE0BUUzhDPmao2ALIrr1j2rd9abHMKP"   
YOUTUBE_playlist_ID_403 = "PL94DC2785DB5D6889"   
YOUTUBE_playlist_ID_404 = "PLwMXTH80keS57IiavZq18PutbObtWpwfI"   
YOUTUBE_playlist_ID_405 = "PL3036C05CC3EC0FEF"   
YOUTUBE_playlist_ID_406 = "PLfqlpuz-LWL28EHinbSqNhj2nFZS-WQ-I"   
YOUTUBE_playlist_ID_407 = "PLBF29177C5D2545EF"   
YOUTUBE_playlist_ID_408 = "PLB507CC895F31BE07"   
YOUTUBE_playlist_ID_409 = "PLgAQes15lM1NSkDXTnvA6zeubQ94b3CTi"   
YOUTUBE_playlist_ID_410 = "PLE5C271899AE85D68"   
YOUTUBE_playlist_ID_411 = "PLo_h4k58Suz-PUA7LJE9qZEAGy0gkn15r"
YOUTUBE_playlist_ID_412 = "PLB94D721E8C56F510"   
YOUTUBE_playlist_ID_413 = "PL2E258831F7A321F3"   
YOUTUBE_playlist_ID_414 = "PL5m2xEMryylqPLhfTaQbuQv0I4Rj96qzE"   
YOUTUBE_playlist_ID_415 = "PLCB1D33824DF694EC"   
YOUTUBE_playlist_ID_416 = "PLPsC4EHY8H1yyHNqF0tThrGvtlnYDevio"   
YOUTUBE_playlist_ID_417 = "PL01704F707A55EF79"   
YOUTUBE_playlist_ID_418 = "PLPbCXiOeC78fFoikLvKKPHduJTYy46md6"   
YOUTUBE_playlist_ID_419 = "PL-wcKZ0usf2xRzGG2nFH9GNJSmsiWY01W"   
YOUTUBE_playlist_ID_420 = "PL30490FAADC79FBDA"   
YOUTUBE_playlist_ID_421 = "PLDE7406D26D7C0C45"   
YOUTUBE_playlist_ID_422 = "PLq3UZa7STrbpBjxItYWh2ezQj3kwoSA8s"   
YOUTUBE_playlist_ID_423 = "PL4q5myTDSpAsg_UMr1QbrGRDeAH4bnUX6"   
YOUTUBE_playlist_ID_424 = "PLF1D793B61571DD4A"   
YOUTUBE_playlist_ID_425 = "PL03DC1B33BDAE6A67" 
YOUTUBE_playlist_ID_426 = "PLzrRkSuSpF2Oaq2yKAkq4EopHiInxFszR"   
YOUTUBE_playlist_ID_427 = "PLgzm-4W_Rws2PG-qWHcssGXvJz_3Gcu9M"   
YOUTUBE_playlist_ID_428 = "PLIISIRE_qI9vZfOX6iOgoyky3veBeOkKe"   
YOUTUBE_playlist_ID_429 = "PLBeeiCx5Kc2uJ7TjYPpQyLaNkHDKegMBB"   
YOUTUBE_playlist_ID_430 = "PLuGTG9Jnl26qNO_wSkjs5-wncuApSEdyJ"   
YOUTUBE_playlist_ID_431 = "PL-HTuqRSXexeuHyM1D9OBvsog2eNzpEkv"   
YOUTUBE_playlist_ID_432 = "PLVKyRPHlceGv2coExv4wXgRdaKvt_HaDF"   
YOUTUBE_playlist_ID_433 = "PL_NbILIrNQ3MDuKA9jF43aDdglBgFG4qk"   
YOUTUBE_playlist_ID_434 = "PLEWdEuIEMHXXqXTVlfAVhEnmZUByluv_T"   
YOUTUBE_playlist_ID_435 = "PLQtqTMmRSduu0x0hD-jZUUWiagB6SoIXr"   
YOUTUBE_playlist_ID_436 = "PLYq7ixysvQ8qac-3tCYdt9Ckzc-B_g01L"
YOUTUBE_playlist_ID_437 = "PLzAzZbNGlKlo5o1r0SoUUwcSymGy7eQrg"   
YOUTUBE_playlist_ID_438 = "PLzaV6_B-O2YMUHCmY0cklUs_MVwqc480-"   
YOUTUBE_playlist_ID_439 = "PLSL9DB9AUS4NXYjaIqcEBfqk0plJpupQO"   
YOUTUBE_playlist_ID_440 = "PLM9IqydaE5Qg-5QGk9hZzxFFc0qDAlk2u"   
YOUTUBE_playlist_ID_441 = "PL5E298F634DE0F5BE"   
YOUTUBE_playlist_ID_442 = "PL0eheHgLSuZC2mpgfwskVw1UqC-isnatw"   
YOUTUBE_playlist_ID_443 = "PL616EA300F070272C"   
YOUTUBE_playlist_ID_444 = "PL1FEA41C25BA65D50"   
YOUTUBE_playlist_ID_445 = "PL0DB47430DB7B19DD"   
YOUTUBE_playlist_ID_446 = "PLE85CC75CADDAC253"   
YOUTUBE_playlist_ID_447 = "PL5yKAm2KCmJf-nK6ffTgtBE9ZtknLzblr"   
YOUTUBE_playlist_ID_448 = "PLdfPuC71j6-92mJwCB59NfOPQxB-WWgg7"   
YOUTUBE_playlist_ID_449 = "PLw1nLsex_Q8K2Q-K9mq6nUKQw6osrHaN9"   
YOUTUBE_playlist_ID_450 = "PLE1179D279C08BE4A" 
YOUTUBE_playlist_ID_451 = "PL_KyKlouByE9b3jTxWwwy2kvQnVX9NnFd"   
YOUTUBE_playlist_ID_452 = "PL8xUXGytbOQmRs2kqId8UiFB8gEdQ8ojR"   
YOUTUBE_playlist_ID_453 = "PLJ5cGDOKPw72LWDHjlfcwjnAiKvxOSa-C"   
YOUTUBE_playlist_ID_454 = "PL4iSbgi3WlCqFsEwfbun3ZquM-MPznJaR"   
YOUTUBE_playlist_ID_455 = "PLq3UZa7STrbpX13PljcNH6hmyrSbcMYK8"   
YOUTUBE_playlist_ID_456 = "PL4pGkk3QBW28n6QCBWcmE76Ro7ONEzlMG"   
YOUTUBE_playlist_ID_457 = "PLpXA1IqBgeZTdZRUjM1kfLYxozJu6Wqvu"   
YOUTUBE_playlist_ID_458 = "PLF10CD8DBC7E24650"   
YOUTUBE_playlist_ID_459 = "PLM3BWIah4Jd6juUG678HMNG-METNTarmg"   
YOUTUBE_playlist_ID_460 = "PLtNMkp_GwStcR3Z6iOGj5pElWIlTU9xVh"   
YOUTUBE_playlist_ID_461 = "PLU7AqrWILU6U4r-u2p3Awynx7zK9OUprh"
YOUTUBE_playlist_ID_462 = "PLrwXzbX3SWnu1H2yesZA0-28anAKGK6ZE"   
YOUTUBE_playlist_ID_463 = "PLqss3L6F2c-fdGzpvsTvNx6jBxfCYfZY_"   
YOUTUBE_playlist_ID_464 = "PLYynWIEvzrvJz47wIwnvITIgRId3F5FtP"   
YOUTUBE_playlist_ID_465 = "PLeoBVKHKNsGrwPxGPZjVGWBOoXJARe5Ca"   
YOUTUBE_playlist_ID_466 = "PL0D4AA1524FE41E11"   
YOUTUBE_playlist_ID_467 = "PLTc5tHPDpnJ__Ne9Z3aCQ_Oq91-CNaku3"   
YOUTUBE_playlist_ID_468 = "PL-yLAUhj7Tv0dspscFI7asl3U8UdF4XqG"   
YOUTUBE_playlist_ID_469 = "PLakVP-Hif-xGA-VFwYubSNfbnUZdLvDh4"   
YOUTUBE_playlist_ID_470 = "PLE722D7508EB8E461"   
YOUTUBE_playlist_ID_471 = "PLbXEBkoCkCnZ6U8KlTRi8I6qNtqbIQTW1"   
YOUTUBE_playlist_ID_472 = "PLOUzUrKhNae51rhMgkY_v1BWWISuvjmkk"   
YOUTUBE_playlist_ID_473 = "PLEC4A6ACBA34E2600"   
YOUTUBE_playlist_ID_474 = "PL4iSbgi3WlCpM2bG4ybcZdttLzyWxbEzf"   
YOUTUBE_playlist_ID_475 = "PLTc5tHPDpnJ-p7MZIpeIvLiHbE7gZfz66" 
YOUTUBE_playlist_ID_476 = "PLF70335554080E22E"   
YOUTUBE_playlist_ID_477 = "PLD96DBE7E46FAD03E"   
YOUTUBE_playlist_ID_478 = "PL18F13283F8B68C2D"   
YOUTUBE_playlist_ID_479 = "PLE1CBD1B33B341143"   
YOUTUBE_playlist_ID_480 = "PL68G3OPRSzPpitH3oximIlV5gXQStNWpv"   
YOUTUBE_playlist_ID_481 = "PLv-V6tGqeV2cBboliakj1lN292CgqDGea"   
YOUTUBE_playlist_ID_482 = "PL3MTqeAZhHKD5Ht0pfOKdwhq2tOYKqChg"   
YOUTUBE_playlist_ID_483 = "PL800877997FBC02C2"   
YOUTUBE_playlist_ID_484 = "PLwMXTH80keS6zjxCrvGfzci6tmbHK6tu8"   
YOUTUBE_playlist_ID_485 = "PL5F82E94EFA6258C9"   
YOUTUBE_playlist_ID_486 = "PLF3158488184AA928"
YOUTUBE_playlist_ID_487 = "PLUhqFX6g_9NenFieBfcTO67pamzG7dKVc"   
YOUTUBE_playlist_ID_488 = "PLP02sRgldWRb9LjuQgJ4AfxCd4cxygDrA"   
YOUTUBE_playlist_ID_489 = "PL5rodSuroR-AG4gzm8gmIsB6qVeOMukrm"   
YOUTUBE_playlist_ID_490 = "PLCSfalJkj4wGOm8ZpwhJbr7ZugcqKy-u0"   
YOUTUBE_playlist_ID_491 = "PLUhqFX6g_9Nd-MBiK9eYPz8wpqU4oKrO7"   
YOUTUBE_playlist_ID_492 = "PLnIc8l-6P2z5EQ4soX1AnbH_kp3P_auAK"   
YOUTUBE_playlist_ID_493 = "PLAJtD5xn2t_V2OnzOn3zNnKX9djzIbjnv"   
YOUTUBE_playlist_ID_494 = "PLlHc5zP6BMBjWNs3hHzXsZuLdAYUCqUkN"   
YOUTUBE_playlist_ID_495 = "PL6CB08BA1FA4C3E44"   
YOUTUBE_playlist_ID_496 = "PLkc_Bfs9bx0K3C4H0QQ_9sii9-JRmBLfj"   
YOUTUBE_playlist_ID_497 = "PLBED3EC3449AC0A5E"   
YOUTUBE_playlist_ID_498 = "PLxllXQXRDRfOWXH64yHRIjJPboXmfn7Cd"   
YOUTUBE_playlist_ID_499 = "PLKa5Nd1o-qEQNm3c1phEKUjpQUGdfcyjj"   
YOUTUBE_playlist_ID_500 = "PLVMTgzzMzyq-vOMOXjhUMVjhBSYNMYBlx" 
YOUTUBE_playlist_ID_501 = "PL83C0CF3A66952878"   
YOUTUBE_playlist_ID_502 = "PLB92C37331CFA7BF1"   
YOUTUBE_playlist_ID_503 = "PLMEZyDHJojxNCL2xZLRNpI_5JPScffvB2"   
YOUTUBE_playlist_ID_504 = "PL9309F6E6083B49D5"   
YOUTUBE_playlist_ID_505 = "PLuBXV0aI8TzvQEQQ_l4QmskB7QprT-vsF"   
YOUTUBE_playlist_ID_506 = "PLE926440DD5594B6C"   
YOUTUBE_playlist_ID_507 = "PLBB4F6C1BDF5A66E2"   
YOUTUBE_playlist_ID_508 = "PLc9n2mgXOm-6UEALuKaPDHZZwPJbEHFes"   
YOUTUBE_playlist_ID_509 = "PLZPH1jRsbZrzxXxi-5Hk3V4V0-rzHyz34"   
YOUTUBE_playlist_ID_510 = "PLjzB8TMjdjwN6Uq86_557_NRuP_iLrOiA"   
YOUTUBE_playlist_ID_511 = "PLBjpeVsxVzrcKdaytaNsr9mZvezjc6uQY"
YOUTUBE_playlist_ID_512 = "PL1NQLkz_HA9-zL8gcTlVmGoWoSMXy-V34"   
YOUTUBE_playlist_ID_513 = "PL44808552AB3C4296"   
YOUTUBE_playlist_ID_514 = "PL7zrnXIkwlVypkCzwbSBpSIrdNWPDqfe1"   
YOUTUBE_playlist_ID_515 = "PLMhCGv0XCuctYxpwhcIEeP7uRy3ba1WqQ"   
YOUTUBE_playlist_ID_516 = "PLC6F132BA6B6AF92E"   
YOUTUBE_playlist_ID_517 = "PLrmTe5LGdXcOXW6ohTxWSaNmi68rRLNip"   
YOUTUBE_playlist_ID_518 = "PLB739CB9E62F387E0"   
YOUTUBE_playlist_ID_519 = "PLwyIC8LoPNoVzex4xc6JxessapdR-H6j0"   
YOUTUBE_playlist_ID_520 = "PLAB3B1E4C92BDC0A4"   
YOUTUBE_playlist_ID_521 = "PLDAc319-LXupaLibqGVJf0J_kbj3A1XCM"   
YOUTUBE_playlist_ID_522 = "PLVMTgzzMzyq-v9t0-XKf1s8GnY8ugO_Wn"   
YOUTUBE_playlist_ID_523 = "PL44EBB23ADA2F36A0"   
YOUTUBE_playlist_ID_524 = "PL_71SYGvVoCFfYPAxL08amtC_2GGCvmz-"   
YOUTUBE_playlist_ID_525 = "PLfEbmmnuSabeg5MS-4f1fPod3zsjOQNMQ" 
YOUTUBE_playlist_ID_526 = "PL7B88D80D895B45A2"   
YOUTUBE_playlist_ID_527 = "PLB6D1882930F82ABA"   
YOUTUBE_playlist_ID_528 = "PLvuNxZXOp0VQxcQdwxk8WbgxKBTHGXr8D"   
YOUTUBE_playlist_ID_529 = "PL3DD77D6194A5DE66"   
YOUTUBE_playlist_ID_530 = "PLUhqFX6g_9Ne0ck9QhOViDrIMD_-6Wk17"   
YOUTUBE_playlist_ID_531 = "PL88B438D3A5B7DE84"   
YOUTUBE_playlist_ID_532 = "PLxhfCY00zUPAYUkapGvjIv2dhFVFCc9rP"   
YOUTUBE_playlist_ID_533 = "PLRrqhqzwiJr2fUJ8yxXCyOJpCCQrxbYUS"   
YOUTUBE_playlist_ID_534 = "PLUwpNLwMcwiToue5SLpweK7Zdwhd6AhWn"   
YOUTUBE_playlist_ID_535 = "PLH_DvgjXDIqeg86pPXncSLHCMpq3do0oF" 
YOUTUBE_playlist_ID_536 = "PLDDD50B2632AE928B"   
YOUTUBE_playlist_ID_537 = "PL2PI3BtEVzA7TfhMFjeseXkYvVJpx__ia"   
YOUTUBE_playlist_ID_538 = "PLYq_mcte9NvDA2Xi5Qjl1DrH5LuDKDlAI"   
YOUTUBE_playlist_ID_539 = "PL4sfVCWR8nGI2dS8kus2BjgqmIPKas5Ar"   
YOUTUBE_playlist_ID_540 = "PL162DF0A1EA635492"   
YOUTUBE_playlist_ID_541 = "PLki40DkF9sdieNYY089rxtvBsQe8UMo3C"   
YOUTUBE_playlist_ID_542 = "PLN0pon2Ar7AbZj860kaXa2EuQm5_aK_5J"   
YOUTUBE_playlist_ID_543 = "PLBB9F6B341EBE788E"   
YOUTUBE_playlist_ID_544 = "PLrmTe5LGdXcPr80ekQ0DDY1GPPogYm0b6"   
YOUTUBE_playlist_ID_545 = "PLyQy-tokPWDCSgygKenf1V5Ldgk4W5hO-" 
YOUTUBE_playlist_ID_546 = "PLEB981E95D02EE8E0"   
YOUTUBE_playlist_ID_547 = "PLDABF14A93B588ECD"   
YOUTUBE_playlist_ID_548 = "PLA52A4666DF8787DD"   
YOUTUBE_playlist_ID_549 = "PL36494E8634856791"   
YOUTUBE_playlist_ID_550 = "PL53r_72HW2Gq7W1aLfdnh-J0ebbcMxn_x"   
YOUTUBE_playlist_ID_551 = "PL10697307553142B4"   
YOUTUBE_playlist_ID_552 = "PL0FM4Hk88HorNIaqTP5RdMFWHfEguknkb"   
YOUTUBE_playlist_ID_553 = "PLSoDfeucGhYhdj8-xYdGMvpLhSW1_c6_1"   
YOUTUBE_playlist_ID_554 = "PL10ADF05EDE138B93"   
YOUTUBE_playlist_ID_555 = "PLdyoht_ygUufhezMUCgHWa4OBQETAznQZ" 
YOUTUBE_playlist_ID_556 = "PLuiHoY-HuNM9ynybRD776aJHVbNyRUb_p"   
YOUTUBE_playlist_ID_557 = "PL9tY0BWXOZFtfXKVAXqyTjl3cJddXO7Ci"   
YOUTUBE_playlist_ID_558 = "PL55Ni-v_oWPdjDMp0E5zt-GlqgFCWy95m"   
YOUTUBE_playlist_ID_559 = "PLy6515vXiQhOrkoPQqYQL-T0GR7eTbHvJ"   
YOUTUBE_playlist_ID_560 = "PLEEE0FC03B2C11631"   
YOUTUBE_playlist_ID_561 = "PL11AE103796E8D14F"   
YOUTUBE_playlist_ID_562 = "PLEgIGDMaPLry3vDpLplgdbdG_wQboT3mu"   
YOUTUBE_playlist_ID_563 = "PLaQH-0rR7Mhs5GJ9nBpA2SAytWGCTMwmP"   
YOUTUBE_playlist_ID_564 = "PLqmSVzIbYy5p7j4XxMK4yGCTlAee0in7b"   
YOUTUBE_playlist_ID_565 = "PL659998B48AFDF694" 
YOUTUBE_playlist_ID_566 = "PLUhqFX6g_9NcTrAFbLsz97uRhBZIfBa1K"   
YOUTUBE_playlist_ID_567 = "PL5151B3326274A0C9"   
YOUTUBE_playlist_ID_568 = "PL5yGB_eqIALRfoednx480iOjvXjmIG1Em"   
YOUTUBE_playlist_ID_569 = "PLeChJ_avuyOgP3Me-pg-qkftETsTXQ-8w"   
YOUTUBE_playlist_ID_570 = "PL227EEB7C9E1B7F6B"   
YOUTUBE_playlist_ID_571 = "PL8yDMPBV36b-4VHjgeY7X9YOwoI0qmSiP"   
YOUTUBE_playlist_ID_572 = "PLDX2jvORHkAbf8EIdFF_8lO1AwS_n9Zeq"   
YOUTUBE_playlist_ID_573 = "PLYXC8wAPyQ-t2evU4cNbcw0j4LCFOacCu"   
YOUTUBE_playlist_ID_574 = "PLyACOLem3DUNm_oSlQx52F2adZp87bfDn"   
YOUTUBE_playlist_ID_575 = "PL29662FBF0FC8F98D" 
YOUTUBE_playlist_ID_576 = "PLD8F8D858996445F4"   
YOUTUBE_playlist_ID_577 = "PLDhVYwv-_6NNVVGjCuVywQr_eKY4OKYgc"   
YOUTUBE_playlist_ID_578 = "PLMKA5kzkfqk2RxeZv-vv9yOAYb-W6MNuF"   
YOUTUBE_playlist_ID_579 = "PLLdhG8CrtPg6BYtlLj6_YDc1TYnMb6JAb"   
YOUTUBE_playlist_ID_580 = "PLx4lUNYIahP0bTBZTqTp97YNzzrHscl-b"   
YOUTUBE_playlist_ID_581 = "PLUhqFX6g_9NeuCVJ_sRtTwGaN9MVtoFM7"   
YOUTUBE_playlist_ID_582 = "PLC1760F50DD217D23"   
YOUTUBE_playlist_ID_583 = "PLA5yV_uAHZxGsmcyYOdNeZxd_BMUPdvnG"   
YOUTUBE_playlist_ID_584 = "PL9FOcjmiWH2NjRxjeV7jGPakWDAMrlygp"   
YOUTUBE_playlist_ID_585 = "PLcqF11LIymWl0cFtebuisw1NLzK67eVJr"
YOUTUBE_playlist_ID_586 = "PL5C8EB872CBF1D6A0"   
YOUTUBE_playlist_ID_587 = "PLD77AA07B082B59D3"   
YOUTUBE_playlist_ID_588 = "PLXSlB4yMaoJt0a3U3L0mCfkBl8E9Fb80e"   
YOUTUBE_playlist_ID_589 = "PLp_iBccYqoUnWmePmcEpwcAlZspGcns2x"   
YOUTUBE_playlist_ID_590 = "PL6AePG2tb9je-vw8-DJLzDAjFKcKJSyw4"   
YOUTUBE_playlist_ID_591 = "PLYIuiP4eVykBlqBTPMJr5PT4cweeE-00Y"   
YOUTUBE_playlist_ID_592 = "PL61B14D1DE8E273C2"   
YOUTUBE_playlist_ID_593 = "PL1C8F05D1E2F4A3E5"   
YOUTUBE_playlist_ID_594 = "PLEuEX6d62_ThmL-mWF429JGNb0xgaqyw3"   
YOUTUBE_playlist_ID_595 = "PLA70BDEC842EFD1B1"
YOUTUBE_playlist_ID_596 = "PLRRe_urOjL_-g3mh2I1dOIJbUSmQCErry"   
YOUTUBE_playlist_ID_597 = "PL9tY0BWXOZFvdgp-L95ah3_g_dVyrdG_2"   
YOUTUBE_playlist_ID_598 = "PLA107D57396828C61"   
YOUTUBE_playlist_ID_599 = "PLA93FBFFB92366058"   
YOUTUBE_playlist_ID_600 = "PLehDej4bAH7s23koRAtKV1Tp51RXbPyTx"   
YOUTUBE_playlist_ID_601 = "PLE22oZlNYBeUkIxlGKvhW4jgQw5Td9A52"   
YOUTUBE_playlist_ID_602 = "PLvaqLJe33YM-YYV4QtgChF0xvymnzyHnG"   
YOUTUBE_playlist_ID_603 = "PL55E46876084F0FF1"   
YOUTUBE_playlist_ID_604 = "PL0FE41504CD0BA279" 
YOUTUBE_playlist_ID_605 = "PLQlc99hV-nkEjUQVJs_yvUWNF9sMT1U2Z"   
YOUTUBE_playlist_ID_606 = "PLzKfy0659ADR919--DPRl6TuXAr2hsy-y"
YOUTUBE_playlist_ID_607 = "PL82DD9D466EF42498"   
YOUTUBE_playlist_ID_608 = "PLYZdoQEzgT6NgXqqGTX9hTcnb3HJu4pMa"
YOUTUBE_playlist_ID_609 = "PLF2B03FD995812F70"   
YOUTUBE_playlist_ID_610 = "PLzMhF_Kgqw3iZBdZ4sX-kdVaWPCEo3q9B"
YOUTUBE_playlist_ID_611 = "PLnb8ASKvc3brEhg5S2RjbqYNUj0abyWZW"   
YOUTUBE_playlist_ID_612 = "PLC6F651FAF1446BA1"
YOUTUBE_playlist_ID_613 = "PLYyCK0RusuMgFqsZGAOmSwDElkGyPezN3"   
YOUTUBE_playlist_ID_614 = "PL9tY0BWXOZFtTq-pR8kxWjPguXAQUWJj2"   
YOUTUBE_playlist_ID_615 = "PLI0Pcsyj7zjDv2snqSpSYg_PhPuKF4rDY"
YOUTUBE_playlist_ID_616 = "PLl5CX1dIY3feSGR_Dt_wPb1fjxtOR1vrB"   
YOUTUBE_playlist_ID_617 = "PLKDEJik_StMCGMzMjNrR9zg_ZXgnmT6Qs"
YOUTUBE_playlist_ID_618 = "PLFp3UFrQEaa6tIGe1EcIqzMdekApcNVmo"   
YOUTUBE_playlist_ID_619 = "PLI3Fu0Wr-wLyG4V_TbpPkaP8V5GBsqOZz"
YOUTUBE_playlist_ID_620 = "PLiy0XOfUv4hEsqQZHj4TlsnTGlFu2wqhy"   
YOUTUBE_playlist_ID_621 = "PLyZuFlFYdMNXP_ERPUTyFQIi1WV-PsSeL"
YOUTUBE_playlist_ID_622 = "PLIdPxD0zhZDN-ERC8ZM4q4zoGiULQi9LI"   
YOUTUBE_playlist_ID_623 = "PL8zqpdiboZKiEXB-IDz6SB_-OG8GXcec5" 
YOUTUBE_playlist_ID_624 = "PL30E6243473881073"   
YOUTUBE_playlist_ID_625 = "PLQoq3MJd_TfeD4m5buLPXA6nhXPntyJ_9"
YOUTUBE_playlist_ID_626 = "PLDF8535C45B99B791"   
YOUTUBE_playlist_ID_627 = "PL0ACBB930AB5A1E47"
YOUTUBE_playlist_ID_628 = "PLBF298B246AAA1AC2"   
YOUTUBE_playlist_ID_629 = "PLXj5JwtQIKHpNU7XpBgAscPfCIXEcxdbl"
YOUTUBE_playlist_ID_630 = "PLt355e7j3qRLlsR5UT2ZGUbXkY3RSkEBm"   
YOUTUBE_playlist_ID_631 = "PL65011B707C4A9B58"
YOUTUBE_playlist_ID_632 = "PL6PWcU1XP813_yo181cAuDh0yhI6ih2q-"   
YOUTUBE_playlist_ID_633 = "PLpTxN0bsTsj7Ef4Y1jHra-UmIvbxYSfsu" 
YOUTUBE_playlist_ID_634 = "PLLcYKNya-TdRxQBfuebWADD1gaPUizsis"   
YOUTUBE_playlist_ID_635 = "PLcLgNr_gjdwM8-Oq8w5nfjg9f52Bv5fWu"
YOUTUBE_playlist_ID_636 = "PLuiynvNke2wDYNHFnOksxAwobcDuAcezs"   
YOUTUBE_playlist_ID_637 = "PL8a8cutYP7foqXhXnBMgjgn92iwX0RAbn"
YOUTUBE_playlist_ID_638 = "PLcBIiSYKhawxOImF66BQBDPX8iKPMiP6l"   
YOUTUBE_playlist_ID_639 = "PLyI9_B_k7W2enSFfVmKFhy0jUOb1xg9Ad"
YOUTUBE_playlist_ID_640 = "PLLiShYJztUuHRMjh01jR1XrYHCSwhpV4H"   
YOUTUBE_playlist_ID_641 = "PLqK1JpL0Zp67FtqVZ2juNw78W8J9znsuv"
YOUTUBE_playlist_ID_642 = "PL204E8BAE8A973840"   
YOUTUBE_playlist_ID_643 = "PLiWvJyFU7nUcbYEWMIxZ-1S5An2qwVM50" 
YOUTUBE_playlist_ID_644 = "PLE9B6270DEFDE6E58"   
YOUTUBE_playlist_ID_645 = "PLE6E7BBF9FE011335"
YOUTUBE_playlist_ID_646 = "PLNrotoZZ8BaoXT_LJuwEyESQlctWNDCwD"   
YOUTUBE_playlist_ID_647 = "PLqK1JpL0Zp646ALr3SrKhN38c0xCywmhe"
YOUTUBE_playlist_ID_648 = "PLeUNUy63QUzxh7s4pk0E1nBm42LMgToBT"   
YOUTUBE_playlist_ID_649 = "PLAYz6ODULpcpe7gr-7G-zspADZ-DCdf_1"
YOUTUBE_playlist_ID_650 = "PLF9Dx60oSplx5RxRUHcuZNnVKszR4ZL6O"   
YOUTUBE_playlist_ID_651 = "PL4A1DA43196B24F85"
YOUTUBE_playlist_ID_652 = "PLqFORg9fBL_94ZPKe3CXn7_qXmdIkWdaS"   
YOUTUBE_playlist_ID_653 = "PLYtUDYMM_E1PolwaYFOuQ-7sCTE1gXMwK" 
YOUTUBE_playlist_ID_654 = "PL8A14540E39141DBC"   
YOUTUBE_playlist_ID_655 = "PLg-jS7VWuFqe2aS7JmjONXF-Ga3YErFk4"
YOUTUBE_playlist_ID_656 = "PLpg0EOoO2vdUrhGf9IY_QBkIfaUAnLS8O"   
YOUTUBE_playlist_ID_657 = "PLSD2CrUbfw2i1COvHWaxdDbO8FOFCVBjH"
YOUTUBE_playlist_ID_658 = "PL9P4O8vi9hsUgEgu1ZWPZacEA1qeP2NbU"   
YOUTUBE_playlist_ID_659 = "PLRYjIdaAzRVmmaJEG-elAlp91clvYXnws"
YOUTUBE_playlist_ID_660 = "PL3F91D3937DA7EFCE"   
YOUTUBE_playlist_ID_661 = "PL8CC200731401AC0A"
YOUTUBE_playlist_ID_662 = "PLcr38rCnhjrHplGqE2os_bozfUS4EvS41"   
YOUTUBE_playlist_ID_663 = "PL7BB69735F962D18E" 
YOUTUBE_playlist_ID_664 = "PL066842B6CB256222"   
YOUTUBE_playlist_ID_665 = "PL6lqml5OGdIk09Jl_N3slhd87-_e0qYKm"
YOUTUBE_playlist_ID_666 = "PLseru_GF_QVXLY8qe6XHBo_u24jlMq1Oz"   
YOUTUBE_playlist_ID_667 = "PLWEEt0QgQFInlTfCOnwOxPNVO8Krdcwk2"
YOUTUBE_playlist_ID_668 = "PL8hPVrMlVbzOHf7eGPu2IZ4VOVS0gyepv"   
YOUTUBE_playlist_ID_669 = "PLjqlUlCV3H7rBC_XhQQdjzroO8pdElqSw"
YOUTUBE_playlist_ID_670 = "PLsutuIAyVp8wuJvmveq5xuZt8JYMuayiH"   
YOUTUBE_playlist_ID_671 = "PL884FF678A170BC35"
YOUTUBE_playlist_ID_672 = "PLSA8Vc13GuKSXGZG2jqkiFK16W8bGb8Mm"   
YOUTUBE_playlist_ID_673 = "PLB4BFC2DFB643E729" 
YOUTUBE_playlist_ID_674 = "PLkXJjkTiC-zPNtKvU3hHwy-dSZy0wLsE7"   
YOUTUBE_playlist_ID_675 = "PLI8MtNNUI5qd9fmUwYbojhBTvCVsa5q8g"
YOUTUBE_playlist_ID_676 = "PLqNfG7MkYF4TqwDRT0Ds2znZKRRfk-Cii"   
YOUTUBE_playlist_ID_677 = "PL36C1AB4598D1D6E0"
YOUTUBE_playlist_ID_678 = "PLMek14-zzEgpO3gPtMVP5mZ3bY-_7jzyp"   
YOUTUBE_playlist_ID_679 = "PL2F3D9D5CDC929969"
YOUTUBE_playlist_ID_680 = "PLnb8ASKvc3brmz0JCNqUQrHMiN_LvdfAa"   
YOUTUBE_playlist_ID_681 = "PL-w1scsQWbsCeg0Xeuz8jRWRj57FN5NWU"
YOUTUBE_playlist_ID_682 = "PL903AB6E90F0C05C1"   
YOUTUBE_playlist_ID_683 = "PL5FavRDVwIUczTwwmChgKgRb0WUgB1RJu" 
YOUTUBE_playlist_ID_684 = "PL08E5A931969FAE33"   
YOUTUBE_playlist_ID_685 = "PLT3jPiiJVnNwhRPaNJiXq6y5thiJT1GkJ"
YOUTUBE_playlist_ID_686 = "PLWCK6Fe5em8pcVxEgpEbM_xcYkoA95Z5m"   
YOUTUBE_playlist_ID_687 = "PL68E9C1298316FBC1"
YOUTUBE_playlist_ID_688 = "PLIU2bME9Y9VJsj2Md5SrYrTc_IsJNrPor"   
YOUTUBE_playlist_ID_689 = "PLUSXqs2WFqIhTLaGJc8RmdGQk0PlpqgXJ"
YOUTUBE_playlist_ID_690 = "PL4iSbgi3WlCriOp4g1qpDJQfmzb9oxkyO"   
YOUTUBE_playlist_ID_691 = "PLq2gWxF1AQDdhDOo5Fr75bpKsunQX55x3"
YOUTUBE_playlist_ID_692 = "PL8f6c6AFUt48ejXRzYp4cyEpv_pPC8rkO"   
YOUTUBE_playlist_ID_693 = "PLTd0UV9qLw0sVWzB342I7dIrtfhK5MTWl" 
YOUTUBE_playlist_ID_694 = "PLvaR-bXAegf5H5-MLUCYBR_zHcU6miq1N"   
YOUTUBE_playlist_ID_695 = "PLjKM2dWFYnoFxiHDjRn0BwmBDF1Wv-MDq"
YOUTUBE_playlist_ID_696 = "PLgaFNC_I_Zkn022HM2tSAiBjFhoZ7X00Y"   
YOUTUBE_playlist_ID_697 = "PLpNEacmt9QefXKUqAGGJslFpPsu9syPZz"
YOUTUBE_playlist_ID_698 = "PLIOQZnD6ykX8MKoFShSE1ZwtJfbVSdj-V"   
YOUTUBE_playlist_ID_699 = "PLC942ECF206D3047A"
YOUTUBE_playlist_ID_700 = "PLgaFNC_I_ZkmdKJu6wanGJgL-CWIjLV5m"   
YOUTUBE_playlist_ID_701 = "PLrkgxVsNPCm0ES1fnu8A14zZ3G0KfYLM6"
YOUTUBE_playlist_ID_702 = "PLRopznIfpLoPgiqAa0i2BhWViTXO5yBmf"   
YOUTUBE_playlist_ID_703 = "PL983B6E5F827FC718" 
YOUTUBE_playlist_ID_704 = "PLD530A8AEC1D0B070"   
YOUTUBE_playlist_ID_705 = "PLE2EA015F849CAE94"
YOUTUBE_playlist_ID_706 = "PLgaFNC_I_ZknsgfpNIoqdvv8AszB22gYD"   
YOUTUBE_playlist_ID_707 = "PLjQExzw340hq-FQv6VfkYla6T-lmnwcxx"
YOUTUBE_playlist_ID_708 = "PL1B43446B8AA785CA"   
YOUTUBE_playlist_ID_709 = "PLBPtLcRsy03T4CKNVhilT7i-wT1Eb58D1"
YOUTUBE_playlist_ID_710 = "PLq3nnug85hZ_0_GjdnJO57MDGRuI7TaHZ"   
YOUTUBE_playlist_ID_711 = "PL_aXlC0TWgsLAxQfhJVStBKMjc14MSzQ2"
YOUTUBE_playlist_ID_712 = "PLdugtpf4nXUtTjtO8cK1Uy5NqKedS_HmL"   
YOUTUBE_playlist_ID_713 = "PLA15C3E2A3229E42C" 
YOUTUBE_playlist_ID_714 = "PLbqlYXEyLVwaUBVAShDRFPVrhmerL-rS3"   
YOUTUBE_playlist_ID_715 = "PL856CEFDC8C9CEEED"
YOUTUBE_playlist_ID_716 = "PLFAO0bzDKkCOoK-cSKvAp3cQp0uGA_k_J"   
YOUTUBE_playlist_ID_717 = "PL04C1D0EBCBAEC3A8"
YOUTUBE_playlist_ID_718 = "PLSL9DB9AUS4PGNLfGN9PpZQYPiF4W59Bf"   
YOUTUBE_playlist_ID_719 = "PL030C18F85149D75C"
YOUTUBE_playlist_ID_720 = "PLq3UZa7STrbr-zXMD4Oz6cPxiUpmN0_NN"   
YOUTUBE_playlist_ID_721 = "PLIct3RjbpeAANVe8djWNH45djyFGGZYGQ"
YOUTUBE_playlist_ID_722 = "PL8IKhLqh-XXrETJ-DIwnIAN4k03OBJHTf"   
YOUTUBE_playlist_ID_723 = "PLCBBA692F0662D5F8" 
YOUTUBE_playlist_ID_724 = "PLHDGitQ9eGu6SdTu60bVyxkegs5Mgk2Fi"   
YOUTUBE_playlist_ID_725 = "PLG3GVypqkY2poMd2AyUF7csaPj2KeXbcx"
YOUTUBE_playlist_ID_726 = "PL-4ijB1oe7C3ms_9_3tkW1f7m1venIb7y"
YOUTUBE_playlist_ID_727 = "PLX1gr6d3ZjxwDM6MMKANf1vDPG5Nppf-S"   
YOUTUBE_playlist_ID_728 = "PL2hyCmfl0rlI-8G2jhY2-K5I8AP3du416"
YOUTUBE_playlist_ID_729 = "PLgR641Qu4bf3p48hRpWdmxeRVMW_ieMPY"   
YOUTUBE_playlist_ID_730 = "PLF0TArDuez8_p7jqCIsp8QXKJAwBAN9dz"
YOUTUBE_playlist_ID_731 = "PLA06046DFAD5A69A0"   
YOUTUBE_playlist_ID_732 = "PL5guYa2LyFUsoKwQvfTh5YEySR6_nhpPD"
YOUTUBE_playlist_ID_733 = "PLCJj1l8DJV4W8XVBcvaFg699rP8tAS2YM"   
YOUTUBE_playlist_ID_734 = "PLFpdnehinM3xwjGewxbZKC_vxbwUXbCFZ" 
YOUTUBE_playlist_ID_735 = "PLSL9DB9AUS4ODoLMRiix-IuYqE0q9suT6"   
YOUTUBE_playlist_ID_736 = "PLfvUiWXo0lNY1G-KL2YmnT-jVm-8ASUM2"
YOUTUBE_playlist_ID_737 = "PLF9B8BA2E3E965A58"   
YOUTUBE_playlist_ID_738 = "PL27722C6C387BD1BC"
YOUTUBE_playlist_ID_739 = "PL4761FA221951C3CC"   
YOUTUBE_playlist_ID_740 = "PLsMsoGh-Udmt9PrQub-8gwbDrnLURMeUk"
YOUTUBE_playlist_ID_741 = "PLC4FE9051CCAC2336"
YOUTUBE_playlist_ID_742 = "PLXLg7-un4zLht0V5WqHEBUmYMM1iiY7iL"
YOUTUBE_playlist_ID_743 = "PL1A8A014DC213C694"
YOUTUBE_playlist_ID_744 = "PLEhjGbcNZKKmzm3nSksErZpsxqQlzIg5a"
YOUTUBE_playlist_ID_745 = "PLZzaJ_W0J8_WPk0kAvcJpgcka91pHdzH1"
YOUTUBE_playlist_ID_746 = "PLA9A79E31D229A592"
YOUTUBE_playlist_ID_747 = "PLBBB011832C832399"
YOUTUBE_playlist_ID_748 = "PLH6S8OjNLi-KAFRjjpmIIeGQcdXec6yc8"
YOUTUBE_playlist_ID_749 = "PLZKmHwHiCfdhutmmIHDjO8jjSGi_BR_DI"
YOUTUBE_playlist_ID_750 = "PL733C52962D34DD03"
YOUTUBE_playlist_ID_751 = "PL95A15ED812807709"
YOUTUBE_playlist_ID_752 = "PLB10E5F2DF4BEEBB7"
YOUTUBE_playlist_ID_753 = "PLXFmxHZkOXBQGgSDLF7Gl7OSm2xBKKNXE"
YOUTUBE_playlist_ID_754 = "PLTOTrTwbLEwy5SgOs7fAxscaGS1tgoC3k"
YOUTUBE_playlist_ID_755 = "PLE40BA45092971353"
YOUTUBE_playlist_ID_756 = "PLSrhq7smj0Eg3yVtb3l5JJERjkuRaP_EE"
YOUTUBE_playlist_ID_757 = "PL4974F92B0C4400C6"
YOUTUBE_playlist_ID_758 = "PL952F5C6F5CD939B3"
YOUTUBE_playlist_ID_759 = "PLzpD5NdyFndU-s5FkBkxLu--W6YQW0xHt"
YOUTUBE_playlist_ID_760 = "PL0ezOkP3idheid0vAILgQ4s7IF3p8wi4v"
YOUTUBE_playlist_ID_761 = "PLt4bWvuRKY7rgbC7FVEqo-goBOqCbdRzZ"
YOUTUBE_playlist_ID_762 = "PLF93038D28B86F5FC"
YOUTUBE_playlist_ID_763 = "PL257F41C824F36158"
YOUTUBE_playlist_ID_764 = "PLzgz4kdV9Q1cS667NWRJLFDuuaXzNZIWQ"
YOUTUBE_playlist_ID_765 = "PLdzn2ZZLbKUl3Wv9v4IqfhX1dHhn_RnT5"
YOUTUBE_playlist_ID_766 = "PL5O3ht-VB6nV8LJmwZk3_JysCPJ-zJSl-"
YOUTUBE_playlist_ID_767 = "PLqrtG-YCnduQnle82nh96PxJ8D4E_VDh9"
YOUTUBE_playlist_ID_768 = "PLflw2XDAAuXWW-zL023zAwNsSkwfXDLwh"
YOUTUBE_playlist_ID_769 = "PLuFQaSjRBUhfePVXV__Z2GvumJ9O3WEps"
YOUTUBE_playlist_ID_770 = "PL92204F8189294D47" 
YOUTUBE_playlist_ID_771 = "PLM1LP6GfV7JdVZjPj5aLjfXQ88sdvvW53"   
YOUTUBE_playlist_ID_772 = "PLMtMLDBXQQVeeHifhdYXza6km5tz9bh6l"   
YOUTUBE_playlist_ID_773 = "PLjTV5wdvls-C5q5-71AhA755ZGW_eEuBb"   
YOUTUBE_playlist_ID_774 = "PLHoSlpUeqEBYxVHF0CmaUgpTsH6iNL0KF"   
YOUTUBE_playlist_ID_775 = "PLMNEQBNBjMhcdEkbjo94NSQC9Ys4dIbQW"   
YOUTUBE_playlist_ID_776 = "PLB7FADBE56783CC04"   
YOUTUBE_playlist_ID_777 = "PLYpSGz0mnDA888Hw1gM3vuxIbBmuciISV"   
YOUTUBE_playlist_ID_778 = "PLtclzMEXudoO2IkcSwgSLTdRAVwsXh7Se"   
YOUTUBE_playlist_ID_779 = "PL25A589B565F2FC69"   
YOUTUBE_playlist_ID_780 = "PL1xm0HhIaKcFwrrwt0yAiy3AJIKA_AA1U" 
YOUTUBE_playlist_ID_781 = "PL449BB2C50DD94AC5"   
YOUTUBE_playlist_ID_782 = "PLdJH-4R-OLjWZk-ElyB6e3X0Cc395I475"   
YOUTUBE_playlist_ID_783 = "PLDyCcI2Pa72K8qTqzTHcrUTR_NMJnL2W1"   
YOUTUBE_playlist_ID_784 = "PL50C4B0A86A42D7BF"   
YOUTUBE_playlist_ID_785 = "PL0v0nuXIA33xLwgYJe0DOAaVzkEMc2XS-"   
YOUTUBE_playlist_ID_786 = "PLSc5JPCCNTDb1MF13lwdxa3C5f6ElEQXX"   
YOUTUBE_playlist_ID_787 = "PLA9D8EBAB45DB0115"   
YOUTUBE_playlist_ID_788 = "PL-_ExPdixCt9hR4TlCUDgiZHnFZ2RJC3f"   
YOUTUBE_playlist_ID_789 = "PL6BA41BB6B0C89083"   
YOUTUBE_playlist_ID_790 = "PLYTqxyRluxNndnxw9waAjeOvk_XvZGowx" 
YOUTUBE_playlist_ID_791 = "PLEsJur9Rh_G6DtavEXmN7OMclhJF8-e2u"   
YOUTUBE_playlist_ID_792 = "PLMEZyDHJojxMDujaVi1khrX0or8I_a8mx"   
YOUTUBE_playlist_ID_793 = "PL_9gWeiShHFFBW6LhQiJ2lnPozsfgwzUO"   
YOUTUBE_playlist_ID_794 = "PLDyfRRkF2Y6ObwH_-V1dpWHlf4Dszu6Zv"   
YOUTUBE_playlist_ID_795 = "PLXSiR52wwCWzji6fD0OtTj_LI3SnbL0KO"   
YOUTUBE_playlist_ID_796 = "PLfSYPN11_s4FegcwNEnPee5tgr2QRhV6Y"   
YOUTUBE_playlist_ID_797 = "PLE1B7BED53FD3B3E6"   
YOUTUBE_playlist_ID_798 = "PL5C9501A378FAA476"   
YOUTUBE_playlist_ID_799 = "PLnA6Y-Wqpx66R5BsVVy2pLmqMvxuZnPol"   
YOUTUBE_playlist_ID_800 = "PLE72125CC502C748B" 
YOUTUBE_playlist_ID_801 = "PLXn5r9ihuvhRMWticQbeqWECDY-EB3im1"   
YOUTUBE_playlist_ID_802 = "PLfSYPN11_s4Esnok-rH7hgVgDQk0JjDKF"   
YOUTUBE_playlist_ID_803 = "PLl7uS-1rp5S452zXh92EvtMDllDV2qAxy"   
YOUTUBE_playlist_ID_804 = "PL3jrk2cq79_EYyiP8U_N2LjSWFT3qwTqj"   
YOUTUBE_playlist_ID_805 = "PLr3UvFb3bkD7dRNxagW_OZM6UrrEyD2xS"   
YOUTUBE_playlist_ID_806 = "PLQlc99hV-nkGAtmIKYFAsnehFnwF0p87e"   
YOUTUBE_playlist_ID_807 = "PL5yA2ibfTtnEaddomUhGPiWV2XDklPmQf"   
YOUTUBE_playlist_ID_808 = "PLDubqQ-R-VxB8arUSc0U2mfYdJcLqnks0"   
YOUTUBE_playlist_ID_809 = "PL7CV-qEhzNJ6vm3KHbK5wV4mdTXDQYk6s"   
YOUTUBE_playlist_ID_810 = "PL8A67CEC3FAD066B8" 
YOUTUBE_playlist_ID_811 = "PLIrvULNMSxGPoQSK7uPOMXtNyEpZrXdjf"   
YOUTUBE_playlist_ID_812 = "PL624767FB619A346D"   
YOUTUBE_playlist_ID_813 = "PLFC1AFBBC38154C32"   
YOUTUBE_playlist_ID_814 = "PLoygUeuCex2gvrSL5nJFopG36KWd0BWll"   
YOUTUBE_playlist_ID_815 = "PLR2RBbO6sIzjqhK4q5v6WL1tPJFiatGaO"   
YOUTUBE_playlist_ID_816 = "PLB79poWK821MG35rjCrDwH4hvuFQx1yQy"   
YOUTUBE_playlist_ID_817 = "PLE5A467F67D461DCF"   
YOUTUBE_playlist_ID_818 = "PLAA1B1B6D3AF706A9"   
YOUTUBE_playlist_ID_819 = "PL61144845291D4650"   
YOUTUBE_playlist_ID_820 = "PL3D843DB0D4D9AC00" 
YOUTUBE_playlist_ID_821 = "PLVmxZ3wfYMNN_hB1StExTK_dUIGMVRAQ5"   
YOUTUBE_playlist_ID_822 = "PLD1C081C1FA886F0C"   
YOUTUBE_playlist_ID_823 = "PLGmJ0IGDH_lcbosqHegy-AruuIqERG8-j"   
YOUTUBE_playlist_ID_824 = "PLDE2957AF0B2AC28F"   
YOUTUBE_playlist_ID_825 = "PL843C2660DD8814CF"   
YOUTUBE_playlist_ID_826 = "PL8DF60C9E701D8ED0"   
YOUTUBE_playlist_ID_827 = "PLFF3CFBD9770F8C45"   
YOUTUBE_playlist_ID_828 = "PLQ5UNwxskwU1rjGA4Febh-1YUeO1H6uOD"   
YOUTUBE_playlist_ID_829 = "PLxQNgJNg1CIv7YnsI7JxaQlmaD1hQaCrk"   
YOUTUBE_playlist_ID_830 = "PLIWJsSfa4QPk7ObsuHttEuBsRzfE1k2ro" 
YOUTUBE_playlist_ID_831 = "PLx10nwpLt54znz8wozgZj87tu93tUO4nT"   
YOUTUBE_playlist_ID_832 = "PLqI2IcGTM1q4ZBtyh51wbupl6zVeB8Oc-"   
YOUTUBE_playlist_ID_833 = "PLRhPRSCaz7XdTa-lofBTGed1IOdn0ickq"   
YOUTUBE_playlist_ID_834 = "PL1D4B1A8FD81C9442"   
YOUTUBE_playlist_ID_835 = "PL08EC2C91BD4CED55"   
YOUTUBE_playlist_ID_836 = "PLj8mOOREvDnyhCls7VPGzdQuwip9kGsTh"   
YOUTUBE_playlist_ID_837 = "PLolCpOqwOBfGiKdj1O8tUuV5jzkh4OXdu"   
YOUTUBE_playlist_ID_838 = "PLFJSWWp0pAk_3bl0-XoObeTXL1GqvRFym"   
YOUTUBE_playlist_ID_839 = "PLMNvPSb4oFOM7IyI3LaCfzhEyzTmz5EsW"   
YOUTUBE_playlist_ID_840 = "PL8TG7jA9ZbdJMjt4ByApRGS0gKc1PyPDV" 
YOUTUBE_playlist_ID_841 = "PLAJu1W28bRBhrAr2O10KmApqb8GMcs5pk"   
YOUTUBE_playlist_ID_842 = "PLpopjJkKoy9VveclhuJiXg5VHAV4-EhGE"   
YOUTUBE_playlist_ID_843 = "PLFE9297A9ACDF3F80"   
YOUTUBE_playlist_ID_844 = "PLF6tCPFECd8UJPtBg088faYLSLKsRh01p"   
YOUTUBE_playlist_ID_845 = "PLdfPuC71j6-94oxRo_atlH4LajRAGGcVu"   
YOUTUBE_playlist_ID_846 = "PLTk_u32vpQqDn25WMhz6fJTfqWfuyRD4D"   
YOUTUBE_playlist_ID_847 = "PLA683A37BE06FC64F"   
YOUTUBE_playlist_ID_848 = "PLI-525h03owp-fmicb_R0i6HjxvamkM9A"   
YOUTUBE_playlist_ID_849 = "PL5D4336DC0A01FA25"   
YOUTUBE_playlist_ID_850 = "PLKlKSaWRYgpbENp69lFfYjrsYXWJjLthM" 
YOUTUBE_playlist_ID_851 = "PL1ibwSHps0sIGfYBgJV-tcWt76eDgoUTN"   
YOUTUBE_playlist_ID_852 = "PLlYKDqBVDxX0t8cvQEj9dWDOuFU56-t42"   
YOUTUBE_playlist_ID_853 = "PLBmxknpG3y7BI8lyEaISrwAacrd77c59E"   
YOUTUBE_playlist_ID_854 = "PLDG3AhsFOBfko0H16b24uJwseQXkNrkbG"   
YOUTUBE_playlist_ID_855 = "PLWivsFZIwM0U7KXnt4g4axSb0OF6LWX7W"   
YOUTUBE_playlist_ID_856 = "PL_jnnxHWt3nADMuCyM6-EITVtpb5zUx7r"   
YOUTUBE_playlist_ID_857 = "PL_jnnxHWt3nBqAJPmzBSsrqKm5LtfEo8g"   
YOUTUBE_playlist_ID_858 = "PLCmpzD-ZrB4_M41-HtYA4fLqhyIsVLQwV"   
YOUTUBE_playlist_ID_859 = "PLFmmjP1mv-WMxG1BmXtOYeDsrRzrAVX-i"   
YOUTUBE_playlist_ID_860 = "PLH0QVvcb7KpZkuwsClF5T5F2TThK2XfHV" 
YOUTUBE_playlist_ID_861 = "PL-P3RRVSsGQBVhhBtVB7KLMdjuqN75wOO"   
YOUTUBE_playlist_ID_862 = "PLabMMFz8p36w5WycqDk00Ad2o0dbnD-0A"   
YOUTUBE_playlist_ID_863 = "PLueuX6-zLU2IpOGPqncDbH73lU8Zk0syD"   
YOUTUBE_playlist_ID_864 = "PLeYuD_259lzxClIFL5G7jSiNozegiNePv"   
YOUTUBE_playlist_ID_865 = "PL352CF2825BFA3471"   
YOUTUBE_playlist_ID_866 = "PL40CB6A078C03A48A"   
YOUTUBE_playlist_ID_867 = "PLMEZyDHJojxNYSVgRCPt589DI5H7WT1ZK"   
YOUTUBE_playlist_ID_868 = "PL4BB898C960784057"   
YOUTUBE_playlist_ID_869 = "PL9EE4598B8AFCE7FB"   
YOUTUBE_playlist_ID_870 = "PLMWZl1IRlFVRQ6GTN1GeVwp5CnecvfwQ8" 
YOUTUBE_playlist_ID_871 = "PL_x_NGTVj4CVi-b78SCgrtLJvh95QreF1"   
YOUTUBE_playlist_ID_872 = "PL595C0EAE5E83EDBE"   
YOUTUBE_playlist_ID_873 = "PL3C28EB6AC6137143"   
YOUTUBE_playlist_ID_874 = "PLwJPGN4t3pRhAfykBFa2oi26FAYpOQXQB"   
YOUTUBE_playlist_ID_875 = "PLDXc4CKwRZofmk6hvrPONJjJlmeZdQPyO"   
YOUTUBE_playlist_ID_876 = "PLM93gi3iFlNL1h5NDYofFoMkIRsp2FqoI"   
YOUTUBE_playlist_ID_877 = "PLG9jLl6Ldd_j6LDKeymDKLFqLwoVvb1VQ"   
YOUTUBE_playlist_ID_878 = "PLzB6GWA5mO6Vnlsxkpa-BkJB15Shhg4Sk"   
YOUTUBE_playlist_ID_879 = "PLN_z8XS2l2zXPSs_T0rjWz8qifeomHJSx"   
YOUTUBE_playlist_ID_880 = "PL9k2zYTdB8GbQddJ4ePXGXJaeFZMhg_ZS" 
YOUTUBE_playlist_ID_881 = "PLE613202D0691B7C4"   
YOUTUBE_playlist_ID_882 = "PLlxZoJ4pT1jMfaBkmhHdpyeIfB8LGY3WB"   
YOUTUBE_playlist_ID_883 = "PLThtNtqL8RdnjCzuq665g7pi4zx9GdlMW"   
YOUTUBE_playlist_ID_884 = "PLZmT04GFvZNl-XLpJidmt2W5wFUqzGtq8"   
YOUTUBE_playlist_ID_885 = "PLAD4805542C9D8708"   
YOUTUBE_playlist_ID_886 = "PLyvEqC97lwBHURWht1D8ldZG2mE5kp-aI"   
YOUTUBE_playlist_ID_887 = "PLmyeaalh1F3rjxRK0rZLqgHCnE3szv2Wu"   
YOUTUBE_playlist_ID_888 = "PLRQnbVh2JwUdfOgGqoaEBdD3o4S_Yoyn8"   
YOUTUBE_playlist_ID_889 = "PLb2FuQvXntDI4jlFb8sMVDxGCyteFz1lZ"   
YOUTUBE_playlist_ID_890 = "PLyWT5KVBlb_AuuYstFqwud0D52VC-YksY" 
YOUTUBE_playlist_ID_891 = "PLgp4Ycu1qbzW9uJ6vm4dX_yRI6ETc8Y5-"   
YOUTUBE_playlist_ID_892 = "PL533790D472AC8C85"   
YOUTUBE_playlist_ID_893 = "PLgaFNC_I_Zkm-q6zhU4ygvX7ALDqC6HKC"   
YOUTUBE_playlist_ID_894 = "PL7v17bxzL4f7DWFj5q8nB8JsmxxnrqK36"   
YOUTUBE_playlist_ID_895 = "PL6UVBfc5OEfHqbREyJ14QCMJHm8FrBy7u"   
YOUTUBE_playlist_ID_896 = "PLUQz5VbHNScP4c5lTZ6JE2qDZT7RfxGhT"   
YOUTUBE_playlist_ID_897 = "PLQeyHUZdlALV1oA9UqsZ9Dr8acsYoavSJ"   
YOUTUBE_playlist_ID_898 = "PLZXDN4eBVB6k3Mhlxo8AgMwTEG1gOYkS7"   
YOUTUBE_playlist_ID_899 = "PLpC8zPSfWKG1pjqVC_95P9-b4kw1gIPYb"   
YOUTUBE_playlist_ID_900 = "PLEdCDPzRcSh5TRXpRQwVoGUQZrJAYFp8o" 
YOUTUBE_playlist_ID_901 = "PLjDhEP8zlmxVUPf23Qqc0c8xThOJDsI1t"   
YOUTUBE_playlist_ID_902 = "PLD20E28A8E87619CC"   
YOUTUBE_playlist_ID_903 = "PLoZRaD-mWONYOLfS9uGq3lIiKW2Jw0Lsx"   
YOUTUBE_playlist_ID_904 = "PL9uhVNjDtjSj5cphBcS2io8zixqCRtBhh"   
YOUTUBE_playlist_ID_905 = "PLAAnneIwIzPsw469fTxogrFl65oJoWceC"   
YOUTUBE_playlist_ID_906 = "PLkezPydZpc2tcO1zzDC1BvaqFCLyT9v3b"   
YOUTUBE_playlist_ID_907 = "PLA63C233A758D6076"   
YOUTUBE_playlist_ID_908 = "PLRVAmnwV_xPoTlLPBnhFRuek-DPUZ6iR6"   
YOUTUBE_playlist_ID_909 = "PLpUzhzPo5fw5Urg6pj6DS-7lG8_O0CNdh"   
YOUTUBE_playlist_ID_910 = "PLgaFNC_I_ZkkZLrytltg9Vc2l-osFbmJT" 
YOUTUBE_playlist_ID_911 = "PLrvDjUzY-sDBGG9UmEH0GWuzaNAB-3i4v"   
YOUTUBE_playlist_ID_912 = "PLDTdCMHdH4A6Di6mrorSuZcE-lI7b4zc3"   
YOUTUBE_playlist_ID_913 = "PL6OK0Uib9rrGnz971L94VESmS1_pHwW7I"   
YOUTUBE_playlist_ID_914 = "PLu6DjUst9TC-BX84L1f2ULQfz4tuYF-Rk"   
YOUTUBE_playlist_ID_915 = "PLfgfIhAtbqn5wnnNeU_qcbSvjQLWFtKp1"   
YOUTUBE_playlist_ID_916 = "PLLLhuJu85wZR8ght8_2B9xb4FB0jSDZ31"   
YOUTUBE_playlist_ID_917 = "PLsaGX6Uw7uFm9EXd-Qx5u0AD6AE7hGzxx"   
YOUTUBE_playlist_ID_918 = "PLgaFNC_I_ZkkKiRN_a3ItmBbHRV89VN9g"   
YOUTUBE_playlist_ID_919 = "PL1s6vseht7yhaFjgmHNuKV3570o3Ib85N"   
YOUTUBE_playlist_ID_920 = "PL51E39FC5D213FBEB" 
YOUTUBE_playlist_ID_921 = "PLe9C5cUN9NgyRtM7RUqcR3S0s5HMnA1h3"   
YOUTUBE_playlist_ID_922 = "PLiqf97Dv46CVK6YYtZbVc5sUiHEYRzh_g"   
YOUTUBE_playlist_ID_923 = "PLL2nNSAxt-mhCRwTo6Prdc3MhCY_CupXO"   
YOUTUBE_playlist_ID_924 = "PL-m7ZyGFP7jX50sYVlmK5yjFJu3BQVlPk"   
YOUTUBE_playlist_ID_925 = "PLu6ujs-MXVLTp5Ng-AZdyaIAU_mrDWmri"   
YOUTUBE_playlist_ID_926 = "PLAGkaL8jbQzuegH3leu0x1wxImj6ALoWI"   
YOUTUBE_playlist_ID_927 = "PL4AkmP8nSNtdOZiHk_QeWe2xksXH0jPzF"   
YOUTUBE_playlist_ID_928 = "PLtc4Iq4UF2ez95ILYNv8ZK37ga-FRNGue"   
YOUTUBE_playlist_ID_929 = "PLth83N5hQjV2oDEIBo8B53D9q6s04hAtK"   
YOUTUBE_playlist_ID_930 = "PL22p7Vvu62x4e8oa08YdHbbbtKMfGEjzT" 
YOUTUBE_playlist_ID_931 = "PLmN3phrn6M5e7nFCfnqhwz4pWRjeBShLb"   
YOUTUBE_playlist_ID_932 = "PLDF0CoX5-58eE5bEMZ7JFTaOgGcmZu02j"   
YOUTUBE_playlist_ID_933 = "PLd_Hyf7cAmczPPAmqMF03eFaggN4rgh6U"   
YOUTUBE_playlist_ID_934 = "PL204CAAC099086211"   
YOUTUBE_playlist_ID_935 = "PLyl5SvWL0lfUifH4kZkg_v-FFj9uEHLZM"   
YOUTUBE_playlist_ID_936 = "PLlXAHIGM-SaT0Uq3yN6veMKivw0qo70Fl"   
YOUTUBE_playlist_ID_937 = "PL8y5PRT4qMfXwrtTz0IloEt1Gw0vA1vq7"   
YOUTUBE_playlist_ID_938 = "PLC0Nw2XOS_ZvVT5oUVuCrXRdWeZprPK8D"   
YOUTUBE_playlist_ID_939 = "PL4XkN68JZz_7vp6_TXZiVURi2JDqrkdpf"   
YOUTUBE_playlist_ID_940 = "PLgCCf1Nshf1FYuYILPW5NAc1SYrzv8A5K" 
YOUTUBE_playlist_ID_941 = "PLpEFNVijk8h6wAb_8zSwuWHWkDqGG3dTB"   
YOUTUBE_playlist_ID_942 = "PL5CbxAYfnSFg6IG1OGzosV0-2v30K4S_b"   
YOUTUBE_playlist_ID_943 = "PLAEEFAE742E0670DB"   
YOUTUBE_playlist_ID_944 = "PL4iSbgi3WlCr0iujW1cMG_dD5fYgcnvEV"   
YOUTUBE_playlist_ID_945 = "PLMjBa4ZN_cwUzdMVF703uNCs5KgDhUyJf"   
YOUTUBE_playlist_ID_946 = "PL74A234653048D668"   
YOUTUBE_playlist_ID_947 = "PLC2FLk4zx0stEunmH-1P3bkijL6GTtcYw"   
YOUTUBE_playlist_ID_948 = "PL8227EA40FB9249B9"   
YOUTUBE_playlist_ID_949 = "PLZx3HiSUMN0F0YbYAgClfDe3KTIVQUmj8"   
YOUTUBE_playlist_ID_950 = "PLgznCdefxauSP2ACrJTWIkJ1KZtQhLdqF" 
YOUTUBE_playlist_ID_951 = "PLmfNQTRXX0zRQ6Dw7HO8SpbhDriNt3RRq"   
YOUTUBE_playlist_ID_952 = "PLntV9JesN1ApATLyfdD-KiZNtAr0u7RLY"   
YOUTUBE_playlist_ID_953 = "PLCSm0FAKsxtOUHg9ct89hbf3u233Wz7OB"   
YOUTUBE_playlist_ID_954 = "PLc-Lq9nrVmz9WJRGRaltWQk6Gl7jwHGMC"   
YOUTUBE_playlist_ID_955 = "PLa-f9DwgIhfIbTLzT-WrNtoH3T_nbzkTs"   
YOUTUBE_playlist_ID_956 = "PL0GY2Y7fcnEShgR6FY0H76WziXl8_lwm4"   
YOUTUBE_playlist_ID_957 = "PLedX0vnXDBrgrr18uGcuSbfwg4JsZlj3R"   
YOUTUBE_playlist_ID_958 = "PLo4aQWg7IcDnYtOfpwOgJXXxH53ZfNIvW"   
YOUTUBE_playlist_ID_959 = "PLZV_AiwSbdsxfwc03bkHo4kevt991WQ2y"   
YOUTUBE_playlist_ID_960 = "PLmGv9yX1UoBoxcSK9AMI7ibTnIhEId9D5" 
YOUTUBE_playlist_ID_961 = "PLTpTTqrW8hdN-PAdzzkRRvs2sxae-Q19b"   
YOUTUBE_playlist_ID_962 = "PLnH4UKYlQTLVq-0oMeGUyCwBvgoTX79Oy"   
YOUTUBE_playlist_ID_963 = "PLIwcBUenQJh2NiMoG7evsD47Y63ZIbj-h"   
YOUTUBE_playlist_ID_964 = "PLY0Bn9EtirVnqduElvHWh_jR9A_8plXN2"   
YOUTUBE_playlist_ID_965 = "PLRTkTYsXpl1pQUXIqQ1RmMKoPFC-LjW7u"   
YOUTUBE_playlist_ID_966 = "PL8DTk8iG5EXM3jlcLODUwe9H6dTYFkxT2"   
YOUTUBE_playlist_ID_967 = "PLcWmrMbNDZ7dFf61yyLUdWHN9M_W5P08R"   
YOUTUBE_playlist_ID_968 = "PL35B23D5B7D4865D4"   
YOUTUBE_playlist_ID_969 = "PL4ACYR0kA2d2U28IvYT-Q5Unc7b3MvbYU"   
YOUTUBE_playlist_ID_970 = "PL0491BB6A7E461649" 
YOUTUBE_playlist_ID_971 = "PLo9pv-Oc1GGMXRNNWmHvY0YUUpHE7QdYF"   
YOUTUBE_playlist_ID_972 = "PLfmEGJYaw_lNoki7GCUDXrMk3-cBSlwE3"   
YOUTUBE_playlist_ID_973 = "PLN_z8XS2l2zVoZ22_0oNSz5JBljKW6-Tl"   
YOUTUBE_playlist_ID_974 = "PLHDGitQ9eGu5Vm-r5C8S_Yb4GIBrwBzN3"   
YOUTUBE_playlist_ID_975 = "PLCxuMuVo3Ji1EJsUqi90Bb3stg8ObZNjy"   
YOUTUBE_playlist_ID_976 = "PLkzBXrBBJ6UkZR7Bdtp37y2TfSaTLggHk"   
YOUTUBE_playlist_ID_977 = "PLpbYDibs0uQjzEbOLIHE9xSq99gBxgkx6"   
YOUTUBE_playlist_ID_978 = "PL2MbxWg6TJGcFN8_BciKJm-4SowIhEw9o"   
YOUTUBE_playlist_ID_979 = "PLaTjA_eo4JqiiW20KX_wbYHBoaEhbmhA0"   
YOUTUBE_playlist_ID_980 = "PLd39S9lhfiEoSXcvh2fjDfMaBbIEZqhuu" 
YOUTUBE_playlist_ID_981 = "PLBOZegPV1Fuu9MH0PL5bP4t7tEOxNMqA4"   
YOUTUBE_playlist_ID_982 = "PLQs7nDVDCudHzr10x3T-Ghozj20vJJfGF"   
YOUTUBE_playlist_ID_983 = "PLOPAia-eUDs-Cj42Jb5FXHbKtnDwJDw40"   
YOUTUBE_playlist_ID_984 = "PLLhkxclgl1zjMCqpJb5UfJRs4WTtsE8Ks"   
YOUTUBE_playlist_ID_985 = "PL6DC9F41EBC5695D1"   
YOUTUBE_playlist_ID_986 = "PLFqRUBPT9l0L0UxQidHsROj8xs5exGD6J"   
YOUTUBE_playlist_ID_987 = "PLxcwVrC2TW4uj3uwwXDOEHtczpVJg1fbk"   
YOUTUBE_playlist_ID_988 = "PLuw6hdbHDMSNiOibggthfZVQ_sGATwdgq"   
YOUTUBE_playlist_ID_989 = "PLkOdu5U9bGxNphzz03EJ-OKwtn0hqlPlw"   
YOUTUBE_playlist_ID_990 = "PLP2fEgVBc4_VFfH1NEMqy1_74M6q1ANQs" 
YOUTUBE_playlist_ID_991 = "PLFNoCAMwVymdXxZtcMIvy3apG8X-g9mrB"   
YOUTUBE_playlist_ID_992 = "PL_CMqaKFQK0Xm41TkqYtIwwxpQC-5JyG7"   
YOUTUBE_playlist_ID_993 = "PL941906730926CE09"   
YOUTUBE_playlist_ID_994 = "PLqK1JpL0Zp65rrcAR4RfOGE7avEE6UggD"   
YOUTUBE_playlist_ID_995 = "PLO96zX1I-x5Ofj_Bz7pcyx4CYtIi4jYtl"   
YOUTUBE_playlist_ID_996 = "PLUuWwAhDZc6eebnB_shCf0DPDHcQv9KP4"   
YOUTUBE_playlist_ID_997 = "PLeF4D7NUt1x1isHaU_DRqcJcEYw0bmaZg"   
YOUTUBE_playlist_ID_998 = "PLjshvpI5Qp6lsbHA21ieVVpuDivqDKGOd"   
YOUTUBE_playlist_ID_999 = "PL0WqteW7wC-e7P2QC2FIA5HTByN1XVuw3"   
YOUTUBE_playlist_ID_1000 = "PLvGBwysD8gAkZ0A3fz9YBhRqhuUBpciNe" 
YOUTUBE_playlist_ID_1001 = "PL_knI3N7Ki1gaD0CRq7FfQFagoEGT2tCG"   
YOUTUBE_playlist_ID_1002 = "PLtN1aXSz4ZpqKz7ChBDPgpZEDEpDW3hz5"   
YOUTUBE_playlist_ID_1003 = "PLma2LvwK0JlGBafhdMxlZZarAdSLKaqPo"   
YOUTUBE_playlist_ID_1004 = "PLxilkcayOSAwIuUBXvj1_HI7_EPUYpbaN"   
YOUTUBE_playlist_ID_1005 = "PLLQAnY3LqaeSEh6Oz5R5pEa3f8hVYbbU2"   
YOUTUBE_playlist_ID_1006 = "PLDFIq8TGPOq_aoG6Lidapn8TlyuisDH9K"   
YOUTUBE_playlist_ID_1007 = "PLCAA2C57F8096F58E"   
YOUTUBE_playlist_ID_1008 = "PLC17B77762EC1109D"   
YOUTUBE_playlist_ID_1009 = "PLFGS2gU28pXNJmpLiP9SAwAglKgZyP8zQ"   
YOUTUBE_playlist_ID_1010 = "PLPbDCq7kIJ04taAF88lMIt-I_nw5VER9Y" 
YOUTUBE_playlist_ID_1011 = "PLCFE7A119DC6FC1FD"   
YOUTUBE_playlist_ID_1012 = "PLavWFH9XM9LvI5ZBk6DhF_boGL0ZGIf5a"   
YOUTUBE_playlist_ID_1013 = "PLmETcMB5nVtgIVLtLPrhYgK8B6ILAAvP_"   
YOUTUBE_playlist_ID_1014 = "PLocMbo6dP9PpppSyRhxMvPa-sqvpoXg9G"   
YOUTUBE_playlist_ID_1015 = "PL2Wzz_MrxoUjXMhRS2Y2hoG3iMbEZYuYr"   
YOUTUBE_playlist_ID_1016 = "PLTisafcBRDNy4vtBS5nAvJniKWLPJnCB5"   
YOUTUBE_playlist_ID_1017 = "PL947422BA7A97D304"   
YOUTUBE_playlist_ID_1018 = "PL19Ovd-loeYBzp2GUGjVsthPbImRWv1Wm"   
YOUTUBE_playlist_ID_1019 = "PL-_bLiFU3R9sWBBYO1VQu_IsnHsKk5qlo"   
YOUTUBE_playlist_ID_1020 = "PLhISdUKNO2KcN1KW13t9JS6fY21RjTkOI" 
YOUTUBE_playlist_ID_1021 = "PLNsmBbzewAsWxzO_El9gGQDVwFI5kGaAT"   
YOUTUBE_playlist_ID_1022 = "PLusEeB6-zcoOw_E7FClcSVdoyGtiu8I0v"   
YOUTUBE_playlist_ID_1023 = "PLF91E3335324B926F"   
YOUTUBE_playlist_ID_1024 = "PLxdc9ROd6JXKc80pjfPIPuoAbs6MromnX"   
YOUTUBE_playlist_ID_1025 = "PL22BC7C8E89C2655E"   
YOUTUBE_playlist_ID_1026 = "PL8O5B7KPS0pltiKaE9GQnZ3Yxxof14XPd"   
YOUTUBE_playlist_ID_1027 = "PLoC5WZnjSKQQqId-2cXppEzOGHurkdNaZ"   
YOUTUBE_playlist_ID_1028 = "PLQCLiN0jQw0u-OvYfVreQ-mmyWrvsiMnJ"   
YOUTUBE_playlist_ID_1029 = "PLCxuMuVo3Ji2MpP8A74ziWSJ4Ced4kThg"   
YOUTUBE_playlist_ID_1030 = "PLgaFNC_I_Zkl_4kjo4kQgLZX4SSzSI8bt" 
YOUTUBE_playlist_ID_1031 = "PLQy4QZl60J30doDMPAlkTxz9P59Mt3izQ"   
YOUTUBE_playlist_ID_1032 = "PLisDNudppcycqikaT6LznfM1hqAe0GmD0"   
YOUTUBE_playlist_ID_1033 = "PLGJhOLrHuruq05IXLJNFpXvMYW29wtXwc"   
YOUTUBE_playlist_ID_1034 = "PL8SNORAnvzLvoqVodUxHa7v2Aqsx1oa0O"   
YOUTUBE_playlist_ID_1035 = "PLF-2eKSQhkkuDAkFz8m-48zXeoPW-Sdp4" 
YOUTUBE_playlist_ID_1036 = "PL6-2jfXgiNqTQQe-8tZzm3IacpUXS7KTq"   
YOUTUBE_playlist_ID_1037 = "PL9YJ1tlKRbtz3ylrAAz0eWy0Poz_MKzT3"   
YOUTUBE_playlist_ID_1038 = "PLkUztAN02Fp-83P8QoGZDX7r8oXt8jGat"   
YOUTUBE_playlist_ID_1039 = "PLHDtlIkLifOeGtDOcup2Qn9jv6aZx32VL"   
YOUTUBE_playlist_ID_1040 = "PLYWPugk9bQf4N4kAx-DuHYd6IORJjYQe6" 
YOUTUBE_playlist_ID_1041 = "PLOwYlH2CfhVIWsfNAxEHS-EfSrpZoA5PP"   
YOUTUBE_playlist_ID_1042 = "PL4U9m2g6lNgh2zgW6Cbe41UurBP7i66bb"   
YOUTUBE_playlist_ID_1043 = "PLRCzO0hV8FOiargo5OYoIsSOvZI1Rz626"   
YOUTUBE_playlist_ID_1044 = "PL8Lpw39GxwbMH_9K_sJvlSkGCIVGuE1tS"   
YOUTUBE_playlist_ID_1045 = "PLgaFNC_I_Zkl0RfRM7YxYMj1xrYBOB125" 
YOUTUBE_playlist_ID_1046 = "PL94FCC49BCD217A89"   
YOUTUBE_playlist_ID_1047 = "PLmxGDTmqIb19q20yXjqYz688_oVesI3q0"   
YOUTUBE_playlist_ID_1048 = "PL_5X-KjTyOvKiGcudJ9X3oe2ux30rcRl0"   
YOUTUBE_playlist_ID_1049 = "PLhtzR5XBHSgZPbzQGGycazNud5WSeXT5O"   
YOUTUBE_playlist_ID_1050 = "PLqO92MEV3QqLfSpGKNw09vsO6vrnc_YfG" 
YOUTUBE_playlist_ID_1051 = "PLUNM5xaryTUzm5KcuOgoij1lAXYguXZOC"   
YOUTUBE_playlist_ID_1052 = "PLF2651CF02AB913A4"   
YOUTUBE_playlist_ID_1053 = "PLB8B51931D47AE65D"   
YOUTUBE_playlist_ID_1054 = "PL9Xgf3SgR5diCdo9myfTZQ8S-HW4l22Ny"   
YOUTUBE_playlist_ID_1055 = "PL1EB7E715299E3775"   
YOUTUBE_playlist_ID_1056 = "PLgaFNC_I_Zknx1Sb8qCyaihymHLUoOV3B"   
YOUTUBE_playlist_ID_1057 = "PLgq5EK55CawXXCT8mUX2aPl2yi-ZtO2-d"   
YOUTUBE_playlist_ID_1058 = "PLAD07340F7B05F4B1"   
YOUTUBE_playlist_ID_1059 = "PLWcCVVqyAOowsW9RD8xR8dIDgFQ7_OozM"   
YOUTUBE_playlist_ID_1060 = "PL48D53935B3C73016"   
YOUTUBE_playlist_ID_1061 = "PLCm29Bigb6gV64kFuuqvLtV1bDsEphtuO"   
YOUTUBE_playlist_ID_1062 = "PLehJFSKeD7FCo-0aY0kIkHWa4m8OHamEs"   
YOUTUBE_playlist_ID_1063 = "PLFyU0XsyfmqdmJcbmsGamR7bwX_WfazCM"   
YOUTUBE_playlist_ID_1064 = "PL8762A02979947DD1"   
YOUTUBE_playlist_ID_1065 = "PLGYgSHwzBS9xYpwRbI0j7q_jCuIamIQri"   
YOUTUBE_playlist_ID_1066 = "PLeX6rAoLpXSQ-2qytAaUcSgQfn80poQUd"   
YOUTUBE_playlist_ID_1067 = "PLE0C7AED7E2101418"   
YOUTUBE_playlist_ID_1068 = "PLsQGWfoprxDEQmdWNUinTZaLfppw52OvF"   
YOUTUBE_playlist_ID_1069 = "PLEDKMOotPisBwh0GI--5zJlTXziaRVNoF"   
YOUTUBE_playlist_ID_1070 = "PLpwUqL0q8iXWpbNx5X7xV5mluXyBY3Jc_"   
YOUTUBE_playlist_ID_1071 = "PLRIYcO5xiIoLKIOkWFbIII5-cPh6XFPcD"   
YOUTUBE_playlist_ID_1072 = "PLaNVIxuj6soY8JkUjGUBuO_8Xs4rl_Tg6"   
YOUTUBE_playlist_ID_1073 = "PL85FC508016067D2D"   
YOUTUBE_playlist_ID_1074 = "PLuK2Kg5yHwN9x5ySgNX4FCjQlkJWQ2qA_"   
YOUTUBE_playlist_ID_1075 = "PL8cwOUNjc6YL2rU33YsuxKH5LSF6o6-_5"   
YOUTUBE_playlist_ID_1076 = "PL8x8AQzUDbhWdpjxiE02YNZykW5kLZu8Z"   
YOUTUBE_playlist_ID_1077 = "PLagY5im8_L6T5fA_L_d_Nd9NhfRWBClAn"   
YOUTUBE_playlist_ID_1078 = "PLSlwqid27iMlSW5HvlDjnLyqbBidecmW_"   
YOUTUBE_playlist_ID_1079 = "PLsgFVMpUjiKWmZGpQbkWxD_HN9FtV2xH5"   
YOUTUBE_playlist_ID_1080 = "PL_UCDs2ps_72iJhkmsAVsdz876U4yttoz"  
YOUTUBE_playlist_ID_1081 = "PLIJysqiSOsgNIJzTC5hf2bPYeG6-_DQMN"   
YOUTUBE_playlist_ID_1082 = "PLI67CujsfCpcufD29LxYjxzs2UB5HUzDF"   
YOUTUBE_playlist_ID_1083 = "PLYUR6eecHWW2UIevwbDR-N9LpQ2ayAwcm"   
YOUTUBE_playlist_ID_1084 = "PLC6CD8FD53E172500"   
YOUTUBE_playlist_ID_1085 = "PLfpcqVtfP2V5fqipgn3OXvi-OAkIwUVrt"   
YOUTUBE_playlist_ID_1086 = "PLK47FsmtihqLoAKIIPaNZuQ1JS95rGe0S"   
YOUTUBE_playlist_ID_1087 = "PLyOGegCfPqm17jHg2-qdMB10pJ5UmueGU"   
YOUTUBE_playlist_ID_1088 = "PLA-oCNyLgPKX48zgHz7Q7ft71w_u_d7X4"   
YOUTUBE_playlist_ID_1089 = "PLgZ_QT6MXq9pc27B8kf7ZWbQ1Z2KoKWqt"   
YOUTUBE_playlist_ID_1090 = "PLA_I2ay5YcUWz97BrH_lVDetmTwbdE9lM" 
YOUTUBE_playlist_ID_1091 = "PLxeSL4hoVk937JW8q1UZbT5RlO12KC3gr"   
YOUTUBE_playlist_ID_1092 = "PLF80A2CAB32733201"   
YOUTUBE_playlist_ID_1093 = "PLTRmkP4-tiXswUl4kGgpK6Pf5QZto7CUv"   
YOUTUBE_playlist_ID_1094 = "PL3jLYJ1kvUOIYxXdNqmAkZXvC9b7_Yy_R"   
YOUTUBE_playlist_ID_1095 = "PLK4Ti3PlMtWyctHdEu_cmlHWd5I-xpnxh"   
YOUTUBE_playlist_ID_1096 = "PL6Go6XFhidEAac3TgkP8EfLF1bA1odl4e"   
YOUTUBE_playlist_ID_1097 = "PLHYRFHmcFz_rdruFqNzc-Zg91Fh8qeiC9"   
YOUTUBE_playlist_ID_1098 = "PL6BA2D5208E8EF161"   
YOUTUBE_playlist_ID_1099 = "PLOFEpWbpBYr6-zRwiDAsiwoYR4B09pAc2"   
YOUTUBE_playlist_ID_1100 = "PLTeaeRnKbR9xFucmvfPtXLlWf-YR9dAZG" 
YOUTUBE_playlist_ID_1101 = "PL3UI5-gj0WvBCdIHIY-fN2jgr8x84vTb4"   
YOUTUBE_playlist_ID_1102 = "PLAITokqQcMvWb2MKHTElaRWm7Ik49LEOi"   
YOUTUBE_playlist_ID_1103 = "PL8wHqErKKi-0PTAmjP9AlnMbhLqdLIt9w"   
YOUTUBE_playlist_ID_1104 = "PLHOpTrYMfMfLYMvtXkCFS50Xgmcf94omw"   
YOUTUBE_playlist_ID_1105 = "PLt8pHT-k6LqkcTeyc6aeLIw-QGNEJtG-H"   
YOUTUBE_playlist_ID_1106 = "PL_1g7lq8HBVRFGyVRNmGdlLfugyhfMGKp"   
YOUTUBE_playlist_ID_1107 = "PL07BECC4E1568EF5F"   
YOUTUBE_playlist_ID_1108 = "PLgzgA64MLAflH_RyIf8Q3CDtIVaXUuwS_"   
YOUTUBE_playlist_ID_1109 = "PLA8_sQAcSbVCNgNuT1d3g4Q9VjR2YYOzu"   
YOUTUBE_playlist_ID_1110 = "PLSQZjlcahcheWAAV_MFC0pIroVIZjFQ4H" 
YOUTUBE_playlist_ID_1111 = "PLChOO_ZAB22UcOXiE-IO6m7Vm25to6Njg"   
YOUTUBE_playlist_ID_1112 = "PLnGdD6ZlITsnPRtYGwuLwDjZK7uPQtYNc"   
YOUTUBE_playlist_ID_1113 = "PLLmwURxBJRMvuaf5Ue9X4S-7c99cjnwk6"   
YOUTUBE_playlist_ID_1114 = "PLgGw6LIB2wogn5ePVt2YJW9m-42oDg_Wp"   
YOUTUBE_playlist_ID_1115 = "PL0Dp1fK6zSD9Jo6DlFFIfs5eU8Qd1wR_0"   
YOUTUBE_playlist_ID_1116 = "PLI1BeaYT4SFaVwSguCTZf2UO3P882egxW"   
YOUTUBE_playlist_ID_1117 = "PL84BCB47564F4DDC3"   
YOUTUBE_playlist_ID_1118 = "PLD9CAA39E6DB9CCC3"   
YOUTUBE_playlist_ID_1119 = "PLJDnUUz3gI6E15I2PkI0-iT_2riy9SW0J"   
YOUTUBE_playlist_ID_1120 = "PLrgbKRCqJ2bL-CcsJRV_T9D6--2sCUPV5" 
YOUTUBE_playlist_ID_1121 = "PLygDZn1BzPDeErpTzozWgmNhOJnLcREcD"   
YOUTUBE_playlist_ID_1122 = "PL7TVsaB-TOLBdQWsN9hDvPfUEQtmuY8HM"   
YOUTUBE_playlist_ID_1123 = "PLziNY3qR9iQy49ShCCCHEVnJji1LMuY1N"   
YOUTUBE_playlist_ID_1124 = "PLlchP7ps9yfxdlSyCwLIbxzNqFsCGELws"   
YOUTUBE_playlist_ID_1125 = "PLtk613JAtMIwm46caj-3i5muGiusDIjdZ"   
YOUTUBE_playlist_ID_1126 = "PLZd3dC8rYO8ymw6bOuGMYbe1x4MtXoOYS"   
YOUTUBE_playlist_ID_1127 = "PLDrdOrOLwED2tMwzNfaQVvEaYqgXbRuKS"   
YOUTUBE_playlist_ID_1128 = "PLD73FDCF8CCBEC29F"   
YOUTUBE_playlist_ID_1129 = "PLMUBYC4a6U2S0zbASDYalJyAjEwR4zBti"   
YOUTUBE_playlist_ID_1130 = "PLYABfwzAmpjl-mtEf_6WFdwsEHBRkVlCS" 
YOUTUBE_playlist_ID_1131 = "PLatVVYrXXlDs1t_xLjPs_cC3fmSBwEaqm"   
YOUTUBE_playlist_ID_1132 = "PLV8lPR63aoMKYnm2aKskTEOcd694uypjw"   
YOUTUBE_playlist_ID_1133 = "PLL6TgT49BYvaLBiAIocG6uUsf8vl7_axi"   
YOUTUBE_playlist_ID_1134 = "PL1qSKrggG7Orucb6kQmfTXnGafR1nqCda"   
YOUTUBE_playlist_ID_1135 = "PLWSRI9KMbUmnk6PoNL3Wmv7mbrkSLvnl7"   
YOUTUBE_playlist_ID_1136 = "PLrNKAW0E0mM1Vl3vaR5oC1dkGTxL3aWVO"   
YOUTUBE_playlist_ID_1137 = "PLiDpep_u5jLK53qDWKiwx_tSPg9jHgbyY"   
YOUTUBE_playlist_ID_1138 = "PL10C27VxGHDEI0ZL_yAMvP68XRuZM24kP"   
YOUTUBE_playlist_ID_1139 = "PLq3UZa7STrbp6kyiLTwlOXOUNEVcEXHY9"   
YOUTUBE_playlist_ID_1140 = "PL38F4DCD598EBCDD6" 
YOUTUBE_playlist_ID_1141 = "PL34BEA9B52242CBFB"   
YOUTUBE_playlist_ID_1142 = "PLeaYKw6gQbjQUuimUelQ1zQgxpejEmtcV"   
YOUTUBE_playlist_ID_1143 = "PL00XcJG91ZUbepVYmLs2djUEDlp1R8EYb"   
YOUTUBE_playlist_ID_1144 = "PL3600889A2193083B"   
YOUTUBE_playlist_ID_1145 = "PL4ACEAD2A8837B687"   
YOUTUBE_playlist_ID_1146 = "PLnRZGUriFBj886ChvIdbkG4zklW0Xs952"   
YOUTUBE_playlist_ID_1147 = "PLkPTL8lnTQA5Y7zVyzGadoKlqcTRAWeKJ"   
YOUTUBE_playlist_ID_1148 = "PLByxupJNIe_XjtqYVl3bYtPFlg9FTbHnr"   
YOUTUBE_playlist_ID_1149 = "PLg4zyOT_3ldsMbv4ig9cQj6bDaLjunC-A"   
YOUTUBE_playlist_ID_1150 = "PLKvRCAsipHcJJn5KlZ1QBE-P6IxOdlhwf" 
YOUTUBE_playlist_ID_1151 = "PLxzjUXzGMDS83UI46xdy99dPP9OQOh0aT"   
YOUTUBE_playlist_ID_1152 = "PLOf3rBvWZTs_dDi6Go1nlA2mV14JytwAv"   
YOUTUBE_playlist_ID_1153 = "PLofwqNdQp_AYJJAPMsYki1Uy3qN4em2oI"   
YOUTUBE_playlist_ID_1154 = "PLcLgNr_gjdwO1Y5GSvbGlGPYwmpD4E-Nc"   
YOUTUBE_playlist_ID_1155 = "PLC40CE70DA3015A4E"   
YOUTUBE_playlist_ID_1156 = "PLTdORzsu5thidba5k5-81mLKfV33U2r_n"   
YOUTUBE_playlist_ID_1157 = "PL835C311FDBF98B2B"   
YOUTUBE_playlist_ID_1158 = "PL4ICqfZ_l0lQ0aoV9oG8VU_q6vbg7oL9F"   
YOUTUBE_playlist_ID_1159 = "PLkD6r9YanmmMd4Q9wUA6QBXGpHRL40EF5"   
YOUTUBE_playlist_ID_1160 = "PLuXwp4uKv0wnubLxsz1KyBdrZ8BroJTGs" 
YOUTUBE_playlist_ID_1161 = "PLwqlyURt96bUY13QS3PTcxLRAigiFzvl9"   
YOUTUBE_playlist_ID_1162 = "PL7ISveU6ibsFWYONfVnz6d4mv25QGVNz8"   
YOUTUBE_playlist_ID_1163 = "PLC878J8mcBo-yU6_UdzE3GEJAi3NrdWXT"   
YOUTUBE_playlist_ID_1164 = "PLyIuKYSnN1TXT5c_ZaLnW1D73iPLbw4uK"   
YOUTUBE_playlist_ID_1165 = "PL9YcpEC7d88iCfJrG8AgaRs9Y3Y8bxCsa"   
YOUTUBE_playlist_ID_1166 = "PLa8P5V54klI-txfrdUVISrp9Qw9fFbkSt"   
YOUTUBE_playlist_ID_1167 = "PLLpdh6O1k23Jzd7ZZ5xt-CCBxTyGZm_qn"   
YOUTUBE_playlist_ID_1168 = "PLuyHTSbLRWiLRheK1v41-AdJdsxzoTz1m"   
YOUTUBE_playlist_ID_1169 = "PLxBVOrLJbZDzQC4TXhc6DKhNN0raiwNc_"   
YOUTUBE_playlist_ID_1170 = "PLDX2twDF5Mc-d0D2yv8xVbk40Ba3I4HP1" 
YOUTUBE_playlist_ID_1171 = "PL67DNDN0TrggTYXEtN7dwKw4aalysmIg_"   
YOUTUBE_playlist_ID_1172 = "PL1kArxBrKiWXii53D-gPVW7631o42aqwo"   
YOUTUBE_playlist_ID_1173 = "PL4AxXiSf3YgCPsKjsNpCxciXPijgeW1Dc"   
YOUTUBE_playlist_ID_1174 = "PLaGGSI0tNMtBLGTRyvIl0j5DfDMp4TWvu"   
YOUTUBE_playlist_ID_1175 = "PLrJzw1v-HLz1WkzWehRyhAMsCUsuKe6On"   
YOUTUBE_playlist_ID_1176 = "PLA_4FyApymnBtrQBYsdruNsd26fyKacKy"   
YOUTUBE_playlist_ID_1177 = "PL8Q_dSJ-3l5Wyb--Uaija8Z614PMR0qIf"   
YOUTUBE_playlist_ID_1178 = "PLjcZwpsKoeKDsx6psYB2comYLWS7d3LS5"   
YOUTUBE_playlist_ID_1179 = "PL0X6k9ILt02rlDugnJT2sn3XIIqL_K67P"   
YOUTUBE_playlist_ID_1180 = "PLzuBdlWK2WvohU40fjVqalxMC3qkd9A_3" 
YOUTUBE_playlist_ID_1181 = "PLKrz8KRZKZLZ1zCIZ0OLe9O19EpAAsdfc"   
YOUTUBE_playlist_ID_1182 = "PL3D7DC18D00EF6C64"   
YOUTUBE_playlist_ID_1183 = "PL7F88D562E4741C5C"   
YOUTUBE_playlist_ID_1184 = "PLfdMKJMGPPtyHB_z1Hgk-OmD3Q5e3jKvO"   
YOUTUBE_playlist_ID_1185 = "PLeb7aQ6syOgMNuIvR-oMsLCS0RfirfONJ"   
YOUTUBE_playlist_ID_1186 = "PLvn5cvVAtp2JtmPoTRc6_y_AR1SUJtXhY"   
YOUTUBE_playlist_ID_1187 = "PLBDRSEH8ze7dfAZ_7XqQ0VORi2XJvdCtq"   
YOUTUBE_playlist_ID_1188 = "PLD1EF389AED0BBAD2"   
YOUTUBE_playlist_ID_1189 = "PLxcovp0zM3gvvvnYfFYAn29q_j-d8VQ-g"   
YOUTUBE_playlist_ID_1190 = "PLh5SyQNqWvpHD3TZ205w2c6FZrApw4l2F" 
YOUTUBE_playlist_ID_1191 = "PLly8yZzXC2MXObuR50pLAs1C_K3gyUFgY"   
YOUTUBE_playlist_ID_1192 = "PLBj3Tu_VQhkysptvDwc2auO58c3Q0EP14"   
YOUTUBE_playlist_ID_1193 = "PLu_8VmS5nqKq9kIR4NsyNExYgEE_hF6wX"   
YOUTUBE_playlist_ID_1194 = "PLGEDwqYmb0hIFEuWQiatpmJORO0pZh9_3"   
YOUTUBE_playlist_ID_1195 = "PLW-nErPmxkyOg6_NiyFdSTSiXGHOtmNYk"   
YOUTUBE_playlist_ID_1196 = "PL85F853286DC3AB2C"   
YOUTUBE_playlist_ID_1197 = "PLPJ39xemDS4Y5wEKUNPW8hixXufevNusp"   
YOUTUBE_playlist_ID_1198 = "PLC_gaI84Nx3CGUBsZdSXJtQsLA3a4c4FU"   
YOUTUBE_playlist_ID_1199 = "PLe14d9MkwdqQ2pj6Gj_dQq9auQKrz0dSO"   
YOUTUBE_playlist_ID_1200 = "PLW6hj213AelOBblUMfijIQxqvQd3izijR" 
YOUTUBE_playlist_ID_1201 = "PLwpIV9v0PFM_xcMEATiXa8owz3qGZQWLS"   
YOUTUBE_playlist_ID_1202 = "PL0ASIhAbDrU6eYwaEK0U1LGuq1GJzkV6T"   
YOUTUBE_playlist_ID_1203 = "PLHayQ_hM_CcMixqeTukA7tuzgyeRYALK-"   
YOUTUBE_playlist_ID_1204 = "PLXo30vH6f-A9se4f8EHdaeloUv9G2meBN"   
YOUTUBE_playlist_ID_1205 = "PL-YjjG703PSg9aiH0N0iRd1e4LFCl_dys"   
YOUTUBE_playlist_ID_1206 = "PLm-hrdJiJCG7oR75T09k-OgBr8zcmvW2E"   
YOUTUBE_playlist_ID_1207 = "PLdge6INLY8FI8wX2sFEzDauFvZ0rGbH2k"   
YOUTUBE_playlist_ID_1208 = "PLBzSXRAvvknq-FUxjNN5j2M58oxl6VU27"   
YOUTUBE_playlist_ID_1209 = "PLwoPg1LAbKSJZBH4KFMT6mcVJek2l00aK"   
YOUTUBE_playlist_ID_1210 = "PLzgux70PySPfQi68w4ZpiFqScR_ncoVlL" 
YOUTUBE_playlist_ID_1211 = "PLQZZ3cBhNF5s9ozv3qdoxZXti6cryXcuC"   
YOUTUBE_playlist_ID_1212 = "PLKABLF664tVhyT6_aSBStAwTcc3z5emgM"   
YOUTUBE_playlist_ID_1213 = "PLbAh-NRTtgR8J_AS5FNaW11GUAjaUyxQd"   
YOUTUBE_playlist_ID_1214 = "PL4ebZXwpTilpNRRNnrPYoRRucYHZbC5KK"   
YOUTUBE_playlist_ID_1215 = "PL4JhlwXrt0vli7DcpbFoij60nSTIW_QDv"   
YOUTUBE_playlist_ID_1216 = "PLkf6p6Aix3hIxQ5k4WI7ErdhM0c2YF7k6"   
YOUTUBE_playlist_ID_1217 = "PLccmC0-jXVkiQF1uMehdwqSlpXafNAe_e"   
YOUTUBE_playlist_ID_1218 = "PLBe2RLwH_ZnVxQ3mbPs3-ELGkO7Xvn2Eh"   
YOUTUBE_playlist_ID_1219 = "PLDSwJEKOvvWMIrTFJd4SLXtgzwx35Tl-B"   
YOUTUBE_playlist_ID_1220 = "PL74C0860C9B68CCF1" 
YOUTUBE_playlist_ID_1221 = "PLH6sFwDngeyIjlMpOWi6TilX10bioVNl5"   
YOUTUBE_playlist_ID_1222 = "PLG7C1GCp_W5yEJcBoBOzFEjxA0Q6aPyx6"   
YOUTUBE_playlist_ID_1223 = "PLccpwGk_xup8EbuaOc_hm0Uc6bOKbO8By"   
YOUTUBE_playlist_ID_1224 = "PL171A82946311D626"   
YOUTUBE_playlist_ID_1225 = "PLme4g_nC93INm5a1uwUg8m6MkGC1WbpLd"   
YOUTUBE_playlist_ID_1226 = "PLlorqOfLZfxnC1Lxh8acjCIFPJJy-icst"   
YOUTUBE_playlist_ID_1227 = "PL1589EF77838FE829"   
YOUTUBE_playlist_ID_1228 = "PLR-cTez7U7IWjhREDlCv_y1FCRjdcoPgu"   
YOUTUBE_playlist_ID_1229 = "PLzPluRA37_MpS1HtBjY2QxfbIH5NOw8eC"   
YOUTUBE_playlist_ID_1230 = "PL1E4AAB8D6C9136AE" 
YOUTUBE_playlist_ID_1231 = "PLeSZ3Yy6leJKceq_xVbls-CkMmhHQTb7z"   
YOUTUBE_playlist_ID_1232 = "PLj9gRUgWAIL85k86B0w3Angub_LF7uNbq"   
YOUTUBE_playlist_ID_1233 = "PLH6X7In6uLyjER_ESvT40e1zf2SYVzSM1"   
YOUTUBE_playlist_ID_1234 = "PLjMCSv8t4ysEXu7HM9-qL4FSIm39Sz5HW"   
YOUTUBE_playlist_ID_1235 = "PLFtD4iAbEEhCDzgEWJV3zniDYwvoFdFDB"   
YOUTUBE_playlist_ID_1236 = "PLc_QJvzBNyqr8Iztxw3xmHem47zfck9_o"   
YOUTUBE_playlist_ID_1237 = "PLX-aEAhqJa5cfdycWqcdu3SyisxXLYqFz"   
YOUTUBE_playlist_ID_1238 = "PLPnm2SfLg8YYOrsCoYfahB4LX0rBf67l_"   
YOUTUBE_playlist_ID_1239 = "PL8vV_oKnRA9sp4luKdT68XEuxSV1ZMnoe"   
YOUTUBE_playlist_ID_1240 = "PLcIRyYL6BFz597jYg0LBwpRz2R0mYCFub" 
YOUTUBE_playlist_ID_1241 = "PLv3GiY98tAj53S5sk4JlT_dsKLCqOnk7b"   
YOUTUBE_playlist_ID_1242 = "PLwPwXGSe1jtQrdzxuf7XDZuzsc_So-qi6"   
YOUTUBE_playlist_ID_1243 = "PL33196EF7664597D5"   
YOUTUBE_playlist_ID_1244 = "PLnzuTBFY_La_ggph4Mixz2hRlsWDSVJbg"   
YOUTUBE_playlist_ID_1245 = "PL57c-2VnN7_9YFz6PwisgDU6OOrfWx5QF"   
YOUTUBE_playlist_ID_1246 = "PLq3UZa7STrbqjU_7SZbKhcKycPNyvbYi8"   
YOUTUBE_playlist_ID_1247 = "PL4FB84C89F174A7A8"   
YOUTUBE_playlist_ID_1248 = "PLN1KGkQoUB0ftaLvfDbxZ1AjOwBvcDkwn"   
YOUTUBE_playlist_ID_1249 = "PLzldPvW-QhUHqy3Y0yyZeHK5BNQ976SkN"   
YOUTUBE_playlist_ID_1250 = "PL8E091CA03070D251" 
YOUTUBE_playlist_ID_1251 = "PLyy3_iaI1nijUoMiZD4ZsVAPVlXFL_APH"   
YOUTUBE_playlist_ID_1252 = "PLz_Jg8rvimiolryoAabq0VNDV8IQNIqkw"   
YOUTUBE_playlist_ID_1253 = "PLVbMBNyzwsaNH9gIXyMktr9XDWaDqenR8"   
YOUTUBE_playlist_ID_1254 = "PLb9fO2YA3HdZUdnIboFA2Sqwt5OlR24yG"   
YOUTUBE_playlist_ID_1255 = "PLK6WIPelB1JxWt_fOk-eJnZhG9THnW98M"   
YOUTUBE_playlist_ID_1256 = "PL7FnXxZHUcchKwmC2P-Zo8cnUwBvlmiDd"   
YOUTUBE_playlist_ID_1257 = "PL0VsBD7qzOkGOvzb7e-v9qLbwcUI4xJEz"   
YOUTUBE_playlist_ID_1258 = "PL78MrFEGgIjE93iILVqm8-Lt_oxf7bQz2"   
YOUTUBE_playlist_ID_1259 = "PLCp0Pbu58F9eLqlFfzQeBwzHp3fQHfnxa"   
YOUTUBE_playlist_ID_1260 = "PLQdZAqHsBnglvenrPQUa1WCZEExcGUapU" 
YOUTUBE_playlist_ID_1261 = "PLGI6q18vQZv3mE9C5L162zZ4iY9OHWv9k"   
YOUTUBE_playlist_ID_1262 = "PLTK7wjVvDySDkUW1Ekx5TaZQa8eJAd5V8"   
YOUTUBE_playlist_ID_1263 = "PL6737BB3EC7BC5DBF"   
YOUTUBE_playlist_ID_1264 = "PL3E5FD0DAAFFD1041"   
YOUTUBE_playlist_ID_1265 = "PL1418D3C39412B845"   
YOUTUBE_playlist_ID_1266 = "PLVkFQbNsdzMBxGMf8jAOXIgoYb9ipsdnf"   
YOUTUBE_playlist_ID_1267 = "PL7Rc7sW07T1dOC08kSWX7hA8MIGX0ToSm"   
YOUTUBE_playlist_ID_1268 = "PLNN6PgGjGMDxYvpUct8xHQGyBupELjubm"   
YOUTUBE_playlist_ID_1269 = "PLNMq82vRNBNZ3D60ZBAUJEpDuK6vWvksr"   
YOUTUBE_playlist_ID_1270 = "PL-f5sU8-_h3c5pT63xYhQbYrRLY9KWmDr" 
YOUTUBE_playlist_ID_1271 = "PLSLdDpXFAL3PKh7DlKMGKXO949LvLUl2u"   
YOUTUBE_playlist_ID_1272 = "PL8N7aYgO1ZklMzf--9E2X1heDluDYl8wO"   
YOUTUBE_playlist_ID_1273 = "PL5jgRq7bETB_GdK8FZMgqxMaqTfzFOdD1"   
YOUTUBE_playlist_ID_1274 = "PLtqkBvc4FXKELJnlGZ-ydDXWpufGO2byg"   
YOUTUBE_playlist_ID_1275 = "PLF90ovVJdtwvfabRkXVLb0zC0UXJw_lra"   
YOUTUBE_playlist_ID_1276 = "PLVyDBcQYPqDErnktKeFzT9Lj21ZVq98Ym"   
YOUTUBE_playlist_ID_1277 = "PL3VgZyr58IYzq30Cqpo_ntWBTq5cCppYb"   
YOUTUBE_playlist_ID_1278 = "PLYJH9RAvAsYxQST9qKj3FULEaJCqcXOaX"   
YOUTUBE_playlist_ID_1279 = "PLswANT8vty3wr1VP6HPHi5fYyo4fiKYrr"   
YOUTUBE_playlist_ID_1280 = "PLSL9DB9AUS4OMke3q5-3YUViF55H2Rbnm" 
YOUTUBE_playlist_ID_1281 = "PLjXD91aXoUUfLc5MmrjBoOLq_4kq0-PSA"
YOUTUBE_playlist_ID_1282 = "PL3B97353EEE7531FF"
YOUTUBE_playlist_ID_1283 = "PLnb6fg0OTszbY5TUUQmTaihCHtl8pKjy1"
YOUTUBE_playlist_ID_1284 = "PLE1QSF_rGMaHopraRr_FMdjjl5CuRyMT0"
YOUTUBE_playlist_ID_1285 = "PLhfbEwH9GRWcONgyesaGNQ3YfJ7GYpct6"
YOUTUBE_playlist_ID_1286 = "PLxEKSO8TCDGv6Wr5SrRwuQOGLY_rOYsuT"
YOUTUBE_playlist_ID_1287 = "PLzjyzFmgotfhAQB6OSvyzv7L0AQqgl9xZ"
YOUTUBE_playlist_ID_1288 = "PL28rSWlcWd3Dzgm0jVsFe1znz4_LceQju"
YOUTUBE_playlist_ID_1289 = "PL6TQYfLw6QyRCPwYiZP94J4qz9H1SnVWI"
YOUTUBE_playlist_ID_1290 = "PLD8029B5D911A0776"
YOUTUBE_playlist_ID_1291 = "PLWgmuvSF6GXvQ4ozQND4oHfk5cXj91hzb"   
YOUTUBE_playlist_ID_1292 = "PLE9C3DBDD0C69FAFB"   
YOUTUBE_playlist_ID_1293 = "PLq4ZNHAeqNYF-bbX29PmOqHgsmpcog8kw"   
YOUTUBE_playlist_ID_1294 = "PLBiNsLvMmUHNqeLJ3D9m62DdlYmhhb3gc"   
YOUTUBE_playlist_ID_1295 = "PLHDGitQ9eGu42uQtSupfNLb9qVpGAhLP6"   
YOUTUBE_playlist_ID_1296 = "PLtmwT2zAoUJddBC8Q_rZnEL8ypBdmaBWk"   
YOUTUBE_playlist_ID_1297 = "PL1PBfSEqTSeAMdhziXKeyQqZQYLrLzZhl"   
YOUTUBE_playlist_ID_1298 = "PLwJTPZLP8Du7vAzt_difhOk2RR4AWzKTM"   
YOUTUBE_playlist_ID_1299 = "PL1669B95BEE6097C0"   
YOUTUBE_playlist_ID_1300 = "PLJziKgkV9M2yLSkGYXYgvLHsL0IVSUDO0" 
YOUTUBE_playlist_ID_1301 = "PLH3uWI-RMnugvomPsGwPekxNhwRnJR18U"   
YOUTUBE_playlist_ID_1302 = "PL-Yos3KSbcXQx8fvaRcW_pio_PUWPK5uC"   
YOUTUBE_playlist_ID_1303 = "PL0B718D45DD99BDD6"   
YOUTUBE_playlist_ID_1304 = "PLgaFNC_I_ZkkXqk-B8wws8IDK7k6E0gX7"   
YOUTUBE_playlist_ID_1305 = "PLj4Z0in59t5b2MfE85RbYrN-fyDDFno8O"
YOUTUBE_playlist_ID_1306 = "PL24fCze99d4pi8iER-wpUWtK8TDc2XIJm"   
YOUTUBE_playlist_ID_1307 = "PLDyCcI2Pa72I3wWVu7sv3LTVHOrVR9os6"   
YOUTUBE_playlist_ID_1308 = "PLVQ4cQ32jaNFqVKwaHBZQ3IxgRumTY-o1"   
YOUTUBE_playlist_ID_1309 = "PLGkwJeDqK71qlEsmcBFXSbTKpCaYBCZ7h"   
YOUTUBE_playlist_ID_1310 = "PL2D01482619323759"
YOUTUBE_playlist_ID_1311 = "PLeoYmhn8-0Hth3R3Fvy4msPcnB_w8V9fh"   
YOUTUBE_playlist_ID_1312 = "PL1LxZ0dh0_dTP9JnXgUJewIYT_MElA6qc"   
YOUTUBE_playlist_ID_1313 = "PLcEOcG701ypILdJwCzvJ_YkecM8KmqKo1"   
YOUTUBE_playlist_ID_1314 = "PLteuMRHQ6yX1EpvpHjKn9I_DcSbsekiRD"   
YOUTUBE_playlist_ID_1315 = "PLDEDD269EE0F0C870"
YOUTUBE_playlist_ID_1316 = "PLY0fFZhAeZnKcZtgXkY7Ac6t-6iZOLVJC"   
YOUTUBE_playlist_ID_1317 = "PLpEJ4CNLsMCwoa46WTMl5Ob6IM0QhDa7s"   
YOUTUBE_playlist_ID_1318 = "PL59EF017FE2E03CBD"   
YOUTUBE_playlist_ID_1319 = "PLA_kcq9Bb6_DWeVX4Jfvr9LtkI0qH65xH"   
YOUTUBE_playlist_ID_1320 = "PLc3RP1qHA2nIt_JcklVbkWHzzUtjlcKfk"
YOUTUBE_playlist_ID_1321 = "PLvH8UCF6QXbEwwEJHIba8H5Xd6nDAA-6P"   
YOUTUBE_playlist_ID_1322 = "PL6653832D9747EB77"   
YOUTUBE_playlist_ID_1323 = "PL8aIynMubrGJAwYdRNirF1IAb_74VAy9L"   
YOUTUBE_playlist_ID_1324 = "PL55342509E69C8B47"   
YOUTUBE_playlist_ID_1325 = "PLVt9N9S0Czvj2jyGlbk-PzbZnEKvzgPbt"
YOUTUBE_playlist_ID_1326 = "PLM5UDu4_tiS_cBvOFADDj9uxb3IXIA0AJ"
YOUTUBE_playlist_ID_1327 = "PLjc8HZ2bhnCDwpPUQBrfYTCgqYcFYd6L1"
YOUTUBE_playlist_ID_1328 = "PLgUuM4N3bcs3uX_DgttcZah7g2HgbhgkF"
YOUTUBE_playlist_ID_1329 = "PLkjL9366zaYvx7he4OroQ2Fy4rPFzU4T7"
YOUTUBE_playlist_ID_1330 = "PLA9CBDEE2C2E735FE"
YOUTUBE_playlist_ID_1333 = "PLBA45B830027E7ADE"   
YOUTUBE_playlist_ID_1334 = "PLIX8IF83F6Rfj1bbosFhARJZGv-iFsIx5"   
YOUTUBE_playlist_ID_1335 = "PLMC9KNkIncKtsacKpgMb0CVq43W80FKvo"   
YOUTUBE_playlist_ID_1336 = "PLD7SPvDoEddZUrho5ynsBfaI7nqhaNN5c"   
YOUTUBE_playlist_ID_1337 = "PL_3moN-ayKSTx9GWQtNowcjnsAoYQidwR"   
YOUTUBE_playlist_ID_1338 = "PL8Lpw39GxwbMEkdXCWe7xag-PgLAH1ouR"   
YOUTUBE_playlist_ID_1339 = "PLPOzFpNyZMSzZOBzWFN1nYZ5XR4JyRB-R"   
YOUTUBE_playlist_ID_1340 = "PLFMMdo6zY1OWXzIbzVgke8W4SnQaLDUut"   
YOUTUBE_playlist_ID_1341 = "PLHTYFawqK1nIGz0zkbhmYQKH1R1GzuF2M"   
YOUTUBE_playlist_ID_1342 = "PL64E6BD94546734D8" 
YOUTUBE_playlist_ID_1343 = "PLjwbNj9NASKPAVPWq8OzQV4m1a6fJLJky"   
YOUTUBE_playlist_ID_1344 = "PLVQYd7N6rKfoK7KXy6tSSxkozONokEfbo"   
YOUTUBE_playlist_ID_1345 = "PLF-VavV_hx6cpV-3s932etavO_iuxYdHo"   
YOUTUBE_playlist_ID_1346 = "PLS864u2gr0XPG6QOl0XKdbv9IqUghg4xk"   
YOUTUBE_playlist_ID_1347 = "PLfCjMXooAuhmuEsNA5vyhHmSFxCUEOfsh"   
YOUTUBE_playlist_ID_1348 = "PLsT9PGvhvomi6NAoPwN1W3fZq0ykTEKy8"   
YOUTUBE_playlist_ID_1349 = "PL3oW2tjiIxvQYJk_KgmzHu3yn1I0pELui"   
YOUTUBE_playlist_ID_1350 = "PLB198123485A074BD"   
YOUTUBE_playlist_ID_1351 = "PLlFYGIP0qPT91MbkVopWOYpFumU99tI1f"   
YOUTUBE_playlist_ID_1352 = "PLJZH8sevmMq5rnnzsmkbteoFOWCdBx24u" 
YOUTUBE_playlist_ID_1353 = "PL0_DTryb6VtxP1az3cotc-wGzOXs0CKVl"   
YOUTUBE_playlist_ID_1354 = "PL_xXZCm82Zkm9J1o94Ep4NK-0Mfb2BkCr"   
YOUTUBE_playlist_ID_1355 = "PLMZxug3Hi7FaMqhuWrdUOqFD2h711RfXm"      
YOUTUBE_playlist_ID_1357 = "PL7v1FHGMOadBTndBvtY4h213M10Pl9Y1c"   
YOUTUBE_playlist_ID_1358 = "PLoKT-dgdau6Hsae1b1BJ_3HDzJ5xzdQUx"   
YOUTUBE_playlist_ID_1359 = "PLCH0JkNDm_RFVIkDSTa0loLUHmBMTGjeb"   
YOUTUBE_playlist_ID_1360 = "PLSl_KJgT50dstRSoc1DxXtp6B3aAO8zfB"   
YOUTUBE_playlist_ID_1361 = "PLJP0gjMCUB8RUOyDlcue_1YNt3XV88rR0"   
YOUTUBE_playlist_ID_1362 = "PLH2d3z522rupw6M13TfVitb5Pu0J10bSk" 
YOUTUBE_playlist_ID_1363 = "PL3wevlBAQrm9FUZi-rOY7n8j-7UBpZui9"    
YOUTUBE_playlist_ID_1365 = "PLWsCOCeiB-9CiDZoWP-EmBJHbWA3eQbZL"   
YOUTUBE_playlist_ID_1366 = "PL1t18zvqSCHMvhwJ_gKRe54r_bTNwM8SX"   
YOUTUBE_playlist_ID_1367 = "PL_34_m4eTlaN6hX-sJcrJCJvRL4pSrPx0"   
YOUTUBE_playlist_ID_1368 = "PL486BB32197AF85C9"   
YOUTUBE_playlist_ID_1369 = "PLlYKDqBVDxX2TXAf8ruuF3FVZgzF3wCTx"   
YOUTUBE_playlist_ID_1370 = "PL7v1FHGMOadAb10Y3q6rv1mxZ4eg6PmB0"   
YOUTUBE_playlist_ID_1371 = "PLGG8o-M0wvxq6J_KrdX8nFdW57OBVnn4V"   
YOUTUBE_playlist_ID_1372 = "PLyORnIW1xT6xo_bLnY7PN7w6CHNxPt5Ai" 
YOUTUBE_playlist_ID_1373 = "PLLcpjj5QHxrzt_zPYQYlUb6e6vEkFmgnI"   
YOUTUBE_playlist_ID_1374 = "PL7F8bxFSznDPnyhy4b6n7QDgQU2qnCz6m"   
YOUTUBE_playlist_ID_1375 = "PL57484A3F82C424E3"   
YOUTUBE_playlist_ID_1376 = "PL3oW2tjiIxvQO6yqJEkrP47yYG_pJ7XJU"   
YOUTUBE_playlist_ID_1377 = "PLWlTX25IDqIwqowTsJmGhqxUWU_6qgG1W"   
YOUTUBE_playlist_ID_1378 = "PLQZCmay3e9pCUrXng_367-TrG6OzrBnrt"   
YOUTUBE_playlist_ID_1379 = "PL4e5v5rgh_1J2Tams1MzwOGDdy2Lfispx"   
YOUTUBE_playlist_ID_1380 = "PLp7pAH9am84Oo5ldXHaoeqmmvXav38S4W"   
YOUTUBE_playlist_ID_1381 = "PLFC28E3AD281409CF"   
YOUTUBE_playlist_ID_1382 = "PLc_QJvzBNyqpdcEvgQVQcY7_BkCLleG6o" 
YOUTUBE_playlist_ID_1383 = "PLEF4FCEA775F67968"   
YOUTUBE_playlist_ID_1384 = "PL55E27F0A3F841080"   
YOUTUBE_playlist_ID_1385 = "PLRGwl0uGb03JJU3uXvTTkg3Plc8VkMRsf"   
YOUTUBE_playlist_ID_1386 = "PLyPLVV5ZP3toAOnj7OcVXN8voaQKFAzUY"   
YOUTUBE_playlist_ID_1387 = "PLHtas7RAJ1Dd5z3yFsXNC2Pc7IAQybnZY"   
YOUTUBE_playlist_ID_1388 = "PLTg4FbX2Lba7C9IyEulc1SFSQucI6n1Dd"   
YOUTUBE_playlist_ID_1389 = "PL53979BD9F5A17EBE"   
YOUTUBE_playlist_ID_1390 = "PL3CCBD39FFA2B8EA6"   
YOUTUBE_playlist_ID_1391 = "PLc0eDNO33XnEwdJJHp4wG2BSswOL0XVE3"   
YOUTUBE_playlist_ID_1392 = "PL310D0B1FA8B9E482" 
YOUTUBE_playlist_ID_1393 = "PL5F9FEB901542819D"   
YOUTUBE_playlist_ID_1394 = "PLevkgFdS1wizhlAcsggxA9W_-t0QECcXB"   
YOUTUBE_playlist_ID_1395 = "PLBBAD26776692C94D"   
YOUTUBE_playlist_ID_1396 = "PL812FC14AD87E0C2C"   
YOUTUBE_playlist_ID_1397 = "PLOYbqpgE4msXjfc2oLUmxyvZueNJu6BmF"   
YOUTUBE_playlist_ID_1398 = "PLLda6EOr0ZHczAwV6Qp2V_QvvwoXNOIgq"   
YOUTUBE_playlist_ID_1399 = "PL8B378392000F267B"   
YOUTUBE_playlist_ID_1400 = "PLlYEwrya-bUMf_ei8YUGI7JPpA2vFg9m0"   
YOUTUBE_playlist_ID_1401 = "PLFZcoHpmKx90VRP6aOcSx_lgbecvEkF6G"   
YOUTUBE_playlist_ID_1402 = "PL8731228C4A625755" 
YOUTUBE_playlist_ID_1403 = "PL66DF0B69504BA7F4"   
YOUTUBE_playlist_ID_1404 = "PLlt4xZeez_gk74mAMH_BdJ5wIWK4uCCOz"   
YOUTUBE_playlist_ID_1405 = "PLirawLr9UsXZ8B1hVGrPCVSnLswqFXfoP"   
YOUTUBE_playlist_ID_1406 = "PL7B97FB52041E68FB"   
YOUTUBE_playlist_ID_1407 = "PLA513EADA1CFDE65C"   
YOUTUBE_playlist_ID_1408 = "PL3DA18F851B25F94C"   
YOUTUBE_playlist_ID_1409 = "PLad0_ESl2zMm5bu0CH-VgKBOxZ_oJSCzI"     
YOUTUBE_playlist_ID_1411 = "PL3E829D559E1BE7B2"   
YOUTUBE_playlist_ID_1412 = "PL203D0D16FC9EB5E4" 
YOUTUBE_playlist_ID_1413 = "PLA19045135255CF20"   
YOUTUBE_playlist_ID_1414 = "PLRkN9rep-454QjFS8s_MUAEBU1Yg4HwD9"   
YOUTUBE_playlist_ID_1415 = "PLDCPm2J8Nug15oDgs2reHkGpl62veV0tB"   
YOUTUBE_playlist_ID_1416 = "PL0bBgG-zbN-hWgAIcTZtZByBC1w9iavn3"   
YOUTUBE_playlist_ID_1417 = "PL55EA4EF16C415356"   
YOUTUBE_playlist_ID_1418 = "PL3RD2crtd_e23FtrMVPuAMNivFOBNSu0-"   
YOUTUBE_playlist_ID_1419 = "PLnGSeYDl9OgXDzW2fdHIZZmZIWRU_BZrD"   
YOUTUBE_playlist_ID_1420 = "PL56D4611BDB5AC9EB"   
YOUTUBE_playlist_ID_1421 = "PLwQwulH3HV_DhNjon-Ncfq08SG0TWYzad"   
YOUTUBE_playlist_ID_1422 = "PLC3124F2740F834CB" 
YOUTUBE_playlist_ID_1423 = "PL27B72A607966CD68"   
YOUTUBE_playlist_ID_1424 = "PLJBorKKZq5Vt-6cJ5b0gitc3LYBVtOYX3"   
YOUTUBE_playlist_ID_1425 = "PLyMX3g9Taar-5D6iAYnCLsy7kA8KIQ38N"   
YOUTUBE_playlist_ID_1426 = "PLB6C8C223032CE3FD"   
YOUTUBE_playlist_ID_1427 = "PLEF7C1B8057F26916"   
YOUTUBE_playlist_ID_1428 = "PLqVUBSFEWLfgsycVP5Pt87iNURSpkRbwG"   
YOUTUBE_playlist_ID_1429 = "PLpMTPTkiNhmViLpSPmMJnMMNWY3vnT39G"   
YOUTUBE_playlist_ID_1430 = "PL9X8GffjHizne1tCeuC5e_hoTAG8fuYMF"   
YOUTUBE_playlist_ID_1431 = "PLGgLuiPaJ2Fm9NZj5ZB0sIxjmHce2q7zP"   
YOUTUBE_playlist_ID_1432 = "PLn3PLU5uPUtAsdpoxN3DTCEPXMP32hXY8" 
YOUTUBE_playlist_ID_1433 = "PLnJO6kcPqYUmtR0L3Evf_zFcA0RsqkatT"   
YOUTUBE_playlist_ID_1434 = "PLImhtwak-2CN-W2gsDDzApW0_zEmJl2f6"   
YOUTUBE_playlist_ID_1435 = "PLxXJWa4J5wHocNxE1mo0R4cdVPfjB2BUI"   
YOUTUBE_playlist_ID_1436 = "PLncnejZ0NSNYh2FyG_NARuhq_1RK9oSBt"   
YOUTUBE_playlist_ID_1437 = "PL47A298678EBD29F4"   
YOUTUBE_playlist_ID_1438 = "PLCBB529B1FCD5DFE9"   
YOUTUBE_playlist_ID_1439 = "PLLTyrFiq_jWxRUbeIyPk1k1ubTRsTtF6N"   
YOUTUBE_playlist_ID_1440 = "PLJo3Lvkvjj8msILnxFPn6NI0uwPgWO86f"   
YOUTUBE_playlist_ID_1441 = "PLE8BzzabnLXclhOAEkov-wpNF2LSucLXs"   
YOUTUBE_playlist_ID_1442 = "PLgG5WNcB__RD-ulzwB4CWjKRu0D-R1-Yt" 
YOUTUBE_playlist_ID_1443 = "PLj1wDRYA50qM3wJ9Hx1mXu51MjwXOUmkC"   
YOUTUBE_playlist_ID_1444 = "PLkSVxY-QrYD7A7vItAZUVa4sUH-lTUVOi"   
YOUTUBE_playlist_ID_1445 = "PLYaEve-bV_q2QPtgRMqMlR2PesGIvGIsi"   
YOUTUBE_playlist_ID_1446 = "PLpDOhu2oo74Xmgg1JzErv8Cv4u6NvTFZg"   
YOUTUBE_playlist_ID_1447 = "PL3KM7YTKKj3SXIj3sEmQp4WJr4Ta13Vj7"   
YOUTUBE_playlist_ID_1448 = "PL7Gpv0iswmDOumLbXwDtvdH4Up-qrB79a"   
YOUTUBE_playlist_ID_1449 = "PLcfAUSELe385SYLh-3qOtupzNPUE6joNn"   
YOUTUBE_playlist_ID_1450 = "PLjtEkYRNN2okXrol4fCLKPLRayUQwMNV3"   
YOUTUBE_playlist_ID_1451 = "PLEA05AB94E7F1847F"   
YOUTUBE_playlist_ID_1452 = "PLHnhZiTRkyK9TQVyRgH1kUGy14BWSa1aO" 
YOUTUBE_playlist_ID_1453 = "PLV9Y9mIaysx5XHUl-TZP5oUVLD1pqR1zK"   
YOUTUBE_playlist_ID_1454 = "PLw2LuhCbGSS-JaT58ANMssBAG6bvgMMHj"   
YOUTUBE_playlist_ID_1455 = "PLBDC370D77AB7BE9C"   
YOUTUBE_playlist_ID_1456 = "PLAB26B586A986C929"   
YOUTUBE_playlist_ID_1457 = "PLdi55YzqENE6GmmJhIvXeWyOp7a3ku3SL"   
YOUTUBE_playlist_ID_1458 = "PLTtuKqkycTVc6goSvnQRpnUnPZGMlSxOi"   
YOUTUBE_playlist_ID_1459 = "PL_Dx6ocrdk1GZb_HNIyCSONGeIberJu45"   
YOUTUBE_playlist_ID_1460 = "PLkT4Xs2qpKuVwLZRX6nlB3a_cBKtv8eKu"   
YOUTUBE_playlist_ID_1461 = "PL1D9MZ8NSdnywHIBVHn6LXbnibJHjeP4b"   
YOUTUBE_playlist_ID_1462 = "PL_2Nui_65m4-_MoQUP55miRkvuywbNgSJ" 
YOUTUBE_playlist_ID_1463 = "PLduNb1B9VN3JiLVWMI6GjvP56Jegh9x4F"   
YOUTUBE_playlist_ID_1464 = "PL6JpQUTnUj0PrOG3PMwDLN1caslxVh5gQ"   
YOUTUBE_playlist_ID_1465 = "PL5rUsm_0xXu66K0POod2j-koKZ3n8BZUA"   
YOUTUBE_playlist_ID_1466 = "PLIuPiFJJr3OQoMjwyUwsqC6kxKs3Tmw1x"   
YOUTUBE_playlist_ID_1467 = "PL8a0iWiyYk4QhZwpY_l7iVTdMZvtLd62M"   
YOUTUBE_playlist_ID_1468 = "PLC59CAF7D26E43D2B"   
YOUTUBE_playlist_ID_1469 = "PL884848E696C48975"   
YOUTUBE_playlist_ID_1470 = "PL514AEA19D53CA37E"   
YOUTUBE_playlist_ID_1471 = "PL-Oq5zdJbI8xzDTCSRDiXOLbXlJXtO0WN"   
YOUTUBE_playlist_ID_1472 = "PLW733zUwKs8gpagkqzdanK1RaNWneTTID" 
YOUTUBE_playlist_ID_1473 = "PL2052655D67AB5ACA"   
YOUTUBE_playlist_ID_1474 = "PLo8GBcaIrb87AQ1Y4nFbgJdAAmR7Ey_mW"   
YOUTUBE_playlist_ID_1475 = "PL32DAD16u1Vwec_GedpJTibqdMPDPafLX"   
YOUTUBE_playlist_ID_1476 = "PLqdv8XhjjbWeQWqGewl2uD7LNFROwFsPQ"   
YOUTUBE_playlist_ID_1477 = "PLLghHpBvQTO_oiVpnFQvUW7HNl4GE_Wm1"   
YOUTUBE_playlist_ID_1478 = "PLLqFX0YNOJxZyIE1oBVx-0RNedzlxDECk"   
YOUTUBE_playlist_ID_1479 = "PLfUSD0lOd3L8WNgkMoXKhhQUhLfVGujtm"   
YOUTUBE_playlist_ID_1480 = "PLgbUm-IHmretEoyrw-tlEsWo-nw2xBaWn"   
YOUTUBE_playlist_ID_1481 = "PLvtgeiv_X4Kywj3gXJFnzosYOwdv3E7od"   
YOUTUBE_playlist_ID_1482 = "PLm2qJi599_Q0KOCvThAAIrXyQTeDBgS2p" 
YOUTUBE_playlist_ID_1483 = "PL59C237A4B869C286"   
YOUTUBE_playlist_ID_1484 = "PLUhqFX6g_9NdEOWN_giQrXyDzO8Jeh4SX"   
YOUTUBE_playlist_ID_1485 = "PLhlzNxw0OeLBbABGy0FHL7QJ8hzRQyzfc"   
YOUTUBE_playlist_ID_1486 = "PL5C4FE4619A29815D"   
YOUTUBE_playlist_ID_1487 = "PLQ9EaY0bhx97AKlpYKAvGbYEsfnOBW1Jv"   
YOUTUBE_playlist_ID_1488 = "PLb-9QWhjIXbH6jHSZE0a9mkx93Q7oRBJs"   
YOUTUBE_playlist_ID_1489 = "PLOVQFaq6JohYEIGwNtn9JadZlbnmTqELZ"   
YOUTUBE_playlist_ID_1490 = "PLIcQbw7ij4yKoNjtOHZrAGT-2f5W61xCh"   
YOUTUBE_playlist_ID_1491 = "PL_dn1cNjzDkm0xHN7f0PB_TaioJarpIMb"   
YOUTUBE_playlist_ID_1492 = "PLieo1J3QucIwApfvN9W-YKg8S4gv6gURE" 
YOUTUBE_playlist_ID_1493 = "PLSCW6Z6Kzf_LIzvv73hxo9gWPwvxc0Vfw"   
YOUTUBE_playlist_ID_1494 = "PLBJ4z1nwRfxKiMrNFaCnyxf_l7ztqu84i"   
YOUTUBE_playlist_ID_1495 = "PLhk1hdPbRIF_ze5jK42ZKGrJxXtWpLkRN"   
YOUTUBE_playlist_ID_1496 = "PLF570D44ADDB15540"   
YOUTUBE_playlist_ID_1497 = "PL894CA1BAB08FD04B"   
YOUTUBE_playlist_ID_1498 = "PL0RJVKBZkZNtqvgr2Gd2jRAHBEoKGG7_g"   
YOUTUBE_playlist_ID_1499 = "PLmXxqSJJq-yXI70WkH5IX6iWzZNXtoCTx"   
YOUTUBE_playlist_ID_1500 = "PLlE4YWXO2iyfNI1LAWU78adIDQTIQ253x"   
YOUTUBE_playlist_ID_1501 = "PLU4GTyMETaQ6aFcPG9mRTNDZh03xQDURa"   
YOUTUBE_playlist_ID_1502 = "PLbhXUZ8fVvVIlvEiS9OX-D7QJkhSq6S48" 
YOUTUBE_playlist_ID_1503 = "PL489771FE8F29BB52"   
YOUTUBE_playlist_ID_1504 = "PLDRU8SQovCBz9ZdRV80YBAm8z4JjWbpUr"   
YOUTUBE_playlist_ID_1505 = "PL343B5D4F8D2FF6E9"   
YOUTUBE_playlist_ID_1506 = "PL983BB33AAEA0417D"   
YOUTUBE_playlist_ID_1507 = "PL8EA2602EC959251A"   
YOUTUBE_playlist_ID_1508 = "PLJNzsdyMbpUm0KZWM3nttMuyaX6z-_gmE"   
YOUTUBE_playlist_ID_1509 = "PLoEq80OSvDV2nTqlTOG3WNbhhcvFrl38U"   
YOUTUBE_playlist_ID_1510 = "PL9k-gGd2m-s5i48eVOgBMOZ5-NZSXyxqG"   
YOUTUBE_playlist_ID_1511 = "PLRGQ5c92pkpT9bKvVkPb6TcGZ6TnVDvOg"   
YOUTUBE_playlist_ID_1512 = "PL-3S4Aw-jj-Bv4l5jLSdC8PFHDbAFtwml" 
YOUTUBE_playlist_ID_1513 = "PL91359E274EA87F2A"   
YOUTUBE_playlist_ID_1514 = "PLBzBwYhHpqLJxFhCUm_nG1Lr9y6lydyQi"   
YOUTUBE_playlist_ID_1515 = "PL5YlbWoQ8MB9pEy2axk-ZBHVCcfEZn-_d"   
YOUTUBE_playlist_ID_1516 = "PL0uQ4d_xPptEMmZfRo1vXE5-HVsoHIc2M"   
YOUTUBE_playlist_ID_1517 = "PLF639FD27B4AC4A5A"   
YOUTUBE_playlist_ID_1518 = "PL1flhjDd23bEh4B0dP8XECDeZT9xrRjvW"   
YOUTUBE_playlist_ID_1519 = "PLH7gP8TLZrssq5uo0rjOPEmWNL-DWdP3J"   
YOUTUBE_playlist_ID_1520 = "PL2z2PVKfWnobejmkf6eVc6NttzkZy10dD"   
YOUTUBE_playlist_ID_1521 = "PLKJzkJ4iq1UGrDLvbWwDQkEabH39TpBzq"   
YOUTUBE_playlist_ID_1522 = "PLpSBkUw1nWxsvcuZWglot-VA-ha4gWifU" 
YOUTUBE_playlist_ID_1523 = "PLuveNUf1W08yItQvh0khxeK6FCy3ELPM_"   
YOUTUBE_playlist_ID_1524 = "PLKwlkwPqaAwXQEeTWNSY36AWUajDyTJvc"   
YOUTUBE_playlist_ID_1525 = "PLB742BAFBD09C2998"   
YOUTUBE_playlist_ID_1526 = "PL5T6ekB4rOR5Bhn0KExuNPskYudYjh1Kt"   
YOUTUBE_playlist_ID_1527 = "PLcfV1uw38QycqoxDOdT1Re-MulP-SIRnx"   
YOUTUBE_playlist_ID_1528 = "PLYnkKNgevw4hvFFLy1EYjIENwkvbOianr"   
YOUTUBE_playlist_ID_1529 = "PLgZ7VU44ekVSmQB_nTzoZZg0J-P_78-TA"   
YOUTUBE_playlist_ID_1530 = "PLRX3ekLC4K79hkvgnfPk0RIayFoNDdY2d"   
YOUTUBE_playlist_ID_1531 = "PL71D30063B6976F48"   
YOUTUBE_playlist_ID_1532 = "PL9CZ_0L9hvlpTPRqR4aLHqQfp34pJmsy0" 
YOUTUBE_playlist_ID_1533 = "PLDaeUbkGAihg_JQB8hLzDVdkznvLbqyQS"   
YOUTUBE_playlist_ID_1534 = "PLvRZx-7vtHq9OKOaxhIr11NALv3JCOWdP"   
YOUTUBE_playlist_ID_1535 = "PLqA19FSYLtRRjNg6XmPQcLTFImOMwVIKX"   
YOUTUBE_playlist_ID_1536 = "PL9F67327C6B153079"   
YOUTUBE_playlist_ID_1537 = "PLC444B7DE8929E4D0"   
YOUTUBE_playlist_ID_1538 = "PLMEZyDHJojxNk4gOMx01KqwnpoMJN008Q"   
YOUTUBE_playlist_ID_1539 = "PLSfHFLHWefOX8BikFxGmvjAI_QaB_fad1"   
YOUTUBE_playlist_ID_1540 = "PLjTpIpvziBRMuFYf7hUcAOD7_Pym-44ks"   
YOUTUBE_playlist_ID_1541 = "PLfnY9BClgvMV5uSyJJoS8Q6md7uIPUMmo"   
YOUTUBE_playlist_ID_1542 = "PLHrlKcl_QBb_w4MSn96WmgM1Bw90klE3Z" 
YOUTUBE_playlist_ID_1543 = "PLF24DB80CD9711B60"   
YOUTUBE_playlist_ID_1544 = "PLB27D9F585EC140E7"   
YOUTUBE_playlist_ID_1545 = "PL8AQWWXxWn8hNO7Xpcap3cvvVHiTXlERW"   
YOUTUBE_playlist_ID_1546 = "PLB27B227B5672F737"   
YOUTUBE_playlist_ID_1547 = "PLatuTuqWSQmViIeVthG2y9YssDtm8EvYt"   
YOUTUBE_playlist_ID_1548 = "PL_RkrPxfpl-TdGjFPh5HBwbl3DL47DzAA"  
YOUTUBE_playlist_ID_1549 = "PLL8mu2V_l0rXRxPciWE483AGmd5ic1zuW"  
YOUTUBE_playlist_ID_1550 = "PLGjk9FUwqCgZ-zmHzGm2hqQbzh-FbO2EL"   
YOUTUBE_playlist_ID_1551 = "PL3tLM4CyJwkm4uXwhIoN3emIi7siamqRV"   
YOUTUBE_playlist_ID_1552 = "PLgEm4bBbe-ZFxcmMC3wRaxoV8H8GipHdD"   
YOUTUBE_playlist_ID_1553 = "PLi7ihgkEws7T-MMD29QAsuGZL8AAtfJfG" 
YOUTUBE_playlist_ID_1554 = "PL0EC02D5B7C0A4B81"   
YOUTUBE_playlist_ID_1555 = "PL-O-GdPSYPsqBG-7DjHV7WIhYk320hrRq"   
YOUTUBE_playlist_ID_1556 = "PLTEiE9Kw0BC4J1xW_45a5DGjhNUeMgLUp"   
YOUTUBE_playlist_ID_1557 = "PLWTO5hqdcmkcsx1p9TOaOmKn_wg-D43mk"   
YOUTUBE_playlist_ID_1558 = "PL6UsqzRx7bZJXtbEVrnDOj4t1uDkhf2np"   
YOUTUBE_playlist_ID_1559 = "PLcY6gZQWqz7NiPZ02c0LCFOGlB35KBRif"   
YOUTUBE_playlist_ID_1560 = "PL3KU6jhraN224qnFhMUqNLnYjjIozk-ic"   
YOUTUBE_playlist_ID_1561 = "PLXuJSagiUtoeqLFTWnR2-0yAdvGDZNTEp"   
YOUTUBE_playlist_ID_1562 = "PLqm_m1ZJ-zhWDg7QhQZf8zUGyZ2fdp-Vp"   
YOUTUBE_playlist_ID_1563 = "PLHcJQn3tSs7gV0aTa6xhdcEZdXuAvzluZ" 
YOUTUBE_playlist_ID_1564 = "PLm-nBFwH-HoS7o2fPoUZPWmLVWxx-R3xS"   
YOUTUBE_playlist_ID_1565 = "PLYtGjTb6IKvH9Pbo0fOuyVr9-zkgd4ONi"   
YOUTUBE_playlist_ID_1566 = "PL-bEg8Jizyt-jcvOFs9Vo60MfA06azYqx"   
YOUTUBE_playlist_ID_1567 = "PLiMtBUmZMV6IH4wWBouGqsRmhQVRtCACo"   
YOUTUBE_playlist_ID_1568 = "PLBzV-Ka1mUyFVUY_qoEpjtwHy2jrzSYCs"   
YOUTUBE_playlist_ID_1569 = "PLHDlnIjwvHcybE7YnBAkUgm_641JHYojD"   
YOUTUBE_playlist_ID_1570 = "PLTVHCXA7CPNZ8FHI89o26HVC8WZiaJ8S7"   
YOUTUBE_playlist_ID_1571 = "PL4613C1AE8F3AD0A2"   
YOUTUBE_playlist_ID_1572 = "PLcLS8GFiWBm_SbOsCvf3m9_BG6M06-IeL"   
YOUTUBE_playlist_ID_1573 = "PL933AC97FC76932EC" 
YOUTUBE_playlist_ID_1574 = "PLhb13QZxD0cx59mFZGxCYWLIwv8Wl3RtL"   
YOUTUBE_playlist_ID_1575 = "PLhMDResaANjErt7xFgVd0FlCE2zu4cp27"   
YOUTUBE_playlist_ID_1576 = "PL410713FC86B7C493"   
YOUTUBE_playlist_ID_1577 = "PLr-0JX4y5cNC8JWjcwp6Lp62ZrJ11phEo"   
YOUTUBE_playlist_ID_1578 = "PLvLi2Av05yRpdwqPNnOxPs3j_yjyQ53rb"   
YOUTUBE_playlist_ID_1579 = "PLo73V4uKVPf9OKXw4T1wKOE1pRHPj04Sj"   
YOUTUBE_playlist_ID_1580 = "PL2F08D1C6050D7EB8"   
YOUTUBE_playlist_ID_1581 = "PLToBvuU3r650WuO4vjzrt62kDO9dKtvNA"   
YOUTUBE_playlist_ID_1582 = "PLY-BgrDToJMm4yHCtFFxOUfnaR1OPAlXP"   
YOUTUBE_playlist_ID_1583 = "PLr9cx6buYgYxj3004uHdnfoL5HHz-CpW5" 
YOUTUBE_playlist_ID_1584 = "PLmK2pQOmRD2S2raDxFOhaMBU62Gh7wb09"   
YOUTUBE_playlist_ID_1585 = "PLb2DvzzWlt4Tx3kALE52AP2fvKBnxMvQG"   
YOUTUBE_playlist_ID_1586 = "PLj-Z7B2znIJEX8lIbXYAtjSnTcalpBfax"   
YOUTUBE_playlist_ID_1587 = "PL_K-VPbYqqMLhnJfJPxcsOs9egX0PkOGi"   
YOUTUBE_playlist_ID_1588 = "PL-9hOG-CQcjfS_uAyxw5FAbSPVSfuXqzQ"   
YOUTUBE_playlist_ID_1589 = "PLqso3dMhsscr2H_fiYgXFzMxlSm4PZDCs"   
YOUTUBE_playlist_ID_1590 = "PLOFuTVPAlS8c_BpDin2YqolnF_fmMtMRX"   
YOUTUBE_playlist_ID_1591 = "PL2rf0GvkIfV3vOVkkKo4RXle1i-FJ8KXc"   
YOUTUBE_playlist_ID_1592 = "PLco5dZ1I7BloK5Dgf1rLC728ANwNxuq95"   
YOUTUBE_playlist_ID_1593 = "PL1A15CB2788DFDF50" 
YOUTUBE_playlist_ID_1594 = "PLRE7qERajyBHic3eTkL6zwBUoDP60WKxV"   
YOUTUBE_playlist_ID_1595 = "PLzPwkHWjEfOoWzavZVLHVY7i8QsGrBWJa"   
YOUTUBE_playlist_ID_1596 = "PLPLXRtz1DM87CoLUGe1R4yvmdMmH496rF"   
YOUTUBE_playlist_ID_1597 = "PLS8wuDWQWgZIcuOIFynK8s0qljcstqMCJ"   
YOUTUBE_playlist_ID_1598 = "PLu8fJwJ025Wtijrh9vpo_O6lG6hBsYwvq"   
YOUTUBE_playlist_ID_1599 = "PLti-4E6z-6OoSnWG93u8DkNVCZ7DtwyIa"   
YOUTUBE_playlist_ID_1600 = "PL2D684D989DAB10BB"   
YOUTUBE_playlist_ID_1601 = "PL8B027362379D8463"   
YOUTUBE_playlist_ID_1602 = "PL4JquojQ5dTvuFXm0-M7GPW9Uy9vuAE6N"   
YOUTUBE_playlist_ID_1603 = "PLvRPN7geKD70RUNl39o2dsg-K93Q6rP1Q" 
YOUTUBE_playlist_ID_1604 = "PL55A10D6EAE732452"   
YOUTUBE_playlist_ID_1605 = "PL091C595F5352BBFD"   
YOUTUBE_playlist_ID_1606 = "PLI4Fw-ASw-95YWDsR0XPVHk1zr6MUG5dz"   
YOUTUBE_playlist_ID_1607 = "PLLqlqs99CNG-2QFTHGymNzWAPrrRzaku6"   
YOUTUBE_playlist_ID_1608 = "PLFE3ABB25A457C47F"   
YOUTUBE_playlist_ID_1609 = "PLk_TsDc95-AS8GBbAvMpZ41MqQ6QD8Fl2"   
YOUTUBE_playlist_ID_1610 = "PLflr9Lcow6GFcLkoSFricM81GKssq5wF2"   
YOUTUBE_playlist_ID_1611 = "PLTMhQSTLVH2N8dbNStNUMa-p3iHgcBY8V"   
YOUTUBE_playlist_ID_1612 = "PLy_f9xg4Oms_eJcLwt95xWBtDWWVsEJdC"   
YOUTUBE_playlist_ID_1613 = "PL-me8j1U9xxJJDMv68ZemFyvnVLr5AZEN" 
YOUTUBE_playlist_ID_1614 = "PL9C89197557927A5A"   
YOUTUBE_playlist_ID_1615 = "PLufnvuHYZtEMMLsTxsmmTv95LrF-hYlb3"   
YOUTUBE_playlist_ID_1616 = "PL22A90250B2E1F1E6" 
YOUTUBE_playlist_ID_1617 = "PLrwE0KqGU92bpVXCOUnKsgqM8n2oCDZzp"  
YOUTUBE_playlist_ID_1618 = "PLgVtq2RPn9YF6yVit6hrK3C48BHejLNZr"   
YOUTUBE_playlist_ID_1619 = "PLSn65m0XaBNe0iUwfNH77fvWrGkAKcBVN"   
YOUTUBE_playlist_ID_1620 = "PLAi1KTNPmouS3UWFCedCBoLsgeGo0AkL3"   
YOUTUBE_playlist_ID_1621 = "PL1FLlE7_mGHfQh8n7NhJndXVGYdE5vJaJ"   
YOUTUBE_playlist_ID_1622 = "PLo8-BfPkuN2UwTlKZ2V3sA11JP-WT_uw-"   
YOUTUBE_playlist_ID_1623 = "PLo3UO5eUr2uqvO7PL7nNqC2HRWWAdpQoC"   
YOUTUBE_playlist_ID_1624 = "PLSfHFLHWefOX2Kzg2VyGBh41RbWr7fI-H" 
YOUTUBE_playlist_ID_1625 = "PLoMw37ylLfW_xkRe606WHJWu2FhWThatN"   
YOUTUBE_playlist_ID_1626 = "PLFwZZcad2Uq2HF5DugmsF_udMo2AuYW4t"   
YOUTUBE_playlist_ID_1627 = "PL5B8769382001D999"   
YOUTUBE_playlist_ID_1628 = "PL4fQUfIu-SlVzeOUwYs0meH1eVT2yhMfH"   
YOUTUBE_playlist_ID_1629 = "PLD2UssvTp14BuyyKX4O0paaF2rbvDp4T-"   
YOUTUBE_playlist_ID_1630 = "PL75D9AA53D2914381"   
YOUTUBE_playlist_ID_1631 = "PLWF6eiCM_1bkBFUG9ve2Vu0kYpiF3q-yz"   
YOUTUBE_playlist_ID_1632 = "PL0A62BF4CB615F925"   
YOUTUBE_playlist_ID_1633 = "PLEu5skf-5pO-Mp-gfTvhBJGvEnv74NM_g"   
YOUTUBE_playlist_ID_1634 = "PLMXUslkaDXyYtaNV3DHeV324NOB0iAZy1" 
YOUTUBE_playlist_ID_1635 = "PLDYSFcH1PeWWsZ7QfYJHJyJIFRAmY6bhw"   
YOUTUBE_playlist_ID_1636 = "PLIRRNHD2kK9SkyHzZE_q8sYK9ia8j4YUE"   
YOUTUBE_playlist_ID_1637 = "PL5kF1v0j15x1Q9ad0F6PUP5JHcYSLgyuE"   
YOUTUBE_playlist_ID_1638 = "PLLRadLfSeE_0BY7MuLQldFHNs4RuFwZ8G"   
YOUTUBE_playlist_ID_1639 = "PLE45I1wGz57QQ0BCzC1q6ilhG2QmiJgYt"   
YOUTUBE_playlist_ID_1640 = "PLggQZAQNM5CcaBw4hGIVYJQxwsVOJO33g"   
YOUTUBE_playlist_ID_1641 = "PLJcbSv_zlUdxUuJMw8q1VeX6FjuyBNYoH"   
YOUTUBE_playlist_ID_1642 = "PLC64DD46B865FFCAD"   
YOUTUBE_playlist_ID_1643 = "PL3B15E071AC2EE1E6"   
YOUTUBE_playlist_ID_1644 = "PLEF7BD6888326788B"  
YOUTUBE_playlist_ID_1645 = "PLo4-FcO5emNxRIKU7o7LqPHYAQjrhg0Bt"   
YOUTUBE_playlist_ID_1646 = "PL58n0Sm06PqO-IzV1YBYTQTbZMwfJ599X"   
YOUTUBE_playlist_ID_1647 = "PLJg8rYr0ToAD1Q6R2Bd20S-Y9-mK0XxyM"   
YOUTUBE_playlist_ID_1648 = "PL8C68AB9EB8055C8A"   
YOUTUBE_playlist_ID_1649 = "PLMLTuLSeb-L0osp7fMbZumImm_uXVzFht"   
YOUTUBE_playlist_ID_1650 = "PLNitVGYNCIxF85QLJSVeu_zVHzrh6X3XI"   
YOUTUBE_playlist_ID_1651 = "PL2H0HVz3HIGEbbHK9MWtfqn2a0zkKm1B5"   
YOUTUBE_playlist_ID_1652 = "PLIvCxKSFwu96H-9mTsn-Mx6P5Yy8thGFq"   
YOUTUBE_playlist_ID_1653 = "PL0XpjnMnHlVhM5hgZxO4uStdESHMBJCXL"   
YOUTUBE_playlist_ID_1654 = "PL60up8FJvonxWVCt2qMOzxy2D8FB1Rupt"  
YOUTUBE_playlist_ID_1655 = "PLg2SX7mQGE2qhn1TjtVDbOKz_-PSLB3BG"   
YOUTUBE_playlist_ID_1656 = "PLC51ldZ9V77xXwon8WmfKNvOtwLSupz1I"   
YOUTUBE_playlist_ID_1657 = "PLuuJ8WbrYqK8Sgq9s3kt5WZDw4DhO_PIM"   
YOUTUBE_playlist_ID_1658 = "PL9fmNdfUAf_dXDHAnWTAq233QmBdH2KSk"   
YOUTUBE_playlist_ID_1659 = "PLmOtBrs4Y6ZNJludUqKPwR_pmWI4HO_wc"   
YOUTUBE_playlist_ID_1660 = "PLeKylvrhHe3J8FeL2cAoFyYQtVkoAjXdw"   
YOUTUBE_playlist_ID_1661 = "PLdvRToFkJX-sx5nB1Nm_9wtGgkvLsXVmN"   
YOUTUBE_playlist_ID_1662 = "PLB1D55AE558E8350F"   
YOUTUBE_playlist_ID_1663 = "PLeVZQ1mxsoICPFkQ6aYgYleCYJI2hY8cM"   
YOUTUBE_playlist_ID_1664 = "PLiN-7mukU_REKTOSXby062ZAfpSk75tkQ"  
YOUTUBE_playlist_ID_1665 = "PLK-SXHR04gppUMJ-WefHY99I2yttopWmq"   
YOUTUBE_playlist_ID_1666 = "PL485DFAD9102857DE"   
YOUTUBE_playlist_ID_1667 = "PLW1w8neoXejvfbHotsf4LP_UsnJ4vy2yw"   
YOUTUBE_playlist_ID_1668 = "PLJBmIwTIee96EAE8MZPdAmN1z6i-ECvIY"   
YOUTUBE_playlist_ID_1669 = "PL94gOvpr5yt1BY3NF3q5pl9hOLwngVCkw"   
YOUTUBE_playlist_ID_1670 = "PLIjrSHPeUAj_xbycCxE-IR5Ifp-1JszJF"   
YOUTUBE_playlist_ID_1671 = "PLudFcBNiVGudFACn1CjsIn7_XbFa3goHY"   
YOUTUBE_playlist_ID_1672 = "PL448E8BFF20AC263D"   
YOUTUBE_playlist_ID_1673 = "PLdcb-Pi4CG_L4grKwvQ5n5TtHjrIO-izI"   
YOUTUBE_playlist_ID_1674 = "PLASuzI3bCn59_notfWAqUlfcZPaHbvEyf"  
YOUTUBE_playlist_ID_1675 = "PLCE10985CFB1E964B"   
YOUTUBE_playlist_ID_1676 = "PLC41999691B8925A9"   
YOUTUBE_playlist_ID_1677 = "PLzefpdunhnr5qhqyUzaAhjrtq5r8BMvv7"   
YOUTUBE_playlist_ID_1678 = "PLh-HeKPYsBao96F8HIkbw_pURytYDZUzT"   
YOUTUBE_playlist_ID_1679 = "PLUEz-ug6jtjU5QN5A1WxlN8m5ZGmZxVSZ"   
YOUTUBE_playlist_ID_1680 = "PLLPIalfi3B1KiP2B9Lz2UuHo9IALkJkPX"   
YOUTUBE_playlist_ID_1681 = "PL9vpdXZ1tnuJ7TvvixGDwUfc9DB2XloXD"   
YOUTUBE_playlist_ID_1682 = "PLtnzVENr5rVNr5DMa8sBPtbiFXLC5E79x"   
YOUTUBE_playlist_ID_1683 = "PLB08B4D07359272E4"   
YOUTUBE_playlist_ID_1684 = "PLURsmAtMbwRFiCTxtZnqKHoC1FTQIsznW"  
YOUTUBE_playlist_ID_1685 = "PL0fkc1XMPIeSLUuyUBMguBo3rohnsp5gN"   
YOUTUBE_playlist_ID_1686 = "PL_XBsr8LzFeUMSEJbk_0I1xS7iqD9fkVD"   
YOUTUBE_playlist_ID_1687 = "PLqkCyKxZ84h4XA1atIgbl4xHoLbIOCHKr"   
YOUTUBE_playlist_ID_1688 = "PLoaLI6j2pVtgpX_zU9DQBnNNLMsd69dQH"   
YOUTUBE_playlist_ID_1689 = "PLZIOAt65vv3oVDCWQFUr7TK5BPU5LuBHs"   
YOUTUBE_playlist_ID_1690 = "PLUV_RfcpmPOYCXeyHDv9AjoxyEXEH_pq8"   
YOUTUBE_playlist_ID_1691 = "PLFLfeXVbGg31JLUgiQ2SMD1viTTGpNYU1"   
YOUTUBE_playlist_ID_1692 = "PLF27EC815E8B06CEA"   
YOUTUBE_playlist_ID_1693 = "PLD26DA33B1F000388"   
YOUTUBE_playlist_ID_1694 = "PLjpdZVAwBy03BHXG_Jc1odTrwucLmViga"  
YOUTUBE_playlist_ID_1695 = "PL72AC1740573C1112"   
YOUTUBE_playlist_ID_1696 = "PLcki_-Qy-xDiomRJilhU998_8aSAbz8pw"   
YOUTUBE_playlist_ID_1697 = "PLjvA76lzbI0sDwEgyjOafwgXnQIyNhL2n"   
YOUTUBE_playlist_ID_1698 = "PLpC_fPUAaJND3j2nVTKHW5b8YdsWza6SO"   
YOUTUBE_playlist_ID_1699 = "PLrDr8rkvcLGtz-_ZfsEJEpHhzuSyW1mLG"   
YOUTUBE_playlist_ID_1700 = "PLINLMX1c0U5pjJ_yHdEQsZbo2arhfsExU"   
YOUTUBE_playlist_ID_1701 = "PLPfsQ2Jg6QevaIRimWjRxs5u6qJrQVwiz"   
YOUTUBE_playlist_ID_1702 = "PL7VYf9B2TiU6dLWxMkOT9WT2fjHTX9Yc-"   
YOUTUBE_playlist_ID_1703 = "PLXYTWf9yJNj-zl5952DdECcWkiLDoS209"   
YOUTUBE_playlist_ID_1704 = "PL-lQgJ3eJ1HvxZjU3Qdn9Ag0aDS5LbgKZ"  
YOUTUBE_playlist_ID_1705 = "PLM8Vwp7b5jN2moGQbHNBk859_wkWJ6omW" 
YOUTUBE_playlist_ID_1706 = "PL2C3B2929C2ED1A9C"   
YOUTUBE_playlist_ID_1707 = "PLMW_c1vyff9kSGL8hujLFHYkgU2Ylt-Bv"   
YOUTUBE_playlist_ID_1708 = "PL537390A646759FE4"   
YOUTUBE_playlist_ID_1709 = "PLhHJ5TCe0wNs4bNeMKd4YEBkYix8QG1za"   
YOUTUBE_playlist_ID_1710 = "PLKVRL_UeH6Isw0nCdsci3srDRLQ8H5t0J" 
YOUTUBE_playlist_ID_1711 = "PLnLj211Lr_yanQOGCFkC3ssnd7NiQyifi"   
YOUTUBE_playlist_ID_1712 = "PLU-LuWofJpmLxIN16wCSETOPY428i1Hjh"   
YOUTUBE_playlist_ID_1713 = "PL3Z46fSkb6nkJPmzp2tTGJ3ysASN8qJCq"   
YOUTUBE_playlist_ID_1714 = "PL2eBh4WlpATXYbvzPvKTs-_BGR6IJJG5j"   
YOUTUBE_playlist_ID_1715 = "PLtYJ9LJlt4qxfbWnk0jK2-RmUJEegY4Ez" 
YOUTUBE_playlist_ID_1716 = "PLNt4NSc2_ojZr4q2gtCqTRv5pUKOFvM5A"   
YOUTUBE_playlist_ID_1717 = "PLJ5cGDOKPw702IE89WlSqdxfsZR5pHNJa"   
YOUTUBE_playlist_ID_1718 = "PLo19p2sC9nr2WF8Jm37lhbbevPaUzeWj0"   
YOUTUBE_playlist_ID_1719 = "PLaRftaHsvxm7dPSZCQXYWxW22_5w2t7Hu"   
YOUTUBE_playlist_ID_1720 = "PL6hA3DNhDECi4bsZOXqUXvo6j1Ac_gNLQ" 
YOUTUBE_playlist_ID_1721 = "PLh1N75AiDBAAsZW1WpT5toxlPDE4-DdcK"   
YOUTUBE_playlist_ID_1722 = "PL085E2AA2A0DD5EFD"   
YOUTUBE_playlist_ID_1723 = "PL5wvriQ3KkYEPRlzco_gBuTG1x3xNVe_T"   
YOUTUBE_playlist_ID_1724 = "PLSCg4h0POi6UfnV0fvQAboAeHtgbTb-uy"   
YOUTUBE_playlist_ID_1725 = "PLL6Jbh8uhy35LKI3gUPTXdhewwzqn2oFX" 
YOUTUBE_playlist_ID_1726 = "PL2-xNSWcVzEffQPZGwIbgHxwgV6DcQm97"   
YOUTUBE_playlist_ID_1727 = "PLkBBLfT7tRGDJiSblrrAdOae1Oh8B0NA4"   
YOUTUBE_playlist_ID_1728 = "PL-haAX7WTpwmviOUc4cxaca4xzUoWagrW"   
YOUTUBE_playlist_ID_1729 = "PLx-yEaLfJzYGpsMLrm0mt8kTxWir_eeeC"   
YOUTUBE_playlist_ID_1730 = "PLYl-qMcBWSzj1XwG_7yzAaoB7CLiIi-yh" 
YOUTUBE_playlist_ID_1731 = "PL4_bxoNJAnh_9HpT01iedLVRSwirnAC7T"   
YOUTUBE_playlist_ID_1732 = "PLYa_OXrEIotdKtKA6oNpovAWdFVtJOqR-"   
YOUTUBE_playlist_ID_1733 = "PLDEC59BB38A4D9F9A"   
YOUTUBE_playlist_ID_1734 = "PLNC447WKz3rvBtma9Gzzz4YrNQevdUUq7"   
YOUTUBE_playlist_ID_1735 = "PLA37A55A97CF9A909"  
YOUTUBE_playlist_ID_1736 = "PLhH-_rO2_KPRumXE9AGcsGbZsJPYa_Hmr"   
YOUTUBE_playlist_ID_1737 = "PLeOcw7g_7LWWv6LYoBgsRV8u8lg1Uzd8O"   
YOUTUBE_playlist_ID_1738 = "PL6_ZRCoGDI-0e1YdDWrHeZ3Wgv1pjSzwZ"   
YOUTUBE_playlist_ID_1739 = "PLHUgsk1eUik-ISbfncBsK8Vpeq2gf2knz"   
YOUTUBE_playlist_ID_1740 = "PLxzBcKO5dbePgpyE5GKwYfuPZv8qZWE_S"
YOUTUBE_playlist_ID_1741 = "PLur6qGzaukU3u44it5fGUAgCtDofMw0Cr"   
YOUTUBE_playlist_ID_1742 = "PLGXw6GDeP7Dt5qBP3DJOjrSXYLmr1mXiJ"   
YOUTUBE_playlist_ID_1743 = "PLY-BfumRSziJGpy8Dpo7WY4nCQL0rAJE9"   
YOUTUBE_playlist_ID_1744 = "PLElqELnq3veXxqphzJ5QjoYy6vqDEAH6Z"   
YOUTUBE_playlist_ID_1745 = "PL8D4Iby0Bmm-nKJtBcg_1BHmukPlaniFk"   
YOUTUBE_playlist_ID_1746 = "PL6ehVJEY2n_8p4c0e8UzoRtolm8A1emm_"   
YOUTUBE_playlist_ID_1747 = "PLbBzBAGq5TKEM2knWZhEo05Y0Ymnuf9II"   
YOUTUBE_playlist_ID_1748 = "PLbKG7kYy2OWjZyHypzYfPqG7H7RRodrXb"   
YOUTUBE_playlist_ID_1749 = "PL5nrctquJucB2SgsGHM9uSvgLcEZf0VVd"   
YOUTUBE_playlist_ID_1750 = "PLA0AD0A43C617D41F"
YOUTUBE_playlist_ID_1751 = "PL2NJLU1QJypLKK14GzFl_z2d4qZ-ukj0g"   
YOUTUBE_playlist_ID_1752 = "PLzYNGnO6Bo2NGr6DOuO4vu7ErVrpSQOiz"   
YOUTUBE_playlist_ID_1753 = "PLhWAMz55RZfN3wR9sH9th3MyTZMKAeEr1"   
YOUTUBE_playlist_ID_1754 = "PLrx32OfkzOop42LOC31FOPDUXalw_KYS_"   
YOUTUBE_playlist_ID_1755 = "PLQq6u6FDJdOldGeAtNENEslptG3OrRApn"   
YOUTUBE_playlist_ID_1756 = "PLIBCozE-i4RPs39KpMWw01HLiPI7Lhprf"   
YOUTUBE_playlist_ID_1757 = "PLXs4nhrk8n05LiOPe_B9aMxgc5Yh3dlQa"   
YOUTUBE_playlist_ID_1758 = "PL8D4Iby0Bmm80DxVJ9IsnPnQ8P-QK6GlF"   
YOUTUBE_playlist_ID_1759 = "PL8D4Iby0Bmm_dLVsoRunF2fuoHH1DUXhU"   
YOUTUBE_playlist_ID_1760 = "PLr9ARTQnH0-NJzcPYMW4ADip99hJ36D8w"
YOUTUBE_playlist_ID_1761 = "PLhsSv8CHYoU3TkyY3-fd4arFpfHOGMklw"   
YOUTUBE_playlist_ID_1762 = "PLzdh0XbwuePMJ3eN_xY5ndQZiCGFW99K8"   
YOUTUBE_playlist_ID_1763 = "PLKmhzFrU9yGcNjXPMNUSG1SQYr5DFHrhE"   
YOUTUBE_playlist_ID_1764 = "PL8D4Iby0Bmm8OmcAYdZxiDl5igLVwFQ1J"   
YOUTUBE_playlist_ID_1765 = "PLur6qGzaukU38SYid4k4AWi5Xu4aZBJPE"   
YOUTUBE_playlist_ID_1766 = "PL8D4Iby0Bmm-g8xzHZUzNmj25Jf_N-Nnc"   
YOUTUBE_playlist_ID_1767 = "PL9rR-NTMf3Lx_xjXx-rZp2Vn8tKYWkNjr"   
YOUTUBE_playlist_ID_1768 = "PL8Lko0uFh_OZmnKJvd-9DhShXZKRDTfLg"   
YOUTUBE_playlist_ID_1769 = "PL25F30C387A7E9AA9"   
YOUTUBE_playlist_ID_1770 = "PLyNBiWeb_buFKWOGDavlGaBmpNcgQJY47"
YOUTUBE_playlist_ID_1771 = "PL8D4Iby0Bmm_u6dldszFSlpOSnCWwp8Sj"   
YOUTUBE_playlist_ID_1772 = "PLprqB9h4cfZb5BfxITjlTUCZur9FlA80f"   
YOUTUBE_playlist_ID_1773 = "PL8D4Iby0Bmm-soJW2sHKw1eoFYe2JvDsE"   
YOUTUBE_playlist_ID_1774 = "PLznIx3_zY-TwVNgCbWgXZfk5kpl59pBxE"   
YOUTUBE_playlist_ID_1775 = "PLuInyccoMbHGzAHriAmR7Su-FjSQX7p_4"   
YOUTUBE_playlist_ID_1776 = "PLjJ9M58LINExf6bvnP4vPi7fDh2GeIh7w"   
YOUTUBE_playlist_ID_1777 = "PL84D97F9E0C62F253"   
YOUTUBE_playlist_ID_1778 = "PL8D4Iby0Bmm8VqHbgQv1KTAB_en5D9Aih"   
YOUTUBE_playlist_ID_1779 = "PLfjSZVPTElA-B2ilWVXcvvw4NNQhP821o"   
YOUTUBE_playlist_ID_1780 = "PL8D4Iby0Bmm-uQIcbRfHeUMd_YDSZDA39"
YOUTUBE_playlist_ID_1781 = "PLqGkpApxFsX_jRp4sDFz9_gwztqqpDZ2U"   
YOUTUBE_playlist_ID_1782 = "PL1C555E0FCE0DE629"   
YOUTUBE_playlist_ID_1783 = "PLluZSsJUjKrEjLL7gwV71N_wCSgK30P_w"   
YOUTUBE_playlist_ID_1784 = "PLGXHsIJdc69nKdsnJtxAmeMZYW89e4pTe"   
YOUTUBE_playlist_ID_1785 = "PLtU_eILiw-sjeqxurJu7HDQi_v14yz8NE"   
YOUTUBE_playlist_ID_1786 = "PLh80vqesU2Qcm4psLz6weTHmYGwU7siey"   
YOUTUBE_playlist_ID_1787 = "PLAC476130CD6A2D67"   
YOUTUBE_playlist_ID_1788 = "PLJUH7JNLszy29GUgxT5eTpoiWWendqzss"   
YOUTUBE_playlist_ID_1789 = "PLsIK0RWGrHy1FIm5wLd2Y6emOnc7xAjia"   
YOUTUBE_playlist_ID_1790 = "PL1pFs4YXC6_hxlcWeMNcYvsFHLXGMelnx"
YOUTUBE_playlist_ID_1791 = "PL_3dlGnPgUZiInt4YuLEiBM4zQiO8-cW5"   
YOUTUBE_playlist_ID_1792 = "PL_3dlGnPgUZgmRnd2w4awMNcqftqWRKSu"   
YOUTUBE_playlist_ID_1793 = "PLckE5h5y5OhLvuG4MiIHZ1YX69QMPepHq"   
YOUTUBE_playlist_ID_1794 = "PL6ehVJEY2n_8p4c0e8UzoRtolm8A1emm_"   
YOUTUBE_playlist_ID_1795 = "PLKfJ5CLF-rwDqNGxXQrqywvcJEyEAPgV8"   
YOUTUBE_playlist_ID_1796 = "PLfmtCIepn9xnOrUrr7Px3ak_Y05oakoXM"   
YOUTUBE_playlist_ID_1797 = "PLhsSv8CHYoU2Y83CKQp6Pvaz-y-5_lkAH"   
YOUTUBE_playlist_ID_1798 = "PL8D4Iby0Bmm9GuYnOyMmpidjIS9g8xDtC"   
YOUTUBE_playlist_ID_1799 = "PLur6qGzaukU3Rf0Sr1q9IcWWUMnbKpjFh"   
YOUTUBE_playlist_ID_1800 = "PLglLEhldqRTN37zWaW6F3kPuFChsdcjvx"
YOUTUBE_playlist_ID_1801 = "PLE_9F5eV8FJfw6kWokllfZQDpUKL9LeNu"   
YOUTUBE_playlist_ID_1802 = "PLKZPhIn8-5PM-yzfUXc3o7Do-LXaw6yNj"   
YOUTUBE_playlist_ID_1803 = "PL8FD190FA838AA1B5"   
YOUTUBE_playlist_ID_1804 = "PL8D4Iby0Bmm8jRM7u1CwgpZ8-cYjF5V5r"   
YOUTUBE_playlist_ID_1805 = "PL1p79P36agMg4q2Txmk8T-twZMZK75qED"   
YOUTUBE_playlist_ID_1806 = "PL8D4Iby0Bmm94U_rwuJuocyC1xFoPTd5R"   
YOUTUBE_playlist_ID_1807 = "PL1a83T2-qyQaCaTf14OI12uSz3cPcrpMn"   
YOUTUBE_playlist_ID_1808 = "PLT6kNxqud5iKzm8Ds44NzCODpLC0IfUcR"   
YOUTUBE_playlist_ID_1809 = "PLprqB9h4cfZb6Q8OedAfKdH76ZmWAFXiA"   
YOUTUBE_playlist_ID_1810 = "PL_p01COUst8HigCd3K47RDW9WfDxKLwMZ"
YOUTUBE_playlist_ID_1811 = "PLur6qGzaukU07UHskYbED2uvdG5pwzmyr"   
YOUTUBE_playlist_ID_1812 = "PLprqB9h4cfZaVzN3E2COdj_dmSJSxzQwd"   
YOUTUBE_playlist_ID_1813 = "PL2EC1B23A4F9EDFAB"   
YOUTUBE_playlist_ID_1814 = "PL8D4Iby0Bmm-gi6w4g7ArnNdef-zblh8k"   
YOUTUBE_playlist_ID_1815 = "PLprqB9h4cfZYgTwHSjpYa3JHjJLn8Fgds"   
YOUTUBE_playlist_ID_1816 = "PLJAYfX8dUplTV9R65NkPKSm-mIwSJVyxr"   
YOUTUBE_playlist_ID_1817 = "PLcVnW2PwAus6IXWqMN-mS_T8SObe85XKR"   
YOUTUBE_playlist_ID_1818 = "PLL1rPzX0L_JkjeGt9zC_xzt0wZVuzQ4VG"   
YOUTUBE_playlist_ID_1819 = "PL9tY0BWXOZFug9gmE6yR39FF0xLDcIto8"   
YOUTUBE_playlist_ID_1820 = "PL_h9o2VpihhxNi14iCRsy0G5_DvBPfdSJ"
YOUTUBE_playlist_ID_1821 = "PLC_3WNGD2_ykwDqXq1z8oU6eZ3N4dEkOr"   
YOUTUBE_playlist_ID_1822 = "PL8D4Iby0Bmm8rohzdA2kgl9z_nOIzIwfd"   
YOUTUBE_playlist_ID_1823 = "PL8D4Iby0Bmm94U_rwuJuocyC1xFoPTd5R"   
YOUTUBE_playlist_ID_1824 = "PLfpdpsmtzQbWqUWKmZV5fV-_yNjZnV8QW"   
YOUTUBE_playlist_ID_1825 = "PL2NJLU1QJypIVnXIybYoZ-qrOGDj90u72"   
YOUTUBE_playlist_ID_1826 = "PLp7xMVxmZR0C3vy7fQ1BKQEAlYdYPshcl"   
YOUTUBE_playlist_ID_1827 = "PL7JpxXM1tzlaSImCEPFjbV6VTHRAczPHT"   
YOUTUBE_playlist_ID_1828 = "PLE003A6E530B01C3E"   
YOUTUBE_playlist_ID_1829 = "PL8D4Iby0Bmm-l5CtS2kHWxlUr08ag4W5f"   
YOUTUBE_playlist_ID_1830 = "PLmKABEDOsP1a_O6BDoAzgSWQp1rf19z44"
YOUTUBE_playlist_ID_1831 = "PLQS524_-0fqVu4ReGp_FY6xFgiq4nEY23"   
YOUTUBE_playlist_ID_1832 = "PL_3dlGnPgUZjpcnfxH5txC7VVL4kZ3zwY"   
YOUTUBE_playlist_ID_1833 = "PL8D4Iby0Bmm-D59aF5zKjer9pe3BqrTgM"   
YOUTUBE_playlist_ID_1834 = "PLL1Jom_mJPK5jcXsQe2gNZYP6zoYV0KUz"   
YOUTUBE_playlist_ID_1835 = "PL8D4Iby0Bmm-273NtcP5dAk1T5DcZuXIS"   
YOUTUBE_playlist_ID_1836 = "PL2853D0DA6F18C901"   
YOUTUBE_playlist_ID_1837 = "PLdugtpf4nXUtRNgshExNSHDjVRt3rhWJv"   
YOUTUBE_playlist_ID_1838 = "PLldnn1_ZePbJz06ntbbo2V_EIWKHNaNBJ"   
YOUTUBE_playlist_ID_1839 = "PLOwMvBWGjS50Gt8EFb0kjIFddrimFQ-zG"   
YOUTUBE_playlist_ID_1840 = "PLunbszRexkE4i4gXNWr4Iho02c_sZkpxi"
YOUTUBE_playlist_ID_1841 = "PLdhUaBrg59z_ZGhR1YDa3x5fzs-jvW40V"   
YOUTUBE_playlist_ID_1842 = "PL8D4Iby0Bmm8QUI5h6VTEZwv0DgcQmsDx"   
YOUTUBE_playlist_ID_1843 = "PLZoD8AKzZoNBi-hF0aNZZsq41r1cCkchp"   
YOUTUBE_playlist_ID_1844 = "PLim_cd6783O64pJTUkauq3sa7iIPw1wGi"   
YOUTUBE_playlist_ID_1845 = "PLprqB9h4cfZYUD0_gOREzsvKPwAIMVWNi"   
YOUTUBE_playlist_ID_1846 = "PL8D4Iby0Bmm_I4qUurA_3LEOcnOpn3uRn"   
YOUTUBE_playlist_ID_1847 = "PL_3dlGnPgUZiEPrB-0JLNI9YDg-47vovt"   
YOUTUBE_playlist_ID_1848 = "PLxBkdYSJdMyTp8LNBJjrW44R7MsKLBMgh"   
YOUTUBE_playlist_ID_1849 = "PLcVnW2PwAus5dcY-X7NPEzAHi2nCtLMaS"   
YOUTUBE_playlist_ID_1850 = "PLw6p6PA8M2mhSsIK4PF-wd4HkCzAntllm"
YOUTUBE_playlist_ID_1851 = "PLTUipEuIrfoUAEAlQ67VJPo0ftVtPKSkp"   
YOUTUBE_playlist_ID_1852 = "PLur6qGzaukU1-hTwGxA0Phvbe7-JPpxQE"   
YOUTUBE_playlist_ID_1853 = "PLPBRsJZxkVJf9xMY4H5UO0PhNwFoega2t"   
YOUTUBE_playlist_ID_1854 = "PLhDMC87gLmqqdKRAsiNRhv4-QrJxuW8VA"   
YOUTUBE_playlist_ID_1855 = "PLOwMvBWGjS50S2LTdrW3kK-uBuNHxp1Ma"   
YOUTUBE_playlist_ID_1856 = "PLBMo5y22220SwMTgtGoUPSDW1TScXzq3P"   
YOUTUBE_playlist_ID_1857 = "PLTuX1vsJDCaWMx3HoWhsXZAODAkvNojGh"   
YOUTUBE_playlist_ID_1858 = "PLJAYfX8dUplTV9R65NkPKSm-mIwSJVyxr"   
YOUTUBE_playlist_ID_1859 = "PLWEEt0QgQFIn8neNfE8EzRi1hsNn8CovL"   
YOUTUBE_playlist_ID_1860 = "PL9rR-NTMf3LxFGR8DluxG3CATTJqpmqji"
YOUTUBE_playlist_ID_1861 = "PL2agNrdTgdfIGRydqlNm0-6vSMSJApMLm"   
YOUTUBE_playlist_ID_1862 = "PLMO23pK5Dp1AMDkl1TffHUjr2aBRPL0HD"   
YOUTUBE_playlist_ID_1863 = "PL5ysWuY0ZZKX0koqNN-qD545DsNqWWgQH"   
YOUTUBE_playlist_ID_1864 = "PLzYNGnO6Bo2OxZsmA2-Q0lBFL0FO5xrwq"   
YOUTUBE_playlist_ID_1865 = "PLE62BAFEDD8162010"   
YOUTUBE_playlist_ID_1866 = "PLbKG7kYy2OWg3hgL1EC2E2N2lEGd8AC46"   
YOUTUBE_playlist_ID_1867 = "PLJ10nnOUjb8Tv-NhYe5GeyYx-QsCrxTkK"   
YOUTUBE_playlist_ID_1868 = "PL8D4Iby0Bmm-AFxvZbhUMzVCm6RiYjC2x"   
YOUTUBE_playlist_ID_1869 = "PLCfhIke0mwASt2sU5WrwUP7WtQoKSEI3m"   
YOUTUBE_playlist_ID_1870 = "PL3dzxbojOmVOOG_WcuYmF6xWCGEtCknCN"
YOUTUBE_playlist_ID_1871 = "PLbKG7kYy2OWiMP6xOKN9ldDGprdwW66FR"   
YOUTUBE_playlist_ID_1872 = "PLdZzClTcgSlUTzH8Vc5T_yoqO6pwRPLpc"   
YOUTUBE_playlist_ID_1873 = "PLqulx6unGTTd6BxGwou1PFj-JKY35V17K"   
YOUTUBE_playlist_ID_1874 = "PL8D4Iby0Bmm_nCLRUBNlG71BANSLP3RxW"   
YOUTUBE_playlist_ID_1875 = "PLpWCIRzTKg2kr0OqVODgVl8Egy6Gm3a0x"   
YOUTUBE_playlist_ID_1876 = "PLznIx3_zY-TwYgunstEYhBtlG7jfxTS4B"   
YOUTUBE_playlist_ID_1877 = "PLdZzClTcgSlX6D6Goaa94mQ4mekn8h7Jj"   
YOUTUBE_playlist_ID_1878 = "PLdZzClTcgSlXjBWV7D1VhXvGQblibP0eb"   
YOUTUBE_playlist_ID_1879 = "PL8D4Iby0Bmm9WJTbBiJIuBmAXaaOkxMRB"   
YOUTUBE_playlist_ID_1880 = "PLznIx3_zY-TxVVmJnPSPOVuU2eAm9RKD6"
YOUTUBE_playlist_ID_1881 = "PLn4GvABOzCQssR8CQ5dUECmSLkCHmFI5P"   
YOUTUBE_playlist_ID_1882 = "PL2Eh0b64x1o-3MHwUuAFMQWjiHmRr1Ahs"   
YOUTUBE_playlist_ID_1883 = "PLn4GvABOzCQtoJMGd4rpRjq2hjfo5ySXN"   
YOUTUBE_playlist_ID_1884 = "PLJtpjlkBVF4zz1kyCPzr-Ahw84ofGYBaC"   
YOUTUBE_playlist_ID_1885 = "PLqGkpApxFsX_jRp4sDFz9_gwztqqpDZ2U"   
YOUTUBE_playlist_ID_1886 = "PL2QDU69iXWC5k9c6AbmEvOQlII4qws797"   
YOUTUBE_playlist_ID_1887 = "PL8D4Iby0Bmm9y57_K3vBvkZiaGjIXD_x5"   
YOUTUBE_playlist_ID_1888 = "PL0F6E957156489D23"   
YOUTUBE_playlist_ID_1889 = "PL8D4Iby0Bmm-or87MPGIgPf6dcSTe1cDy"   
YOUTUBE_playlist_ID_1890 = "PLi3QVLt-dw0IWikoGcUgJdJpyjHgAurKX"
YOUTUBE_playlist_ID_1891 = "PLaBaq8MtdL-b3uvPEl2TKj6b1Ukemjvns"   
YOUTUBE_playlist_ID_1892 = "PL8D4Iby0Bmm8JKpuXNscifeVJxONw0zEW"   
YOUTUBE_playlist_ID_1893 = "PLTfrnDl20kIOmlwIT7LtUL8iX8UHAzqOw"   
YOUTUBE_playlist_ID_1894 = "PLOC3nsYGhpAvsd0L2Xy3WJDwEKaFSpvBt"   
YOUTUBE_playlist_ID_1895 = "PL0EPwLkmf8bvvG1jDhjcAxwahjL87eUMz"   
YOUTUBE_playlist_ID_1896 = "PL1B57C09DFDA8A2BD"   
YOUTUBE_playlist_ID_1897 = "PLFyvgMP3QJSGune-qfJjiBOPx5DjbUWY6"   
YOUTUBE_playlist_ID_1898 = "PLFyvgMP3QJSF8ZoHtdq3yp0YSlaMc8QGj"   
YOUTUBE_playlist_ID_1899 = "PL8D4Iby0Bmm-3CTbWPPyRDc6tV-ilRMXp"   
YOUTUBE_playlist_ID_1900 = "PL8sjzjEZEcxck6BBqmcWgZ3WN3gN9iUB6"   
# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec(action+"(params)")
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]MusicHall Videoclips, [COLOR magenta]Siguenos  en el Grupo Telegram @AprendiendoKodi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1+"/",
        thumbnail="https://i.imgur.com/yr7txZt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Conciertos MusicHall, [COLOR magenta]Siguenos en el Grupo Telegram @AprendiendoKodi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_2+"/",
        thumbnail="https://i.imgur.com/6tbCPcq.jpg",
		fanart="https://i.imgur.com/6tbCPcq.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Clasicos MusicHall, [COLOR magenta]Siguenos en el Grupo Telegram @AprendiendoKodi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_01+"/",
        thumbnail="https://i.imgur.com/g0FzKY9.jpg",
		fanart="https://i.imgur.com/g0FzKY9.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]MusicHall Sessions, [COLOR magenta]Siguenos en el Grupo Telegram @AprendiendoKodi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_02+"/",
        thumbnail="https://i.imgur.com/yr7txZt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aquamarine]Buscador[/COLOR]",
        url=YOUTUBE_search,
        thumbnail="https://i.imgur.com/yr7txZt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]90s Music Dance[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1333+"/",
        thumbnail="https://i.imgur.com/dmp9DOf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Acid House Groovy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_111+"/",
        thumbnail="https://i.imgur.com/eRy3y8x.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]African Hits Song 2019[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_123+"/",
        thumbnail="https://i.imgur.com/GDCmvY8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Aires De Cuba[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_146+"/",
        thumbnail="https://i.imgur.com/ba6b0aX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alternative rock of the 2000s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_10+"/",
        thumbnail="https://i.imgur.com/V1ZqiX9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alucinante Canto Gregoriano Pop Rock[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_147+"/",
        thumbnail="https://i.imgur.com/TezNQwI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Antologia De La Jota Aragonesa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1081+"/",
        thumbnail="https://i.imgur.com/Q5zELwm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bachata[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_156+"/",
        thumbnail="https://i.imgur.com/eiLCAU9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Baladas De Ayer Hoy y Siempre[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_106+"/",
        thumbnail="https://i.imgur.com/JYDY7w6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Baladas Pop En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_83+"/",
        thumbnail="https://i.imgur.com/WOJzJbw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Baladas y Boleros[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1082+"/",
        thumbnail="https://i.imgur.com/3d5hZLv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ballroom Dancing Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1083+"/",
        thumbnail="https://i.imgur.com/iAR1kM6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bandas Heavy Metal 80s 90s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1334+"/",
        thumbnail="https://i.imgur.com/gWVO7I2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bast Boosted[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_167+"/",
        thumbnail="https://i.imgur.com/uN5VVWA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Best Classic rock mix[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_8+"/",
        thumbnail="https://i.imgur.com/ZvwVGKf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Best Summer Songs 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1335+"/",
        thumbnail="https://i.imgur.com/vTGGF0u.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Best Women Jazz Music of All Time[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_53+"/",
        thumbnail="https://i.imgur.com/qPgX7rO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Big Room[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_175+"/",
        thumbnail="https://i.imgur.com/9QYu2LG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Billboard 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_143+"/",
        thumbnail="https://i.imgur.com/0HzRnK7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Billboard Hot Week 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1336+"/",
        thumbnail="https://i.imgur.com/IVkUiFN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Billboard Retro Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1337+"/",
        thumbnail="https://i.imgur.com/lRHQI8m.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Boleros[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_64+"/",
        thumbnail="https://i.imgur.com/52v0FZO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bossanova Canciones en Acustico[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_59+"/",
        thumbnail="https://i.imgur.com/d3kFnc1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Boys Band[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_138+"/",
        thumbnail="https://i.imgur.com/y075DdT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]BSO Canciones De Peliculas Famosas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_84+"/",
        thumbnail="https://i.imgur.com/X0Jm2xZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]BSO Grease[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1338+"/",
        thumbnail="https://i.imgur.com/WQCeG8a.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Canciones De Telenovelas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1339+"/",
        thumbnail="https://i.imgur.com/9JmsXjc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Canciones Nostalgicas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1084+"/",
        thumbnail="https://i.imgur.com/DcKTy7m.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Canciones Romanticas en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_105+"/",
        thumbnail="https://i.imgur.com/RpbOayc.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Canciones Spot Publicitarios[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_129+"/",
        thumbnail="https://i.imgur.com/G47GcR6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cante Flamenco - Figuras del cante Jondo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_30+"/",
        thumbnail="https://i.imgur.com/Tbi5AfE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chambao Chill Out[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_13+"/",
        thumbnail="https://i.imgur.com/THq2a2S.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Charleston Music Dance[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1085+"/",
        thumbnail="https://i.imgur.com/PjPNDHE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chill Out[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_12+"/",
        thumbnail="https://i.imgur.com/yTnsSPZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chillout Lounge[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1340+"/",
        thumbnail="https://i.imgur.com/smlOPsx.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chillout Lounge - Spotify[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_24+"/",
        thumbnail="https://i.imgur.com/CMhwl96.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chirigotas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_127+"/",
        thumbnail="https://i.imgur.com/ABRt8SO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Clasicos Del Funk[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_110+"/",
        thumbnail="https://i.imgur.com/992TtX4.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Clasicos De La Musica Electronica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_32+"/",
        thumbnail="https://i.imgur.com/GVH8gc0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Clasicos del Rap Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_73+"/",
        thumbnail="https://i.imgur.com/RMZ0aXQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Clasicos del Rock en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_11+"/",
        thumbnail="https://i.imgur.com/KyVQSrI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Clubland Classics Dance[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1341+"/",
        thumbnail="https://i.imgur.com/TItAwzj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Conciertos en Directo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_33+"/",
        thumbnail="https://i.imgur.com/D0e8euc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Copla Española[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_70+"/",
        thumbnail="https://i.imgur.com/FnIz7PG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Country De Los 70 80[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_135+"/",
        thumbnail="https://i.imgur.com/Je1f67V.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cumbia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_151+"/",
        thumbnail="https://i.imgur.com/OaVd21R.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dance Music Party[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1342+"/",
        thumbnail="https://i.imgur.com/IN7E40S.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Death metal 2020 2021[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1343+"/",
        thumbnail="https://i.imgur.com/iiBGTzk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Disco Funk Soul 70s 80s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_37+"/",
        thumbnail="https://i.imgur.com/CEelwt2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Disco Hits of the 70s 80s 90s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_38+"/",
        thumbnail="https://i.imgur.com/Tp3VTg0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Disco La Casa Fuerte[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1344+"/",
        thumbnail="https://i.imgur.com/s3IsNqu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dragon Ball Z Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1345+"/",
        thumbnail="https://i.imgur.com/w89mv7V.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]El mejor Flamenquito 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_26+"/",
        thumbnail="https://i.imgur.com/r8XeyVC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Europa FM - Lista de Exitos 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_18+"/",
        thumbnail="https://i.imgur.com/J75Rikb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Euskal Musik[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_80+"/",
        thumbnail="https://i.imgur.com/XVeJXCt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Eurovision[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_102+"/",
        thumbnail="https://i.imgur.com/mEDVpJV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Exitos En Español De Los 70[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1086+"/",
        thumbnail="https://i.imgur.com/fIwHpsv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Exitos Radio Ole[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_120+"/",
        thumbnail="https://i.imgur.com/7tNHdSK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Femme Fatale Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1346+"/",
        thumbnail="https://i.imgur.com/cXQxPmN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ganadores Eurovision 1956-2019[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_103+"/",
        thumbnail="https://i.imgur.com/Qly45Xg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Fandangos y Cante Jondo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_31+"/",
        thumbnail="https://i.imgur.com/Rf0hkuk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Fado Portugues[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_165+"/",
        thumbnail="https://i.imgur.com/9HD48Br.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Flamenco Pop Mix[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_29+"/",
        thumbnail="https://i.imgur.com/8OUagSi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Flashback Romantico Internacional[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_107+"/",
        thumbnail="https://i.imgur.com/8TIN5ff.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Folk Mexicano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_96+"/",
        thumbnail="https://i.imgur.com/PIBo335.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Foxtrot[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1087+"/",
        thumbnail="https://i.imgur.com/oV1fONp.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Garaje Rock[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_154+"/",
        thumbnail="https://i.imgur.com/MtZWQ9b.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Girls Power[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_139+"/",
        thumbnail="https://i.imgur.com/vqDri8j.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Glam And Hair Metal de Los 80[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_98+"/",
        thumbnail="https://i.imgur.com/MSfTpef.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Goguettes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_166+"/",
        thumbnail="https://i.imgur.com/2wBrN7y.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gospel Hits 2019[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_131+"/",
        thumbnail="https://i.imgur.com/6jMAiVH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Grandes Exitos de la Musica Indie en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_48+"/",
        thumbnail="https://i.imgur.com/SgDCIxN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Grunge The Best[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_155+"/",
        thumbnail="https://i.imgur.com/qztwyR3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Guitarra Clasica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_42+"/",
        thumbnail="https://i.imgur.com/qWr7skf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Guitarra Clasica Española[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_25+"/",
        thumbnail="https://i.imgur.com/HNHuitY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hard Rock 80s & 90s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_22+"/",
        thumbnail="https://i.imgur.com/BlBjux5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hard Rock 2 De Los 80 y 90[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_94+"/",
        thumbnail="https://i.imgur.com/j106577.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hard Rock Woman Singers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_140+"/",
        thumbnail="https://i.imgur.com/I7xcyNo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hilo Musical Canciones Para Recordar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_87+"/",
        thumbnail="https://i.imgur.com/Ehbz3nY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hilo Musical En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_86+"/",
        thumbnail="https://i.imgur.com/wvT1oqu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hilo Musical Internacional[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_85+"/",
        thumbnail="https://i.imgur.com/q4edbhf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hits Dance 2020 2021 Classifica Mtv[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_39+"/",
        thumbnail="https://i.imgur.com/3ytyF7o.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Humppa Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_168+"/",
        thumbnail="https://i.imgur.com/VQhEqJP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ibiza Music 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1347+"/",
        thumbnail="https://i.imgur.com/SoRVIbq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Indian American Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_124+"/",
        thumbnail="https://i.imgur.com/JS8p1k5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Industrial Techno, Dark, Gotic[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1348+"/",
        thumbnail="https://i.imgur.com/mGT8yBF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Inspirational Gospel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1088+"/",
        thumbnail="https://i.imgur.com/OIuJwdt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jesucristo Super Star Camilo Sesto[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_118+"/",
        thumbnail="https://i.imgur.com/B1iJrPR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Joropo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_164+"/",
        thumbnail="https://i.imgur.com/gTEWlax.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]JPOP 2020 2021[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1349+"/",
        thumbnail="https://i.imgur.com/s1uaL0B.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jukebox 50s 60s Oldies Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1350+"/",
        thumbnail="https://i.imgur.com/A1Y9W0i.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jukebox 80s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1351+"/",
        thumbnail="https://i.imgur.com/SHWyG5y.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jukebox Postmodern Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1352+"/",
        thumbnail="https://i.imgur.com/uUkAO8W.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]80s Love Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1736+"/",
        thumbnail="https://i.imgur.com/oQ9ncbN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1737+"/",
        thumbnail="https://i.imgur.com/I7lF04g.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Abba[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1738+"/",
        thumbnail="https://i.imgur.com/j6LhxC8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Acustico[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1739+"/",
        thumbnail="https://i.imgur.com/ycXhaEz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]All Time Female[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1740+"/",
        thumbnail="https://i.imgur.com/PVp4IXb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Alternative Rock[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1741+"/",
        thumbnail="https://i.imgur.com/Llv4Sfc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Anime Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1742+"/",
        thumbnail="https://i.imgur.com/AP3hUeW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Aquellos 60s,70s 80 & 90s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1743+"/",
        thumbnail="https://i.imgur.com/58PIeVI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Ariana Grandes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1744+"/",
        thumbnail="https://i.imgur.com/03Qyj3H.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Baladas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1745+"/",
        thumbnail="https://i.imgur.com/IQjWMTk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Baladas De Oro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1746+"/",
        thumbnail="https://i.imgur.com/pWAYP6e.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Baladas Inolvidables[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1747+"/",
        thumbnail="https://i.imgur.com/ZewnS4W.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Baritone Or Bass Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1748+"/",
        thumbnail="https://i.imgur.com/PBAsHFP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Beatles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1749+"/",
        thumbnail="https://i.imgur.com/Oc2wEKf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Bee Gees[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1750+"/",
        thumbnail="https://i.imgur.com/OPc7Gi1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Best Oldies Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1751+"/",
        thumbnail="https://i.imgur.com/NMeT55x.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Billie Ellish Instrumental[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1752+"/",
        thumbnail="https://i.imgur.com/wrHFsaq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Boleros[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1753+"/",
        thumbnail="https://i.imgur.com/7TvV1nc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Boleros y Baladas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1754+"/",
        thumbnail="https://i.imgur.com/I7lF04g.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Bollywood Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1755+"/",
        thumbnail="https://i.imgur.com/bRH4KK9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Bon Jovi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1756+"/",
        thumbnail="https://i.imgur.com/zIhyCgQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Broadway[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1757+"/",
        thumbnail="https://i.imgur.com/CKlvRj7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Bruno Mars[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1758+"/",
        thumbnail="https://i.imgur.com/lO05dMr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Camila Cabello[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1759+"/",
        thumbnail="https://i.imgur.com/WFmtpr6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Canta Con Tu Artista[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1760+"/",
        thumbnail="https://i.imgur.com/yYnc4n3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Carpenters[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1761+"/",
        thumbnail="https://i.imgur.com/ZtqLNEX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Celine Dion[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1762+"/",
        thumbnail="https://i.imgur.com/SMOj6mu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Christian[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1763+"/",
        thumbnail="https://i.imgur.com/4zLtl7L.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Christmas Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1764+"/",
        thumbnail="https://i.imgur.com/9n7tHdv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Classics Rock[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1765+"/",
        thumbnail="https://i.imgur.com/CaLZ4VA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Classics Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1766+"/",
        thumbnail="https://i.imgur.com/biLIN5U.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Con Voz y Letra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1767+"/",
        thumbnail="https://i.imgur.com/gUdmRTI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Country[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1768+"/",
        thumbnail="https://i.imgur.com/fILknVV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Dance Party[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1769+"/",
        thumbnail="https://i.imgur.com/OhXOXgN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]De Los 90s A Los 2000[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1770+"/",
        thumbnail="https://i.imgur.com/I7lF04g.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]De Pelicula[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1771+"/",
        thumbnail="https://i.imgur.com/KmHP4nl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Def Leppard[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1772+"/",
        thumbnail="https://i.imgur.com/cw1X6o7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Demi Lovato[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1773+"/",
        thumbnail="https://i.imgur.com/k53ZIon.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Disney[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1774+"/",
        thumbnail="https://i.imgur.com/K1mrsGz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Disney II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1775+"/",
        thumbnail="https://i.imgur.com/3uUw2TO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Duetos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1776+"/",
        thumbnail="https://i.imgur.com/n3iMUkF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Easy & Fun[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1777+"/",
        thumbnail="https://i.imgur.com/ei1GlZP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]El Gran Showman[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1778+"/",
        thumbnail="https://i.imgur.com/RKkCTJD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Elvis Presley[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1779+"/",
        thumbnail="https://i.imgur.com/4zpOTi0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Empieza La Fiesta[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1780+"/",
        thumbnail="https://i.imgur.com/v2Qq7E4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]En Español 2019[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1781+"/",
        thumbnail="https://i.imgur.com/avoApPu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke [COLOR magenta] En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_144+"/",
        thumbnail="https://i.imgur.com/07zHCNa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]En Español II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1782+"/",
        thumbnail="https://i.imgur.com/FK52OVa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]En Frances[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1783+"/",
        thumbnail="https://i.imgur.com/ycXhaEz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]En Italiano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1784+"/",
        thumbnail="https://i.imgur.com/5VdAo2d.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Exitos De Los 90[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1785+"/",
        thumbnail="https://i.imgur.com/7tfsBzy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Fiesta[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1786+"/",
        thumbnail="https://i.imgur.com/omSCJxH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Fiesta II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1787+"/",
        thumbnail="https://i.imgur.com/3GpU5Ss.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Folk[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1788+"/",
        thumbnail="https://i.imgur.com/IXTJtey.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Folk Venezolano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1789+"/",
        thumbnail="https://i.imgur.com/UI2pgyt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Frank Sinatra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1790+"/",
        thumbnail="https://i.imgur.com/w1Z9ayI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Generacion Rock[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1791+"/",
        thumbnail="https://i.imgur.com/cUpMrNq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Girls Power[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1792+"/",
        thumbnail="https://i.imgur.com/XmLjuYe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Glam De Los 80s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1793+"/",
        thumbnail="https://i.imgur.com/p93Wi91.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Golden Ballads[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1794+"/",
        thumbnail="https://i.imgur.com/YR1QwlT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Gospel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1795+"/",
        thumbnail="https://i.imgur.com/qUewmhg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Greatest Love Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1796+"/",
        thumbnail="https://i.imgur.com/PGVhzzJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Guarani[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1797+"/",
        thumbnail="https://i.imgur.com/TO9oWeP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Halloween Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1798+"/",
        thumbnail="https://i.imgur.com/OzF19w7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Hard Rock Classic[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1799+"/",
        thumbnail="https://i.imgur.com/T7v9dzH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Heavy Metal Classic[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1800+"/",
        thumbnail="https://i.imgur.com/8pkxtEL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Heavy Metal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1801+"/",
        thumbnail="https://i.imgur.com/pLbxSXP.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]High School Musical[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1802+"/",
        thumbnail="https://i.imgur.com/5RnPG4J.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Holidays Party[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1803+"/",
        thumbnail="https://i.imgur.com/IA30uY3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Indie Pop[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1804+"/",
        thumbnail="https://i.imgur.com/F0AKmdo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Instrumental Whit Lyrics[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1805+"/",
        thumbnail="https://i.imgur.com/R9UDwAS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke [COLOR magenta] Internacional[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_145+"/",
        thumbnail="https://i.imgur.com/72SbWDP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Internacional II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1806+"/",
        thumbnail="https://i.imgur.com/HDIVIIi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]International 60s 70s 80s y 90s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1807+"/",
        thumbnail="https://i.imgur.com/zHoT87e.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]International Academy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1808+"/",
        thumbnail="https://i.imgur.com/XB6bl1D.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Iron Maiden[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1809+"/",
        thumbnail="https://i.imgur.com/QaJWcfG.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Italian Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1810+"/",
        thumbnail="https://i.imgur.com/L2uc2RF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Jazz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1811+"/",
        thumbnail="https://i.imgur.com/iREgcJA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Judas Priets[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1812+"/",
        thumbnail="https://i.imgur.com/E5aXHYw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Julio Iglesias[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1813+"/",
        thumbnail="https://i.imgur.com/rpDLK4W.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Katty Perry[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1814+"/",
        thumbnail="https://i.imgur.com/xrFK2Bo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Kiss[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1815+"/",
        thumbnail="https://i.imgur.com/ZJTIxH2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]La Movida Madrileña[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1816+"/",
        thumbnail="https://i.imgur.com/TbabxyF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Lady Gaga[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1817+"/",
        thumbnail="https://i.imgur.com/2Tr6ckX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Lana Del Rey[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1818+"/",
        thumbnail="https://i.imgur.com/F0Pb3q1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Latin Party[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1819+"/",
        thumbnail="https://i.imgur.com/DW7s0kx.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1820+"/",
        thumbnail="https://i.imgur.com/o24cYG8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Lo Mas Cantado[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1821+"/",
        thumbnail="https://i.imgur.com/qhRIzW0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Lo Mas Nuevo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1822+"/",
        thumbnail="https://i.imgur.com/vxGFSD4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Lo Mas Popular Del Momento[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1823+"/",
        thumbnail="https://i.imgur.com/JMOqcrc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Lo Mejor De Los 50s,60s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1824+"/",
        thumbnail="https://i.imgur.com/MqpKrn2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Love Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1825+"/",
        thumbnail="https://i.imgur.com/XJhZLvR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Mamma Mia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1826+"/",
        thumbnail="https://i.imgur.com/pYjVWfT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Mariachi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1827+"/",
        thumbnail="https://i.imgur.com/jL8ksKD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Mariachi Girls[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1828+"/",
        thumbnail="https://i.imgur.com/oI49vv4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Melanie Martinez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1829+"/",
        thumbnail="https://i.imgur.com/y4y3AiY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Merengue[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1830+"/",
        thumbnail="https://i.imgur.com/DtH4idt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Metal de Los 80s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1831+"/",
        thumbnail="https://i.imgur.com/FNZXg5L.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Modern Rock Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1832+"/",
        thumbnail="https://i.imgur.com/0sjdwUf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]MTV 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1833+"/",
        thumbnail="https://i.imgur.com/WyB7jCq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Oldies Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1834+"/",
        thumbnail="https://i.imgur.com/paFVzuR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]One Direction[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1835+"/",
        thumbnail="https://i.imgur.com/xVyjA2i.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Pasillos Ecuatorianos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1836+"/",
        thumbnail="https://i.imgur.com/9DIp1fL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Placebo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1837+"/",
        thumbnail="https://i.imgur.com/tuRaaWt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Playlist Male[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1838+"/",
        thumbnail="https://i.imgur.com/Ogw0Hqv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Pop Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1839+"/",
        thumbnail="https://i.imgur.com/NpHWNnx.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Pop Español 60s 70s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1840+"/",
        thumbnail="https://i.imgur.com/5UIHHZX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Pop Indonesio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1841+"/",
        thumbnail="https://i.imgur.com/cQhgV85.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Pop Rock[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1842+"/",
        thumbnail="https://i.imgur.com/XK3q693.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Pop Rock En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1843+"/",
        thumbnail="https://i.imgur.com/kWElbow.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Popular Do Brasil[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1844+"/",
        thumbnail="https://i.imgur.com/UhcZrjY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Power Ballads[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1845+"/",
        thumbnail="https://i.imgur.com/4ZubSCD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Queen[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1846+"/",
        thumbnail="https://i.imgur.com/OPBrnjx.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]R&B Soul[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1847+"/",
        thumbnail="https://i.imgur.com/5og407l.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Rancheras[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1848+"/",
        thumbnail="https://i.imgur.com/AcRCXjJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Rihanna[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1849+"/",
        thumbnail="https://i.imgur.com/CwidfeH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Rock & Hard Rock Ballads[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1850+"/",
        thumbnail="https://i.imgur.com/3Vemnxg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Rock 90s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1851+"/",
        thumbnail="https://i.imgur.com/Fs0ey0I.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Rock Classics[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1852+"/",
        thumbnail="https://i.imgur.com/D0jMJac.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Rock En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1853+"/",
        thumbnail="https://i.imgur.com/odMZYZy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Rock Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1854+"/",
        thumbnail="https://i.imgur.com/LBpLaWk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Rumbas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1855+"/",
        thumbnail="https://i.imgur.com/Xgz24Oh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Sabor Latino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1856+"/",
        thumbnail="https://i.imgur.com/hrgl5HL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Sad Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1857+"/",
        thumbnail="https://i.imgur.com/MvWZ3Vy.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Salsa 2019[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1858+"/",
        thumbnail="https://i.imgur.com/l1tx4Tu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Salsa Canciones Populares[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1859+"/",
        thumbnail="https://i.imgur.com/5UWW6CV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Salsa y Merengue[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1860+"/",
        thumbnail="https://i.imgur.com/ZP10c3c.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Samoan Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1861+"/",
        thumbnail="https://i.imgur.com/3JXZ4cW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Single Woman[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1862+"/",
        thumbnail="https://i.imgur.com/uMTiuN3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Slow Rock[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1863+"/",
        thumbnail="https://i.imgur.com/4TunMAV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Solo Piano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1864+"/",
        thumbnail="https://i.imgur.com/V6LSpSP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Songs Whit Lead Vocal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1865+"/",
        thumbnail="https://i.imgur.com/jZcXzWy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Soprano Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1866+"/",
        thumbnail="https://i.imgur.com/JgVv0zO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Sweeney Todd[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1867+"/",
        thumbnail="https://i.imgur.com/vddnvbe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Taylor Swift[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1868+"/",
        thumbnail="https://i.imgur.com/gUNnK9x.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Teatro Musical[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1869+"/",
        thumbnail="https://i.imgur.com/3evKc2n.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Teatro Musical II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1870+"/",
        thumbnail="https://i.imgur.com/4o4JXsG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Tenor Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1871+"/",
        thumbnail="https://i.imgur.com/bCM7bye.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]The Best Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1872+"/",
        thumbnail="https://i.imgur.com/SYw90Gd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]The Corrs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1873+"/",
        thumbnail="https://i.imgur.com/IQLdZbb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Tik Tok Song[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1874+"/",
        thumbnail="https://i.imgur.com/d7EJmbX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Top 50s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1875+"/",
        thumbnail="https://i.imgur.com/xqfwD6I.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Top 60s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1876+"/",
        thumbnail="https://i.imgur.com/bR3ragu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Top 70s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1877+"/",
        thumbnail="https://i.imgur.com/QZLMSQU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Top 80s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1878+"/",
        thumbnail="https://i.imgur.com/8gkPpPJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Top 90s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1879+"/",
        thumbnail="https://i.imgur.com/O4rTOXs.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Top 2000[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1880+"/",
        thumbnail="https://i.imgur.com/XeyhnCR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Top 2017[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1881+"/",
        thumbnail="https://i.imgur.com/d74anPy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Top 2018[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1882+"/",
        thumbnail="https://i.imgur.com/TyqrZco.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Top 2019[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1883+"/",
        thumbnail="https://i.imgur.com/O9pkuEZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Top 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1884+"/",
        thumbnail="https://i.imgur.com/buYX5XK.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Top Hits All Time[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1885+"/",
        thumbnail="https://i.imgur.com/TENElWk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Top Lyrics Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1886+"/",
        thumbnail="https://i.imgur.com/MumQiyW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Top Popular[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1887+"/",
        thumbnail="https://i.imgur.com/fav7fkI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]U2[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1888+"/",
        thumbnail="https://i.imgur.com/zwM74RP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Valentine's Day[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1889+"/",
        thumbnail="https://i.imgur.com/gwxmAsv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Vallenato[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1890+"/",
        thumbnail="https://i.imgur.com/uIzxWwo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Vallenato II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1891+"/",
        thumbnail="https://i.imgur.com/jPod8Ki.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Variado[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1892+"/",
        thumbnail="https://i.imgur.com/1A4jwCi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Variado II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1893+"/",
        thumbnail="https://i.imgur.com/E8paDHl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Variado III[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1894+"/",
        thumbnail="https://i.imgur.com/5mdAeGv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Variado IV[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1895+"/",
        thumbnail="https://i.imgur.com/LOFN0HE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Variado V[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1896+"/",
        thumbnail="https://i.imgur.com/1A4jwCi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Villancicos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1897+"/",
        thumbnail="https://i.imgur.com/tmxWei6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Villancicos II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1898+"/",
        thumbnail="https://i.imgur.com/c6QH3cA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Woman Power Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1899+"/",
        thumbnail="https://i.imgur.com/IeZTF5o.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]Karaoke  [COLOR magenta]Woman Power Songs II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1900+"/",
        thumbnail="https://i.imgur.com/R9UDwAS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )   

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kiss Fm Radio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_122+"/",
        thumbnail="https://i.imgur.com/zgtcvHY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]KPOP 2020 2021 Korean Pop Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_119+"/",
        thumbnail="https://i.imgur.com/2dH0kMC.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Edad De Oro Del Pop Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1353+"/",
        thumbnail="https://i.imgur.com/Su1v3qt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Movida Madrileña[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1089+"/",
        thumbnail="https://i.imgur.com/OH7V1bt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Nova CanÇo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1090+"/",
        thumbnail="https://i.imgur.com/4spWRIW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Las Mejores Rancheras[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_66+"/",
        thumbnail="https://i.imgur.com/g3D7PdH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Latino Total 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_82+"/",
        thumbnail="https://i.imgur.com/U7wOsZk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Late 70s Soul Funk & Disco Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_36+"/",
        thumbnail="https://i.imgur.com/a1F1Guf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mas Escuchado 2019-2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_15+"/",
        thumbnail="https://i.imgur.com/AmoXCbH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mas Escuchado 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1111+"/",
        thumbnail="https://i.imgur.com/jXEGMME.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mas Nuevo Del Rap Y Hip Hop En Español 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_75+"/",
        thumbnail="https://i.imgur.com/j2rpjC7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mejor De La Musica Clasica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1354+"/",
        thumbnail="https://i.imgur.com/sELiWJ6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mejor De La Tuna[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1091+"/",
        thumbnail="https://i.imgur.com/HPd3VBz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mejor De Los 50, 60 y 70[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1355+"/",
        thumbnail="https://i.imgur.com/wc8cElW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mejor Del Freestyle[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_829+"/",
        thumbnail="https://i.imgur.com/QOiOSz0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mejor Del Rap En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_828+"/",
        thumbnail="https://i.imgur.com/p4wKLl1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )				

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Mejores Boleros de Todos los Tiempos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_65+"/",
        thumbnail="https://i.imgur.com/7B9EKjJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Mejores Exitos de Guitarra Española[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_43+"/",
        thumbnail="https://i.imgur.com/StuplSO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mejor Del Country[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_134+"/",
        thumbnail="https://i.imgur.com/urbBmOZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mejor de la Opera Lirica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_116+"/",
        thumbnail="https://i.imgur.com/FAyOGUX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mejor del Reggae[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_56+"/",
        thumbnail="https://i.imgur.com/MLHdoft.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Mejor de La Zarzuela[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_68+"/",
        thumbnail="https://i.imgur.com/nhq4fNY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lounge Music 2019[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_23+"/",
        thumbnail="https://i.imgur.com/JBBhJlm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]M80 Serie Oro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_121+"/",
        thumbnail="https://i.imgur.com/RnSB4FW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Marchas Militares Españolas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_170+"/",
        thumbnail="https://i.imgur.com/xZiu8gV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Marchas Nupciales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_161+"/",
        thumbnail="https://i.imgur.com/IZA7IYc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Marchas De Procesiones y Cofrades[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_128+"/",
        thumbnail="https://i.imgur.com/v4pa3vM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mariachi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_97+"/",
        thumbnail="https://i.imgur.com/UNxdqB1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mejores Canciones Rumba Flamenca Pop 2020-2021[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_27+"/",
        thumbnail="https://i.imgur.com/R5Cdma5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mejores Canciones de la Radio 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_34+"/",
        thumbnail="https://i.imgur.com/s1eaBKA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mejores Canciones Musica rock[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_9+"/",
        thumbnail="https://i.imgur.com/iDA38r1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Merengue[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_153+"/",
        thumbnail="https://i.imgur.com/8JKJzpo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mento Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_163+"/",
        thumbnail="https://i.imgur.com/wDfVaG1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Metal Sinfonico Gotico[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_113+"/",
        thumbnail="https://i.imgur.com/WNCPlsd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Metalcore 2020 2021[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1357+"/",
        thumbnail="https://i.imgur.com/Z9mW1X3.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Milongas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_169+"/",
        thumbnail="https://i.imgur.com/1wQ3gBu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mix Internacional 2020-2021[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_6+"/",
        thumbnail="https://i.imgur.com/i4avcbK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mix Reggaeton 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_14+"/",
        thumbnail="https://i.imgur.com/G7HgD9Q.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Monster Jam Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1358+"/",
        thumbnail="https://i.imgur.com/94UJ9UY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Monster Truck Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1359+"/",
        thumbnail="https://i.imgur.com/CHNid8a.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Monster Truck Theme Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1360+"/",
        thumbnail="https://i.imgur.com/RfMpYpV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]MTV Greatest Hits[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_61+"/",
        thumbnail="https://i.imgur.com/77rD8gZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mtv Top Songs 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_60+"/",
        thumbnail="https://i.imgur.com/9W3ieuN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]MTV Top Hits[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_62+"/",
        thumbnail="https://i.imgur.com/I1ZjuSS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Music From Valhalla[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1361+"/",
        thumbnail="https://i.imgur.com/Ph8YznL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Andina[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1092+"/",
        thumbnail="https://i.imgur.com/lwtTWi0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Barroca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_125+"/",
        thumbnail="https://i.imgur.com/RyYkttl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Brasilera 2020 Lo Mas Escuchado[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_58+"/",
        thumbnail="https://i.imgur.com/ihMknfV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Canaria[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_101+"/",
        thumbnail="https://i.imgur.com/YB2VTF5.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Celta Epica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_81+"/",
        thumbnail="https://i.imgur.com/iYn8iZ5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Clasica Instrumental[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_21+"/",
        thumbnail="https://i.imgur.com/VLFhuAJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica De Peliculas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1362+"/",
        thumbnail="https://i.imgur.com/4ZigBF7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Del Alma Kundalini Yoga[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_92+"/",
        thumbnail="https://i.imgur.com/9JId3Um.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Española De Los 60 70[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1093+"/",
        thumbnail="https://i.imgur.com/k90xH0a.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Española Flamenco Pop[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_28+"/",
        thumbnail="https://i.imgur.com/CPRNpCl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Disco De Los 70s 80s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1363+"/",
        thumbnail="https://i.imgur.com/SL5lUtr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Folk Latina[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_95+"/",
        thumbnail="https://i.imgur.com/6uOvnoq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Gallega[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_104+"/",
        thumbnail="https://i.imgur.com/XikeTkl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Hebrea[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1365+"/",
        thumbnail="https://i.imgur.com/zY8cFaX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Italiana top 80s-90s-00s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_45+"/",
        thumbnail="https://i.imgur.com/15I8Syb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Navideña Internacional[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_88+"/",
        thumbnail="https://i.imgur.com/SILxjqZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Para Bailar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_17+"/",
        thumbnail="https://i.imgur.com/Ou7Kjmw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Retro Disco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_109+"/",
        thumbnail="https://i.imgur.com/qMTvcIo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Tradicional Japonesa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1094+"/",
        thumbnail="https://i.imgur.com/2HGiHTY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Variada de Todo un Poco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_16+"/",
        thumbnail="https://i.imgur.com/RJ018Tm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Musica Zingara[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1366+"/",
        thumbnail="https://i.imgur.com/bs2OIC0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]New Age[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_159+"/",
        thumbnail="https://i.imgur.com/HxZwpcm.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]New Metal Songs 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_93+"/",
        thumbnail="https://i.imgur.com/QRSyQMA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nightcore[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1095+"/",
        thumbnail="https://i.imgur.com/Mz7XUrX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nightcore 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_148+"/",
        thumbnail="https://i.imgur.com/2c70Ajm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Novedades POP en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_47+"/",
        thumbnail="https://i.imgur.com/5Em3PAr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Now Thats What I Call Summer Hits[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1367+"/",
        thumbnail="https://i.imgur.com/jZp6uZL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Operas Completas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1368+"/",
        thumbnail="https://i.imgur.com/opcNWdO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Opera Rock The Best Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_117+"/",
        thumbnail="https://i.imgur.com/AKDIKiL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pasodobles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_69+"/",
        thumbnail="https://i.imgur.com/QBhm3w9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pop 2020 2021[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1369+"/",
        thumbnail="https://i.imgur.com/tk3ZDbT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pop Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_54+"/",
        thumbnail="https://i.imgur.com/RBQnFAW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pop Latino Clasico[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_5+"/",
        thumbnail="https://i.imgur.com/P5eJVmT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pop Latino Mix 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_20+"/",
        thumbnail="https://i.imgur.com/hcUe0tq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]POP Music  2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_3+"/",
        thumbnail="https://i.imgur.com/bbN45sb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pop Music Lo Mejor de Todos los Tiempos 2020-2021[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_4+"/",
        thumbnail="https://i.imgur.com/0eq7tXz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pop Rock En Catala 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_78+"/",
        thumbnail="https://i.imgur.com/a5G4AC0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Progresive Metal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1370+"/",
        thumbnail="https://i.imgur.com/J6MAukr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Punk Rock En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_79+"/",
        thumbnail="https://i.imgur.com/dJwMB0Q.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pop Rock Best of 1990 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_55+"/",
        thumbnail="https://i.imgur.com/CFbI5Lb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Radio One 103.7[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1371+"/",
        thumbnail="https://i.imgur.com/C1NKaqB.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rancheras Para El Recuerdo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_67+"/",
        thumbnail="https://i.imgur.com/KT3IJGx.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rap[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_850+"/",
        thumbnail="https://i.imgur.com/vVAbrsy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rap II[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_851+"/",
        thumbnail="https://i.imgur.com/EcxpKF4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rap Argentino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_852+"/",
        thumbnail="https://i.imgur.com/NhvK3hl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rap Boom[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_853+"/",
        thumbnail="https://i.imgur.com/NABMu02.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rap Cultura Torneo 2019[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_854+"/",
        thumbnail="https://i.imgur.com/C4IDWas.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rap España[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_855+"/",
        thumbnail="https://i.imgur.com/nXNUpi4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rap Final Nacional España 2017[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_857+"/",
        thumbnail="https://i.imgur.com/hlgAUNv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rap Final Nacional España 2018[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_856+"/",
        thumbnail="https://i.imgur.com/T4fSD2p.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rap Love[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_858+"/",
        thumbnail="https://i.imgur.com/bP5sWtj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rap Trap[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_859+"/",
        thumbnail="https://i.imgur.com/VqWUqVU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rap Variado[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_860+"/",
        thumbnail="https://i.imgur.com/rxvzvKc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rap y Beatbox[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_861+"/",
        thumbnail="https://i.imgur.com/r3LL1eV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rap Conciencia Hip -Hop en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_76+"/",
        thumbnail="https://i.imgur.com/0jz5zlD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rap Hip Hop en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_71+"/",
        thumbnail="https://i.imgur.com/IDjIjyC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Reggaeton 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1096+"/",
        thumbnail="https://i.imgur.com/rQa7a6r.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Reggaeton Hits[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_40+"/",
        thumbnail="https://i.imgur.com/TRPvO7t.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Reggaeton 2019 Playlist & Latin Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_41+"/",
        thumbnail="https://i.imgur.com/L3SQ5YE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Reggae En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_57+"/",
        thumbnail="https://i.imgur.com/XJzhCnd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Reggae Playlist[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_63+"/",
        thumbnail="https://i.imgur.com/RwoHeoK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Retro Disco Infierno[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_132+"/",
        thumbnail="https://i.imgur.com/2Egvoiz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Road Trip Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_150+"/",
        thumbnail="https://i.imgur.com/wIKuXVQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rock A Violin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_114+"/",
        thumbnail="https://i.imgur.com/GPlojss.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rock 80s y 90s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_7+"/",
        thumbnail="https://i.imgur.com/vOuU0yR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rock Metal 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1372+"/",
        thumbnail="https://i.imgur.com/Kl2G66x.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rockabilly Boogie Woogie[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_133+"/",
        thumbnail="https://i.imgur.com/tVfeXT5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rock Instrumental de Guitarra Electrica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_44+"/",
        thumbnail="https://i.imgur.com/j2skU30.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rock Sinfonico[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_112+"/",
        thumbnail="https://i.imgur.com/eCAqWKM.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rumba y Flamenco Pop[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1301+"/",
        thumbnail="https://i.imgur.com/GkFzL1X.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rumbas 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_99+"/",
        thumbnail="https://i.imgur.com/YPim42g.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ruta Del Bacalao[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_100+"/",
        thumbnail="https://i.imgur.com/Fokvewf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sevillanas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1097+"/",
        thumbnail="https://i.imgur.com/RmMKY2P.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sintonias TV[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_130+"/",
        thumbnail="https://i.imgur.com/waFnhGS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ska Songs All Time[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_152+"/",
        thumbnail="https://i.imgur.com/bp8CADg.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sophistic Pop[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_172+"/",
        thumbnail="https://i.imgur.com/rCgSu9P.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Spotify Playlist 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_35+"/",
        thumbnail="https://i.imgur.com/MHnErB6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Surf Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_160+"/",
        thumbnail="https://i.imgur.com/33CbTO0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tandas de Tango[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_142+"/",
        thumbnail="https://i.imgur.com/ZV4GxzF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Templar Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1373+"/",
        thumbnail="https://i.imgur.com/W1a3TT2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Annual 2020 Ministry Of Sound[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1374+"/",
        thumbnail="https://i.imgur.com/O3kTqci.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The London Simphony Orchestra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1375+"/",
        thumbnail="https://i.imgur.com/vvPNUE7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Third Stream Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_173+"/",
        thumbnail="https://i.imgur.com/0cElGqF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Throwback Exitos de 1990 a 2000[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_149+"/",
        thumbnail="https://i.imgur.com/z19nx22.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Timeless Dance Bachata[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_137+"/",
        thumbnail="https://i.imgur.com/wyhNR9g.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top 50 España Exitos 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_19+"/",
        thumbnail="https://i.imgur.com/OHUtwe0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Best Rhythm aquas & Soul 60s 70s 80s & 90s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_108+"/",
        thumbnail="https://i.imgur.com/vVB0s2n.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Love Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1098+"/",
        thumbnail="https://i.imgur.com/7X4SCAf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Mejores aquas aquas-Rock  Jazz All Time[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_52+"/",
        thumbnail="https://i.imgur.com/nkIeyUi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Mejores Canciones Español 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_50+"/",
        thumbnail="https://i.imgur.com/X1fPsK3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Metal 2020 2021[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1376+"/",
        thumbnail="https://i.imgur.com/hPsGpeR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Party Dance[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1377+"/",
        thumbnail="https://i.imgur.com/9b2zfc7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Hip Hop Español 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_72+"/",
        thumbnail="https://i.imgur.com/yRggM5p.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Jazz Classics Songs of All Time[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_51+"/",
        thumbnail="https://i.imgur.com/ThRjE2R.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Las 50 Mejores Canciones del Rap en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_74+"/",
        thumbnail="https://i.imgur.com/u2zu8el.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Musica Italiana del Momento[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_46+"/",
        thumbnail="https://i.imgur.com/NP8qwiG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Musica Piano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_126+"/",
        thumbnail="https://i.imgur.com/RGcOde6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Todo Retro En Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_141+"/",
        thumbnail="https://i.imgur.com/jHumbuT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Top Trap España 2020[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_49+"/",
        thumbnail="https://i.imgur.com/92HJf5u.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tradicional y Fusion Latina[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1099+"/",
        thumbnail="https://i.imgur.com/TFylKm4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Trova[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_157+"/",
        thumbnail="https://i.imgur.com/QKqCmE7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ultimate F1 Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1378+"/",
        thumbnail="https://i.imgur.com/sVRd6ei.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Urban[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_158+"/",
        thumbnail="https://i.imgur.com/XgfVp4C.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Vallenato[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_136+"/",
        thumbnail="https://i.imgur.com/eP5NkL4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Valses[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_162+"/",
        thumbnail="https://i.imgur.com/ZkTTIeU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]VaporWave Best Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_174+"/",
        thumbnail="https://i.imgur.com/bF6lgYm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Villancicos en Español[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_89+"/",
        thumbnail="https://i.imgur.com/yYtbToH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Villancicos Heavy Metal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_90+"/",
        thumbnail="https://i.imgur.com/qvbZxjf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Wardruna Viking Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1379+"/",
        thumbnail="https://i.imgur.com/nYRWlGQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Wednesday Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_77+"/",
        thumbnail="https://i.imgur.com/fQZunsr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]World Music Polka Songs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1380+"/",
        thumbnail="https://i.imgur.com/o28OPQR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Yaravis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_171+"/",
        thumbnail="https://i.imgur.com/qYElmVv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
	    #action="", 
        title="[COLOR aqua]Zen Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_91+"/",
        thumbnail="https://i.imgur.com/Vmg7Kz2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]2 Unlimited[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1424+"/",
        thumbnail="https://i.imgur.com/dNZRGhV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]1000 Mods[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1425+"/",
        thumbnail="https://i.imgur.com/WJJfx9Q.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]6ix9ine[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1100+"/",
        thumbnail="https://i.imgur.com/FrzoKqY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Aaron Carter[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_771+"/",
        thumbnail="https://i.imgur.com/D5Qnixz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Abraham Mateo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_772+"/",
        thumbnail="https://i.imgur.com/fHLAUgX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Accept[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1426+"/",
        thumbnail="https://i.imgur.com/6arsHu8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Aczino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_773+"/",
        thumbnail="https://i.imgur.com/MC0wLWH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Aczino Vs Chuty[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_774+"/",
        thumbnail="https://i.imgur.com/8kN77wp.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Adamo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_881+"/",
        thumbnail="https://i.imgur.com/MWtmXQ1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]A Day To Remenber[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_176+"/",
        thumbnail="https://i.imgur.com/9a9jp8K.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Abba[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_177+"/",
        thumbnail="https://i.imgur.com/8qMcf9r.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]AcDc[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_178+"/",
        thumbnail="https://i.imgur.com/kN7n8Xx.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Adele[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_179+"/",
        thumbnail="https://i.imgur.com/4nVJfi8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Adelitas Way[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_180+"/",
        thumbnail="https://i.imgur.com/oxFtYS9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Adexe y Nau[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_882+"/",
        thumbnail="https://i.imgur.com/KA0Q1cT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Adriano Celentano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1051+"/",
        thumbnail="https://i.imgur.com/H5GUzLE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Aerosmith[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_181+"/",
        thumbnail="https://i.imgur.com/ZwzaOz5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Aguaviva[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1101+"/",
        thumbnail="https://i.imgur.com/6AZpJuU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]A Ha[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_605+"/",
        thumbnail="https://i.imgur.com/OtLxINC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ainoha Arteta[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_606+"/",
        thumbnail="https://i.imgur.com/t8X3eVz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Airbourne[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_182+"/",
        thumbnail="https://i.imgur.com/WW86GfF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Air Supply[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_607+"/",
        thumbnail="https://i.imgur.com/poDoYvn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Al Bano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_883+"/",
        thumbnail="https://i.imgur.com/Nq283hd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Al Stewart[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_608+"/",
        thumbnail="https://i.imgur.com/4eW7MI4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alabama Shakes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1427+"/",
        thumbnail="https://i.imgur.com/GpRLK05.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alabama Thunderpussy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1428+"/",
        thumbnail="https://i.imgur.com/IDvxzbr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alameda[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_884+"/",
        thumbnail="https://i.imgur.com/gy36u0T.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alan Jackson[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1706+"/",
        thumbnail="https://i.imgur.com/AAwHLDg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alan Parsons[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_183+"/",
        thumbnail="https://i.imgur.com/uQikm93.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alanis Morissette[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_184+"/",
        thumbnail="https://i.imgur.com/coP0PRC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alannah Myles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1302+"/",
        thumbnail="https://i.imgur.com/Dcy7bOS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alaska Y Dinarama[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_185+"/",
        thumbnail="https://i.imgur.com/Hyyxpdz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Albert Hammond[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1711+"/",
        thumbnail="https://i.imgur.com/cixujLy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alberto Cortez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_885+"/",
        thumbnail="https://i.imgur.com/VlRyLHp.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alcatrazz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1429+"/",
        thumbnail="https://i.imgur.com/9Emqk3k.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alcazar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1712+"/",
        thumbnail="https://i.imgur.com/J2J0x22.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alejandro Abad[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1102+"/",
        thumbnail="https://i.imgur.com/dXclLD9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alejandro Sanz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_186+"/",
        thumbnail="https://i.imgur.com/l5ErmP5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alesha Dixon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_775+"/",
        thumbnail="https://i.imgur.com/t2ZacOf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alfredo Kraus[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_609+"/",
        thumbnail="https://i.imgur.com/suyFKt0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alice Cooper[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_610+"/",
        thumbnail="https://i.imgur.com/pyyKrJ2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alice Chater[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1286+"/",
        thumbnail="https://i.imgur.com/vfxZRf0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alice In Chains[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_187+"/",
        thumbnail="https://i.imgur.com/LlIh3fJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alicia Keys[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_776+"/",
        thumbnail="https://i.imgur.com/fTA9BY3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]All That Remains[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_188+"/",
        thumbnail="https://i.imgur.com/74XM5Ke.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Amanda Lear[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1430+"/",
        thumbnail="https://i.imgur.com/eoMGnMw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alphaville[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_189+"/",
        thumbnail="https://i.imgur.com/K69A9SB.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Alter Bridge[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_190+"/",
        thumbnail="https://i.imgur.com/rMxmI4f.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Amaia Montero[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_611+"/",
        thumbnail="https://i.imgur.com/KbP9jgM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Amaral[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_191+"/",
        thumbnail="https://i.imgur.com/VwAmSgj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Amaranthe[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_192+"/",
        thumbnail="https://i.imgur.com/Aak3Du3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]American Authors[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_193+"/",
        thumbnail="https://i.imgur.com/FIzRgyn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Amigos De Gines[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_886+"/",
        thumbnail="https://i.imgur.com/BF2TtQB.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Amii Stewart[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1431+"/",
        thumbnail="https://i.imgur.com/cyMWUlP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Amistades Peligrosas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_777+"/",
        thumbnail="https://i.imgur.com/eB8iWTG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Amon Amarth[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_194+"/",
        thumbnail="https://i.imgur.com/ryvP4w6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Amparanoia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1103+"/",
        thumbnail="https://i.imgur.com/wvJU7yz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Amy Winehouse[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_195+"/",
        thumbnail="https://i.imgur.com/T7uboVc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Amyl And The Sniffers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1432+"/",
        thumbnail="https://i.imgur.com/sOZgYnV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ana Belen[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_612+"/",
        thumbnail="https://i.imgur.com/dSYFQzu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ana Guerra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_613+"/",
        thumbnail="https://i.imgur.com/2jcxDds.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ana Reverte[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_887+"/",
        thumbnail="https://i.imgur.com/4LdXTvW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ana Torroja[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_778+"/",
        thumbnail="https://i.imgur.com/k7sOPjh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Anabantha[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1433+"/",
        thumbnail="https://i.imgur.com/ei1rDZZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Anabel Conde[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1104+"/",
        thumbnail="https://i.imgur.com/aT5wHQP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Anastasia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_740+"/",
        thumbnail="https://i.imgur.com/8u7e1zn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Andrea Bocelli[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_614+"/",
        thumbnail="https://i.imgur.com/38gT0Fm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Andres Calamaro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_763+"/",
        thumbnail="https://i.imgur.com/5TonGbg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Andres Do Barro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1105+"/",
        thumbnail="https://i.imgur.com/JpyxOy7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Andres Segovia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1283+"/",
        thumbnail="https://i.imgur.com/8yeeS1P.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Anita Ward[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1434+"/",
        thumbnail="https://i.imgur.com/t8sz4yF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Andy y Lucas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_615+"/",
        thumbnail="https://i.imgur.com/NBZsgvt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Angeles Azules[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1106+"/",
        thumbnail="https://i.imgur.com/GVrZxFN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Angeles Del Infierno[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1107+"/",
        thumbnail="https://i.imgur.com/gTHqwvd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Angelillo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_888+"/",
        thumbnail="https://i.imgur.com/3VElHEm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Anne Marie[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1108+"/",
        thumbnail="https://i.imgur.com/knP9Kvq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Annie Lennox[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1303+"/",
        thumbnail="https://i.imgur.com/Hhl0HjZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Anthrax[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_196+"/",
        thumbnail="https://i.imgur.com/djE3Jo1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Antoni Parera Fons[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1109+"/",
        thumbnail="https://i.imgur.com/K8XmbEq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Antonio Flores[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_779+"/",
        thumbnail="https://i.imgur.com/1YytMv1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Antonio Machin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1052+"/",
        thumbnail="https://i.imgur.com/m8Xny8F.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Antonio Molina[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_889+"/",
        thumbnail="https://i.imgur.com/1axKpaq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Antonio Orozco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_197+"/",
        thumbnail="https://i.imgur.com/O0ybARK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Antoñita Moreno[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_890+"/",
        thumbnail="https://i.imgur.com/goA1I3S.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Antoñita Peñuela[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1110+"/",
        thumbnail="https://i.imgur.com/JiMG7BN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Anuel AA[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1112+"/",
        thumbnail="https://i.imgur.com/vU1XdOq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Arcano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_616+"/",
        thumbnail="https://i.imgur.com/NWHKdvo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Arch Enemy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1435+"/",
        thumbnail="https://i.imgur.com/6vyPCva.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Aretha Franklin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_198+"/",
        thumbnail="https://i.imgur.com/tPltQ7P.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ariadna Grande[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_199+"/",
        thumbnail="https://i.imgur.com/qQyvkNn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Arkano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_617+"/",
        thumbnail="https://i.imgur.com/DTreZdT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Armando Manzanero[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1113+"/",
        thumbnail="https://i.imgur.com/hz2rrdQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Artic Monkeys[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_200+"/",
        thumbnail="https://i.imgur.com/BZyq1Yz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]As I Lay Dying[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_201+"/",
        thumbnail="https://i.imgur.com/xwbHvYw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Asia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_618+"/",
        thumbnail="https://i.imgur.com/fvPxdsy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Asking Alexandria[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_202+"/",
        thumbnail="https://i.imgur.com/2h0VpHL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Atomic Kitten[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1713+"/",
        thumbnail="https://i.imgur.com/SnHUUhs.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Atomic Rooster[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1436+"/",
        thumbnail="https://i.imgur.com/LaDwX27.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Atreyu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_203+"/",
        thumbnail="https://i.imgur.com/DArawdD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Audiomachine[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1437+"/",
        thumbnail="https://i.imgur.com/12Gg3Hu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Audioslave[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_204+"/",
        thumbnail="https://i.imgur.com/q0rrvXL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Auryn[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_891+"/",
        thumbnail="https://i.imgur.com/nfcKpJZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ava Max[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1304+"/",
        thumbnail="https://i.imgur.com/pIDSz2c.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Avalanch[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_205+"/",
        thumbnail="https://i.imgur.com/pgvnnS9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Avantasia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_619+"/",
        thumbnail="https://i.imgur.com/Up4Rks8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Avenged Sevenfold[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_206+"/",
        thumbnail="https://i.imgur.com/2X3x6vX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Aviador Dro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_207+"/",
        thumbnail="https://i.imgur.com/pRn3oIv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Avici[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1305+"/",
        thumbnail="https://i.imgur.com/CAFvgw2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Avril Lavigne[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_208+"/",
        thumbnail="https://i.imgur.com/2iTTt5C.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Azucar Moreno[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_209+"/",
        thumbnail="https://i.imgur.com/dk4TUcZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Azealia Banks[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1114+"/",
        thumbnail="https://i.imgur.com/MkvNna6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]B Witched[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1714+"/",
        thumbnail="https://i.imgur.com/KyDcgqQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Babymetal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_210+"/",
        thumbnail="https://i.imgur.com/LQBx0Sj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Baccara[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_892+"/",
        thumbnail="https://i.imgur.com/lIvz4U1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bach, Johann Sebastian[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1381+"/",
        thumbnail="https://i.imgur.com/PcQe62Q.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bachman Turner Overdrive[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1438+"/",
        thumbnail="https://i.imgur.com/PkWwIid.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Back Street Boys[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_211+"/",
        thumbnail="https://i.imgur.com/o7Xlb6u.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bad Boy Blue[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1439+"/",
        thumbnail="https://i.imgur.com/ZNtjZsQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bad Bunny[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1331+"/",
        thumbnail="https://i.imgur.com/MtPOQLt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bad Pollyanna[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1440+"/",
        thumbnail="https://i.imgur.com/sw4bHvS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bad Wolves[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_212+"/",
        thumbnail="https://i.imgur.com/zAikx1V.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bambino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1053+"/",
        thumbnail="https://i.imgur.com/OJAbwhi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bananarama[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_780+"/",
        thumbnail="https://i.imgur.com/I3ieL6O.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Barbra Streisand[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_741+"/",
        thumbnail="https://i.imgur.com/zl7esGM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Barei[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1115+"/",
        thumbnail="https://i.imgur.com/y7IX26G.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Baron Rojo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_213+"/",
        thumbnail="https://i.imgur.com/OQItE4h.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Baroness[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1441+"/",
        thumbnail="https://i.imgur.com/4re1Okc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Barrabas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1038+"/",
        thumbnail="https://i.imgur.com/wqBB2GO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )			
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Barry Manilow[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_620+"/",
        thumbnail="https://i.imgur.com/5HNeqPm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bartok, Bela[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1382+"/",
        thumbnail="https://i.imgur.com/gs6AzQM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Barry Whyte[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_214+"/",
        thumbnail="https://i.imgur.com/ri07nPX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Basilio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_893+"/",
        thumbnail="https://i.imgur.com/Vd1rf5l.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Beastie Boys[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_781+"/",
        thumbnail="https://i.imgur.com/p8lpvhz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bebe[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_621+"/",
        thumbnail="https://i.imgur.com/tul4XtL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bebe Rexha[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_782+"/",
        thumbnail="https://i.imgur.com/0Z4iUjj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Becky G[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_622+"/",
        thumbnail="https://i.imgur.com/vnehoey.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bee Gees[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_215+"/",
        thumbnail="https://i.imgur.com/YuxJS0W.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Beethoven, Ludwig Van[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1383+"/",
        thumbnail="https://i.imgur.com/zUZZV8L.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )			
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Belinda Carlise[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_783+"/",
        thumbnail="https://i.imgur.com/UQQWwvE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Belle Epoque[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1442+"/",
        thumbnail="https://i.imgur.com/YgyLVQU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bellini, Vicenzo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1384+"/",
        thumbnail="https://i.imgur.com/pfurAAa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bely Basarte[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1116+"/",
        thumbnail="https://i.imgur.com/mkLZjRv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Benito Lestxundi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1117+"/",
        thumbnail="https://i.imgur.com/c3exP6d.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Benny Goodman[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1118+"/",
        thumbnail="https://i.imgur.com/cpz1gwL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bereiz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1119+"/",
        thumbnail="https://i.imgur.com/9IZhe9R.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Beret[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_760+"/",
        thumbnail="https://i.imgur.com/8RcaSR7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Berlioz, Hector[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1385+"/",
        thumbnail="https://i.imgur.com/2q7oTOv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Berstein, Leonard[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1386+"/",
        thumbnail="https://i.imgur.com/msvE79G.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bertin Osborne[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_623+"/",
        thumbnail="https://i.imgur.com/K4GDKew.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
				
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bette Midler[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1120+"/",
        thumbnail="https://i.imgur.com/T1nvcND.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Betty Misiego[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_894+"/",
        thumbnail="https://i.imgur.com/LScPHh7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Beverly Craven[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1443+"/",
        thumbnail="https://i.imgur.com/13VdYrr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Beyonce[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_216+"/",
        thumbnail="https://i.imgur.com/Euw7Rpv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Beyond The Black[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1444+"/",
        thumbnail="https://i.imgur.com/VSOEgOG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bia Ferreira[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1445+"/",
        thumbnail="https://i.imgur.com/51C3bVV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Big Time Rush[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_217+"/",
        thumbnail="https://i.imgur.com/e4go1Sc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bill Haley And The Comets[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_624+"/",
        thumbnail="https://i.imgur.com/5sWKAbC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Billie Ellish[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1121+"/",
        thumbnail="https://i.imgur.com/kCqMLFT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Billie Holliday[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_784+"/",
        thumbnail="https://i.imgur.com/ixhX2F6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Billy Idol[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_218+"/",
        thumbnail="https://i.imgur.com/FYkW5Zm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Billy Joel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_625+"/",
        thumbnail="https://i.imgur.com/VM68tAO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bing Crosby[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1122+"/",
        thumbnail="https://i.imgur.com/H9hdRsZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bizet, Georges[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1387+"/",
        thumbnail="https://i.imgur.com/n10VJ3A.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bjork[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_785+"/",
        thumbnail="https://i.imgur.com/0XJTiE1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Blacc Cuzz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1123+"/",
        thumbnail="https://i.imgur.com/wSKQ3rV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Black Eyed Peas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_219+"/",
        thumbnail="https://i.imgur.com/Fk3RdTP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Black Pistol Fire[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1446+"/",
        thumbnail="https://i.imgur.com/WpzvqBe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Black Sabbath[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_220+"/",
        thumbnail="https://i.imgur.com/74wtldm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Black Stone Cherry[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_221+"/",
        thumbnail="https://i.imgur.com/IcXmQWa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Blackberry Smoke[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1447+"/",
        thumbnail="https://i.imgur.com/NlRlhOr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Blas Canto[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_222+"/",
        thumbnail="https://i.imgur.com/NIScNvL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Blink 182[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_223+"/",
        thumbnail="https://i.imgur.com/NYraVCv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]BlocBoy JB[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1124+"/",
        thumbnail="https://i.imgur.com/uwvxVX4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Blon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_786+"/",
        thumbnail="https://i.imgur.com/El56yN4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Blondie[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_626+"/",
        thumbnail="https://i.imgur.com/WYKnwAO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bloodhound Gang[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1715+"/",
        thumbnail="https://i.imgur.com/SHC2K43.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Blue Oyster Cult[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_224+"/",
        thumbnail="https://i.imgur.com/DKoFWVP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Blutengel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1448+"/",
        thumbnail="https://i.imgur.com/95Pww4v.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bob Dylan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_225+"/",
        thumbnail="https://i.imgur.com/pcOJOnS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bob Marley[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_226+"/",
        thumbnail="https://i.imgur.com/eXDjsdG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bobby McFerrin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1449+"/",
        thumbnail="https://i.imgur.com/hisLD7m.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bobby Vinton[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1716+"/",
        thumbnail="https://i.imgur.com/tp24ezV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bomba Estereo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1450+"/",
        thumbnail="https://i.imgur.com/GfndBM1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bon Jovi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_227+"/",
        thumbnail="https://i.imgur.com/wrhCbPF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bones Of Minerva[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_895+"/",
        thumbnail="https://i.imgur.com/tavoMfM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bonney M[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_228+"/",
        thumbnail="https://i.imgur.com/eJEMseu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bonnie Tyler[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_229+"/",
        thumbnail="https://i.imgur.com/Noe3HwP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Boomtown Rats[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_627+"/",
        thumbnail="https://i.imgur.com/8Abl5BY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bordon 4[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_896+"/",
        thumbnail="https://i.imgur.com/5ST6VBg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Borodin, Aleksandr[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1388+"/",
        thumbnail="https://i.imgur.com/2TMAoYD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Boston[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_230+"/",
        thumbnail="https://i.imgur.com/RGT1UIq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Brahms, Johannes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1389+"/",
        thumbnail="https://i.imgur.com/m8bNZKc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Braulio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_897+"/",
        thumbnail="https://i.imgur.com/x4txjXb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Breaking Benjamin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_231+"/",
        thumbnail="https://i.imgur.com/VcbQvS8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Brenda Lee[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1717+"/",
        thumbnail="https://i.imgur.com/EB1fTRN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bring Me The Horizon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_232+"/",
        thumbnail="https://i.imgur.com/HaITfZJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Brioni Faith[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1451+"/",
        thumbnail="https://i.imgur.com/gTllGhP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Brisa Fenoy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1125+"/",
        thumbnail="https://i.imgur.com/Y89K8t7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Britney Spears[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_628+"/",
        thumbnail="https://i.imgur.com/4U1qUuj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Brody Dalle[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1452+"/",
        thumbnail="https://i.imgur.com/p9rmtHc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Brothers Of Metal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1453+"/",
        thumbnail="https://i.imgur.com/VKpZdSs.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bruce Springsteen[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_233+"/",
        thumbnail="https://i.imgur.com/5HwEx9a.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bruno Lomas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_898+"/",
        thumbnail="https://i.imgur.com/87oZQnQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bruno Mars[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_234+"/",
        thumbnail="https://i.imgur.com/2nOeSUj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bryan Adams[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_235+"/",
        thumbnail="https://i.imgur.com/9UsEnl9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Buika[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_787+"/",
        thumbnail="https://i.imgur.com/LXnHXA1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Bullet For My Valentine[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_236+"/",
        thumbnail="https://i.imgur.com/zUNRHie.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Burning Witches[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1454+"/",
        thumbnail="https://i.imgur.com/59DKP8h.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]C.C. Catch[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1455+"/",
        thumbnail="https://i.imgur.com/gQxa6pw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]C Tangana[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_629+"/",
        thumbnail="https://i.imgur.com/Uso0GYH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cab Calloway[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1456+"/",
        thumbnail="https://i.imgur.com/MasXhrs.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Café Quijano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_237+"/",
        thumbnail="https://i.imgur.com/wFzhKG2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cafe Tacvba[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_238+"/",
        thumbnail="https://i.imgur.com/ICfzDRA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Caifanes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_239+"/",
        thumbnail="https://i.imgur.com/H4E2JNI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Calinhos Brown[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_788+"/",
        thumbnail="https://i.imgur.com/MLnN2Ch.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Camaron[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_240+"/",
        thumbnail="https://i.imgur.com/URnMsXl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Camela[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_630+"/",
        thumbnail="https://i.imgur.com/13CcCwm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Camilo Sesto[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_241+"/",
        thumbnail="https://i.imgur.com/hzR8BYy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cannibal Corpse[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1457+"/",
        thumbnail="https://i.imgur.com/6zG7qmc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cantores De Hispalis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_899+"/",
        thumbnail="https://i.imgur.com/8QTTETM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Captain Hollywood Project[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1458+"/",
        thumbnail="https://i.imgur.com/B9wj9MZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cariño[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_900+"/",
        thumbnail="https://i.imgur.com/Egfx6bF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Carla Morrison[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1126+"/",
        thumbnail="https://i.imgur.com/kuf8ULS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Carlos Baute[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_631+"/",
        thumbnail="https://i.imgur.com/8aaLgzh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Carlos Cano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_901+"/",
        thumbnail="https://i.imgur.com/VY3QeqT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Carlos Gardel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_902+"/",
        thumbnail="https://i.imgur.com/2Jrz8JQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Carlos Jean[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_632+"/",
        thumbnail="https://i.imgur.com/ChcTjxb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Carlos Mejia Godoy y Los De Palacaguina[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1127+"/",
        thumbnail="https://i.imgur.com/qfEQ9J8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Carlos Nuñez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1128+"/",
        thumbnail="https://i.imgur.com/tlbsmaX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Carlos Vargas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1129+"/",
        thumbnail="https://i.imgur.com/HlpTLiv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Carmen Boza[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1130+"/",
        thumbnail="https://i.imgur.com/s83rhok.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Carmen Flores[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_903+"/",
        thumbnail="https://i.imgur.com/mwFjbIQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Carmen Sevilla[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_904+"/",
        thumbnail="https://i.imgur.com/kCOX0JE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Carol G[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_633+"/",
        thumbnail="https://i.imgur.com/e1N4DC5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Carolina Durante[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_905+"/",
        thumbnail="https://i.imgur.com/KOlv6bE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cat Stevens[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_634+"/",
        thumbnail="https://i.imgur.com/g9cM7DH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cecilia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_910+"/",
        thumbnail="https://i.imgur.com/yQPnKcV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cecilia Toussaint[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1133+"/",
        thumbnail="https://i.imgur.com/sqhdLvI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Celine Dion[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_242+"/",
        thumbnail="https://i.imgur.com/arpzeaB.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Celia Cruz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1134+"/",
        thumbnail="https://i.imgur.com/n2DhG2O.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Celia Gamez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1135+"/",
        thumbnail="https://i.imgur.com/p96yL3Q.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Celtas Cortos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1332+"/",
        thumbnail="https://i.imgur.com/sizNABm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cetu Javu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1459+"/",
        thumbnail="https://i.imgur.com/sEaHPSF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chanel West Coast[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1131+"/",
        thumbnail="https://i.imgur.com/Uo9J7XQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Charlee Way[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1132+"/",
        thumbnail="https://i.imgur.com/Pqn5RCj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Charles & Eddie[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1718+"/",
        thumbnail="https://i.imgur.com/IOkEeq8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Charles Aznavour[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_906+"/",
        thumbnail="https://i.imgur.com/lSyJyiu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chavela Vargas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_907+"/",
        thumbnail="https://i.imgur.com/5xuk79e.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chayanne[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_789+"/",
        thumbnail="https://i.imgur.com/X9V3kXc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chimo Bayo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1460+"/",
        thumbnail="https://i.imgur.com/wUc8JqX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chino y Nacho[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_908+"/",
        thumbnail="https://i.imgur.com/RkJKzHw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chiquetete[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_909+"/",
        thumbnail="https://i.imgur.com/YWeEI4H.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chopin, Frederic[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1390+"/",
        thumbnail="https://i.imgur.com/ktxLoja.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chromatics[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1461+"/",
        thumbnail="https://i.imgur.com/lIzwdcR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chubby Checker[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1719+"/",
        thumbnail="https://i.imgur.com/5NHaIy3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Church Of The Cosmic Skull[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1462+"/",
        thumbnail="https://i.imgur.com/bG9Ucae.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chuty[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_790+"/",
        thumbnail="https://i.imgur.com/CEuXWMY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chenoa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_635+"/",
        thumbnail="https://i.imgur.com/oHUmUJ7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cher[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_636+"/",
        thumbnail="https://i.imgur.com/Y1AasCW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chicago[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_243+"/",
        thumbnail="https://i.imgur.com/7bpw7LD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chris Rea[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_637+"/",
        thumbnail="https://i.imgur.com/MVY5CST.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Christopher Cross[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_638+"/",
        thumbnail="https://i.imgur.com/eu1phuQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Chuck Berry[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_244+"/",
        thumbnail="https://i.imgur.com/LM1tjlP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cinderella[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_245+"/",
        thumbnail="https://i.imgur.com/tzZEBOY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Clara Montes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_911+"/",
        thumbnail="https://i.imgur.com/PzntRJg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Claudio Baglioni[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1054+"/",
        thumbnail="https://i.imgur.com/WCqXNL5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cliff Richard[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_912+"/",
        thumbnail="https://i.imgur.com/SWTM1li.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Clutch[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1463+"/",
        thumbnail="https://i.imgur.com/XHjr2u0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Coco Cece[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1136+"/",
        thumbnail="https://i.imgur.com/22rZcBs.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cody Jinks[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1707+"/",
        thumbnail="https://i.imgur.com/gfz4Ids.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Coheed And Cambria[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_246+"/",
        thumbnail="https://i.imgur.com/qz9lcz2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cold Cave[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1464+"/",
        thumbnail="https://i.imgur.com/xqW3KmW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Coldplay[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_247+"/",
        thumbnail="https://i.imgur.com/aqsiq5c.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Collage[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_913+"/",
        thumbnail="https://i.imgur.com/29wgEtV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Companyia Electrica Dharma[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1137+"/",
        thumbnail="https://i.imgur.com/Iqkxzvp.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Complices[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1055+"/",
        thumbnail="https://i.imgur.com/MMmKrHa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Conchita Bautista[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_914+"/",
        thumbnail="https://i.imgur.com/tdFyxc7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Corey Hart[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1465+"/",
        thumbnail="https://i.imgur.com/BZRVt2f.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Coyote Dax[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_915+"/",
        thumbnail="https://i.imgur.com/Xuzia2M.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Crazy Lixx[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1466+"/",
        thumbnail="https://i.imgur.com/xwZ27Ug.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cream[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_639+"/",
        thumbnail="https://i.imgur.com/bDlw6bt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Creedence Clearwater Revival[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_248+"/",
        thumbnail="https://i.imgur.com/24dOf09.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cristina Aguilera[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_640+"/",
        thumbnail="https://i.imgur.com/SLkAInH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Crematory[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1467+"/",
        thumbnail="https://i.imgur.com/XbpEOMF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Crucified Barbara[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1468+"/",
        thumbnail="https://i.imgur.com/uO8d6uF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Crystal Waters[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1469+"/",
        thumbnail="https://i.imgur.com/04zg9tR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Culture Club[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_791+"/",
        thumbnail="https://i.imgur.com/xCn8lm5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cupido[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_916+"/",
        thumbnail="https://i.imgur.com/Sk0qbqV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Cyndi Lauper[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_249+"/",
        thumbnail="https://i.imgur.com/wgvyFKC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Da Palestrina, Giovanni Pierluigi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1391+"/",
        thumbnail="https://i.imgur.com/Ktcrm4O.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="",
        title="[COLOR aqua]Dadee Yankee[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_250+"/",
        thumbnail="https://i.imgur.com/vbhutQa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Daft Punk[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_251+"/",
        thumbnail="https://i.imgur.com/G9xxadj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dalex[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1138+"/",
        thumbnail="https://i.imgur.com/QjLp1vJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Damn Yankees[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1470+"/",
        thumbnail="https://i.imgur.com/XJl8Xef.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Daniel Diges[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_917+"/",
        thumbnail="https://i.imgur.com/zgFd6oG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Daniela Romo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_918+"/",
        thumbnail="https://i.imgur.com/4quDwPz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Danna Paola[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1306+"/",
        thumbnail="https://i.imgur.com/IjHP0Wr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dany Daniel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1056+"/",
        thumbnail="https://i.imgur.com/RQP0vYS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Danza Invisible[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_762+"/",
        thumbnail="https://i.imgur.com/MR67YBb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Danzing[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_252+"/",
        thumbnail="https://i.imgur.com/CkeI2L5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Darkness[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_792+"/",
        thumbnail="https://i.imgur.com/SETsnai.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Darell[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1139+"/",
        thumbnail="https://i.imgur.com/Nt7473u.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Darius Rucker[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1140+"/",
        thumbnail="https://i.imgur.com/fN65BZx.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Darren Hayes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1720+"/",
        thumbnail="https://i.imgur.com/4g15FLk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]David Bisbal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_253+"/",
        thumbnail="https://i.imgur.com/cb9QzoF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dave Gaham[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1471+"/",
        thumbnail="https://i.imgur.com/zUJiROV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]David Bowei[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_254+"/",
        thumbnail="https://i.imgur.com/0pREhIz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]David Bustamante[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_255+"/",
        thumbnail="https://i.imgur.com/p9Wzeso.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]David Civera[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_641+"/",
        thumbnail="https://i.imgur.com/oTQVrmQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]David De Maria[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_642+"/",
        thumbnail="https://i.imgur.com/rx6I6Ld.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]David Garret[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1472+"/",
        thumbnail="https://i.imgur.com/yrMZ4h7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]David Gilmore[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1141+"/",
        thumbnail="https://i.imgur.com/82QHRnR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]David Guetta[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_256+"/",
        thumbnail="https://i.imgur.com/KLiLIsi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Davide Salvado[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1142+"/",
        thumbnail="https://i.imgur.com/eWet2sx.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Deacon Blue[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_793+"/",
        thumbnail="https://i.imgur.com/qktuKC3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )			

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dead Or Alive[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1307+"/",
        thumbnail="https://i.imgur.com/zdsMI6G.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Deathstars[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1473+"/",
        thumbnail="https://i.imgur.com/9UGy8N0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Debbie Gibson[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1474+"/",
        thumbnail="https://i.imgur.com/uVwGBSn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Debussy, Claude[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1392+"/",
        thumbnail="https://i.imgur.com/wXgxeXl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Decai[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1308+"/",
        thumbnail="https://i.imgur.com/RlkAckA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dee D Jackson[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1475+"/",
        thumbnail="https://i.imgur.com/lid115E.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Deep Puple[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_257+"/",
        thumbnail="https://i.imgur.com/78REQo2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Def Con Dos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_794+"/",
        thumbnail="https://i.imgur.com/17kn5Lo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Def Leppard[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_258+"/",
        thumbnail="https://i.imgur.com/3YJdqwz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Deftones[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_259+"/",
        thumbnail="https://i.imgur.com/kRdJzPx.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Delta Rae[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1476+"/",
        thumbnail="https://i.imgur.com/djW79al.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Demarco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_919+"/",
        thumbnail="https://i.imgur.com/hod3SU7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Demi Lovato[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_643+"/",
        thumbnail="https://i.imgur.com/LZh0pzZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Demis Roussos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_920+"/",
        thumbnail="https://i.imgur.com/l5IsTSn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Demons And Wizards[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1477+"/",
        thumbnail="https://i.imgur.com/NGR4lqO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Denise Gutierrez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1143+"/",
        thumbnail="https://i.imgur.com/vZC6KXe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Depeche Mode[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_260+"/",
        thumbnail="https://i.imgur.com/LKfqOks.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Desmadre 75[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_921+"/",
        thumbnail="https://i.imgur.com/qywGbK8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Destinys Child[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_261+"/",
        thumbnail="https://i.imgur.com/7tOWYaa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Devo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1478+"/",
        thumbnail="https://i.imgur.com/2MdhnKM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Diana Navarro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_644+"/",
        thumbnail="https://i.imgur.com/TVmMEpL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Diana Ross[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1046+"/",
        thumbnail="https://i.imgur.com/tsM60r5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dias De Vino y Rosas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1144+"/",
        thumbnail="https://i.imgur.com/YVZxH4l.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dido[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1145+"/",
        thumbnail="https://i.imgur.com/e6ZDWaA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Diego El Cigala[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_645+"/",
        thumbnail="https://i.imgur.com/k83Vmzj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_262+"/",
        thumbnail="https://i.imgur.com/59ri3oM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dionne Warwick[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1047+"/",
        thumbnail="https://i.imgur.com/0zjSxOy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dire Straits[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_263+"/",
        thumbnail="https://i.imgur.com/pRSDrKU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dirty Honey[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1479+"/",
        thumbnail="https://i.imgur.com/tv431T6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Disturbed[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_264+"/",
        thumbnail="https://i.imgur.com/GXfbApN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Doctor Feelgood[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_265+"/",
        thumbnail="https://i.imgur.com/3fHcczA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dokken[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1480+"/",
        thumbnail="https://i.imgur.com/DLHzyvv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dolly Parton[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_755+"/",
        thumbnail="https://i.imgur.com/a0nTX1b.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dolors Laffite[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1146+"/",
        thumbnail="https://i.imgur.com/OyMY7eX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dolores Vargas La Terremoto[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_922+"/",
        thumbnail="https://i.imgur.com/znygbZ0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Domenico Modugno[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1057+"/",
        thumbnail="https://i.imgur.com/WJMeaZN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Don Omar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_266+"/",
        thumbnail="https://i.imgur.com/Rwgy15X.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Don Toliver[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1147+"/",
        thumbnail="https://i.imgur.com/Oj6qehb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Donna Summer[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_742+"/",
        thumbnail="https://i.imgur.com/cymJ811.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Donovan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_797+"/",
        thumbnail="https://i.imgur.com/WJcn6Ge.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )			

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dope[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_267+"/",
        thumbnail="https://i.imgur.com/1ysowkh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dover[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_268+"/",
        thumbnail="https://i.imgur.com/eDb72W4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dragonforce[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_269+"/",
        thumbnail="https://i.imgur.com/fFIF8Hq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Drama Relax[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1148+"/",
        thumbnail="https://i.imgur.com/dMcsNsZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dream Theater[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_270+"/",
        thumbnail="https://i.imgur.com/QRw1NAn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Drowing Pool[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_271+"/",
        thumbnail="https://i.imgur.com/I48lKtV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dtoke[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_795+"/",
        thumbnail="https://i.imgur.com/idO6haB.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dtoke Vs Stuart[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_796+"/",
        thumbnail="https://i.imgur.com/91Rjyxi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dua Lipa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_646+"/",
        thumbnail="https://i.imgur.com/Zbnmdy0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ducan Dhu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_272+"/",
        thumbnail="https://i.imgur.com/i8M64s7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Duffy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_743+"/",
        thumbnail="https://i.imgur.com/RCe8Mn0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dulce Pontes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1149+"/",
        thumbnail="https://i.imgur.com/wzaOrqQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dum Dum Girls[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1481+"/",
        thumbnail="https://i.imgur.com/zyDbeYz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Duo Dinamico[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_647+"/",
        thumbnail="https://i.imgur.com/9wNOkYf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Duran Duran[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_273+"/",
        thumbnail="https://i.imgur.com/DI5IGBa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dvicio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_648+"/",
        thumbnail="https://i.imgur.com/TK6a0hR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dvorak, Antonin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1393+"/",
        thumbnail="https://i.imgur.com/frOowM5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dyango[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_649+"/",
        thumbnail="https://i.imgur.com/vwgcZcv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dynazty[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1482+"/",
        thumbnail="https://i.imgur.com/2K2PPIF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Eagles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_274+"/",
        thumbnail="https://i.imgur.com/Vxo2u6l.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Earth Wind And Fire[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_650+"/",
        thumbnail="https://i.imgur.com/jsyfRXo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]East 17[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1483+"/",
        thumbnail="https://i.imgur.com/DhkInT5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Echo And The Bunnymen[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1484+"/",
        thumbnail="https://i.imgur.com/C9vYjjf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Eddy Grant[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_798+"/",
        thumbnail="https://i.imgur.com/7mYkKRd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ed Sheeran[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_275+"/",
        thumbnail="https://i.imgur.com/REVCJLU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Edith Piaf[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_923+"/",
        thumbnail="https://i.imgur.com/CASs6Uw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Edurne[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_651+"/",
        thumbnail="https://i.imgur.com/3wCf7RM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Efecto Mariposa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_276+"/",
        thumbnail="https://i.imgur.com/zTexmQs.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Efecto Pasillo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_652+"/",
        thumbnail="https://i.imgur.com/c6sNoqX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Eisfabrik[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1485+"/",
        thumbnail="https://i.imgur.com/glGG1aO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]El Arrebato[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_277+"/",
        thumbnail="https://i.imgur.com/N1VI1nL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]El Barrio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_278+"/",
        thumbnail="https://i.imgur.com/dLfoY5L.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]El Canto El Loco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_279+"/",
        thumbnail="https://i.imgur.com/pQlOHM9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]El Fary[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_744+"/",
        thumbnail="https://i.imgur.com/OFi9kE0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]El Koala[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_924+"/",
        thumbnail="https://i.imgur.com/i4RfcTL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]El Lebrijano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1150+"/",
        thumbnail="https://i.imgur.com/5eaxSeJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]El Mejor Minuto De Cada Gallo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_799+"/",
        thumbnail="https://i.imgur.com/9U9lrzf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]El Principe Gitano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_925+"/",
        thumbnail="https://i.imgur.com/YZuaUQG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]El Sueño De Morfeo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_926+"/",
        thumbnail="https://i.imgur.com/jC6Fsbp.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]El Tren De Los Sueños[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_927+"/",
        thumbnail="https://i.imgur.com/ZBHDiEq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]El Ultimo De La Fila[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_280+"/",
        thumbnail="https://i.imgur.com/QfOGBi8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Elder Barber[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1151+"/",
        thumbnail="https://i.imgur.com/1ebzaEo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Electric Light Orchestra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_281+"/",
        thumbnail="https://i.imgur.com/btGHWTW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Eleni Foureira[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1486+"/",
        thumbnail="https://i.imgur.com/ex4lVz1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Elgar, Edward[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1394+"/",
        thumbnail="https://i.imgur.com/BMzhOxb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ella Baila Sola[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_928+"/",
        thumbnail="https://i.imgur.com/QqD51z9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ella Fitzgerald[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_800+"/",
        thumbnail="https://i.imgur.com/5PsMTxw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ellie Goulding[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1152+"/",
        thumbnail="https://i.imgur.com/iZXwbTd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Els Trovadors[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1153+"/",
        thumbnail="https://i.imgur.com/JTh68i9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Elsa Baeza[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_929+"/",
        thumbnail="https://i.imgur.com/ezZRTvm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Elton John[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_282+"/",
        thumbnail="https://i.imgur.com/8iADjLD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Elvis Presley[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_283+"/",
        thumbnail="https://i.imgur.com/rPx81P0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ely Guerra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1154+"/",
        thumbnail="https://i.imgur.com/zs2UVeM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Emerson Lake And Palmer[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_653+"/",
        thumbnail="https://i.imgur.com/5x8QiGY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Eminem[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1155+"/",
        thumbnail="https://i.imgur.com/nJwbdkt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Emmylou Harris[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1487+"/",
        thumbnail="https://i.imgur.com/7JZTxLY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]En Vogue[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1488+"/",
        thumbnail="https://i.imgur.com/kH8hyNY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Enanitos Verdes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_284+"/",
        thumbnail="https://i.imgur.com/l5yqexI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Engelbert Humperdinck[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1156+"/",
        thumbnail="https://i.imgur.com/bgltxVO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Enigma[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1157+"/",
        thumbnail="https://i.imgur.com/vH7roOp.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ennio Morricone[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1309+"/",
        thumbnail="https://i.imgur.com/ZOmFPPe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Enric Hernaez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1158+"/",
        thumbnail="https://i.imgur.com/Z2Cza00.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Enrico Caruso[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1058+"/",
        thumbnail="https://i.imgur.com/sp0TKXF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Enrique Granados[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1284+"/",
        thumbnail="https://i.imgur.com/lEAamrQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Enrique Iglesias[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_285+"/",
        thumbnail="https://i.imgur.com/ml45fQY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Enrique Morente[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1159+"/",
        thumbnail="https://i.imgur.com/sHPZ7Rj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ensiferum[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1489+"/",
        thumbnail="https://i.imgur.com/4OVkYuj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Enya[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_286+"/",
        thumbnail="https://i.imgur.com/rC9BjLC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Eric Benet[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1160+"/",
        thumbnail="https://i.imgur.com/3th0K5l.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Eric Clapton[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_287+"/",
        thumbnail="https://i.imgur.com/nrHZAfV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Erma Franklin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1490+"/",
        thumbnail="https://i.imgur.com/nOJ96fB.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Eros Ramazzotti[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_654+"/",
        thumbnail="https://i.imgur.com/Zp6poJv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Errece[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_801+"/",
        thumbnail="https://i.imgur.com/d3ZxgRk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Eruption[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1491+"/",
        thumbnail="https://i.imgur.com/uu21agi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Estopa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_288+"/",
        thumbnail="https://i.imgur.com/Mko0dS9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Estrella Morente[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1161+"/",
        thumbnail="https://i.imgur.com/ChRGWRb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Estrellita Castro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_930+"/",
        thumbnail="https://i.imgur.com/z7f4F8V.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Europe[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_752+"/",
        thumbnail="https://i.imgur.com/33NdDyk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Eurythmics[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_289+"/",
        thumbnail="https://i.imgur.com/jqvvzOh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Evanescence[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_290+"/",
        thumbnail="https://i.imgur.com/BZqqUfQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Evenmore[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1492+"/",
        thumbnail="https://i.imgur.com/vhbg0XR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Everlast[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1329+"/",
        thumbnail="https://i.imgur.com/UeELPKS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Everly Brothers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_655+"/",
        thumbnail="https://i.imgur.com/gKn5KFY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Everything But The Girl[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1493+"/",
        thumbnail="https://i.imgur.com/kt3Oxw8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Extremo Duro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_291+"/",
        thumbnail="https://i.imgur.com/eSgbnNy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Exit Eden[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1494+"/",
        thumbnail="https://i.imgur.com/NNrrIXI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Eyes Of The Nightmare Jungle[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1495+"/",
        thumbnail="https://i.imgur.com/Ma9yDWn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Faithless[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1162+"/",
        thumbnail="https://i.imgur.com/TSry5ma.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Faith No More[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_292+"/",
        thumbnail="https://i.imgur.com/UEcksEm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Falete[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_931+"/",
        thumbnail="https://i.imgur.com/uV5hwjm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Fall Out Boy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_293+"/",
        thumbnail="https://i.imgur.com/3X0RV40.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Fernando Barroso[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1163+"/",
        thumbnail="https://i.imgur.com/tmyxLsc.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Fifth Harmony[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_294+"/",
        thumbnail="https://i.imgur.com/vRt9JDK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Firehouse[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1496+"/",
        thumbnail="https://i.imgur.com/0KNSGB0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Firewind[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1497+"/",
        thumbnail="https://i.imgur.com/29iG2jR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Fito y Fitipaldis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_295+"/",
        thumbnail="https://i.imgur.com/4nrTHgq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Five[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1721+"/",
        thumbnail="https://i.imgur.com/8X7jdDQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Five Finger Death Punch[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_296+"/",
        thumbnail="https://i.imgur.com/Suotvnr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Fleetwood Mac[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_656+"/",
        thumbnail="https://i.imgur.com/fWBnHdm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Fletcher[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1164+"/",
        thumbnail="https://i.imgur.com/H1Evdly.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Fondo Flamenco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1310+"/",
        thumbnail="https://i.imgur.com/kvdB4jz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Foo Fighters[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_297+"/",
        thumbnail="https://i.imgur.com/hswpYUS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Foreigner[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_298+"/",
        thumbnail="https://i.imgur.com/p62O6GM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Formula Abierta[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_932+"/",
        thumbnail="https://i.imgur.com/5IdBexi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Formula V[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_933+"/",
        thumbnail="https://i.imgur.com/iBSzLDQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Foxy Shazam[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1498+"/",
        thumbnail="https://i.imgur.com/sJPzB9m.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Francisco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_657+"/",
        thumbnail="https://i.imgur.com/BgfaTyH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Francisco Tarrega[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1165+"/",
        thumbnail="https://i.imgur.com/1K4RYQV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Franco Battiato[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_934+"/",
        thumbnail="https://i.imgur.com/xzYDGvC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Frank Ocean[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1166+"/",
        thumbnail="https://i.imgur.com/YiL9TTL.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Frank Sinatra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_299+"/",
        thumbnail="https://i.imgur.com/zKzbLiu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Frank Zappa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_300+"/",
        thumbnail="https://i.imgur.com/rvE9CJW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Frankie Goes To Hollywood[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1291+"/",
        thumbnail="https://i.imgur.com/AmQ2jmK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Frankie Vallei And The Four Seasons[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1499+"/",
        thumbnail="https://i.imgur.com/kbRihvF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Fred De Palma[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1167+"/",
        thumbnail="https://i.imgur.com/fl2kFoo.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Freestyle Batallas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_802+"/",
        thumbnail="https://i.imgur.com/oj6uLM1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Frozen Crown[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1500+"/",
        thumbnail="https://i.imgur.com/X7LpgAu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Fun[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_301+"/",
        thumbnail="https://i.imgur.com/cXUAx3p.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Fun Factory[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1501+"/",
        thumbnail="https://i.imgur.com/qZoUPnh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gabinete Caligari[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_302+"/",
        thumbnail="https://i.imgur.com/hzUP3EH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Garbage[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_803+"/",
        thumbnail="https://i.imgur.com/3Ep6OKj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gary B.B Coleman[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1311+"/",
        thumbnail="https://i.imgur.com/KozCTPD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gary Low[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1502+"/",
        thumbnail="https://i.imgur.com/b78dk8N.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gemeliers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_935+"/",
        thumbnail="https://i.imgur.com/UybtSjo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Genesis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_303+"/",
        thumbnail="https://i.imgur.com/VJzNbgt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]George Harrison[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1168+"/",
        thumbnail="https://i.imgur.com/P14cp8Y.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]George Michael[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_304+"/",
        thumbnail="https://i.imgur.com/tVrUZW8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]George Moustaki[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1503+"/",
        thumbnail="https://i.imgur.com/RlYgD56.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gerorgie Dann[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_936+"/",
        thumbnail="https://i.imgur.com/cdsenGR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gershwin, George[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1395+"/",
        thumbnail="https://i.imgur.com/TDYkIpH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ghost[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_305+"/",
        thumbnail="https://i.imgur.com/hNjVMg7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gianluca Grignani[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1059+"/",
        thumbnail="https://i.imgur.com/7igmJ8g.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gianni Bella[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_937+"/",
        thumbnail="https://i.imgur.com/FNmAZQt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gigi D'Agostino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1722+"/",
        thumbnail="https://i.imgur.com/Rn4pXxo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gigliola Cinquetti[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1060+"/",
        thumbnail="https://i.imgur.com/slOgP8U.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gillbert Osullivan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1504+"/",
        thumbnail="https://i.imgur.com/2qy0RTY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gilberto Gil[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_804+"/",
        thumbnail="https://i.imgur.com/qyCg5Eg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gino Vannelli[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1505+"/",
        thumbnail="https://i.imgur.com/r627EJL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gipsy King[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_938+"/",
        thumbnail="https://i.imgur.com/CgHq4HQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Girlicious[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_306+"/",
        thumbnail="https://i.imgur.com/sMLCGud.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Girlschool[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_805+"/",
        thumbnail="https://i.imgur.com/CQkH7Vw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Girls Aloud[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_307+"/",
        thumbnail="https://i.imgur.com/9aNudJu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Girls Generation[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_308+"/",
        thumbnail="https://i.imgur.com/O05yiDa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Giulia Be[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1312+"/",
        thumbnail="https://i.imgur.com/ty7kPTz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Glenn Frey[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1313+"/",
        thumbnail="https://i.imgur.com/iKzZ2dQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gloria[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1169+"/",
        thumbnail="https://i.imgur.com/YZPZduN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gloria Estefan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_806+"/",
        thumbnail="https://i.imgur.com/LfkqNtZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gloria Gaynor[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_745+"/",
        thumbnail="https://i.imgur.com/q1oiShR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gloria Groove[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1314+"/",
        thumbnail="https://i.imgur.com/dxAbM4k.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gloria Trevi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_658+"/",
        thumbnail="https://i.imgur.com/XCqjNfi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Glutamato Ye Ye[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1170+"/",
        thumbnail="https://i.imgur.com/ngBAGXj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gnarls Barkley[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1506+"/",
        thumbnail="https://i.imgur.com/Ya1bmcS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Goldfrapp[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1507+"/",
        thumbnail="https://i.imgur.com/SAYKh4M.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Godsmack[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_309+"/",
        thumbnail="https://i.imgur.com/u5H6Zl3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gojira[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_310+"/",
        thumbnail="https://i.imgur.com/ZFAkxxr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Golpes Bajos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_311+"/",
        thumbnail="https://i.imgur.com/9Vwu432.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Good Charlotte[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_312+"/",
        thumbnail="https://i.imgur.com/7u2KIgw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gorilaz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_313+"/",
        thumbnail="https://i.imgur.com/V8OpZiM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gotthard[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1508+"/",
        thumbnail="https://i.imgur.com/hVR8cgY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gracia De Triana[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1171+"/",
        thumbnail="https://i.imgur.com/eVWjRVs.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gracia Montes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_939+"/",
        thumbnail="https://i.imgur.com/7SHG4Ds.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Grand Funk Railroad[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1509+"/",
        thumbnail="https://i.imgur.com/kK6stQf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Green Day[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_314+"/",
        thumbnail="https://i.imgur.com/fHglx8r.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Greta Van Fleet[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_315+"/",
        thumbnail="https://i.imgur.com/MgHEp0g.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Grieg, Edvard[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1396+"/",
        thumbnail="https://i.imgur.com/OD4iTPL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Grima[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1510+"/",
        thumbnail="https://i.imgur.com/wWLgOmg.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Guarana[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_807+"/",
        thumbnail="https://i.imgur.com/fhwwlnV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Guillermo Barea[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_940+"/",
        thumbnail="https://i.imgur.com/PqYr9ZF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Guns And Roses[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_316+"/",
        thumbnail="https://i.imgur.com/RTLwCwk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ha Ash[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_317+"/",
        thumbnail="https://i.imgur.com/GqNsJOC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hadaway[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1511+"/",
        thumbnail="https://i.imgur.com/8Nvsr5L.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Halstorm[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_318+"/",
        thumbnail="https://i.imgur.com/f9lsuDK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Handel, Georg Friedrich[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1397+"/",
        thumbnail="https://i.imgur.com/Yw47JNq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Harry Styles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1512+"/",
        thumbnail="https://i.imgur.com/oXQ0wDQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hatsune Miku[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1513+"/",
        thumbnail="https://i.imgur.com/rBqGWIF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Haydn, Joseph[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1398+"/",
        thumbnail="https://i.imgur.com/rN1EKFN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Heart[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_659+"/",
        thumbnail="https://i.imgur.com/ZLTurZw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Helloween[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_319+"/",
        thumbnail="https://i.imgur.com/H4jUoP4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hellyeah[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_320+"/",
        thumbnail="https://i.imgur.com/zWSPH1O.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Herbert Von Karajan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1172+"/",
        thumbnail="https://i.imgur.com/qNyjbEg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Heroes Del Silencio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_321+"/",
        thumbnail="https://i.imgur.com/DAdS1QR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hevia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_808+"/",
        thumbnail="https://i.imgur.com/j3oDaJ3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hollywood Vampires[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1514+"/",
        thumbnail="https://i.imgur.com/bYsMyyW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hombres G[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_322+"/",
        thumbnail="https://i.imgur.com/uwZN3sz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Hoobastank[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1315+"/",
        thumbnail="https://i.imgur.com/ENMs6DY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]House Of Pain[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1326+"/",
        thumbnail="https://i.imgur.com/PvH6nxJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Huecco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_764+"/",
        thumbnail="https://i.imgur.com/boBGO1B.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ice MC[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1515+"/",
        thumbnail="https://i.imgur.com/SKeNy9G.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Iced Earth[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1516+"/",
        thumbnail="https://i.imgur.com/iBnUEXR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Icona Pop[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_323+"/",
        thumbnail="https://i.imgur.com/wAiMZOd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Iggy pop[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_660+"/",
        thumbnail="https://i.imgur.com/YDerwpW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Il Divo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_809+"/",
        thumbnail="https://i.imgur.com/9qFaj7E.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ilegales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_324+"/",
        thumbnail="https://i.imgur.com/P75aZUs.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Imagine Dragons[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_325+"/",
        thumbnail="https://i.imgur.com/GbEdouC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Imelda May[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1517+"/",
        thumbnail="https://i.imgur.com/elGegwS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Imperial Age[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1518+"/",
        thumbnail="https://i.imgur.com/QOq4jf3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Imperio Argentina[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_941+"/",
        thumbnail="https://i.imgur.com/ysMCYBn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Imperio De Triana[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1173+"/",
        thumbnail="https://i.imgur.com/ddWV3Yf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]In Flames[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_326+"/",
        thumbnail="https://i.imgur.com/ctAkFEq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]In This Moment[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_327+"/",
        thumbnail="https://i.imgur.com/ypPjhzi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Incubus[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_810+"/",
        thumbnail="https://i.imgur.com/GdUCKdP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]India Martinez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_661+"/",
        thumbnail="https://i.imgur.com/uOcq505.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Indeep[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1519+"/",
        thumbnail="https://i.imgur.com/i3vzqeT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Information Society[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1520+"/",
        thumbnail="https://i.imgur.com/a3OcPL0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ini Kamoze[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1327+"/",
        thumbnail="https://i.imgur.com/7b86clk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Invert[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_811+"/",
        thumbnail="https://i.imgur.com/oZU4xZZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Inxs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_328+"/",
        thumbnail="https://i.imgur.com/kgsBUmG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Irene Cara[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_746+"/",
        thumbnail="https://i.imgur.com/q3nJddi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Iron Maiden[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_329+"/",
        thumbnail="https://i.imgur.com/xwHJHIH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Isaac Albeniz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1285+"/",
        thumbnail="https://i.imgur.com/hRTy0SW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Isabel Pantoja[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_330+"/",
        thumbnail="https://i.imgur.com/sa5VQN1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Isabel Ruiz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1174+"/",
        thumbnail="https://i.imgur.com/k2BaGCU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Iva Zanicchi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1061+"/",
        thumbnail="https://i.imgur.com/og7LWCC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Iza[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1521+"/",
        thumbnail="https://i.imgur.com/aDLEjAO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]J Balvin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_331+"/",
        thumbnail="https://i.imgur.com/mI6G2Qd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jackson 5[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_332+"/",
        thumbnail="https://i.imgur.com/tD8fXWW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jaime Morey[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_942+"/",
        thumbnail="https://i.imgur.com/YNgwv78.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jairo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_943+"/",
        thumbnail="https://i.imgur.com/f1oan2k.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]James Blunt[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_333+"/",
        thumbnail="https://i.imgur.com/rjOmtGe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]James Brown[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_334+"/",
        thumbnail="https://i.imgur.com/HG94vKh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jamiroquai[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_812+"/",
        thumbnail="https://i.imgur.com/CDsgchR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jane Rose And The Deadend Boys[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1522+"/",
        thumbnail="https://i.imgur.com/xx3h4V0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Janet Jackson[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1523+"/",
        thumbnail="https://i.imgur.com/ywzQROZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Janette[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_944+"/",
        thumbnail="https://i.imgur.com/0fbQoTy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Janis Joplin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_335+"/",
        thumbnail="https://i.imgur.com/30vy8e3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jarabe De Palo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_336+"/",
        thumbnail="https://i.imgur.com/xLMhKyk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jarcha[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1175+"/",
        thumbnail="https://i.imgur.com/vsi1SOP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jared Dylan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1176+"/",
        thumbnail="https://i.imgur.com/K1qKFd0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jason Derulo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_337+"/",
        thumbnail="https://i.imgur.com/ChSpBxA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Javier Flores[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1177+"/",
        thumbnail="https://i.imgur.com/S7WqyBr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jazmin Solar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1178+"/",
        thumbnail="https://i.imgur.com/UqqrozD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jean Michel Jarre[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1179+"/",
        thumbnail="https://i.imgur.com/7GLOCxZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jeff Beck[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_338+"/",
        thumbnail="https://i.imgur.com/8IIbK0w.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jefferson Starship[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1524+"/",
        thumbnail="https://i.imgur.com/VBENaEE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jennifer Hudson[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1525+"/",
        thumbnail="https://i.imgur.com/yXUabfx.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jeninifer Lopez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_813+"/",
        thumbnail="https://i.imgur.com/JpOhTxQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jenny And The Mexicats[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_339+"/",
        thumbnail="https://i.imgur.com/xGcdLgy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jermaine Stewart[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1723+"/",
        thumbnail="https://i.imgur.com/XlhbpmL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jesse y Joy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_340+"/",
        thumbnail="https://i.imgur.com/OasaSsz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jessy Bulbo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1180+"/",
        thumbnail="https://i.imgur.com/nHgOXP7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jesuton[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1526+"/",
        thumbnail="https://i.imgur.com/yjoRz2k.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jerry Lee Lewis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_814+"/",
        thumbnail="https://i.imgur.com/oPXSlYn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jethro Tull[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_662+"/",
        thumbnail="https://i.imgur.com/hyBJPmm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jewel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_815+"/",
        thumbnail="https://i.imgur.com/G54EvpA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jhay Cortez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1181+"/",
        thumbnail="https://i.imgur.com/IIwxLCg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jim Reeves[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1724+"/",
        thumbnail="https://i.imgur.com/NRBxzQX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jimmy Fontana[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1062+"/",
        thumbnail="https://i.imgur.com/NclPQRw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jimmy Hendrix[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_341+"/",
        thumbnail="https://i.imgur.com/CgxmMED.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Joan Isaac[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1182+"/",
        thumbnail="https://i.imgur.com/vgovLOe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Joan Jett And The Blackhearts[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_342+"/",
        thumbnail="https://i.imgur.com/B95TSxz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Joan Manuel Serrat[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_343+"/",
        thumbnail="https://i.imgur.com/voHYgvt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Joaquin Sabina[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_344+"/",
        thumbnail="https://i.imgur.com/pSVv3I5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Joe Cocker[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_663+"/",
        thumbnail="https://i.imgur.com/K7uiI0j.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]John Coltrane[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_345+"/",
        thumbnail="https://i.imgur.com/fbpAgtg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]John Denver[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_747+"/",
        thumbnail="https://i.imgur.com/2XFxBo9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]John Lee Hooker[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1183+"/",
        thumbnail="https://i.imgur.com/X3fsKUj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jonh Lennon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1063+"/",
        thumbnail="https://i.imgur.com/KgonCAP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]John Scofield[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1184+"/",
        thumbnail="https://i.imgur.com/IDlaKJu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Johnny Cash[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1185+"/",
        thumbnail="https://i.imgur.com/EXakVXE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Johnny Halyday[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1186+"/",
        thumbnail="https://i.imgur.com/Z0yiX7z.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jonas Brothers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_346+"/",
        thumbnail="https://i.imgur.com/LPw7QxH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jose Carreras[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1064+"/",
        thumbnail="https://i.imgur.com/sAL1ORZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jose Guardiola[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_945+"/",
        thumbnail="https://i.imgur.com/bGQknuw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jose Luis Perales[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_664+"/",
        thumbnail="https://i.imgur.com/lNrxbSH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jose Luis Rodriguez El Puma[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_946+"/",
        thumbnail="https://i.imgur.com/DfzlAKP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jose Manuel Soto[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_754+"/",
        thumbnail="https://i.imgur.com/UpqmD2x.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jose Menese[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1187+"/",
        thumbnail="https://i.imgur.com/aEnDOFA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jose Merce[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_665+"/",
        thumbnail="https://i.imgur.com/3FwDIE3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Jose Velez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_947+"/",
        thumbnail="https://i.imgur.com/zyvRsiD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Joselito[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_948+"/",
        thumbnail="https://i.imgur.com/brPiLXx.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Journey[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_666+"/",
        thumbnail="https://i.imgur.com/5QNU2Cm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Joy Division[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1527+"/",
        thumbnail="https://i.imgur.com/Qu1LoCw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Juan Bau[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_949+"/",
        thumbnail="https://i.imgur.com/WRZoN83.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Juan Magan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_667+"/",
        thumbnail="https://i.imgur.com/QBCjiO0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Juan Pardo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_668+"/",
        thumbnail="https://i.imgur.com/Qu72xFT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Juan Perro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_816+"/",
        thumbnail="https://i.imgur.com/yGTzVkK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Juan y Junior[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_950+"/",
        thumbnail="https://i.imgur.com/qeupui8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Juanes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_761+"/",
        thumbnail="https://i.imgur.com/xI62A3o.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Juanita Reina[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_951+"/",
        thumbnail="https://i.imgur.com/tE7aUY8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Juanito Valderrama[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_952+"/",
        thumbnail="https://i.imgur.com/cN1fUqV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Judas Priest[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_347+"/",
        thumbnail="https://i.imgur.com/EVDJ2jo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Julio Iglesias[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_348+"/",
        thumbnail="https://i.imgur.com/RRblO7s.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Junco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_953+"/",
        thumbnail="https://i.imgur.com/a49yAP0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Justin Timberlake[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_349+"/",
        thumbnail="https://i.imgur.com/YjytTW1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kælan Mikla[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1528+"/",
        thumbnail="https://i.imgur.com/Dsb1tbl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kafu Banton[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1188+"/",
        thumbnail="https://i.imgur.com/YG6DUwB.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kajagoogoo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1529+"/",
        thumbnail="https://i.imgur.com/ckv1MPk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kaka Deluxe[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_350+"/",
        thumbnail="https://i.imgur.com/GY1pgGX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
			
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kamelot[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_669+"/",
        thumbnail="https://i.imgur.com/RJUyn2d.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kansas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_351+"/",
        thumbnail="https://i.imgur.com/TaUNWCZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Karina[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_954+"/",
        thumbnail="https://i.imgur.com/4iCW93L.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Katie James[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1530+"/",
        thumbnail="https://i.imgur.com/xFFSN01.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Katy Perry[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_352+"/",
        thumbnail="https://i.imgur.com/vS2WsWN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kc And The Sunshine Band[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1531+"/",
        thumbnail="https://i.imgur.com/9yacG92.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kelly Clarkson[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_817+"/",
        thumbnail="https://i.imgur.com/xRWwDZJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kelly Rowland[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_818+"/",
        thumbnail="https://i.imgur.com/ulXYtRA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kemuri[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1532+"/",
        thumbnail="https://i.imgur.com/nkb3UhW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kenny G[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_819+"/",
        thumbnail="https://i.imgur.com/E5L3MQw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kenny Loggings[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1725+"/",
        thumbnail="https://i.imgur.com/7GLEto7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kenny Rogers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1708+"/",
        thumbnail="https://i.imgur.com/EPYLU0d.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ketama[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_820+"/",
        thumbnail="https://i.imgur.com/QqxotjE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Khachaturian, Aram[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1399+"/",
        thumbnail="https://i.imgur.com/SxN2V1Y.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kiko Veneno[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_670+"/",
        thumbnail="https://i.imgur.com/E3PFr6m.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kiko y Sara[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_955+"/",
        thumbnail="https://i.imgur.com/f6Rlpi2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Killswitch Engage[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_353+"/",
        thumbnail="https://i.imgur.com/F2lcvch.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kim Wilde[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1533+"/",
        thumbnail="https://i.imgur.com/vdF6Si8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]King Crimson[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_354+"/",
        thumbnail="https://i.imgur.com/4mKURPo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kings Of Leon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_355+"/",
        thumbnail="https://i.imgur.com/iHTJkpj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kiss[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_356+"/",
        thumbnail="https://i.imgur.com/PWnjIxR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kix[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1534+"/",
        thumbnail="https://i.imgur.com/oDb2Ibd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kobra And The Lotus[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1535+"/",
        thumbnail="https://i.imgur.com/8R4r1xH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kool And The Gang[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1536+"/",
        thumbnail="https://i.imgur.com/XIdbUBx.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Korn[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_357+"/",
        thumbnail="https://i.imgur.com/hZXe6nW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kortatu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_358+"/",
        thumbnail="https://i.imgur.com/FNZQR1y.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Korsakov, Nikolai Rimski[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1400+"/",
        thumbnail="https://i.imgur.com/K7471D4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kraftwerk[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_359+"/",
        thumbnail="https://i.imgur.com/TPz2CTi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kris Kristofferson[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1709+"/",
        thumbnail="https://i.imgur.com/9ltN8zv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Krokus[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1537+"/",
        thumbnail="https://i.imgur.com/asFR8DV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Krull[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1039+"/",
        thumbnail="https://i.imgur.com/QUcZser.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kungs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1538+"/",
        thumbnail="https://i.imgur.com/HViIcKE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Kylie Minogue[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_360+"/",
        thumbnail="https://i.imgur.com/Smtudfe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Bouche[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1539+"/",
        thumbnail="https://i.imgur.com/4TouPni.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Bullonera[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1189+"/",
        thumbnail="https://i.imgur.com/Zykzajo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Cabra Mecanica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_821+"/",
        thumbnail="https://i.imgur.com/Qwfshyo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Chunga[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1065+"/",
        thumbnail="https://i.imgur.com/FCHJuj7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Decada Prodigiosa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_956+"/",
        thumbnail="https://i.imgur.com/w9i1A3D.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Fuga[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1292+"/",
        thumbnail="https://i.imgur.com/aLWUMqR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Guardia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_957+"/",
        thumbnail="https://i.imgur.com/MC79fSc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Hungara[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_958+"/",
        thumbnail="https://i.imgur.com/MyJfVsB.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Niña De La Puebla[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_959+"/",
        thumbnail="https://i.imgur.com/zYMzJSz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Niña De Los Peines[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1540+"/",
        thumbnail="https://i.imgur.com/ixVjqLJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Nueva Banda Timberiche[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_361+"/",
        thumbnail="https://i.imgur.com/AT1jiJK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Oreja De Van Gogh[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_362+"/",
        thumbnail="https://i.imgur.com/xLlMhXq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Polla Records[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_822+"/",
        thumbnail="https://i.imgur.com/rHyvd7P.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Quinta Estacion[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_363+"/",
        thumbnail="https://i.imgur.com/y3FhWWX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Sonora Matancera[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1190+"/",
        thumbnail="https://i.imgur.com/ONmljUW.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Toya Jackson[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1541+"/",
        thumbnail="https://i.imgur.com/VpNxg2d.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Trinca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1191+"/",
        thumbnail="https://i.imgur.com/jbBt2H9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Union[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_364+"/",
        thumbnail="https://i.imgur.com/SQPijT5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lacrimosa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1542+"/",
        thumbnail="https://i.imgur.com/NMprRGo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lacuna Coil[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1543+"/",
        thumbnail="https://i.imgur.com/65hia1Q.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lady Antebellum[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_365+"/",
        thumbnail="https://i.imgur.com/dQp9iMs.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lady Gaga[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_366+"/",
        thumbnail="https://i.imgur.com/VG4yBiq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lali[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1316+"/",
        thumbnail="https://i.imgur.com/BaxM2rk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lamb Of God[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_367+"/",
        thumbnail="https://i.imgur.com/QhIZvTu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lana Del Rey[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_823+"/",
        thumbnail="https://i.imgur.com/h19nq9v.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Las Grecas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_960+"/",
        thumbnail="https://i.imgur.com/qpE7DYo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Las Hermanas Parra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1192+"/",
        thumbnail="https://i.imgur.com/jePPYY6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Las Ketchup[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_961+"/",
        thumbnail="https://i.imgur.com/mz1Oa6Z.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Laura Branigan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_824+"/",
        thumbnail="https://i.imgur.com/3194Y9Z.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Laura Pausini[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_671+"/",
        thumbnail="https://i.imgur.com/T44V1Bn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Le Tigre[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1544+"/",
        thumbnail="https://i.imgur.com/xp01KHh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Led Zeppelin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_368+"/",
        thumbnail="https://i.imgur.com/h4ZqlpU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lenny Kravitz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_369+"/",
        thumbnail="https://i.imgur.com/ySgIF6P.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lenny Tavarez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1193+"/",
        thumbnail="https://i.imgur.com/pYtxShq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Leño[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_370+"/",
        thumbnail="https://i.imgur.com/6Bcd4we.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Leo Rojas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1194+"/",
        thumbnail="https://i.imgur.com/FFyphes.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Leo Sayer[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_757+"/",
        thumbnail="https://i.imgur.com/kPRqQ9o.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Leona Lewis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_825+"/",
        thumbnail="https://i.imgur.com/hwDWJkg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Leonard Cohen[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_672+"/",
        thumbnail="https://i.imgur.com/Pvfzaeh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Leprous[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_371+"/",
        thumbnail="https://i.imgur.com/gernYoW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lerica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1195+"/",
        thumbnail="https://i.imgur.com/ocY3yma.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Level 42[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_826+"/",
        thumbnail="https://i.imgur.com/lrREOWr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lila Downs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1196+"/",
        thumbnail="https://i.imgur.com/7rejT9I.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Liliac[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1545+"/",
        thumbnail="https://i.imgur.com/X9jbeNo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lilly Allen[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1546+"/",
        thumbnail="https://i.imgur.com/bgOX39s.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Limahl[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1200+"/",
        thumbnail="https://i.imgur.com/9TygMXc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Limp Bizkit[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_372+"/",
        thumbnail="https://i.imgur.com/N1GtzDx.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Linkin Park[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_373+"/",
        thumbnail="https://i.imgur.com/ys1it7N.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lionel Ritchie[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_374+"/",
        thumbnail="https://i.imgur.com/ku8j0DL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lipps Inc[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1293+"/",
        thumbnail="https://i.imgur.com/dmWiu7J.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lisa Stansfield[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_827+"/",
        thumbnail="https://i.imgur.com/Tyj1GDa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Liszt, Franz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1401+"/",
        thumbnail="https://i.imgur.com/UvnfNL2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Little Mix[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_375+"/",
        thumbnail="https://i.imgur.com/zx0UsJf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Little Richard[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_673+"/",
        thumbnail="https://i.imgur.com/9uoROTC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Liza Minnelli[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1197+"/",
        thumbnail="https://i.imgur.com/1pZ8tNW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lluis Llach[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1066+"/",
        thumbnail="https://i.imgur.com/PF1ghyU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lmfao[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1547+"/",
        thumbnail="https://i.imgur.com/CbUFJYH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Locomia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_962+"/",
        thumbnail="https://i.imgur.com/DD3zoap.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lola Flores[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_674+"/",
        thumbnail="https://i.imgur.com/x4nQ2M1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lola Indigo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_675+"/",
        thumbnail="https://i.imgur.com/LoMl58d.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lole y Manuel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_963+"/",
        thumbnail="https://i.imgur.com/C9mbnE8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lolita Garrido[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1198+"/",
        thumbnail="https://i.imgur.com/7OGDFlS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lolita Sevilla[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1199+"/",
        thumbnail="https://i.imgur.com/tPPGhBg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lollypop Lorry[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1548+"/",
        thumbnail="https://i.imgur.com/BMGPrvC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lone Star[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_376+"/",
        thumbnail="https://i.imgur.com/jRoS4CJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Loquillo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_377+"/",
        thumbnail="https://i.imgur.com/nFAom3e.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lord Of The Lost[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1549+"/",
        thumbnail="https://i.imgur.com/KuZEW2f.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lordi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_378+"/",
        thumbnail="https://i.imgur.com/61Maibq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lorenzo Santamaria[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_964+"/",
        thumbnail="https://i.imgur.com/TXmHDWn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Amaya[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_965+"/",
        thumbnail="https://i.imgur.com/LDfBHx2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Angeles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1040+"/",
        thumbnail="https://i.imgur.com/DxQofkR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Brincos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_967+"/",
        thumbnail="https://i.imgur.com/gi3LSxc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Calis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_968+"/",
        thumbnail="https://i.imgur.com/jJ32SAD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Caños[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_969+"/",
        thumbnail="https://i.imgur.com/LVAZlrw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Chichos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_970+"/",
        thumbnail="https://i.imgur.com/WcrApbF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Chimberos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_971+"/",
        thumbnail="https://i.imgur.com/1fNDOmy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Choqueros[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1201+"/",
        thumbnail="https://i.imgur.com/hY1wSB9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Chunguitos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_972+"/",
        thumbnail="https://i.imgur.com/Db42cjS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Del Rio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_973+"/",
        thumbnail="https://i.imgur.com/ty75wUN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item(		
        #action="", 
        title="[COLOR aqua]Los Bravos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_966+"/",
        thumbnail="https://i.imgur.com/s4HVLGZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Delincuentes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_974+"/",
        thumbnail="https://i.imgur.com/ZcLO1Ow.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Diablos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_975+"/",
        thumbnail="https://i.imgur.com/qBIeOOk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Fabulosos Cadillacs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_379+"/",
        thumbnail="https://i.imgur.com/Qz5BsxW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Gandules[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1202+"/",
        thumbnail="https://i.imgur.com/KanpyXN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Iberos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1041+"/",
        thumbnail="https://i.imgur.com/Ccnb5JM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Impala[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1203+"/",
        thumbnail="https://i.imgur.com/G9ic2Nh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Mariismeños[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_976+"/",
        thumbnail="https://i.imgur.com/uw2Qe69.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Millonarios del Jazz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1204+"/",
        thumbnail="https://i.imgur.com/wcZ7p82.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Mismos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_977+"/",
        thumbnail="https://i.imgur.com/8ZQzXbX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Mitos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1205+"/",
        thumbnail="https://i.imgur.com/4Q7L7h4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Modulos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1042+"/",
        thumbnail="https://i.imgur.com/8p8wgTl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Mustang[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_978+"/",
        thumbnail="https://i.imgur.com/oe0FNdg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Panchos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_979+"/",
        thumbnail="https://i.imgur.com/HtOrUnn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Pecos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_676+"/",
        thumbnail="https://i.imgur.com/PV6mP0Y.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Pekenikes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_980+"/",
        thumbnail="https://i.imgur.com/qIBqdcX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Piratas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_380+"/",
        thumbnail="https://i.imgur.com/clBbsJw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Planetas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_381+"/",
        thumbnail="https://i.imgur.com/LPDBYXp.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Platers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1043+"/",
        thumbnail="https://i.imgur.com/zk3AwhX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Rebujitos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1317+"/",
        thumbnail="https://i.imgur.com/XUWbVTL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Relampagos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_981+"/",
        thumbnail="https://i.imgur.com/neIzMp0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Rodriguez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_382+"/",
        thumbnail="https://i.imgur.com/HcqfVeR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Sabandeños[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1037+"/",
        thumbnail="https://i.imgur.com/zWkqlXw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Salvajes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_383+"/",
        thumbnail="https://i.imgur.com/NcOVpOz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Secretos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_384+"/",
        thumbnail="https://i.imgur.com/Vn72Uwb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Sirex[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_982+"/",
        thumbnail="https://i.imgur.com/IsZZArj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Suaves[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_385+"/",
        thumbnail="https://i.imgur.com/GWA8FQe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los TNT[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1206+"/",
        thumbnail="https://i.imgur.com/uJWHhkn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Toreros Muertos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_983+"/",
        thumbnail="https://i.imgur.com/RAhbUVs.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Los Tres Sudamericanos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_984+"/",
        thumbnail="https://i.imgur.com/HN3HlrT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lou Bega[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_830+"/",
        thumbnail="https://i.imgur.com/NiUhlAD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lou Reed[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_677+"/",
        thumbnail="https://i.imgur.com/YxIXvrQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Louis Armstrong[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_985+"/",
        thumbnail="https://i.imgur.com/xeHdrsh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Love And Rockets[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1550+"/",
        thumbnail="https://i.imgur.com/OGLkgIX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Love of Lesbian[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_386+"/",
        thumbnail="https://i.imgur.com/BNJeS0a.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Luar Na Lubre[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_831+"/",
        thumbnail="https://i.imgur.com/shB1cTi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lucciano Pavaroti[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1067+"/",
        thumbnail="https://i.imgur.com/H2oG1vN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lucho Gatica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1068+"/",
        thumbnail="https://i.imgur.com/VJFLbNU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lucio Dalla[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1069+"/",
        thumbnail="https://i.imgur.com/WHkkJWI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lucrecia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1551+"/",
        thumbnail="https://i.imgur.com/bM1E8lw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lucy Alves[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1552+"/",
        thumbnail="https://i.imgur.com/07l6a5J.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Luis Cobos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_678+"/",
        thumbnail="https://i.imgur.com/iTS6m2x.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Luis Eduardo Aute[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_679+"/",
        thumbnail="https://i.imgur.com/5pPjM4H.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Luis Fonsi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_387+"/",
        thumbnail="https://i.imgur.com/tzgzq9n.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Luis Lucena[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_986+"/",
        thumbnail="https://i.imgur.com/AJ6lGJ4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Luis Mariano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_987+"/",
        thumbnail="https://i.imgur.com/y7K81zz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Luis Miguel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_388+"/",
        thumbnail="https://i.imgur.com/kRTpX5q.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Luisita Tenor[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1207+"/",
        thumbnail="https://i.imgur.com/VaLJqir.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lume De Biqueira[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1208+"/",
        thumbnail="https://i.imgur.com/4cuhmY5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lunay[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1209+"/",
        thumbnail="https://i.imgur.com/pFMU3Mh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Luz Casal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_680+"/",
        thumbnail="https://i.imgur.com/g3v4VxS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lynyrd Skynyrd[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_681+"/",
        thumbnail="https://i.imgur.com/OZ6yVYU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]M.C Hammer[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1328+"/",
        thumbnail="https://i.imgur.com/J1Ll2lp.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]M Clan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_389+"/",
        thumbnail="https://i.imgur.com/Bi1FPrS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mabel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1210+"/",
        thumbnail="https://i.imgur.com/tDaiMc6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Macaco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_832+"/",
        thumbnail="https://i.imgur.com/w979D6c.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Machine Gun Kelly[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1553+"/",
        thumbnail="https://i.imgur.com/LYpudaq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Machine Head[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_390+"/",
        thumbnail="https://i.imgur.com/xOq4oXm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Madcon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1287+"/",
        thumbnail="https://i.imgur.com/LIFPoZS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Madnes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1554+"/",
        thumbnail="https://i.imgur.com/hyfnPej.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Madonna[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_391+"/",
        thumbnail="https://i.imgur.com/2TYEep4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Magic[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_392+"/",
        thumbnail="https://i.imgur.com/Vl2S9UT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mahler, Gustav[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1402+"/",
        thumbnail="https://i.imgur.com/AZTrmJN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mala Rodriguez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_682+"/",
        thumbnail="https://i.imgur.com/HBOIlTy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Malu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_393+"/",
        thumbnail="https://i.imgur.com/skfAuYa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Maluma[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_394+"/",
        thumbnail="https://i.imgur.com/40Dc35N.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mana[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_395+"/",
        thumbnail="https://i.imgur.com/0dWfrBW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Manegarm[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1555+"/",
        thumbnail="https://i.imgur.com/xwunkCv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Manhattan Transfer[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1211+"/",
        thumbnail="https://i.imgur.com/vYHq0Z4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Maniac Street Preachers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1288+"/",
        thumbnail="https://i.imgur.com/l3oH6h4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )			
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Manolo Caracol[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_988+"/",
        thumbnail="https://i.imgur.com/PcqCdZr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Manolo Escobar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_683+"/",
        thumbnail="https://i.imgur.com/AKhOCnk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Manolo Garcia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_396+"/",
        thumbnail="https://i.imgur.com/QO9N2dH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Manolo Sanlucar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_753+"/",
        thumbnail="https://i.imgur.com/nmOete3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Manolo Tena[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_397+"/",
        thumbnail="https://i.imgur.com/t0hYt8d.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Manowar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_833+"/",
        thumbnail="https://i.imgur.com/mW4B11x.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Manu Chao[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_834+"/",
        thumbnail="https://i.imgur.com/8xtMLBW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Manu Tenorio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_768+"/",
        thumbnail="https://i.imgur.com/W55yl1B.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Manuel Carrasco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_398+"/",
        thumbnail="https://i.imgur.com/SPKySUv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Manuel Navarro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_990+"/",
        thumbnail="https://i.imgur.com/WKvDCEN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Manuel De Falla[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_989+"/",
        thumbnail="https://i.imgur.com/j3uDnUe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Manzanita[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_991+"/",
        thumbnail="https://i.imgur.com/03ktQ4y.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Marc Anthony[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_835+"/",
        thumbnail="https://i.imgur.com/UCb1VCV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mari Fe De Triana[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_992+"/",
        thumbnail="https://i.imgur.com/QHiTf5y.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mari Trini[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_684+"/",
        thumbnail="https://i.imgur.com/yoEYErR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Maria Callas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_993+"/",
        thumbnail="https://i.imgur.com/qNzCtdR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Maria Cristina Plata[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1556+"/",
        thumbnail="https://i.imgur.com/aEiqt6y.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Maria Del Mar Bonet[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1212+"/",
        thumbnail="https://i.imgur.com/Vr50apv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Maria Del Monte[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_994+"/",
        thumbnail="https://i.imgur.com/25Hwgfl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Maria Dolores Pradera[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_995+"/",
        thumbnail="https://i.imgur.com/WBSmZuf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Maria Isabel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_685+"/",
        thumbnail="https://i.imgur.com/0hwKCBp.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Maria Jimenez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_996+"/",
        thumbnail="https://i.imgur.com/IIsRoiB.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Maria Jose Santiago[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_997+"/",
        thumbnail="https://i.imgur.com/MZrnB8A.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Maria Lourdes Iriondo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1213+"/",
        thumbnail="https://i.imgur.com/v92ypRE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Maria Ostiz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_998+"/",
        thumbnail="https://i.imgur.com/AZREgtb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Maria Rubi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1214+"/",
        thumbnail="https://i.imgur.com/XC81Ugy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Maria Villalon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_999+"/",
        thumbnail="https://i.imgur.com/mzwhuzv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mariah Carey[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_399+"/",
        thumbnail="https://i.imgur.com/aBwQ9HN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Marillion[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_686+"/",
        thumbnail="https://i.imgur.com/15uhd2f.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Marilyn Manson[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_400+"/",
        thumbnail="https://i.imgur.com/5ChQmFX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Marina Rosell[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1557+"/",
        thumbnail="https://i.imgur.com/9rKaLVf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Marisol[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1000+"/",
        thumbnail="https://i.imgur.com/7uDVqEl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Marlango[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1289+"/",
        thumbnail="https://i.imgur.com/jel5Kpu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )			

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Maroon 5[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_401+"/",
        thumbnail="https://i.imgur.com/kkMIegO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Marta Sanchez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_748+"/",
        thumbnail="https://i.imgur.com/fTX0VqJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Martika[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1558+"/",
        thumbnail="https://i.imgur.com/rRzS90L.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Martin L Gore[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1559+"/",
        thumbnail="https://i.imgur.com/Mam9jpb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Martirio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1001+"/",
        thumbnail="https://i.imgur.com/oXSoCpY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Marvin Gaye[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_687+"/",
        thumbnail="https://i.imgur.com/5cyjTz3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Massiel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1215+"/",
        thumbnail="https://i.imgur.com/pdiJUOJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mastodon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_402+"/",
        thumbnail="https://i.imgur.com/KUPIAiy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Matia Bazar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1002+"/",
        thumbnail="https://i.imgur.com/5HiaUI8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Matt McGuire[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1216+"/",
        thumbnail="https://i.imgur.com/ycPz3af.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Matt Mercers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1217+"/",
        thumbnail="https://i.imgur.com/QChClZQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Matt Monroe[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1218+"/",
        thumbnail="https://i.imgur.com/s3RqtJ5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Matt Redman[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1219+"/",
        thumbnail="https://i.imgur.com/HVnhlss.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Matty Braps[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1220+"/",
        thumbnail="https://i.imgur.com/Ttmh623.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Maurice Chevalier[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1070+"/",
        thumbnail="https://i.imgur.com/N71yvJ2.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Meatloaf[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_688+"/",
        thumbnail="https://i.imgur.com/G65DvxD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mecano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_403+"/",
        thumbnail="https://i.imgur.com/7WZ8A4K.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Medina Azahara[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_689+"/",
        thumbnail="https://i.imgur.com/Mhd468g.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Megadeth[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_404+"/",
        thumbnail="https://i.imgur.com/Du6Fe7Z.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Megaherz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1560+"/",
        thumbnail="https://i.imgur.com/r57cPCg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Meghan Trainor[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_836+"/",
        thumbnail="https://i.imgur.com/asUdCJz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Melanie C[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1726+"/",
        thumbnail="https://i.imgur.com/xbjOYz1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Melendi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_405+"/",
        thumbnail="https://i.imgur.com/iChbwsd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
			
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Melocos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1003+"/",
        thumbnail="https://i.imgur.com/5tlX2fQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Melody[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_690+"/",
        thumbnail="https://i.imgur.com/jNm9F3K.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Melon Diesel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_837+"/",
        thumbnail="https://i.imgur.com/WTelD2f.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mendelssohn, Felix[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1403+"/",
        thumbnail="https://i.imgur.com/VZZya8o.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Merche[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_691+"/",
        thumbnail="https://i.imgur.com/eTpEcG5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mery Granados[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1221+"/",
        thumbnail="https://i.imgur.com/PRirAG7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Metallica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_406+"/",
        thumbnail="https://i.imgur.com/CPyojKL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Metalite[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1561+"/",
        thumbnail="https://i.imgur.com/d0jjMCr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Michael Bolton[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_838+"/",
        thumbnail="https://i.imgur.com/qx3sudU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Michael Jackson[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_407+"/",
        thumbnail="https://i.imgur.com/5dg2SrI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Miguel Bose[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_408+"/",
        thumbnail="https://i.imgur.com/yMJhBrG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Miguel De Molina[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1004+"/",
        thumbnail="https://i.imgur.com/5klCSFR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Miguel Gallardo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1005+"/",
        thumbnail="https://i.imgur.com/CJxDysU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Miguel Nandez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1006+"/",
        thumbnail="https://i.imgur.com/eEs6u4h.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Miguel Poveda[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_692+"/",
        thumbnail="https://i.imgur.com/ieckzcH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Miguel Rios[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_693+"/",
        thumbnail="https://i.imgur.com/yLdaBcn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Miguel Saez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1007+"/",
        thumbnail="https://i.imgur.com/xzxLL4Y.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mika[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_767+"/",
        thumbnail="https://i.imgur.com/F01stla.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mike and the Mechanics[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_694+"/",
        thumbnail="https://i.imgur.com/CW4qtTw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mike Oldfield[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_409+"/",
        thumbnail="https://i.imgur.com/coDGAGQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mikel Laboa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1222+"/",
        thumbnail="https://i.imgur.com/b7ovTaT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Miles Davis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1223+"/",
        thumbnail="https://i.imgur.com/GAyb9Xk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Miley Cyrus[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_695+"/",
        thumbnail="https://i.imgur.com/P4QR0H4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mina[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1224+"/",
        thumbnail="https://i.imgur.com/8778oTo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ministry[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1562+"/",
        thumbnail="https://i.imgur.com/vayEK6u.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Miquel Cors[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1225+"/",
        thumbnail="https://i.imgur.com/kKe4izc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Miranda[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_410+"/",
        thumbnail="https://i.imgur.com/zqdbuuv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mireille Mathieu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1008+"/",
        thumbnail="https://i.imgur.com/QtVkmDy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Misfits[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_411+"/",
        thumbnail="https://i.imgur.com/GlYbhQL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Miwa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1563+"/",
        thumbnail="https://i.imgur.com/5CLrAxG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mocedades[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_696+"/",
        thumbnail="https://i.imgur.com/C6vSBQ1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Modestia Aparte[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1009+"/",
        thumbnail="https://i.imgur.com/wkfZNhP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mojinos Escozios[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_765+"/",
        thumbnail="https://i.imgur.com/qcuXx1a.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Molotov[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_412+"/",
        thumbnail="https://i.imgur.com/8brYXko.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Monica Naranjo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_697+"/",
        thumbnail="https://i.imgur.com/4FhJp2q.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mono Inc[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1564+"/",
        thumbnail="https://i.imgur.com/4Vxw6dg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Monster Truck[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1565+"/",
        thumbnail="https://i.imgur.com/Cywp9RP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Moody Blues[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_413+"/",
        thumbnail="https://i.imgur.com/eE1N0VS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Moonlight Howlers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_698+"/",
        thumbnail="https://i.imgur.com/IKWQdJd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Moonspell[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1566+"/",
        thumbnail="https://i.imgur.com/Frjt7bp.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Morat[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_759+"/",
        thumbnail="https://i.imgur.com/HUflgAk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Morgan Heritage[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1226+"/",
        thumbnail="https://i.imgur.com/yQs5NSh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Motionless In White[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_414+"/",
        thumbnail="https://i.imgur.com/ck4aBqn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Motley Crue[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_415+"/",
        thumbnail="https://i.imgur.com/HiRSljO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Motorama[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1567+"/",
        thumbnail="https://i.imgur.com/cm4gelJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Motorhead[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_416+"/",
        thumbnail="https://i.imgur.com/Fs49W6k.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mozart, Wolfgang Amadeus[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1404+"/",
        thumbnail="https://i.imgur.com/prFTL4f.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mr Big[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1568+"/",
        thumbnail="https://i.imgur.com/lzN4uSj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mr President[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1569+"/",
        thumbnail="https://i.imgur.com/s16FpPT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Muddy Waters[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1227+"/",
        thumbnail="https://i.imgur.com/YhXTulW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mudvayne[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_417+"/",
        thumbnail="https://i.imgur.com/giyqdwp.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Muse[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_699+"/",
        thumbnail="https://i.imgur.com/CrjhF9I.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mushroomhead[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1570+"/",
        thumbnail="https://i.imgur.com/nRcFOE3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]MxPx[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1571+"/",
        thumbnail="https://i.imgur.com/IMCDoO2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]My Chemical Romance[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_418+"/",
        thumbnail="https://i.imgur.com/2ewjM1P.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Myke Towers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1228+"/",
        thumbnail="https://i.imgur.com/5z7q5Sf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nach[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1294+"/",
        thumbnail="https://i.imgur.com/PM4vUc8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nacha Guevara[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1229+"/",
        thumbnail="https://i.imgur.com/a8Ea78S.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nacha Pop[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_419+"/",
        thumbnail="https://i.imgur.com/xJvPSyW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nat King Cole[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1230+"/",
        thumbnail="https://i.imgur.com/Xy8WzIe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Natalia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_769+"/",
        thumbnail="https://i.imgur.com/5xzJu4o.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Natalia Jimenez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_700+"/",
        thumbnail="https://i.imgur.com/0B7KwGI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Natalia Lafourcade[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1231+"/",
        thumbnail="https://i.imgur.com/pQ9g9af.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Natanael Cano[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1232+"/",
        thumbnail="https://i.imgur.com/mYA0rUk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nati Mistral[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1233+"/",
        thumbnail="https://i.imgur.com/7S4qIus.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Natti Natasha[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_701+"/",
        thumbnail="https://i.imgur.com/QMQKsGD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Navajita Platea[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1010+"/",
        thumbnail="https://i.imgur.com/K9o0OHp.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Neil Diamond[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_702+"/",
        thumbnail="https://i.imgur.com/BHccyph.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Neil Sedaka[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1572+"/",
        thumbnail="https://i.imgur.com/KExn9bo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Neil Young[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_703+"/",
        thumbnail="https://i.imgur.com/AHxFEHg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nek[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_704+"/",
        thumbnail="https://i.imgur.com/C6PytOj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nelly Furtado[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_839+"/",
        thumbnail="https://i.imgur.com/T4bYKwc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nelson[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1573+"/",
        thumbnail="https://i.imgur.com/wjBiaMC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nena[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1574+"/",
        thumbnail="https://i.imgur.com/YGxQlvP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nena Daconte[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_840+"/",
        thumbnail="https://i.imgur.com/IqWeOxl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nicki Minaj[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_841+"/",
        thumbnail="https://i.imgur.com/MenfPuF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nicola Di Bari[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1011+"/",
        thumbnail="https://i.imgur.com/r0rRNDz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nightwish[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_420+"/",
        thumbnail="https://i.imgur.com/XQGkvnb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nikki Clan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_421+"/",
        thumbnail="https://i.imgur.com/Mnj7CPf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nikky Jam[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_422+"/",
        thumbnail="https://i.imgur.com/5o6bkUF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nina Simone[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1049+"/",
        thumbnail="https://i.imgur.com/Eyi31UH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )			
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nino Bravo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_705+"/",
        thumbnail="https://i.imgur.com/pixpMWX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nino Rota[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1318+"/",
        thumbnail="https://i.imgur.com/kflWpxM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )    

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Niña De Antequera[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1234+"/",
        thumbnail="https://i.imgur.com/oUCCadZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Niña Pastori[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_423+"/",
        thumbnail="https://i.imgur.com/WeFLcrj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nirvana[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_424+"/",
        thumbnail="https://i.imgur.com/1utuvjX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]No Doubt[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_425+"/",
        thumbnail="https://i.imgur.com/v14qlJO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]No Mercy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1575+"/",
        thumbnail="https://i.imgur.com/lPPy6BS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nosferatu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1576+"/",
        thumbnail="https://i.imgur.com/VovK8UE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nothing More[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_426+"/",
        thumbnail="https://i.imgur.com/6rdgUJY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nsync[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_427+"/",
        thumbnail="https://i.imgur.com/aaQSm6Q.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nu Shooz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1577+"/",
        thumbnail="https://i.imgur.com/O8qhwwi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nuevo Rap[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_842+"/",
        thumbnail="https://i.imgur.com/vtnJqv3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nuno Bettencourt[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1578+"/",
        thumbnail="https://i.imgur.com/TS2PgIe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nya De La Rubia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1319+"/",
        thumbnail="https://i.imgur.com/k9EJoox.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nyno Vargas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1235+"/",
        thumbnail="https://i.imgur.com/sKyr5Eb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ñu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_428+"/",
        thumbnail="https://i.imgur.com/IFniyTh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]O.B.K[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1579+"/",
        thumbnail="https://i.imgur.com/Li6WfC0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Oasis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_429+"/",
        thumbnail="https://i.imgur.com/2nSfBy0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Obus[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_430+"/",
        thumbnail="https://i.imgur.com/1EtbBEH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Of Mice And Men[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_431+"/",
        thumbnail="https://i.imgur.com/k8m9nAG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Omega[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1580+"/",
        thumbnail="https://i.imgur.com/PWRBd23.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]One Direction[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_432+"/",
        thumbnail="https://i.imgur.com/LNKzQwX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]One Republic[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_433+"/",
        thumbnail="https://i.imgur.com/LNKzQwX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Orden Ogan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1581+"/",
        thumbnail="https://i.imgur.com/JaMGgYz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Orianthi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1582+"/",
        thumbnail="https://i.imgur.com/UPwvjYR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Orquesta Mondragon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_434+"/",
        thumbnail="https://i.imgur.com/2bQ1tTn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Orquesta Riverside[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1236+"/",
        thumbnail="https://i.imgur.com/h7AGzjj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Osibisa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1237+"/",
        thumbnail="https://i.imgur.com/B8KhmFF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ottawan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1583+"/",
        thumbnail="https://i.imgur.com/NjaJKRv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Our Last Nigth[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_435+"/",
        thumbnail="https://i.imgur.com/TOoLKzM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ov7[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_436+"/",
        thumbnail="https://i.imgur.com/I9jvfUI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ozuma[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_437+"/",
        thumbnail="https://i.imgur.com/Fj4l9qn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ozzy Osbourne[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_438+"/",
        thumbnail="https://i.imgur.com/amNZYCK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]P.Lion[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1584+"/",
        thumbnail="https://i.imgur.com/g3ICYuw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pablo Abraira[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1012+"/",
        thumbnail="https://i.imgur.com/uvwf5Yd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pablo Alboran[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_439+"/",
        thumbnail="https://i.imgur.com/ZKy00nn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pablo Lopez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_440+"/",
        thumbnail="https://i.imgur.com/FzPibaw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pablo Milanes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_843+"/",
        thumbnail="https://i.imgur.com/JNCz1EM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Paco De Lucia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_441+"/",
        thumbnail="https://i.imgur.com/CvJ5g8P.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Paco Ibañez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1238+"/",
        thumbnail="https://i.imgur.com/2weq1do.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Paige Anderson & The Fearless Kin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1585+"/",
        thumbnail="https://i.imgur.com/FWfMh5K.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Paloma Faith[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1239+"/",
        thumbnail="https://i.imgur.com/Oigtq3Y.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Paloma Ford[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1240+"/",
        thumbnail="https://i.imgur.com/Eit8ird.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Paloma San Basilio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_706+"/",
        thumbnail="https://i.imgur.com/OSU4pFh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Panic At The Disco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_442+"/",
        thumbnail="https://i.imgur.com/8PPoLQs.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pantera[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_443+"/",
        thumbnail="https://i.imgur.com/zVQLwY9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Papa Roach[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_444+"/",
        thumbnail="https://i.imgur.com/GN4HFKA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Papo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_844+"/",
        thumbnail="https://i.imgur.com/N2aDLyf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Paquita La Del Barrio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1013+"/",
        thumbnail="https://i.imgur.com/7Lq9rSk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Paquita Rico[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1014+"/",
        thumbnail="https://i.imgur.com/5aOUklE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Parasite[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1586+"/",
        thumbnail="https://i.imgur.com/umsSYIU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pat Boone[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1727+"/",
        thumbnail="https://i.imgur.com/SBPbSgE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pat Metheny[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1241+"/",
        thumbnail="https://i.imgur.com/2bUXwMF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Patricia Kraus[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1242+"/",
        thumbnail="https://i.imgur.com/LUOIe6p.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Patsy Cline[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1728+"/",
        thumbnail="https://i.imgur.com/q5bXF93.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Patti Smith[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_845+"/",
        thumbnail="https://i.imgur.com/zw0n6IW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Patty Bravo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1071+"/",
        thumbnail="https://i.imgur.com/QXmem2H.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Patxi Andion[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_846+"/",
        thumbnail="https://i.imgur.com/0ImQ0LR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Paramore[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_445+"/",
        thumbnail="https://i.imgur.com/cCUI7Se.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Parkway Drive[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_446+"/",
        thumbnail="https://i.imgur.com/oBhlFT3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Parrita[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1015+"/",
        thumbnail="https://i.imgur.com/xSLd2F2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pasion Vega[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_707+"/",
        thumbnail="https://i.imgur.com/zpe5Urc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pastora Imperio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1016+"/",
        thumbnail="https://i.imgur.com/mJaKt8w.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pastora Soler[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_447+"/",
        thumbnail="https://i.imgur.com/A1Avv8J.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pat Benatar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_448+"/",
        thumbnail="https://i.imgur.com/yaAWa49.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pata Negra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_449+"/",
        thumbnail="https://i.imgur.com/qYc5CGx.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Patricia Manterola[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_766+"/",
        thumbnail="https://i.imgur.com/92f62Yl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Paul Anka[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1072+"/",
        thumbnail="https://i.imgur.com/0zNHGvF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Paul McCartney[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1073+"/",
        thumbnail="https://i.imgur.com/sv6EAgj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Paul Mauriat[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1243+"/",
        thumbnail="https://i.imgur.com/J6rEYS8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Paulina Rubio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1017+"/",
        thumbnail="https://i.imgur.com/lRuL0Me.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Peaches And Herb[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1587+"/",
        thumbnail="https://i.imgur.com/Wjsg2SG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pearl Jam[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_450+"/",
        thumbnail="https://i.imgur.com/9RUiCv2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pepe Blanco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1018+"/",
        thumbnail="https://i.imgur.com/gEBYa0f.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Peret[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_749+"/",
        thumbnail="https://i.imgur.com/91ZYM27.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Perez Prado[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_708+"/",
        thumbnail="https://i.imgur.com/UrKeWLK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Perlita De Huelva[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1019+"/",
        thumbnail="https://i.imgur.com/egmOx0F.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pet Shop Boys[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_451+"/",
        thumbnail="https://i.imgur.com/MchfoYu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Peter Frampton[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_709+"/",
        thumbnail="https://i.imgur.com/zAad5bP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Peter Gabriel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_452+"/",
        thumbnail="https://i.imgur.com/RehSEWz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Peter Murphy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1588+"/",
        thumbnail="https://i.imgur.com/loAobR7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Peter Schiling[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1589+"/",
        thumbnail="https://i.imgur.com/wW6LYjK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Petula Clark[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1590+"/",
        thumbnail="https://i.imgur.com/WaB7jhy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pharrell Williams[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_847+"/",
        thumbnail="https://i.imgur.com/QYg3spR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Phil Collins[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_453+"/",
        thumbnail="https://i.imgur.com/Oprogtz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pieces Of Eden[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1591+"/",
        thumbnail="https://i.imgur.com/99qrLTV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )			
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pignoise[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_710+"/",
        thumbnail="https://i.imgur.com/5ieI2rw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pimpinella[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_454+"/",
        thumbnail="https://i.imgur.com/rDATIUV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pink[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_455+"/",
        thumbnail="https://i.imgur.com/jPnaame.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pink Floyd[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_456+"/",
        thumbnail="https://i.imgur.com/YmC999L.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pino DAngio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1074+"/",
        thumbnail="https://i.imgur.com/sebxIWf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pitingo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_711+"/",
        thumbnail="https://i.imgur.com/29HVqZr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pitt Bull[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_457+"/",
        thumbnail="https://i.imgur.com/wdGtJcS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pj Harvey[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1592+"/",
        thumbnail="https://i.imgur.com/tOUbhuc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Placebo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_712+"/",
        thumbnail="https://i.imgur.com/weZ7xl0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Placido Domingo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1075+"/",
        thumbnail="https://i.imgur.com/4ecrLV0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Platero y Tu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_848+"/",
        thumbnail="https://i.imgur.com/4esfmJL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]P.O.D[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1330+"/",
        thumbnail="https://i.imgur.com/50tMgKa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pockey LaFarge[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1593+"/",
        thumbnail="https://i.imgur.com/KcJKwb9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Poison[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_458+"/",
        thumbnail="https://i.imgur.com/kcasoR9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pop Evil[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_459+"/",
        thumbnail="https://i.imgur.com/XF23cH3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Presuntos Implicados[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_460+"/",
        thumbnail="https://i.imgur.com/BKgClVe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Prevail[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_461+"/",
        thumbnail="https://i.imgur.com/YIC74ms.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Prince[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_462+"/",
        thumbnail="https://i.imgur.com/Px2uBRe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Projetc Pitchfork[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1594+"/",
        thumbnail="https://i.imgur.com/bEWbdvx.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Prokokiev, Serguei[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1405+"/",
        thumbnail="https://i.imgur.com/VjMr8qC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Puccini, Giacomo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1406+"/",
        thumbnail="https://i.imgur.com/X2393v3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Puddle Of Mudd[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_463+"/",
        thumbnail="https://i.imgur.com/JU5citc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pussy Cat Dolls[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_464+"/",
        thumbnail="https://i.imgur.com/lHYDMjr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Queen[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_465+"/",
        thumbnail="https://i.imgur.com/BRTXZ8y.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Queens Of Stone Age[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_466+"/",
        thumbnail="https://i.imgur.com/EtFRnW7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Quiet Riot[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_467+"/",
        thumbnail="https://i.imgur.com/QBW8neJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Quini Rangel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1244+"/",
        thumbnail="https://i.imgur.com/m17ZvVJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Quincy Jones[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_849+"/",
        thumbnail="https://i.imgur.com/sUar7fq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rachmaninof, Serguei[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1407+"/",
        thumbnail="https://i.imgur.com/XujQY7Y.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Radio Futura[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_468+"/",
        thumbnail="https://i.imgur.com/LtwMNii.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Radiohead[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_469+"/",
        thumbnail="https://i.imgur.com/WEWXnes.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rafael Farina[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1020+"/",
        thumbnail="https://i.imgur.com/2lZ215K.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Raffaella Carra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1076+"/",
        thumbnail="https://i.imgur.com/gP08UFL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rage Aganist The Machine[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_470+"/",
        thumbnail="https://i.imgur.com/npy7CoB.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rage Of Light[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1595+"/",
        thumbnail="https://i.imgur.com/6CmVodd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rainbow[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_471+"/",
        thumbnail="https://i.imgur.com/GN2joO7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rammstein[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_472+"/",
        thumbnail="https://i.imgur.com/yTcVcPU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ramoncin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1021+"/",
        thumbnail="https://i.imgur.com/SExcwOT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ramones[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_473+"/",
        thumbnail="https://i.imgur.com/SDTkgng.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Randy Van Warmer[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_756+"/",
        thumbnail="https://i.imgur.com/6wvR54V.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Raphael[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_474+"/",
        thumbnail="https://i.imgur.com/FKzGB6a.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rasel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1320+"/",
        thumbnail="https://i.imgur.com/3RPdMdr.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rata Blanca[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1295+"/",
        thumbnail="https://i.imgur.com/vE87DxW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ratt[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_475+"/",
        thumbnail="https://i.imgur.com/enMFCVc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Raul Palomo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1245+"/",
        thumbnail="https://i.imgur.com/rvbRWdC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rauw Alejandro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1246+"/",
        thumbnail="https://i.imgur.com/EEMBnHk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ravel, Maurice[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1408+"/",
        thumbnail="https://i.imgur.com/szMF6VX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ray Charles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1247+"/",
        thumbnail="https://i.imgur.com/9NTyN7O.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rbd[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_476+"/",
        thumbnail="https://i.imgur.com/ykHy6Wa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Real McCoy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1596+"/",
        thumbnail="https://i.imgur.com/5E8RmwF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Really Slow Motion[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1597+"/",
        thumbnail="https://i.imgur.com/iybqXoL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rebel Cats[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1598+"/",
        thumbnail="https://i.imgur.com/i5QmUzv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Red Fang[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1599+"/",
        thumbnail="https://i.imgur.com/iUmKWc6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Red Hot Chilli Peppers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_477+"/",
        thumbnail="https://i.imgur.com/WhRPdVO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rednex[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1600+"/",
        thumbnail="https://i.imgur.com/OK4D9Up.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Regina Spektor[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1601+"/",
        thumbnail="https://i.imgur.com/lerEfhS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Reik[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_478+"/",
        thumbnail="https://i.imgur.com/S5G0o4o.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rem[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_479+"/",
        thumbnail="https://i.imgur.com/5hoLOAr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Renee Mooi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1248+"/",
        thumbnail="https://i.imgur.com/2VBoTr2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Reo Speedwagon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_480+"/",
        thumbnail="https://i.imgur.com/yLDu5dp.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Replik[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_862+"/",
        thumbnail="https://i.imgur.com/2EXJGei.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Republica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1729+"/",
        thumbnail="https://i.imgur.com/NqooUZc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ric Ocasek[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1602+"/",
        thumbnail="https://i.imgur.com/E1KUntc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ricchi E Poveri[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1022+"/",
        thumbnail="https://i.imgur.com/hPHadt9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Richard Clayderman[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_758+"/",
        thumbnail="https://i.imgur.com/zQWrqyR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Richard Cocciante[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1023+"/",
        thumbnail="https://i.imgur.com/aAWEUud.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Richard Marx[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_713+"/",
        thumbnail="https://i.imgur.com/E6SUj5I.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ricky Martin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_481+"/",
        thumbnail="https://i.imgur.com/yD6nmWo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Righteous Brothers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1249+"/",
        thumbnail="https://i.imgur.com/LoQF2pV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rihanna[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_482+"/",
        thumbnail="https://i.imgur.com/GeamDKP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ringo Starr[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1250+"/",
        thumbnail="https://i.imgur.com/AizEMkR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rise Against[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_483+"/",
        thumbnail="https://i.imgur.com/v2tDIrB.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rita Pavone[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1077+"/",
        thumbnail="https://i.imgur.com/u94wQ6r.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ritchie Valens[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_714+"/",
        thumbnail="https://i.imgur.com/uhQJNcl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rival Sons[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1603+"/",
        thumbnail="https://i.imgur.com/CrcHKnK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rob Zombie[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_484+"/",
        thumbnail="https://i.imgur.com/2RnmnSG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Robbie Williams[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_485+"/",
        thumbnail="https://i.imgur.com/wEtrc9z.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Roberta Flack[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_863+"/",
        thumbnail="https://i.imgur.com/xkhdC73.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Roberto Carlos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_715+"/",
        thumbnail="https://i.imgur.com/1aLj9jp.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Robin Gibb[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1604+"/",
        thumbnail="https://i.imgur.com/rtbJ44o.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rocio Durcal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_716+"/",
        thumbnail="https://i.imgur.com/MFrinw0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rocio Jurado[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_486+"/",
        thumbnail="https://i.imgur.com/xyIHUzV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rod Steward[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_487+"/",
        thumbnail="https://i.imgur.com/bq1iZqA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rolling Stone[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_488+"/",
        thumbnail="https://i.imgur.com/bPVzrV9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rory Gallagher[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1605+"/",
        thumbnail="https://i.imgur.com/7h6bFR2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rosa Cedron[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1251+"/",
        thumbnail="https://i.imgur.com/1ifr8vH.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rosa Leon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1024+"/",
        thumbnail="https://i.imgur.com/NOGbSaj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rosa Lopez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1078+"/",
        thumbnail="https://i.imgur.com/deN7J1Q.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rosa Morena[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1025+"/",
        thumbnail="https://i.imgur.com/NzX3cuU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rosalia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_489+"/",
        thumbnail="https://i.imgur.com/63KhKFC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rosana[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_717+"/",
        thumbnail="https://i.imgur.com/0oaabK8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rosendo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1079+"/",
        thumbnail="https://i.imgur.com/3pi3GdX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rossini, Gioachino[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1409+"/",
        thumbnail="https://i.imgur.com/VEWmZuw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Roxette[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_490+"/",
        thumbnail="https://i.imgur.com/lDb1qiY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Roxy Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_491+"/",
        thumbnail="https://i.imgur.com/kpXGmFz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Roy Orbison[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1252+"/",
        thumbnail="https://i.imgur.com/dDIqszC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Royal Bliss[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1606+"/",
        thumbnail="https://i.imgur.com/45qiqYr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Royal Blood[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1607+"/",
        thumbnail="https://i.imgur.com/MLNsHRG.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Röyksopp[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1608+"/",
        thumbnail="https://i.imgur.com/a9z5rxu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rozalen[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_718+"/",
        thumbnail="https://i.imgur.com/ghlYqN3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rumba Tres[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1026+"/",
        thumbnail="https://i.imgur.com/J1R3Q3w.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Rush[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_492+"/",
        thumbnail="https://i.imgur.com/e3IDNHQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ruth Lorenzo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_493+"/",
        thumbnail="https://i.imgur.com/BM5rmts.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ryan Paris[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1609+"/",
        thumbnail="https://i.imgur.com/MQ11rEq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sabaton[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_494+"/",
        thumbnail="https://i.imgur.com/81epsvZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sacha Distel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1027+"/",
        thumbnail="https://i.imgur.com/WYWgsmX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sade[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_495+"/",
        thumbnail="https://i.imgur.com/njTcxYC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Safri Duo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1610+"/",
        thumbnail="https://i.imgur.com/Nzx9RlT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sally Oldfield[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1028+"/",
        thumbnail="https://i.imgur.com/8JPn0el.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Salome[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1029+"/",
        thumbnail="https://i.imgur.com/n78iIFR.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Saltors[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1253+"/",
        thumbnail="https://i.imgur.com/3xPqhGk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sammi Smith[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1611+"/",
        thumbnail="https://i.imgur.com/ABFxZZe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sandie Show[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1254+"/",
        thumbnail="https://i.imgur.com/AIYkwUr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sandro Giacobbe[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1030+"/",
        thumbnail="https://i.imgur.com/f5tom9W.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Santana[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_719+"/",
        thumbnail="https://i.imgur.com/2HTBRNE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sara Montiel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1031+"/",
        thumbnail="https://i.imgur.com/k9IhTm6.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sarayma[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1321+"/",
        thumbnail="https://i.imgur.com/C46Kk1T.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sash[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1612+"/",
        thumbnail="https://i.imgur.com/WvDUgAK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Savage Garden[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_496+"/",
        thumbnail="https://i.imgur.com/eBEahMu.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Savatage[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1613+"/",
        thumbnail="https://i.imgur.com/hXLoWlA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Saxon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1614+"/",
        thumbnail="https://i.imgur.com/QScq7MJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Scatman[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1615+"/",
        thumbnail="https://i.imgur.com/vlZglG8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Schubert, Franz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1411+"/",
        thumbnail="https://i.imgur.com/JaQgHeo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Schumann, Robert[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1412+"/",
        thumbnail="https://i.imgur.com/hEoogJg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Scorpions[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_497+"/",
        thumbnail="https://i.imgur.com/1d0Nknr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Seasons After[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1616+"/",
        thumbnail="https://i.imgur.com/iHh3Uks.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sech[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1255+"/",
        thumbnail="https://i.imgur.com/MhDVNCM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Seether[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_498+"/",
        thumbnail="https://i.imgur.com/1COzeUA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Seguridad Social[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_499+"/",
        thumbnail="https://i.imgur.com/FZTCUbY.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Selena Gomez[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_720+"/",
        thumbnail="https://i.imgur.com/wqENpc0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Semblant[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1617+"/",
        thumbnail="https://i.imgur.com/gsMJnW2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sergio Dalma[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_721+"/",
        thumbnail="https://i.imgur.com/ttJXHsv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sergio y Estibaliz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1032+"/",
        thumbnail="https://i.imgur.com/Hn2VWeX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sevendust[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_500+"/",
        thumbnail="https://i.imgur.com/Caufsty.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sex Pistols[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_501+"/",
        thumbnail="https://i.imgur.com/92p1wi3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Shaila Durcal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1033+"/",
        thumbnail="https://i.imgur.com/n2arrOT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Shakespears Sister[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1618+"/",
        thumbnail="https://i.imgur.com/EX7UHyC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Shakira[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_722+"/",
        thumbnail="https://i.imgur.com/iTh3pjg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Shania Twain[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_751+"/",
        thumbnail="https://i.imgur.com/xTisxfM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]She Hates Emotions[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1619+"/",
        thumbnail="https://i.imgur.com/6guciOr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sheena Easton[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1620+"/",
        thumbnail="https://i.imgur.com/TaLOHv8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sheryl Crow[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_723+"/",
        thumbnail="https://i.imgur.com/VE2ZRxL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Shinedown[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_502+"/",
        thumbnail="https://i.imgur.com/w3ahtCV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Shireen[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1621+"/",
        thumbnail="https://i.imgur.com/qo85BCT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Shostakovich, Dmitri[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1413+"/",
        thumbnail="https://i.imgur.com/CSnZ7Yi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_503+"/",
        thumbnail="https://i.imgur.com/0iAShQd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sigue Sigue Sputnik[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1622+"/",
        thumbnail="https://i.imgur.com/ZJFG06A.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Silent Circle[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1623+"/",
        thumbnail="https://i.imgur.com/x1vBk1x.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Silver Convention[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1256+"/",
        thumbnail="https://i.imgur.com/nK5Zc43.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Silver Pozzoli[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1624+"/",
        thumbnail="https://i.imgur.com/iTLFGc3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Simon And Garlfunken[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_504+"/",
        thumbnail="https://i.imgur.com/qn1UP0K.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Simon Rondon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1625+"/",
        thumbnail="https://i.imgur.com/ixw7k65.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Simple Minds[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_505+"/",
        thumbnail="https://i.imgur.com/I0MKPcX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Simple Plan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_506+"/",
        thumbnail="https://i.imgur.com/M4SKqbJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Simply Red[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_507+"/",
        thumbnail="https://i.imgur.com/zrxvEpb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Siniestro Total[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_508+"/",
        thumbnail="https://i.imgur.com/jWywaJ4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Siva Six[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1626+"/",
        thumbnail="https://i.imgur.com/ukmGc1T.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sizzla[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1257+"/",
        thumbnail="https://i.imgur.com/4WHczBE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ska-P[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_724+"/",
        thumbnail="https://i.imgur.com/4BVTWdT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Skriabin, Aleksandr[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1414+"/",
        thumbnail="https://i.imgur.com/YtD5tVg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Skid Row[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_509+"/",
        thumbnail="https://i.imgur.com/alFyrL8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Skillet[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_510+"/",
        thumbnail="https://i.imgur.com/AfCti1r.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Skone[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_864+"/",
        thumbnail="https://i.imgur.com/SoP9lkU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Slash[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_511+"/",
        thumbnail="https://i.imgur.com/76aTnQj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Slayer[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_512+"/",
        thumbnail="https://i.imgur.com/aojRjrP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]SlipKnot[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_513+"/",
        thumbnail="https://i.imgur.com/4CvZtN3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Slowdive[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1627+"/",
        thumbnail="https://i.imgur.com/b8D9YAI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Smackbound[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1628+"/",
        thumbnail="https://i.imgur.com/FJ0w3nN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Smashing Pumpkins[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_514+"/",
        thumbnail="https://i.imgur.com/mtErSfe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Smetana, Bedrich[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1415+"/",
        thumbnail="https://i.imgur.com/ryJuzlb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Solea Morente[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1258+"/",
        thumbnail="https://i.imgur.com/SYavRo2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sonata Artica[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1629+"/",
        thumbnail="https://i.imgur.com/Qi3mBXX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sondeseu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1259+"/",
        thumbnail="https://i.imgur.com/C4lOiyy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sonic Youth[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1630+"/",
        thumbnail="https://i.imgur.com/XxJ3S8f.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sonohra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_515+"/",
        thumbnail="https://i.imgur.com/l9vlCKF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Soraya Arnelas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1034+"/",
        thumbnail="https://i.imgur.com/Ja90p8d.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Soundgarden[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_516+"/",
        thumbnail="https://i.imgur.com/3qcgBKv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Spandau Ballet[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_517+"/",
        thumbnail="https://i.imgur.com/r81znvJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Spice Girls[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_518+"/",
        thumbnail="https://i.imgur.com/d8uOEJo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Spin Doctors[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1730+"/",
        thumbnail="https://i.imgur.com/ysEhArq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Stacey Q[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1631+"/",
        thumbnail="https://i.imgur.com/7wJnPId.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Starset[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_519+"/",
        thumbnail="https://i.imgur.com/48W7C0Q.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]State Of Mine[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1296+"/",
        thumbnail="https://i.imgur.com/XnWmOBh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Static X[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_520+"/",
        thumbnail="https://i.imgur.com/tVa2viS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Status Quo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_521+"/",
        thumbnail="https://i.imgur.com/u0AIR3X.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Steely Dan[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_725+"/",
        thumbnail="https://i.imgur.com/5gRuXP0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Steppenwolf[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_726+"/",
        thumbnail="https://i.imgur.com/I8eZAl2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Stereophonics[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1322+"/",
        thumbnail="https://i.imgur.com/23Aez9t.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Steve Miller Band[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_727+"/",
        thumbnail="https://i.imgur.com/xrdpbTI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Stevie Nicks[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_728+"/",
        thumbnail="https://i.imgur.com/Ng3fjbg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Stevie Wonder[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_729+"/",
        thumbnail="https://i.imgur.com/Cfk2w3U.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Steel Panther[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1632+"/",
        thumbnail="https://i.imgur.com/1Z0W66v.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Stil Corners[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1633+"/",
        thumbnail="https://i.imgur.com/hbT8Qgq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Stone Sour[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_522+"/",
        thumbnail="https://i.imgur.com/XoCAgz0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Stoned Jesus[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1634+"/",
        thumbnail="https://i.imgur.com/6yja4bw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Storm Seeker[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1635+"/",
        thumbnail="https://i.imgur.com/OpOxW7F.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Stratovarius[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1636+"/",
        thumbnail="https://i.imgur.com/TKez3ak.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Strauss, Johann[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1416+"/",
        thumbnail="https://i.imgur.com/9LoxkKs.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Strauss, Richard[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1417+"/",
        thumbnail="https://i.imgur.com/MfawrLO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Stravinsky, Igor[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1418+"/",
        thumbnail="https://i.imgur.com/2rffQAR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Stray Cats[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_730+"/",
        thumbnail="https://i.imgur.com/9WfnJXr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Stryper[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1637+"/",
        thumbnail="https://i.imgur.com/LKyVRHy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Styx[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_523+"/",
        thumbnail="https://i.imgur.com/yM5t4z3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sugababes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1731+"/",
        thumbnail="https://i.imgur.com/sWVjaHV.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Supertramp[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_524+"/",
        thumbnail="https://i.imgur.com/ONBHwMG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Suppe, Franz Von[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1419+"/",
        thumbnail="https://i.imgur.com/pzm8IxP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Surfin Bichos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_525+"/",
        thumbnail="https://i.imgur.com/uXZnJte.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Survivor[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_526+"/",
        thumbnail="https://i.imgur.com/JAFDyLo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Suzanne Vega[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_865+"/",
        thumbnail="https://i.imgur.com/TrHVv8l.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Suzi Quatro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1638+"/",
        thumbnail="https://i.imgur.com/TXYiSPZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Sylvester[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1639+"/",
        thumbnail="https://i.imgur.com/TyUs2Fn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]System Of A Donw[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_527+"/",
        thumbnail="https://i.imgur.com/PL99xQK.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]T Rex[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_731+"/",
        thumbnail="https://i.imgur.com/d7CvpBX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Taburete[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_732+"/",
        thumbnail="https://i.imgur.com/JcbJbcA.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tahures Zurdos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1298+"/",
        thumbnail="https://i.imgur.com/q73SHvO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Take That[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_866+"/",
        thumbnail="https://i.imgur.com/j1dGaZH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Talk Talk[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1640+"/",
        thumbnail="https://i.imgur.com/LAyRbrG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Talking Heads[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_528+"/",
        thumbnail="https://i.imgur.com/4EkvQo6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tam Tam Go[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_733+"/",
        thumbnail="https://i.imgur.com/hqzzrB0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tamara[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_734+"/",
        thumbnail="https://i.imgur.com/OIjqeRB.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tanita Tikaram[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1299+"/",
        thumbnail="https://i.imgur.com/HGcmlmq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tatu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_529+"/",
        thumbnail="https://i.imgur.com/RXv6Tww.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Taxi Orquesta[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1641+"/",
        thumbnail="https://i.imgur.com/6Nallrp.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Taylor Dyane[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1642+"/",
        thumbnail="https://i.imgur.com/kYkcmVh.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Taylor Swift[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_867+"/",
        thumbnail="https://i.imgur.com/YSd2DNJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tchaikovsky, Priotr LLich[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1420+"/",
        thumbnail="https://i.imgur.com/N4iIhJT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tears for Fears[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_530+"/",
        thumbnail="https://i.imgur.com/Iu8HP3E.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Technotronic[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1643+"/",
        thumbnail="https://i.imgur.com/hvYv0Zl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ted Nugent[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_531+"/",
        thumbnail="https://i.imgur.com/rx2ktuk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tequila[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_532+"/",
        thumbnail="https://i.imgur.com/FD9Q7uT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Terence Trent Darby[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_869+"/",
        thumbnail="https://i.imgur.com/R2pauxy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Terry Stafford[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1732+"/",
        thumbnail="https://i.imgur.com/MxQ2bQa.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tesla[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_533+"/",
        thumbnail="https://i.imgur.com/SufrR0x.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tete Montoliu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1260+"/",
        thumbnail="https://i.imgur.com/RVsIZj4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Texas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_868+"/",
        thumbnail="https://i.imgur.com/nRDerXE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The 69 Eyes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1644+"/",
        thumbnail="https://i.imgur.com/m3fx8VQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The 1975[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_534+"/",
        thumbnail="https://i.imgur.com/I3hp0PT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Agnes Circle[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1645+"/",
        thumbnail="https://i.imgur.com/w3pCM61.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Amity Affliction[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_535+"/",
        thumbnail="https://i.imgur.com/qBfc4je.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The B 52s[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1646+"/",
        thumbnail="https://i.imgur.com/P7a52P8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Beatles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_115+"/",
        thumbnail="https://i.imgur.com/COHYV3N.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Bangles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_536+"/",
        thumbnail="https://i.imgur.com/8uOV8Ta.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Beach Boys[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_537+"/",
        thumbnail="https://i.imgur.com/NZI2Dg7.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Beatles[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_538+"/",
        thumbnail="https://i.imgur.com/mKAkEBb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Beautiful Faces of Mera Luna[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1647+"/",
        thumbnail="https://i.imgur.com/tFll4Aw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Blasters[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1648+"/",
        thumbnail="https://i.imgur.com/MH6bhu9.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Blue Stones[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1649+"/",
        thumbnail="https://i.imgur.com/teuJsfI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Blues Brothers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_539+"/",
        thumbnail="https://i.imgur.com/J13kfBP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Breeders[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1650+"/",
        thumbnail="https://i.imgur.com/P4eDNhG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Brian Setzer Orchestra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1651+"/",
        thumbnail="https://i.imgur.com/F73iT1a.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Cars[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1323+"/",
        thumbnail="https://i.imgur.com/B5yzmdx.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Chantels[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1261+"/",
        thumbnail="https://i.imgur.com/qAH9jKP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Chordettes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1262+"/",
        thumbnail="https://i.imgur.com/K1aopNZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Clash[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_540+"/",
        thumbnail="https://i.imgur.com/GBKN0V4.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Coasters[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1263+"/",
        thumbnail="https://i.imgur.com/kQLyUOQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Communards[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_541+"/",
        thumbnail="https://i.imgur.com/u7wicNW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Corrs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_542+"/",
        thumbnail="https://i.imgur.com/A4xpuPI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Cramps[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1652+"/",
        thumbnail="https://i.imgur.com/mLLISEZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Cranberries[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_543+"/",
        thumbnail="https://i.imgur.com/d3h1HC8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Crickets[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1264+"/",
        thumbnail="https://i.imgur.com/zfScTMo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Cult[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_544+"/",
        thumbnail="https://i.imgur.com/YYthigE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Cure[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_545+"/",
        thumbnail="https://i.imgur.com/dchTOn9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Dandy Warhols[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1653+"/",
        thumbnail="https://i.imgur.com/LoQCn3h.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Dark Element[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1654+"/",
        thumbnail="https://i.imgur.com/ntyYzB0.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Dead Daisies[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1655+"/",
        thumbnail="https://i.imgur.com/ziHWw2x.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Dead South[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1656+"/",
        thumbnail="https://i.imgur.com/r5AxuqE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Devils Daugthers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1657+"/",
        thumbnail="https://i.imgur.com/SycMoYf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Distillers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1658+"/",
        thumbnail="https://i.imgur.com/iIJuhya.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Donnas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1659+"/",
        thumbnail="https://i.imgur.com/bqsarib.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Doobie Brothers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1660+"/",
        thumbnail="https://i.imgur.com/UiVb0G9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Doors[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_546+"/",
        thumbnail="https://i.imgur.com/JiN0XwC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Drifters[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1265+"/",
        thumbnail="https://i.imgur.com/tKFaHTc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Edsels[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1266+"/",
        thumbnail="https://i.imgur.com/cL216K6.jpghttps://i.imgur.com/cL216K6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Greg Kihn Band[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1661+"/",
        thumbnail="https://i.imgur.com/9dO9grF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Hillbilly Moon Explosion[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1662+"/",
        thumbnail="https://i.imgur.com/oocl09K.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Hives[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1663+"/",
        thumbnail="https://i.imgur.com/yX7oPKj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Hu[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1664+"/",
        thumbnail="https://i.imgur.com/cF8JImb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Human League[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1324+"/",
        thumbnail="https://i.imgur.com/539OiLS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Imterrupters[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1665+"/",
        thumbnail="https://i.imgur.com/liSdf21.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Jesus And Mary Chain[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1666+"/",
        thumbnail="https://i.imgur.com/Kdx2Kqd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Jets[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1290+"/",
        thumbnail="https://i.imgur.com/JAWm6ZU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Killers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_547+"/",
        thumbnail="https://i.imgur.com/rCY1r4m.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Kinks[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1667+"/",
        thumbnail="https://i.imgur.com/0BJRHCz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Knack[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_548+"/",
        thumbnail="https://i.imgur.com/LiALYbz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Lazys[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1668+"/",
        thumbnail="https://i.imgur.com/nSyVlrC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Marmalade[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1669+"/",
        thumbnail="https://i.imgur.com/TO04NHL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Meteors[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1670+"/",
        thumbnail="https://i.imgur.com/ez5TbQw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Muffs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1671+"/",
        thumbnail="https://i.imgur.com/72TW0Or.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Offspring[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1733+"/",
        thumbnail="https://i.imgur.com/8ipjhDO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Police[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_549+"/",
        thumbnail="https://i.imgur.com/6vx1Qfk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Pretenders[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_550+"/",
        thumbnail="https://i.imgur.com/coPP3t5.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Pretty Reckless[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_551+"/",
        thumbnail="https://i.imgur.com/C25i7qe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Raconteurs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1672+"/",
        thumbnail="https://i.imgur.com/NWPK757.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Rasmus[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_552+"/",
        thumbnail="https://i.imgur.com/FDQ2i8n.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Rattlesnakes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1267+"/",
        thumbnail="https://i.imgur.com/mqZz6gq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Regrettes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1673+"/",
        thumbnail="https://i.imgur.com/7HRNCSI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Reverend Peytons Big Damn Band[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1674+"/",
        thumbnail="https://i.imgur.com/bUIVuKs.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Runaways[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1675+"/",
        thumbnail="https://i.imgur.com/1f09Ucw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Sisters of Mercy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1676+"/",
        thumbnail="https://i.imgur.com/AYaFDY6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Stone Rose[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1300+"/",
        thumbnail="https://i.imgur.com/21SPfX2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Supremes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1044+"/",
        thumbnail="https://i.imgur.com/eiyCOZ2.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Sweet[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1297+"/",
        thumbnail="https://i.imgur.com/dLXqoel.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The The[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1677+"/",
        thumbnail="https://i.imgur.com/WT2Hokq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Ting Tings[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1678+"/",
        thumbnail="https://i.imgur.com/obiWjKm.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Troggs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1679+"/",
        thumbnail="https://i.imgur.com/Z0i4bh3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Vamps[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_553+"/",
        thumbnail="https://i.imgur.com/LJTAo6F.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Velvet Underground[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_554+"/",
        thumbnail="https://i.imgur.com/BBQLGfl.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Wanted[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_555+"/",
        thumbnail="https://i.imgur.com/I0Jh3Dk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Waterboys[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_556+"/",
        thumbnail="https://i.imgur.com/O3fmTlO.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Weenknd[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1325+"/",
        thumbnail="https://i.imgur.com/GbgOBVe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The White Buffalo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1710+"/",
        thumbnail="https://i.imgur.com/v8ICs6S.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Winery Dogs[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1680+"/",
        thumbnail="https://i.imgur.com/htmFk71.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]The Who[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_557+"/",
        thumbnail="https://i.imgur.com/iZ8VRVq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Them Evils[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1681+"/",
        thumbnail="https://i.imgur.com/MFQvIox.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Theory Of A Deadman[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_558+"/",
        thumbnail="https://i.imgur.com/RB6giew.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Thin Lizzy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_559+"/",
        thumbnail="https://i.imgur.com/Z2T0cnF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Thirty Secons To Mars[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_560+"/",
        thumbnail="https://i.imgur.com/V4FCyVT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Three Days Grace[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_561+"/",
        thumbnail="https://i.imgur.com/E6bLZVR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Thunderpussy[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1682+"/",
        thumbnail="https://i.imgur.com/ljM1iLX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tick Tick.....Boom[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1683+"/",
        thumbnail="https://i.imgur.com/8ROS6UW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tierra Santa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_562+"/",
        thumbnail="https://i.imgur.com/jPZ3l0A.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tiffany Young[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1684+"/",
        thumbnail="https://i.imgur.com/N75QPTq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tijeritas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1035+"/",
        thumbnail="https://i.imgur.com/MquVHJe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tina Turner[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_563+"/",
        thumbnail="https://i.imgur.com/eEOZy6A.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tino Casal[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_564+"/",
        thumbnail="https://i.imgur.com/v72tyGC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tizziano Ferro[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1080+"/",
        thumbnail="https://i.imgur.com/RehehO6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tokio Hotel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_565+"/",
        thumbnail="https://i.imgur.com/0HL8rtG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tom Jones[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_566+"/",
        thumbnail="https://i.imgur.com/WqzDj8G.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tom Stormy Trio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1685+"/",
        thumbnail="https://i.imgur.com/c232F66.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tomas De Antequera[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1268+"/",
        thumbnail="https://i.imgur.com/JhmrfCn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tomas Pavon[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1269+"/",
        thumbnail="https://i.imgur.com/QEMLwpN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tones And I[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1686+"/",
        thumbnail="https://i.imgur.com/g3U3ghc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Toni Basil[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1687+"/",
        thumbnail="https://i.imgur.com/dPKNDdp.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Toni Braxton[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_567+"/",
        thumbnail="https://i.imgur.com/Meq8hUg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tony Bennett[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1270+"/",
        thumbnail="https://i.imgur.com/P19ziVU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tony Ronald[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1045+"/",
        thumbnail="https://i.imgur.com/FlxjcFb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tools[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_568+"/",
        thumbnail="https://i.imgur.com/L1o0Jeq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Toto[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_569+"/",
        thumbnail="https://i.imgur.com/1KBF8nk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Toy Dolls[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_570+"/",
        thumbnail="https://i.imgur.com/KMUsbRE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tracy Chapman[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_571+"/",
        thumbnail="https://i.imgur.com/lLSOfbr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Tracy Spencer[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1688+"/",
        thumbnail="https://i.imgur.com/yzzeHlJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Train[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_572+"/",
        thumbnail="https://i.imgur.com/4KoWWcL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Trans-X[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1689+"/",
        thumbnail="https://i.imgur.com/IGPosa3.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Triana[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_573+"/",
        thumbnail="https://i.imgur.com/xiX5xPj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Triana Pura[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1271+"/",
        thumbnail="https://i.imgur.com/NHhOaIq.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Trigo Limpio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1272+"/",
        thumbnail="https://i.imgur.com/UiuFF2h.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Trivium[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_574+"/",
        thumbnail="https://i.imgur.com/7Inpzxr.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Truckfigthers[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1690+"/",
        thumbnail="https://i.imgur.com/TPbpZgG.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Trueno[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_870+"/",
        thumbnail="https://i.imgur.com/tSPP0Tf.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Twelve Titans Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1691+"/",
        thumbnail="https://i.imgur.com/yVmtY1N.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Twisted Sister[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_575+"/",
        thumbnail="https://i.imgur.com/IhEIBzt.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Two Steps From Hell[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1692+"/",
        thumbnail="https://i.imgur.com/rSNioqe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Two Tone Sessions[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1693+"/",
        thumbnail="https://i.imgur.com/MRowjmP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]U2[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_576+"/",
        thumbnail="https://i.imgur.com/7KYOa3l.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ub40[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_577+"/",
        thumbnail="https://i.imgur.com/L60wAvH.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ufo[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_578+"/",
        thumbnail="https://i.imgur.com/VpfelZy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ugly Kid Joe[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_579+"/",
        thumbnail="https://i.imgur.com/2lrw8l6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ultrajala[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_871+"/",
        thumbnail="https://i.imgur.com/PLK2eqj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ultraspank[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_580+"/",
        thumbnail="https://i.imgur.com/85umw6M.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ultravox[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_581+"/",
        thumbnail="https://i.imgur.com/oI8veeE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Umberto Tozzi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_582+"/",
        thumbnail="https://i.imgur.com/jiAqpt1.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Undisputed Truth[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_583+"/",
        thumbnail="https://i.imgur.com/mIs783b.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Unknown Mortal Orchestra[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_584+"/",
        thumbnail="https://i.imgur.com/0crPiFM.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Urge Overkill[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_585+"/",
        thumbnail="https://i.imgur.com/mnUvDwr.jpghttps://i.imgur.com/4F2dJEW.jpg",
		fanart="https://i.imgur.com/CGRFk7P.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Uriah Heep[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_586+"/",
        thumbnail="https://i.imgur.com/sNMNgOT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Usher[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_587+"/",
        thumbnail="https://i.imgur.com/GPSjbJ8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Valerie Dore[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1694+"/",
        thumbnail="https://i.imgur.com/dqRat1W.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Van Halen[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_588+"/",
        thumbnail="https://i.imgur.com/H6QEg7d.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Vanesa Martin[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_735+"/",
        thumbnail="https://i.imgur.com/5uXg1SX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Vanessa Mae[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_736+"/",
        thumbnail="https://i.imgur.com/BoddAxf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Vanessa Williams[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1695+"/",
        thumbnail="https://i.imgur.com/j8zFKVT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Vangelis[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_872+"/",
        thumbnail="https://i.imgur.com/Yswt2nJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Verdi, Giuseppe[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1421+"/",
        thumbnail="https://i.imgur.com/Rg3ylMZ.png",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Veruca Salt[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1696+"/",
        thumbnail="https://i.imgur.com/WUUIA5d.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Vetusta Morla[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_589+"/",
        thumbnail="https://i.imgur.com/hDXmBgn.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Viceversa[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1697+"/",
        thumbnail="https://i.imgur.com/92PI1PQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Victor Jara[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1273+"/",
        thumbnail="https://i.imgur.com/CJJqB8N.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Victor Manuel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_737+"/",
        thumbnail="https://i.imgur.com/PfYCWND.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Village People[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_590+"/",
        thumbnail="https://i.imgur.com/RMpmwUW.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Violadores Del Verso[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_738+"/",
        thumbnail="https://i.imgur.com/jENsWtc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Vitalic[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1698+"/",
        thumbnail="https://i.imgur.com/oZymZcS.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Vivaldi, Antonio[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1422+"/",
        thumbnail="https://i.imgur.com/TzzMcGc.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Volbeat[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_591+"/",
        thumbnail="https://i.imgur.com/gFV1pGk.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Volturian[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1699+"/",
        thumbnail="https://i.imgur.com/9q85Hn6.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Vonda Shepard[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_873+"/",
        thumbnail="https://i.imgur.com/pGS5zey.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Wafia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1274+"/",
        thumbnail="https://i.imgur.com/duGujwF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Wagner, Richard[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1423+"/",
        thumbnail="https://i.imgur.com/dHlixaL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )			

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Walk In Darkness[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1700+"/",
        thumbnail="https://i.imgur.com/MHcobmJ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Warcry[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_592+"/",
        thumbnail="https://i.imgur.com/UhhQviP.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Warrant[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_593+"/",
        thumbnail="https://i.imgur.com/TE5gOhQ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Wasp[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_594+"/",
        thumbnail="https://i.imgur.com/cmRhLu8.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Westlife[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_595+"/",
        thumbnail="https://i.imgur.com/EN0aNMe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Wham[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_739+"/",
        thumbnail="https://i.imgur.com/HM0WAIy.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Wheatus[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1734+"/",
        thumbnail="https://i.imgur.com/ClJlsxR.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Whisbone Ash[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_596+"/",
        thumbnail="https://i.imgur.com/AeWzNY9.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]White Lion[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1701+"/",
        thumbnail="https://i.imgur.com/9P7J8qf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]White Snake[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_597+"/",
        thumbnail="https://i.imgur.com/PgpiBOg.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Whitney Houston[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_598+"/",
        thumbnail="https://i.imgur.com/hzNu2jw.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Wilco[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_875+"/",
        thumbnail="https://i.imgur.com/MpS9yaC.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Willy De Ville[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_876+"/",
        thumbnail="https://i.imgur.com/t91jFEo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Willy Nelson[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_750+"/",
        thumbnail="https://i.imgur.com/AW131uj.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Wilson Phillips[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1735+"/",
        thumbnail="https://i.imgur.com/0FC57PD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Wilson Pickett[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_877+"/",
        thumbnail="https://i.imgur.com/JdkQx76.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Within Templation[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_599+"/",
        thumbnail="https://i.imgur.com/OyirEeb.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Wolf Alice[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_874+"/",
        thumbnail="https://i.imgur.com/5SktwjE.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Wos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_878+"/",
        thumbnail="https://i.imgur.com/XaUmFXT.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Xabier Lete[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1276+"/",
        thumbnail="https://i.imgur.com/HzNxIDF.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Xandria[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1702+"/",
        thumbnail="https://i.imgur.com/9DYSAdU.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Xavier Cugat[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1275+"/",
        thumbnail="https://i.imgur.com/PuzhRfe.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Xesco Boix[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1277+"/",
        thumbnail="https://i.imgur.com/MTS15ul.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Xose Manuel Budiño[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1278+"/",
        thumbnail="https://i.imgur.com/BTHrLsi.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Xperiment[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1703+"/",
        thumbnail="https://i.imgur.com/eQQEtuX.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Yael Naim[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_879+"/",
        thumbnail="https://i.imgur.com/G3sP82u.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Yvonne Elliman[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1048+"/",
        thumbnail="https://i.imgur.com/HQWhIJZ.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Zahara[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1036+"/",
        thumbnail="https://i.imgur.com/4nK5Y0O.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )			

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Zak Abel[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_600+"/",
        thumbnail="https://i.imgur.com/olprY2m.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Zanias[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1704+"/",
        thumbnail="https://i.imgur.com/FLR7usp.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Zapato Veloz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1050+"/",
        thumbnail="https://i.imgur.com/ddbtDAz.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )			

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Zara Larsson[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_601+"/",
        thumbnail="https://i.imgur.com/ShTWD6B.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Zardonic[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1279+"/",
        thumbnail="https://i.imgur.com/XmlhWDo.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Zasko[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_880+"/",
        thumbnail="https://i.imgur.com/m5Ci1cN.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Zaz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1280+"/",
        thumbnail="https://i.imgur.com/sKODDvD.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ziggy Alberts[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1281+"/",
        thumbnail="https://i.imgur.com/Gc7BmLI.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Ziggy Marley[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1282+"/",
        thumbnail="https://i.imgur.com/g1KmFLL.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Zion And Lennox[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_602+"/",
        thumbnail="https://i.imgur.com/vpbinJd.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Zoe[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_603+"/",
        thumbnail="https://i.imgur.com/FbQ6cEv.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Zona Ganjah[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_1705+"/",
        thumbnail="https://i.imgur.com/9EQNvno.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Zucchero[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_770+"/",
        thumbnail="https://i.imgur.com/7yH1RRf.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Zz Top[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_playlist_ID_604+"/",
        thumbnail="https://i.imgur.com/ce2Yy2a.jpg",
		fanart="https://i.imgur.com/yr7txZt.jpg",
        folder=True )		
		
run()