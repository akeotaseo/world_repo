﻿import xbmc

def videosettings():
    xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin("ActivateWindowAndFocus(PlayerSettings)")
    xbmc.executebuiltin("Action(Pause)")
    while xbmc.getCondVisibility("Window.IsVisible(PlayerSettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")

videosettings()
