# -*- coding: utf-8 -*-

import requests
from lib import scrapers, utils, logger

api = "https://platform.wim.tv/wimtv-server"
headers = {
    "User-Agent": utils.USER_AGENT,
    "Content-Type": "application/json",
    "Referer": "https://platform.wim.tv/",
    "X-Requested-With": "XMLHttpRequest",
}
session = requests.Session()
session.headers.update(headers)


def play(search):
    res = dict()

    if search == "extra":
        pageUrl = "https://mschannel.tv/extra"
    elif search == "acisport":
        pageUrl = "https://www.acisport.it/aci_sport_tv.htm"
    else:
        pageUrl = "https://{}.tv".format(search)

    data = session.get(pageUrl).text

    match = scrapers.find_single_match(data, r'iframe.*?src\s*="[^\?]+\?(\w+)=([^&]+)')

    if match:
        channelType, channelId = match
        logger.debug("channelType:", channelType, "channelId:", channelId)

        query = {"grant_type": "client_credentials"}
        token = (session.post("{}/oauth/token".format(api),auth=requests.auth.HTTPBasicAuth("www", ""),params=query,).json().get("access_token", ""))

        session.headers.update({"Authorization": "Bearer {}".format(token),"Origin": "https://platform.wim.tv",})
        _json = (session.post("{}/api/public/{}/channel/{}/play".format(api, channelType, channelId),json={},).json().get("srcs", []))

        try:
            hls_stream = next(iter(filter(lambda item: (item["mimeType"] == "application/x-mpegurl"),_json,)))
            res["url"] = hls_stream["uniqueStreamer"]
        except (StopIteration, KeyError):
            logger.error("Something is changed on broadcaster side")

    return res
