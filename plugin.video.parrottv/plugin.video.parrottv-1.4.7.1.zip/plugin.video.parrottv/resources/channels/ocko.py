# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

class Ocko:
    def __init__(self):
        self.ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36'
        self.channels = {
            'ocko': 'https://ocko-live.ssl.cdn.cra.cz/channels/ocko/playlist.m3u8',
            'expres': 'https://ocko-live.ssl.cdn.cra.cz/channels/ocko_expres/playlist.m3u8',
            'star': 'https://ocko-live.ssl.cdn.cra.cz/channels/ocko_gold/playlist.m3u8'
        }

    def grab(self, channel):
        headers = {'User-Agent': self.ua}
        hlsurl = self.channels[channel]
        return hlsurl, headers