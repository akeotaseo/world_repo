# -*- coding: utf-8 -*-
import os
import sys

try:
    from urllib.parse import urlparse, urlencode
    from urllib.request import urlopen, Request
    from urllib.error import HTTPError
except ImportError:
    from urlparse import urlparse
    from urllib import urlencode
    from urllib2 import urlopen, Request, HTTPError


import re
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import xbmcplugin
import plugintools
import unicodedata
import base64
import requests
import shutil
import base64
import time
import six
import random
from datetime import date
from datetime import datetime
try:
    from resolveurl.lib import jsunpack 
except ImportError:
    from resolveurl.plugins.lib import jsunpack 
from resources.modules import control

if six.PY3:
    unicode = str
#PY3=False
#if sys.version_info[0] >= 3: PY3 = True; unicode = str; unichr = chr; long = int
addon = xbmcaddon.Addon()
addonname = '[LOWERCASE][CAPITALIZE][COLOR orange]Mac[COLOR orange]VOD[/CAPITALIZE][/LOWERCASE][/COLOR]'
icon = addon.getAddonInfo('icon')
myaddon = xbmcaddon.Addon("plugin.video.edemro")

## Fotos
thmb_nada='https://archive.org/download/bee-1/pngegg%20%281%29.png'
fanny="https://i.ytimg.com/vi/_7bFXWNfXTY/maxresdefault.jpg"
fanart_guia="http://www.panoramaaudiovisual.com/wp-content/uploads/2012/01/EPG-Toshiba-Smart-Tv-web.png"
backgr="https://freeiptvstb.com/wp-content/uploads/2021/06/UZ4VHKEdhTkviRzJSEfFZC.jpg"
thmb_ver_m3u='https://archive.org/download/bee-1/live-iptv.png'
thmb_ver_canales='https://archive.org/download/bee-1/channels%20live.png'

f4mproxy = control.setting("f4mproxy")
setting = xbmcaddon.Addon().getSetting

mislogos = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.video.macvod/jpg/'))
logo_transparente = xbmcvfs.translatePath(os.path.join(mislogos , 'transparente.png'))

def keyboard_input(default_text="", title="", hidden=False):

    keyboard = xbmc.Keyboard(default_text,title,hidden)
    keyboard.doModal()
    
    if (keyboard.isConfirmed()):
        tecleado = keyboard.getText()
    else:
        tecleado = ""

    return tecleado

   
def run():
    
    plugintools.log("---> macvod.run <---")
    #plugintools.set_view(plugintools.LIST)
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
       action = params.get("action")
       url = params.get("url")
       exec(action+"(params)")
    plugintools.close_item_list()

def main_list(params):
    proxy=params.get('extra')
    import shutil,xbmc  
    try:
        addon_path3 = xbmcvfs.translatePath('special://home/cache').decode('utf-8')
        shutil.rmtree(addon_path3, ignore_errors=True) 
    except:
        pass
        
    plugintools.log("macvod.main_list ")    
    params['thumbnail']=thmb_ver_canales
    params['fanart']="https://i.ytimg.com/vi/_7bFXWNfXTY/maxresdefault.jpg"

    edem = control.setting("edem")
    if edem=="":
        edemkey = edemkeyen()
        control.setSetting('edem',edemkey)
        if setting('edemworld') == "0":
        	edemm(params)
        else:
        	edemro(params)
        xbmc.executebuiltin('Container.Refresh')
    else:
        if setting('edemworld') == "0":
        	edemm(params)
        else:
        	edemro(params)
        
def edemkeyen():
    kb = xbmc.Keyboard('default', 'heading', True)
    kb.setHeading('EDEM KEY')
    kb.setDefault('GM676ZPU74CU7Q')
    kb.setHiddenInput(False)
    kb.doModal()
    if kb.isConfirmed():
        text = kb.getText()
        return text
    else:
        return False

def edemm(params): 
    plugintools.log("macvod.edem")
    thumbnail = 'https://archive.org/download/bee-1/romanian.png'
    url = 'http://tvshare.xyz/settings_iptv/DownloadCountry2.php'
    
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body,response_headers = plugintools.read_body_and_headers( url, headers=request_headers)
    url = body.strip().decode('utf-8')
    matches = plugintools.find_multiple_matches(url,'(?s)(<a href="DownloadCountry2\.php\?login\=\&group_title\=.*?">.*?</a>,)')
    for generos in matches:

        url=plugintools.find_single_match(generos,'(?s)<a href="DownloadCountry2\.php\?login\=\&group_title\=.*?">(.*?)</a>,')
        url=url.replace('\u0103','a')
        titulo=plugintools.find_single_match(generos,'(?s)<a href="DownloadCountry2\.php\?login\=\&group_title\=.*?">(.*?)</a>,')
        titulo=titulo.replace('azərbaycan','Azerbaijan').replace('беларускія','Belarusian').replace('взрослые','adults').replace('детские','child').replace('другие','other').replace('кино','movie').replace('қазақстан','kazakhstan').replace('музыка','music').replace('познавательные','educational').replace('развлекательные','entertaining').replace('спорт','sport').replace('точик','point').replace('українські','Ukrainian').replace('ქართული','Georgian').replace('Հայկական','Armenian')
        plugintools . add_item ( action = "edem2" , title = "[LOWERCASE][CAPITALIZE] [COLOR orange]"+titulo+"[/CAPITALIZE][/LOWERCASE][/COLOR]", url = url, thumbnail =  thumbnail , fanart=thumbnail, folder=True )
 
def edem2(params): 
    plugintools.log("macvod.edem2")
    thumbnail = params.get("thumbnail")    
    edem = control.setting("edem")
    url2 = params.get("url")
    url3 = "http://tvshare.xyz/settings_iptv/get_Server2.php?login="+edem+"&server=2&group="+url2
 
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body,response_headers = plugintools.read_body_and_headers( url3, headers=request_headers)
    url = body.strip().decode('utf-8')

    matches = plugintools.find_multiple_matches(url,'(#EXTINF:.+?,.*?[\n\r]+.+?\/\d+/)')
    for generos in matches:  
        patron=plugintools.find_single_match(generos,'(?s)#EXTINF:.+?,(.*?)[\n\r]+.+?\/(\d+/)')    
        url=patron[1]
        url="http://tvshare.ottrast.com/iptv/"+edem+"/"+url+"/index.m3u8"
        titulo=patron[0]     
        plugintools . add_item ( action = "inpstr" , title = "[LOWERCASE][CAPITALIZE] [COLOR orange]"+titulo+"[/CAPITALIZE][/LOWERCASE][/COLOR]", url = url, thumbnail =  thumbnail , fanart=thumbnail, folder=False,  isPlayable = True )

def edemro(params): 
    plugintools.log("macvod.edem2")
    thumbnail = params.get("thumbnail")    
    edem = control.setting("edem")
    edemunu = control.setting("edem1")
    url3 = "http://tvshare.xyz/settings_iptv/DownloadCountry2.php?login=&group_title=Romania"
 
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body,response_headers = plugintools.read_body_and_headers( url3, headers=request_headers)
    url = body.strip().decode('utf-8')

    matches = plugintools.find_multiple_matches(url,'(<td valign="top">  <font color="#FF6600"><b>.*?</b></font> \(\,\d+\))')
    for generos in matches:  
        patron=plugintools.find_single_match(generos,'<td valign="top">  <font color="#FF6600"><b>(.*?)</b></font> \(\,(\d+)\)')    
        url=patron[1]
        edemid=url
        url="http://tvshare.ottrast.com/iptv/"+edem+"/"+url+"/index.m3u8"
        titulo=patron[0]     
        if not edemunu:
        	plugintools . add_item ( action = "inpstr" , title = "[LOWERCASE][CAPITALIZE] [COLOR orange]"+titulo+"[/CAPITALIZE][/LOWERCASE][/COLOR]", url = url, thumbnail =  thumbnail , fanart=thumbnail, folder=False,  isPlayable = True )
        else:
        	plugintools . add_item ( action = "edem5" , title = "[LOWERCASE][CAPITALIZE] [COLOR orange]"+titulo+"[/CAPITALIZE][/LOWERCASE][/COLOR]", url = edemid, thumbnail =  thumbnail , fanart=thumbnail, folder=True )

def edem5(params): 
    plugintools.log("macvod.edem5")
    imagine = params.get("thumbnail")
    thumbnail=imagine
    titulo = params.get("title") 
    if setting('edem'):
    	edem = control.setting("edem")
    	url=params.get("url")
    	url="http://tvshare.ottrast.com/iptv/"+edem+"/"+url+"/index.m3u8"
    	plugintools . add_item ( action = "inpstr" , title = titulo+" Link1", url = url, thumbnail =  imagine , fanart=thumbnail, folder=False,  isPlayable = True )
    if setting('edem1'):
    	edem = control.setting("edem1")
    	url=params.get("url")
    	url="http://tvshare.ottrast.com/iptv/"+edem+"/"+url+"/index.m3u8"
    	plugintools . add_item ( action = "inpstr" , title = titulo+" Link2", url = url, thumbnail =  imagine , fanart=thumbnail, folder=False,  isPlayable = True )
    if setting('edem2'):
    	edem = control.setting("edem2")
    	url=params.get("url")
    	url="http://tvshare.ottrast.com/iptv/"+edem+"/"+url+"/index.m3u8"
    	plugintools . add_item ( action = "inpstr" , title = titulo+" Link3", url = url, thumbnail =  imagine , fanart=thumbnail, folder=False,  isPlayable = True )
    if setting('edem3'):
    	edem = control.setting("edem3")
    	url=params.get("url")
    	url="http://tvshare.ottrast.com/iptv/"+edem+"/"+url+"/index.m3u8"
    	plugintools . add_item ( action = "inpstr" , title = titulo+" Link4", url = url, thumbnail =  imagine , fanart=thumbnail, folder=False,  isPlayable = True )
    if setting('edem4'):
    	edem = control.setting("edem4")
    	url=params.get("url")
    	url="http://tvshare.ottrast.com/iptv/"+edem+"/"+url+"/index.m3u8"
    	plugintools . add_item ( action = "inpstr" , title = titulo+" Link5", url = url, thumbnail =  imagine , fanart=thumbnail, folder=False,  isPlayable = True )
    else:
        pass

def inpstr(params):
    plugin = xbmcvfs.translatePath('special://home/addons/inputstream.ffmpegdirect')
    if os.path.exists(plugin)==False:
        try:
            xbmc.executebuiltin('InstallAddon(inputstream.ffmpegdirect)', wait=True)
        except:
            pass
    url = params.get("url")
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    name = params.get("title")
    iconimage = params.get("thumbnail") 
    liz = xbmcgui.ListItem(name)
    liz.setArt({'thumb': iconimage, 'icon': iconimage})
    liz.setInfo(type='Video', infoLabels={'Title': name, 'mediatype': 'video'})
    liz.setProperty("IsPlayable", "true")
    liz.setProperty('inputstream', 'inputstream.adaptive')
    liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
    liz.setMimeType('application/vnd.apple.mpegstream_url')
    liz.setContentLookup(False)
    liz.setPath(url)
    xbmc.Player().play(url)   
    

def edemf4m(params):
    url = params.get("url")  
    finalurl=url
    finalurl = "plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name={}&amp;iconImage={}&amp;url={}".format(params.get('title'),params.get('thumbnail'),finalurl) 
    builtin = 'RunPlugin(%s)' %finalurl 
    xbmc.executebuiltin(builtin)

run()