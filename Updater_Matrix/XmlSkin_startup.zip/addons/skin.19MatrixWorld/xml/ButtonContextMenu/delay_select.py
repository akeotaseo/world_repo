﻿import xbmc, xbmcgui
xbmc.sleep(250) # Περιμένει να εμφανιστεί το μενού της εικόνας
xbmc.executebuiltin('Action(Select)') # Πατάει αυτόματα την "Αναπαραγωγή..."
xbmc.sleep(250)
xbmcgui.Dialog().notification("[COLOR white]TMDb Helper[/COLOR]", "[B][COLOR orange]Επιλέξτε Player[/COLOR][/B]", sound=True, icon='special://home/addons/skin.19MatrixWorld/media/player.png')

