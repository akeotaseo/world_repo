from urllib.parse import urlencode, parse_qsl, unquote, quote_plus, urlparse, urljoin
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from html import unescape
from xbmc import executebuiltin
from pickle import load, dump
from xbmcvfs import translatePath
from xbmcgui import ListItem, Dialog, INPUT_ALPHANUM
from requests import Session
from sys import argv
import re, sys, os
addon_url = argv[0]
HANDLE = int(argv[1])
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
UA = 'Mozilla/5.0 (SMART-TV; LINUX; Tizen 9.0) AppleWebKit/537.36 (KHTML, like Gecko) 120.0.6099.5/9.0 TV Safari/537.36'
avdb = 'https://avdbapi.com'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
def addDir(title=None, img=None, plot=None, search_key=None, mode=None, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = ListItem(label=f'{title}')
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img, 'fanart': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(f'{title}')
    info_tag.setPlot(f'{plot}')
    setContent(HANDLE, 'videos')
    if search_key is not None:
        list_item.addContextMenuItems([('Xóa khỏi lịch sử', f'RunPlugin({addon_url}?mode=remove&key={search_key})')])
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref):
    with Session() as s:
        s.headers.update({'user-agent': UA,'referer': ref.encode('utf-8')})
        try:
            r = s.get(url, timeout=20)
        except:
            r = s.get(url, timeout=20, verify=False)
    r.encoding = 'utf-8'
    return r
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}'
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def search_history_clear():
    write_file('historys.pkl', [])
    executebuiltin('Container.Refresh()')
def remove_search_history(search_key):
    content = read_file('historys.pkl') or []
    if search_key in content:
        content.remove(search_key)
        write_file('historys.pkl', content)
    executebuiltin('Container.Refresh()')
def main():
    addDir('Tìm kiếm', searchimg, 'Tìm kiếm', None, 'timkiem')
    T = {
    'Phim mới': f'{avdb}/api.php/provide/vod/?ac=detail',
    'Censored': f'{avdb}/api.php/provide/vod/?ac=detail&t=1',
    'Uncensored': f'{avdb}/api.php/provide/vod/?ac=detail&t=2',
    'Uncensored Leaked': f'{avdb}/api.php/provide/vod/?ac=detail&t=9',
    'Chinese AV': f'{avdb}/api.php/provide/vod/?ac=detail&t=10'}
    for k in T:
        addDir(k, ICON, k, None, 'ds_avdb', url = T[k], p=1)
    endOfDirectory(HANDLE)
def find():
    addDir('Tìm kiếm', searchimg, 'Tìm kiếm', None, 'search')
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, ICON, m, search_key = m, mode = 'tim_avdb', key = m, p=1)
        addDir('Xóa lịch sử', searchimg, 'Xóa lịch sử', None, 'removeall', is_folder=False)
    endOfDirectory(HANDLE)
def timkiem(query, p):
    sr = quote_plus(query)
    url = f'{avdb}/api.php/provide/vod?ac=detail&wd={sr}'
    ds_avdb(url, p)
def ds_avdb(url, p):
    n = f'{url}&pg={p}' if '?' in url else f'{url}?pg={p}'
    resp = getlink(n, n)
    data = resp.json()['list']
    for item in data:
        name = unescape(item['name'])
        poster_url = item['poster_url']
        description = unescape(item['description'])
        for episode in [item['episodes']]:
            server_name = episode['server_name']
            for data_key in episode['server_data']:
                if 'link_embed' in episode['server_data'][data_key]:
                    slug = episode['server_data'][data_key]['slug']
                    linkplay = episode['server_data'][data_key]['link_embed']
                    tenphim = f"[COLOR yellow]{slug}[/COLOR] [COLOR red]{server_name}[/COLOR] {name}"
                    addDir(tenphim, poster_url, description, None, 'play_vn', linkplay = linkplay, is_folder=False)
    if p < resp.json()['pagecount']:
        nextp = f'{p + 1}'
        addDir(f'Trang {nextp}', nextimg, f'Trang {nextp}', None, 'ds_avdb', url = url, p=nextp)
    endOfDirectory(HANDLE)
def play_vn(url):
    r = getlink(url, url).text
    ref = referer(url)
    mplay = re.search(r'(?s)playerInstance\.setup.*?(["\'])(.*?)\1', r)[2]
    linkplay = urljoin(ref, mplay)
    linkplay = re.sub(r'\s+', '%20', linkplay.strip(), flags=re.UNICODE)
    hdr = f'verifypeer=false&User-Agent={unquote(UA)}&Referer={ref}/'
    play_item = ListItem(offscreen=True, path=linkplay)
    play_item.setProperty('inputstream', 'inputstream.adaptive')
    play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
    play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def search():
    query = Dialog().input(u'Tìm: tên phim ...', type=INPUT_ALPHANUM)
    if query:
        search_history_save(query)
        timkiem(query, 1)
    else:
        find()
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'ds_avdb': partial(ds_avdb, params.get('url'), int(params.get('p', 1))),
        'search': search,
        'timkiem': find,
        'tim_avdb': partial(timkiem, params.get('key'), int(params.get('p', 1))),
        'play_vn': partial(play_vn, params.get('linkplay')),
        'remove': partial(remove_search_history, params.get('key')),
        'removeall': search_history_clear,
    }
    action_map.get(params.get('mode'), main)()
try:
    router(argv[2][1:])
except:
    pass