import sys
import requests
import xbmcplugin
import xbmcaddon
import xbmcgui
import xbmc
import re
import time
import hashlib
import urllib.parse

# Inițializăm addon-ul pentru a accesa setările
addon = xbmcaddon.Addon()

# Verificăm dacă rulăm pe Android
is_android = xbmc.getCondVisibility('System.Platform.Android')

# Funcția pentru a extrage lista de categorii folosind regex
def extract_categories():
    url = 'https://emisiuni.live/categorii/'
    headers = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Referer': 'https://emisiuni.live/',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    }

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
    except requests.exceptions.RequestException:
        return []

    response_text = response.text

    # Extragem categoriile din HTML folosind regex
    categories = []
    regex_pattern = r'<li .*?class="menu-item.*?"><a href="(https://emisiuni\.live/categorie/.*?)".*?>(.*?)</a>'
    matches = re.findall(regex_pattern, response_text)

    for match in matches:
        link, title = match
        categories.append({'title': title.strip(), 'link': link.strip()})

    # Adăugăm categoria suplimentară "Toate"
    categories.insert(0, {'title': 'Toate', 'link': 'ALL_CATEGORIES'})

    return categories

def extract_all_channels():
    url = 'https://emisiuni.live/canale-tv-1/'
    headers = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Referer': 'https://emisiuni.live/',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    }

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
    except requests.exceptions.RequestException:
        return []

    response_text = response.text

    # Izolăm secțiunea <div class="lista-canale">
    lista_canale_match = re.search(r'<div class="lista-canale">(.*?)</div>', response_text, re.DOTALL)
    if not lista_canale_match:
        return []

    lista_canale_html = lista_canale_match.group(1)

    # Regex pentru articole care conțin canale
    channels = []
    regex_pattern = r'<article id="post-(\d+)" class=".*?canal.*?">(.*?)</article>'
    articles = re.findall(regex_pattern, lista_canale_html, re.DOTALL)

    for post_id, article_content in articles:
        try:
            # Extragem titlul din atributul title al tagului <a>
            title_match = re.search(r'<a class="post-thumbnail".*?title="(.*?)"', article_content)
            title = re.sub(r'\b(online|gratis)\b', '', title_match.group(1), flags=re.IGNORECASE).strip() if title_match else None

            # Extragem link-ul canalului din atributul href al tagului <a>
            link_match = re.search(r'<a class="post-thumbnail".*?href="(.*?)"', article_content)
            link = link_match.group(1).strip() if link_match else ''

            # Extragem posterul din atributul src al tagului <img>
            poster_match = re.search(r'<img.*?src="(.*?)"', article_content)
            poster = poster_match.group(1).strip() if poster_match else ''

            if title:
                channels.append({
                    'id': post_id,
                    'title': title,
                    'poster': poster,
                    'link': link
                })
        except Exception:
            continue

    return channels

# Funcția pentru a extrage lista de canale dintr-o categorie folosind regex
def extract_channel_items(category_url, category_name):
    headers = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Referer': category_url,
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    }

    try:
        response = requests.get(category_url, headers=headers)
        response.raise_for_status()
    except requests.exceptions.RequestException:
        return []

    response_text = response.text

    # Izolăm secțiunea <div class="lista-canale"> care conține doar posturile din categoria curentă
    lista_canale_match = re.search(r'<div class="lista-canale">(.*?)</div>', response_text, re.DOTALL)
    if not lista_canale_match:
        return []

    lista_canale_html = lista_canale_match.group(1)

    # Regex pentru articole care aparțin categoriei curente
    channels = []
    regex_pattern = rf'<article id="post-(\d+)" class=".*?categorie-{category_name}.*?">(.*?)</article>'
    articles = re.findall(regex_pattern, lista_canale_html, re.DOTALL)

    for post_id, article_content in articles:
        try:
            # Extragem titlul din atributul title al tagului <a>
            title_match = re.search(r'<a class="post-thumbnail".*?title="(.*?)"', article_content)
            title = re.sub(r'\b(online|gratis)\b', '', title_match.group(1), flags=re.IGNORECASE).strip() if title_match else None

            # Extragem link-ul canalului din atributul href al tagului <a>
            link_match = re.search(r'<a class="post-thumbnail".*?href="(.*?)"', article_content)
            link = link_match.group(1).strip() if link_match else ''

            # Extragem posterul din atributul src al tagului <img>
            poster_match = re.search(r'<img.*?src="(.*?)"', article_content)
            poster = poster_match.group(1).strip() if poster_match else ''

            if title:
                channels.append({
                    'id': post_id,
                    'title': title,
                    'poster': poster,
                    'link': link
                })
        except Exception:
            continue

    return channels

# Funcția pentru a extrage sursele video pentru un canal
def extract_video_sources(post_id, max_sources=2):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        'Referer': 'https://emisiuni.live/',
        'Accept-Language': 'ro-RO,ro;q=0.9,en-US;q=0.8,en;q=0.7',
        'X-Requested-With': 'XMLHttpRequest',
    }

    sources = []
    ajax_url = 'https://emisiuni.live/wp-admin/admin-ajax.php'

    try:
        for source in range(1, max_sources + 1):
            # Step 1: Fetch raw video source
            data = {
                'action': 'get_video_source',
                'tab': f'tab{source}',
                'post_id': post_id,
            }

            response = requests.post(ajax_url, headers=headers, data=data)
            response.raise_for_status()

            json_response = response.json()

            if json_response.get('success'):
                raw_source_url = json_response.get('data')
                if raw_source_url:
                    timestamp = int(time.time())
                    token = generate_token(raw_source_url, timestamp)
                    embed_url = (
                        f"https://ivanturbinca.com/embed-video.php?"
                        f"source={raw_source_url}&token={token}&timestamp={timestamp}"
                    )

                    # Step 2: Fetch final video URL
                    final_url = get_final_video_url(embed_url)
                    if final_url:
                        sources.append(final_url)
                    else:
                        xbmc.log(f"[RDSLive] Eroare: URL final lipsă pentru source-{source}", xbmc.LOGWARNING)
            else:
                xbmc.log(f"[RDSLive] Eroare în răspuns AJAX pentru source-{source}: {json_response.get('data')}", xbmc.LOGERROR)

    except requests.exceptions.RequestException as e:
        xbmc.log(f"[RDSLive] Eroare la extragerea sursei video: {e}", xbmc.LOGERROR)

    return sources

def get_final_video_url(embed_url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        'Referer': 'https://emisiuni.live/',
        'Accept-Language': 'ro-RO,ro;q=0.9,en-US;q=0.8,en;q=0.7',
    }

    try:
        response = requests.get(embed_url, headers=headers)
        response.raise_for_status()

        # Căutăm URL-ul real al stream-ului în sursa paginii
        video_source_match = re.search(r'<source src="([^"]+)"', response.text)

        if video_source_match:
            final_url = video_source_match.group(1)
            return final_url
        else:
            xbmc.log(f"[RDSLive] URL final nu a fost găsit pentru {embed_url}", xbmc.LOGWARNING)
            return None
    except requests.exceptions.RequestException as e:
        xbmc.log(f"[RDSLive] Eroare la obținerea URL-ului final: {e}", xbmc.LOGERROR)
        return None

def generate_token(source_url, timestamp):
    secret_key = "your_secret_key"  # Replace this with the actual secret key if known
    raw_token = f"{source_url}{timestamp}{secret_key}"
    return hashlib.sha256(raw_token.encode()).hexdigest()

# Funcția pentru a reda un canal selectat, permițând selecția sursei
def play_channel(post_id):
    # Citim setarea "play_mode" din settings.xml
    play_mode = addon.getSetting("play_mode")  # Returnează "0" (Automat) sau "1" (Manual)

    video_sources = extract_video_sources(post_id)

    if not video_sources:
        # Notificăm utilizatorul dacă nu sunt surse disponibile
        xbmcgui.Dialog().notification('Eroare', 'Nu am putut obține sursa video.', xbmcgui.NOTIFICATION_ERROR, 5000)
        return

    if play_mode == "0":  # Automat
        # Redăm automat prima sursă validă
        player_url = video_sources[0]
    elif play_mode == "1":  # Manual
        # Afișăm lista de surse utilizatorului pentru selecție
        dialog = xbmcgui.Dialog()
        source_labels = [f"Sursa {i+1}" for i in range(len(video_sources))]
        selected_index = dialog.select("Selectați sursa video", source_labels)

        if selected_index == -1:  # Dacă utilizatorul anulează selecția
            xbmcgui.Dialog().notification('Informație', 'Selecția a fost anulată.', xbmcgui.NOTIFICATION_INFO, 5000)
            return

        player_url = video_sources[selected_index]
    else:
        # Notificare în cazul unei setări neașteptate
        xbmcgui.Dialog().notification('Eroare', 'Setare necunoscută pentru mod redare.', xbmcgui.NOTIFICATION_ERROR, 5000)
        return

    # Redăm fluxul video selectat
    list_item = xbmcgui.ListItem(path=player_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, list_item)

# Funcția pentru a lista canalele dintr-o categorie selectată
def list_channels_for_category(category_url):
    if category_url == 'ALL_CATEGORIES':
        # Pentru categoria "Toate", extragem toate posturile din pagina specificată
        channels = extract_all_channels()
    else:
        # Extragem numele categoriei din URL
        category_name = category_url.rstrip('/').split('/')[-1]
        channels = extract_channel_items(category_url, category_name)

    for channel in channels:
        url = f"{sys.argv[0]}?action=play&post_id={channel['id']}"
        list_item = xbmcgui.ListItem(label=channel['title'])

        # Setăm thumb, icon și fundalul fanart.webp pentru fiecare canal
        list_item.setArt({
            'thumb': channel['poster'],
            'icon': channel['poster'],
            'fanart': 'special://home/addons/plugin.video.rdslive/fanart.webp'  # Setează fundalul
        })

        list_item.setProperty('IsPlayable', 'true')  # Marcăm elementul ca redabil
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

# Funcția pentru a lista categoriile în interfața Kodi
def list_categories():
    # Dicționar cu fundaluri pentru fiecare categorie
    category_backgrounds = {
        'Toate': 'special://home/addons/plugin.video.rdslive/resources/media/fanart.webp',
        'Generaliste': 'special://home/addons/plugin.video.rdslive/resources/media/fanart.webp',
        'Copii': 'special://home/addons/plugin.video.rdslive/resources/media/fanart.webp',
        'Filme': 'special://home/addons/plugin.video.rdslive/resources/media/fanart.webp',
        'Sport': 'special://home/addons/plugin.video.rdslive/resources/media/fanart.webp'
    }

    categories = extract_categories()
    for category in categories:
        url = f"{sys.argv[0]}?action=list_category&category_url={urllib.parse.quote_plus(category['link'])}"
        list_item = xbmcgui.ListItem(label=category['title'])

        # Setăm fundalul specific categoriei, dacă există
        fanart = category_backgrounds.get(category['title'], 'special://home/addons/plugin.video.rdslive/resources/media/fanart.webp')
        list_item.setArt({
            'fanart': fanart
        })

        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

# Funcția principală pentru a gestiona acțiunile
def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    if params and 'action' in params:
        if params['action'] == 'play':
            play_channel(params['post_id'])
        elif params['action'] == 'list_category':
            category_url = params['category_url']
            list_channels_for_category(category_url)
    else:
        list_categories()

# Main entry point
if __name__ == '__main__':
    router(sys.argv[2][1:])
