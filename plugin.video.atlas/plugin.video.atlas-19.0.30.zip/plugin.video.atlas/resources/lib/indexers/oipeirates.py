# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
OIPEIRATES = 'https://oipeirates.club'


def menu_year(): #97
    addDir('[COLOR white]2020[/COLOR]', OIPEIRATES + '/genre/2020/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]2019[/COLOR]', OIPEIRATES + '/genre/2019/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]2018[/COLOR]', OIPEIRATES + '/genre/2018/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]2017[/COLOR]', OIPEIRATES + '/genre/2017/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]2016[/COLOR]', OIPEIRATES + '/genre/2016/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]2013-2015[/COLOR]', OIPEIRATES + '/genre/2013-2015/', 96, ART + 'oipeirates.png', FANART, '')


def menu_genre(): #98
    addDir('[COLOR white]Περιπέτεια-Δράσης[/COLOR]', OIPEIRATES + '/genre/drasis/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Κωμωδίες[/COLOR]', OIPEIRATES + '/genre/komodies/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Θρίλερ[/COLOR]', OIPEIRATES + '/genre/thriller/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Τρόμου[/COLOR]', OIPEIRATES + '/genre/tromou/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Επ-φαντασίας[/COLOR]', OIPEIRATES + '/genre/ep-fantasias/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Φαντασίας[/COLOR]', OIPEIRATES + '/genre/fantasias/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Έγκλημα[/COLOR]', OIPEIRATES + '/genre/egklima/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Μυστήριο[/COLOR]', OIPEIRATES + '/genre/mystery/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Πολέμου[/COLOR]', OIPEIRATES + '/genre/war/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Γουέστερν[/COLOR]', OIPEIRATES + '/genre/western/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Δράμα[/COLOR]', OIPEIRATES + '/genre/drama/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Ρομαντικές[/COLOR]', OIPEIRATES + '/genre/romantikes/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Ντοκιμαντέρ[/COLOR]', OIPEIRATES + '/genre/documentary/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Μουσικές[/COLOR]', OIPEIRATES + '/genre/music/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Χορευτικές[/COLOR]', OIPEIRATES + '/genre/xoreftikes/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Χριστουγιεννιάτικες[/COLOR]', OIPEIRATES + '/genre/x-mas/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Φιλμογραφίες[/COLOR]', OIPEIRATES + '/genre/filmography/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Συλλογές[/COLOR]', OIPEIRATES + '/genre/collection/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Ελλ-ταινίες[/COLOR]', OIPEIRATES + '/genre/ell-tainies/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Bollywood[/COLOR]', OIPEIRATES + '/genre/Bollywood/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Anime-series[/COLOR]', OIPEIRATES + '/genre/anime/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Anime-movies[/COLOR]', OIPEIRATES + '/genre/animemovies/', 96, ART + 'oipeirates.png', FANART, '')


def oipeirates(url): #96
    hdrs = {'Referer': OIPEIRATES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    
    m = re.compile('<img src="(.+?)" alt="(.+?)".+?<a href="(.+?)">', re.DOTALL).findall(p)
    for icon, name, url in m:
        if 'Tainies Online σειρες OiPeirates Movies Greek Subs' in name:
            continue
        name = clear_Title(name)

        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 99, icon, FANART, '')
    try:
        m = re.compile('</u></span><span class="page"><a href="(.+?)"').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 96, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass


def get_links(name, url, iconimage, description): #99
    hdrs = {'Referer': OIPEIRATES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m2 = re.compile('<iframe.+?src="(.+?)"').findall(p)
    for url in m2:
        if 'youtube' in url:
            Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
            addDir(Trailer, url, 100, ART + 'youtube.png', '', str(description))
        else:
            addDir('[B][COLOR orange]Δεν υπάρχει διαθέσιμο Τρέιλερ[/COLOR][/B]', '', 100, '', '', str(description))
    else:
        m = re.compile('href="(.+?)"\s+').findall(p)
        t = re.compile('<meta property="og:title" content="(.+?)" />').findall(p)
        link_list = ['aparat', 'flashx', 'hdvid', 'vidd', 'vidoza', 'vidlox', 'estream', 'clipwatching', 'thevideo', 'vidzi']
        for url in m:
            for name in t:
                if any(x in url for x in link_list):
                    name = clear_Title(name)
                    addDir(name, url, 100, iconimage, FANART, str(description))

def oipeirates_series(url): #112
    hdrs = {'Referer': OIPEIRATES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    
    m = re.compile('<img src="(.+?)" alt="(.+?)".+?<a href="(.+?)">', re.DOTALL).findall(p)
    for icon, name, url in m:
        if 'Tainies Online σειρες OiPeirates Movies Greek Subs' in name:
            continue
        name = clear_Title(name)
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 111, icon, FANART, '')
    try:
        m = re.compile('</u></span><span class="page"><a href="(.+?)"').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 112, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass


def get_links_series(name, url, iconimage, description): #111
    hdrs = {'Referer': OIPEIRATES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m2 = re.compile('<iframe.+?src="(.+?)"').findall(p)
    for url in m2:
        if 'youtube' in url:
            Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
            addDir(Trailer, url, 100, ART + 'youtube.png', '', str(description))
        else:
            addDir('[B][COLOR orange]Δεν υπάρχει διαθέσιμο Τρέιλερ[/COLOR][/B]', '', 100, '', '', str(description))
    else:
        m = re.compile('<a href="(.+?)" target="_blank".+?>(.+?)</a>').findall(p)
        t = re.compile('<meta property="og:title" content="(.+?)" />').findall(p)
        link_list = ['aparat', 'flashx', 'hdvid', 'vidd',
                     'vidoza', 'vidlox', 'estream', 'clipwatching', 'thevideo', 'vidzi']
        for url, epi in m:
            for name in t:
                epi = ' | Επεισόδιο ' + epi
            #    name = name + epi
                name = clear_Title(name)
                if any(x in url for x in link_list):
                    if 'La casa de papel' in name:
                        addDir(name, url, 100, iconimage, FANART, str(description))
                    else:
                        addDir((name+epi), url, 100, iconimage, FANART, str(description))


def search(url): #95
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = 'https://oipeirates.club/?s=' + search
        oipeirates(url)

def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')

    txt = txt.replace('(2003– )', '(2003)').replace('(2005– )', '(2005)').replace('(2011– )', '(2011)').replace('(2017–)', '(2017)').replace('-)', ')').replace('- )', ')')
    txt = txt.replace('(TV Series 2011) Greek Subs', '').replace('Tv Series ', '').replace('TV Series ', '')
    txt = txt.replace('(Tv Series 2010)', '(2010)').replace(' (Tv Series 2010- )', '(2010)').replace(' (Tv Series 2011)', '(2011)').replace('(Tv Series 2011)', '(2011)')
    txt = txt.replace(' (Tv Series 2013)', '(2013)').replace('(Tv Series 2013)', '(2013)').replace('(TV Series 2013)', '(2013)').replace('(TV Series 2013– )', '(2013)').replace(' - Tainies Online σειρες OiPeirates Movies Greek Subs', '')
    txt = txt.replace(' (Tv Series 2006)', '(2006)').replace(' (Tv Series 2011- )', '(2011)').replace('(2013– )', '(2013)').replace(' Online Greek Subs - OiPeirates Movies', '').replace(' - OiPeirates Movies', '').replace(' Greek Subs', '')
    return txt

