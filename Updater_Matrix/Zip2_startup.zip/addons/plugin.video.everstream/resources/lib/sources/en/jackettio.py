# -*- coding: utf-8 -*-

import re
import requests
from six.moves.urllib_parse import parse_qs, urlencode, quote_plus
from resources.lib.modules import api_keys
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import source_utils
from resources.lib.modules import log_utils

import json
import xbmcgui

class source:
	def __init__(self):
		self.priority = 1
		self.language = ['en', 'el']
		self.domains = ['jackettiofortheweebs.midnightignite.me']
		self.base_link = 'https://jackettiofortheweebs.midnightignite.me/eyJtYXhUb3JyZW50cyI6MzAsInByaW90aXplUGFja1RvcnJlbnRzIjoyLCJleGNsdWRlS2V5d29yZHMiOlsicnV0cmFja2VyIl0sImRlYnJpZElkIjoidG9yYm94IiwiaGlkZVVuY2FjaGVkIjp0cnVlLCJzb3J0Q2FjaGVkIjpbWyJxdWFsaXR5Iix0cnVlXSxbInNpemUiLHRydWVdXSwic29ydFVuY2FjaGVkIjpbWyJzZWVkZXJzIix0cnVlXV0sImZvcmNlQ2FjaGVOZXh0RXBpc29kZSI6ZmFsc2UsInByaW90aXplTGFuZ3VhZ2VzIjpbImVuZ2xpc2giXSwiaW5kZXhlclRpbWVvdXRTZWMiOjYwLCJtZXRhTGFuZ3VhZ2UiOiIiLCJlbmFibGVNZWRpYUZsb3ciOmZhbHNlLCJtZWRpYWZsb3dQcm94eVVybCI6IiIsIm1lZGlhZmxvd0FwaVBhc3N3b3JkIjoiIiwibWVkaWFmbG93UHVibGljSXAiOiIiLCJ1c2VTdHJlbVRocnUiOnRydWUsInN0cmVtdGhydVVybCI6Imh0dHBzOi8vc3RyZW10aHJ1Zm9ydGhld2VlYnMubWlkbmlnaHRpZ25pdGUubWUiLCJxdWFsaXRpZXMiOlswLDM2MCw0ODAsNzIwLDEwODAsMjE2MF0sImluZGV4ZXJzIjpbImNpbmVjYWxpZGFkIiwia25hYmVuIiwic3Vic3BsZWFzZSIsInRvcnJlbnRzY3N2IiwiYW5pbWV0b3NobyIsImJpdHNlYXJjaCIsInRvcnJlbnQ5IiwidGhlcmFyYmciLCJsaW1ldG9ycmVudHMiLCJveHRvcnJlbnQtY28iLCJjcGFzYmllbmNsb25lIiwiYW5pUmVuYSIsImJpdG1hZ25ldCIsInRoZXBpcmF0ZWJheSIsInRvcnJlbnRnYWxheHljbG9uZSIsInRvcnJlbnRkb3dubG9hZHMiLCJlenR2IiwidWluZGV4IiwiZXp0dmwiLCJ5dHMiLCJ0b3JyZW50ZG93bmxvYWQiXSwiZGVicmlkQXBpS2V5IjoiMzhhZWVjYTEtNjNhMC00ODExLWEwMmMtYWZkYjNjOTRjNjVjIn0='
		self.movieSearch_link = '/stream/movie/%s.json'
		self.tvSearch_link = '/stream/series/%s:%s:%s.json'
		self.aliases = []

	def movie(self, imdb, tmdb, title, localtitle, aliases, year):
		try:
			self.aliases.extend(aliases)
			url = {'imdb': imdb, 'title': title, 'aliases': aliases, 'year': year}
			url = urlencode(url)
			return url
		except:
			return

	def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
		try:
			self.aliases.extend(aliases)
			url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
			url = urlencode(url)
			return url
		except:
			return

	def episode(self, url, imdb, tvdb, title, premiered, season, episode):
		try:
			if url is None: return

			url = parse_qs(url)
			url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
			url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
			url = urlencode(url)
			return url
		except:
			return

	def sources(self, url, hostDict, hostprDict):
		sources = []
		try:
			try:
				data = parse_qs(url)
				data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

				title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
				year = data['year']
				imdb = data['imdb']
				if 'tvshowtitle' in data:
					season = data['season']
					episode = data['episode']
					hdlr = 'S%02dE%02d' % (int(season), int(episode))
					url = '%s%s' % (self.base_link, self.tvSearch_link % (imdb, season, episode))
				else:
					url = '%s%s' % (self.base_link, self.movieSearch_link % imdb)
					hdlr = year
				results = client.request(url, timeout='60')
				#log_utils.log(results, 1)
				files = json.loads(results)['streams']
			except:
				log_utils.log('torrentio_exc', 1)
				return sources

			if files:
				for file in files:
					try:
						parts = file['title']
						name_part, info_part = parts.split('\n', 1)
						name = name_part.strip()
						if not source_utils.is_match(name, title, hdlr, self.aliases): continue
						url = file['url']
						hash = file['infoHash']
						try:
							rsize = re.search(r'([\d.]+)\s*(KB|MB|GB|TB)', info_part, re.IGNORECASE)
							value = float(rsize.group(1))
							unit = rsize.group(2).upper()

							# Unit multipliers (binary)
							multipliers = {
								'KB': 1024,
								'MB': 1024 ** 2,
								'GB': 1024 ** 3,
								'TB': 1024 ** 4,
							}

							size_bytes = int(value * multipliers[unit])
							dsize = size_bytes
							isize = self.format_bytes(dsize)
						except:
							dsize = 0
							isize = ''
						quality, info = source_utils.get_release_quality(name)
						info.insert(0, isize)
						info = ' | '.join(info)
						if quality == 'cam' and not 'tvshowtitle' in data: continue
						excluded = control.excludedStrings
						if any(fs in name.lower() for fs in excluded): continue
						sources.append(
							{
								'source': 'direct', 
								'quality': quality, 
								'hash': hash,
								'language': 'en', 
								'url': url, 
								'info': info, 
								'direct': True, 
								'debridonly': False, 
								'name': name, 
								'size': dsize
							}
						)
					except:
						log_utils.log('torrentio_exc', 1)
						pass

			return sources
		except:
			log_utils.log('torrentio_exc', 1)
			return sources

	def resolve(self, url):
		return url
	
	def format_bytes(self, size):
		for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
			if size < 1024:
				return f"{size:.2f} {unit}"
			size /= 1024
		return f"{size:.2f} PB"

