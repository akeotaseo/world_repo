# -*- coding: utf-8 -*-
import re, requests, control, datetime, time, sys
plupdate = False
if sys.version_info[0] == 2:
	reload(sys)
	sys.setdefaultencoding('utf-8')

def main(new=False):
	global plupdate
	if plupdate:
		return
	channelscache = control.getcache("plugin.video.vavooto.channels")
	if channelscache and not new:
		return channelscache
	plupdate = True
	while not control.getcache("plugin.video.vavooto.gruppen"):
		choose()
	groups = {}
	for c in requests.get('http://vjackson.info/live/index?output=json').json():
		if c['group'] in control.getcache("plugin.video.vavooto.gruppen") or "DE :" in c['name']:
			name = re.sub("\(.*\)", "", c['name'])
			name = name.replace('EINS', '1').replace('ZWEI', '2').replace('DREI', '3').replace('SIEBEN', '7').replace('DE : ', '').replace(' FHD', '').replace(' HD', '').replace(' 1080', '').replace(' AUSTRIA', '').replace(' GERMANY', '').replace(' DEUTSCHLAND', '').replace(' DE', '').replace('SKY TNT', 'TNT').strip()
			if "1-2-3" in name: name = "arriba"
			name = re.sub(r'(\d)([A-Z])', r'\1 \2', name)
			name = re.sub(r'(\D)(\d)', r'\1 \2', name)
			name = name.replace('KRIME', 'KRIMI').replace('SPORT BUNDESLIGA', 'BUNDESLIGA').replace('.', '').replace('DOC', 'DOK').replace('ACITON', 'ACTION').replace('SERIES', 'SERIE').replace(' SD', '').replace('  YOU', '').replace('SKY DISNEY', 'DISNEY').replace('SKY NAT', 'NAT').replace('SKY POP', 'POP').replace('SKY UNI', 'UNI').replace('SKY CINEMA 24', 'SKY CINEMA +24').replace('SKY CINEMA 1', 'SKY CINEMA +1').replace('NAT GEOGRAPHIC', 'NATIONAL GEOGRAPHIC').replace('  ', ' ')
			if "HEIMA" in name: name = "HEIMATKANAL"
			if "CENTRAL" in name or "VIVA" in name: name = "VIVA"
			if "BR" and "FERNSEHEN" in name: name = "BR"
			if "DMAX" in name: name = "DMAX"
			if "KINOWELT" in name: name = "KINOWELT"
			if "MDR" in name: name = "MDR"
			if "RBB" in name: name = "RBB"
			if "WDR" in name: name = "WDR"
			if "PLANET" in name: name = "PLANET"
			if "NITRO" in name: name = "RTL NITRO"
			if "SYFY" in name: name = "SYFY"
			if "E!" in name: name = "E! ENTERTAINMENT"
			if "ENTERTAINMENT" in name: name = "E! ENTERTAINMENT"
			if "STREET" in name: name = "13TH STREET"
			if "WUNDER" in name: name = "WELT DER WUNDER"
			if "KAB" and "CLA" in name: name = "KABEL 1 CLASSICS"
			if "MAXX" in name: name = "PRO 7 MAXX"
			if "PRO" and "FUN" in name: name = "PRO 7 FUN"
			if "ZEE" in name: name = "ZEE ONE"
			if "FOX" in name: name = "FOX"
			if "AXN" in name: name = "AXN"
			if "arriba" in name: name = "1-2-3 TV"
			if "UNIVERSAL" in name: name = "UNIVERSAL"
			if "DELUX" in name: name = "DELUXE MUSIC"
			if "DISCO" in name: name = "DISCOVERY"
			if "TLC" in name: name = "TLC"
			if "HISTORY" in name: name = "HISTORY"
			if "ATLANTIC" in name: name = "SKY ATLANTIC"
			if "WILD" in name: name = "NAT GEO WILD"
			if "VISION" in name: name = "MOTORVISION"
			if "INVESTIGATION" in name or "A&E" in name: name = "A&E"
			if "AUTO" in name: name = "AUTO MOTOR SPORT"
			if "GEOGRAPHIC" in name: name = "NATIONAL GEOGRAPHIC"
			if name not in groups:
				groups[name] = []
			groups[name].append(c['url'])
	control.setcache( "plugin.video.vavooto.channels", groups, expiration=datetime.timedelta(minutes=control.getSettingInt('play')))
	plupdate = False
	return groups
	
def choose():
	data = requests.get('http://vjackson.info/live/index?output=json').text
	new_groups = sorted(list(set(re.findall('group":"(.*?)"',data))))
	indicies = control.selectDialog(new_groups, "Choose Groups", True)
	group = []
	if indicies:
		for i in indicies:
			group.append(new_groups[i])
	if len(group) > 0:
		control.setcache( "plugin.video.vavooto.gruppen", group)
		main(new=True)
		icies = control.selectDialog(new_groups, "Choose Groups", True)
	group = []
	if indicies:
		for i in indicies:
			group.append(new_groups[i])
	if len(group) > 0:
		control.setcache( "plugin.video.vavooto.gruppen", group)
		main(new=True)
		