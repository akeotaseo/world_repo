# -*- coding: utf-8 -*-
import re
import base64
import urllib.parse
from blackscrapers.modules import client
from blackscrapers.modules import log_utils

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en', 'el']
        self.domains = ['vidsrc.io', 'vidsrc.net', 'vidsrc.me', 'vidsrc.to']
        self.base_link = 'https://vidsrc.io'
        self.headers = {
            'User-Agent': client.agent(),
            'Referer': self.base_link
        }

    def movie(self, imdb, tmdb, title, localtitle, aliases, year):
        if imdb: return f"{self.base_link}/embed/movie?imdb={imdb}&ds_lang=en"
        return

    def tvshow(self, imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        if imdb: return imdb
        return

    def episode(self, url, imdb, tmdb, tvdb, title, premiered, season, episode):
        if not url: return
        return f"{self.base_link}/embed/tv?imdb={url}&season={season}&episode={episode}&ds_lang=en"

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if not url: return sources

            # Βήμα 1: Embed Page
            r = client.request(url, headers=self.headers, timeout=10)
            if not r: return sources

            # Βήμα 2: Εντοπισμός RCP Iframe (Cloudnestra)
            iframe_match = re.search(r'iframe.*?src=["\'](//.*?)["\']', r)
            
            if iframe_match:
                rcp_url = iframe_match.group(1)
                if rcp_url.startswith('//'): rcp_url = 'https:' + rcp_url
                
                # Βήμα 3: Μπαίνουμε στο RCP (Cloudnestra)
                headers_rcp = {'User-Agent': client.agent(), 'Referer': url}
                r_rcp = client.request(rcp_url, headers=headers_rcp, timeout=10)
                
                found_links = []

                # --- METHOD A: JS UNPACKER ---
                # Ψάχνουμε για packed code (eval(function(p,a,c,k,e,d)...))
                packed_data = re.search(r'eval\(function\(p,a,c,k,e,d\).*?\.split\("\|"\)\)\)', r_rcp)
                if packed_data:
                    try:
                        from blackscrapers.modules import jsunpack # Αν υπάρχει, αλλιώς δικό μας
                        unpacked = jsunpack.unpack(packed_data.group(0))
                        # Ψάχνουμε μέσα στον ξεπακεταρισμένο κώδικα
                        found_links.extend(re.findall(r'src=["\'](https?://.*?)["\']', unpacked))
                        found_links.extend(re.findall(r'file=["\'](https?://.*?)["\']', unpacked))
                    except:
                        # Fallback simple unpack logic αν δεν έχουμε βιβλιοθήκη
                        pass

                # --- METHOD B: BASE64 DECODING ---
                b64_candidates = re.findall(r'["\']([a-zA-Z0-9+/=]{40,})["\']', r_rcp)
                for candidate in b64_candidates:
                    try:
                        decoded = base64.b64decode(candidate).decode('utf-8')
                        if 'http' in decoded and '://' in decoded:
                            found_links.append(decoded)
                    except:
                        pass

                # --- METHOD C: REGULAR REGEX ---
                found_links.extend(re.findall(r'src=["\'](https?://.*?)["\']', r_rcp))

                # Επεξεργασία Ευρημάτων
                for link in found_links:
                    if any(x in link for x in ['vidsrc', 'rcp', 'cloudnestra', '.css', '.js', 'google']): continue

                    hoster = ''
                    quality = '1080p'
                    
                    if 'vidplay' in link or 'mcloud' in link: hoster = 'VidPlay'
                    elif 'filemoon' in link: hoster = 'Filemoon'
                    elif 'streamtape' in link: hoster = 'Streamtape'; quality = 'SD'
                    
                    if hoster:
                        sources.append({
                            'source': 'vidsrc',
                            'quality': quality,
                            'language': 'en',
                            'url': link,
                            'info': f'[{hoster}]',
                            'direct': False, # ResolveURL handles this
                            'debridonly': False
                        })

        except Exception as e:
            log_utils.log(f'VIDSRC Unpacker Error: {e}', 1)
            return sources

        return sources

    def resolve(self, url):
        return url