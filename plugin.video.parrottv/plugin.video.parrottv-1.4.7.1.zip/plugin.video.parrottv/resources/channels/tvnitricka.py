# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests
import re

class TVNitricka:
    def __init__(self):
        self.ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36"
        self.ytburl = "https://www.youtube.com/channel/UCnEQCNDsMtPlrVwCrRViaeQ/live"

    def grab(self, channel):
        headers = {
            "User-Agent": self.ua,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "DNT": "1",
            "Alt-Used": "www.youtube.com",
            "Connection": "keep-alive",
            "Cookie": "YSC=xZ55110E6S4; CONSENT=YES+cb.20220320-18-p0.en+FX+712",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
            "Sec-GPC": "1",
            "Cache-Control": "max-age=0"
        }
        r = requests.get(self.ytburl, headers=headers).content.decode('utf-8')
        pattern = re.compile(r'"hlsManifestUrl":"(.*?)"')
        match = pattern.search(r)
        hlsurl = None
        if match:
            hlsurl = match.group(1)
        return hlsurl, headers