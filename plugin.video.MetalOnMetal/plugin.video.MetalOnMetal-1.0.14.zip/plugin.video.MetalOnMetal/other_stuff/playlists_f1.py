import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_youtube_channels


setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="

arrayMenu = ([
            [ "Víctor Abad - Carreras 2023",  "PLzZvLfrmXZ5beQ0UJJL5XRSfqRZAT3Gp0"],
            [ "Víctor Abad - Vlog Post Carrera",  "PLzZvLfrmXZ5YzOepVAXLJh1M907M2vV0A"],
            [ "Abel Caro - Entendiendo la F1",  "PLLBkMvKxwvC96kFO3gpVMWUZitD6uIDLq"],
            [ "Abel Caro - F1 para futboleros",  "PLLBkMvKxwvC-VzuFt4xmARYY7VtQUJiII"],
            [ "Albert Fábrega - Mundial de F1",  "PLr5q8ylzsZEmINFxe36HK_EbVZ2gsUR0_"],
            [ "Adrian Puente - Telemétrico F1 Fox Sports ",  "PLwSBQUF7LBnty1BY0aak6fp4IHL3qsmgr"],
           # [ "",  ""],
           # [ "",  ""]
            ])
       

def playlists(params):
    logo=logos_youtube_channels.metalfever(params)

    for i in range(len(arrayMenu)):
        titulo = arrayMenu[i][0]
        id_canal = arrayMenu[i][1]
        if usa_duffyou:  ##Usamos plugin Duff You
            reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_canal)
            videos = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        else:  ##Usamos plugin YouTube
            videos = youtube.replace("MI-ID-PLAYLIST" , id_canal)
        
        plugintools.add_item( 
            title=titulo,
            url=videos,
            thumbnail=logo, folder=True )

