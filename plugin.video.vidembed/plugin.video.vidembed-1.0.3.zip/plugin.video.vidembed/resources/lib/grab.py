# Copyright © 2022 Parrot Developers.
# Coded by Parrot Developers alias HereIronman7746.
# Do not share this addon.
import base64, codecs
magic = 'aW1wb3J0IHJlcXVlc3RzLCBiczQsIHJlc29sdmV1cmwNCmZyb20gcmVzb3VyY2VzLmxpYi5icm93c2VySGVhZGVycyBpbXBvcnQgaGVhZGVycw0KDQpzZXJ2ZXIgPSAiaHR0cHM6Ly9zYnBsYXkyLmNvbS9lLyINCg0KZGVmIHVybGZpbmQoaWZyYW1lX2h0bWwpOg0KICAgIHBsYXllcmlkID0gaWZyYW1lX2h0bWwucmVwbGFjZSgnXG4nLCAnJykuc3BsaXQoZ'
love = 'vp8oTxtL2kup3Z9VzkcozgmMKW2MKVvVTEuqTRgp3EuqUImCFVkVvOxLKEuYKMcMTIiCFW7p2IlqzIlsFpcJmSqYaAjoTy0XPp/WlyoZS0APvNtVPOjoTS5MKW1pzjtCFOzVagmMKW2MKW9r3OfLKyypzyxsFVAPvNtVPOlMKE1pz4tpTkurJIlqKWfQDbAPzEyMvOapzSvXUIloPx6QDbtVPNtnUEgoPN9VUWypKIyp3EmYzqyqPu1pzjfVTuyLJEypaZ9nTIuMT'
god = 'VycykudGV4dA0KICAgIHNvdXAgPSBiczQuQmVhdXRpZnVsU291cChodG1sLCAnaHRtbC5wYXJzZXInKQ0KICAgIGlmcmFtZSA9IHNvdXAuZmluZCgnaWZyYW1lJykNCiAgICBpZnJhbWVfdXJsID0gaWZyYW1lWydzcmMnXS5yZXBsYWNlKCIvLyIsICJodHRwczovLyIpDQogICAgaWZyYW1lX2h0bWwgPSByZXF1ZXN0cy5nZXQoaWZyYW1lX3VybCwgaGVhZGV'
destiny = 'lpm1bMJSxMKWmXF50MKu0QDbtVPNtIIWZqT9FMKAioUMyVQ0tqKWfMzyhMPucMaWuoJIsnUEgoPxAPvNtVPOlMKAioUMyMPN9VPVvQDbtVPNtnJLtpzImo2k2MKIloP5Vo3A0MJEAMJEcLHMcoTHbIIWZqT9FMKAioUMyXGbAPvNtVPNtVPNtpzImo2k2MJDtCFOlMKAioUMyqKWfYaWyp29fqzHbIIWZqT9FMKAioUMyXD0XVPNtVUWyqUIlovOlMKAioUMyMN0X'
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))