from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from resolver_360 import SportResolver


class CommonResolver:

    def __init__(self, resolver: 'SportResolver'):
        self.servers = self.set_servers()
        self.resolver = resolver
        self.page_url = None
        self.page_src = None
        self.request_headers = {}
        self.set_request_headers()

    def set_request_headers(self):
        pass

    def set_page_url(self, url):
        self.page_url = url

    def set_page_src(self, page_src):
        self.page_src = page_src

    def set_servers(self):
        pass

    def find_page(self):
        pass

    def find_page_src(self, src):
        pass

    def parse_stream(self, url):
        pass

    def set_referer(self, url):
        pass

    def find_stream(self):
        pass
