import re
import xbmcaddon
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

BaseURL = 'https://hog.tv'
Thumb   = 'special://home/addons/plugin.video.xxx/resources/art/hogtv.png'


def Menu():
	addDir('Latest Videos',      BaseURL + '/new',        81, Thumb)
	addDir('Most Viewed Videos', BaseURL + '/trending',   81, Thumb)
	addDir('Top Rated Videos',   BaseURL + '/all',        81, Thumb)
	addDir('Categories',         BaseURL + '/categories', 82, Thumb)
	addDir('Channels',           BaseURL + '/channels',   82, Thumb)

def Browse(url):
	r = OpenURL(url)
	m = re.compile('<a class="item__main" href="(.+?)" title="(.+?)">\n                        <div class="item__image">\n                            \n                                <img class="item__inner lazy" width="100%" data-src=".+?" data-srcset="(.+?)" data-id=".+?" alt=".+?">\n                                                    </div>\n\n                        <div class="item__counter">(.+?)</div>').findall(r)
	for url, title, thumb, time in m:
		if not thumb.startswith('http'): thumb = 'http:' + thumb
		url = '%s&random_id=%s' % (url, RandomID())
		if Setting('show_time') == 'true': title = '[B](%s)[/B] %s' % (time, title)
		addVideo(title, url, 83, thumb)
	
	n = re.compile('href="(.+?)"><span>Next<').findall(r)
	for NextPage in n:
		addDir('Next page >', BaseURL + NextPage, 81, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	Common.SetView()
		
def Categories(url):
	r = OpenURL(url)
	if '/categories' in url:
		m = re.compile('<a class="item" href="(.+?)" title="(.+?)" data-id=".+?">\n                        <div class="item__main">\n                            <div class="item__image">\n                                                                <img class="item__inner lazy" width="100%" data-src="(.+?)"').findall(r)	
	if '/channels' in url:
		m = re.compile('<a class="item" href="(.+?)" title="(.+?)" data-id=".+?">\n                <div class="item__main">\n                    <div class="item__image">\n                                                <img class="item__inner lazy" width="100%" data-src="(.+?)" data-id=".+?" alt=".+?" />').findall(r)	
	for url, title, thumb in m:
		if not thumb.startswith('http'): thumb = 'http:' + thumb
		addDir(title, BaseURL + url, 81, thumb)
	n = re.compile('href="(.+?)"><span>Next<').findall(r)
	for NextPage in n:
		addDir('Next page >', BaseURL + NextPage, 82, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	Common.SetView()
	
def PlayStream(url):
	if 'random_id=' in url: url = re.compile('(.+?)&random_id').findall(url)[0]
	r = OpenURL(BaseURL + url)
	video = re.compile('"downloadUrl":"(.+?)",').findall(r)[0]
	if not video.startswith('http'):
		video = 'http:' + video
	Play(video)
	

def RandomID():
	import random
	random_id = str(random.randint(0,1000000))
	return random_id