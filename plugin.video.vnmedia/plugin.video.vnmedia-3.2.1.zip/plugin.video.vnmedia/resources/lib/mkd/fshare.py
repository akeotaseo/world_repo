from codequick import Route, Script, Listitem
from xbmcaddon import Addon
from functools import lru_cache
@Route.register
def index_fshare(plugin, **kwargs):
	yield Listitem.search(Route.ref('/resources/lib/mkd/onfshare/timfshare:searchfs'))
	if Addon().getSetting('historyfs') == 'true':
		yield Listitem.from_dict(**{'label': 'LỊCH SỬ XEM',
		'info': {'plot': 'Nội dung được xem gần nhất'},
		'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/lichsu.png',
		'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/lichsu.png'},
		'callback': Route.ref('/resources/lib/mkd/onfshare/ifshare:index_daxem')})
	yield Listitem.from_dict(**{'label': 'NHẬP CODEPLAY',
	'info': {'plot': 'Nhập MÃ CODE để phát phim'},
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/playcode.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/playcode.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/codenumber:index_number')})
	yield Listitem.from_dict(**{'label': 'Fshare Favourite',
	'info':{'plot':'Yêu thích'},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/yeuthich.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/yeuthich.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/ifshare:fs_favorite')})
	if Addon().getSetting('taifshare') == 'true':
		yield Listitem.from_dict(**{'label': 'Tệp đã tải',
		'info':{'plot':'Tệp đã tải'},
		'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/datai.png',
		'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/datai.png'},
		'callback': Route.ref('/resources/lib/mkd/onfshare/datai:index_datai')})
	yield Listitem.from_dict(**{'label': 'VNM Tuyển Chọn',
	'info': {'plot': 'VNM đề xuất'},
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/dexuat.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/dexuat.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/timfshare:index_pdx')})
	yield moicapnhat()
	yield trending()
	yield phim4k()
	yield bluray()
	yield thuyetminh()
	yield longtieng()
	yield phimle()
	yield phimbo()
	yield anime()
	yield Listitem.from_dict(**{'label': 'HdVietNam',
	'info':{'plot':'Thư viện dữ liệu phim Fshare'},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/thuvienhd.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/thuvienhd.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/hdvn:index_hdvn')})
	yield Listitem.from_dict(**{'label': 'Thư viện HD',
	'info':{'plot':'Thư viện dữ liệu phim Fshare'},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/tvhd.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/tvhd.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/thuvienhd:index_thuvienhd')})
	yield Listitem.from_dict(**{'label': 'Thư viện Cine',
	'info':{'plot':'Thư viện dữ liệu phim Fshare'},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/thuviencine.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/thuviencine.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/thuviencine:index_thuviencine')})
	yield Listitem.from_dict(**{'label': 'TOP FSHARE',
	'info':{'plot':'Top 15 thư mục theo dõi nhiều nhất'},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/topfshare.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/topfshare.png'},
	'callback': Route.ref('/resources/lib/mkd/onfshare/ifshare:fs_topfollow')})
	yield Listitem.from_dict(**{'label': 'Đo tốc độ Fshare',
	'info': {'plot': 'Đo tốc độ Fshare'},
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/Speedtest.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/Speedtest.png'},
	'callback': Script.ref('/resources/lib/download:speedtestfs')})
@lru_cache(maxsize=None)
def moicapnhat():
	item = Listitem()
	item.label = '[COLOR yellow][B]MỚI NHẤT[/B][/COLOR]'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/moicapnhat.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/recent/page/', 1)
	return item
@lru_cache(maxsize=None)
def phim4k():
	item = Listitem()
	item.label = '4K - H265'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/4k.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/4k/page/', 1)
	return item
@lru_cache(maxsize=None)
def bluray():
	item = Listitem()
	item.label = 'Bluray nguyên gốc'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/bluray.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/bluray-nguyen-goc/page/', 1)
	return item
@lru_cache(maxsize=None)
def thuyetminh():
	item = Listitem()
	item.label = 'Thuyết minh'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/thuyetminh.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/thuyet-minh-tieng-viet/page/', 1)
	return item
@lru_cache(maxsize=None)
def longtieng():
	item = Listitem()
	item.label = 'Lồng tiếng'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/longtieng.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/long-tieng-tieng-viet/page/', 1)
	return item
@lru_cache(maxsize=None)
def anime():
	item = Listitem()
	item.label = 'Hoạt hình'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/anime.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/animation/page/', 1)
	return item
@lru_cache(maxsize=None)
def phimle():
	item = Listitem()
	item.label = 'Phim lẻ'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/phimle.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/phim-le/page/', 1)
	return item
@lru_cache(maxsize=None)
def phimbo():
	item = Listitem()
	item.label = 'Phim bộ'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/phimbo.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_page'), 'https://thuvienhd.com/genre/series/page/', 1)
	return item
@lru_cache(maxsize=None)
def trending():
	item = Listitem()
	item.label = '[COLOR yellow][B]TRENDING[/B][/COLOR]'
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/hot.png'
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuviencine:thuviencine_page'), 'https://thuviencine.com/top/', 1)
	return item