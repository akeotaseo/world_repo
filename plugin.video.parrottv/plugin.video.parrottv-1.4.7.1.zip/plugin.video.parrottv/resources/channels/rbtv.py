# Credits to madtitansports <3
# Never gonna give you up guys
# Also check 'em out, they do have nice selection of channels

import requests
from datetime import datetime
import xbmcaddon
import io
import os
import resources
_ADDON = xbmcaddon.Addon()
_USERNAME = _ADDON.getSetting('username')
_PASSWORD = _ADDON.getSetting('password')

channelInfoPath = resources.translatePath('special://home/userdata/addon_data/'+_ADDON.getAddonInfo('id')+'/RBTV.txt')

if not os.path.exists(channelInfoPath):
    try:
        resp = requests.get('https://pastebin.com/raw/78is3tW3').text
    except: # Sometimes my pastebin gets blocked idk why. So this is backup.
        resp = requests.get("https://api.parrotdevelopers.repl.co/{}/{}/ChannelLists/RBTV.txt".format(_USERNAME, _PASSWORD)).text
    io.open(channelInfoPath, "w", encoding="utf-8").write(resp)


channelinfo = io.open(channelInfoPath, 'r', encoding='utf-8').read()

class RBTV:
    def __init__(self):
        self.ua = "Dalvik/2.1.0 (Linux; U; Android 5.1.1; AFTT Build/LVY48F)"

    def genWMS(self):
        headers = {
            "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 5.1.1; AFTT Build/LVY48F)",
            "Accept-Encoding": "gzip",
            "Authorization": "Basic QDA3NzEyMSM6QDA3NzEyMSM=",
        }  
        req = requests.Request("GET", "http://135.181.2.111:8800/cip/4c.rbt/"   )
        prepped = req.prepare()
        prepped.headers = headers
        s = requests.Session()
        r = s.send(prepped, timeout=5, verify=False)
        r.raise_for_status()
        _token = r.text
        now = datetime.utcnow()
        _in = list(_token)
        _in.pop(len(_in) + 2 - 3 - int(str(now.year)[:2]))
        _in.pop(len(_in) + 3 - 4 - int(str(now.year)[2:]))
        _in.pop(len(_in) + 4 - 5 - (now.month - 1 + 1 + 10))
        _in.pop(len(_in) + 5 - 6 - now.day)
        token = "".join(_in)
        return token
    
    def grab(self, channel):
        headers = {'User-Agent': self.ua}
        hlsurl = ""
    
        for line in channelinfo.split('\n'):
            line = line.split(' | ')
            if channel == line[3]:
                hlsurl = line[2] + RBTV().genWMS()
                break
        return hlsurl, headers

