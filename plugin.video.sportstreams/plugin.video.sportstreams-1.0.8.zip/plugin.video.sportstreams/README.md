<h1>Sport Streams</h1>
<p>
Sportovní přenosy z různých zdrojů:<br><br>

ČT4 Sport Plus (ČT4 Sport + extra přenosy)<br>
TVcom.cz (živé přenosy i archiv různých sportů a soutěží)<br>
Huste.tv (živé přenosy i archiv ze slovenských soutěží)<br>
Volej.tv (přenosy volejbalových soutěží)<br>
Ping-pong.tv (přenosy ze soutěží stolního tenisu)<br>
Ettu.tv (přenosy mezinárodní federace stolního tenisu)<br>
Niké.sk (živé přenosy i archiv ze slovenských soutěží)<p>

v1.0.8 (30.3.2024)<br>
- ošetření chybějících dat u Ettu.tv<br><br>

v1.0.7 (4.3.2023)<br>
- oprava řazení u ČT4 Sport Plus<br>
- oprava chyby s nevyplněným url u budoucích streamů<br><br>

v1.0.6 (14.12.2022)<br>
- úprava huste.tv<br>
- přídání nike.sk<br><br>

v1.0.5 (14.11.2022)<br>
- oprava chyby po přidání Ettu.tv<br><br>

v1.0.4 (12.11.2022)<br>
- přidání Ettu.tv<br><br>
</p>
