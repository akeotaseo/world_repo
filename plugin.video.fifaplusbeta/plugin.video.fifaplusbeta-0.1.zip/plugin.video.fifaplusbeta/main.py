# -*- coding: UTF-8 -*-

from resources.lib.fifa import Fifa

if __name__ == '__main__':
    Fifa()