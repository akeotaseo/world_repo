import xbmc
import xbmcaddon
import json

ADDON = xbmcaddon.Addon()

def notify(title, message, timeout=2000):
    try:
        # Έλεγχος αν ο χρήστης θέλει ειδοποιήσεις
        if ADDON.getSetting('show_notifications') == 'true':
            xbmc.executebuiltin(f'Notification({title}, {message}, {timeout})')
    except:
        pass

class AudioSyncPlayer(xbmc.Player):
    def onAVStarted(self):
        try:
            if ADDON.getSetting('enabled') != 'true':
                return
            
            # Διάρκεια αναμονής από τις ρυθμίσεις (default 6)
            delay_val = ADDON.getSetting('delay')
            xbmc.sleep(int(delay_val) * 1000)
        except:
            xbmc.sleep(6000)

        target_lang = xbmc.getInfoLabel('Window(Home).Property(AudioSync.TargetLang)')
        if not target_lang:
            target_lang = xbmc.getInfoLabel('Container(9143).ListItem.Property(original_language)')

        if not target_lang:
            return

        notify("AudioSync", f"Oiginal Audio Language: {target_lang.upper()}", 1500)

        mapping = {
            'en': ['eng', 'english', 'en-'],
            'el': ['gre', 'ell', 'greek', 'ελληνικά'],
            'it': ['ita', 'italian', 'italiano'],
            'ru': ['rus', 'russian', 'pυσский'],
            'es': ['spa', 'spanish', 'español', 'castilian'],
            'fr': ['fra', 'fre', 'french', 'français'],
            'de': ['deu', 'ger', 'german', 'deutsch'],
            'ja': ['jpn', 'japanese', 'jp-', 'jap', '日本語'],
            'ko': ['kor', 'korean', 'ko-', '한국어'],
            'zh': ['chi', 'zho', 'chinese', '中文'],
            'tr': ['tur', 'turkish', 'türkçe']
        }
        
        search_terms = mapping.get(target_lang.lower(), [target_lang.lower()])

        try:
            rpc_query = {
                "jsonrpc": "2.0",
                "method": "Player.GetProperties",
                "params": {"playerid": 1, "properties": ["audiostreams", "currentaudiostream"]},
                "id": 1
            }
            
            response = xbmc.executeJSONRPC(json.dumps(rpc_query))
            data = json.loads(response)
            
            if 'result' not in data or 'audiostreams' not in data['result']:
                return

            streams = data['result']['audiostreams']
            current = data['result']['currentaudiostream']
            
            idx = current.get('index', 0)
            current_track = streams[idx]
            current_label = (current_track.get('language', '') + current_track.get('name', '')).lower()
            
            if any(term in current_label for term in search_terms):
                notify("AudioSync", f"Already {target_lang.upper()}", 1500)
                return

            for stream in streams:
                name = (stream.get('name', '') + stream.get('language', '')).lower()
                for term in search_terms:
                    if term in name:
                        index = stream.get('index')
                        xbmc.executeJSONRPC(json.dumps({
                            "jsonrpc": "2.0",
                            "method": "Player.SetAudioStream",
                            "params": {"playerid": 1, "stream": index},
                            "id": 1
                        }))
                        notify("AudioSync", f"Switched to {target_lang.upper()}", 2500)
                        return
            
            notify("AudioSync", f"Track {target_lang.upper()} Not Found", 2000)
        except:
            pass

    def onPlayBackStopped(self):
        xbmc.executebuiltin('ClearProperty(AudioSync.TargetLang, home)')

class SyncMonitor(xbmc.Monitor):
    def onSettingsChanged(self):
        global ADDON
        ADDON = xbmcaddon.Addon()

if __name__ == '__main__':
    xbmc.executebuiltin('ClearProperty(AudioSync.TargetLang, home)')
    monitor = SyncMonitor()
    player = AudioSyncPlayer()
    
    while not monitor.abortRequested():
        val = xbmc.getInfoLabel('Container(9143).ListItem.Property(original_language)')
        if val:
            xbmc.executebuiltin(f'SetProperty(AudioSync.TargetLang, {val}, home)')
        if monitor.waitForAbort(0.5):
            break