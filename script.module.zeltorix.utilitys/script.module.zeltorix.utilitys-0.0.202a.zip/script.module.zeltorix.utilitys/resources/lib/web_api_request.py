# -*- coding: utf-8 -*-
# Module: web_api_request
# Author: Zeltorix
# Created on: 2023.09.28
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль запросов
"""

# Стандартные библиотеки
import asyncio
import time
from random import choice
from json import loads
from re import search, findall

# Не стандартные библиотеки
try:
    # Импорт для KODI
    from httpx import Client, AsyncClient, TimeoutException, Response, ConnectError
except ImportError:
    # Импорт для тестирования
    from source.release.packages.resources.lib.httpx import Client, AsyncClient, TimeoutException, Response

user_agents = [
    'Chrome (AppleWebKit/537.1; Chrome50.0; Windows NT 6.3) AppleWebKit/537.36 (KHTML like Gecko) Chrome/51.0.2704.79 Safari/537.36 Edge/14.14393',
    'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.8810.3391 Safari/537.36 Edge/18.14383',
    'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:69.2.1) Gecko/20100101 Firefox/69.2',
    'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:77.0) Gecko/20100101 Firefox/77.0',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML like Gecko) Chrome/46.0.2486.0 Safari/537.36 Edge/13.10586',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML like Gecko) Chrome/51.0.2704.79 Safari/537.36 Edge/14.14931',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.246',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/18.17720',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.19577',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.19582',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Firefox/58.0.1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:99.0) Gecko/20100101 Firefox/99.0',
    'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:39.0) Gecko/20100101 Firefox/75.0',
    'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/58.0',
    'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:64.0) Gecko/20100101 Firefox/64.0',
    'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:70.0) Gecko/20190101 Firefox/70.0',
    'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:70.0) Gecko/20191022 Firefox/70.0',
    'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:77.0) Gecko/20190101 Firefox/77.0',
    'Mozilla/5.0 (Windows NT 6.1; rv:68.7) Gecko/20100101 Firefox/68.7',
    'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML like Gecko) Chrome/46.0.2486.0 Safari/537.36 Edge/13.9200',
    'Mozilla/5.0 (Windows NT 6.2; WOW64; rv:63.0) Gecko/20100101 Firefox/63.0',
    'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:52.59.12) Gecko/20160044 Firefox/52.59.12',
    'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:71.0) Gecko/20100101 Firefox/71.0',
    'Mozilla/5.0 (Windows; U; Windows NT 9.1; en-US; rv:12.9.1.11) Gecko/20100821 Firefox/70',
]

accepts = [
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
]

accept_language = [
    "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    "ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3",
]

referer = [
    "https://yandex.ru/",
    "https://ya.ru/",
    "https://yandex.com/",
    "https://yandex.org/",
    "https://yandex.asia/",
    "https://yandex.com.ru/",
    "https://yandex.net/",
    "https://yandex.eu/",
    "https://yandex.kz/",
    "https://yandex.de/",
    "https://yandex.it/",
    "https://yandex.lv/",
    "https://yandex.fr/",
    "https://yandex.net.ru/",
    "https://yandex.az/",
    "https://yandex.lt/",
    "https://yandex.com.tr/",
    "https://yandex.by/",
    "https://yandex.uz/",
    "https://www.google.com",
    "https://www.google.ac",
    "https://www.google.ad",
    "https://www.google.ae",
    "https://www.google.com.af",
    "https://www.google.com.ag",
    "https://www.google.com.ai",
    "https://www.google.al",
    "https://www.google.am",
    "https://www.google.co.ao",
    "https://www.google.com.ar",
    "https://www.google.as",
    "https://www.google.at",
    "https://www.google.com.au",
    "https://www.google.az",
    "https://www.google.ba",
    "https://www.google.com.bd",
    "https://www.google.be",
    "https://www.google.bf",
    "https://www.google.bg",
    "https://www.google.com.bh",
    "https://www.google.bi",
    "https://www.google.bj",
    "https://www.google.com.bn",
    "https://www.google.com.bo",
    "https://www.google.com.br",
    "https://www.google.bs",
    "https://www.google.co.bw",
    "https://www.google.by/",
    "https://www.google.com.bz",
    "https://www.google.ca",
    "https://www.google.cc",
    "https://www.google.cd",
    "https://www.google.cf",
    "https://www.google.cat",
    "https://www.google.cg",
    "https://www.google.ch/",
    "https://www.google.ci",
    "https://www.google.co.ck",
    "https://www.google.cl",
    "https://www.google.cm",
    "https://www.google.cn",
    "https://www.g.cn",
    "https://www.google.com.co",
    "https://www.google.co.cr",
    "https://www.google.com.cu",
    "https://www.google.cv",
    "https://www.google.com.cy",
    "https://www.google.cz",
    "https://www.google.de/",
    "https://www.google.dj",
    "https://www.google.dk",
    "https://www.google.dm",
    "https://www.google.com.do",
    "https://www.google.dz",
    "https://www.google.com.ec",
    "https://www.google.ee",
    "https://www.google.com.eg",
    "https://www.google.es",
    "https://www.google.com.et",
    "https://www.google.fi",
    "https://www.google.com.fj",
    "https://www.google.fm",
    "https://www.google.fr",
    "https://www.google.ga",
    "https://www.google.ge",
    "https://www.google.gf",
    "https://www.google.gg",
    "https://www.google.com.gh",
    "https://www.google.com.gi",
    "https://www.google.gl",
    "https://www.google.gm",
    "https://www.google.gp",
    "https://www.google.gr",
    "https://www.google.com.gt",
    "https://www.google.gy",
    "https://www.google.com.hk",
    "https://www.google.hn",
    "https://www.google.hr",
    "https://www.google.ht",
    "https://www.google.hu",
    "https://www.google.co.id",
    "https://www.google.iq",
    "https://www.google.ie",
    "https://www.google.co.il",
    "https://www.google.im",
    "https://www.google.co.in",
    "https://www.google.io",
    "https://www.google.is",
    "https://www.google.it",
    "https://www.google.je",
    "https://www.google.com.jm",
    "https://www.google.jo",
    "https://www.google.co.jp",
    "https://www.google.co.ke",
    "https://www.google.com.kh",
    "https://www.google.ki",
    "https://www.google.kg",
    "https://www.google.co.kr",
    "https://www.google.com.kw",
    "https://www.google.kz",
    "https://www.google.la",
    "https://www.google.com.lb",
    "https://www.google.li/",
    "https://www.google.lk",
    "https://www.google.co.ls",
    "https://www.google.lt",
    "https://www.google.lu/",
    "https://www.google.lv",
    "https://www.google.com.ly",
    "https://www.google.co.ma",
    "https://www.google.md",
    "https://www.google.me",
    "https://www.google.mg",
    "https://www.google.mk",
    "https://www.google.ml",
    "https://www.google.com.mm",
    "https://www.google.mn",
    "https://www.google.ms",
    "https://www.google.com.mt",
    "https://www.google.mu",
    "https://www.google.mv",
    "https://www.google.mw",
    "https://www.google.com.mx",
    "https://www.google.com.my",
    "https://www.google.co.mz",
    "https://www.google.com.na",
    "https://www.google.ne",
    "https://www.google.com.nf",
    "https://www.google.com.ng",
    "https://www.google.com.ni",
    "https://www.google.nl",
    "https://www.google.no",
    "https://www.google.com.np",
    "https://www.google.nr",
    "https://www.google.nu",
    "https://www.google.co.nz",
    "https://www.google.com.om",
    "https://www.google.com.pa",
    "https://www.google.com.pe",
    "https://www.google.com.ph",
    "https://www.google.com.pk",
    "https://www.google.pl",
    "https://www.google.com.pg",
    "https://www.google.pn",
    "https://www.google.com.pr",
    "https://www.google.ps",
    "https://www.google.pt",
    "https://www.google.com.py",
    "https://www.google.com.qa",
    "https://www.google.ro",
    "https://www.google.rs",
    "https://www.google.ru",
    "https://www.google.rw",
    "https://www.google.com.sa",
    "https://www.google.com.sb",
    "https://www.google.sc",
    "https://www.google.se",
    "https://www.google.com.sg",
    "https://www.google.sh",
    "https://www.google.si",
    "https://www.google.sk",
    "https://www.google.com.sl",
    "https://www.google.sn",
    "https://www.google.sm",
    "https://www.google.so",
    "https://www.google.st",
    "https://www.google.com.sv",
    "https://www.google.td",
    "https://www.google.tg",
    "https://www.google.co.th",
    "https://www.google.com.tj",
    "https://www.google.tk",
    "https://www.google.tl",
    "https://www.google.tm",
    "https://www.google.to",
    "https://www.google.com.tn",
    "https://www.google.com.tr",
    "https://www.google.tt",
    "https://www.google.com.tw",
    "https://www.google.co.tz",
    "https://www.google.com.ua",
    "https://www.google.co.ug",
    "https://www.google.co.uk",
    "https://www.google.us",
    "https://www.google.com.uy",
    "https://www.google.co.uz",
    "https://www.google.com.vc",
    "https://www.google.co.ve",
    "https://www.google.vg",
    "https://www.google.co.vi",
    "https://www.google.com.vn",
    "https://www.google.vu",
    "https://www.google.ws",
    "https://www.google.co.za",
    "https://www.google.co.zm",
    "https://www.google.co.zw",
    "https://vk.com/"
    "https://vk.ru/"
    "https://dzen.ru/",
    "https://ok.ru/",
    "https://instagram.com/",
    "https://facebook.com/",
    "https://t.me/",
    "https://twitter.com/",
    "https://x.com/",
    "https://www.youtube.com/",
    "https://my.mail.ru",
    "https://pinterest.ru/",
    "https://pinterest.com/",
    "https://web.whatsapp.com/",
    "https://instagram.com/",
]

headers = {
    "Accept": choice(accepts),
    "Accept-Language": choice(accept_language),
    "Cache-Control": "no-cache",
    "Connection": "Keep-Alive",
    "Dnt": "1",  # 1 отказ от отслеживания, 0 разрешения отслеживания, и null (по умолчанию)
    "Pragma": "no-cache",
    "Referer": choice(referer),
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "same-origin",
    "Sec-Fetch-User": "?1",
    "Sec-Gpc": "1",  # 1 отказ от передачи данных третьим лицам, 0 разрешения отслеживания, и null (по умолчанию)
    "Upgrade-Insecure-Requests": "1",  # 1 предпочтения защищенного соединения
    "User-Agent": choice(user_agents),
}


def https_checking(url_check: str, start_url: (str, bool) = False) -> str:
    if url_check.startswith("https"):
        return url_check
    elif url_check.startswith("http"):
        return url_check.replace("http", "https")
    elif url_check.startswith("//"):
        return "https:" + url_check
    elif "." in url_check.split("/")[0]:
        return "https://" + url_check
    elif start_url:
        if start_url in url_check:
            return url_check
        elif url_check.startswith("/"):
            return start_url + url_check
        elif "/" in url_check:
            return f"{start_url}/{url_check}"
    else:
        raise ValueError(f"Неизвестный тип ссылки - {url_check}")


class Proxy:
    __slots__ = []

    @staticmethod
    def antizapret(proxies: bool = False) -> (str, list):
        headers["Accept"] = "application/x-ns-proxy-autoconfig"
        response = WebApiRequest(headers).request_get("cap.yxorp/3448:gro.npvotsorp.terpazitna//:sptth"[::-1])
        if response and type(response) is not dict:
            find_data = findall(r"proxy.*?:\d+", response.text)
            if proxies:
                return {"https://": "https://" + find_data[-2], "http://": "http://" + find_data[-1], }
            else:
                return "https://" + find_data[-2]

    @staticmethod
    def censortracker() -> str:
        headers["Accept"] = "application/x-ns-proxy-autoconfig"
        response = WebApiRequest(headers).request_get("https://app.censortracker.org/api/proxy-config/")
        if response and type(response) is not dict:
            data = response.json()
            return f"https://{data['server']}:{data['port']}"


class WebApiRequest:

    def __init__(self, _headers=None, proxies=None, proxy=None, timeout: int = 8, redirects=True):
        self.redirects = redirects
        if _headers is None:
            _headers = headers
        self._session = Client(
            headers=_headers,
            follow_redirects=redirects,
            timeout=timeout,
        )
        self._session_async = AsyncClient(
            headers=_headers,
            follow_redirects=redirects,
            timeout=timeout,
            http2=True,
        )
        if proxies:
            self._session = Client(
                headers=_headers,
                follow_redirects=redirects,
                timeout=timeout,
                proxies=proxies,
            )
            self._session_async = AsyncClient(
                headers=_headers,
                follow_redirects=redirects,
                timeout=timeout,
                http2=True,
                proxies=proxies,
            )
        if proxy:
            self._session = Client(
                headers=_headers,
                follow_redirects=redirects,
                timeout=timeout,
                proxy=proxy,
            )
            self._session_async = AsyncClient(
                headers=_headers,
                follow_redirects=redirects,
                timeout=timeout,
                http2=True,
                proxy=proxy,
            )

    def request_get(self, link: str, params: dict = None, retry: int = 5) -> (Response, int, None):
        if params is None:
            params: dict = {}
        try:
            response: Response = self._session.get(link, params=params)
            if response.status_code == 200 or response.status_code == 302:
                if response:
                    return response
            elif response.status_code in [403, 404, ]:
                return {
                    "status": "status_code",
                    "status_code": response.status_code,
                    "response": response,
                }
            elif response.status_code in [429, 503, ]:
                if response.headers.get("Retry-after"):
                    time_sleep = int(response.headers["Retry-after"])
                else:
                    time_sleep = 30
                time.sleep(time_sleep)
                return self.request_get(link, params=params, retry=retry - 1)
            else:
                raise ValueError(f"Неизвестный код ответа {response.status_code} {link}")
        except TimeoutException:
            if retry:
                time.sleep(5)
                return self.request_get(link, params=params, retry=retry - 1)
        except ConnectError:
            if retry:
                time.sleep(5)
                return self.request_get(link, params=params, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "ConnectError",
                }
        except Exception as e:
            if retry:
                return self.request_get(link, params=params, retry=retry - 1)
            else:
                raise ValueError(f"Проблемы с получением данных с ссылки {link}\n{e}")

    def request_post(self, link: str, params: dict = None, data: dict = None, retry: int = 10) -> (Response, int, None):
        if params is None:
            params = {}
        if data is None:
            data = {}
        try:
            response: Response = self._session.post(link, data=data, params=params)
            if response.status_code == 200 or response.status_code == 302:
                if response:
                    return response
            elif response.status_code in [403, 404, ]:
                return {
                    "status": "status_code",
                    "status_code": response.status_code,
                    "response": response,
                }
            elif response.status_code in [429, 503, ]:
                if response.headers.get("Retry-after"):
                    time_sleep = int(response.headers["Retry-after"])
                else:
                    time_sleep = 30
                time.sleep(time_sleep)
                return self.request_post(link, params=params, data=data, retry=retry - 1)
            elif response.status_code != 200:
                return self.request_post(link, params=params, data=data, retry=retry - 1)
            else:
                raise ValueError(f"Неизвестный код ответа {response.status_code} {link}")
        except TimeoutException:
            if retry:
                time.sleep(5)
                return self.request_post(link, params=params, data=data, retry=retry - 1)
        except ConnectError:
            if retry:
                time.sleep(5)
                return self.request_post(link, params=params, data=data, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "ConnectError",
                }
        except Exception as e:
            if retry:
                return self.request_post(link, params=params, data=data, retry=retry - 1)
            else:
                raise ValueError(f"Проблемы с получением данных с ссылки {link}\n{e}")

    # async def request_async_get(self, link: str, retry: int = 10):
    #     try:
    #         async with self._session_async as client:
    #             response = await client.get(link)
    #
    #             if response.status_code == 200:
    #                 return response
    #             elif response.status_code == 403:
    #                 return 403
    #             elif response.status_code == 404:
    #                 return 404
    #             elif response.status_code == 429 or response.status_code == 503:
    #                 if response.headers.get("Retry-after"):
    #                     time_sleep = int(response.headers["Retry-after"])
    #                 else:
    #                     time_sleep = 30
    #                 await asyncio.sleep(time_sleep)
    #                 return self.request_async_get(link, retry=retry - 1)
    #             elif response.status_code != 200:
    #                 return self.request_async_get(link, retry=retry - 1)
    #             else:
    #                 raise TypeError(f"Неизвестный код ответа {response.status_code} {link}")
    #     except Exception as e:
    #         if retry:
    #             return self.request_async_get(link, retry=retry - 1)
    #         else:
    #             raise ValueError(f"Проблемы с получением данных с ссылки {link}\n{e}")
    #
    # async def request_async_post(self, link: str, data: dict, retry: int = 10):
    #     try:
    #         async with self._session_async as client:
    #             response = await client.post(link, data=data)
    #             if response.status_code == 200:
    #                 return response
    #             elif response.status_code == 403:
    #                 return 403
    #             elif response.status_code == 404:
    #                 return 404
    #             elif response.status_code == 429 or response.status_code == 503:
    #                 if response.headers.get("Retry-after"):
    #                     time_sleep = int(response.headers["Retry-after"])
    #                 else:
    #                     time_sleep = 30
    #                 await asyncio.sleep(time_sleep)
    #                 return self.request_async_post(link, data, retry=retry - 1)
    #             elif response.status_code != 200:
    #                 return self.request_async_post(link, data, retry=retry - 1)
    #             else:
    #                 raise TypeError(f"Неизвестный код ответа {response.status_code} {link}")
    #     except Exception as e:
    #         if retry:
    #             return self.request_async_post(link, data, retry=retry - 1)
    #         else:
    #             raise TypeError(f"Проблемы с получением данных с ссылки {link}\n{e}")
