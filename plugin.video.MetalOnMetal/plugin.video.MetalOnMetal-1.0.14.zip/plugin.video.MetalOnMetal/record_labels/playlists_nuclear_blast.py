import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_labels


setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="

arrayMenu = ([
            [ "Official Music Videos",  "PLB4brr7vf-P4zaBq7duea0Z9-wwFgMZUK"],           
            [ "All Clips",  "PLB4brr7vf-P7ZXJ0Qw9QayoLxHslFTzvF"],           
            [ "WELCOME TO THE PIT - LIVE!",  "PLB4brr7vf-P7IvKjXn7jOkJ4cCsF6bPd8"],           
            [ "THRASH METAL / SPEED METAL",  "PLB4brr7vf-P4ocoTLNNB-tQEao4T5doxp"],           
            [ "MELODIC METAL / DEATH METAL",  "PLB4brr7vf-P6ZASQYEYp11EKSF3TYe6_c"],           
            [ "POWER METAL / HEAVY METAL / SYMPHONIC METAL",  "PLB4brr7vf-P7aTZXCV5KLPITpP6J4upAG"],           
            [ "HARD ROCK / HEAVY ROCK / ROCK",  "PLB4brr7vf-P6OvedJkPV9SJdFUtIWaB1a"],           
            [ "BLACK METAL / BLACKGAZE / POST-BLACK METAL",  "PLB4brr7vf-P5_yQzIZdlC7xsa3v0XAStE"],           
            [ "HARDCORE / METALCORE & BEYOND",  "PLB4brr7vf-P6jp764WUpP4Tor29yeI6Pt"],           
            [ "FOLK METAL / PAGAN METAL",  "PLB4brr7vf-P5RbZb1oe30-l2maOxOQZtX"],           
            [ "DOOM METAL / SLUDGE METAL / STONER ROCK",  "PLB4brr7vf-P4cjJ5bEca_Nd7kUSbgteSW"],           
            [ "Nuclear Blast Presents: Metal Fan Covers",  "PLB4brr7vf-P6xIgHnat0STHkAzI0VJX5m"]])

def playlists(params):
    logo=logos_labels.nuclear_blast(params)

    for i in range(len(arrayMenu)):
        titulo = arrayMenu[i][0]
        id_canal = arrayMenu[i][1]
        if usa_duffyou:  ##Usamos plugin Duff You
            reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_canal)
            videos = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        else:  ##Usamos plugin YouTube
            videos = youtube.replace("MI-ID-PLAYLIST" , id_canal)
        
        plugintools.add_item( 
            title=titulo,
            url=videos,
            thumbnail=logo, folder=True )

