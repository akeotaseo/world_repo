
THEORIES Player addon for Kodi
======================

About
-----
THEORIES live and on-demand broadcasts

Kodi Addon for http://theories.xxx

This addon is not published nor endorsed by el.gr

This addon offers content available in Greece


Artwork
---------------------
Artwork sourced from public domains:



License
-------
This software is released under the [GPL 3.0 license] [1].

[1]: http://www.gnu.org/licenses/gpl-3.0.html