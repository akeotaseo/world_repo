from .__version__ import VERSION
__version__ = '.'.join(map(str, VERSION))
