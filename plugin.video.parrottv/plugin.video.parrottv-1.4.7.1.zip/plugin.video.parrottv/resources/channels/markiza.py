# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests
import random
import xbmc
import xbmcaddon
_ADDON = xbmcaddon.Addon()

class Markiza:
    def __init__(self):
        self.channels = {
            'markiza': 'https://media.cms.markiza.sk/embed/6EiuEYTfM1m?autoplay=1',
            'doma': 'https://media.cms.markiza.sk/embed/1EzNOAGdOjl?autoplay=1',
            'dajto': 'https://media.cms.markiza.sk/embed/HhDydkbM0h2?autoplay=1',
            'krimi': 'https://media.cms.markiza.sk/embed/5optAOIvjKG?autoplay=1'
        }
        self.ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36'
    
    def genip(self):
        ip = ""
        opt = random.randint(1,5)
        if opt == 1:
            ip = '5.178.'+ str(random.randint(48,63))+'.'+str(random.randint(0,255))
        elif opt == 2:
            ip = '84.47.'+ str(random.randint(0,127))+'.'+str(random.randint(0,255))
        elif opt == 3:
            ip = '91.191.'+ str(random.randint(64,127))+'.'+str(random.randint(0,255))
        elif opt == 4:
            ip = '178.'+ str(random.randint(143,143))+'.'+str(random.randint(0,255))+'.'+str(random.randint(0,255))
        elif opt == 5:
            ip = '178.'+ str(random.randint(40,41))+'.'+str(random.randint(0,255))+'.'+str(random.randint(0,255))
        return ip

    def grab(self, channel):
        headers = {'User-Agent': self.ua}
        ip = Markiza().genip()
        headers.update({'X-Forwarded-For': ip})
        headers.update({'Referer': 'https://videoarchiv.markiza.sk/'})
        if channel not in self.channels: return 'Channel not found'
        url = self.channels[channel]
        r = requests.get(url, headers=headers)
        hlsurl = ""
        while True:
            try:
                hlsurl = r.text.split('processAdTagModifier({"tracks":{"HLS":[{"src":"')[1].split('","')[0].replace('\/','/')
                xbmc.log("[{name}] Markiza: Using IP: {ip}".format(name=_ADDON.getAddonInfo("name"), ip=ip), xbmc.LOGINFO)
                break
            except:
                xbmc.log("[{name}] Markiza: IP Address: {ip} was blocked by markiza.sk".format(name=_ADDON.getAddonInfo("name"), ip=ip), xbmc.LOGERROR)
                ip = Markiza().genip()
                headers.update({'X-Forwarded-For': ip})
                r = requests.get(url, headers=headers)
        headers.update({'Referer': url})
        return hlsurl, headers
