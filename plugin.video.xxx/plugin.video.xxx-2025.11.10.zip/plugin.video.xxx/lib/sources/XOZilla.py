import re
import xbmcaddon
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

BaseURL = 'https://www.xozilla.com'
Thumb   = 'special://home/addons/plugin.video.xxx/resources/art/xozilla.png'

def Menu():
	addDir('Latest Videos',      BaseURL + '/latest-updates/', 101, Thumb)
	addDir('Most Viewed Videos', BaseURL + '/most-popular/',   101, Thumb)
	addDir('Top Rated Videos',   BaseURL + '/top-rated/',      101, Thumb)
	addDir('Categories',         BaseURL + '/categories/',     102, Thumb)
	addDir('Channels',           BaseURL + '/channels/',       102, Thumb)

def Browse(url):
	r = OpenURL(url)
	r = r.replace('\n', '')
	r = r.replace('	', '')
	m = re.compile('<a href="(.+?)" class="item "                                                  vthumb=".+?">    <div class="mobile-preview"></div><div class="img ithumb"><img class="thumb lazy-load" src=".+?" data-original="(.+?)" alt="(.+?)"  thumb=".+?" width=".+?" height=".+?"/>.+?<div class="duration">(.+?)</div> --></div><strong class="title">.+?</strong></a>').findall(r)
	for url, thumb, title, time in m:
		time  = time.replace('m', '').replace('s', '')
		if Setting('show_time') == 'true': title = '[B](%s)[/B] %s' % (time, title)
		url = '%s&random_id=%s' % (url, RandomID())
		if time.startswith('19:'): pass
		elif time.startswith('18:'): pass
		elif time.startswith('17:'): pass
		elif time.startswith('16:'): pass
		elif time.startswith('15:'): pass
		elif time.startswith('14:'): pass
		elif time.startswith('13:'): pass
		elif time.startswith('12:'): pass
		elif time.startswith('11:'): pass
		elif time.startswith('10:'): pass
		elif time.startswith('9:'): pass
		elif time.startswith('8:'): pass
		elif time.startswith('7:'): pass
		elif time.startswith('6:'): pass
		elif time.startswith('5:'): pass
		elif time.startswith('4:'): pass
		elif time.startswith('3:'): pass
		elif time.startswith('2:'): pass
		elif time.startswith('1:'): pass
		else: addVideo(title, url, 103, thumb)
	n = re.compile('<li class="next"><a href="(.+?)" ').findall(r)
	for NextPage in n:
		addDir('Next page >', BaseURL + NextPage, 101, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	Common.SetView()

def Categories(url):
	r = OpenURL(url)
	r = r.replace('\n', '')
	r = r.replace('	', '')
	m = re.compile('<a class="item" href="(.+?)" title="(.+?)"><div class="img"><img class="thumb" src="(.+?)" alt="').findall(r)
	for url, title, thumb in m:
		addDir(title, url, 101, thumb)
	
	n = re.compile('arrow-next"><a href="(.+?)"').findall(r)
	for NextPage in n:
		addDir('Next page >', BaseURL + NextPage, 102, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	
def PlayStream(url):
	if 'random_id=' in url: url = re.compile('(.+?)&random_id').findall(url)[0]
	r = OpenURL(url)
	try: video = re.compile('video_alt_url: \'(.+?)\'').findall(r)[0]
	except: video = re.compile('video_url: \'(.+?)\'').findall(r)[0]
	Play(video)

def RandomID():
	import random
	random_id = str(random.randint(0,1000000))
	return random_id