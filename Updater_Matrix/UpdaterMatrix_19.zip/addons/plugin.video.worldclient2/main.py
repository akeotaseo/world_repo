import urllib.request
import xbmcgui
import xbmcaddon
import xbmcplugin
import re
import sys
import urllib.parse

addon = xbmcaddon.Addon()
m3u_url = addon.getSetting("m3u_url")

def parse_m3u_playlist(url):
    try:
        response = urllib.request.urlopen(url)
        lines = response.read().decode('utf-8').splitlines()

        categories = {}
        current_category = None

        for line in lines:
            line = line.strip()
            if line.startswith("#EXTINF:"):
                channel_info = re.search(r'tvg-name="([^"]+)" tvg-logo="([^"]+)" group-title="([^"]+)"', line)
                if channel_info:
                    current_category = channel_info.group(3)
                    if current_category not in categories:
                        categories[current_category] = []
                else:
                    current_category = None
            elif line.startswith("http") and current_category:
                channel_name = channel_info.group(1)
                channel_logo = channel_info.group(2)
                channel_url = line.strip()
                categories[current_category].append({"name": channel_name, "logo": channel_logo, "url": channel_url})

        return categories
    except urllib.error.URLError:
        xbmcgui.Dialog().ok("Error", "This list has stopped working. Choose another list.")
        return {}

def run():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get("action", None)
    category = params.get("category", None)

    if not action:
        categories = parse_m3u_playlist(m3u_url)
        for category in categories.keys():
            list_item = xbmcgui.ListItem(label="[B][COLOR deepskyblue]{}[/COLOR][/B]".format(category))
            url = "{}?action=list_channels&category={}".format(sys.argv[0], urllib.parse.quote(category))
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif action == "list_channels" and category:
        categories = parse_m3u_playlist(m3u_url)
        channels = categories.get(urllib.parse.unquote(category), [])
        for channel in channels:
            list_item = xbmcgui.ListItem(label="[COLOR deepskyblue]{}[/COLOR]".format(channel["name"]))
            list_item.setInfo("video", {"title": channel["name"]})
            list_item.setArt({"thumb": channel["logo"]})
            url = channel["url"]
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

if __name__ == "__main__":
    run()
