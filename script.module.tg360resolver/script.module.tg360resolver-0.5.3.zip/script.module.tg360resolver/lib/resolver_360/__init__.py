from resolver_360.thegroove_sport_resolver import SportResolver
import logging
import xbmcaddon

logger = logging.getLogger(xbmcaddon.Addon().getAddonInfo('id'))

def resolve(url):
    sr = SportResolver(url)
    sr.find_page_src()

    if sr.resolved:
        print("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS")
        logger.debug(sr.resolved_urls)
        return sr.resolved_urls

    return None
