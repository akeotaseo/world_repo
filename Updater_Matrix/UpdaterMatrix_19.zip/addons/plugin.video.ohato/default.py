import requests
import json
import urllib
import xbmc
import xbmcgui
import xbmcplugin
import resolveurl
import xbmcaddon  # Import to handle addon settings
import sys
import time
import unicodedata
from collections import defaultdict

BASE_API_URL = "https://oha.to/web-vod/api/"
HANDLE = int(sys.argv[1])

# Initialize the addon to access settings
ADDON = xbmcaddon.Addon()

##### HEADERS #####
HEADERS = {
    'api-key': 'ov262WdL5UdUUz4mwsOKLCFy3mLmLKXiN3Yz',
    'Accept': '*/*',
    'Accept-Encoding': 'gzip, deflate, br, zstd',
    'Accept-Language': 'ro-RO,ro;q=0.6',
    'Cache-Control': 'no-cache',
    'Content-Type': 'application/json; charset=utf-8',
    'Pragma': 'no-cache',
    'Referer': 'https://oha.to/',
    'Sec-CH-UA': '"Brave";v="129", "Not=A?Brand";v="8", "Chromium";v="129"',
    'Sec-CH-UA-Mobile': '?0',
    'Sec-CH-UA-Platform': '"Linux"',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-GPC': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36'
}

##### LOGOS #####
def load_json_data_from_url(url):
    try:
        response = requests.get(url)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        xbmc.log(f"Failed to load JSON from {url}: {e}", xbmc.LOGERROR)
        return {}

CHANNEL_LOGOS = load_json_data_from_url('https://derzis.xyz/channel_logos.json')
COUNTRY_LOGOS = load_json_data_from_url('https://derzis.xyz/country_logos.json')
DEFAULT_LOGO = "https://github.com/lipis/flag-icons/blob/main/flags/4x3/un.svg?raw=true"

##### CACHE #####
CACHE = {
    'countries': None,
    'channels': {}  # Format: { 'normalized_country_name': [channel_list] }
}

##### FUNCTIONS #####
def get_logo_url(channel_id, country):
    channel_logo_url = DEFAULT_LOGO
    try:
        channel_logo_entry = next((entry for entry in CHANNEL_LOGOS if entry['id'] == channel_id), None)
        if channel_logo_entry and 'logo' in channel_logo_entry:
            channel_logo_url = channel_logo_entry['logo']
        else:
            country_logo_entry = next((entry for entry in COUNTRY_LOGOS if normalize_string(entry['country']) == country), None)
            channel_logo_url = country_logo_entry['logo'] if country_logo_entry else DEFAULT_LOGO

        if not channel_logo_url or not channel_logo_url.startswith("http"):
            channel_logo_url = DEFAULT_LOGO
    except Exception as e:
        xbmc.log(f"Error getting logo for channel ID {channel_id}: {e}", xbmc.LOGERROR)
        channel_logo_url = DEFAULT_LOGO

    return channel_logo_url

def build_url(query):
    return sys.argv[0] + '?' + urllib.parse.urlencode(query)

def normalize_string(input_string):
    # Normalize unicode string to remove accents and convert to lowercase
    if input_string:
        normalized = unicodedata.normalize('NFKD', input_string)
        return ''.join([c for c in normalized if not unicodedata.combining(c)]).lower().strip()
    return ''

def fetch_tv_channels():
    if CACHE['countries'] is not None:
        xbmc.log("Using cached countries data.", xbmc.LOGDEBUG)
        return CACHE['countries']
    try:
        response = requests.get('https://derzis.xyz/channels.json')
        response.raise_for_status()
        json_data = response.json()
        if isinstance(json_data, list):
            CACHE['countries'] = json_data
            xbmc.log(f"Fetched and cached {len(json_data)} TV channels.", xbmc.LOGINFO)
            return json_data
    except requests.HTTPError as e:
        xbmc.log(f"Error fetching TV channels: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", "Failed to fetch TV channels.")
    return []

def display_countries(channels):
    if channels:
        country_channels = {}
        for channel in channels:
            country = channel.get('country', 'Unknown')

            # Normalize country names to ensure consistency
            normalized_country = normalize_string(country)

            if normalized_country not in country_channels:
                country_channels[normalized_country] = []
            country_channels[normalized_country].append(channel)

        CACHE['channels'] = country_channels  # Cache the channels by normalized country
        xbmc.log(f"Countries cached: {list(country_channels.keys())}", xbmc.LOGDEBUG)

        sorted_countries = sorted(country_channels.keys(), key=lambda x: x.capitalize())
        if 'romania' in sorted_countries:
            sorted_countries.remove('romania')
            sorted_countries.insert(0, 'romania')

        for country in sorted_countries:
            country_display_name = country.capitalize()
            country_logo_entry = next((entry for entry in COUNTRY_LOGOS if normalize_string(entry['country']) == country), None)
            country_logo_url = country_logo_entry['logo'] if country_logo_entry else DEFAULT_LOGO

            url = build_url({'action': 'list_channels', 'country': country_display_name})
            li = xbmcgui.ListItem(country_display_name)
            li.setArt({'icon': country_logo_url, 'thumb': country_logo_url})
            li.setProperty('IsPlayable', 'false')
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(HANDLE)
    else:
        xbmcgui.Dialog().notification("Error", "No TV channels data available.")

def list_channels_by_country(country):
    # Normalize the input country name to match cache keys
    normalized_country = normalize_string(country)
    xbmc.log(f"Attempting to list channels for normalized country: {normalized_country}", xbmc.LOGINFO)

    # Check if channels for this country are already cached
    if normalized_country not in CACHE['channels']:
        xbmc.log(f"Caching channels for the first time for country: {normalized_country}", xbmc.LOGINFO)
        cache_country_channels(normalized_country)

    # Confirm that channels are now cached
    if normalized_country in CACHE['channels']:
        country_channels = CACHE['channels'][normalized_country]
        xbmc.log(f"Found {len(country_channels)} channels for {normalized_country} in cache.", xbmc.LOGDEBUG)
    else:
        xbmc.log(f"No channels found for {normalized_country} in cache after caching attempt.", xbmc.LOGERROR)
        return

    if country_channels:
        grouped_channels = group_channels_by_name(country_channels)
        display_grouped_channels(grouped_channels, country)

def group_channels_by_name(channels):
    grouped = defaultdict(list)
    for channel in channels:
        normalized_name = normalize_string(channel.get('name', 'Unknown Channel'))
        grouped[normalized_name].append(channel)
    return grouped

def display_grouped_channels(grouped_channels, country):
    auto_play_first_source = ADDON.getSettingBool('auto_play_first_source')  # Check user setting

    for normalized_name, channels in grouped_channels.items():
        # Use the first channel to determine the display name
        display_name = channels[0].get('name', 'Unknown Channel')
        logo_url = get_logo_url(channels[0].get('id'), country)

        # If there's more than one source for the channel
        if len(channels) > 1:
            if auto_play_first_source:
                # Automatically play the first source if setting is enabled
                initial_url = f"https://oha.to/play/{channels[0]['id']}/index.m3u8"
                url = build_url({'action': 'play_tv', 'initial_url': initial_url})
            else:
                # Create a menu to choose between sources
                url = build_url({'action': 'choose_source', 'channels': json.dumps([c['id'] for c in channels]), 'name': display_name})
        else:
            # Directly play the single source
            initial_url = f"https://oha.to/play/{channels[0]['id']}/index.m3u8"
            url = build_url({'action': 'play_tv', 'initial_url': initial_url})

        li = xbmcgui.ListItem(display_name)
        li.setArt({'icon': logo_url, 'thumb': logo_url, 'fanart': logo_url})
        li.setProperty('IsPlayable', 'true' if len(channels) == 1 or auto_play_first_source else 'false')
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=len(channels) > 1 and not auto_play_first_source)

    xbmcplugin.endOfDirectory(HANDLE)

def cache_country_channels(normalized_country):
    # Fetch TV channels data
    channels = fetch_tv_channels()

    # Group channels by country if not already cached
    if channels:
        country_channels = {}
        for channel in channels:
            country = channel.get('country', 'Unknown')
            norm_country = normalize_string(country)

            if norm_country not in country_channels:
                country_channels[norm_country] = []
            country_channels[norm_country].append(channel)

        # Update the global cache with the fetched channels
        CACHE['channels'].update(country_channels)
        xbmc.log(f"Channels cached for countries: {list(country_channels.keys())}", xbmc.LOGDEBUG)

def play_tv_channel(initial_url):
    final_url = follow_redirect(initial_url)
    if final_url:
        play_video(final_url)

def follow_redirect(url):
    try:
        with requests.Session() as session:
            response = session.get(url, allow_redirects=True)
            response.raise_for_status()
            return response.url
    except requests.RequestException as e:
        xbmc.log(f"Error following redirect: {e}", xbmc.LOGERROR)
        return None

def play_video(url):
    li = xbmcgui.ListItem(path=url)
    li.setProperty('IsPlayable', 'true')
    li.setMimeType('video/x-mpegURL')
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

def sanitize_title(title):
    return title.split("|")[0].strip()

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get('action')

    if action is None:
        data = fetch_tv_channels()
        display_countries(data)
    elif action == 'list_channels':
        country = params.get('country')
        xbmc.log(f"Received request to list channels for country: {country}", xbmc.LOGINFO)
        if country:
            list_channels_by_country(country)
    elif action == 'choose_source':
        # Handle menu to choose between different sources for a grouped channel
        channels = json.loads(params.get('channels', '[]'))
        name = params.get('name', 'Unknown Channel')
        for channel_id in channels:
            initial_url = f"https://oha.to/play/{channel_id}/index.m3u8"
            li = xbmcgui.ListItem(f"{name} (Source {channel_id})")
            li.setProperty('IsPlayable', 'true')
            li.setArt({'icon': DEFAULT_LOGO, 'thumb': DEFAULT_LOGO, 'fanart': DEFAULT_LOGO})
            url = build_url({'action': 'play_tv', 'initial_url': initial_url})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

        xbmcplugin.endOfDirectory(HANDLE)
    elif action == 'play_tv':
        initial_url = params.get('initial_url')
        if initial_url:
            play_tv_channel(initial_url)

if __name__ == '__main__':
    router(sys.argv[2][1:])
