﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def HomeWidgetON():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Απενεργοποίηση HomeWidget[/COLOR]', 'Απενεργοποίηση HomeWidget.[CR]Για να συνεχίσετε πατήστε [B][COLOR red]HomeWidget Off[/COLOR][/B][CR]και περιμένετε...',
                                        nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR red]HomeWidget OFF[/COLOR][/B]')

        if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_100.py")'),]

HomeWidgetON()