import os, xbmc, xbmcvfs, xbmcgui


def FixArrowRepo():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Fix Arrow Repo[/COLOR]', 'Επιλέξτε [COLOR green]version 2.0[/COLOR][CR]Στην επόμενη εκκινηση του  build το [COLOR green]repository.arrownegra[/COLOR] θα πάρει την τελευταία ενημέωση.',
                                        nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR green]version 2.0[/COLOR][/B]')

        if choice == 1: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/resources/InstallAutowidget.py")')


FixArrowRepo()
