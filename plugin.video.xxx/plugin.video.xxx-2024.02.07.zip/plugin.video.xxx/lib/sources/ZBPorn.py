import re
import xbmcaddon
import random
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

BaseURL = 'https://zbporn.com'
Thumb   = 'special://home/addons/plugin.video.xxx/resources/art/zbporn.png'


def Menu():
	addDir('Latest Videos',      BaseURL + '/latest-updates/', 51, Thumb)
	addDir('Most Viewed Videos', BaseURL + '/most-popular/',   51, Thumb)
	addDir('Top Rated Videos',   BaseURL + '/top-rated/',      51, Thumb)
	#addDir('Channels',           BaseURL + '/channels/',       54, Thumb)
	addDir('Categories',         BaseURL + '/categories/',     52, Thumb)

def Browse(url):
	r = OpenURL(url)
	r = r.replace('\n', '')
	r = r.replace('    ', '')
	m = re.compile('<a class="th"(.+?)</div>').findall(r)
	for i in m:
		url   = re.compile('href="(.+?)"').findall(i)[0]
		title = re.compile('title="(.+?)"').findall(i)[0]
		try: thumb = re.compile('img src="(.+?)"').findall(i)[0]
		except: thumb = None
		try: time  = re.compile('<span class="th-duration">(.+?)</span>').findall(i)[0]
		except: time = None
		random_id = random.randint(0,1000000)
		if '/categories/' in url: pass
		elif '/models/' in url: pass
		elif '/performers/' in url: pass
		else: addVideo(title, url + '&random_id=' + str(random_id), 53, thumb)
	n = re.compile('<a class="item" href="(.+?)" title="Next">').findall(r)
	for NextPage in n:
		addDir('Next page >', BaseURL + NextPage, 51, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	Common.SetView()
	
def Categories(url):
	r = OpenURL(url)
	m = re.compile('<a class="th" href="https://zbporn\.com/categories/(.+?)/" title="(.+?)">').findall(r)
	for content_id, title in m:
		addDir(title, 'https://zbporn.com/categories/%s/' % content_id, 51, Thumb)
	n = re.compile('<li class="item-pagin is_last">\n						<a class="link" href="(.+?)"').findall(r)
	for NextPage in n:
		addDir('Next page >', BaseURL + NextPage, 52, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
		
def Channels(url):
	r = OpenURL(url)
	m = re.compile('<a class="th" href="(.+?)">\n				<div class=".+?">\n											<img class="lazyload" src=".+?" data-src="(.+?)" alt="(.+?)">').findall(r)
	for url, thumb, title in m:
		addDir(title, url, 51, thumb)
	
def PlayStream(url):
	if 'random_id=' in url:
		url = re.compile('(.+?)&random_id').findall(url)[0]
	r = OpenURL(url)
	m = re.compile('video_url: \'(.+?)\'').findall(r)
	for url in m:
		Play(url)
