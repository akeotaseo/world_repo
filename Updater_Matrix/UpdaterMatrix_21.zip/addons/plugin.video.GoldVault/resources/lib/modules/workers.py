# -*- coding: utf-8 -*-
#      __    ____  ____  _   _____  _____________________
#     / /   / __ \/ __ \/ | / /   |/_  __/  _/ ____/ ___/
#    / /   / / / / / / /  |/ / /| | / /  / // /    \__ \
#   / /___/ /_/ / /_/ / /|  / ___ |/ / _/ // /___ ___/ /
#  /_____/\____/\____/_/ |_/_/  |_/_/ /___/\____//____/
#

from threading import Thread as thread

class Thread(thread):
	def __init__(self, target, *args):
		self._target = target
		self._args = args
		thread.__init__(self, target=self._target, args=self._args)