﻿import xbmc

def audioflow():
  #  xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin("ActivateWindowAndFocus(osdaudiosettings)")
    xbmc.executebuiltin("Action(Pause)")
    xbmc.sleep(500)
    xbmc.executebuiltin('SendClick(-76)')
    while xbmc.getCondVisibility("Window.IsVisible(osdaudiosettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")

audioflow()
