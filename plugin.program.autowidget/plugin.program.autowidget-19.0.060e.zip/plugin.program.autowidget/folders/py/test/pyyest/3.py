﻿import xbmc



xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sporthdme/?description&iconimage=C%3a%5cPortableApps%5ckodi%5cMy%20kodi%5cKodi%5cportable_data%5caddons%5cplugin.video.sporthdme%5cicon.png&mode=5&name=%5bB%5d%5bCOLOR%20white%5dLIVE%20EVENTS%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2f1.livesoccer.sx%2f",return)')