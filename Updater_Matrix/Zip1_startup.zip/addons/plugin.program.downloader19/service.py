﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcvfs
from updatervar import *
from resources.lib.modules import check

from xbmc import executebuiltin
from xbmcaddon import Addon
from os.path import exists,join
from os import makedirs
from xbmcvfs import translatePath


xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":1}}')
xbmc.sleep(5000)



if __name__ == '__main__':
	if not setting('updaterversion') == 'false':

		dialog.notification(Dialog_welcome, Dialog_Update, icon_Build, sound=False)
		xbmc.sleep(5000)

		check.notifyT()
		check.updater()  #downloader_startup#
		check.autoenable()
		check.var()
		check.delete()
		check.installation()
		check.players()
		check.zip1()
		check.zip2()
		check.zip3()
		check.zip4()
		check.zip5()
		check.pvr()
		check.setsetting()
		check.database()
		check.xmlskin()
		check.UpdateAddonRepos()



	else:
		dialog.notification(Dialog_welcome, Dialog_not_Updater, icon_Build, sound=False)
		check.UpdateAddonRepos()

	xbmc.sleep(1000)
	xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/Tools/ArtistslideshowCleanUp.py")')



	pack = translatePath('special://home/addons/packages')
	monitor = xbmc.Monitor()

	while not monitor.abortRequested():
		if monitor.waitForAbort(2*60*60):#διάστημα 2ωρών μεταξύ των ενημερώσεων
			break
		xbmc.executebuiltin('UpdateAddonRepos()')
		dialog.notification('Υπηρεσία ενημέρωσης', 'Εκκίνηση ενημερώσεων προσθέτων', icon_auto, sound=False)
		xbmcvfs.delete('special://home/addons/plugin.video.vnmedia/service.py')
		if not exists(pack):
			makedirs(pack)
		packfolders = 'packages'