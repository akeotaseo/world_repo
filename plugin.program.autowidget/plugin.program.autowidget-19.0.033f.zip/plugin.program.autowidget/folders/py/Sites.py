import xbmc, xbmcgui


def sites():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]       Pair Sites[/COLOR][/B]', 
['[B][COLOR=white]                               GKoBu [COLOR=orange]Pair Hosts [/COLOR][/B]',
 '[B][COLOR=white]                                           [COLOR=blue]Sites[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




#def click_1():
#    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.apex_sports/?category=live_sport&amp;mode=search)')
#    xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology[/COLOR][/B]",'[COLOR white]Για την αναζήτηση αγώνων, πληκτρολογήστε την Ομάδα ή την Χώρα με λατινικούς χαρακτήρες ...[/COLOR]' , icon ='special://home/addons/skin.TechNEWSology/icon.png')

def click_1():
    xbmc.executebuiltin('RunAddon(script.gkobu.pairwith)')

def click_2():
    xbmc.executebuiltin('RunAddon(script.sites)')

sites()
