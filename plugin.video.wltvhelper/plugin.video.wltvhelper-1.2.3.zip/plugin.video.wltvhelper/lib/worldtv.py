# Module: WorldLiveTV
# Author: CrAcK75
# Created on: 06/05/2021
#

import os
import sys
import xbmcgui, xbmcplugin, json
import requests
import routing

from typing import List
from lib import logger, config, utils
from lib.m3u.m3uitem import M3UItem
from lib.m3u.m3uparser import M3UParser, M3UStreamType

TEMP_LISTFILE_NAME = "~temp.dat"
fileName = "listIntChannels.bin"
plugin = routing.Plugin()


@plugin.route("/worldtv")
def Start():
    ShowContinentsList()


def ShowContinentsList():
    handle = plugin.handle
    xbmcplugin.setPluginCategory(handle, "International TVs")

    lstItem = GetLists()
    if not lstItem:
        return

    for item in lstItem.get("worlditems", {}):
        name = item["name"]
        code = item["code"]
        utils.addMenuItem(handle, name, plugin.url_for(ShowCountries, code), "world", code)

    xbmcplugin.endOfDirectory(handle)


@plugin.route("/worldtv/showcountries/<continentcode>")
def ShowCountries(continentcode):
    handle = plugin.handle
    xbmcplugin.setPluginCategory(handle, continentcode)

    lstItem = GetLists()
    lstItem = GetItems(continentcode, lstItem)
    for item in lstItem.get("worlditems", {}):
        code = item["code"]
        name = item["name"]
        url = item["url"]

        if code == "it":
            continue

        utils.addMenuItem(handle, name, plugin.url_for(SwitchList, name, url), "flags", code, fanart="background.png")

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(handle, True)


@plugin.route("/worldtv/switchlist/<name>/<code>")
def SwitchList(name, code):
    handle = plugin.handle
    url = utils.fromBase64(code)

    if handle == -1:
        utils.setListInt(name, url, "")
    else:
        m3u = M3UParser(logger)
        m3u.exclusion = ["51.52.156.22:8888"]
        m3u.loadM3U(url, utils.getPersonalPathFile(TEMP_LISTFILE_NAME))

        CreateListItems(name, m3u.getItems(M3UStreamType.LIVE))


def CreateListItems(name, listitems: List[M3UItem]):
    handle = plugin.handle
    xbmcplugin.setPluginCategory(handle, name)
    xbmcplugin.setContent(handle, "videos")

    imagedir = ""
    for item in listitems:
        utils.addMenuItemVideoM3U(handle, item)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(handle)


def GetItems(code, lstItem):
    lstItem = [x for x in lstItem.get("worlditems", {}) if x["code"] == code][0]
    return lstItem


def GetLists():
    strJson = ""

    try:
        strJson = utils.decompressFile(fileName)
        strJson = json.loads(strJson)
    except Exception as e:
        strJson = ""
        logger.error("GetLists error:", e)

    if strJson == "":
        utils.MessageNotification(config.getString(30148))

    return strJson


plugin.run()
