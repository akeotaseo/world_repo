import os, xbmc, xbmcgui, glob, shutil
from updatervar import *

def tools_menu():
    funcs = (click1, click2, click3, click4, click5, click6, click7, click8, click9, click10, click11, click12, click13, click14, click15,
             click16, click17, click18, click19, click20)
    selection = xbmcgui.Dialog().select('[B][COLOR=orange]                                           ~ Εργαλεία ~[/COLOR][/B]', 
['[B][COLOR=white]Έλεγχος Αναβάθμισης Πρόσθετων ...[/COLOR][/B]',
 '[B][COLOR=white]Αν δεν εμφανίζονται τα Widgets ή τα Εικονίδια ...[/COLOR][/B]',
 '[B][COLOR=white]Καλύτερο streaming στο Βίντεο ...[/COLOR][/B]',
 '[B][COLOR=white]Εγκατάσταση Binary Addons[/COLOR][/B]',
 '[B][COLOR=white]Επιλογή Api Key [COLOR red]YouTube[/COLOR][/B]',
 '[B][COLOR=white]Διαγραφή PVR Stalker[/COLOR][/B]',
 '[B][COLOR=white]=Επαναφορά αρχικού μενού[/COLOR][/B]',
 '[B][COLOR=white]=Εξουσιοδότηση [COLOR lime]Trakt ...[/COLOR][/B]',
 '[B][COLOR=white]Authorize-Reset [COLOR lime]Derbid...[/COLOR][/B]',
 '[B][COLOR=white]Εργαλεία G.K.N.Wizard[/COLOR][/B]',
 '[B][COLOR=white]Διαγραφή Indigo...[/COLOR][/B]',
 '[B][COLOR=lime]Καθαρή Εγκατάσταση Build[/COLOR][/B]',
 '[B][COLOR=white]G.K.N.Wizard[/COLOR][/B]',
 '[B][COLOR=white]Αφαίρεση πρόσθετων[/COLOR][/B]',
 '[B][COLOR=white]Καθαρισμός παρόχων-Cache[/COLOR][/B]',
 '[B][COLOR=white]Save Data[/COLOR][/B]',
 '[B][COLOR=white]Reload Skin[/COLOR][/B]',
 '[B][COLOR=white]Enable/Disable Addons[/COLOR][/B]',
 '[B][COLOR=white]Speed Test[/COLOR][/B]',
 '[B][COLOR=white]Εργαλεία AliveGR[/COLOR][/B]'])

    if selection:
        if selection < 0:
            return
        func = funcs[selection-20]
        return func()
    else:
        func = funcs[selection]
        return func()
    return 


def click1():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=kodi17fix)')

def click2():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=fullclean)')
    xbmc.sleep(15000)
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=convertpath)')
    xbmc.sleep(10000)
    xbmc.executebuiltin("ReloadSkin()")

def click3():
        choice = xbmcgui.Dialog().yesno('TechNEWSology Tools', '[COLOR white]Για να επιτύχουμε καλύτερο streaming του Βίντεο, αλλάζουμε την τιμή στο Video Cache size από αυτήν που έχει μπαίνοντας στο *Advanced Settings Configurator* σε 120 μέχρι 150! Μετά πατάμε Write File και κάνουμε επανεκκίνηση το Kodi για να καταχωρηθούν οι αλλαγές! [B][COLOR red]Tip:[/COLOR][/B] [COLOR white]Για καλύτερο buffering πατάμε παύση [COLOR lime](||)[COLOR white] στην Έναρξη του Βίντεο για μερικά λεπτά.[/COLOR]',
                                        nolabel='[COLOR red]Άκυρο[/COLOR]',yeslabel='[COLOR lime]Advanced Settings[/COLOR]')

        if choice == 1: xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=autoadvanced)')

def click4():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?mode=16,return)')

def click5():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.downloader19/?mode=1,return)')

def click6():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]TechNEWSology[/COLOR][/B]', '[COLOR white]            Επιθυμείτε την διαγραφή του PVR Stalker ?[/COLOR]',
                                        nolabel='[COLOR orange]Άκυρο[/COLOR]',yeslabel='[COLOR lime]Διαγραφή[/COLOR]')

        if choice == 1: [xbmc.executebuiltin("Action(Close)"), xbmc.sleep(1000), xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}'),
                         xbmc.sleep(5000), xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')]
        base_path = xbmc.translatePath('special://home/addons')
        dir_list = glob.iglob(os.path.join(base_path, "pvr.stalker"))
        for path in dir_list:
            if os.path.isdir(path):
                shutil.rmtree(path)
            if os.path.exists(base_path): xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology[/COLOR][/B]", "[COLOR white]Το PVR Stalker αφαιρέθηκε με επιτυχία![/COLOR]", icon='special://skin/icon.png')

def click7():
    xbmc.executebuiltin("Action(Close)"),
    xbmc.sleep(1000)
    xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin(Backgrounds_With_Widgets)
    xbmc.sleep(5000)
    xbmc.executebuiltin(skinshortcuts_menu)
    xbmcgui.Dialog().notification("[B][COLOR orange]Επαναφόρτωση του προφίλ...[/COLOR][/B]",'[COLOR white]Πάγωμα εικόνας - Αναμονή προς ολοκλήρωση.[/COLOR]' , icon_Build)
    xbmc.sleep(10000)
    xbmc.executebuiltin("LoadProfile(Master user)")

def click8():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.theoath/?action=authTrakt)')

def click9():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?mode=24,return)')

def click10():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.G.K.N.Wizard/?mode=maint,return)')

def click11():
    base_path = xbmc.translatePath('special://home/addons')
    dir_list = glob.iglob(os.path.join(base_path, "plugin.program.indigo"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)

    base_path = xbmc.translatePath('special://home/userdata/addon_data')
    dir_list = glob.iglob(os.path.join(base_path, "plugin.program.indigo"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)

    base_path = xbmc.translatePath('special://home/addons')
    dir_list = glob.iglob(os.path.join(base_path, "script.tvaddons.debug.log"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)

    xbmcgui.Dialog().ok("[COLOR orange]TechNEWSology Updater-Tools[/COLOR]", "[COLOR white]Bye Bye --> plugin.program.indigo[/COLOR]")

def click12():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.downloader19/?mode=12,return)')

def click13():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.G.K.N.Wizard)')

def click14():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=removeaddons)')

def click15():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=clearcache)')

def click16():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.G.K.N.Wizard/?mode=savedata)')

def click17():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceskin)')

def click18():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.G.K.N.Wizard/?mode=enableaddons,return)')

def click19():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.G.K.N.Wizard/?mode=speedtest,return)')

def click20():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.AliveGR/?click=settings,return)')


tools_menu()
