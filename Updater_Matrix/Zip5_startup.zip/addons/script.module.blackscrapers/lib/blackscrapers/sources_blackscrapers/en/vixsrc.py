# -*- coding: utf-8 -*-
import re
import json
from blackscrapers import parse_qs, urlencode
from blackscrapers.modules import client
from blackscrapers.modules import log_utils

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domain = ['vixsrc.to']
        self.base_link = 'https://vixsrc.to'
        self.headers = {'User-Agent': client.agent()}

    def movie(self, imdb, tmdb, title, localtitle, aliases, year):
        try:
            # Εδώ το tmdb υπάρχει γιατί η μέθοδος movie το υποστηρίζει συνήθως, 
            # αλλά αν δεις ότι κρασάρει και η ταινία, αφαίρεσέ το. 
            # Στις ταινίες όμως είπες ότι έπαιζε, άρα εκεί το περνάει.
            if tmdb:
                return f"{self.base_link}/movie/{tmdb}"
            if imdb:
                return f"{self.base_link}/movie/{imdb}"
            return
        except:
            return

    # ΔΙΟΡΘΩΣΗ: Αφαιρέθηκε το tmdb
    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            if tvdb:
                data = {'tvdb': tvdb}
                return urlencode(data)
            return
        except:
            return

    # ΔΙΟΡΘΩΣΗ: Αφαιρέθηκε το tmdb
    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return
            
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            target_id = data.get('tvdb')
            
            if not target_id:
                return

            s = int(season)
            e = int(episode)
            
            # Δομή: https://vixsrc.to/tv/TVDB_ID/SEASON/EPISODE
            post_url = f"{self.base_link}/tv/{target_id}/{s}/{e}"
            return post_url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if not url:
                return sources

            headers = self.headers.copy()
            headers['Referer'] = self.base_link
            
            response = client.request(url, headers=headers, timeout=10)

            match = re.search(r"window.masterPlaylist =\s+({.+?})\s", response, flags=re.DOTALL | re.IGNORECASE)
            
            if match:
                data = match.group(1)
                data = data.replace("params", "'params'").replace("url", "'url'")
                data = data.replace("\r", "").replace("\n", "").replace(" ", "")
                data = data.replace(",}", '}')
                data = data.replace("'", '"')
                
                try:
                    jdata = json.loads(data)
                except:
                    return sources

                video_url_raw = jdata.get("url")
                token = jdata.get("params", {}).get("token")
                expires = jdata.get("params", {}).get("expires")

                if video_url_raw and token:
                    separator = '&' if '?' in video_url_raw else '?'
                    video_url = f'{video_url_raw}{separator}token={token}&expires={expires}&h=1&lang=en'

                    sources.append({
                        'source': 'vixsrc',
                        'quality': '1080p',
                        'language': 'en',
                        'url': video_url,
                        'direct': True,
                        'debridonly': False
                    })

            return sources
        except Exception as e:
            log_utils.log(f'VIXSRC - Exception: {e}', 1)
            return sources

    def resolve(self, url):
        return url