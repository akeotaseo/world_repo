from urllib.parse import urlencode, parse_qsl, unquote, urlparse, quote_plus
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from requests import Session
from datetime import datetime
from pickle import dumps, loads
from base64 import b64encode, b64decode
from collections import defaultdict
from htmlement import fromstring
from time import time
import re, sys, requests, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_name = Addon().getAddonInfo('name')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
nextimg = RESOURCES + 'next.png'
daddy = 'https://daddylive.sx'
hostApiAccount = 'https://vua-phim.xyz/api/account'
UA = 'Mozilla/5.0 (Linux; Android 16; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/605.1.15 EdgA/140.0.0.0'
def addDir(title, logo, mode, is_folder=True, **kwargs):
    kwargs = {key: b64encode(dumps(value)).decode('utf-8') if isinstance(value, list) else value for key, value in kwargs.items()}
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=f'{title}')
    list_item.setArt({'icon': logo, 'thumb': logo, 'poster': logo, 'fanart': logo})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(f'{title}')
    info_tag.setPlot(f'{title}')
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref):
    r = requests.get(url, timeout=20, headers={'user-agent': UA, 'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}'
def remove_html_tags(text):
    return re.sub(r'<[^>]*>', '', text)
def convert_to_gmt7(time_str):
    hour, minute = map(int, time_str.split(":"))
    time_gmt7 = (hour + 7) % 24
    return f"{time_gmt7:02}:{minute:02}"
def domhtml(root, xpath, attribute=None, default=None):
    element = root.find(xpath)
    return default if element is None else element.get(attribute, ' '.join(element.itertext()).strip())
def fu(url):
    return requests.get(url, headers={'user-agent': UA, 'referer': url.encode('utf-8')}, allow_redirects=True).url
def play(link, ref=None):
    hdr = f'verifypeer=false&User-Agent={unquote(UA)}'
    linkplay = re.sub(r'\s+', '%20', link.strip(), flags=re.UNICODE)
    if ref:
        hdr += f'&Referer={ref}/'
    play_item = xbmcgui.ListItem(offscreen=True)
    if 'm3u8' in linkplay:
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    else:
        linkplay = f'{linkplay}|{hdr}'
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def play_tc(url):
    response = getlink(url, 'https://thapcam,tv/').text
    link = re.search(r'(?s)var url.*?(["\'])(.*?)\1', response)[2]
    linkplay = re.sub(r'\s+', '%20', link.strip(), flags=re.UNICODE)
    hdr = f'verifypeer=false&User-Agent={unquote(UA)}&Referer={referer(url)}/'
    play_item = xbmcgui.ListItem(offscreen=True)
    if 'm3u8' in linkplay:
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    else:
        linkplay = f'{linkplay}|{hdr}'
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def play_nhadai(link):
    fdad = fu(daddy)
    dtext = getlink(f'{fdad}embed/stream-{link}.php', fdad).text
    ifr = re.search(r'iframe src=(["\'])(.*?)\1', dtext)[2]
    ref = referer(ifr)
    response = getlink(ifr, fdad).text
    channel_key = re.search(r'(?s)channelKey.*?(["\'])(.*?)\1', response)[2]
    host = re.search(r'(?s)m3u8.*?:.*?:.*?(["\'])(.*?)\1.*?(["\'])(.*?)\1', response)[4]
    server_lookup = re.search(r'n fetchWithRetry\(\s*\'([^\']*)', response)[1]
    server_lookup_url = f'{ref}{server_lookup}{channel_key}'
    server_key = getlink(server_lookup_url, fdad).json()['server_key']
    play_item = xbmcgui.ListItem(offscreen=True)
    play_item.setPath(f'https://{server_key}{host}{server_key}/{channel_key}/mono.m3u8|verifypeer=false&Referer={ref}/&Origin={ref}&User-Agent={unquote(UA)}')
    setResolvedUrl(HANDLE, True, listitem=play_item)
def play_xemlaivb(ids):
    u = f'https://br.vebo.xyz/api/news/vebotv/detail/{ids}'
    r = getlink(u, u).json()['data']
    link = r['video_url']
    linkplay = re.sub(r'\s+', '%20', link.strip(), flags=re.UNICODE)
    play_item = xbmcgui.ListItem(offscreen=True)
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def play_xemlaitc(ids):
    u = f'https://q.thapcamn.xyz/api/news/thapcam/detail/{ids}'
    r = getlink(u, u).json()['data']
    link = r['video_url']
    linkplay = re.sub(r'\s+', '%20', link.strip(), flags=re.UNICODE)
    play_item = xbmcgui.ListItem(offscreen=True)
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def main():
    addDir('NHÀ ĐÀI', ICON, 'index_nhadai')
    addDir('Highlight nhà đài', ICON, 'index_xem24', p = 0)
    addDir('Xem lại bóng đá', ICON, 'index_xemlaivb', p = 1)
    addDir('Xem lại thể thao', ICON, 'index_xemlaitc', p = 1)
    addDir('Tâm điểm bóng đá', ICON, 'index_vebo')
    addDir('Tâm điểm thapcam', ICON, 'index_thapcam')
    addDir('Tâm điểm cakeo', ICON, 'index_cakeo')
    endOfDirectory(HANDLE)
def index_nhadai():
    grouped_results = defaultdict(list)
    fdad = fu(daddy)
    resp = getlink(f'{fdad}schedule/schedule-generated.php', fdad).json()
    for h in resp.values():
        for k in h:
            result = [(f"{convert_to_gmt7(show.get('time')) if show.get('time') else ''} {show.get('event')}",
                       [(ch.get('channel_name', ''), ch.get('channel_id', '')) for ch in show.get('channels', []) if isinstance(ch, dict)])
                      for show in h[k] if any(isinstance(ch, dict) for ch in show.get('channels', []))]            
            if result:
                grouped_results[k].extend(result)
    for k, results in grouped_results.items():
        tenshow = remove_html_tags(k)
        addDir(tenshow, ICON, 'list_nhadai', ids = b64encode(dumps(results)))
    endOfDirectory(HANDLE)
def index_vebo():
    url = 'https://api.vebo.xyz/api/match/vb/featured'
    resp = getlink(url, url).json()['featured']
    for k in resp:
        time = datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M')
        blv = ' - '.join(h['name'] for h in k.get('fansites') or [] if h.get('name'))
        namet = f'{time} {k["name"]}'
        tentran = f'[COLOR yellow]{namet}[/COLOR]' if k['match_status'] == 'live' else namet
        tenv = f'{tentran} | {blv}' if blv else tentran
        tenv2 = f'{time} {k["name"]} | {blv}' if blv else f'{time} {k["name"]}'
        logotour = k['tournament']['logo']
        addDir(tenv, logotour, 'list_vebo', idk = k['id'], tentran = tenv2, anhtran = logotour, slug = k['slug'])
    endOfDirectory(HANDLE)
def index_thapcam():
    url = 'https://ro.thapcamo.xyz/api/match/tc/featured'
    resp = getlink(url, url).json()['data']
    resp_sorted = sorted(resp, key=lambda x: int(x['timestamp']))
    for k in resp_sorted:
        time = datetime.fromtimestamp(int(k['timestamp']) / 1000).strftime('%H:%M')
        tg = f'[COLOR red]{time}[/COLOR]' if 'live' in k['match_status'] else time
        blv = ' - '.join(h['name'] for h in k.get('fansites') or [] if h.get('name'))
        nametour = k['tournament']['name']
        tentrandau = f'{tg} {nametour} [COLOR yellow]{k["name"]}[/COLOR]'
        tenv = f'{tentrandau} {blv}' if blv else tentrandau
        logotour = k['tournament']['logo'] or ''
        addDir(tenv, logotour, 'list_thapcam', idk = k['id'], tentran = tentrandau, anhtran = logotour)
    endOfDirectory(HANDLE)
def index_cakeo():
    url = 'https://api.cakeo.xyz/match/live'
    resp = getlink(url, url).json()['data']
    resp_sorted = sorted(resp, key=lambda x: int(x['timestamp']))
    for k in resp_sorted:
        if k['match_status'] == 1 or k['status'] == 1:
            time = datetime.fromtimestamp(int(k['timestamp']) / 1000).strftime('%H:%M')
            blv = ' - '.join(h['name'] for h in k.get('fansites') or [] if h.get('name'))
            nametour = k['tournament']['name']
            tentrandau = f'{time} {nametour} [COLOR yellow]{k["name"]}[/COLOR]'
            tenv = f'{tentrandau} {blv}' if blv else tentrandau
            logotour = k['tournament']['logo'] or ''
            addDir(tenv, logotour, 'list_cakeo', idk = k['id'], tentran = tentrandau, anhtran = logotour, slug = k['slug'])
    endOfDirectory(HANDLE)
def index_xem24(p):
    tg = time()
    d = f'https://24h.24hstatic.com//ajax/box_template_tin_noi_bat/index/953/1/10/0/3/0/0/0?v_is_ajax=1&v_device_global=pc&v_max_row=10&fk_listing_template=722&v_type_box_template=tin_noi_bat&v_show_date=0&v_show_event=0&v_color_button_more=51AE5A&v_color_button_more_1=51AE5A&v_loc_giai_dau=1&v_loai_giai=&t={tg}' if p == 0 else f'https://24h.24hstatic.com//ajax/box_template_tin_noi_bat/index/953/{p}/10/0/3/0/0/0?v_is_ajax=1&v_device_global=pc&v_max_row=10&fk_listing_template=722&v_type_box_template=tin_noi_bat&v_show_date=0&v_show_event=0&v_color_button_more=51AE5A&v_color_button_more_1=51AE5A&v_loc_giai_dau=1&v_loai_giai=&v_load_lan_2=1&t={tg}'
    html_clean = re.sub(r'</?html[^>]*>', '', getlink(d, d).text, flags=re.IGNORECASE)
    soup = fromstring(html_clean).iterfind('.//article//figure//a')
    for k in soup:
        title = domhtml(k, './/img', attribute='alt')
        img1 = domhtml(k, './/img', attribute='src')
        img2 = domhtml(k, './/img', attribute='data-original')
        img = img1 if img1.startswith('http') else img2
        link = k.get('href')
        addDir(title, img, 'list_xem24', idk = link, tentran = title, anhtran = img)
    trang = f'{p + 1}'
    nextpage = f'{p + 2}'
    addDir(f'Trang {nextpage}', nextimg, 'index_xem24', p=trang)
    endOfDirectory(HANDLE)
def list_xem24(u, tenm, anhtran):
    r = getlink(u, u).text
    linkstreams = re.findall(r'src.*?(https?://[^\s"\'<>]+?\.(?:m3u8|flv)[^"\']*)', r)
    for i, link in enumerate(linkstreams, start=1):
        tenv = f'{tenm} | Video {i}'
        addDir(tenv, anhtran, 'play', link = link, is_folder=False)
    endOfDirectory(HANDLE)
def index_xemlaivb(p):
    d = f'https://br.vebo.xyz/api/news/vebotv/list/{p}'
    resp = getlink(d, d).json()['data']
    try:
        ids = resp['highlight']['id']
        name = resp['highlight']['name']
        img = resp['highlight']['feature_image']
        addDir(name, img, 'play_xemlaivb', ids = ids, is_folder=False)
    except:
        pass
    listp = resp['list']
    for k in listp:
        ids = k['id']
        name = k['name']
        img = k['feature_image']
        addDir(name, img, 'play_xemlaivb', ids = ids, is_folder=False)
    trang = f'{p + 1}'
    addDir(f'Trang {trang}', nextimg, 'index_xemlaivb', p=trang)
    endOfDirectory(HANDLE)
def index_xemlaitc(p):
    d = f'https://q.thapcamn.xyz/api/news/thapcam/list/{p}'
    resp = getlink(d, d).json()['data']
    try:
        ids = resp['highlight']['id']
        name = resp['highlight']['name']
        img = resp['highlight']['feature_image']
        addDir(name, img, 'play_xemlaitc', ids = ids, is_folder=False)
    except:
        pass
    listp = resp['list']
    for k in listp:
        ids = k['id']
        name = k['name']
        img = k['feature_image']
        addDir(name, img, 'play_xemlaitc', ids = ids, is_folder=False)
    trang = f'{p + 1}'
    addDir(f'Trang {trang}', nextimg, 'index_xemlaitc', p=trang)
    endOfDirectory(HANDLE)
def list_nhadai(paramsids):
    ids = loads(b64decode(paramsids))
    for k in ids:
        tentran = k[0]
        channel_ids = k[1]
        if len(channel_ids) > 1:
            addDir(tentran, ICON, 'detail_nhadai', ev = b64encode(dumps(channel_ids)), nameid = tentran)
        elif channel_ids:
            addDir(tentran, ICON, 'play_nhadai', link = channel_ids[0][1], is_folder=False)
    endOfDirectory(HANDLE)
def detail_nhadai(paramsev, nameid):
    ev = loads(b64decode(paramsev))
    for k in ev:
        channelname = k[0]
        channelid = k[1]
        ten = f'{nameid} | {channelname}'
        addDir(ten, ICON, 'play_nhadai', link = channelid, is_folder=False)
    endOfDirectory(HANDLE)
def list_vebo(slug, idk, tenm, anhtran):
    urlvb = fu('https://vebo.tv')
    resp = getlink(f'{urlvb}truc-tiep/{slug}-{idk}', urlvb).text
    ref = referer(re.search(r"base_embed_url.*?(['\"])(.*?)(\1)", resp)[2])
    kq = getlink(f'http://api.vebo.xyz/api/match/{idk}/meta', urlvb).json()['data']['play_urls']
    for k in kq:
        tenv = f"{tenm} | {k['name']}"
        addDir(tenv, anhtran, 'play', link = k['url'], ref = f'{ref}/', is_folder=False)
    endOfDirectory(HANDLE)
def list_cakeo(slug, idk, tenm, anhtran):
    urlck = fu('https://cakeo.tv')
    resp = getlink(f'{urlck}truc-tiep/{slug}-{idk}', urlck).text
    ref = referer(re.search(r"base_embed_url.*?(['\"])(.*?)(\1)", resp)[2])
    kq = getlink(f'https://api.cakeo.xyz/match/meta-v2/{idk}', urlck).json()['data']['fansites']
    for k in kq:
        blv = k['name']
        for m in k['play_urls']:
            tenv = f"{tenm} | {blv} | {m['name']}"
            addDir(tenv, anhtran, 'play', link = m['url'], ref = f'{ref}/', is_folder=False)
    endOfDirectory(HANDLE)
def list_thapcam(idk, tenm, anhtran):
    resp = getlink(f'{hostApiAccount}/public/sports/links?matchId={idk}', f'{referer(hostApiAccount)}/').json()['contents']
    for k in resp:
        tenv = f"{tenm} | {k['name']}"
        addDir(tenv, anhtran, 'play_tc', link = k['link'], is_folder=False)
    endOfDirectory(HANDLE)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'index_nhadai': index_nhadai,
        'index_vebo': index_vebo,
        'index_cakeo': index_cakeo,
        'index_thapcam': index_thapcam,
        'list_nhadai': partial(list_nhadai, params.get('ids')),
        'index_xem24': partial(index_xem24, int(params.get('p', 0))),
        'index_xemlaivb': partial(index_xemlaivb, int(params.get('p', 1))),
        'index_xemlaitc': partial(index_xemlaitc, int(params.get('p', 1))),
        'detail_nhadai': partial(detail_nhadai, params.get('ev'), params.get('nameid')),
        'list_xem24': partial(list_xem24, params.get('idk'), params.get('tentran'), params.get('anhtran')),
        'list_vebo': partial(list_vebo, params.get('slug'), params.get('idk'), params.get('tentran'), params.get('anhtran')),
        'list_cakeo': partial(list_cakeo, params.get('slug'), params.get('idk'), params.get('tentran'), params.get('anhtran')),
        'list_thapcam': partial(list_thapcam, params.get('idk'), params.get('tentran'), params.get('anhtran')),
        'play': partial(play, params.get('link'), params.get('ref')),
        'play_tc': partial(play_tc, params.get('link')),
        'play_nhadai': partial(play_nhadai, params.get('link')),
        'play_xemlaivb': partial(play_xemlaivb, params.get('ids')),
        'play_xemlaitc': partial(play_xemlaitc, params.get('ids'))
    }
    action_map.get(params.get('mode'), main)()
try:
    router(sys.argv[2][1:])
except:
    pass