﻿import xbmc, xbmcgui
xbmc.executebuiltin('Dialog.Close(all,true)')
xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vavooto/?action=group_tv&type=vavoo")')
xbmcgui.Dialog().notification("[COLORwhite]Vavoo[/COLOR]", "IPTV", sound=False, icon='https://github.com/DonkeykongArcade/plugin.video.vavooto/blob/main/icon.png?raw=true')
xbmc.sleep(4000)
# xbmcgui.Dialog().notification("[B][COLOR orange]Keep calm and just wait[/COLOR][/B]", "[COLOR green]Περιμένετε...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/Pleasewait.png')
# xbmc.sleep(4000)
xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png')
xbmc.sleep(4000)
