import os, xbmc, xbmcvfs, xbmcgui, shutil, glob
from updatervar import *


base_path = xbmcvfs.translatePath('special://home/userdata/addon_data')

dir_list = glob.iglob(os.path.join(base_path, "plugin.program.downloader"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

xbmc.sleep(100)

xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.downloader/mac_player_main",return)')


