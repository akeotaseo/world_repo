import xbmcaddon
from lib.modules import Common

OpenURL = Common.OpenURL
addDir= Common.addDir
addVideo= Common.addVideo
Play= Common.Play
Setting = xbmcaddon.Addon().getSetting
#TVSetting = xbmcaddon.Addon('plugin.program.rays.files').getSetting

def Menu():
	addDir('FreePornVideos', 'none', 30, 'special://home/addons/plugin.video.xxx/resources/art/freepornvideos.png')
	addDir('GoodPorn', 'none', 5, 'special://home/addons/plugin.video.xxx/resources/art/goodporn.png')
	addDir('HQPorner', 'none', 120, 'special://home/addons/plugin.video.xxx/resources/art/hqporner.png')
	#addDir('PornoHD', 'none', 20, 'special://home/addons/plugin.video.xxx/resources/art/pornohd.png')
	addDir('PornOne', 'none', 130, 'special://home/addons/plugin.video.xxx/resources/art/pornone.png')
	addDir('XHand', 'none', 90, 'special://home/addons/plugin.video.xxx/resources/art/xhand.png')
	addDir('XOZilla', 'none', 100, 'special://home/addons/plugin.video.xxx/resources/art/xozilla.png')
	addDir('XTits', 'none', 40, 'special://home/addons/plugin.video.xxx/resources/art/xtits.png')