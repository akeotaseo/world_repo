#[
#    {
#        "Title": "-----",
#        "TvgName": "-----",
#        "TvgChNo": 1,
#        "TvgId": "channelId",
#        "TvgLogo": "http://www.logos.com/logo.png",
#        "TvgGroup": "GroupMain",
#        "Link": "http://www.stream.com/123456",
#        "IsFilm": false,
#        "IsSerie": false,
#        "IsLive": true
#    }
#]

#
#     import json
#
#     result = M3UItemfromdict(json.loads(json_string))

import re
from lib import logger
from typing import Any, List, TypeVar, Callable, Type, cast

T = TypeVar("T")

TAG_TVG_NAME = "tvg-name"
TAG_TVG_CHNO = "tvg-chno"
TAG_TVG_ID   = "tvg-id"
TAG_TVG_LOGO = "tvg-logo"
TAG_GROUP_TITLE = "group-title"
TAG_USER_AGENT  = "user-agent"

def from_str(x: Any) -> str:
    assert isinstance(x, str)
    return x


def from_int(x: Any) -> int:
    assert isinstance(x, int) and not isinstance(x, bool)
    return x


def from_bool(x: Any) -> bool:
    assert isinstance(x, bool)
    return x


def from_list(f: Callable[[Any], T], x: Any) -> List[T]:
    assert isinstance(x, list)
    return [f(y) for y in x]


def to_class(c: Type[T], x: Any) -> dict:
    assert isinstance(x, c)
    return cast(Any, x).to_dict()


class M3UItem:
    Title:    str
    TvgName:  str
    TvgChNo:  int
    TvgId:    str
    TvgLogo:  str
    TvgGroup: str
    UserAgent:str
    Referer:  str
    Link:     str
    IsFilm:   bool
    IsSerie:  bool
    IsLive:   bool
    IsKaraoke:bool

    def __init__(self, Title: str, TvgName: str, TvgChNo: int, TvgId: str, TvgLogo: str, TvgGroup: str, UserAgent: str, Referer: str, Link: str, IsFilm: bool, IsSerie: bool, IsLive: bool, IsKaraoke: bool) -> None:
        if not TvgName:   TvgName  = Title
        if not TvgChNo:   TvgChNo  = 0
        if not TvgId:     TvgId    = Title.lower()
        if not TvgLogo:   TvgLogo  = ""
        if not TvgGroup:  TvgGroup = "Unknown"
        if not UserAgent: UserAgent= ""
        if not Referer:   Referer  = ""

        self.Title    = Title    .strip()
        self.TvgName  = TvgName  .strip()
        self.TvgChNo  = TvgChNo
        self.TvgId    = TvgId    .strip()
        self.TvgLogo  = TvgLogo  .strip()
        self.TvgGroup = TvgGroup .strip()
        self.UserAgent= UserAgent.strip()
        self.Referer  = Referer  .strip()
        self.Link     = Link     .strip()
        self.IsFilm   = IsFilm
        self.IsSerie  = IsSerie
        self.IsLive   = IsLive
        self.IsKaraoke= IsKaraoke

    @staticmethod
    def from_dict(obj: Any) -> 'M3UItem':
        assert isinstance(obj, dict)
        Title    = from_str(obj.get("Title"))
        TvgName  = from_str(obj.get("TvgName"))
        TvgChNo  = from_int(obj.get("TvgChNo"))
        TvgId    = from_str(obj.get("TvgId"))
        TvgLogo  = from_str(obj.get("TvgLogo"))
        TvgGroup = from_str(obj.get("TvgGroup"))
        UserAgent= from_str(obj.get("UserAgent"))
        Referer  = from_str(obj.get("Referer"))
        Link     = from_str(obj.get("Link"))
        IsFilm   = from_bool(obj.get("IsFilm"))
        IsSerie  = from_bool(obj.get("IsSerie"))
        IsLive   = from_bool(obj.get("IsLive"))
        IsKaraoke= from_bool(obj.get("IsKaraoke"))

        return M3UItem(Title, TvgName, TvgChNo, TvgId, TvgLogo, TvgGroup, UserAgent, Referer, Link, IsFilm, IsSerie, IsLive, IsKaraoke)

    @staticmethod
    def from_extinf_url(extInf: str, url: str) -> None:
        if(extInf and url):
            try:
                m = re.search( TAG_TVG_NAME + '="(.*?)"', extInf)
                tvg_name = m.group(1) if m else ""
                m = re.search( TAG_TVG_CHNO + '="(.*?)"', extInf)
                tvg_ch_no = m.group(1) if m else ""
                m = re.search( TAG_TVG_ID   + '="(.*?)"', extInf)
                tvg_id = m.group(1) if m else ""
                m = re.search( TAG_TVG_LOGO + '="(.*?)"', extInf)
                tvg_logo = m.group(1) if m else ""
                m = re.search( TAG_GROUP_TITLE + '="(.*?)"', extInf)
                tvg_group = m.group(1) if m else ""
                m = re.search( TAG_USER_AGENT  + '="(.*?)"', extInf)
                user_agent = m.group(1) if m else ""
                #m = re.search("(?!.*=\",?.*\")[,](.*?)$", extInf)
                #title = m.group(1)
                title = extInf.split(',')[-1]

                link = url

                is_film  = "/movie/"  in link.lower() or tvg_group.lower().startswith("movie") or tvg_group.lower().startswith("film")
                is_serie = "/series/" in link.lower() or tvg_group.lower().startswith("serie")
                is_karaoke = tvg_group.lower().startswith("kar")
                is_live  = (not is_serie and not is_film and not is_karaoke) or tvg_group.lower().startswith("live")

                return M3UItem(title, tvg_name, tvg_ch_no, tvg_id, tvg_logo, tvg_group, user_agent, "", link, is_film, is_serie, is_live, is_karaoke)
            except Exception as ex :
                logger.error(ex)
                logger.error(extInf)
        
    def to_dict(self) -> dict:
        result: dict = {}
        result["Title"]    = from_str(self.Title)
        result["TvgName"]  = from_str(self.TvgName)
        result["TvgChNo"]  = from_int(self.TvgChNo)
        result["TvgId"]    = from_str(self.TvgId)
        result["TvgLogo"]  = from_str(self.TvgLogo)
        result["TvgGroup"] = from_str(self.TvgGroup)
        result["UserAgent"]= from_str(self.UserAgent)
        result["Referer"]  = from_str(self.Referer)
        result["Link"]     = from_str(self.Link)
        result["IsFilm"]   = from_bool(self.IsFilm)
        result["IsSerie"]  = from_bool(self.IsSerie)
        result["IsLive"]   = from_bool(self.IsLive)
        result["IsKaraoke"]= from_bool(self.IsKaraoke)
        
        return result


def M3UItemfromdict(s: Any) -> List[M3UItem]:
    return from_list(M3UItem.from_dict, s)


def M3UItemtodict(x: List[M3UItem]) -> Any:
    return from_list(lambda x: to_class(M3UItem, x), x)
