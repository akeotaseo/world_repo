# -*- coding: utf-8 -*-

import time
import xbmc
import os
import xbmcgui
import webbrowser




def menuoptions():
    dialog = xbmcgui.Dialog()
    funcs = (
        function1, function2, function3, function4, function5, function6, function7, function8, function9, function10, function11, function12, function13, function14, function15, function16, function17,function18,function19,function20,function21,
        function22, function23, function24, function25, function26, function27, function28, function29, function30, function31, function32
    )
        
    call = dialog.select('[B][COLOR=white]ΙΣΤΟΣΕΛΙΔΕΣ[/COLOR][/B]',
    [
    '[COLOR blue]ManaLaB NET[/COLOR] [COLOR red]YouTube[/COLOR]',
    '[COLOR orange]TechNEWSology[/COLOR] [COLOR red]YouTube[/COLOR]',
    '[B][COLOR=grey]Support @Discord [/COLOR][/B]',   
    '[COLOR=red]reddit Addons4Kodi[/COLOR]',

    '[B][COLOR=grey]Πρόγραμμα TV[/COLOR][/B]',
    '[COLOR=grey]Πρόγραμμα αθλητικών μεταδόσεων ( σε ποια κανάλια παίζουν)[/COLOR]',
    '[COLOR=grey]liveonsat[/COLOR]',
    '[COLOR=grey]SPORTEVENTZ[/COLOR]',

    '[B][COLOR=blue]Subtitles[/COLOR][/B]',

    '[B][COLOR=red]TRAKT[/COLOR][/B]',
    '[COLOR=red]Trakt activate[/COLOR]',
    '[COLOR=yellow]IMDB[/COLOR]',
     '[B][COLOR=yellow]Imdb Create account[/COLOR][/B]',
    '[COLOR=white]TVDB[/COLOR]',
    '[COLOR=aquamarine]Real Debrid activate[/COLOR]',
    '[COLOR=red]YouTube/activate[/COLOR]',
    
    '[B][COLOR=blue]GKoBu Pair-ing System[/COLOR][/B]',
    '[B][COLOR=blue]kodi.tv[/COLOR][/B]',
    '[B][COLOR=purple]LazyLinks[/COLOR][/B]',

    '[COLOR=grey]pinsystem[/COLOR] / [B][COLOR=yellow]NemesisAio[/COLOR][/B]',

    '[COLOR=grey]gamato[/COLOR]',
    '[COLOR=grey]tenies-online[/COLOR]',
    
    '[B][COLOR=red]rojadirecta.eu[/COLOR][/B]',
    '[B][COLOR=grey]DaddyHD[/COLOR][/B]',
    '[COLOR=red]LiveTv.sx[/COLOR]',
    '[COLOR=cadetblue]Diggz Sports Browser [/COLOR]',



    '[B][COLOR=orange]TV Schedule & Episode Calendar[/COLOR][/B]',

    '[B][COLOR=red]Netflix Login[/COLOR][/B]',
    '[B][COLOR=orange]ANT1 Login[/COLOR][/B]',
    '[B][COLOR=cornflowerblue]MEGA[/COLOR][/B]',
    '[B][COLOR=blue]ertflix [/COLOR][/B]',
    '[B][COLOR=white]Programs_tv GR [/COLOR][/B]',])

    # dialog.selectreturns
    #   0 -> escape pressed
    #   1 -> first item
    #   2 -> second item
    if call:
        # esc is not pressed
        if call < 0:
            return
        func = funcs[call-32]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()


def function1():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.youtube.com/results?search_query=ManaLaB+NET' ) )
    else:
        opensite = webbrowser . open('https://www.youtube.com/results?search_query=ManaLaB+NET')

def function2():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.youtube.com/results?search_query=TechNEWSology' ) )
    else:
        opensite = webbrowser . open('https://www.youtube.com/results?search_query=TechNEWSology')

def function3():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://discord.com/channels/557998225718640650/558717634959507475' ) )
    else:
        opensite = webbrowser . open('https://discord.com/channels/557998225718640650/558717634959507475')

def function4():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://old.reddit.com/r/Addons4Kodi/' ) )
    else:
        opensite = webbrowser . open('https://old.reddit.com/r/Addons4Kodi/')	
        
def function5():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://programmatileorasis.gr/' ) )
    else:
        opensite = webbrowser . open('https://programmatileorasis.gr/')	
		



def function6():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.livesoccertv.com/schedules/' ) )
    else:
        opensite = webbrowser . open('https://www.livesoccertv.com/schedules')	

def function7():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://liveonsat.com/quickindex.html' ) )
    else:
        opensite = webbrowser . open('https://liveonsat.com/quickindex.html')

def function8():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.sporteventz.com/en/' ) )
    else:
        opensite = webbrowser . open('https://www.sporteventz.com/en/')




def function9():
    xbmc.executebuiltin('RunScript("special://home/addons/script.sites/SearchSubs.py")')




def function10():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://trakt.tv/join' ) )
    else:
        opensite = webbrowser . open('https://trakt.tv/join')

def function11():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://trakt.tv/activate' ) )
    else:
        opensite = webbrowser . open('https://trakt.tv/activate')

def function12():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.imdb.com/' ) )
    else:
        opensite = webbrowser . open('https://www.imdb.com/')

def function13():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://m.imdb.com/ap/register?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.imdb.com%2Fap-signin-handler&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=imdb_mobile_web_us&openid.mode=checkid_setup&siteState=eyJvcGVuaWQuYXNzb2NfaGFuZGxlIjoiaW1kYl9tb2JpbGVfd2ViX3VzIiwicmVkaXJlY3RUbyI6Imh0dHA6Ly9tLmltZGIuY29tLz9yZWZfPW1fbG9naW4ifQ&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&&tag=imdbtag_reg-20' ) )
    else:
        opensite = webbrowser . open('https://m.imdb.com/ap/register?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.imdb.com%2Fap-signin-handler&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=imdb_mobile_web_us&openid.mode=checkid_setup&siteState=eyJvcGVuaWQuYXNzb2NfaGFuZGxlIjoiaW1kYl9tb2JpbGVfd2ViX3VzIiwicmVkaXJlY3RUbyI6Imh0dHA6Ly9tLmltZGIuY29tLz9yZWZfPW1fbG9naW4ifQ&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&&tag=imdbtag_reg-20')

def function14():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://thetvdb.com' ) )
    else:
        opensite = webbrowser . open('https://thetvdb.com/')

def function15():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://real-debrid.com/device' ) )   
    else:
        opensite = webbrowser . open('https://real-debrid.com/device')

def function16():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.youtube.com/activate' ) )
    else:
        opensite = webbrowser . open('https://www.youtube.com/activate/')


def function17():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://kodi.tv/' ) )   
    else:
        opensite = webbrowser . open('https://kodi.tv/')


def function18():
    xbmc.executebuiltin('RunScript("special://home/addons/script.sites/plugin.program.lazylinks.py")')
    # xbmc.executebuiltin('RunScript("plugin.program.jewpair")')

def function19():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.lazylinks/")')
    #xbmc.executebuiltin('RunScript("plugin.program.lazylinks")')


def function20():
    if myplatform == 'android': # Android +
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://pinsystem.co.uk' ) )
    else:
        opensite = webbrowser . open('https://pinsystem.co.uk/')




def function21():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://gamato3.com' ) )
    else:
        opensite = webbrowser . open('https://gamatotv.best/')

def function22():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://tenies-online.best/' ) )
    else:
        opensite = webbrowser . open('https://tenies-online.best/')




def function23():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://www.rojadirecta.eu/' ) )
    else:
        opensite = webbrowser . open('http://www.rojadirecta.eu/')

def function24():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://dlhd.link/' ) )
    else:
        opensite = webbrowser . open('https://dlhd.link/')

def function25():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://livetv.sx/enx/' ) )
    else:
        opensite = webbrowser . open('https://livetv.sx/enx/')

def function26():
    xbmc.executebuiltin('RunScript("special://home/addons/script.sites/plugin.program.sports.py")')
    # xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.sports")')
    # xbmc.executebuiltin('RunScript("plugin.program.sports")')




def function27():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.pogdesign.co.uk/cat/' ) )
    else:
        opensite = webbrowser . open('https://www.pogdesign.co.uk/cat/')


def function28():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.netflix.com/gr/' ) )
    else:
        opensite = webbrowser . open('https://www.netflix.com/gr/')

def function29():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://vod.antenna.gr/#/' ) )
    else:
        opensite = webbrowser . open('https://vod.antenna.gr/#/')

def function30():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.megatv.com/' ) )
    else:
        opensite = webbrowser . open('https://www.megatv.com/')


def function31():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.ertflix.gr/' ) )
    else:
        opensite = webbrowser . open('https://www.ertflix.gr/')

def function32():
    xbmc.executebuiltin('RunScript("special://home/addons/script.sites/Programs_tv.py")')

menuoptions()
