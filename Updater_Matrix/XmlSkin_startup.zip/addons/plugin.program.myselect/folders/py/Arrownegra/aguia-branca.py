import xbmc, xbmcgui


def xcodes():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ aguia-branca ~[/COLOR][/B]', 
['[COLOR maroon]ÁGUIA[/COLOR] [COLOR gold]BRANCA[/COLOR]',
 '[COLORorange]Pach API Aguia_Branca Stalker[/COLOR]',
 #'    ',
 #'[B][COLOR red]neo[/COLOR][COLOR orange]tv [/COLOR][/B] (F4mtester)',
 #'IPTV Stalker',
 #'[COLOR white]XC MAC M3U[/COLOR]'
 
 ])


    if call:
        if call < 0:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.aguia-branca/",return)')

def click_2():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/Arrownegra/DialogAguia-branca.py")')

def click_3():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/Arrownegra/x-codes.py")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.neo.tv/",return)')
    
def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.stalker/",return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.macvod/",return)')

xcodes()
