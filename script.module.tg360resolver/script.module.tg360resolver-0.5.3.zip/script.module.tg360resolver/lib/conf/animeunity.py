import re
from base64 import b64encode
from hashlib import md5
from time import time

from conf.common import CommonResolver
import json


class AnimeUnity(CommonResolver):

    def set_servers(self):
        return ['animeunity.tv']

    def find_stream(self):
        matches = re.compile(r"<video-player.*?scws_id.*?:(\d+)", re.DOTALL).findall(self.page_src)

        if matches:
            scws_id = matches[0]
            res = self.resolver.cli.get_request('https://scws.xyz/videos/' + scws_id,
                                                headers={'Referer': self.page_url}).text
            cli_ip = json.loads(res).get('client_ip')
            expires = int(time() + 172800)
            token = b64encode(md5('{}{} Yc8U6r8KjAKAepEA'.format(expires, cli_ip).encode('utf-8')).digest()).decode(
                'utf-8').replace('=', '').replace('+', '-').replace('/', '_')

            url = 'https://scws.xyz/master/{}?token={}&expires={}&n=1'.format(scws_id, token, expires)

            return [url]
