import re
import xbmcaddon
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

BaseURL = 'https://goodporn.to'
Thumb   = 'special://home/addons/plugin.video.xxx/resources/art/goodporn.png'


def Menu():
	addDir('Latest Videos',      BaseURL + '/latest-updates/', 71, Thumb)
	addDir('Most Viewed Videos', BaseURL + '/most-popular/',   71, Thumb)
	addDir('Top Rated Videos',   BaseURL + '/top-rated/',      71, Thumb)
	addDir('Categories',         BaseURL + '/categories/',     72, Thumb)
	addDir('Sites',              BaseURL + '/sites/',          72, Thumb)
	addDir('Channels',           BaseURL + '/channels/',       72, Thumb)

def Browse(url):
	NextPage = 0
	if '/categories/' in url:
		page = re.compile('/categories/.+?/(.+?)/').findall(url)[0]
		CatURL = url.replace(page + '/', '')
		page = int(page)
		page = page + 1
		NextPage = str(page)
	if '/sites/' in url:
		page = re.compile('/sites/.+?/(.+?)/').findall(url)[0]
		CatURL = url.replace(page + '/', '')
		page = int(page)
		page = page + 1
		NextPage = str(page)
	r = OpenURL(url)
	r = r.replace('\n', '')
	m = re.compile('<div class="item  ">(.+?)</div></div>').findall(r)
	for i in m:
		url   = re.compile('<a href="(.+?)"').findall(i)[0]
		thumb = re.compile('data-original="(.+?)"').findall(i)[0]
		if not thumb.startswith('http'): thumb = 'http:' + thumb
		time  = re.compile('<div class="duration">(.+?)</div>').findall(i)[0]
		title = re.compile('<strong class="title">(.+?)</strong>').findall(i)[0]
		if Setting('show_time') == 'true': title = '[B](%s)[/B] %s' % (time, title)
		url = '%s&random_id=%s' % (url, RandomID())
		addVideo(title, url, 73, thumb)
	if NextPage == 0:
		n = re.compile('<li class="next"><a href="(.+?)"').findall(r)
		for NextPage in n:
			addDir('Next page >', BaseURL + NextPage, 71, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	else:
		addDir('Next page >', CatURL + NextPage + '/', 71, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	Common.SetView()

def Categories(url):
	r = OpenURL(url)
	if '/channels/' not in url:
		m = re.compile('<a class="item" href="(.+?)" title="(.+?)">\n<div class="img">\n<img class="thumb" src="(.+?)" alt=".+?" />').findall(r)
	else:
		m = re.compile('<a href="(.+?)" title="(.+?)">\n<div class="img">\n<img class="thumb" src="(.+?)" alt=".+?" />').findall(r)	
	for url, title, thumb in m:
		if not thumb.startswith('http'): thumb = 'http:' + thumb
		addDir(title, url + '1/', 71, thumb)
	n = re.compile('<li class="next"><a href="(.+?)"').findall(r)
	for NextPage in n:
		addDir('Next page >', BaseURL + NextPage, 72, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	
def PlayStream(url):
	if 'random_id=' in url: url = re.compile('(.+?)&random_id').findall(url)[0]
	r = OpenURL(url)
	
	try: vid_1080 = re.compile('<a href="(.+?)" data-attach-session="PHPSESSID">MP4 1080p').findall(r)[0]
	except: vid_1080 = ''
	
	try: vid_720 = re.compile('<a href="(.+?)" data-attach-session="PHPSESSID">MP4 720p').findall(r)[0]
	except: vid_720 = ''
	
	try: vid_480 = re.compile('<a href="(.+?)" data-attach-session="PHPSESSID">MP4 480p').findall(r)[0]
	except: vid_480 = ''
	
	try: vid_360 = re.compile('<a href="(.+?)" data-attach-session="PHPSESSID">MP4 360p').findall(r)[0]
	except: vid_360 = ''
	
	if vid_1080 != '': Play(vid_1080)
	elif vid_720 != '': Play(vid_720)
	elif vid_480 != '': Play(vid_480)
	elif vid_360 != '': Play(vid_360)
	else: pass

def RandomID():
	import random
	random_id = str(random.randint(0,1000000))
	return random_id