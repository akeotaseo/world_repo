import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.matrixflix/?site=cFav&function=setBookmark)", True)
