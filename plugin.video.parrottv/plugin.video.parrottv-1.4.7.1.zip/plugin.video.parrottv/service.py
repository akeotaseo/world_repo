# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import xbmc
import time
from addon import genPlaylist
import xbmcaddon
import requests
try: from urllib.parse import quote_plus
except ImportError: from urllib import quote_plus

if __name__ == '__main__':
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        _ADDON = xbmcaddon.Addon()
        username = _ADDON.getSetting('username')
        password = _ADDON.getSetting('password')
        if username == "" or password == "": _ADDON.setSetting('verified', 'false'); time.sleep(3); continue
        headers = {"username": quote_plus(username)}
        headers.update({"password": quote_plus(password)})
        resp = requests.get("https://login.parrotdevelopers.repl.co/login", headers=headers)
        if resp.text == "True":
            _ADDON.setSetting('verified', 'true')
            genPlaylist()
            time.sleep(15 * 60)
        else:
            _ADDON.setSetting('verified', 'false')
            time.sleep(5)