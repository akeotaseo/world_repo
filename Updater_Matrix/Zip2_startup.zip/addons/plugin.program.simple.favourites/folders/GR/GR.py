import xbmc, xbmcgui
xbmcgui.Dialog().notification("[B][COLOR green]Loading lists[/COLOR][/B]", "[COLOR orange]They don't always work[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png')
# xbmc.executebuiltin('Dialog.Close(all,true)')
xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.simple.favourites/index_of/special%3A%2F%2Fhome%2Faddons%2Fplugin.program.simple.favourites%2Ffolders%2FGR%2F",return)')

