# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import xbmcgui

class ABC:
    def __init__(self):
        self.ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'
        self.channels = {
            "WBRZ": {
                "name": "ABC 2 WBRZ | Baton Rouge LA",
                "url": "http://cms-wowza.lunabyte.io/wbrz-live-1/_definst_/smil:wbrz-live.smil/chunklist_b1300000.m3u8"
            },
            "KMGH": {
                "name": "ABC 7 KMGH | Denver",
                "url": "https://content.uplynk.com/channel/64ca339f04964a5e961c3207a7771bf1.m3u8"
            },
            "KERO": {
                "name": "ABC 23 KERO | California",
                "url": "https://content.uplynk.com/channel/ff809e6d9ec34109abfb333f0d4444b5.m3u8"
            }
        }


    def grab(self, *args):
        headers = {'User-Agent': self.ua}
        sel = xbmcgui.Dialog().select("Select a channel", [x["name"] for x in self.channels.values()])
        if sel == -1: return
        channel = list(self.channels.keys())[sel]
        hlsurl = self.channels[channel]["url"]
        return hlsurl, headers

    