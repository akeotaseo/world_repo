from urllib.parse import parse_qsl
from xbmcplugin import addDirectoryItem, endOfDirectory, setContent
from xbmcaddon import Addon
from xbmcvfs import translatePath
from xbmcgui import ListItem
from pickle import load
import sys, os
HANDLE = int(sys.argv[1])
ICON = Addon().getAddonInfo('icon')
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), 'plugin.video.daxem')
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def get_last_watch():
    return read_file('daxem.pkl') or []
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        data= get_last_watch()
        if data:
            for m in data:
                list_item = ListItem(m)
                list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': ICON})
                list_item.setInfo('video', infoLabels={'title': m, 'plot': m})
                setContent(HANDLE, 'videos')
                list_item.setProperty('IsPlayable', 'true')
                addDirectoryItem(HANDLE, data[m], list_item, False)
        endOfDirectory(HANDLE)
if __name__ == '__main__':
    router(sys.argv[2][1:])