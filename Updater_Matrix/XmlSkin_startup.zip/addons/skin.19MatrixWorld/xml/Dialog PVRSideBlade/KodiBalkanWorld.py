﻿import xbmc, xbmcgui
def KodiBalkanWorld():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/RobinhoodTVPortal/KodiBalkanWorld.py")')
    xbmcgui.Dialog().notification("[B][COLOR blue]Kodi Balkan World[/COLOR][/B]", "   ", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/worldclient.png')
    xbmc.sleep(4000)
KodiBalkanWorld()
