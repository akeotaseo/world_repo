﻿import xbmc
# Ρυθμίσεις
def audiosettings():
    if xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin("Action(Close)")
        xbmc.sleep(100)
        xbmc.executebuiltin("ActivateWindowAndFocus(systemsettings, -199,)")
        xbmc.sleep(100)
    while xbmc.getCondVisibility("Window.IsVisible(systemsettings, -199)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")
    if not xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin("Action(Close)")
        xbmc.sleep(100)
        xbmc.executebuiltin("ActivateWindowAndFocus(systemsettings, -199,)")
        xbmc.sleep(100)
        xbmc.executebuiltin("Action(Pause)")
    while xbmc.getCondVisibility("Window.IsVisible(systemsettings, -199)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")

audiosettings()
