import os
import sys
import xbmcaddon
import xbmcgui
import xbmcvfs
import xbmcplugin
import xbmc
from urllib.parse import unquote, quote, urlparse, parse_qs
import requests
import re
import html
import resolveurl
from categories import (
    list_genuri_menu,
    list_ani_menu,
    list_limba_menu,
    list_genuri_seriale_menu,
    list_ani_seriale_menu,
    list_limba_seriale_menu
)

addon = xbmcaddon.Addon()
addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))
icon_path = os.path.join(addon_path, 'resources', 'media')

base_url = "http://filmeserialeonline.org"
search_url = "http://www.filmeserialeonline.org/?s="
filme_url = "http://www.filmeserialeonline.org/filme-online-hd-22/"
seriale_url = "http://www.filmeserialeonline.org/seriale-online-hd-2024-00/"

headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1'}

def get_html(url):
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        return response.text
    except requests.RequestException as e:
        xbmc.log(f"Error fetching URL {url}: {e}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", f"Failed to fetch URL: {url}", xbmcgui.NOTIFICATION_ERROR)
        return ""

def extract_video_sources(url):
    s = requests.Session()
    reg_id = r'''id[\:\s]+(\d+)[,\}]'''
    headers.update({'Referer': url})

    first = s.get(url, headers=headers)
    try:
        mid = re.findall(reg_id, first.text)[0].strip()
    except:
        mid = "1"

    dataid = {'id': mid, 'logat': '0'}
    second = f"{base_url}/wp-content/themes/grifus/loop/second.php"
    third = f"{base_url}/wp-content/themes/grifus/includes/single/second.php"

    data1 = {'call': '03AHhf_52tCb5gUikGtjLeSMufA-2Hd3hcejVejJrPldhT-fjSepWRZdKTuQ0YjvPiph7-zcazBsIoVtGAwi_C3JsOFH74_TvXq2rRRQ4Aev59zTCFHFIAOOyxuOHRyIKIy4AZoxalLMegYUL5-J6LBvFZvFuTeKa6h3oNLISO4J0qw0fZSGrEhN02Hlbtnmdilj-nRUrMUCpPLWnZaV8eB8iatMaOg6FEqayxdJ1oF8AaFlOoVOnRrw_WWPu0cH97VkreacJNaQqh0qz-5yB1tbFD0GVOHLtU7Bd6DvUf_24hTxFsCszvjPD_hltYNxTrSOj49_lpTs279NghbyVvz-yVFfC-3mU-bQ'}

    if re.search('/episodul/', url):
        s.post(second, data=data1, headers=headers)
        j = 0
        html_content = ''
        while j <= 4:
            reslink = f"{base_url}/wp-content/themes/grifus/loop/second_id.php?id={mid}&embed={j}"
            res = s.get(reslink, headers=headers).text
            html_content += res
            j += 1
        g = html_content
    else:
        s.post(third, data=data1, headers=headers)
        g = s.post(third, data=dataid, headers=headers).text

    reg_link = r'''<iframe(?:.+?)?src="(?:[\s+])?((?:[htt]|[//]).+?)"'''
    linkss = []

    if not re.search('/episodul/', url):
        reg = r'''url:\s+"(.+?)"'''
        match_lnk = re.findall(reg, g, re.IGNORECASE | re.DOTALL)
        try:
            for links in match_lnk:
                link = s.get(f"{base_url}/{links}", headers=headers).text
                linkss.append(re.findall(reg_link, link)[0])
        except:
            pass
    else:
        match_lnk = re.findall(reg_link, g, re.IGNORECASE | re.DOTALL)
        for links in match_lnk:
            linkss.append(links)

    #return linkss

    # Handle redirection for special URLs
    real_sources = []
    for link in linkss:
        if "player.php" in link:
            # Follow the redirect to get the real video URL
            response = s.head(link, allow_redirects=True)
            real_url = response.url
            real_sources.append(real_url)
        else:
            real_sources.append(link)

    return real_sources

def get_video_url(url):
    sources = extract_video_sources(url)
    for source in sources:
        # Extrage subtitrările din URL înainte de a rezolva video-ul
        subtitles = extract_subtitles_from_url(source)

        # Rezolvă URL-ul video
        resolved = resolveurl.resolve(source)
        if resolved:
            return resolved, subtitles  # Returnează atât URL-ul video cât și subtitrările

    return None, []

def extract_subtitles_from_url(url):
    parsed_url = urlparse(unquote(url))
    query_params = parse_qs(parsed_url.query)
    subtitles = []

    # Caută toate subtitrările în parametrii query
    for key, value in query_params.items():
        if 'sub' in key.lower() or 'c1_file' in key.lower() or 'c2_file' in key.lower():
            subtitles.append(value[0])

    return subtitles

def parse_items(html_content):
    # Regex ajustat pentru a captura corect toate item-urile și detaliile relevante
    pattern = re.compile(
        r'<div id="mt-\d+" class="item">.*?<a href="(.*?)".*?<img src="(.*?)".*?alt="(.*?)".*?'
        r'<span class="tipoitem">(.*?)</span>.*?<span class="year">(.*?)</span>',
        re.DOTALL
    )

    items = pattern.findall(html_content)

    decoded_items = []
    for url, thumbnail, title, description, year in items:
        # Decodificăm și curățăm datele extrase
        decoded_items.append((
            url.strip(),
            thumbnail.strip(),
            html.unescape(title).strip(),
            year.strip(),
            html.unescape(description.strip())
        ))

    return decoded_items

def list_items(items, next_page_url=None):
    for item in items:
        url, thumbnail, title, year, description = item
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt({'thumb': thumbnail, 'icon': thumbnail})
        list_item.setInfo('video', {'title': title, 'year': year, 'plot': description})  # Set the plot (description)

        is_series = '/seriale/' in url or '/episodul/' in url

        if is_series:
            action = 'list_seasons'
            is_folder = True
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action={action}&url={quote(url)}", listitem=list_item, isFolder=is_folder)
        else:
            action = 'play_movie'
            is_folder = False
            list_item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action={action}&url={quote(url)}", listitem=list_item, isFolder=is_folder)

    # Adaugă opțiunea "Pagina următoare" dacă există un URL pentru paginarea următoare
    if next_page_url:
        next_page_item = xbmcgui.ListItem(label="Pagina următoare")
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=next_page&url={quote(next_page_url)}", listitem=next_page_item, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))
"""
def extract_pagination_urls(html_content):
    # Regex ajustat pentru a captura corect URL-urile paginilor următoare
    pagination_pattern = re.compile(r"<li><a rel='nofollow' class='page larger' href='(.*?)'>", re.IGNORECASE)
    urls = pagination_pattern.findall(html_content)

    return urls
"""
def extract_pagination_urls(html_content):
    # Regex ajustat pentru a captura corect URL-urile paginilor următoare, inclusiv pentru ultima pagină
    pagination_pattern = re.compile(r"<li><a[^>]*?href=['\"](http[^'\"]+page/\d+/)['\"][^>]*?>", re.IGNORECASE)
    urls = pagination_pattern.findall(html_content)

    # Eliminăm duplicatele, dacă există
    urls = list(dict.fromkeys(urls))

    return urls

def add_next_page(next_page_url, page):
    xbmc.log(f"Adding next page URL: {next_page_url}", level=xbmc.LOGINFO)
    list_item = xbmcgui.ListItem(label="Pagina următoare")
    list_item.setArt({'thumb': 'resources/media/nextpage.png', 'icon': 'resources/media/nextpage.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=next_page&url={quote(next_page_url)}&page={page}", listitem=list_item, isFolder=True)

def list_genuri_filme(url, page=1):
    html_content = get_html(url)

    if html_content:
        items = parse_items(html_content)

        if items:
            xbmc.log(f"Parsed {len(items)} items from genre content", level=xbmc.LOGINFO)

            # Extrage URL-urile de paginare și alege următorul URL, dacă există
            pagination_urls = extract_pagination_urls(html_content)
            xbmc.log(f"Pagination URLs found: {pagination_urls}", level=xbmc.LOGINFO)

            if pagination_urls and len(pagination_urls) >= page:
                next_page_url = pagination_urls[page - 1]
                xbmc.log(f"Next page URL: {next_page_url}", level=xbmc.LOGINFO)
            else:
                next_page_url = None
                xbmc.log("No more pages found.", level=xbmc.LOGINFO)

            # Listează item-urile în listă
            for item in items:
                url, thumbnail, title, year, description = item
                list_item = xbmcgui.ListItem(label=title)
                list_item.setArt({'thumb': thumbnail, 'icon': thumbnail})
                list_item.setInfo('video', {'title': title, 'year': year, 'plot': description})

                is_series = '/seriale/' in url or '/episodul/' in url

                if is_series:
                    action = 'list_seasons'
                    is_folder = True
                else:
                    action = 'play_movie'
                    is_folder = False
                    list_item.setProperty('IsPlayable', 'true')

                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action={action}&url={quote(url)}", listitem=list_item, isFolder=is_folder)

            # Adaugă butonul "Pagina următoare" la finalul listei, dacă este cazul
            if next_page_url:
                xbmc.log(f"Adding next page button for URL: {next_page_url}", level=xbmc.LOGINFO)
                next_page_item = xbmcgui.ListItem(label="Pagina următoare")
                xbmcplugin.addDirectoryItem(
                    handle=int(sys.argv[1]),
                    url=f"{sys.argv[0]}?action=next_page&url={quote(next_page_url)}&page={page + 1}",
                    listitem=next_page_item,
                    isFolder=True
                )
            else:
                xbmc.log("No next page URL available, button will not be added.", level=xbmc.LOGINFO)

        else:
            xbmcgui.Dialog().notification("Error", "No items found in this category", xbmcgui.NOTIFICATION_ERROR)
    else:
        xbmc.log(f"Failed to fetch or parse items for genre URL: {url}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", "Failed to fetch category content", xbmcgui.NOTIFICATION_ERROR)

    # Asigură-te că finalizarea listei se face doar aici, după ce toate elementele au fost adăugate
    xbmcplugin.endOfDirectory(int(sys.argv[1]))



def list_genuri_seriale(url, page=1):
    html_content = get_html(url)

    if html_content:
        items = parse_items(html_content)

        if items:

            # Extrage URL-urile de paginare
            pagination_urls = extract_pagination_urls(html_content)
            next_page_url = pagination_urls[0] if pagination_urls else None

            # Listează item-urile și adaugă "Pagina următoare" dacă este cazul
            list_items(items, next_page_url=next_page_url)
        else:
            xbmcgui.Dialog().notification("Error", "No items found in this series genre", xbmcgui.NOTIFICATION_ERROR)
    else:
        xbmc.log(f"Failed to fetch or parse items for series genre URL: {url}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", "Failed to fetch series genre content", xbmcgui.NOTIFICATION_ERROR)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def list_ani_seriale(url, page=1):
    html_content = get_html(url)

    if html_content:
        items = parse_items(html_content)

        if items:

            # Extrage URL-urile de paginare
            pagination_urls = extract_pagination_urls(html_content)
            next_page_url = pagination_urls[0] if pagination_urls else None

            # Listează item-urile și adaugă "Pagina următoare" dacă este cazul
            list_items(items, next_page_url=next_page_url)
        else:
            xbmc.log(f"No items parsed from content at URL: {url}", level=xbmc.LOGWARNING)
            xbmcgui.Dialog().notification("Error", "No items found for this series year", xbmcgui.NOTIFICATION_ERROR)
    else:
        xbmc.log(f"Failed to fetch or parse items for series year URL: {url}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", "Failed to fetch series year content", xbmcgui.NOTIFICATION_ERROR)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def list_limba_seriale(url, page=1):
    html_content = get_html(url)

    if html_content:
        items = parse_items(html_content)

        if items:

            # Extrage URL-urile de paginare
            pagination_urls = extract_pagination_urls(html_content)
            next_page_url = pagination_urls[0] if pagination_urls else None

            # Listează item-urile și adaugă "Pagina următoare" dacă este cazul
            list_items(items, next_page_url=next_page_url)
        else:
            xbmc.log(f"No items parsed from content at URL: {url}", level=xbmc.LOGWARNING)
            xbmcgui.Dialog().notification("Error", "No items found for this series language", xbmcgui.NOTIFICATION_ERROR)
    else:
        xbmc.log(f"Failed to fetch or parse items for series language URL: {url}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", "Failed to fetch series language content", xbmcgui.NOTIFICATION_ERROR)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def parse_seriale_items(html_content):
    pattern = re.compile(
        r'<div id="mt-\d+" class="item">.*?<a href="(.*?)".*?<img src="(.*?)".*?alt="(.*?)".*?<span class="year">(.*?)</span>(?:.*?<span class="tipoitem">(.*?)</span>)?',
        re.DOTALL
    )

    items = pattern.findall(html_content)
    if not items:
        xbmc.log(f"parse_seriale_items: No items matched the pattern.", level=xbmc.LOGWARNING)
    else:
        xbmc.log(f"parse_seriale_items: {len(items)} items matched the pattern.", level=xbmc.LOGINFO)
    decoded_items = []
    for item in items:
        url, thumbnail, title, year = item[:4]
        description = item[4] if len(item) > 4 else ''
        decoded_items.append((url, thumbnail, html.unescape(title), year, html.unescape(description.strip())))

    return decoded_items

def play_movie(url):
    video_url, subtitles = get_video_url(url)
    if video_url:
        # Creează obiectul de redare
        play_item = xbmcgui.ListItem(path=video_url)

        # Setează subtitrările dacă au fost găsite
        if subtitles:
            play_item.setSubtitles(subtitles)
        else:
            xbmc.log("No subtitles found to add.", level=xbmc.LOGWARNING)
            # Redă videoclipul cu subtitrările setate
        xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=play_item)
    else:
        xbmc.log("Could not resolve video URL", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", "Could not resolve video URL", xbmcgui.NOTIFICATION_ERROR)

def search_and_play(title):
    # Căutăm filmul folosind titlul primit ca parametru
    search_query = quote(title)
    search_url_full = f"http://www.filmeserialeonline.org/?s={search_query}"
    html_content = get_html(search_url_full)

    # Interpretăm rezultatele căutării
    items = parse_search_results(html_content)

    # Dacă găsim rezultate, redăm primul film
    if items:
        first_item_url = items[0][0]  # Accesăm primul element din tuplu (presupunem că e URL-ul)
        play_movie(first_item_url)  # Folosim funcția existentă play_movie pentru redare
    else:
        xbmcgui.Dialog().notification("FSOnline", f"Nu am găsit niciun film pentru '{title}'", xbmcgui.NOTIFICATION_INFO)

def search_and_play_episode(showname, season, episode):
    # Folosim URL-ul direct al serialului, înlocuind spațiile cu '-'
    formatted_showname = showname.lower().replace(' ', '-')
    series_url = f"http://www.filmeserialeonline.org/seriale/{formatted_showname}/"

    # Jurnal pentru debugging
    xbmc.log(f"Direct series URL: {series_url}", level=xbmc.LOGINFO)

    # Obținem HTML-ul paginii serialului
    html_content = get_html(series_url)

    # Afișăm primele 1000 de caractere din HTML pentru a verifica structura
    xbmc.log(f"HTML content for {showname}: {html_content[:1000]}", level=xbmc.LOGINFO)

    if html_content:
        # Parsăm sezoanele și episoadele din HTML
        seasons = parse_seasons_episodes(html_content)
        if not seasons:
            xbmc.log(f"Search failed: No seasons found for {showname} season {season}.", level=xbmc.LOGERROR)
            xbmcgui.Dialog().notification("FSOnline", f"Nu am găsit sezoane pentru '{showname}'.", xbmcgui.NOTIFICATION_ERROR)
            return

        # Căutăm sezonul și episodul specific
        for season_data in seasons:
            if season_data['number'] == season:
                for episode_data in season_data['episodes']:
                    if episode_data['number'].startswith(f"{season} x {episode}"):
                        episode_url = episode_data['url']
                        # Jurnal pentru debugging
                        xbmc.log(f"Found episode URL: {episode_url}", level=xbmc.LOGINFO)
                        # Redăm episodul folosind funcția play_movie
                        play_movie(episode_url)
                        return

        xbmc.log(f"Episodul {episode} din sezonul {season} nu a fost găsit.", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification("FSOnline", f"Episodul {episode} din sezonul {season} nu a fost găsit.", xbmcgui.NOTIFICATION_INFO)
    else:
        xbmc.log(f"Failed to fetch HTML content for {showname}.", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification("FSOnline", f"Nu am găsit conținut pentru serialul '{showname}'", xbmcgui.NOTIFICATION_ERROR)

def show_filme_menu():
    xbmcplugin.setPluginCategory(int(sys.argv[1]), 'Filme')

    list_item = xbmcgui.ListItem(label='Genuri')
    list_item.setArt({'thumb': os.path.join(icon_path, 'genre.png'), 'icon': os.path.join(icon_path, 'genre.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=genuri_menu", listitem=list_item, isFolder=True)

    list_item = xbmcgui.ListItem(label='Ani')
    list_item.setArt({'thumb': os.path.join(icon_path, 'genre.png'), 'icon': os.path.join(icon_path, 'genre.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=ani_menu", listitem=list_item, isFolder=True)

    list_item = xbmcgui.ListItem(label='Limbă')
    list_item.setArt({'thumb': os.path.join(icon_path, 'genre.png'), 'icon': os.path.join(icon_path, 'genre.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=limba_menu", listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def show_seriale_menu():
    xbmcplugin.setPluginCategory(int(sys.argv[1]), 'Seriale')

    list_item = xbmcgui.ListItem(label='Genuri')
    list_item.setArt({'thumb': os.path.join(icon_path, 'genre.png'), 'icon': os.path.join(icon_path, 'genre.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=genuri_seriale_menu", listitem=list_item, isFolder=True)

    list_item = xbmcgui.ListItem(label='Ani')
    list_item.setArt({'thumb': os.path.join(icon_path, 'genre.png'), 'icon': os.path.join(icon_path, 'genre.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=ani_seriale_menu", listitem=list_item, isFolder=True)

    list_item = xbmcgui.ListItem(label='Limbă')
    list_item.setArt({'thumb': os.path.join(icon_path, 'genre.png'), 'icon': os.path.join(icon_path, 'genre.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=limba_seriale_menu", listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def show_main_menu():
    xbmcplugin.setPluginCategory(int(sys.argv[1]), 'Filme și Seriale')

    list_item = xbmcgui.ListItem(label='Filme')
    list_item.setArt({'thumb': os.path.join(icon_path, 'movies.png'), 'icon': os.path.join(icon_path, 'movies.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=filme_menu", listitem=list_item, isFolder=True)

    list_item = xbmcgui.ListItem(label='Seriale')
    list_item.setArt({'thumb': os.path.join(icon_path, 'tv.png'), 'icon': os.path.join(icon_path, 'tv.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=seriale_menu", listitem=list_item, isFolder=True)

    list_item = xbmcgui.ListItem(label='Căutare')
    list_item.setArt({'thumb': os.path.join(icon_path, 'search.png'), 'icon': os.path.join(icon_path, 'search.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=search", listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def search():
    keyboard = xbmc.Keyboard('', 'Caută')  # Deschide tastatura pentru a introduce termenul de căutare
    keyboard.doModal()  # Așteaptă inputul utilizatorului
    if keyboard.isConfirmed():  # Verifică dacă utilizatorul a confirmat inputul
        search_query = quote(keyboard.getText())  # Obține textul introdus
        search_url_full = f"http://www.filmeserialeonline.org/?s={search_query}"
        html_content = get_html(search_url_full)

        if html_content:
            items = parse_search_results(html_content)
            if items:
                list_items(items)
            else:
                xbmcgui.Dialog().notification("Căutare", "Nu au fost găsite rezultate", xbmcgui.NOTIFICATION_INFO, 5000)
                show_main_menu()
        else:
            xbmcgui.Dialog().notification("Eroare", "Nu s-a putut obține conținutul căutării", xbmcgui.NOTIFICATION_ERROR)

        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def parse_search_results(html_content):
    pattern = re.compile(
        r'<div id="mt-\d+" class="item">.*?<a href="(.*?)".*?<img src="(.*?)".*?alt="(.*?)".*?<span class="tipoitem">(.*?)</span>.*?<span class="year">(.*?)</span>',
        re.DOTALL
    )

    items = pattern.findall(html_content)
    decoded_items = []
    for url, thumbnail, title, description, year in items:
        decoded_items.append((
            url.strip(),
            thumbnail.strip(),
            html.unescape(title).strip(),
            year.strip(),
            html.unescape(description.strip())
        ))

    return decoded_items

def parse_seasons_episodes(html_content):
    # Regex pentru extragerea thumbnail-ului din pagina serialului
    thumbnail_pattern = re.compile(
        r'<div class="imagen">.*?<img src="(.*?)"',
        re.DOTALL
    )

    # Regex pentru sezoane (ajustat)
    seasons_pattern = re.compile(
        r'<div class="se-c">.*?<span class="se-t(?: se-o)?">(.*?)</span>\s*<span class="title">(.*?)</span>.*?<ul class="episodios">(.*?)</ul>',
        re.DOTALL
    )

    # Regex pentru episoade
    episodes_pattern = re.compile(
        r'<li>.*?<div class="numerando">(.*?)</div>.*?<div class="episodiotitle">.*?<a href="(.*?)".*?>(.*?)</a>.*?<span class="date">(.*?)</span>.*?<span class="eyes">.*?<b class="icon-time".*?</b>\s*(.*?)</span>',
        re.DOTALL
    )

    # Extragerea thumbnail-ului
    thumbnail_match = thumbnail_pattern.search(html_content)
    thumbnail = thumbnail_match.group(1).strip() if thumbnail_match else ''
    xbmc.log(f"Found series thumbnail: {thumbnail}", level=xbmc.LOGINFO)

    seasons = []
    for season_match in seasons_pattern.findall(html_content):
        season_number, season_title, episodes_html = season_match
        xbmc.log(f"Found season: {season_number} - {season_title}", level=xbmc.LOGINFO)

        episodes = []
        for episode_match in episodes_pattern.findall(episodes_html):
            episode_number, episode_url, episode_title, episode_date, episode_duration = episode_match
            xbmc.log(f"Found episode: {episode_title} with URL {episode_url}", level=xbmc.LOGINFO)
            episodes.append({
                'number': episode_number.strip(),
                'url': episode_url.strip(),
                'title': html.unescape(episode_title).strip(),
                'date': episode_date.strip(),
                'duration': episode_duration.strip(),
                'thumbnail': thumbnail  # Folosim thumbnail-ul serialului dacă nu există un thumbnail specific pentru episod
            })

        seasons.append({
            'number': season_number.strip(),
            'title': html.unescape(season_title).strip(),
            'thumbnail': thumbnail,  # Asigură-te că thumbnail-ul este adăugat pentru fiecare sezon
            'episodes': episodes
        })

    xbmc.log(f"Total seasons found: {len(seasons)}", level=xbmc.LOGINFO)
    return seasons

def list_seasons(url, thumbnail=None):
    html_content = get_html(url)
    if html_content:
        seasons = parse_seasons_episodes(html_content)

        # Verificare dacă sezoanele au fost găsite
        if not seasons:
            xbmc.log("No seasons found in the provided HTML content.", level=xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Error", "No seasons found", xbmcgui.NOTIFICATION_ERROR)
            return

        xbmc.log(f"Total seasons to display: {len(seasons)}", level=xbmc.LOGINFO)
        for season in seasons:
            season_url = f"{sys.argv[0]}?action=list_episodes&url={quote(url)}&season={season['number']}&thumbnail={quote(season['thumbnail'])}"
            list_item = xbmcgui.ListItem(label=f"Sezonul {season['number']}")

            # Setează thumbnail-ul pentru sezon
            if season.get('thumbnail'):
                list_item.setArt({'thumb': season['thumbnail'], 'icon': season['thumbnail']})
            elif thumbnail:
                list_item.setArt({'thumb': thumbnail, 'icon': thumbnail})

            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=season_url, listitem=list_item, isFolder=True)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    else:
        xbmc.log(f"Failed to fetch HTML content for seasons from URL: {url}", level=xbmc.LOGERROR)

def list_episodes(url, season_number, thumbnail):
    html_content = get_html(url)
    if html_content:
        seasons = parse_seasons_episodes(html_content)
        for season in seasons:
            if season['number'] == season_number:
                for episode in season['episodes']:

                    list_item = xbmcgui.ListItem(label=episode['title'])

                    # Setează informațiile episodului, inclusiv thumbnail-ul
                    list_item.setInfo('video', {
                        'title': episode['title'],
                        'date': episode['date'],
                        'duration': episode['duration']
                    })
                    list_item.setProperty('IsPlayable', 'true')

                    # Dacă există thumbnail specific pentru episod, folosește-l, altfel folosește thumbnail-ul sezonului
                    if episode.get('thumbnail'):
                        list_item.setArt({'thumb': episode['thumbnail'], 'icon': episode['thumbnail']})
                    else:
                        list_item.setArt({'thumb': thumbnail, 'icon': thumbnail})

                    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=play_episode&url={quote(episode['url'])}", listitem=list_item, isFolder=False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    else:
        xbmc.log(f"Failed to fetch HTML content for episodes from URL: {url}", level=xbmc.LOGERROR)

def main():
    args = sys.argv[2][1:].split('&')
    params = {}
    for arg in args:
        if '=' in arg:
            key, value = arg.split('=', 1)
            params[key] = value

    action = params.get('action')
    url = unquote(params.get('url', ''))
    page = int(params.get('page', '1'))
    season_number = params.get('season', '')
    thumbnail = unquote(params.get('thumbnail', ''))

    xbmc.log(f"Action: {action}, URL: {url}, Page: {page}, Season: {season_number}, Thumbnail: {thumbnail}", level=xbmc.LOGINFO)
    xbmc.log(f"Action: {action}, URL: {url}, Page: {page}", level=xbmc.LOGINFO)

    if not action:
        show_main_menu()
        return

    if action == 'filme_menu':
        show_filme_menu()
        return
    elif action == 'genuri_menu':
        list_genuri_menu()
        return
    elif action == 'ani_menu':
        list_ani_menu()
        return
    elif action == 'limba_menu':
        list_limba_menu()
        return
    elif action == 'genuri_filme':
        list_genuri_filme(url, page)
        return
    elif action == 'ani_filme':
        list_genuri_filme(url, page)
        return
    elif action == 'limba_filme':
        list_genuri_filme(url, page)
        return
    elif action == 'seriale_menu':
        show_seriale_menu()
        return
    elif action == 'genuri_seriale_menu':
        list_genuri_seriale_menu()
        return
    elif action == 'genuri_seriale':
        list_genuri_seriale(url, page)
        return
    elif action == 'ani_seriale_menu':
        list_ani_seriale_menu()
        return
    elif action == 'ani_seriale':
        list_ani_seriale(url, page)
        return
    elif action == 'limba_seriale_menu':
        list_limba_seriale_menu()
        return
    elif action == 'limba_seriale':
        list_limba_seriale(url, page)
        return
    elif action == 'list_seasons':
        list_seasons(url, thumbnail)
        return
    elif action == 'list_episodes':
        list_episodes(url, season_number, thumbnail)
        return
    elif action == 'search':
        search()
        return
    elif action == 'next_page':
        list_genuri_filme(url, page)
        return
    elif action == 'play_movie':
        play_movie(url)
        return
    elif action == 'play_episode':
        play_movie(url)
        return
    elif action == 'search_and_play':
        title = unquote(params.get('title', ''))
        search_and_play(title)
        return
    elif action == 'search_and_play_episode':
        showname = unquote(params.get('title', ''))
        season = unquote(params.get('season', ''))
        episode = unquote(params.get('episode', ''))
        search_and_play_episode(showname, season, episode)
        return

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

if __name__ == '__main__':
    main()
