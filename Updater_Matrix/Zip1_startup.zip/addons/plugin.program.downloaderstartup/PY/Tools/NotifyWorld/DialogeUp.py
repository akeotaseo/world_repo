﻿import xbmc, xbmcgui


def DialogeUp():
        
        choice = xbmcgui.Dialog().yesno('[B][COLOR green]Ενημερώσεις Πρόσθετων[/COLOR][/B]', 'Θέλετε να δείτε τις ενημερώσεις των πρόσθετων ;',
                                        nolabel='[COLOR red]Οχι[/COLOR]',yeslabel='[COLOR green]Ναι[/COLOR]')

        if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/skin.19MatrixWorld/xml/Up.py")'),
                         ]
                         

DialogeUp()
