# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests

class RTVS:
    def __init__(self):
        self.API = "https://www.rtvs.sk/json/live5f.json?c="
        self.channels = {
            'STV1': '1',
            'STV2': '2',
            'STV24': '3',
            'SPORT': '15',
            'O': '4',
            'RTVS': '6',
            'NRSR': '5'
        }
        self.alternatives = {
            'STV2': 'http://213.151.233.20:8000/dna-5105-tv-pc.m3u8'
        }
        self.ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36'
    
    def grab(self, channel):
        if channel not in self.channels: return 'Channel not found'
        hlsurl = ""
        headers = {'User-Agent': self.ua}
        if channel in self.alternatives:
            hlsurl = self.alternatives[channel]
        else:
            url = self.API + self.channels[channel]
            hlsurl = requests.get(url).json()['clip']['sources'][0]['src']
        return hlsurl, headers
            
