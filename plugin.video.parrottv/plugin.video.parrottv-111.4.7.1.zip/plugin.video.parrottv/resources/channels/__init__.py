import os
import xbmcaddon
import sys
import io
import resources

_ADDON = xbmcaddon.Addon()
PATH = 'special://home/addons/'+_ADDON.getAddonInfo('id')+'/resources/channels'
PATH = resources.translatePath(PATH)

for filename in os.listdir(PATH):
    if filename.endswith('.py') and filename != '__init__.py':
        file = io.open(PATH+'/'+filename, 'r', encoding="utf-8").read() 
        class_name = file.split('class ')[1].split(':')[0]
        if sys.version_info[0] == "2":
            exec("from {filename} import {class_name}".format(filename=filename[:-3], class_name=class_name))
        else:
            exec("from resources.channels.{filename} import {class_name}".format(filename=filename[:-3], class_name=class_name))