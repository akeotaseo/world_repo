import re, os, random
import xbmcaddon, xbmcvfs
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

Thumb   = 'special://home/addons/plugin.video.xxx/resources/art/favourites.png'

def Browse():
	file = xbmcvfs.translatePath(os.path.join('special://userdata/addon_data/plugin.video.xxx', 'favourites.xml'))
	items = Common.OpenFile(file)
	videos = []
	entries = re.compile('<i title="(.+?)" icon="(.+?)" url="(.+?)" />').findall(items)
	for title, icon, url in entries:
		videos.append(
			{
				'title': title,
				'icon': icon,
				'url': url
			}
		)
	
	if Setting('rec_random') == 'true': random.shuffle(videos)
	for i in videos:
		if 'pornohd.porn' in i['url']: mode = 23
		if 'xcum.com'     in i['url']: mode = 33
		if 'xtits.com'    in i['url']: mode = 43
		if 'zbporn.com'   in i['url']: mode = 53
		if 'pornhat.com'  in i['url']: mode = 63
		if 'goodporn.to'  in i['url']: mode = 73
		if 'hog.tv'       in i['url']: mode = 83
		if 'xhand.com'    in i['url']: mode = 93
		if 'xozilla.com'  in i['url']: mode = 103
		if 'hqporner.com' in i['url']: mode = 123
		if 'pornone.com'  in i['url']: mode = 133
		if 'porntrex.com' in i['url']: mode = 153
		if Setting('rec_watched') == 'true':
			url = '%s&random_id=%s' % (i['url'], RandomID())
		else:
			url = '%s&random_id=%s' % (i['url'], '00000')
		addVideo(i['title'], url, mode, i['icon'])
	
	Common.SetView()
	
def RandomID():
	import random
	random_id = str(random.randint(0,1000000))
	return random_id