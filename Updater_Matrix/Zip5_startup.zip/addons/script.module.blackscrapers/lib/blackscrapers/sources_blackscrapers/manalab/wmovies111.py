# -*- coding: utf-8 -*-
import re
import json
import base64
from urllib.parse import urlparse

# Imports
from blackscrapers import parse_qs, urlencode
from blackscrapers.modules import client
from blackscrapers.modules import log_utils

# Crypto Check
try:
    from Cryptodome.Cipher import AES
    from Cryptodome.Util.Padding import pad
except ImportError:
    try:
        from Crypto.Cipher import AES
        from Crypto.Util.Padding import pad
    except:
        log_utils.log('WMOVIES111 - PyCryptodome not found', 1)

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domain = ['111movies.com']
        self.base_link = 'https://111movies.com'
        self.headers = {
            "User-Agent": client.agent(),
            "Content-Type": "text/javascript",
            "X-Csrf-Token": "WP6BXZEsOAvSP0tk4AhxIWllVsuBx0Iy"
        }

    def movie(self, imdb, tmdb, title, localtitle, aliases, year):
        try:
            if imdb:
                return f"{self.base_link}/movie/{imdb}"
            return
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            if tvdb:
                data = {'tvdb': tvdb, 'year': year}
                return urlencode(data)
            return
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url: return
            
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            
            target_id = data.get('tvdb')
            
            if not target_id: return

            s = int(season)
            e = int(episode)
            
            post_url = f"{self.base_link}/tv/{target_id}/{s}/{e}"
            return post_url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if not url: return sources

            parsed_uri = urlparse(self.base_link)
            domain = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)
            
            headers = self.headers.copy()
            headers['Referer'] = domain

            # 1. Request σελίδας (Γρήγορο)
            response = client.request(url, headers=headers, timeout=10)

            # 2. Crypto Logic (Το κρίσιμο σημείο που δουλεύει)
            match = re.search(r'{\"data\":\"(.*?)\"', response)
            if not match: return sources
            raw_data = match.group(1)

            aes_key = bytes([138, 238, 17, 197, 68, 75, 124, 44, 53, 79, 11, 131, 216, 176, 124, 80, 161, 126, 163, 21, 238, 68, 192, 209, 135, 253, 84, 163, 18, 158, 148, 102])
            aes_iv = bytes([181, 63, 33, 220, 121, 92, 190, 223, 94, 49, 56, 160, 53, 233, 201, 230])

            cipher = AES.new(aes_key, AES.MODE_CBC, aes_iv)
            padded_data = pad(raw_data.encode(), AES.block_size)
            aes_encrypted = cipher.encrypt(padded_data).hex()

            xor_key = bytes([215, 136, 144, 55, 198])
            xor_result = ''.join(chr(ord(char) ^ xor_key[i % len(xor_key)]) for i, char in enumerate(aes_encrypted))

            def custom_encode(input_str):
                src = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_"
                dst = "c86mtuVv2EUlDgX-1YSpoiTq9WJadfzNe_Rs53kMrKHQZnxL0wGCFBhb7AP4yIOj"
                trans = str.maketrans(src, dst)
                b64 = base64.b64encode(input_str.encode()).decode().replace('+', '-').replace('/', '_').replace('=', '')
                return b64.translate(trans)

            encoded_final = custom_encode(xor_result)
            
            static_path = "h/APA91Pu8JKhvEMftnB2QqFE9aSTlLqQF4iF0DRuk7YXkLqvJaUmlRlblS_1ZK6t2VIbx68GVQ5AVkepTGy82DLIz_uAyGx3Z421GLf2TIhbySFvE1bOInrzHRKLtjkPTpliKjWPhvPIzDjFmHp4zwMvRvqLhstjw4CVCy8jn-BuTxk1SRkl8s1r/ef860363-4e1b-5482-8d76-ec6fdebe974b/e993fc0bc499fdfb502f96b85963f9f0bbc698dd/wiv/1000044292358307/1bda1d30afdf5f775dcddb0a888bf9898b90ad4d3e1089396585236913b00773/ar"
            api_servers_url = f"{self.base_link}/{static_path}/{encoded_final}/sr"
            
            # 3. Παίρνουμε τη λίστα servers (Αυτό είναι γρήγορο)
            api_resp = client.request(api_servers_url, headers=headers, timeout=10)
            try:
                servers_data = json.loads(api_resp)
            except:
                return sources

            # 4. ΒΡΟΧΟΣ (Εδώ κάναμε την αλλαγή)
            # ΔΕΝ ζητάμε το τελικό βίντεο εδώ. Απλά φτιάχνουμε το Link για να το ζητήσουμε αργότερα.
            
            for rsp in servers_data:
                server_hash = rsp.get('data')
                server_name = rsp.get("name", "Unknown")
                if not server_hash: continue

                # Φτιάχνουμε το URL που θα λύσουμε στο resolve()
                # Δεν κάνουμε client.request εδώ!
                api_stream_url = f"{self.base_link}/{static_path}/{server_hash}"
                
                sources.append({
                    'source': '111movies',
                    'quality': '1080p',
                    'language': 'en',
                    'url': api_stream_url, # Δίνουμε το API URL
                    'info': server_name,   # Charlie, India etc
                    'direct': False,       # False = Χρειάζεται resolve
                    'debridonly': False
                })

            return sources
        except Exception as e:
            log_utils.log(f'111MOVIES - Exception: {e}', 1)
            return sources

    def resolve(self, url):
        # 5. AYSTHRO RESOLVE (Για να δουλέψει το "Next Source")
        try:
            if not url: return None # Επιστρέφουμε None αντί για σκουπίδια

            parsed_uri = urlparse(self.base_link)
            domain = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)
            headers = self.headers.copy()
            headers['Referer'] = domain

            # Κάνουμε το request
            r = client.request(url, headers=headers, timeout=10)
            
            if not r: return None # Αν δεν απαντήσει, None

            try:
                data = json.loads(r)
                final_link = data.get('url') or data.get('link') or data.get('src')
            except:
                return None # Αν δεν είναι JSON, είναι λάθος, άρα None

            # Έλεγχος αν το link είναι υπαρκτό
            if final_link and 'http' in final_link:
                return final_link
            
            # Αν φτάσαμε εδώ, κάτι πήγε στραβά, επιστρέφουμε None
            return None 

        except:
            # Σε περίπτωση error, επιστρέφουμε None για να πάει στο επόμενο
            return None