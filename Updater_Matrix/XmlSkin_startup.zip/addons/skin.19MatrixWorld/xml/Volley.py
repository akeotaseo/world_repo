import xbmc, xbmcgui



def Volley():
    funcs = (click_1, click_2,)
    call = xbmcgui.Dialog().select('[B][COLOR=blue]       VOLLEY[/COLOR][/B]',
['[COLOR=yellow]Volley  ([COLOR blue]Daddylive[/COLOR])',

 '[COLOR=blue]Volley  ([COLOR yellow]MatrixFlix Media[/COLOR])'

 # '[COLOR=green]Volley[/COLOR] (Dracarys)'


 ])




    if call:
        if call < 1:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('RunScript("special://home/addons/skin.19MatrixWorld/xml/Dialog Spor/DialogDLvolley.py")')
def click_2():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.matrixflix/?function=showMovies&sFav=showMovies&sMovieTitle=Volleyball&site=livetv&siteUrl2=https%3a%2f%2flivetv821.me%2f%2fenx%2fallupcomingsports%2f5%2f&title=Volleyball")')
    xbmcgui.Dialog().notification("[B][COLOR blue]Volley[/COLOR][/B]", "[COLOR yellow]MatrixFlix Media[/COLOR]", sound=False, icon='special://home/addons/plugin.video.matrixflix/resources/art/sport.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR blue]Volley[/COLOR][/B]", "[COLOR yellow]MatrixFlix Media[/COLOR]", sound=False, icon='special://home/addons/plugin.video.matrixflix/resources/art/sport.png')
    xbmcgui.Dialog().notification("[B][COLOR blue]Volley[/COLOR][/B]", "[COLOR yellow]MatrixFlix Media[/COLOR]", sound=False, icon='special://home/addons/plugin.video.matrixflix/resources/art/sport.png')

# def click_2():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dracarys/?category=live_sport&mode=open_site_category&site=livetv&url=https%3a%2f%2flivetv751.me%2fenx%2fallupcomingsports%2f5%2f")')
    # xbmcgui.Dialog().notification("[B][COLOR yellow]Volley[/COLOR][/B]", "[COLOR green]Dracarys[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/iloveimg-resized(2)/Dracarys.png')
    # xbmc.sleep(4000)
    # xbmcgui.Dialog().notification("[B][COLOR yellow]Volley[/COLOR][/B]", "[COLOR green]Dracarys[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/iloveimg-resized(2)/Dracarys.png')
    # xbmcgui.Dialog().notification("[B][COLOR yellow]Volley[/COLOR][/B]", "[COLOR green]Dracarys[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/iloveimg-resized(2)/Dracarys.png')


Volley()
