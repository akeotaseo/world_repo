# -*- coding: utf-8 -*-

import sys
import xbmcaddon, xbmcgui, xbmcplugin

# Plugin Info
ADDON_ID      = 'plugin.video.takeroom'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1=  "channel/UCTJ9Qg-1vBu2pP_YrWUfGnQ"
YOUTUBE_CHANNEL_ID2=  "channel/UCwuMGwU6kX_lvkrYoVQWBGw"
YOUTUBE_CHANNEL_ID3=  "channel/UCNpUrH2KLq5dfwU_wohD9fA"
YOUTUBE_CHANNEL_ID4=  "channel/UCmvAV_za1KXGXSgC0o0v9DQ"
YOUTUBE_CHANNEL_ID5=  "channel/UCg8AmJuGLr-bc8GbR3WdZmA"


icon1 = "https://yt3.ggpht.com/a/AATXAJwgI97ogMNV-TZGsKURU1GUXathXBXFFYaPhjhT=s256-c-k-c0x00ffffff-no-rj"
icon2 = "https://yt3.ggpht.com/a/AATXAJxuM8HSgjLG6NvqNQCe537rpx1Aqa-9IzJ0fj8guQ=s256-c-k-c0x00ffffff-no-rj"
icon3 = "https://yt3.ggpht.com/a/AATXAJz8kjF_ZH90PkroVthQVzKt1-hdYK2nMjcYTTIL=s256-c-k-c0x00ffffff-no-rj"
icon4 = "https://yt3.ggpht.com/a/AATXAJwlO39rBnA17dxsut4EDP5B6jWW6TV7_nm3yFx-BQ=s256-c-k-c0x00ffffff-no-rj"
icon5 = "https://yt3.ggpht.com/a/AATXAJyyNSwjF9pUuEFC4D8nMZO2tahw5uxCl51ZUYLN=s256-c-k-c0x00ffffff-no-rj"


def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    
def main():

   addDir(title = "Miracle Music",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",thumbnail = icon1,)
   addDir(title = "Tropical House Radio",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",thumbnail = icon2,)
   addDir(title = "Deep Legacy.",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",thumbnail = icon3,)
   addDir(title = "Miracle Vibes",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID4+"/",thumbnail = icon4,)
   addDir(title = "Miracle Music - Música Electrónica",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID5+"/",thumbnail = icon5,)
   

   xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)

	


