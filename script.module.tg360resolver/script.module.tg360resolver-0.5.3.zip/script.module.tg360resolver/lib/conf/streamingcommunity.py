import re
from conf.common import CommonResolver
import json


class StreamCommunity(CommonResolver):

    def set_servers(self):
        return ['streamingcommunity.xyz', 'streamingcommunity.one', 'streamingcommunity.tv', 'streamingcommunity.vip', 'streamingcommunity.work',
                'streamingcommunity.name', 'streamingcommunity.video', 'streamingcommunity.live', 'streamingcommunity.space', 'streamingcommunity.art', 'streamingcommunity.fun', 'streamingcommunity.website', 'streamingcommunity.host', 
                'streamingcommunity.site', 'streamingcommunity.bond', 'streamingcommunity.icu' , 'streamingcommunity.bar', 'streamingcommunity.top', 'streamingcommunity.cc', 'streamingcommunity.monster', 'streamingcommunity.press', 'streamingcommunity.business', 'streamingcommunity.org', 'streamingcommunity.best', 'streamingcommunity.agency', 'streamingcommunity.blog']

    def get_host(self):
        res = self.resolver.cli.get_request("https://streamingcommunity-nuovo.com").text
        try:
            domain = re.compile(r'var domain\s+=\s+\"([^\"]+)\"').findall(res)[0]
            return "https://" + domain
        except:
            return None

    def find_stream(self):
        host = self.get_host()
        if not host:
            host = self.resolver.find_hostname(self.resolver.start_url)

        url = re.sub(r"^(http.*?://.*?\.[\w]+)/", host + "/", self.resolver.start_url, 0, re.MULTILINE)

        html = self.resolver.cli.get_request(url).text
        matches = re.compile(r"<video-player.*?scws_id.*?:(\d+)", re.DOTALL).findall(html)

        if matches:
            scws_id = matches[0]
            res = self.resolver.cli.get_request('https://scws.xyz/videos/' + scws_id,
                                                headers={'Referer': self.page_url}).text
            a = json.loads(res).get('client_ip')
            url = 'https://scws.xyz/master/{0}?{1}'.format(scws_id, self.get_token(a))
            return [url]

    def set_referer(self, url):
        return self.page_url + "&user-agent=" + self.resolver.cli.headers["user-agent"]

    @staticmethod
    def get_token(a):
        import time
        import base64
        from Cryptodome.Hash import MD5
        t = int(time.time() + 172800)
        s = '{0}{1} Yc8U6r8KjAKAepEA'.format(t, a)
        c = base64.b64encode(MD5.new(s.encode('utf-8')).digest()).decode('utf-8')
        c = c.replace('=', '').replace('+', '-').replace('/', '_')
        return 'token={0}&expires={1}&n=1'.format(c, t)
