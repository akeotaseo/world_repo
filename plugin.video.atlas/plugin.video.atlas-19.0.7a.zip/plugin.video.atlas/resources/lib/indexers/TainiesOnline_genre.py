import xbmc, xbmcgui


def tainiesonline_genre():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13, click_14,
             click_15, click_16, click_17, click_18, click_19, click_20, click_21)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]                                            Κατηγορίες [/COLOR][/B]', 
['[B][COLOR=white]                                                       Western[/COLOR][/B]',
 '[B][COLOR=white]                                                    Αστυνομική[/COLOR][/B]',
 '[B][COLOR=white]                                                         Δράμα[/COLOR][/B]',
 '[B][COLOR=white]                                                         Δράση[/COLOR][/B]',
 '[B][COLOR=white]                                                 Επ. Φαντασίας[/COLOR][/B]',
 '[B][COLOR=white]                                                        Θρίλερ[/COLOR][/B]',
 '[B][COLOR=white]                                                      Ιστορική[/COLOR][/B]',
 '[B][COLOR=white]                                              Κινούμενα σχέδια[/COLOR][/B]',
 '[B][COLOR=white]                                                       Κωμωδία[/COLOR][/B]',
 '[B][COLOR=white]                                            Action & Adventure[/COLOR][/B]',
 '[B][COLOR=white]                                                       Μουσική[/COLOR][/B]',
 '[B][COLOR=white]                                                     Μυστηρίου[/COLOR][/B]',
 '[B][COLOR=white]                                                   Ντοκιμαντέρ[/COLOR][/B]',
 '[B][COLOR=white]                                                  Οικογενειακή[/COLOR][/B]',
 '[B][COLOR=white]                                                    Περιπέτεια[/COLOR][/B]',
 '[B][COLOR=white]                                                      Πολεμική[/COLOR][/B]',
 '[B][COLOR=white]                                                     Ρομαντική[/COLOR][/B]',
 '[B][COLOR=white]                                                        Τρόμου[/COLOR][/B]',
 '[B][COLOR=white]                                                     Φαντασίας[/COLOR][/B]',
 '[B][COLOR=white]                                             Τηλεοπτική Ταινία[/COLOR][/B]',
 '[B][COLOR=white]                                            Χριστουγεννιάτικες[/COLOR][/B]'])

    if call:
        if call < 0:
            return
        func = funcs[call-21]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/western/)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/astinomiki/)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/drama/)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/drasi/)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/epistimonikis-fantasias/)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/thriler/)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/istoriki/)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/%ce%ba%ce%b9%ce%bd%ce%bf%cf%8d%ce%bc%ce%b5%ce%bd%ce%b1-%cf%83%cf%87%ce%ad%ce%b4%ce%b9%ce%b1/)')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/komodia/)')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/action-adventure/)')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/nousiki/)')

def click_12():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/mistiriou/)')

def click_13():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/ntokimanter/)')

def click_14():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/ikogeniaki/)')

def click_15():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/peripetia/)')

def click_16():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/polemiki/)')

def click_17():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/romantiki/)')

def click_18():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/tromou/)')

def click_19():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/fantasias/)')

def click_20():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/tileoptiki-tenia/)')

def click_21():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/christmas/)')
