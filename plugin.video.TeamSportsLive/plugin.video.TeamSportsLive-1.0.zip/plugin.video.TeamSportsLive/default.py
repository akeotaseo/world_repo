# -*- coding: utf-8 -*-
from libs import addon
addon.run()