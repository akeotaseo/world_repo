import os
import re
import time
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from itertools import islice
from dateutil.parser import parse
from dateutil.tz import gettz
from .peewee import SqliteDatabase, Model, IntegerField, TextField, ForeignKeyField, DoesNotExist

db = SqliteDatabase(None, pragmas={"foreign_keys": 1})


class BaseModel(Model):
    class Meta:
        database = db


class Event(BaseModel):
    data_age = IntegerField(default=time.time)
    web_url = TextField()
    event_time = IntegerField()
    sport = TextField()
    competition = TextField()
    event = TextField()


class Channel(BaseModel):
    data_age = IntegerField(default=time.time)
    channel_id = IntegerField(primary_key=True)
    title = TextField()
    web_url = TextField()
    ace_cid = TextField(null=True)
    ace_url = TextField(null=True)


class Live(BaseModel):
    title = TextField()
    event_id = ForeignKeyField(Event, backref="channels")
    channel_id = ForeignKeyField(Channel, backref="events")


class ArenaVision(object):
    def __init__(self, cache_dir):
        DB = os.path.join(cache_dir, "arenavisionl0.db")
        db.init(DB)
        db.connect()
        db.create_tables(
            [
                Event,
                Channel,
                Live,
            ],
            safe=True,
        )

        self.user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.0.0 Safari/537.36"
        self.base_url = "https://linkotes.com/arenavision/"
        self.s = requests.Session()
        self.s.headers.update(
            {
                "User-Agent": self.user_agent,
                "Accept-Encoding": "gzip, deflate",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.5",
            }
        )

    def __del__(self):
        self.s.close()
        db.close()

    def get_url(self, url, headers={}):
        r = self.s.get(url, headers=headers, timeout=10)
        r.raise_for_status()
        res_url = r.url
        soup = BeautifulSoup(r.text, "html.parser")
        return res_url, soup

    def resolve_channel(self, channel):
        headers = {"Referer": self.base_url, "X-Requested-With": "XMLHttpRequest"}
        data = {"id": channel.channel_id, "nocatxe": 0}
        r = self.s.post(channel.web_url, headers=headers, data=data)
        r.raise_for_status()
        res = r.json()
        if "ace" in res:
            if res["ace"]:
                channel.ace_cid = res["ace"][-40:]
        if "acelive" in res:
            if res["acelive"]:
                channel.ace_url = res["acelive"]
        channel.save()
        return channel

    def get_event_by_id(self, event_id):
        return Event.get(Event.id == event_id)

    def get_events(self):
        if Event.select().where(Event.data_age + 2 * 60 * 60 > int(time.time())).count() == 0:
            self.update_guide()
        return Event.select()

    def get_channel_by_id(self, channel_id):
        try:
            return Channel.get(Channel.channel_id == channel_id)
        except DoesNotExist:
            return None

    def get_channels(self):
        if Channel.select().where(Channel.data_age + 2 * 60 * 60 > int(time.time())).count() == 0:
            self.update_guide()

        return Channel.select()

    def update_guide(self):
        base_url, base_soup = self.get_url(self.base_url)
        id_re = re.compile("av(\d+)", re.I)
        new_channels = []
        update_channels = []
        uniq = []
        for a in base_soup.find_all("a", text=re.compile("av\d+", re.I)):
            title = a.get_text(strip=True)
            id_match = re.match(id_re, title)
            if id_match:
                channel_id = int(id_match.group(1))
                if channel_id in uniq:
                    continue
                else:
                    uniq.append(channel_id)
                web_url = urljoin(base_url, "aj_canal.php")
                channel = self.get_channel_by_id(channel_id)
                if channel:
                    channel.data_age = time.time()
                    channel.web_url = web_url
                    channel.ace_cid = None
                    channel.ace_url = None
                    update_channels.append(channel)
                else:
                    new_channels.append(Channel(channel_id=int(id_match.group(1)), title=title, web_url=web_url))
        with db.atomic():
            Channel.bulk_create(new_channels, batch_size=50)
            Channel.bulk_update(
                update_channels,
                fields=[Channel.data_age, Channel.web_url, Channel.ace_cid, Channel.ace_url],
                batch_size=50,
            )

        guide_url = base_url
        guide_soup = base_soup.select_one("#agenda_av")

        events = []
        links_live = []
        events_table = guide_soup.select("table")
        if events_table:
            with db.atomic():
                Live.delete().execute()
                Event.delete().execute()
            for table in events_table:
                day = table.previous_sibling.get_text(strip=True).split(" ")[-1]
                rows = table.select("tr")
                for event in islice(rows, 1, len(rows)):
                    tds = event.find_all("td")
                    event_time = parse(
                        "{0} {1}".format(day, tds[0].get_text(strip=True)),
                        dayfirst=True,
                    ).replace(tzinfo=gettz("Europe/Madrid"))
                    event_time_int = int(event_time.timestamp())
                    event, competition = re.search("([^\(]*)\s*\(([^\)]+)", tds[2].get_text(strip=True)).groups()
                    event = event or competition
                    new_event = Event(
                        web_url=guide_url,
                        event_time=event_time_int,
                        sport=tds[1].get_text(strip=True),
                        competition=competition.strip(),
                        event=event.strip(),
                    )
                    new_event.save()

                    title = "[UNK]"
                    for t in tds[3].stripped_strings:
                        if ":" in t:
                            title = f'[{t.strip(":").upper()}]'
                            continue
                        re_ch = re.search('av(\d+)', t, re.I)
                        if re_ch:
                            _id = int(re_ch.group(1))
                            if Channel.select().where(Channel.channel_id == _id):
                                links_live.append(
                                    Live(
                                        title=title,
                                        event_id=new_event,
                                        channel_id=Channel.get(Channel.channel_id == _id),
                                    )
                                )
                    events.append(new_event)

            with db.atomic():
                Live.bulk_create(links_live, batch_size=100)
                print("guide updated")
