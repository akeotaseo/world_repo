﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcvfs, sys, json, os, re, glob, shutil

###########################################
# from updatervar import *
# from resources.lib.modules import check
###########################################
# from xbmc import executebuiltin
# from xbmcaddon import Addon
# from os.path import exists,join
# from os import makedirs
# from xbmcvfs import translatePath
###########################################




xbmcvfs.delete('special://home/addons/plugin.video.vnmedia/service.py')
xbmc.sleep(2000)

# pack = translatePath('special://home/addons/packages')

# if not exists(pack):
    # makedirs(pack)
# packfolders = 'packages'





xbmcvfs.delete('special://home/addons/skin.19MatrixWorld/xml/Dialog Spor/DialogÆorquelite.py')







                       #script.artistslideshow
base_path = xbmcvfs.translatePath('special://home/userdata/addon_data/script.artistslideshow')

dir_list = glob.iglob(os.path.join(base_path, "ArtistInformation"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)


base_path = xbmcvfs.translatePath('special://home/userdata/addon_data/script.artistslideshow')

dir_list = glob.iglob(os.path.join(base_path, "ArtistSlideshow"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)


                                 #temp
base_path = xbmcvfs.translatePath('special://home/addons')

dir_list = glob.iglob(os.path.join(base_path, "temp"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)


xbmc.executebuiltin('PlayMedia("plugin://plugin.video.sporthdme/?url=clear&mode=clear&name=%5BB%5D%5BCOLOR+gold%5DClear+Addon+Data%5B%2FCOLOR%5D%5B%2FB%5D&iconimage=C%3A%5CPortableApps%5Ckodi%5Ckodi+World+21%5CKodi%5Cportable_data%5Caddons%5Cplugin.video.sporthdme%5Cicon.png&description=C%3A%5CPortableApps%5Ckodi%5Ckodi+World+21%5CKodi%5Cportable_data%5Caddons%5Cplugin.video.sporthdme%5Cfanart.jpg")")')
xbmc.sleep(6000)
xbmc.executebuiltin('PlayMedia("plugin://plugin.video.atlas/?url=&mode=9&name=%5BB%5D%5BCOLOR+white%5D%CE%95%CE%BA%CE%BA%CE%B1%CE%B8%CE%AC%CF%81%CE%B9%CF%83%CE%B7+Cache%5B%2FCOLOR%5D%5B%2FB%5D&iconimage=https%3A%2F%2Fi.imgur.com%2F2cPUPkf.png&description=")')
xbmc.sleep(5000)
xbmc.executebuiltin('PlayMedia("plugin://plugin.video.microjen/clear_cache_silent")')
xbmc.sleep(10000)
xbmc.executebuiltin('PlayMedia("plugin://plugin.program.downloader19/?url=&mode=23&name=%5BB%5D%5BCOLOR+white%5D%CE%9A%CE%B1%CE%B8%CE%B1%CF%81%CE%B9%CF%83%CE%BC%CF%8C%CF%82+%CE%A0%CE%B1%CF%81%CF%8C%CF%87%CF%89%CE%BD%5B%2FCOLOR%5D%5B%2FB%5D&icon=special%3A%2F%2Fhome%2Faddons%2Fplugin.program.downloader19%2Fresources%2Fmedia%2FWorld.png&fanart=C%3A%5CPortableApps%5Ckodi%5Ckodi+World+21%5CKodi%5Cportable_data%5Caddons%5Cplugin.program.downloader19%5Cfanart.jpg&description=&name2=&version=")')
xbmc.sleep(4000)
xbmcgui.Dialog().notification("Εγώ ότι ήταν να κάνω το ΄κανα...", "[COLOR lime]good luck...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/itsok.jpg', sound=True)


