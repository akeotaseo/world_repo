# coding: UTF-8
import sys
l11l11l1_thegroove = sys.version_info [0] == 2
l1lll1lll_thegroove = 2048
l1ll1l11_thegroove = 7
def l11ll111_thegroove (l1111l_thegroove):
    global l1lll111l_thegroove
    l1l111l1_thegroove = ord (l1111l_thegroove [-1])
    l1111l11_thegroove = l1111l_thegroove [:-1]
    l1lllll1_thegroove = l1l111l1_thegroove % len (l1111l11_thegroove)
    l1lll11_thegroove = l1111l11_thegroove [:l1lllll1_thegroove] + l1111l11_thegroove [l1lllll1_thegroove:]
    if l11l11l1_thegroove:
        l1ll1l_thegroove = unicode () .join ([unichr (ord (char) - l1lll1lll_thegroove - (l1l11_thegroove + l1l111l1_thegroove) % l1ll1l11_thegroove) for l1l11_thegroove, char in enumerate (l1lll11_thegroove)])
    else:
        l1ll1l_thegroove = str () .join ([chr (ord (char) - l1lll1lll_thegroove - (l1l11_thegroove + l1l111l1_thegroove) % l1ll1l11_thegroove) for l1l11_thegroove, char in enumerate (l1lll11_thegroove)])
    return eval (l1ll1l_thegroove)
import base64
import hashlib
import os
import requests
import sys
l1l1ll1l1_thegroove = False
import inspect
try:
    from Cryptodome import Random
    from Cryptodome.Cipher import AES
except ImportError:
    import resources.lib.pyaes.aes as pyaes
    l1l1ll1l1_thegroove = True
try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
except:
    pass
class Token:
    def __init__(self):
        self.name = l11ll111_thegroove (u"ࠢࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡴࡩࡧࡪࡶࡴࡵࡶࡦ࠵࠹࠴ࠧࡳ")
        self.token = l11ll111_thegroove (u"ࠣࠤࡴ")
        self.l1l1ll11l_thegroove = l11ll111_thegroove (u"ࠤ࠶࠷࠷࡙ࡅࡄࡔࡈࡘࡦࡨࡣ࠲࠴࠶࠸ࠧࡵ")
        self.l1ll111ll_thegroove = l11ll111_thegroove (u"ࠥࡘ࡭࡫ࡧࡳࡱࡲࡺࡪࠦ࠳࠷࠲ࠥࡶ")
        self.result = l11ll111_thegroove (u"ࠦࠧࡷ")
        self.l1l1l1111_thegroove = 0
        self.l1l1ll1l1_thegroove = l1l1ll1l1_thegroove
    def l1ll11l11_thegroove(self):
        if sys.version_info[0] < 3:
            __caller__ = sys._getframe().f_back.f_code.co_name
        else:
            __caller__ = inspect.stack()[1].function
        self.l1l11ll1l_thegroove(__caller__)
        content = requests.get(l11ll111_thegroove (u"ࠧ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡩࡧࡪࡶࡴࡵࡶࡦ࠵࠹࠴࠳ࡺ࡫࠰ࡖ࡫ࡩࡵࡧࡳࡵࡱ࠲ࡸ࡮ࡳࡥ࠯ࡲ࡫ࡴࠧࡸ"),
                               headers={l11ll111_thegroove (u"ࠨࡃࡢࡥ࡫ࡩ࠲ࡉ࡯࡯ࡶࡵࡳࡱࠨࡹ"): l11ll111_thegroove (u"ࠢ࡯ࡱ࠰ࡧࡦࡩࡨࡦࠤࡺ"), l11ll111_thegroove (u"ࠣࡒࡵࡥ࡬ࡳࡡࠣࡻ"): l11ll111_thegroove (u"ࠤࡱࡳ࠲ࡩࡡࡤࡪࡨࠦࡼ")})
        l1l1l111l_thegroove = content.json()
        l1l1ll1ll_thegroove = l1l1l111l_thegroove[l11ll111_thegroove (u"ࠥࡸ࡮ࡳࡥࡴࡶࡤࡱࡵࠨࡽ")]
        l1l11l111_thegroove = int(l1l1ll1ll_thegroove - int(l11ll111_thegroove (u"ࠦ࠹࠼࠴࠲࠲࠵࠵࠵࠶ࠢࡾ")))
        return l1l11l111_thegroove
    def l1l11ll11_thegroove(self, l1l11l111_thegroove):
        if sys.version_info[0] < 3:
            __caller__ = sys._getframe().f_back.f_code.co_name
        else:
            __caller__ = inspect.stack()[1].function
        self.l1l11ll1l_thegroove(__caller__)
        try:
            __addon__ = xbmcaddon.Addon(id=self.name)
            if sys.version_info[0] < 3:
                cwd = xbmc.translatePath(__addon__.getAddonInfo(l11ll111_thegroove (u"ࠬࡶࡡࡵࡪࠪࡿ")))
            else:
                cwd = xbmcvfs.translatePath(__addon__.getAddonInfo(l11ll111_thegroove (u"࠭ࡰࡢࡶ࡫ࠫࢀ")))
        except:
            cwd = os.getcwd() + l11ll111_thegroove (u"ࠢ࠰ࡶࡨࡷࡹࠨࢁ")
        path = l11ll111_thegroove (u"ࠣࡴࡨࡷࡴࡻࡲࡤࡧࡶ࠰ࡲࡵࡤࡶ࡮ࡨࡷ࠱࡯ࡴࡦ࡯ࡢࡴࡦࡸࡳࡦࡴ࠱ࡴࡾࠨࢂ").split(l11ll111_thegroove (u"ࠤ࠯ࠦࢃ"))
        l1l1l11ll_thegroove = cwd + os.sep + os.path.join(*path)
        l1l11lll1_thegroove = len(open(l1l1l11ll_thegroove).read().splitlines())
        l1l1lll11_thegroove = l1l11l111_thegroove % l1l11lll1_thegroove
        self.l1l1l1111_thegroove = l1l1lll11_thegroove
        line = self.l1ll111l1_thegroove(l1l1l11ll_thegroove, l1l1lll11_thegroove)
        return line
    @staticmethod
    def l1ll111l1_thegroove(l1l1l1l11_thegroove, l1l1lll11_thegroove):
        try:
            with open(l1l1l1l11_thegroove, l11ll111_thegroove (u"ࠪࡶࠬࢄ")) as f:
                for l1ll1lll1_thegroove, line in enumerate(f):
                    if l1ll1lll1_thegroove == l1l1lll11_thegroove:
                        return str(line)
        except Exception as e:
            pass
    def set_token(self):
        if not self.l1l1l1ll1_thegroove():
            return None
        try:
            l1l11l111_thegroove = self.l1ll11l11_thegroove()
            print(l11ll111_thegroove (u"ࠦࡹ࡯࡭ࡦࡶࡲ࡯ࡪࡴ࠺ࠡࠤࢅ") + str(l1l11l111_thegroove))
            line = self.l1l11ll11_thegroove(l1l11l111_thegroove)
            line = str(l1l11l111_thegroove) + l11ll111_thegroove (u"ࠧࡀ࠺ࠣࢆ") + str(line).rstrip().lstrip()
            print(l11ll111_thegroove (u"ࠨ࡬ࡪࡰࡨ࠾ࠥࠨࢇ") + line)
            l1l11l1l1_thegroove = self.l1ll1111l_thegroove(line)
            self.token = l1l11l1l1_thegroove
            return l1l11l1l1_thegroove
        except Exception as e:
            print(l11ll111_thegroove (u"ࠧࡆࡴࡵࡳࡷࠦ࡯࡯ࠢ࡯࡭ࡳ࡫ࠠࡼࡿࠪ࢈").format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
            import l1l11l1ll_thegroove
            l1l11l1ll_thegroove.l1ll1l1l1_thegroove()
            print(e)
            self.l1l111lll_thegroove(l11ll111_thegroove (u"ࠣࡈࡲࡶࡧ࡯ࡤࡥࡧࡱࠦࢉ"))
    def set_result(self, data):
        if not self.l1l1l1ll1_thegroove():
            return None
        if data.headers and data.headers[l11ll111_thegroove (u"ࠤࡗ࡬ࡪ࡭ࡲࡰࡱࡹࡩࠧࢊ")] == self.token:
            self.result = bytearray.fromhex(data.text).decode(l11ll111_thegroove (u"ࠥࡹࡹ࡬࠭࠹ࠤࢋ"))
        else:
            self.l1l111lll_thegroove(l11ll111_thegroove (u"ࠦࡋࡵࡲࡣ࡫ࡧࡨࡪࡴࠢࢌ"))
            return None
    @staticmethod
    def l1l1ll111_thegroove(s, bs):
        l1ll11l1l_thegroove = bs - len(s) % bs
        return (s.decode(l11ll111_thegroove (u"ࠧࡻࡴࡧ࠯࠻ࠦࢍ")) + l1ll11l1l_thegroove * chr(l1ll11l1l_thegroove)).encode(l11ll111_thegroove (u"࠭ࡵࡵࡨ࠰࠼ࠬࢎ"))
    def l1ll1111l_thegroove(self, text):
        if sys.version_info[0] < 3:
            __caller__ = sys._getframe().f_back.f_code.co_name
        else:
            __caller__ = inspect.stack()[1].function
        self.l1l11ll1l_thegroove(__caller__)
        l1ll1l11l_thegroove = l11ll111_thegroove (u"ࠢࡎࡆࡦࡱࡼࡐࡳࡢࠤ࢏") + l11ll111_thegroove (u"ࠣࡉࡴࡊࡓࡠࡋ࡯ࡶࠥ࢐") + l11ll111_thegroove (u"ࠤࡐࡈࡨࡳࡷࡋࡵࡤࠦ࢑") + l11ll111_thegroove (u"ࠥ࡞ࡩࡓࡕࡍ࡭ࡓࡖࠧ࢒") + l11ll111_thegroove (u"ࠦࡦࡘ࡙࡛ࡲࡋࡩࡪࠨ࢓")
        if sys.version_info[0] < 3:
            l1ll1l11l_thegroove = hashlib.sha256(l1ll1l11l_thegroove).hexdigest()[:32].encode(l11ll111_thegroove (u"ࠧࡻࡴࡧ࠯࠻ࠦ࢔"))
        else:
            l1ll1l11l_thegroove = hashlib.sha256(l1ll1l11l_thegroove.encode(l11ll111_thegroove (u"ࠨࡵࡵࡨ࠰࠼ࠧ࢕"))).hexdigest()[:32]
        l1ll1l1ll_thegroove = text.encode(l11ll111_thegroove (u"ࠧࡶࡶࡩ࠱࠽࠭࢖"))
        l1l1l1l1l_thegroove = 32
        if not self.l1l1ll1l1_thegroove:
            bs = AES.block_size
            l1ll11lll_thegroove = Random.new().read(bs)
            cipher = AES.new(l1ll1l11l_thegroove.encode(l11ll111_thegroove (u"ࠣࡷࡷࡪ࠲࠾ࠢࢗ")), AES.MODE_CFB, l1ll11lll_thegroove)
            if sys.version_info[0] < 3:
                l1ll1ll11_thegroove = cipher.encrypt(self.l1l1ll111_thegroove(l1ll1l1ll_thegroove, l1l1l1l1l_thegroove).encode(l11ll111_thegroove (u"ࠤࡸࡸ࡫࠳࠸ࠣ࢘")))
            else:
                l1ll11ll1_thegroove = self.l1l1ll111_thegroove(l1ll1l1ll_thegroove, l1l1l1l1l_thegroove)
                l1ll1ll11_thegroove = cipher.encrypt(l1ll11ll1_thegroove)
        else:
            l1ll11lll_thegroove = os.urandom(16)
            aes = pyaes.AESModeOfOperationCFB(l1ll1l11l_thegroove, l1ll11lll_thegroove)
            if sys.version_info[0] < 3:
                l1ll1ll11_thegroove = aes.encrypt(self.l1l1ll111_thegroove(l1ll1l1ll_thegroove, l1l1l1l1l_thegroove).encode(l11ll111_thegroove (u"ࠥࡹࡹ࡬࠭࠹ࠤ࢙")))
            else:
                l1ll1ll11_thegroove = aes.encrypt(self.l1l1ll111_thegroove(l1ll1l1ll_thegroove, l1l1l1l1l_thegroove))
        if sys.version_info[0] < 3:
            l1l1l1lll_thegroove = base64.b64encode(l1ll1ll11_thegroove + l11ll111_thegroove (u"ࠫ࠿ࡀ࢚ࠧ") + l1ll11lll_thegroove).encode(l11ll111_thegroove (u"ࠬࡻࡴࡧ࠯࠻࢛ࠫ"))
        else:
            l1l1l1lll_thegroove = base64.b64encode(l1ll1ll11_thegroove + l11ll111_thegroove (u"࠭࠺࠻ࠩ࢜").encode(l11ll111_thegroove (u"ࠢࡶࡶࡩ࠱࠽ࠨ࢝")) + l1ll11lll_thegroove).decode(l11ll111_thegroove (u"ࠣࡷࡷࡪ࠲࠾ࠢ࢞"))
        l1l1l1lll_thegroove = l1l1l1lll_thegroove.replace(l11ll111_thegroove (u"ࠤ࠮ࠦ࢟"), l11ll111_thegroove (u"ࠥ࠲ࠧࢠ"))
        l1l1l1lll_thegroove = l1l1l1lll_thegroove.replace(l11ll111_thegroove (u"ࠦ࠲ࠨࢡ"), l11ll111_thegroove (u"ࠧ࠲ࠢࢢ"))
        l1l1l1lll_thegroove = l1l1l1lll_thegroove.replace(l11ll111_thegroove (u"ࠨ࠯ࠣࢣ"), l11ll111_thegroove (u"ࠢࡠࠤࢤ"))
        return l1l1l1lll_thegroove
    def l1l11l11l_thegroove(self, data):
        if sys.version_info[0] < 3:
            __caller__ = sys._getframe().f_back.f_code.co_name
        else:
            __caller__ = inspect.stack()[1].function
        self.l1l11ll1l_thegroove(__caller__)
        data = data.replace(l11ll111_thegroove (u"ࠣ࠰ࠥࢥ"), l11ll111_thegroove (u"ࠤ࠮ࠦࢦ"))
        data = data.replace(l11ll111_thegroove (u"ࠥ࠰ࠧࢧ"), l11ll111_thegroove (u"ࠦ࠲ࠨࢨ"))
        data = data.replace(l11ll111_thegroove (u"ࠧࡥࠢࢩ"), l11ll111_thegroove (u"ࠨ࠯ࠣࢪ"))
        try:
            res = base64.b64decode(data).split(l11ll111_thegroove (u"ࠧ࠻࠼ࠪࢫ"))
            l1ll11lll_thegroove = res[len(res) - 1]
            l1l1l11l1_thegroove = l11ll111_thegroove (u"ࠨࠩࢬ")
            for i in range(0, (len(res) - 1)):
                l1l1l11l1_thegroove += res[i]
            l1ll1l11l_thegroove = l11ll111_thegroove (u"ࠤࡐࡈࡨࡳࡷࡋࡵࡤࠦࢭ") + l11ll111_thegroove (u"ࠥࡋࡶࡌࡎ࡛ࡍࡱࡸࠧࢮ") + l11ll111_thegroove (u"ࠦࡒࡊࡣ࡮ࡹࡍࡷࡦࠨࢯ") + l11ll111_thegroove (u"ࠧࡠࡤࡎࡗࡏ࡯ࡕࡘࠢࢰ") + l11ll111_thegroove (u"ࠨࡡࡓ࡛࡝ࡴࡍ࡫ࡥࠣࢱ")
            l1ll1l11l_thegroove = hashlib.sha256(l1ll1l11l_thegroove).hexdigest()[:32].encode(l11ll111_thegroove (u"ࠢࡶࡶࡩ࠱࠽ࠨࢲ"))
            if not self.l1l1ll1l1_thegroove:
                cipher = AES.new(l1ll1l11l_thegroove, AES.MODE_CFB, l1ll11lll_thegroove)
                l1ll1l111_thegroove = cipher.decrypt(l1l1l11l1_thegroove)
            else:
                aes = pyaes.AESModeOfOperationCFB(l1ll1l11l_thegroove, l1ll11lll_thegroove)
                l1ll1l111_thegroove = aes.decrypt(l1l1l11l1_thegroove)
            sep = base64.b64encode(l11ll111_thegroove (u"ࠣࠬ࠭ࠦࢳ")).encode(l11ll111_thegroove (u"ࠤࡸࡸ࡫࠳࠸ࠣࢴ"))
            result, l1l1l1111_thegroove, l1ll11111_thegroove = l1ll1l111_thegroove.split(str(sep))
            if l1l1l1111_thegroove == str(self.l1l1l1111_thegroove):
                return result
            else:
                self.l1l111lll_thegroove(l11ll111_thegroove (u"ࠥࡉࡷࡸ࡯ࡳࡧࠣ࠸࠵࠻ࠢࢵ"), l11ll111_thegroove (u"ࠦࡎࡳࡰࡰࡵࡶ࡭ࡧ࡯࡬ࡦࠢࡆࡳࡲࡶ࡬ࡦࡶࡤࡶࡪࠦࡌࡢࠢࡕ࡭ࡨ࡮ࡩࡦࡵࡷࡥࠧࢶ"))
        except Exception as e:
            self.l1l111lll_thegroove(l11ll111_thegroove (u"ࠧࡋࡲࡳࡱࡵࡩࠥ࠺࠰࠸ࠤࢷ"), l11ll111_thegroove (u"ࠨࡉ࡮ࡲࡲࡷࡸ࡯ࡢࡪ࡮ࡨࠤࡈࡵ࡭ࡱ࡮ࡨࡸࡦࡸࡥࠡࡎࡤࠤࡗ࡯ࡣࡩ࡫ࡨࡷࡹࡧࠢࢸ"))
            import l1l11l1ll_thegroove
            l1l11l1ll_thegroove.l1ll1l1l1_thegroove()
            print(e)
        return None
    def l1l1l1ll1_thegroove(self, skip=False):
        if skip is False:
            if sys.version_info[0] < 3:
                __caller__ = sys._getframe().f_back.f_code.co_name
            else:
                __caller__ = inspect.stack()[1].function
            self.l1l11ll1l_thegroove(__caller__)
        try:
            l1l1lllll_thegroove = xbmc.getInfoLabel(l11ll111_thegroove (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡔࡱࡻࡧࡪࡰࡑࡥࡲ࡫ࠧࢹ"))
            l1l1lllll_thegroove = xbmcaddon.Addon(l1l1lllll_thegroove).getAddonInfo(l11ll111_thegroove (u"ࠨࡰࡤࡱࡪ࠭ࢺ"))
            if l1l1lllll_thegroove != self.l1ll111ll_thegroove:
                raise Exception()
        except Exception as e:
            self.l1l111lll_thegroove(l11ll111_thegroove (u"ࠤࡈࡶࡷࡵࡲࡦࠢ࠴ࠦࢻ"), l11ll111_thegroove (u"ࠥࡊࡺࡴࡺࡪࡱࡱࡩࠥࡊࡩࡴࡲࡲࡲ࡮ࡨࡩ࡭ࡧࠣࡗࡴࡲ࡯ࠡࡕࡸࠦࢼ"), self.l1ll111ll_thegroove + l11ll111_thegroove (u"ࠦࠥࡇࡤࡥࡱࡱࠦࢽ"))
            return False
        try:
            l1l11llll_thegroove = xbmcaddon.Addon(id=self.name)
            xbmc.translatePath(l1l11llll_thegroove.getAddonInfo(l11ll111_thegroove (u"ࠬࡶࡡࡵࡪࠪࢾ")))
        except:
            self.l1l111lll_thegroove(l11ll111_thegroove (u"ࠨࡅࡳࡴࡲࡶࡪࠦ࠲ࠣࢿ"), l11ll111_thegroove (u"ࠢࡇࡷࡱࡾ࡮ࡵ࡮ࡦࠢࡇ࡭ࡸࡶ࡯࡯࡫ࡥ࡭ࡱ࡫ࠠࡔࡱ࡯ࡳ࡙ࠥࡵࠣࣀ"), self.l1ll111ll_thegroove + l11ll111_thegroove (u"ࠣࠢࡄࡨࡩࡵ࡮ࠣࣁ"))
            return False
        try:
            l1l11llll_thegroove = xbmcaddon.Addon(id=self.name)
            cwd = xbmc.translatePath(l1l11llll_thegroove.getAddonInfo(l11ll111_thegroove (u"ࠩࡳࡥࡹ࡮ࠧࣂ")))
            l1l1llll1_thegroove = l11ll111_thegroove (u"ࠥࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠲࡭ࡰࡦࡸࡰࡪࡹࠬࡪࡶࡨࡱࡤࡶࡡࡳࡵࡨࡶ࠳ࡶࡹࠣࣃ").split(l11ll111_thegroove (u"ࠦ࠱ࠨࣄ"))
            l1l1l11ll_thegroove = cwd + os.sep + os.path.join(*l1l1llll1_thegroove)
            if not os.path.isfile(l1l1l11ll_thegroove):
                raise Exception()
        except:
            self.l1l111lll_thegroove(l11ll111_thegroove (u"ࠧࡋࡲࡳࡱࡵࡩࠥ࠹ࠢࣅ"), l11ll111_thegroove (u"ࠨࡆࡶࡰࡽ࡭ࡴࡴࡥࠡࡆ࡬ࡷࡵࡵ࡮ࡪࡤ࡬ࡰࡪࠦࡓࡰ࡮ࡲࠤࡘࡻࠢࣆ"), self.l1ll111ll_thegroove + l11ll111_thegroove (u"ࠢࠡࡃࡧࡨࡴࡴࠢࣇ"))
            return False
        return True
    def l1l11ll1l_thegroove(self, l1ll1ll1l_thegroove):
        if l1ll1ll1l_thegroove != l11ll111_thegroove (u"ࠣࡵࡨࡸࡤࡺ࡯࡬ࡧࡱࠦࣈ") and l1ll1ll1l_thegroove != l11ll111_thegroove (u"ࠤࡶࡩࡹࡥࡲࡦࡵࡸࡰࡹࠨࣉ"):
            raise Exception()
    def l1l111lll_thegroove(self, s1=l11ll111_thegroove (u"ࠥࠦ࣊"), s2=l11ll111_thegroove (u"ࠦࠧ࣋"), l1l1lll1l_thegroove=l11ll111_thegroove (u"ࠧࠨ࣌")):
        try:
            xbmcgui.Dialog().ok(self.l1ll111ll_thegroove, s1, s2, l1l1lll1l_thegroove)
        except:
            print(s1 + l11ll111_thegroove (u"ࠨࠠࠣ࣍") + s2 + l11ll111_thegroove (u"ࠢࠡࠤ࣎") + l1l1lll1l_thegroove)