﻿################################################################################
#      Copyright (C) 2015 Surfacingx                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import os, sys, glob
import re
import uservar
import xbmc, xbmcgui, xbmcvfs
from datetime import date, datetime, timedelta
from urllib.parse import quote_plus


from resources.libs import extract, downloader, notify, loginit, debridit, traktit, skinSwitch, uploadLog, dnsleaktest, wizard as wiz

xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.ResetSettingValue", "params":{"setting":"debug.showloginfo"},"id":1}')
KODIV            = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
transPath  = xbmcvfs.translatePath
lognot = xbmc.LOGINFO
ADDON_ID       = uservar.ADDON_ID
ADDONTITLE     = uservar.ADDONTITLE
ADDON          = wiz.addonId(ADDON_ID)
VERSION        = wiz.addonInfo(ADDON_ID,'version')
ADDONPATH      = wiz.addonInfo(ADDON_ID,'path')
ADDONID        = wiz.addonInfo(ADDON_ID,'id')
DIALOG         = xbmcgui.Dialog()
DP             = xbmcgui.DialogProgress()
HOME           = transPath('special://home/')
PROFILE        = transPath('special://profile/')
KODIHOME       = transPath('special://xbmc/')
ADDONS         = os.path.join(HOME,     'addons')
KODIADDONS     = os.path.join(KODIHOME, 'addons')
USERDATA       = os.path.join(HOME,     'userdata')
PLUGIN         = os.path.join(ADDONS,   ADDON_ID)
PACKAGES       = os.path.join(ADDONS,   'packages')
ADDONDATA      = os.path.join(USERDATA, 'addon_data', ADDON_ID)
TEXTCACHE      = os.path.join(ADDONDATA, 'Cache')
FANART         = os.path.join(ADDONPATH,'fanart.jpg')
ICON           = os.path.join(ADDONPATH,'icon.png')
ART            = os.path.join(ADDONPATH,'resources', 'art')
ADVANCED       = os.path.join(USERDATA, 'advancedsettings.xml')
SKIN           = xbmc.getSkinDir()
BUILDNAME      = wiz.getS('buildname')
DEFAULTSKIN    = wiz.getS('defaultskin')
DEFAULTNAME    = wiz.getS('defaultskinname')
DEFAULTIGNORE  = wiz.getS('defaultskinignore')
BUILDVERSION   = wiz.getS('buildversion')
BUILDLATEST    = wiz.getS('latestversion')
BUILDCHECK     = wiz.getS('lastbuildcheck')
DISABLEUPDATE  = wiz.getS('disableupdate')
AUTOCLEANUP    = wiz.getS('autoclean')
AUTOCACHE      = wiz.getS('clearcache')
AUTOPACKAGES   = wiz.getS('clearpackages')
AUTOTHUMBS     = wiz.getS('clearthumbs')
AUTOFEQ        = wiz.getS('autocleanfeq')
AUTONEXTRUN    = wiz.getS('nextautocleanup')
TRAKTSAVE      = wiz.getS('traktlastsave')
REALSAVE       = wiz.getS('debridlastsave')
#ALLUCSAVE      = wiz.getS('alluclastsave')
LOGINSAVE      = wiz.getS('loginlastsave')
KEEPTRAKT      = wiz.getS('keeptrakt')
KEEPREAL       = wiz.getS('keepdebrid')
#KEEPALLUC      = wiz.getS('keepalluc')
KEEPLOGIN      = wiz.getS('keeplogin')
INSTALLED      = wiz.getS('installed')
EXTRACT        = wiz.getS('extract')
EXTERROR       = wiz.getS('errors')
NOTIFY         = wiz.getS('notify')
NOTEDISMISS    = wiz.getS('notedismiss')
NOTEID         = wiz.getS('noteid')
DNSWARN        = wiz.getS('dnswarning')
BACKUPLOCATION = ADDON.getSetting('path') if not ADDON.getSetting('path') == '' else HOME
MYBUILDS       = os.path.join(BACKUPLOCATION, 'My_Builds', '')
NOTEID         = 0 if NOTEID == "" else int(NOTEID)
AUTOFEQ        = int(AUTOFEQ) if AUTOFEQ.isdigit() else 0
TODAY          = date.today()
TOMORROW       = TODAY + timedelta(days=1)
TWODAYS        = TODAY + timedelta(days=2)
THREEDAYS      = TODAY + timedelta(days=3)
ONEWEEK        = TODAY + timedelta(days=7)
SKINCHECK      = ['skin.aftermath.zephyr', 'skin.aftermath.silvo', 'skin.aftermath.simple', 'skin.ccm.aftermath']
RAM            = int(xbmc.getInfoLabel("System.Memory(total)")[:-2])
EXCLUDES       = uservar.EXCLUDES
BUILDFILE      = wiz.BUILDFILE
UPDATECHECK    = uservar.UPDATECHECK if str(uservar.UPDATECHECK).isdigit() else 1
NEXTCHECK      = TODAY + timedelta(days=UPDATECHECK)
NOTIFICATION   = uservar.NOTIFICATION
AUTOUPDATE     = uservar.AUTOUPDATE
WIZARDFILE     = uservar.WIZARDFILE
AUTOINSTALL    = uservar.AUTOINSTALL
REPOID         = uservar.REPOID
REPOADDONXML   = uservar.REPOADDONXML
REPOZIPURL     = uservar.REPOZIPURL
COLOR1         = uservar.COLOR1
COLOR2         = uservar.COLOR2
WORKING        = True if wiz.workingURL(BUILDFILE) == True else False
FAILED         = False
try:
    ENABLE         = uservar.ENABLE()
except:
    ENABLE         = uservar.ENABLE
PLATFORM       = wiz.platform()
if PLATFORM == 'windows':
    winuser = ADDONPATH.split('\\')[2]
    try:
        winuser.encode('ascii')
    except UnicodeEncodeError:
        DIALOG.ok(ADDONTITLE + '[COLOR gold] - ΠΡΟΒΛΗΜΑ!!![/COLOR]', '[COLOR red]Δυστυχώς το όνομα χρήστη των Windows --[B][COLOR yellow]%s[/COLOR][/B]-- που χρησιμοποιείται περιέχει μη αποδεκτούς χαρακτήρες για την σωστή λειτουργία των προσθέτων του Kodi.\nΘα πρέπει ή να φτιάξετε [B][COLOR aqua]νέο χρήστη Windows[/COLOR][/B] χωρίς ελληνικούς χαρακτήρες ή κενά και να κάνετε εγκατάσταση του Kodi σε αυτόν ή να φτιάξετε [B][COLOR aqua]Portable εγκατάσταση[/COLOR][/B] του Kodi.[/COLOR]' % winuser)
        pass
##############################################
####SHOW BUILDS DEPENDING THE KODI VERSION####
##############################################
if 16 <= KODIV < 17:
    wiz.setS('show15', 'false')
    wiz.setS('show16', 'true')
    wiz.setS('show17', 'false')
    wiz.setS('show18', 'false')
    wiz.setS('show19', 'false')
    wiz.setS('show20', 'false')
    wiz.setS('show21', 'false')

elif 17 <= KODIV < 18:
    wiz.setS('show15', 'false')
    wiz.setS('show16', 'false')
    wiz.setS('show17', 'true')
    wiz.setS('show18', 'false')
    wiz.setS('show19', 'false')
    wiz.setS('show20', 'false')
    wiz.setS('show21', 'false')

elif 18 <= KODIV < 19:
    wiz.setS('show15', 'false')
    wiz.setS('show16', 'false')
    wiz.setS('show17', 'false')
    wiz.setS('show18', 'true')
    wiz.setS('show19', 'false')
    wiz.setS('show20', 'false')
    wiz.setS('show21', 'false')

elif 19 <= KODIV < 20:
    wiz.setS('show15', 'false')
    wiz.setS('show16', 'false')
    wiz.setS('show17', 'false')
    wiz.setS('show18', 'false')
    wiz.setS('show19', 'true')
    wiz.setS('show20', 'false')
    wiz.setS('show21', 'false')

elif 20 <= KODIV < 21:
    wiz.setS('show15', 'false')
    wiz.setS('show16', 'false')
    wiz.setS('show17', 'false')
    wiz.setS('show18', 'false')
    wiz.setS('show19', 'false')
    wiz.setS('show20', 'true')
    wiz.setS('show21', 'false')

elif 21 <= KODIV < 22:
    wiz.setS('show15', 'false')
    wiz.setS('show16', 'false')
    wiz.setS('show17', 'false')
    wiz.setS('show18', 'false')
    wiz.setS('show19', 'false')
    wiz.setS('show20', 'false')
    wiz.setS('show21', 'true')

else:
    wiz.setS('show15', 'true')
    wiz.setS('show16', 'false')
    wiz.setS('show17', 'false')
    wiz.setS('show18', 'false')
    wiz.setS('show19', 'false')
    wiz.setS('show20', 'false')
    wiz.setS('show21', 'false')


###########################
#### Check Updates   ######
###########################
def checkUpdate():
    BUILDNAME      = wiz.getS('buildname')
    BUILDVERSION   = wiz.getS('buildversion')
    bf             = wiz.textCache(BUILDFILE)
    if bf == False: return
    link           = bf.decode('utf-8').replace('\n','').replace('\r','').replace('\t','')
    match          = re.compile('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"' % BUILDNAME).findall(link)
    if len(match) > 0:
        version = match[0][0]
        icon    = match[0][1]
        fanart  = match[0][2]
        wiz.setS('latestversion', version)
        if version > BUILDVERSION:
            if DISABLEUPDATE == 'false':
                wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window" % (BUILDVERSION, version), lognot)
                while (xbmc.getCondVisibility("Window.isVisible(yesnodialog)") or xbmc.getCondVisibility("Window.isVisible(okdialog)")):
                    xbmc.sleep(100)
                notify.updateWindow(BUILDNAME, BUILDVERSION, version, icon, fanart)
            else: wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled" % (BUILDVERSION, version), lognot)
        else: wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s]" % (BUILDVERSION, version), lognot)
    else: wiz.log("[Check Updates] ERROR: Unable to find build version in build text file", xbmc.LOGERROR)

def checkInstalled():
    # current = ''
    # for skin in SKINCHECK:
        # skinpath = os.path.join(ADDONS,skin)
        # if os.path.exists(skinpath): 
            # current = skin
    # if current == SKINCHECK[0]:
        # yes_pressed = DIALOG.yesno(ADDONTITLE,"[COLOR dodgerblue]Aftermath[/COLOR] Zephyr is currently outdated and is no longer being updated.[CR]Please download one of the newer community builds.", yeslabel="Build Menu", nolabel="Ignore")
        # if yes_pressed: xbmc.executebuiltin('ActivateWindow(10025 , "plugin://%s/?mode=builds", return)' % ADDON_ID)
        # else: DIALOG.ok(ADDONTITLE, 'You can still install a community build from the [COLOR dodgerblue]Aftermath[/COLOR] Wizard.')
    # elif current == SKINCHECK[1]:
        # yes_pressed = DIALOG.yesno(ADDONTITLE,"[COLOR dodgerblue]Aftermath[/COLOR] Silvo is currently outdated and is no longer being updated.[CR]Please download one of the newer community builds.", yeslabel="Build Menu", nolabel="Ignore")
        # if yes_pressed: xbmc.executebuiltin('ActivateWindow(10025 , "plugin://%s/?mode=builds", return)' % ADDON_ID)
        # else: DIALOG.ok(ADDONTITLE, 'You can still install a community build from the [COLOR dodgerblue]Aftermath[/COLOR] Wizard.')
    # elif current == SKINCHECK[2]:
        # if KODIV >= 16: 
            # gui   = os.path.join(ADDOND, SKINCHECK[2], 'settings.xml')
            # f     = xbmcvfs.File(gui); g = f.read(); f.close()
            # match = re.compile('<setting id=\"SubSettings.3.Label\" type=\"string\">(.+?)<\/setting>').findall(g)
            # if len(match): 
                # name, build, ver = match[0].replace('[COLOR dodgerblue]','').replace('[/COLOR]','').split(' ')
            # else: 
                # build = "Simple"
                # ver = "v0.1"
        # else: 
            # gui   = os.path.join(USERDATA,'guisettings.xml')
            # f     = xbmcvfs.File(gui); g = f.read(); f.close()
            # match = re.compile('<setting type=\"string\" name=\"skin.aftermath.simple.SubSettings.3.Label\">(.+?)<\/setting>').findall(g)
            # name, build, ver = match[0].replace('[COLOR dodgerblue]','').replace('[/COLOR]','').split(' ')
        # wiz.setS('buildname', 'Aftermath %s' % build)
        # wiz.setS('buildversion', ver[1:])
        # wiz.setS('lastbuildcheck', str(NEXTCHECK))
        # checkUpdate()
    # elif current == SKINCHECK[3]:
        # yes_pressed = DIALOG.yesno(ADDONTITLE,"[COLOR dodgerblue]Aftermath[/COLOR] CCM is currently outdated and is no longer being updated.[CR]Please download one of the newer community builds.", yeslabel="Build Menu", nolabel="Ignore")
        # if yes_pressed: xbmc.executebuiltin('ActivateWindow(10025 , "plugin://%s/?mode=builds", return)' % ADDON_ID)
        # else: DIALOG.ok(ADDONTITLE, 'You can still install a community build from the [COLOR dodgerblue]Aftermath[/COLOR] Wizard.')
    # else:
        while (xbmc.getCondVisibility("Window.isVisible(yesnodialog)") or xbmc.getCondVisibility("Window.isVisible(okdialog)")):
            xbmc.sleep(100)
        notify.firstRunSettings()
        while (xbmc.getCondVisibility("Window.isVisible(yesnodialog)") or xbmc.getCondVisibility("Window.isVisible(okdialog)")):
            xbmc.sleep(100)
        notify.firstRun()

def writeAdvanced():
    if RAM > 1536: buffer = '209715200'
    else: buffer = '104857600'
    with xbmcvfs.File(ADVANCED, 'w') as f:
        f.write('<advancedsettings>\n')
        f.write('   <network>\n')
        f.write('       <buffermode>2</buffermode>\n')
        f.write('       <cachemembuffersize>%s</cachemembuffersize>\n' % buffer)
        f.write('       <readbufferfactor>5</readbufferfactor>\n')
        f.write('       <curlclienttimeout>10</curlclienttimeout>\n')
        f.write('       <curllowspeedtime>10</curllowspeedtime>\n')
        f.write('   </network>\n')
        f.write('</advancedsettings>\n')
    # f.close()

def checkSkin():
    wiz.log("[Build Check] Invalid Skin Check Start")
    DEFAULTSKIN   = wiz.getS('defaultskin')
    DEFAULTNAME   = wiz.getS('defaultskinname')
    DEFAULTIGNORE = wiz.getS('defaultskinignore')
    gotoskin = False
    if not DEFAULTSKIN == '':
        if os.path.exists(os.path.join(ADDONS, DEFAULTSKIN)):
            if DIALOG.yesno(ADDONTITLE, "[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR][CR]Would you like to set the skin back to:[/COLOR][CR][COLOR %s]%s[/COLOR]" % (COLOR2, COLOR1, SKIN[5:].title(), COLOR1, DEFAULTNAME)):
                gotoskin = DEFAULTSKIN
                gotoname = DEFAULTNAME
            else: wiz.log("Skin was not reset", lognot); wiz.setS('defaultskinignore', 'true'); gotoskin = False
        else: wiz.setS('defaultskin', ''); wiz.setS('defaultskinname', ''); DEFAULTSKIN = ''; DEFAULTNAME = ''
    if DEFAULTSKIN == '':
        skinname = []
        skinlist = []
        for folder in glob.glob(os.path.join(ADDONS, 'skin.*/')):
            xml = "%s/addon.xml" % folder
            if os.path.exists(xml):
                f  = xbmcvfs.File(xml); g = f.read().replace('\n','').replace('\r','').replace('\t',''); f.close();
                match  = wiz.parseDOM(g, 'addon', ret='id')
                match2 = wiz.parseDOM(g, 'addon', ret='name')
                wiz.log("%s: %s" % (folder, str(match[0])), lognot)
                if len(match) > 0: skinlist.append(str(match[0])); skinname.append(str(match2[0]))
                else: wiz.log("ID not found for %s" % folder, lognot)
            else: wiz.log("ID not found for %s" % folder, lognot)
        if len(skinlist) > 0:
            if len(skinlist) > 1:
                if DIALOG.yesno(ADDONTITLE, "[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR][CR]Would you like to view a list of avaliable skins?[/COLOR]" % (COLOR2, COLOR1, SKIN[5:].title())):
                    choice = DIALOG.select("Select skin to switch to!", skinname)
                    if choice == -1: wiz.log("Skin was not reset", lognot); wiz.setS('defaultskinignore', 'true')
                    else: 
                        gotoskin = skinlist[choice]
                        gotoname = skinname[choice]
                else: wiz.log("Skin was not reset", lognot); wiz.setS('defaultskinignore', 'true')
            else:
                if DIALOG.yesno(ADDONTITLE, "[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR][CR]Would you like to set the skin back to:[/COLOR][CR][COLOR %s]%s[/COLOR]" % (COLOR2, COLOR1, SKIN[5:].title(), COLOR1, skinname[0])):
                    gotoskin = skinlist[0]
                    gotoname = skinname[0]
                else: wiz.log("Skin was not reset", lognot); wiz.setS('defaultskinignore', 'true')
        else: wiz.log("No skins found in addons folder.", lognot); wiz.setS('defaultskinignore', 'true'); gotoskin = False
    if gotoskin:
        if wiz.swapSkins(gotoskin):
            wiz.lookandFeelData('restore')
    wiz.log("[Build Check] Invalid Skin Check End", lognot)

while xbmc.Player().isPlayingVideo():
    xbmc.sleep(1000)

if KODIV >= 17:
    NOW = datetime.now()
    temp = wiz.getS('kodi17iscrap')
    if not temp == '':
        if temp > str(NOW - timedelta(minutes=2)):
            wiz.log("Killing Start Up Script")
            sys.exit()
    wiz.log("%s" % (NOW))
    wiz.setS('kodi17iscrap', str(NOW))
    xbmc.sleep(1000)
    if not wiz.getS('kodi17iscrap') == str(NOW):
        wiz.log("Killing Start Up Script")
        sys.exit()
    else:
        wiz.log("Continuing Start Up Script")

wiz.log("[Path Check] Started", lognot)
path = os.path.split(os.path.dirname(ADDONPATH))
if not ADDONID == path[1]: DIALOG.ok(ADDONTITLE, '[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR][CR][COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR][CR][COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR2, COLOR1, ADDONID, COLOR2, COLOR1, path)); wiz.log("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s " % (ADDONID, path))
else: wiz.log("[Path Check] Good!", lognot)

if KODIADDONS in ADDONPATH:
    wiz.log("Copying path to addons dir", lognot)
    if not os.path.exists(ADDONS): os.makedirs(ADDONS)
    newpath = transPath(os.path.join('special://home/addons/', ADDONID))
    if os.path.exists(newpath):
        wiz.log("Folder already exists, cleaning House", lognot)
        wiz.cleanHouse(newpath)
        wiz.removeFolder(newpath)
    try:
        wiz.copytree(ADDONPATH, newpath)
    except Exception as e:
        pass
    wiz.forceUpdate(True)

#if not os.path.exists(ADVANCED): writeAdvanced()

try:
    mybuilds = transPath(MYBUILDS)
    if not os.path.exists(mybuilds): xbmcvfs.mkdirs(mybuilds)
except:
    pass

wiz.log("Flushing Aged Cached Text Files")
wiz.flushOldCache()

wiz.log("[Auto Install Repo] Started", lognot)
if AUTOINSTALL == 'Yes' and not os.path.exists(os.path.join(ADDONS, REPOID)):
    workingxml = wiz.workingURL(REPOADDONXML)
    if workingxml == True:
        ver = wiz.parseDOM(wiz.openURL(REPOADDONXML), 'addon', ret='version', attrs = {'id': REPOID})
        if len(ver) > 0:
            installzip = '%s-%s.zip' % (REPOID, ver[0])
            workingrepo = wiz.workingURL(REPOZIPURL+installzip)
            if workingrepo == True:
                DP.create(ADDONTITLE,'Γίνετε λήψη Repo...[CR][CR]Παρακαλώ περιμένετε!')
                if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
                lib=os.path.join(PACKAGES, installzip)
                try: xbmcvfs.delete(lib)
                except: pass
                downloader.download(REPOZIPURL+installzip,lib, DP, 'repository')
                extract.all(lib, ADDONS, DP)
                try:
                    f = xbmcvfs.File(os.path.join(ADDONS, REPOID, 'addon.xml')); g = f.read(); f.close()
                    name = wiz.parseDOM(g, 'addon', ret='name', attrs = {'id': REPOID})
                    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name[0]), "[COLOR %s]Add-on updated[/COLOR]" % COLOR2, icon=os.path.join(ADDONS, REPOID, 'icon.png'))
                except:
                    pass
                if KODIV >= 17: wiz.addonDatabase(REPOID, 1)
                DP.close()
                xbmc.sleep(500)
                wiz.forceUpdate(True)
                wiz.log("[Auto Install Repo] Successfully Installed", lognot)
            else: 
                wiz.LogNotify("[COLOR %s]Repo Install Error[/COLOR]" % COLOR1, "[COLOR %s]Invalid url for zip![/COLOR]" % COLOR2)
                wiz.log("[Auto Install Repo] Was unable to create a working url for repository. %s" % workingrepo, xbmc.LOGERROR)
        else:
            wiz.log("Invalid URL for Repo Zip", xbmc.LOGERROR)
    else: 
        wiz.LogNotify("[COLOR %s]Repo Install Error[/COLOR]" % COLOR1, "[COLOR %s]Invalid addon.xml file![/COLOR]" % COLOR2)
        wiz.log("[Auto Install Repo] Unable to read the addon.xml file.", xbmc.LOGERROR)
elif not AUTOINSTALL == 'Yes': wiz.log("[Auto Install Repo] Not Enabled", lognot)
elif os.path.exists(os.path.join(ADDONS, REPOID)): wiz.log("[Auto Install Repo] Repository already installed")

# REINSTALL ELIGIBLE BINARIES
binarytxt = os.path.join(USERDATA, 'build_binaries.txt')
if os.path.exists(binarytxt):
    wiz.log("[Binary Detection] Reinstalling Eligible Binary Addons", level=xbmc.LOGINFO)
    wiz.restorebinaries()
else:
    wiz.log("[Binary Detection] Eligible Binary Addons to Reinstall", level=xbmc.LOGINFO)


wiz.log("[Auto Update Wizard] Started", lognot)
if AUTOUPDATE == 'Yes':
    wiz.wizardUpdate('startup')
else: wiz.log("[Auto Update Wizard] Not Enabled", lognot)

wiz.log("[Notifications] Started", lognot)
if ENABLE == 'Yes':
    if not NOTIFY == 'true':
        url = wiz.workingURL(NOTIFICATION)
        if url == True:
            id, msg = wiz.splitNotify(NOTIFICATION)
            if not id == False:
                try:
                    id = int(id); NOTEID = int(NOTEID)
                    if id == NOTEID:
                        if NOTEDISMISS == 'false':
                            while (xbmc.getCondVisibility("Window.isVisible(yesnodialog)") or xbmc.getCondVisibility("Window.isVisible(okdialog)")):
                                xbmc.sleep(100)
                            notify.notification(msg)
                        else: wiz.log("[Notifications] id[%s] Dismissed" % int(id), lognot)
                    elif id > NOTEID:
                        wiz.log("[Notifications] id: %s" % str(id), lognot)
                        wiz.setS('noteid', str(id))
                        wiz.setS('notedismiss', 'false')
                        while (xbmc.getCondVisibility("Window.isVisible(yesnodialog)") or xbmc.getCondVisibility("Window.isVisible(okdialog)")):
                            xbmc.sleep(100)
                        notify.notification(msg=msg)
                        wiz.log("[Notifications] Complete", lognot)
                except Exception as e:
                    wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)
            else: wiz.log("[Notifications] Text File not formated Correctly")
        else: wiz.log("[Notifications] URL(%s): %s" % (NOTIFICATION, url), lognot)
    else: wiz.log("[Notifications] Turned Off", lognot)
else: wiz.log("[Notifications] Not Enabled", lognot)

wiz.log("[Installed Check] Started", lognot)
if INSTALLED == 'true':
    if KODIV >= 19:
        wiz.kodi19Fix()
        if SKIN in ['skin.confluence', 'skin.estuary']:
            checkSkin()
        FAILED = True
    elif not EXTRACT == '100' and not BUILDNAME == "":
        wiz.log("[Installed Check] Build was extracted %s/100 with [ERRORS: %s]" % (EXTRACT, EXTERROR), lognot)
        yes=DIALOG.yesno(ADDONTITLE, '[COLOR %s]%s[/COLOR] [COLOR %s]was not installed correctly![CR]Installed: [COLOR %s]%s[/COLOR] / Error Count: [COLOR %s]%s[/COLOR][CR]Would you like to try again?[/COLOR]' % (COLOR1, COLOR2, BUILDNAME, COLOR1, EXTRACT, COLOR1, EXTERROR), nolabel='[B]No Thanks![/B]', yeslabel='[B]Retry Install[/B]')
        wiz.clearS('build')
        FAILED = True
        if yes: 
            wiz.ebi("PlayMedia(plugin://%s/?mode=install&name=%s&url=fresh)" % (ADDON_ID, quote_plus(BUILDNAME)))
            wiz.log("[Installed Check] Fresh Install Re-activated", lognot)
        else: wiz.log("[Installed Check] Reinstall Ignored")
    elif SKIN in ['skin.confluence', 'skin.estuary']:
        wiz.log("[Installed Check] Incorrect skin: %s" % SKIN, lognot)
        defaults = wiz.getS('defaultskin')
        if not defaults == '':
            if os.path.exists(os.path.join(ADDONS, defaults)):
                if wiz.swapSkins(defaults):
                    wiz.lookandFeelData('restore')
        if not wiz.currSkin() == defaults and not BUILDNAME == "":
            gui = wiz.checkBuild(BUILDNAME, 'gui')
            FAILED = True
            if gui == 'http://':
                wiz.log("[Installed Check] Guifix was set to http://", lognot)
                DIALOG.ok(ADDONTITLE, "[COLOR %s]It looks like the skin settings was not applied to the build." % COLOR2, "Sadly no gui fix was attatched to the build", "You will need to reinstall the build and make sure to do a force close[/COLOR]")
            elif wiz.workingURL(gui):
                yes=DIALOG.yesno(ADDONTITLE, '%s was not installed correctly![CR]It looks like the skin settings was not applied to the build.[CR]Would you like to apply the GuiFix?' % BUILDNAME, nolabel='[B]No, Cancel[/B]', yeslabel='[B]Apply Fix[/B]')
                if yes: wiz.ebi("PlayMedia(plugin://%s/?mode=install&name=%s&url=gui)" % (ADDON_ID, quote_plus(BUILDNAME))); wiz.log("[Installed Check] Guifix attempting to install")
                else: wiz.log('[Installed Check] Guifix url working but cancelled: %s' % gui, lognot)
            else:
                DIALOG.ok(ADDONTITLE, "[COLOR %s]It looks like the skin settings was not applied to the build." % COLOR2, "Sadly no gui fix was attatched to the build", "You will need to reinstall the build and make sure to do a force close[/COLOR]")
                wiz.log('[Installed Check] Guifix url not working: %s' % gui, lognot)
    else:
        wiz.log('[Installed Check] Install seems to be completed correctly', lognot)
    # if not wiz.getS('pvrclient') == "":
        # wiz.toggleAddon(wiz.getS('pvrclient'), 1)
        # wiz.ebi('StartPVRManager')
    # wiz.addonUpdates('reset')
    if KEEPTRAKT == 'true': traktit.traktIt('restore', 'all'); wiz.log('[Installed Check] Restoring Trakt Data', lognot)
    if KEEPREAL  == 'true': debridit.debridIt('restore', 'all'); wiz.log('[Installed Check] Restoring Debrid Data', lognot)
    if KEEPLOGIN == 'true': loginit.loginIt('restore', 'all'); wiz.log('[Installed Check] Restoring Login Data', lognot)
    wiz.clearS('install')
else: wiz.log("[Installed Check] Not Enabled", lognot)

if FAILED == False:
    wiz.log("[Build Check] Started", lognot)
    if not WORKING:
        wiz.log("[Build Check] Not a valid URL for Build File: %s" % BUILDFILE, lognot)
    elif BUILDCHECK == '' and BUILDNAME == '':
        wiz.log("[Build Check] First Run", lognot)
        checkInstalled()
        wiz.setS('lastbuildcheck', str(NEXTCHECK))
    elif not BUILDNAME == '':
        wiz.log("[Build Check] Build Installed", lognot)
        if SKIN in ['skin.confluence', 'skin.estuary'] and not DEFAULTIGNORE == 'true':
            checkSkin()
            wiz.log("[Build Check] Build Installed: Checking Updates", lognot)
            wiz.setS('lastbuildcheck', str(NEXTCHECK))
            checkUpdate()
        elif BUILDCHECK <= str(TODAY):
            wiz.log("[Build Check] Build Installed: Checking Updates", lognot)
            wiz.setS('lastbuildcheck', str(NEXTCHECK))
            checkUpdate()
        else: 
            wiz.log("[Build Check] Build Installed: Next check isnt until: %s / TODAY is: %s" % (BUILDCHECK, str(TODAY)), lognot)

wiz.log("[Trakt Data] Started", lognot)
if KEEPTRAKT == 'true':
    if TRAKTSAVE <= str(TODAY):
        wiz.log("[Trakt Data] Saving all Data", lognot)
        traktit.autoUpdate('all')
        wiz.setS('traktlastsave', str(THREEDAYS))
    else: 
        wiz.log("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s" % (TRAKTSAVE, str(TODAY)), lognot)
else: wiz.log("[Trakt Data] Not Enabled", lognot)

wiz.log("[Debrid Data] Started", lognot)
if KEEPREAL == 'true':
    if REALSAVE <= str(TODAY):
        wiz.log("[Debrid Data] Saving all Data", lognot)
        debridit.autoUpdate('all')
        wiz.setS('debridlastsave', str(THREEDAYS))
    else: 
        wiz.log("[Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s" % (REALSAVE, str(TODAY)), lognot)
else: wiz.log("[Debrid Data] Not Enabled", lognot)

wiz.log("[Login Data] Started", lognot)
if KEEPLOGIN == 'true':
    if LOGINSAVE <= str(TODAY):
        wiz.log("[Login Data] Saving all Data", lognot)
        loginit.autoUpdate('all')
        wiz.setS('loginlastsave', str(THREEDAYS))
    else: 
        wiz.log("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s" % (LOGINSAVE, str(TODAY)), lognot)
else: wiz.log("[Login Data] Not Enabled", lognot)

wiz.log("[Auto Clean Up] Started", lognot)
if AUTOCLEANUP == 'true':
    service = False
    days = [TODAY, TOMORROW, THREEDAYS, ONEWEEK]
    feq = int(float(AUTOFEQ))
    if AUTONEXTRUN <= str(TODAY) or feq == 0:
        service = True
        next_run = days[feq]
        wiz.setS('nextautocleanup', str(next_run))
    else: wiz.log("[Auto Clean Up] Next Clean Up %s" % AUTONEXTRUN, lognot)
    if service == True:
        AUTOCACHE      = wiz.getS('clearcache')
        AUTOPACKAGES   = wiz.getS('clearpackages')
        AUTOTHUMBS     = wiz.getS('clearthumbs')
        if AUTOCACHE == 'true': wiz.log('[Auto Clean Up] Cache: On', lognot); wiz.clearCache(True)
        else: wiz.log('[Auto Clean Up] Cache: Off', lognot)
        if AUTOTHUMBS == 'true': wiz.log('[Auto Clean Up] Old Thumbs: On', lognot); wiz.oldThumbs()
        else: wiz.log('[Auto Clean Up] Old Thumbs: Off', lognot)
        if AUTOPACKAGES == 'true': wiz.log('[Auto Clean Up] Packages: On', lognot); wiz.clearPackagesStartup()
        else: wiz.log('[Auto Clean Up] Packages: Off', lognot)
else: wiz.log('[Auto Clean Up] Turned off', lognot)

# wiz.log("[DNS leak] Started", lognot)
# if DNSWARN <= str(TODAY):
    # wiz.log("[DNS leak] test in progress", lognot)
    # dnsleaktest.dialog_warning()
    # wiz.setS('dnswarning', str(THREEDAYS))
# else: 
    # wiz.log("[DNS leak] Next DNS leak test isnt until: %s / TODAY is: %s" % (LOGINSAVE, str(TODAY)), lognot)

wiz.setS('kodi17iscrap', '')