﻿# -*- coding: utf-8 -*-
import os, xbmc
import xml.etree.ElementTree as ET
from updatervar import *
from resources.lib.GUIcontrol import notify
from resources.lib.modules import addonsEnable
from resources.lib.GUIcontrol.notify import get_notifyversion
from resources.lib.GUIcontrol.txt_updater import get_updaterversion

notify_version = get_notifyversion()
updater_version = get_updaterversion()


if __name__ == '__main__':
	xbmc.executebuiltin('UpdateAddonRepos')
	dialog.notification(Dialog_welcome, Dialog_Update, icon_Build, sound=False)

	if setting('updaterversion') == '1234':
		setting_set('updaterversion','1234')

	elif updater_version > int(setting('updaterversion')):
		xbmc.executebuiltin(Updater_startup)
		xbmc.sleep(25000)
		xbmc.executebuiltin(downloader_startup)
		setting_set('updaterversion', str(updater_version))
	else:
		if os.path.exists (downloader_startup_tk):
			xbmc.sleep(5000)
			xbmc.executebuiltin(downloader_startup)

	if setting('autoenable') == 'true':
		addonsEnable.enable_addons()
		setting_set('autoenable','false')

	if not setting('firstrunNotify')=='false':
		if notify_version > int(setting('notifyversion')):
			setting_set('notifyversion', str(notify_version))
			d=notify.notify()
			d.doModal()
			del d

    monitor = xbmc.Monitor()

	while not monitor.abortRequested():
		if monitor.waitForAbort(2*60*60):#διάστημα 2ωρών μεταξύ των ενημερώσεων
			break
		xbmc.executebuiltin('UpdateAddonRepos()')
		dialog.notification('Υπηρεσία ενημέρωσης', 'Εκκίνηση ενημερώσεων προσθέτων', icon_Build, sound=False)