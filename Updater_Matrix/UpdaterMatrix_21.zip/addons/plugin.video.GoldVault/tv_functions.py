import xbmc
import xbmcgui
import xbmcplugin
import urllib.parse
import os
import re
import sys

# Addon info
addon_handle = int(sys.argv[1])
addon_id = 'plugin.video.example'  # Change this to your addon's ID
ICONS_PATH = os.path.join(os.path.dirname(__file__), 'resources', 'images', 'icons')
FANART_PATH = os.path.join(os.path.dirname(__file__), 'resources', 'images', 'fanart.jpg') #added fanart path

def show_sports():
    """Displays sports channels from sport_list.txt."""
    file_path = os.path.join(os.path.dirname(__file__), 'sport_list.txt')
    sport_titles = read_sport_list(file_path)

    if not sport_titles:
        xbmcgui.Dialog().notification("Error", "No sports channels available.", xbmcgui.NOTIFICATION_ERROR)
        return

    # Set fanart for the sports listing
    xbmcplugin.setPluginFanart(addon_handle, image=FANART_PATH)

    # Path to the sports image
    sport_image = os.path.join(ICONS_PATH, 'sports.png')
    
    
    for title, url in sport_titles.items():
        list_item = xbmcgui.ListItem(label=title)
        list_item.setProperty('IsPlayable', 'true')

        # Set the same thumbnail for all sports
        list_item.setArt({'thumb': sport_image})
        list_item.setArt({'fanart': FANART_PATH}) # Use FANART_PATH

        xbmcplugin.addDirectoryItem(addon_handle, url, list_item, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)


def play_stream(title, url):
    """Plays the stream with retry logic and improved error handling."""
    retries = 3
    for attempt in range(retries):
        try:
            list_item = xbmcgui.ListItem(label=title)
            list_item.setProperty('IsPlayable', 'true')
            player = xbmc.Player()
            player.play(url, list_item)

            # Wait for a moment to allow playback to initiate
            for _ in range(10):  # Check for 10 seconds
                xbmc.sleep(1000)  # Sleep for 1 second between checks
                if player.isPlaying():
                    xbmcgui.Dialog().notification("Playing", f"Now playing: {title}", xbmcgui.NOTIFICATION_INFO)
                    return  # Exit if playback is successful

            xbmc.log(f"Playback failed for {url} on attempt {attempt + 1}", level=xbmc.LOGWARNING)
            xbmcgui.Dialog().notification("Playback Failed", f"Attempt {attempt + 1} failed.", xbmcgui.NOTIFICATION_ERROR)

        except Exception as e:
            xbmc.log(f"Error playing {url}: {e}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Error", f"Error playing stream: {e}", xbmcgui.NOTIFICATION_ERROR)

        if attempt < retries - 1:
            xbmc.sleep(5000)  # Wait 5 seconds before retrying

    xbmcgui.Dialog().notification("Error", f"Failed to play stream after {retries} attempts.", xbmcgui.NOTIFICATION_ERROR)



def read_sport_list(file_path):
    """Reads sports channel titles and URLs from a text file."""
    sport_titles = {}
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            for i in range(len(lines)):
                line = lines[i].strip()
                if line.startswith('#EXTINF:'):
                    match = re.search(r'#EXTINF:-1 group-title=".*?",(.*?)$', line)
                    if match:
                        title = match.group(1).strip()
                        if i + 1 < len(lines):
                            url = lines[i + 1].strip()
                            sport_titles[title] = url
                        else:
                            xbmc.log(f"URL missing for title: {title}", level=xbmc.LOGERROR)
    except FileNotFoundError:
        xbmc.log(f"File not found: {file_path}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", f"File not found: {file_path}", xbmcgui.NOTIFICATION_ERROR) #added
    except Exception as e:
        xbmc.log(f"Error reading file: {str(e)}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", f"Error reading file: {str(e)}", xbmcgui.NOTIFICATION_ERROR) #added
    return sport_titles