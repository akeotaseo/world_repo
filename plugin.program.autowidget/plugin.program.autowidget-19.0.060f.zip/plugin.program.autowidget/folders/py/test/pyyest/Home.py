﻿import xbmc



xbmc.executebuiltin('ActivateWindow(Home)')