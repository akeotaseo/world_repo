﻿import xbmc, xbmcaddon
from updatervar import *
xbmcgui.Dialog().notification("Database", "Addons33", icon='special://home/addons/plugin.program.downloader19/resources/media/database.webp', sound=False)

def set_setting():


    ###  plugin.program.downloader19   ###

    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('addonsreposversion')=='0':
        xbmc.sleep(1000)
        setting_set_downloader19('addonsreposversion', '0')

        xbmc.sleep(2000)
        xbmcgui.Dialog().notification("Database", "Addons33", icon='special://home/addons/plugin.program.downloader19/resources/media/auto4.png', sound=False)
        xbmc.sleep(4000)
        xbmcgui.Dialog().ok('[B][COLOR orange][COLOR white]World Updater...[/COLOR][/COLOR][/B]', '[B][COLOR=white]Επαν-εκκίνηση [COLOR orange]World Updater - Tools[/COLOR][/B].')
        xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/service.py")')



#            xbmc.executebuiltin("ReloadSkin()")

set_setting()
