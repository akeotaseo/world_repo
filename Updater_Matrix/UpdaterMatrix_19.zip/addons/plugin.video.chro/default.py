# -*- coding: utf-8 -*-
import os
import sys

try:
    from urllib.parse import urlparse, urlencode
    from urllib.request import urlopen, Request
    from urllib.error import HTTPError
except ImportError:
    from urlparse import urlparse
    from urllib import urlencode
    from urllib2 import urlopen, Request, HTTPError


import re
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import xbmcplugin
import plugintools
import unicodedata
import base64
import requests
import shutil
import base64
import time
import six
import random
import string
from datetime import date
from datetime import datetime
try:
    from resolveurl.lib import jsunpack 
except ImportError:
    from resolveurl.plugins.lib import jsunpack 
from resources.modules import control

    
#PY3=False
addon = xbmcaddon.Addon()
addonname = '[LOWERCASE][CAPITALIZE][COLOR orange]Lista TV Romania[/CAPITALIZE][/LOWERCASE][/COLOR]'
icon = addon.getAddonInfo('icon')
myaddon = xbmcaddon.Addon("plugin.video.chro")
#px={"http": "http://14.139.189.213:3128"}
px=''
local_file=xbmcvfs.translatePath('special://home/addons/plugin.video.chro/proxy.dat')
listacanale = 'https://gist.githubusercontent.com/staycanuca/674dbc2e2cbe52928a1aaa1272aa9d96/raw/8851f55ce10098fc70dc587315235edbfc287a1f/listacanale.txt'
adresecanale = 'https://gist.githubusercontent.com/staycanuca/595cefa12760f7eca28407fb1a05406b/raw/1c5819988d55f92ffedd0fbc39439aad1cdc0413/canale.txt'

## Fotos
thmb_nada='https://archive.org/download/bee-1/pngegg%20%281%29.png'
thmb_ver_canales='https://archive.org/download/bee-1/channels%20live.png'
thmb_ver_vod='https://archive.org/download/bee-1/vod%20mac.png'
thmb_cambio_servidor='https://archive.org/download/bee-1/server.png'
thmb_cambio_mac='https://archive.org/download/bee-1/MAC.png'
thmb_carga_servidores='https://archive.org/download/bee-1/arrow.png'
thmb_guarda_servidores='https://archive.org/download/bee-1/rack-server_icon-icons.com_52830.png'
thmb_nuevo_servidor='https://icons.iconarchive.com/icons/custom-icon-design/pretty-office-9/256/new-file-icon.png'
thmb_guia='https://static.vecteezy.com/system/resources/previews/000/567/906/non_2x/vector-tv-icon.jpg'
fanny="https://i.ytimg.com/vi/_7bFXWNfXTY/maxresdefault.jpg"
fanart_guia="http://www.panoramaaudiovisual.com/wp-content/uploads/2012/01/EPG-Toshiba-Smart-Tv-web.png"
backgr="https://freeiptvstb.com/wp-content/uploads/2021/06/UZ4VHKEdhTkviRzJSEfFZC.jpg"
thmb_ver_set='https://archive.org/download/bee-1/settings.png'
thmb_ver_xc='https://archive.org/download/bee-1/xtream%20codes.png'
thmb_ver_stb='https://archive.org/download/bee-1/mac-iptv.png'
thmb_ver_m3u='https://archive.org/download/bee-1/live-iptv.png'
thmb_about='https://archive.org/download/bee-1/about.png'
thmb_radio='https://archive.org/download/bee-1/radio.png'
fnrt_radio='http://www.elzulianorajao.com/images/site/radio-g.jpg'
thmb_help='https://archive.org/download/bee-1/help.png'
thmb_ace='https://archive.org/download/bee-1/Ace%20Stream.png'
thmb_tube='https://archive.org/download/bee-1/Tube.png'

portal = control.setting('portal')
mac = control.setting('mac')
userp = control.setting('userp')
portalxc = control.setting('portalxc')
usernamexc = control.setting('usernamexc')
passxc = control.setting('passxc')
f4mproxy = control.setting("f4mproxy")
search_done = False





   
def run():
    
    plugintools.log("---> chro.run <---")
    #plugintools.set_view(plugintools.LIST)
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
       action = params.get("action")
       url = params.get("url")
       exec(action+"(params)")
    plugintools.close_item_list()

    
def main_list(params):

    import shutil,xbmc  
    try:
        addon_path3 = xbmcvfs.translatePath('special://home/cache').decode('utf-8')
        shutil.rmtree(addon_path3, ignore_errors=True) 
    except:
        pass
    
        
    plugintools.log("chro.main_list ")    
    params['title']="[COLOR red]i[COLOR orange]P[COLOR green]TV[COLOR orange] CHaNNeLS[/COLOR]"
    params['thumbnail']=thmb_ver_canales
    params['fanart']="https://i.ytimg.com/vi/_7bFXWNfXTY/maxresdefault.jpg"

	

   
    
    plugintools.log("koditv.super_iptv")
    thumbnail = thmb_ver_xc
    plugintools.add_item(action="search_iptv_channels", url='todos',title="[LOWERCASE][CAPITALIZE][COLOR white]Cauta canal[/CAPITALIZE][/LOWERCASE][/COLOR]",thumbnail=thumbnail,fanart=thumbnail,folder=True )
    plugintools.add_item(action="tvroall", url='',title="[LOWERCASE][CAPITALIZE][COLOR white]Toate Canalele[/CAPITALIZE][/LOWERCASE][/COLOR]",thumbnail=thumbnail,fanart=thumbnail,folder=True )
    plugintools.add_item(action="tvroallaz", url='',title="[LOWERCASE][CAPITALIZE][COLOR white]CANALE A-Z[/CAPITALIZE][/LOWERCASE][/COLOR]",thumbnail=thumbnail,fanart=thumbnail,folder=True ) 
    # Lista de imagini miniatură asociate fiecărui gen
    thumbnails = [
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTx46DNVznxZM7lUimuOFaxS6NjcQhOzpU3Lg&s",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTx46DNVznxZM7lUimuOFaxS6NjcQhOzpU3Lg&s",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTx46DNVznxZM7lUimuOFaxS6NjcQhOzpU3Lg&s",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTx46DNVznxZM7lUimuOFaxS6NjcQhOzpU3Lg&s",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTx46DNVznxZM7lUimuOFaxS6NjcQhOzpU3Lg&s",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTx46DNVznxZM7lUimuOFaxS6NjcQhOzpU3Lg&s",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTx46DNVznxZM7lUimuOFaxS6NjcQhOzpU3Lg&s",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTx46DNVznxZM7lUimuOFaxS6NjcQhOzpU3Lg&s",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTx46DNVznxZM7lUimuOFaxS6NjcQhOzpU3Lg&s"
    ]

    url = ''
    # Define genres
    genres = ["Generale", "Filme", "Stiri", "Sport", "Documentare", "Muzica", "Life Style", "Desene Animate", "Altele"]
    for index, genre in enumerate(genres):
        plugintools.add_item(action="afisare_canale", title=genre, url=url, extra=genre, thumbnail=thumbnails[index], fanart=thumbnails[index], folder=True)
        

def afisare_canale(params):
    plugintools.log("chro.tvonline")
    thumbnail = params.get("thumbnail")    
    #url = 'http://localhost/form/continut.txt'
    url = listacanale
    genre = params.get("extra")
    genres = ["Generale", "Filme", "Stiri", "Sport", "Documentare", "Muzica", "Life Style", "Desene Animate", "Altele"]
    # Define channels for each genre
    channels = {
        "Generale": ["A7", "ACASA", "ANTENA 1", "ANTENA INTERNATIONAL", "ANTENA MONDEN", "ANTENA STARS", "COMEDY PLAY", "COOK & PLAY", "DOBROGEA TV", "DOTTO TV", "EMITV", "HAPPY CHANNEL", "HUNEDOARA TV", "JURNAL TV", "KANAL D", "KANALD 2", "KAPITAL TV", "MIREASA 1", "MIREASA 2", "MOLDOVA 1", "MOLDOVA 2", "NATIONAL 24 PLUS", "NATIONAL TV", "PRIMA COMEDY", "PRIMA TV", "PRO TV INTERNATIONAL", "PRO TV", "TVR 2", "TVR INTERNATIONAL", "TVR 1", "TVR 3", "TELESTAR", "TV ARAD", "TVR CRAIOVA", "TVR IASI", "TVR TARGU MURES", "TVR TIMISOARA"],
        "Filme": ["AMC", "AXN", "AXN BLACK", "AXN SPIN", "AXN WHITE", "BBC FIRST", "BOLLYWOOD", "BOLLYWOOD CLASSIC", "BOLLYWOOD FILM", "BOLLYWOOD", "BOXOFFICE FILM", "CINEMARATON", "CINEMAX 2", "CINEMAX", "COMEDY CENTRAL", "DIVA", "DIZI TV", "EPIC DRAMA", "FILM CAFÉ", "FILM MANIA", "FILM NOW", "FILMBOX EXTRA", "FILMBOX PREMIUM", "FILMBOX STARS", "FILMTV HORROR", "FILMTV ISTORIC", "FILMBOX", "FILMBOX FAMILY", "HBO", "HBO2", "HBO3", "MARVEL DC", "PRO CINEMA", "SKYSHOWTIME 1", "SKYSHOWTIME 2", "TLC", "TV 1000", "WARNER TV"],
        "Stiri": ["AGRO TV", "ALEPH BUSINESS", "ALEPH NEWS", "ALFA OMEGA TV", "ANTENA 3", "B1", "CBS REALITY", "DIGI 24", "EURONEWS", "GLOBAL NEWS TV", "HD 365", "INFO", "JOBTV", "NASUL TV", "PRIMA NEWS", "PRIVESC EU", "PROFIT.RO", "REALITATEA PLUS", "REALITATEA STAR", "ROMANIA TV", "SMART TV", "TVR INFO"],
        "Sport": ["DIGI SPORT 1", "DIGI SPORT 2", "DIGI SPORT 3", "DIGI SPORT 4", "ORANGE SPORT 1", "ORANGE SPORT 2", "ORANGE SPORT 3", "ORANGE SPORT 4", "PRIMA SPORT 1", "PRIMA PPV 1", "PRIMA SPORT 2", "PRIMA PPV 2", "PRIMA SPORT 3", "PRIMA PPV 3", "PRIMA SPORT 4", "PRIMA SPORT 5", "EUROSPORT 1", "EUROSPORT 2", "PRO ARENA", "TVR SPORT", "SPORT EXTRA", "REALITATEA SPORTIVA", "AUTO MOTOR SPORT", "EXTREME SPORTS"],
        "Documentare": ["DISCOVERY CHANNEL", "DISCOVERY ID", "CRIME & INVESTIGATION CHANNEL", "PRIMA HISTORY", "DIGI WORLD", "DIGI LIFE", "DIGI ANIMAL WORLD", "ANIMAL PLANET", "BBC EARTH", "VIASAT HISTORY", "VIASAT NATURE", "VIASAT EXPLORE", "DOCUBOX", "CINETHRONIX", "LOVE NATURE", "HISTORY CHANNEL", "E! ENTERTAINMENT", "NATIONAL GEOGRAPHIC", "NATIONAL GEOGRAPHIC WILD", "NAT GEO PEOPLE"],
        "Muzica": ["TARAF TV", "BALKANIKA MUSIC", "FAVORIT TV", "PARTY MIX", "ETNO TV", "TEZAUR TV", "ORIZONT TV", "MOOZ DANCE", "MOOZ HITS", "MOOZ RO", "ZU TV", "ATOMIC TV", "MTV", "MTV 00S", "MTV 90", "TVR FOLCLOR", "TRACE URBAN", "KISS TV", "MTV LIVE", "MAGIC TV", "ROCK TV", "QUB TV", "U TV", "LIRA TV", "HITS 360", "IMPACT TV", "BALCAN MUSIC TV", "TRADITIONAL TV", "TVAS"],
        "Life Style": ["HGTV", "PRIMA FOOD & TRAVEL", "TV PAPRIKA", "TRAVEL CHANNEL", "FISHING AND HUNTING", "TRINITAS", "SPERANTA TV", "CREDO TV", "CARDIO TV", "EXPLORIS", "FOOD NETWORK"],
        "Desene Animate": ["LOONEY TUNES", "BABY TV", "MASHA SI URSU", "DISNEY CHANNEL", "DISNEY JUNIOR", "NICKELODEON", "DUCK TV", "MINIMAX", "JIMJAM", "NICK JR", "NICKTOONS", "CARTOON NETWORK", "CARTOONITO", "TEENNICK", "TRALALA TV"],
        "Altele": []
    }
    
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body,response_headers = plugintools.read_body_and_headers( url, headers=request_headers)
    url = body.strip().decode('utf-8')
    matches =  re.findall(r'(?s)cn=(.*?)@@th=(.*?)@@', url, re.DOTALL)

    # Add channels to genres
    for titulo, thumbnail in matches:
        if any(channel in titulo for channel in channels[genre]):
            plugintools.add_item(action="tvro2", title="[LOWERCASE][CAPITALIZE] [COLOR orange]"+titulo+"[/CAPITALIZE][/LOWERCASE][/COLOR]", url=url, extra=titulo, thumbnail=thumbnail, fanart=thumbnail, folder=True)
        elif not any(channel in titulo for channel in sum(channels.values(), [])):
            channels["Altele"].append(titulo)
            if genre == "Altele":
                plugintools.add_item(action="tvro2", title="[LOWERCASE][CAPITALIZE] [COLOR orange]"+titulo+"[/CAPITALIZE][/LOWERCASE][/COLOR]", url=url, extra=titulo, thumbnail=thumbnail, fanart=thumbnail, folder=True)
        
def tvro2(params): 
    plugintools.log("chro.tvonline")
    thumbnail = params.get("thumbnail")    
    #url = 'http://localhost/form/continut.txt'
    url = adresecanale
    title=params.get("extra")
    
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body,response_headers = plugintools.read_body_and_headers( url, headers=request_headers)
    data = body.strip().decode('utf-8')
    lines = data.split('\n')
    
    match_counter = 1
    for line in lines:
        if title in line:
            match = re.search(r'nm=(.*?)@@ch=(.*?)@@ref=(.*?)@@', line, re.IGNORECASE | re.DOTALL)
            if match:
                titulo, url, ref = match.groups()
                plugintools . add_item ( action = "playtv123" , title = "Server " + str(match_counter) + ". [LOWERCASE][CAPITALIZE] [COLOR orange]"+titulo+"[/CAPITALIZE][/LOWERCASE][/COLOR]", url = url+"|referer="+ref, thumbnail =  thumbnail , fanart=thumbnail, folder=False,  isPlayable = True )
                match_counter += 1
    
    
    
    
def tvroall(params):
    plugintools.log("chro.tvonline")
    thumbnail = params.get("thumbnail")
    
    plugintools.add_item(action="main_list", url='todos',title="[LOWERCASE][CAPITALIZE][COLOR white]Pagina principala[/CAPITALIZE][/LOWERCASE][/COLOR]",thumbnail=thumbnail,fanart=thumbnail,folder=True )
    
    
    # Verifică dacă parametrul "page" este furnizat și este un număr valid
    page_str = params.get("page", "1")
    try:
        page = int(page_str)
    except ValueError:
        page = 1  # Dacă parametrul "page" nu este un număr valid, folosește pagina 1 implicit

    items_per_page = 50  # Numărul de elemente pe pagină

    #url = 'http://localhost/form/continut.txt'
    url = listacanale

    request_headers = []
    request_headers.append(["User-Agent", "Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body, response_headers = plugintools.read_body_and_headers(url, headers=request_headers)
    url = body.strip().decode('utf-8')
    matches = re.findall(r'(?s)cn=(.*?)@@th=(.*?png)@@', url, re.DOTALL)

    # Calculează indicele de început și de sfârșit al elementelor pe pagina curentă
    start_index = (page - 1) * items_per_page
    end_index = page * items_per_page

    # Selectează elementele corespunzătoare paginii curente
    page_matches = matches[start_index:end_index]

    for titulo, thumbnail in page_matches:
        plugintools.add_item(action="tvro2",
                             title="[LOWERCASE][CAPITALIZE] [COLOR orange]" + titulo + "[/CAPITALIZE][/LOWERCASE][/COLOR]",
                             url=url,
                             extra=titulo,
                             thumbnail=thumbnail,
                             fanart=thumbnail,
                             folder=True)

    # Adaugă butoane pentru navigarea între pagini
    if page > 1:
        plugintools.add_item(action="tvroall", title="Pagina anterioară", url=url, page=str(page - 1), folder=True)
    if end_index < len(matches):
        plugintools.add_item(action="tvroall", title="Pagina următoare", url=url, page=str(page + 1), folder=True)
        

def group_channels_by_alphabet(matches):
    grouped_channels = {}
    for titulo, thumbnail in matches:
        first_char = titulo[0].upper()  # Obține prima literă sau cifra din titlu și o face majusculă
        if first_char.isalpha() or first_char.isdigit():
            if first_char not in grouped_channels:
                grouped_channels[first_char] = []
            grouped_channels[first_char].append((titulo, thumbnail))
        else:
            # Dacă prima literă nu este nici o literă și nici un număr, grupează-o sub 'Altul'
            if 'Altul' not in grouped_channels:
                grouped_channels['Altul'] = []
            grouped_channels['Altul'].append((titulo, thumbnail))
    return grouped_channels

def generate_alphabet_menu(grouped_channels):
    alphabet_menu = []
    alphabet = string.ascii_uppercase  # Obține toate literele mari ale alfabetului
    for letter in alphabet:
        if letter in grouped_channels and grouped_channels[letter]:  # Verifică dacă există canale pentru litera
            alphabet_menu.append({
                "action": "display_channels",
                "title": f"Canale care încep cu '{letter}'",
            })
    # Adaugă o intrare pentru cifrele de la 1 la 9
    for number in range(1, 10):
        if str(number) in grouped_channels and grouped_channels[str(number)]:  # Verifică dacă există canale pentru număr
            alphabet_menu.append({
                "action": "display_channels",
                "title": f"Canale care încep cu '{number}'",
            })
    return alphabet_menu

def display_channels(params):
    plugintools.log("chro.tvonline")
    thumbnail = params.get("thumbnail")

    letter = params.get("title", "")[-2]  # Extrage ultimul caracter din titlu (litera sau cifra)
    letter = letter.upper() if letter.isalpha() else letter  # Asigură că litera este majusculă dacă este o literă

    url = listacanale

    request_headers = []
    request_headers.append(["User-Agent", "Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body, response_headers = plugintools.read_body_and_headers(url, headers=request_headers)
    url = body.strip().decode('utf-8')
    matches = re.findall(r'(?s)cn=(.*?)@@th=(.*?png)@@', url, re.DOTALL)

    grouped_channels = group_channels_by_alphabet(matches)

    for titulo, thumbnail in grouped_channels.get(letter, []):
        plugintools.add_item(action="tvro2",
                             title="[LOWERCASE][CAPITALIZE] [COLOR orange]" + titulo + "[/CAPITALIZE][/LOWERCASE][/COLOR]",
                             url=url,
                             extra=titulo,
                             thumbnail=thumbnail,
                             fanart=thumbnail,
                             folder=True)
    plugintools.add_item(action="tvroallaz", url='',title="[LOWERCASE][CAPITALIZE][COLOR white]CANALE A-Z[/CAPITALIZE][/LOWERCASE][/COLOR]",thumbnail=thumbnail,fanart=thumbnail,folder=True )                          

def tvroallaz(params):
    plugintools.log("chro.tvonline")
    thumbnail = params.get("thumbnail")

    url = listacanale

    request_headers = []
    request_headers.append(["User-Agent", "Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body, response_headers = plugintools.read_body_and_headers(url, headers=request_headers)
    url = body.strip().decode('utf-8')
    matches = re.findall(r'(?s)cn=(.*?)@@th=(.*?png)@@', url, re.DOTALL)

    grouped_channels = group_channels_by_alphabet(matches)

    alphabet_menu = generate_alphabet_menu(grouped_channels)

    for entry in alphabet_menu:
        plugintools.add_item(action=entry["action"],
                             title=entry["title"],
                             extra='',
                             thumbnail=thumbnail,
                             fanart=thumbnail,
                             folder=True)

def search_iptv_channels(params):
    global search_done
    if search_done:
        return 

    plugintools.log("macvod.tvonline")
    thumbnail = params.get("thumbnail")    
    url = listacanale
    title=params.get("extra")
    
    # Solicită intrarea de la utilizator folosind mediul Kodi
    keyboard = xbmc.Keyboard('', 'Cauta Iptv:')
    keyboard.doModal()

    if not keyboard.isConfirmed():
        plugintools.add_item(action="", url='',title='',thumbnail=thmb_ver_m3u,fanart=backgr,folder=True )
        return

    search_term = keyboard.getText()
    return search_iptv_channels_by_term(search_term, thumbnail)
    search_done = True
    
def search_iptv_channels_by_term(search_term, thumbnail):

    url = listacanale
    request_headers = [["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"]]
    body, response_headers = plugintools.read_body_and_headers(url, headers=request_headers)
    data = body.strip().decode('utf-8')
    lines = data.split('\n')
    
    for line in lines:
        if search_term.lower() not in line.lower():  # Căutăm termenul introdus de utilizator (ignorăm diferențele de majuscule/minuscule)
            continue

        match = re.search(r'cn=(.*?)@@th=(.*?png)@@', line, re.IGNORECASE | re.DOTALL)
        if match:
            titulo, url = match.groups()
            plugintools.add_item(action="tvro2", title="[LOWERCASE][CAPITALIZE] [COLOR orange]"+titulo+"[/CAPITALIZE][/LOWERCASE][/COLOR]", extra=titulo, url=url, thumbnail=thumbnail, fanart=thumbnail, folder=True)
            
            
            
            
def playtv123(params):            
    url = params.get("url")
    try:
        plugintools.play_resolved_url( url )    
    except:
        pass  

def resolve_without_resolveurl(params):
   import resolveurl
   finalurl = (params.get ( "url" ))
   plugintools.play_resolved_url ( finalurl )

run()