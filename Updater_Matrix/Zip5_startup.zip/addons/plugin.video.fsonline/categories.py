import os
import sys
import requests
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import xbmcplugin
from urllib.parse import quote
from bs4 import BeautifulSoup

addon = xbmcaddon.Addon()
addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))
icon_path = os.path.join(addon_path, 'resources', 'media')

filme_url = "http://www.filmeserialeonline.org/filme-online-hd-22/"
seriale_url = "http://www.filmeserialeonline.org/seriale-online-hd-2024-00/"

def list_genuri_menu():
    # Obține conținutul HTML al paginii care conține genurile
    response = requests.get(filme_url)
    html_content = response.text

    # Folosește BeautifulSoup pentru a parsa HTML-ul
    soup = BeautifulSoup(html_content, 'html.parser')

    # Găsește toate elementele care conțin genurile
    genres_list = soup.find_all('li', class_='cat-item')

    # Parcurge rezultatele și adaugă-le în meniul Kodi
    for item in genres_list:
        link = item.find('a')
        url = link.get('href')
        genre_name = link.get_text(strip=True)
        list_item = xbmcgui.ListItem(label=genre_name)
        list_item.setArt({'thumb': os.path.join(icon_path, 'genre.png'), 'icon': os.path.join(icon_path, 'genre.png')})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=genuri_filme&url={quote(url)}", listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def list_ani_menu():
    # Obține conținutul HTML al paginii care conține anii pentru filme
    response = requests.get(filme_url)
    html_content = response.text

    # Folosește BeautifulSoup pentru a parsa HTML-ul
    soup = BeautifulSoup(html_content, 'html.parser')

    # Găsește toate elementele care conțin anii
    years_list = soup.find_all('li')

    # Parcurge rezultatele și adaugă-le în meniul Kodi
    for item in years_list:
        link = item.find('a')
        href = link.get('href') if link else None  # Obținem href doar dacă link nu este None
        if href and '/an-film/' in href:
            url = href
            year = link.get_text(strip=True)
            list_item = xbmcgui.ListItem(label=year)
            list_item.setArt({'thumb': os.path.join(icon_path, 'genre.png'), 'icon': os.path.join(icon_path, 'genre.png')})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=ani_filme&url={quote(url)}", listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def list_limba_menu():
    # Obține conținutul HTML al paginii care conține limbile
    response = requests.get(filme_url)
    html_content = response.text

    # Folosește BeautifulSoup pentru a parsa HTML-ul
    soup = BeautifulSoup(html_content, 'html.parser')

    # Găsește toate elementele care conțin limbile
    languages_list = soup.find_all('li')

    # Parcurge rezultatele și adaugă-le în meniul Kodi
    for item in languages_list:
        link = item.find('a')
        href = link.get('href') if link else None  # Obținem href doar dacă link nu este None
        if href and 'limba' in href:
            url = href
            language = link.get_text(strip=True)
            list_item = xbmcgui.ListItem(label=language.capitalize())
            list_item.setArt({'thumb': os.path.join(icon_path, 'genre.png'), 'icon': os.path.join(icon_path, 'genre.png')})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=limba_filme&url={quote(url)}", listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def list_genuri_seriale_menu():
    # Obține conținutul HTML al paginii care conține genurile
    response = requests.get(seriale_url)
    html_content = response.text

    # Folosește BeautifulSoup pentru a parsa HTML-ul
    soup = BeautifulSoup(html_content, 'html.parser')

    # Găsește toate elementele care conțin genurile
    genres_list = soup.find_all('li', class_='cat-item')

    # Loghează genurile găsite
    xbmc.log(f"Genuri găsite: {[(link.get('href'), link.get_text(strip=True)) for link in genres_list]}", level=xbmc.LOGINFO)

    # Parcurge rezultatele și adaugă-le în meniul Kodi
    for item in genres_list:
        link = item.find('a')
        url = link.get('href')
        genre = link.get_text(strip=True)
        xbmc.log(f"Gen adăugat: {genre} - URL: {url}", level=xbmc.LOGINFO)
        list_item = xbmcgui.ListItem(label=genre.capitalize())
        list_item.setArt({'thumb': os.path.join(icon_path, 'genre.png'), 'icon': os.path.join(icon_path, 'genre.png')})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=genuri_seriale&url={quote(url)}", listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def list_ani_seriale_menu():
    # Obține conținutul HTML al paginii care conține anii
    response = requests.get(seriale_url)
    html_content = response.text

    # Folosește BeautifulSoup pentru a parsa HTML-ul
    soup = BeautifulSoup(html_content, 'html.parser')

    # Găsește toate elementele care conțin anii
    years_list = soup.find_all('li')

    # Parcurge rezultatele și adaugă-le în meniul Kodi
    for item in years_list:
        link = item.find('a')
        href = link.get('href') if link else None  # Obținem href doar dacă link nu este None
        if href and '/an-serial/' in href:
            url = href
            year = link.get_text(strip=True)
            list_item = xbmcgui.ListItem(label=year)
            list_item.setArt({'thumb': os.path.join(icon_path, 'genre.png'), 'icon': os.path.join(icon_path, 'genre.png')})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=ani_seriale&url={quote(url)}", listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def list_limba_seriale_menu():
    # Obține conținutul HTML al paginii care conține limbile
    response = requests.get(seriale_url)
    html_content = response.text

    # Folosește BeautifulSoup pentru a parsa HTML-ul
    soup = BeautifulSoup(html_content, 'html.parser')

    # Găsește toate elementele care conțin limbile
    languages_list = soup.find_all('li')

    # Parcurge rezultatele și adaugă-le în meniul Kodi
    for item in languages_list:
        link = item.find('a')
        href = link.get('href') if link else None  # Obținem href doar dacă link nu este None
        if href and 'limba-serial' in href:
            url = href
            language = link.get_text(strip=True)
            list_item = xbmcgui.ListItem(label=language.capitalize())
            list_item.setArt({'thumb': os.path.join(icon_path, 'genre.png'), 'icon': os.path.join(icon_path, 'genre.png')})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=limba_seriale&url={quote(url)}", listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

