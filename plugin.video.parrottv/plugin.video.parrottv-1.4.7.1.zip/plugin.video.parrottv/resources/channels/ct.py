import requests
import xml.etree.ElementTree as ET

BASE = "https://www.ceskatelevize.cz"
HEADERS={"Content-type": "application/x-www-form-urlencoded",
         "Accept-encoding": "gzip",
         "Connection": "Keep-Alive",
         "User-Agent": "Dalvik/1.6.0 (Linux; U; Android 4.4.4; Nexus 7 Build/KTU84P)"}
TOKENURL = "/services/ivysilani/xml/token/"
PLAYLISTURL = "/services/ivysilani/xml/playlisturl/"

_token = None
_session = requests.Session()
_session.headers.update(HEADERS)

def _https_ceska_televize_fetch(url, params):
    response = _session.post(BASE + url, data=params)
    return response

def _token_refresh():
    params = {"user": "iDevicesMotion"}
    response = _https_ceska_televize_fetch(TOKENURL, params)
    global _token
    _token = ET.fromstring(response.content).text
    return response

def _fetch(url, params):
    if _token is None:
        _token_refresh()
    params["token"] = _token
    response = _https_ceska_televize_fetch(url, params)
    try:
        root = ET.fromstring(response.content)
    except:
        return None
    if root.tag == "errors":
        if root[0].text == "no token sent" or root[0].text == "wrong token":
            _token_refresh()
            response = _https_ceska_televize_fetch(url, params)
        else:
            raise Exception(', '.join([e.text for e in root]))
    return response



def getct(channel):
    response = _fetch(PLAYLISTURL, {'quality': 'web', 'ID': channel, 'playerType': 'iPad'})
    root = ET.fromstring(response.content)
    if root.tag == "errors":
        raise Exception(', '.join([e.text for e in root]))
    playlist_url = root.text
    response = _session.get(playlist_url)
    playlist_data = response.content
    root = ET.fromstring(playlist_data)
    videos = root.findall("smilRoot/body//video")
    manifest = videos[0].get('src')
    return manifest

class CT:
    def __init__(self):
        self.ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'
        self.alternatives = {
            "CT1": "http://213.151.233.20:8000/dna-5100-tv-pc.m3u8"
        }

    def grab(self, channel):
        channel = channel.upper()
        headers = {'User-Agent': self.ua}
        headers.update({'Referer': 'http://ceskatelevize.cz/'})
        url = ""
        if channel in self.alternatives:
            url = self.alternatives[channel]
        else:
            url = getct(channel)
        return url, headers