import xbmc, xbmcgui, xbmcaddon

addon_pvr       = xbmcaddon.Addon('pvr.stalker')
setting_pvr     = addon_pvr.getSetting
setting_set_pvr = addon_pvr.setSetting
icon ='special://home/addons/pvr.stalker/icon.png'

def pvr():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)

    call = xbmcgui.Dialog().select('[COLOR=orange]Επιλογή Πύλης ...[/COLOR]',
['[B][COLOR=whiteΠύλη [COLOR=lime]1[/COLOR][/B]',
 '[B][COLOR=white]Πύλη [COLOR=lime]2[/COLOR][/B]',
 '[B][COLOR=white]Πύλη [COLOR=lime]3[/COLOR][/B]',
 '[B][COLOR=white]Πύλη [COLOR=lime]4[/COLOR][/B]',
 '[B][COLOR=white]Πύλη [COLOR=lime]5[/COLOR][/B]',
 '[COLOR=white]+ [COLOR=lime]Προσθήκη επιπλέον πυλών[/COLOR]'])



    if call:
        if call < 0:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [COLOR orange]Πύλη [COLOR lime]1[/COLOR]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    setting_set_pvr('active_portal', '0')
    pvr_on_off()
    cleaner()

def click_2():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [COLOR orange]Πύλη [COLOR lime]2[/COLOR]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    setting_set_pvr('active_portal', '1')
    pvr_on_off()
    cleaner()
    xbmc.sleep(10000)
    xbmc.executebuiltin('SendClick(28)')

def click_3():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [COLOR orange]Πύλη [COLOR lime]3[/COLOR]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    setting_set_pvr('active_portal', '2')
    pvr_on_off()
    cleaner()
    xbmc.sleep(10000)
    xbmc.executebuiltin('SendClick(28)')

def click_4():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [COLOR orange]Πύλη [COLOR lime]4[/COLOR]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    setting_set_pvr('active_portal', '3')
    pvr_on_off()
    cleaner()
    xbmc.sleep(10000)
    xbmc.executebuiltin('SendClick(28)')

def click_5():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [COLOR orange]Πύλη [COLOR lime]5[/COLOR]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    setting_set_pvr('active_portal', '4')
    pvr_on_off()
    cleaner()
    xbmc.sleep(10000)
    xbmc.executebuiltin('SendClick(28)')

def click_6():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgknwizard.eu%2Frepo%2FBuilds%2FTechNEWsology%2FUpdaterMatrix%2FPvr_Stalker%2FPvr_Settings_Portals.zip&mode=9&name=Προσθήκη 5 επιπλέον πυλών...)')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B]",'[COLOR white]Αναμονή προς ολοκλήρωση απαραίτητων ενεργειών![/COLOR]' , icon)
    xbmc.sleep(12000)
    cleaner()
    pvr_on_off()
    xbmc.sleep(10000)
    xbmc.executebuiltin("ReloadSkin()")

def cleaner():
    xbmc.executebuiltin("ActivateWindowAndFocus(pvrsettings, 100,0 , -69,0)")
    xbmc.executebuiltin('SendClick(-69)')
    xbmc.executebuiltin('SendClick(11)')
    xbmc.executebuiltin("ActivateWindow(10700)")

def pvr_on_off():
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":true}}')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":true}}')

pvr()
