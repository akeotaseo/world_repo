import re
from ..common import getHTML


def parseInt(sin):
    m = re.search(r'^(\d+)[.,]?\d*?', str(sin))
    return int(m.groups()[-1]) if m and not callable(sin) else 0


def xx(n):
    global xx  # Define xx as global to allow modification
    t = dc()

    def new_xx(r):
        return t[r + op]
    xx = new_xx  # Reassign xx to the new function
    return xx(n)


def dc():
    n = arr1

    def inner_dc():
        return n
    return inner_dc()


def rottit(n, x, cf):
    cff = re.sub(r'parseInt\(\w+', 'parseInt(xx', cf)
    r = n()
    # while True:
    for i in range(0, len(r)):  # run max over length of array
        try:
            # test = parseInt(xx(404))/1*(parseInt(xx(390))/2)+-parseInt(xx(415))/3*(-parseInt(xx(403))/4)+parseInt(xx(417))/5+parseInt(xx(388))/6*(-parseInt(xx(416))/7)+parseInt(xx(397))/8*(-parseInt(xx(382))/9)+-parseInt(xx(391))/10*(-parseInt(xx(381))/11)+parseInt(xx(405))/12*(parseInt(xx(398))/13)
            if (eval(cff) == x):
                break
            r.append(r.pop(0))
        except:
            r.append(r.pop(0))


def getKey():
    try:
        data = getHTML("https://thetvapp.to/")
        js = re.findall(r'<script\s+type="module"\s+src="([^"]+)', data)[0]
        data = getHTML(js, referer="https://thetvapp.to/")
        m = re.search(r'\w{1,2}="([\w\-\=\+]+)"\)\s*{\s*const\s+\w+\s*=\s*\w+', data)
        if m:
            key = m.groups()[0]
        else:
            m = re.search(r'\w{1,2}\(\w{1,2}\)\s*{\s*const\s+\w{1,2}\s*=\s*"([\w\-\=\+]+)";', data)
            if m:
                key = m.groups()[0]
            else:
                i1, f1 = re.findall(r'\w{1,2}=\w{2}\((\d{3})\)\)\s*{\s*const\s+\w+\s*=\s*(\w+)', data)[0]
                f2 = re.findall(r'const\s+{}\s*=\s*(.*?);'.format(f1), data)[0]
                f2 = f2.replace('$', r'\$')
                arrv1, dummy, op1 = re.findall(r'function\s+%s\(.*?{\s*const\s+\w+\s*=\s*(\w+)\(\).*?return\s+(\w+)\s*=\s*\2\s*([\+\-]\s*\d+)' % f2, data, re.S)[0]
                global op
                op = eval(op1)
                global arr1
                arr1 = re.findall(r'function\s+%s\(\)\s*\{\s*const\s+\w+\s*=\s*(\[.*?\]);\s*return' % arrv1, data)[0]
                arr1 = eval(arr1)
                calc1 = re.findall(r'if\s*\((-?parseInt.*?)\s*===\s*\w+\s*\).*?}\s*\)\s*\((\w+),\s*(\d+)', data, re.S)
                calc1 = [c for c in calc1 if c[1] == arrv1][0]
                cf = calc1[0]
                x = int(calc1[2])
                i1 = int(i1)
                rottit(dc, x, cf)
                key = xx(i1)

        return key
    except:
        return ""


def getPass():
    try:
        data = getHTML("https://thetvapp.to/tv")
        js = re.findall(r'<script\s+type="module"\s+src="([^"]+)', data)[0]
        data = getHTML(js, referer="https://thetvapp.to/")
        pwvar = re.findall(r'password:([\w\$]+)', data)[0].replace("$", r"\$")
        pwfuncs = re.search(r'const\s+%s=(.*?);' % pwvar, data)
        if pwfuncs and "+" in pwfuncs.group(1):
            pwfuncs = pwfuncs.group(1).split("+")
        else:
            f_ = re.findall(r'(function\s+%s.*?return.*?})\s*(?:function|const|fetch|$)' % pwvar, data)[0]
            pwfuncs = re.findall(r'let\s(\w)="";return\s\1\+=([^,]+),\1\+=([^,]+),\1\+=([^,]+),\1\+=([^,]+)', f_)[0]
            pwfuncs = [pf_[-4:].replace('(', '').replace(')', '') for pf_ in pwfuncs[1:]]

        df, calc, op1 = re.findall(r'\(function.*?{for\(var\s+[\w\$]=([\w$]+).*?;\)\s*try\s*{var\s+[\w\$]+=(-?parseInt.*?);.*?}\)\([\w\$]+,\s*(\d+)', data)[-1]
        op2 = re.findall(r'function\s+%s.*?=[\w\$]([\+-]\d+)' % df, data)[0]
        global op
        op = eval(op2)
        global arr1
        arr1 = re.findall(r'function\s+[\w\$]+\(\)\s*{\s*var\s+[\w\$]+=(\[.*?]);', data)[-1]
        arr1 = eval(arr1)
        rottit(dc, int(op1), calc)

        pw = ""
        for pwfunc in pwfuncs:
            pwfunc = re.sub(r'([\$\(\)])', r'\\\1', pwfunc)
            jsc = re.findall(r'(function\s+%s.*?return.*?})\s*(?:function|const|fetch|$)' % pwfunc, data)[0]
            m = re.search(r'"(\w{3})"', jsc)
            if m:
                pw += m.group(1)
            else:
                m = re.search(r'var\s*([^=]+)=.*return.*?[^\[:{}\]]\1\((\d+)\)}', jsc)
                if not m:
                    m = re.search(r'var\s*([^=]+)=.*return.*?\[\1\((\d+)\)\]}', jsc)
                    if not m:
                        m = re.search(r'var\s*([^=]+)=.*return\s+.*?[\w\$]\.([\w$]+)}', jsc)
                        k = m.group(2)
                    else:
                        k = xx(int(m.group(2)))
                    m = re.search(r'%s:\s*([\w\$]+)\((\d+)\)' % k, jsc)

                idx = int(m.group(2))
                pw += xx(idx)

        return pw if len(pw) == 12 else ""
    except:
        # import traceback
        # traceback.print_exc()
        return ""
