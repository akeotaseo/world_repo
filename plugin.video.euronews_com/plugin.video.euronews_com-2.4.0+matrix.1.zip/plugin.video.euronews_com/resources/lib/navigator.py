﻿# -*- coding: utf-8 -*-

from .common import *


def main_menu():
	debug_MS("(navigator.main_menu) -------------------------------------------------- START = main_menu --------------------------------------------------")
	add_views({'mode': 'list_videos', 'slug': 'timeline', 'name': 'Timeline'}, create_entries({'Title': translation(30605)}))
	counter, unwanted = 0, ['livingit', 'joboffers', '/paidpost', 'partner', 'service', '/tag', '/video']
	DATA_ONE = trackContent(BASE_URL, 'GET', 'TEXT', HEAD_WEB)
	RESULTS = re.findall(r'''<ul class=["']c-navigation-bar__wrappable-list(.*?)<div class=["']o-site-hr__second-level__dropdown__container''', DATA_ONE, re.S)
	for chtml in RESULTS:
		part = chtml.split('id="adb-header-mainnav')
		for i in range(1, len(part), 1):
			articles = re.compile(r'''class=["']c-navigation-bar__link["'] href=["']([^"']*)["'] aria-label=[^>]*>(.*?)</a>''', re.S).findall(part[i])
			for link, name in articles: # <a class="c-navigation-bar__link" href="/my-europe" aria-label="Read more about Europa">Europa</a>
				name, counter = cleaning(name.replace('\n', '')), counter.__add__(1)
				if link and (any(eox in link.lower() for eox in unwanted) or counter == 1): continue
				debug_MS(f"(navigator.main_menu[1]) ##### COUNTER : {counter} || NAME : {name} || LINK : {link} #####")
				FETCH_UNO = create_entries({'Title': translation(30606).format(name)})
				add_views({'mode': 'list_themes', 'slug': link, 'synopsis': f"{part[i]}</level></stop>", 'name': name}, FETCH_UNO)
	add_views({'mode': 'list_programs'}, create_entries({'Title': translation(30607)}))
	add_views({'mode': 'play_live'}, create_entries({'Title': translation(30608), 'Image': f"{artpic}livestream.png"}), False)
	if enable_tune:
		add_views({'mode': 'antuning'}, create_entries({'Title': translation(30609), 'Image': f"{artpic}settings.png"}), False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_themes(SLUG, COMPACT, NAME):
	debug_MS("(navigator.list_themes) -------------------------------------------------- START = list_themes --------------------------------------------------")
	debug_MS(f"(navigator.list_themes) ### NAME = {NAME} ###\n### >>> COMPACT_LIST = {COMPACT}\n<<< COMPACT_LIST ###\n### SLUG = {SLUG} ###")
	debug_MS("---------------------------------------------")
	counter, unikat, unwanted = 0, set(), ['livingit', 'joboffers', '/paidpost', 'partner', 'service', '/tag', '/video']
	DATA_ONE = re.findall(r'''<div class=["']c-navigation-bar__subitem (?:c-links-list|c-featured-nav)[^>]*>(.*?)</ul>\s*</div>''', COMPACT, re.S)
	for chtml in DATA_ONE:
		heading = re.compile(r'''<div class=["']c-navigation-bar__subitem__title(?: c-featured-nav__title)?["']>([^<]*)<''', re.S).findall(chtml)
		if SLUG and heading: # HEADLINE === <div class="c-navigation-bar__subitem__title">Programme</div>
			add_views({'mode': 'blankFUNC'}, create_entries({'Title': f"[B][COLOR lime]≡ ≡ ≡ {heading[0]} ≡ ≡ ≡[/COLOR][/B]"}), False)
			debug_MS(f"(navigator.list_themes[1]) >>>>> MAIN_CATEGORY : {heading[0]} >>>>>")
		parts_uno = re.compile(r'''<a href=["']([^"']*)["'] class=["']c-links-list__link["'] aria-label=[^>]*>(.*?)</a>''', re.S).findall(chtml)
		parts_due = re.compile(r'''<a class=["']c-featured-nav__item__link["'] href=["']([^"']*)["'] aria-label=.+?class=["']c-featured-nav__item__title[^>]*>(.*?)</p>''', re.S).findall(chtml)
		categories = parts_uno if parts_uno else parts_due # <a href="/my-europe/europa-news" class="c-links-list__link" aria-label="Read more about Europa News">Europa News</a>
		for link, name in categories: # <a class="c-featured-nav__item__link" href="https://de.euronews.com/programme/water-matters" aria-label=...<p class="c-featured-nav__item__title">Water Matters</p>
			if link not in unikat and not any(ts in link.lower() for ts in unwanted):
				unikat.add(link)
				name, piece, counter = cleaning(name.replace('\n', '')), 'PROGRAMS' if 'programs/' in link else 'THEMES', counter.__add__(1)
				target = link if link.startswith('http') else f"https:{link}" if link.startswith('//') else f"{BASE_URL}{link}"
				add_views({'mode': 'list_videos', 'slug': target, 'name': name, 'piece': piece}, create_entries({'Title': name, 'Genre': name}))
				debug_MS(f"(navigator.list_themes[2]) ##### COUNTER : {counter} || NAME : {name} || CATEGORY : {piece} || LINK : {target} #####")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_programs():
	debug_MS("(navigator.list_programs) ------------------------------------------------ START = list_programs -----------------------------------------------")
	counter, DATA_ONE = 0, trackContent(f"{BASE_URL}/programs", 'GET', 'TEXT', HEAD_WEB) # ab Mai 2026 in URL=programs für alle Sprachen
	RESULT_ONE = re.compile(r'''<main class=["']o-site-main["'] id=["']enw-main-content["']>\s*<div data-content=["'](.*?)["'] data-verticals=["']''', re.S).findall(DATA_ONE)[0].replace('&quot;', '"').replace('\/', '/')
	add_views({'mode': 'list_videos', 'slug': 'FASTRUN@@homevideo', 'name': 'Homevideo', 'piece': 'VIDEOS'}, create_entries({'Title': translation(30610), 'Genre': 'Homevideo'}))
	character = json.loads(RESULT_ONE)
	for key, value in character.items():
		for article in value:
			name, piece = cleaning(article['data']['title']), 'PROGRAMS'
			target, teaser = article.get('data', {}).get('id', None), (cleaning(article.get('data', {}).get('description', '')) or '')
			thumb = re.sub(r'programs/{{w}}x{{h}}_', 'programs/programs-posters/500x660_poster-', article['data']['images'][0]['url']) if article.get('data', '') and article['data'].get('images', '') and article['data'].get('images', {})[0].get('url', '') else None
			if thumb and 'from-the-usa' in thumb: thumb = f"{artpic}from-the-usa.png"
			if target is None or any(vs in target for vs in ['-azerbaijan', 'virtual-']): continue # https://static.euronews.com/articles/programs/{{w}}x{{h}}_climate-now.jpg
			counter += 1 # https://static.euronews.com/articles/programs/programs-posters/500x660_poster-climate-now.jpg // https://static.euronews.com/articles/programs/programs-bg/632x512_bg-climate-now.jpg
			add_views({'mode': 'list_videos', 'slug': f"FASTRUN@@{target}", 'name': name, 'piece': piece}, create_entries({'Title': name, 'Plot': teaser, 'Genre': name, 'Image': thumb}, False))
			debug_MS(f"(navigator.list_programs[1]) ##### COUNTER : {counter} || NAME : {name} || CATEGORY : {piece} || SLUG : {target} #####")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_videos(SLUG, NAME, PIECE):
	debug_MS("(navigator.list_videos) ------------------------------------------------ START = list_videos -----------------------------------------------")
	debug_MS(f"(navigator.list_videos) ### NAME = {NAME} ### CATEGORY = {PIECE} ### LINK/SLUG = {SLUG} ###")
	unikat, (combo, merging), (next_page, DATA_ONE, sign_link) = set(), ({} for _ in range(2)), (None for _ in range(3))
	page_number, (complete, sending, combo_partial, combo_pages, combo_uno, combo_due) = 1, ([] for _ in range(6))
	if NAME == 'Timeline':
		while page_number > 0:
			DATA_ONE = trackContent(f"{BASE_DROID}/pages/{SLUG}" if page_number == 1 else next_page, 'GET', 'JSON', HEAD_ATV)
			if DATA_ONE is not None and DATA_ONE.get('pageContent', {}) and len(DATA_ONE['pageContent']) > 0:
				for item in DATA_ONE.get('pageContent', []): # ARTICLES = 'justin'
					if item.get('type') == 'justin' and item.get('content', {}) and len(item['content']) > 0:
						for result in item.get('content', {}):
							combo_partial.append(_parse_uno(result))
			if DATA_ONE is not None and str(DATA_ONE.get('pagination', {}).get('next', {}).get('url', '')).startswith('/pages/timeline') and int(page_number) <= 5: # Maximum of total 5 Pages
				debug_MS("---------------------------------------------")
				page_number, next_page = page_number.__add__(1), f"{BASE_DROID}{DATA_ONE['pagination']['next']['url']}"
				debug_MS(f"(navigator.list_videos[1.2]) PAGES ### NOW GET NEXTPAGE : {next_page} ###")
			else: break
	else:
		if SLUG.startswith('FASTRUN'):
			marking, sign_link = '&' if PIECE == 'PROGRAMS' else '?', f"program?id={SLUG.split('@@')[1]}" if PIECE == 'PROGRAMS' else SLUG.split('@@')[1]
		else:
			marking, DATA_ONE = '&', trackContent(SLUG, 'GET', 'TEXT', HEAD_WEB)
			if DATA_ONE is not None:
				parts_uno = re.compile(r'''["']entities["']:\{["']theme["']:\{["']id["']:["']([^"']*)["'],["']urlSafeValue["']''', re.S).findall(DATA_ONE) # "entities":{"theme":{"id":"europe-news","urlSafeValue"
				parts_due = re.compile(r'''["']entities["']:\{["']program["']:\{["']id["']:["']([^"']*)["'],["']urlSafeValue["']''', re.S).findall(DATA_ONE) # "entities":{"program":{"id":"europeans-stories","urlSafeValue"
				sign_link = f"theme?id={parts_uno[0]}" if parts_uno else f"program?id={parts_due[0]}" if parts_due else None
		if DATA_ONE is not None or sign_link:
			highest = 11 if sign_link and 'theme?id=' in sign_link and not any(ws in sign_link for ws in ['markets', 'series', 'sport']) else 6 # Maximum of total 10 Pages for Themes and maximum of total 5 Pages for Program-Videos
			for ii in range(1, highest, 1): # https://api.euronews.com/v2/apps/androidPhoneEuronews-6.3/languages/de/pages/theme?id=europe-news&slide=1 // Request for Themes
				page_link = f"{BASE_DROID}/pages/{sign_link}{marking}slide={str(ii)}" if sign_link else f"{SLUG}?p={str(ii)}"
				debug_MS(f"(navigator.list_videos[1]) OVERVIEW-PAGES XXX POS : {str(ii)} || LINK : {page_link} XXX")
				combo_pages.append({'Count_1': int(ii), 'Link_1': page_link})
			debug_MS("---------------------------------------------")
		if combo_pages:
			complete = trackSeveral(combo_pages, 'GET', 'JSON', HEAD_ATV, 3) if sign_link else trackSeveral(combo_pages, 'GET', 'TEXT', HEAD_WEB, 3)
			debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
			if complete and sign_link:
				DATA_TWO = json.loads(complete)
				for contents in DATA_TWO:
					if contents is not None and contents.get('pageContent', {}) and len(contents['pageContent']) > 0:
						for item in contents.get('pageContent', []): # THEMES and PROGRAMS = 'articleslist' // VIDEOS = 'sliders'
							if item.get('type') in ['articleslist', 'sliders'] and item.get('content', {}) and len(item['content']) > 0:
								for result in item.get('content', {}):
									combo_partial.append(_parse_uno(result))
			elif complete and sign_link is None:
				for points, links, article in complete:
					if article is not None:
						contents = re.findall(r'''<article id=.*?the-media-object--has-video(?: the-media-object--has-related)?["'] data-nid=["']([^"']*)["'] data-cid=.*?the-media-object__image"\s*src=["']([^"']*)["'].*?aria-label=["']([^"']*)["'].*?</article>''', article, re.S)
						for ident_uno, thumb_uno, title_uno in contents:
							title_uno, thumb_uno = cleaning(title_uno), re.sub(r'/[0-9]+x[0-9]+_', '/1280x720_', thumb_uno)
							transfer = f"{BASE_EIRIS}{ident_uno}?device=androidPhone&id={ident_uno}"
							debug_MS(f"(navigator.list_videos[1.2]) xxxxx TITLE-01 : {title_uno} || IDD-01 : {ident_uno} || THUMB-01 : {thumb_uno} xxxxx")
							combo_partial.append({'Code': ident_uno, 'Link_1': transfer, 'Title_1': title_uno, 'Thumb_1': thumb_uno, 'Video': True})
	for num, table in enumerate(combo_partial, 1):
		if str(table.get('Code')).isdecimal() and table['Code'] not in unikat and table.get('Video', False) is True: # https://api.euronews.com/v2/apps/androidPhoneEuronews-6.3/languages/de/pages/article?id=2812488 // OLD before
			unikat.add(table['Code'])
			combo_uno.append({**{'Count_1': num}, **{key: value for key, value in table.items() if value not in ['', 'None', None]}})
	if combo_uno: combo_due = _parse_due(combo_uno)
	merging = [{**uno, **next(iter([due for due in combo_due if due.get('Code') == uno.get('Code')]), {})} for uno in combo_uno] # Merge two Lists of Dictionaries by specific value !!!
	if merging: # https://stackoverflow.com/questions/56658669/combine-two-lists-of-dictionaries-by-value-of-key-in-dictionaries
		for post in sorted(merging, key=lambda sox: sox.get('Sorting', '2026-01-01T00:01'), reverse=True): # 0-4 = List1 || 5-18 = List2 (sorted by date in descending order)
			debug_MS("---------------------------------------------")
			notice = {key: value for key, value in post.items() if key != 'Story'}
			debug_MS(f"(navigator.list_videos[3]) ##### Anzahl = {len(post)} || Eintrag : {notice} #####")
			if len(post) < 19: continue ### merging ist gleich Nummer:20 oder 21 ###
			name = (post.get('Title_2', '') or post.get('Title_1', ''))
			prefix = translation(30611).format(post.get('Note')) if post.get('Note') else ""
			plot = prefix+post.get('Story') if len(post.get('Story')) > len(post.get('Teaser')) else prefix+post.get('Teaser')
			photo = (post.get('Thumb_2', None) or post.get('Thumb_1', None))
			debug_MS(f"(navigator.list_videos[3]) ##### POSITION : {post.get('Count_2')} || TITLE : {name} || IDD : {post.get('Code')} || DATE : {post.get('Sorting')} #####")
			debug_MS(f"(navigator.list_videos[3]) ##### YOUTUBE : {post.get('YoutStream')} || EURO_VIDEO : {post.get('EuroStream')} || THUMB : {photo} #####")
			FETCH_UNO = {'Title': name, 'Tagline': post.get('Tagline'), 'Plot': plot, 'Duration': post.get('Duration'), 'Date': post.get('Date'), \
				'Aired': post.get('Aired'), 'Genre': post.get('Genre'), 'Mediatype': 'movie', 'Image': photo, 'Reference': 'Single'}
			add_views({'mode': 'playCODE', 'IDENTiTY': post.get('Code')}, create_entries(FETCH_UNO), False)
			sending.append({'filtrate': post.get('Code'), 'name': name, 'direct': post.get('EuroStream'), 'youtube': post.get('YoutStream')})
		preserve(WORKS_FILE, sending)
	else:
		debug_MS(f"(navigator.list_videos) ##### NO VIDEO-LIST - NO ENTRY FOR >{NAME}< FOUND #####")
		return dialog.notification(translation(30526), translation(30527).format(NAME), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def _parse_uno(news):
	debug_MS("(navigator._parse_uno) -------------------------------------------------- START = _parse_uno --------------------------------------------------")
	debug_MS(f"(navigator._parse_uno[1.1]) xxxxx ARTICLE : {news} xxxxx")
	title_uno, video = cleaning(news['title']), news.get('showVideo', False)
	ident_uno = re.sub(r'(article-|header-)', '', news['id']).strip() if news.get('id', '') else None
	thumb_uno = re.sub(r'/{{w}}x{{h}}', '/1280x720', news['image']['url']) if news.get('image', {}).get('url', '') else None # https://api.euronews.com/v2/apps/androidPhoneEuronews-6.3/languages/de/pages/article?id=2812488 // OLD before
	transfer = f"{BASE_EIRIS}{ident_uno}?device=androidPhone&id={ident_uno}" if ident_uno else None # https://www.euronews.com/iris/euronews/v7.3/de/articles/2812488?device=androidPhone&id=2812488  // NEW at 03.07.25
	return {'Code': ident_uno, 'Link_1': transfer, 'Title_1': title_uno, 'Thumb_1': thumb_uno, 'Video': video}

def _parse_due(news, embrace=[], secondo=[]):
	debug_MS("(navigator._parse_due) -------------------------------------------------- START = _parse_due --------------------------------------------------")
	embrace = trackSeveral(news, 'GET', 'JSON', HEAD_ATV, 3)
	if embrace:
		DATA_RIDER = json.loads(embrace)
		for elem in DATA_RIDER:
			if elem is not None and elem.get('pageContent', {}) and elem.get('pageContent', {})[0].get('content', {}):
				(teaser, descript), sorting, (tagline, display, starting, airing, duration, stream_euro, stream_yout) = ("" for _ in range(2)), '2026-01-01T00:01', (None for _ in range(7))
				number, transition, packs = elem.get('Position', 0), elem.get('Demand', ''), elem['pageContent'][0]['content'][0]
				debug_MS("* * * * * * * * * * * * * * * * * * * * * * *")
				debug_MS(f"(navigator._parse_due[2]) xxxxx POSITION-02 : {number} || LINK-02 : {transition} || ELEMENT-02 : {packs} xxxxx")
				title_due = cleaning(packs.get('title', None))
				ident_due = re.sub(r'(article-|header-)', '', packs['id']).strip() if packs.get('id', '') else None
				teaser = cleaning(packs.get('summary', ''), True)
				thumb_due = re.sub(r'/{{w}}x{{h}}', '/1280x720', packs['image']['url']) if packs.get('image', {}).get('url', '') else None
				bodies = next(filter(lambda aco: aco.get('type') == 'article-body' and aco.get('content', []), elem['pageContent']), None)
				if VIDEO_META is True and bodies and bodies.get('content', {})[0].get('text', ''):
					styles = re.compile(r'</style></head>.+?<h[2/3]>(.*?)</h[2/3]>', re.S).findall(bodies['content'][0]['text'])
					tagline = cleaning(re.sub(r'\<.*?\>', ' ', styles[0])) if styles else None
					tagline = f"{tagline[:125]}..." if tagline and len(tagline) > 125 else tagline
					parts = re.findall(r'<p[^>]*>(.*?)</p>', bodies['content'][0]['text'], re.S)
					story = 'breakone'.join([psx for psx in parts if psx is not None]) if parts and len(parts[0]) > 10 else None
					descript = cleaning(re.sub(r'(>Related\<.*?</li></ul></div|View this post.*?www.instagram.com.*?</a>breakone)', 'breakone', story), True) if story else "" # Delete Related Text and Instagram-Posts
				chips = next(filter(lambda cps: cps.get('type') == 'chipslist' and cps.get('content', {}), elem['pageContent']), None)
				genre = ' / '.join(sorted([cleaning(og.get('title', '')) for og in chips.get('content', {})][:2])) if chips else None
				if packs.get('video', ''):
					if str(elem.get('tracking', {}).get('insider', {}).get('product', {}).get('custom', {}).get('article_publication_date', '')).isdecimal():
						start_times = elem['tracking']['insider']['product']['custom']['article_publication_date']
					else: start_times = packs['dateUts'] if str(packs.get('dateUts')).isdecimal() else None
					if start_times:
						local_start = datetime(1970,1,1) + timedelta(seconds=TGM(time.localtime(start_times)))
						sorting = local_start.strftime('%Y-%m-%dT%H:%M')
						display = local_start.strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('-', '•', ':')
						starting = local_start.strftime('%Y-%m-%dT%H:%M') if KODI_BUILD >= 20 else local_start.strftime('%d.%m.%Y') # 2025-07-03T12:30:00 = NEWFORMAT // 03.07.2025 = OLDFORMAT
						airing = local_start.strftime('%d.%m.%Y') # FirstAired
					if elem.get('tracking', {}).get('adobe', {}).get('customParams', ''): # Duration is displayed in Seconds
						duration = next((tac.get('value') for tac in elem['tracking']['adobe'].get('customParams', {}) if 'videoduration' in tac.get('key', '') and str(tac.get('value')).isdecimal()), None)
					stream_euro = packs['video'].get('url', None)
					stream_yout = packs['video'].get('id', None) if packs['video'].get('type') == 'pfp' else None # 'pfp' Type is for YOUTUBE
					if packs['video'].get('videoFallback', ''):
						if stream_euro is None: stream_euro = packs['video']['videoFallback'].get('url', None)
						if stream_yout is None and packs['video']['videoFallback'].get('type') == 'pfp': stream_yout = packs['video']['videoFallback'].get('id', None) # 'pfp' Type is for YOUTUBE
					secondo.append({'Count_2': int(number), 'Code': ident_due, 'Link_2': transition, 'Title_2': title_due, 'Tagline': tagline, 'Teaser': teaser, 'Story': descript, 'Sorting': sorting,
						'Note': display, 'Date': starting, 'Aired': airing, 'Genre': genre, 'Duration': duration, 'Thumb_2': thumb_due, 'EuroStream': stream_euro, 'YoutStream': stream_yout})
	return secondo

def you_control(CODE):
	END_URL, MARK = (None for _ in range(2))
	TEST_URL = trackContent(f"https://youtu.be/{CODE}", 'GET', 'TRACK', HEAD_TUBE, timeout=15)
	if TEST_URL.status_code in [200, 201, 202]: END_URL, MARK = f"plugin://plugin.video.youtube/play/?video_id={CODE}", 'YOUTUBE'
	return (END_URL, MARK)

def play_live():
	debug_MS("(navigator.play_live) -------------------------------------------------- START = play_live --------------------------------------------------")
	LIVE_URL, STREAM, euro_sign, yout_sign, yout_cipher = (False for _ in range(5))
	suitable = SHORTS_DROID.replace('gr', 'el').replace('pe', 'fa').replace('tr', 'de')# https://www.euronews.com/api/live/data?locale=en
	check_uno = trackContent(f"https://www.euronews.com/api/live/data?locale={suitable}", 'GET', 'TRACK', HEAD_WEB)
	if check_uno.status_code in [200, 201, 202]: # Available Languages: en, fr, de, el, hu, it, fa, pl, pt, ru, es / Arabic in English - Turkish in german
		numerals = re.compile(r'''["']videoId["']:["']([^"']*)["']''', re.S).findall(check_uno.text)
		yout_sign = numerals[0] if numerals else False
		debug_MS(f"(navigator.play_live[2]) ***** CHECKED YOUTUBE - ID IN CONTEXT : {yout_sign} *****")
		yout_cipher = yout_sign if yout_sign else LIVE_CODES if LIVE_CODES != '00' else False
		if yout_cipher:
			debug_MS(f"(navigator.play_live[3]) ***** TESTING - REDIRECTED : https://youtu.be/{yout_cipher} || (Youtube-Redirect-Test) *****")
			LIVE_URL, STREAM = you_control(yout_cipher)
		else: log("(navigator.play_live[3]) XXXXX !!! YOUTUBE - ID NOT FOUND - ACTION NOT SUCCESSFUL - SKIP !!! XXXXX")
	if not LIVE_URL: 
		check_due = trackContent(f"{BASE_DROID.replace('/tr', '/de')}/livestream/{SHORTS_DROID.replace('tr', 'de')}", 'GET', 'TRACK', HEAD_ATV)
		if check_due.status_code in [200, 201, 202]: # Available Languages: en, fr, de, gr, hu, it, pe, pl, pt, ru, es / Arabic in English - Turkish in german
			orig_uno = re.compile(r'''["']primary["']:["']([^"']*)["']''', re.S).findall(check_due.text)
			orig_due = re.compile(r'''["']backup["']:["']([^"']*)["']''', re.S).findall(check_due.text)
			euro_sign = orig_uno[0] if orig_uno else orig_due[0] if orig_due else False
			if euro_sign:
				debug_MS(f"(navigator.play_live[1]) ***** EURONEWS-DIRECT-STREAM FOUND : {euro_sign} *****")
				LIVE_URL, STREAM = euro_sign, 'DIRECT'
			else: log("(navigator.play_live[1]) XXXXX !!! EURONEWS-DIRECT-STREAM NOT FOUND - ACTION NOT SUCCESSFUL - SKIP !!! XXXXX")
	if LIVE_URL and STREAM in ['DIRECT', 'YOUTUBE']:
		debug_MS(f"(navigator.play_live) ### LIVE_URL : {LIVE_URL} ###")
		LTM = xbmcgui.ListItem(translation(30612).format(SHORTS_DROID.upper()), path=LIVE_URL, offscreen=True)
		if STREAM == 'DIRECT':
			LTM.setArt({'icon': icon, 'thumb': f"{artpic}livestream.png", 'poster': f"{artpic}livestream.png"})
			MIME = 'video/mp4' if LIVE_URL.endswith('.mp4') else 'application/vnd.apple.mpegurl'
			LTM.setMimeType(MIME)
			if xbmc.getCondVisibility('System.HasAddon(inputstream.ffmpegdirect)') and MIME == 'application/vnd.apple.mpegurl':
				IA_NAME = 'inputstream.ffmpegdirect'
				LTM.setContentLookup(False), LTM.setProperty('inputstream', IA_NAME)
				LTM.setProperty('Seekable', 'false'), LTM.setProperty('SeekEnabled', 'false')
				LTM.setProperty(f'{IA_NAME}.stream_mode', 'default')
				LTM.setProperty(f'{IA_NAME}.manifest_type', 'hls')
				LTM.setProperty(f'{IA_NAME}.is_realtime_stream', 'true')
				LTM.setProperty(f'{IA_NAME}.open_mode', 'ffmpeg')
		xbmc.Player().play(item=LIVE_URL, listitem=LTM)
	else:
		failing("(navigator.play_live) ##### PLAYBACK OF THE >LIVE STREAM< NOT POSSIBLE #####\n ########## NO STREAM ENTRY FOUND ON THE *Euronews.com* WEBSITE !!! ##########")
		return dialog.notification(translation(30521).format('LIVE'), translation(30528), icon, 10000)

def playCODE(PLID):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS(f"(navigator.playCODE) ### EURONEWS_IDD = {PLID} ###")
	FINAL_URL, euro_sign, yout_cipher = (False for _ in range(3))
	for worx in preserve(WORKS_FILE):
		if worx['filtrate'] != '00' and worx['filtrate'] == PLID:
			clear_title, euro_sign, yout_cipher = worx['name'], worx['direct'], worx['youtube']
			debug_MS(f"(navigator.playCODE[1]) ### WORKFILE-Line : {worx} ###")
	if euro_sign or yout_cipher:
		if euro_sign: FINAL_URL = euro_sign
		if PREFER_TUBE is True or not euro_sign:
			if not yout_cipher:
				debug_MS(f"(navigator.playCODE[2]) ***** SEARCH FOR YOUTUBE - ID : {BASE_URL}/embed/{PLID} || (Youtube-Video-Search) *****")
				check_uno = trackContent(f"{BASE_URL}/embed/{PLID}", 'GET', 'TEXT', HEAD_WEB).replace('\\', '').replace("&quot;", "\"")
				numerals = re.compile(r'''["']videoid["']:["']([^"']*)["'],["']youtubevideoid["']:["']([^"']*)["'],''', re.S).findall(check_uno)
				yout_cipher = numerals[0][1] if numerals and numerals[0][0] == PLID and numerals[0][1] not in ['', 'none', 'None'] else False
			if yout_cipher:
				debug_MS(f"(navigator.playCODE[3]) ***** TESTING - REDIRECTED : https://youtu.be/{yout_cipher} || (Youtube-Redirect-Test) *****")
				VOD_URL, STREAM = you_control(yout_cipher)
				if VOD_URL and STREAM == 'YOUTUBE':
					FINAL_URL = VOD_URL
	if FINAL_URL:
		log(f"(navigator.playCODE) YTID : {yout_cipher} || StreamURL : {FINAL_URL}")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, xbmcgui.ListItem(path=FINAL_URL, offscreen=True))
	else:
		failing(f"(navigator.playCODE) ##### PLAYBACK OF THE VOD-STREAM : >{PLID}< NOT POSSIBLE #####\n ########## NO STREAM ENTRY FOUND ON THE *Euronews.com* WEBSITE !!! ##########")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
		xbmc.PlayList(1).clear()
		return dialog.notification(translation(30521).format('STREAM'), translation(30528), icon, 10000)

def add_views(params, listitem, folder=True):
	uws = build_mass(params)
	listitem.setPath(uws)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
