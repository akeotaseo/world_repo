# -*- coding: utf-8 -*-
# Module: get_video_link
# Author: Zeltorix
# Created on: 2023.10.04
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from json import loads, dumps
from re import findall
from random import choice

import yt_dlp


try:
    from web_api_request import WebApiRequest, headers
except ImportError:
    from source.release.utilitys.resources.lib.web_api_request import WebApiRequest, headers


class VideoLink:
    __slots__ = []

    def definition_links(self, link: str) -> (str, dict):
        if "vk.com" in link or findall(r"\d{5,}_\d{5,}", link) or (len(findall(r"\d{5,}", link)) == 2):
            return self.vk_link(link)
        elif "ok.ru" in link or findall(r"\d{12,}", link):
            return self.ok_link(link)
        elif "rutube.ru" in link or findall(r"(\d,\w){28,}", link):
            return self.rutube_link(link)
        elif "youtube" in link or "embed" in link or findall(r"(\d,-,\w){11}", link):
            return self.youtube_link(link)
        elif "mediavitrina" in link:
            return self.mediavitrina_links(link)
        else:
            raise ValueError(f"Неизвестная ссылка - {link}")

    @staticmethod
    def _vk_get_id(link: str) -> str:
        rex = findall(r'\d{5,}', link)
        if rex:
            return f"-{rex[0]}_{rex[1]}"
        else:
            raise ValueError(f"Неизвестная ссылка {link}")

    def vk_link(self, link: str) -> str:
        id_: str = self._vk_get_id(link)
        if id_:
            post = {"al": "1", "video": id_}

            headers["Referer"] = "moc.xednay//:sptth"[::-1]
            headers["x-requested-with"] = "XMLHttpRequest"

            response = WebApiRequest(headers).request_post("wohs=tca?php.oediv_la/moc.kv//:sptth"[::-1], post)
            if response and response is not int:
                data = response.json()["payload"][1][4]["player"]["params"][0]
                if data.get("hls"):
                    return data["hls"]
                elif data.get("hls_ondemand"):
                    return data["hls_ondemand"]
                else:
                    raise KeyError(f"Нету нудных ключей {dumps(data, indent=2)}")
        else:
            raise ValueError("Отсутствует данные")

    @staticmethod
    def _ok_get_id(link: str) -> str:
        if "video/" in link:
            return link.split("video/")[1]
        elif findall(r"\d{10,}", link):
            return findall(r"\d{10,}", link)[0]
        elif "/" not in link:
            return link
        else:
            raise ValueError(f"Неизвестная ссылка {link}")

    def ok_link(self, link: str) -> (str, dict):
        id_: str = self._ok_get_id(link)
        if id_:
            post: dict = {"st.vpl.id": id_, "st.vpl.bu": link}
            response = WebApiRequest().request_post("oediVreyaLpoP=dmc?kd/ur.ko//:sptth"[::-1], post)
            if response and response is not int:
                data_options: str = findall(
                    r'data-options=".*?"',
                    response.text
                )[0].split('"')[1].replace("&quot;", '"')
                hls: dict = loads(loads(data_options)["flashvars"]["metadata"])
                if hls.get("hlsMasterPlaylistUrl"):
                    video: str = hls["hlsMasterPlaylistUrl"]
                elif hls.get("hlsManifestUrl"):
                    video: str = hls["hlsManifestUrl"]
                else:
                    raise KeyError(f"Нужного ключа не найдено {link}")
                return video
        else:
            raise ValueError("Отсутствует данные")

    @staticmethod
    def _rutube_get_id(link: str) -> str:
        if "/" in link:
            if "?" in link:
                return link.split("?")[0].split("/")[-2]
            elif link.endswith("/"):
                return link.split("/")[-2]
            elif "rutube.ru/play/embed/" in link:
                return link.split("/")[-1]
        elif "/" not in link:
            return link
        else:
            raise ValueError(f"Неизвестная ссылка {link}")

    def rutube_link(self, link: str) -> (str, dict):
        id_: (str, int, dict, None) = self._rutube_get_id(link)
        if id_:
            vido_dict: dict = WebApiRequest().request_get("/snoitpo/yalp/ipa/ur.ebutur//:sptth"[::-1] + id_).json()

            # Если видео на портале
            if vido_dict["has_video"]:
                # Используется ли плеер портала
                if vido_dict["player"] == "rutube":
                    # Обычное видео
                    if vido_dict["video_balancer"]:
                        return vido_dict["video_balancer"]["m3u8"]
                    # Прямой эфир
                    elif vido_dict["live_streams"] and vido_dict["live_streams"].get("hls"):
                        return vido_dict["live_streams"]["hls"][0]["url"]

                    # При отсутствии потока проверить детали
                    elif vido_dict.get("detail"):
                        # Заглушка для стрима
                        if vido_dict["detail"]["name"] == "stream_access_fail":
                            return {
                                "title": vido_dict["detail"]["languages"][0]["title"],
                                "description": vido_dict["detail"]["languages"][0]["description"],
                                "router": "message",
                            }
                    else:
                        raise ValueError(f"Видео вроде как есть на портале, но логики на вынимания потока нет - "
                                         f"{'/snoitpo/yalp/ipa/ur.ebutur//:sptth'[::-1] + id_}")
                else:
                    raise ValueError(f"Видео вроде как есть, но логики на вынимания потока нет - "
                                     f"{'/snoitpo/yalp/ipa/ur.ebutur//:sptth'[::-1] + id_}")
            # Отсутствие видео на портале
            else:
                # Проверяет использоваться ли сторонний плеер
                if vido_dict["player"] == "iframe":
                    return {
                        "title": "Сторонний плеер",
                        "data": "https:" + vido_dict["iframe_url"],
                        "referer": vido_dict["referer"],
                        "router": "iframe",
                    }

                else:
                    raise ValueError(f"Не понятно от куда брать поток, требуется исследование - "
                                     f"{'/snoitpo/yalp/ipa/ur.ebutur//:sptth'[::-1] + id_}")
        else:
            raise ValueError("Отсутствует данные")

    @staticmethod
    def mediavitrina_links(link: str, one_link=False) -> dict:
        response = WebApiRequest().request_get(link)
        if response and response is not int:
            link_site = loads(findall(r"allowedDomains: .*?]", response.text)[0].split("allowedDomains: ")[1])
            refer_host_name: str = list(filter(lambda item: item if "*" not in item else False, link_site[::-1][:2]))[0]

            url_players: str = findall(r"url:.*'", response.text)[0].split("'")[1]

            link_players: str = url_players \
                .replace("{{APPLICATION_ID}}", "") \
                .replace("{{PLAYER_REFERER_HOSTNAME}}", refer_host_name) \
                .replace("{{CONFIG_CHECKSUM_SHA256}}", "")

            link_epg: str = findall(r"epg_url:.*'", response.text)[0].split("'")[1]

            headers["Referer"] = "/ur.anirtivaidem.reyalp//:sptth"[::-1]
            headers["Sec-Fetch-Dest"] = "empty"
            headers["Sec-Fetch-Mode"] = "cors"
            headers["Sec-Fetch-Site"] = "same-site"
            session = WebApiRequest(headers)
            players: dict = session.request_get(link_players).json()
            if one_link:
                return choice(players["hls"])
            else:
                epg: dict = session.request_get(link_epg).json()
                return {**players, **epg}

    @staticmethod
    def youtube_link(link: str) -> str:
        with yt_dlp.YoutubeDL({}) as ydl:
            for i in ydl.sanitize_info(ydl.extract_info(link, download=False))["formats"]:
                if i.get("fps") and i["fps"] and i.get("audio_channels") and i["audio_channels"] \
                        and i["format_note"] == "720p":
                    import xbmc
                    xbmc.log(msg=f'youtube: {i["url"]}', level=xbmc.LOGINFO)
                    return i["url"]


        # ydl = yt_dlp.YoutubeDL({})
        # data = ydl.sanitize_info(ydl.extract_info(link, download=False))
        # if data["is_live"]:
        #     if data.get("manifest_url"):
        #         return data["manifest_url"]
        #     else:
        #         return data["url"]
        # else:
        #     if data["requested_formats"][0].get("manifest_url"):
        #         return data["requested_formats"][0]["manifest_url"]
        #     else:
        #         return data["requested_formats"][0]["url"]


        # import httpx
        # import re
        # import json
        # r = httpx.Client().get(link).text
        # d = re.search(r'"streamingData".*"playbackTracking"', r)[0].strip('"streamingData": ').strip(
        #     ',"playbackTracking"')
        # j = json.loads(d)
        # from urllib.parse import unquote
        # m3u8 = "#EXTM3U"
        # m3u8_list = ""
        # for item in j["formats"]:
        #     video_bitrate: int = item["bitrate"]
        #     video_width: int = item["width"]
        #     video_height: int = item["height"]
        #     video_url: str = unquote(item["url"])
        #     video_codecs: str = re.search(r"codecs=.*", item["mimeType"])[0].strip("codecs=")
        #     m3u8_list += f'\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH={video_bitrate},CODECS={video_codecs},RESOLUTION={video_width}x{video_height}\n{video_url}'
        # # return m3u8 + m3u8_list
        # return "https://rr1---sn-wnj58pxag0-1p5e.googlevideo.com/videoplayback?expire=1698283795&ei=s2w5ZZ-uCNKOv_IPnr6h6Ak&ip=93.185.199.101&id=o-ANSRsf9eHWajVmd1f3OQ8Z3-wHVSVrvxKKfZAT3_YJRw&itag=248&aitags=133,134,135,136,137,160,242,243,244,247,248,278,394,395,396,397,398,399&source=youtube&requiressl=yes&mh=aB&mm=31,29&mn=sn-wnj58pxag0-1p5e,sn-n8v7kn7y&ms=au,rdu&mv=m&mvi=1&pl=20&initcwndbps=823750&spc=UWF9f85OSoZntfJEL7H3CIT7NvDQORVhrL9l8jOFvA&vprv=1&svpuc=1&mime=video/webm&ns=vSIfF_v7dMDRq4jc4h-bXpIP&gir=yes&clen=100515537&dur=850.067&lmt=1678259087707140&mt=1698261924&fvip=6&keepalive=yes&fexp=24007246&beids=24350018&c=WEB&txp=4535434&n=bEmNfz3_xXR9QXJkna&sparams=expire,ei,ip,id,aitags,source,requiressl,spc,vprv,svpuc,mime,ns,gir,clen,dur,lmt&sig=AGM4YrMwRQIhALfVT30tz8y-gmi9h_ARaKuiQtv77S98dKqAKd22tUUgAiBM2k034sG8zBSgnB-3kG6TSz_cvPqQe9cxs0dKWg-meQ==&lsparams=mh,mm,mn,ms,mv,mvi,pl,initcwndbps&lsig=AK1ks_kwRAIgBIA0hJlSsKIWwgpP8ABFWN9LnXljGR3ft8NbX8F-z5gCIDq8GYI4ytEh3r_S_ZpsmgvjhpGO4M5HTPb0Cz3Wxkd3"





