﻿import xbmc, xbmcgui
# xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=fixaddonupdate")')
# xbmc.sleep(5000)
xbmcgui.Dialog().notification("Database", "Addons33", icon='special://home/addons/plugin.program.downloader19/resources/media/database.webp', sound=False)
from updatervar import *
import db


def addon_database():
    db.addon_database(Database_Addons33, 1, True)

Database_Addons33 = [('repository.World', 'repository.World'),
                     ('repository.Worldolympic', 'repository.World'),
                     ('repository.Worldrepo', 'repository.World'),
                     ('repository.WorldNexus', 'repository.World'),
                     ('repository.WorldOmega', 'repository.World'),

                     ('plugin.switchback', 'repository.WorldNexus'),


                     ('script.module.youtube.dl', 'repository.World'),


                     ('plugin.program.downloaderstartup', 'repository.Worldolympic'),
                     ('skin.19MatrixWorld', 'repository.Worldolympic'),
                     ('plugin.program.myselect', 'repository.Worldolympic'),
                     ('plugin.program.simple.favourites', 'repository.Worldolympic'),
                     ('service.autoexec', 'repository.Worldolympic'),
                     ('service.subtitles.All_Subs', 'repository.Worldolympic'),
                     ('script.RealDebrid.vpn', 'repository.Worldolympic'),
                     ('plugin.video.duffyou', 'Worldolympic'),
                                       # scrubsv2
                     #('plugin.video.scrubsv2', 'repository.WorldNexus'),
                     ('plugin.video.scrubsv2', 'repository.jewrepo'),
                                          ###

                     ('script.embuary.info', 'repository.Worldolympic'),
                     #('plugin.video.watchnixtoons2', 'repository.Worldolympic'),

                     ('plugin.video.macvod', 'repository.Worldolympic'),
                     # ('plugin.video.rumble', 'repository.Worldolympic'),
                     ('plugin.video.scrapee', 'repository.Worldolympic'),
                     ('service.world.build', 'repository.Worldolympic'),


                     ('plugin.video.cristalazul', 'repository.World'),

                     ('script.kelebek', 'repository.World'),
                     ('script.luar', 'repository.World'),
                     ('plugin.video.stalker', 'repository.World'),

                     ('repository.oliver', 'repository.Worldrepo'),
                     # ('script.black.bars.never', 'repository.World'),
                     ('script.black.bars.never', 'repository.xbmc.org'),




                                        # resolveurl
                     ('script.module.resolveurl', 'repository.resolveurl'),




                                      # sportsdevil
                     ('plugin.video.sportsdevil', 'repository.World'),
                     ('script.module.streamlink', 'repository.World'),
                     ('script.module.pycountry', 'repository.World'),
                     ('script.module.isodate', 'repository.gkobu'),
                     # ('script.module.pysocks', 'repository.xbmc.org'),

                     # ('script.module.slproxy', 'repository.World'),
                     ('script.module.slproxy', 'repository.gujal'),




                                          # gkobu 

                     #('inputstream.adaptive', 'repository.gkobu'),
                     #('pvr.stalker', 'repository.gkobu'),

                     ('script.module.pysubs2', 'repository.gkobu'),


                     ('script.module.horus', 'repository.gkobu'),

                     # ('plugin.video.duffyou', 'repository.gkobu'),
                     ('plugin.video.f4mTester', 'repository.gkobu'),
                     ('script.video.F4mProxy', 'repository.gkobu'),
                     ('plugin.video.live.streamspro', 'repository.gkobu'),
                     ('plugin.video.lookmovietomb', 'repository.gkobu'),
                     ('plugin.video.fmoviesto', 'repository.gkobu'),
                     #('plugin.video.sporthdme', 'repository.gkobu'),

                     ('plugin.video.cartoonsgr', 'repository.gkobu'),

                     ('plugin.video.gratis', 'repository.gkobu'),
                     ('plugin.video.lookmovietomb', 'repository.gkobu'),
                     ('plugin.video.thetvapp', 'repository.gkobu'),
                     ('plugin.video.fen', 'repository.gkobu'),
                     ('service.subtitles.subsource-net', 'repository.gkobu'),
                     ('service.subtitles.subscene', 'repository.gkobu'),
                     ('service.subtitles.subdl-com', 'repository.gkobu'),
                     ('service.subtitles.a4ksubtitles', 'repository.gkobu'),

                     ('script.module.thetvdb', 'repository.gkobu'),
                     ('script.skin.helper.skinbackup', 'repository.gkobu'),
                     ('script.module.metadatautils', 'repository.gkobu'),
                     ('script.skin.helper.service', 'repository.gkobu'),
                     ('script.module.nemzzy', 'repository.gkobu'),


                                           # bugatsinho
                     #('plugin.video.cartoonsgr', 'repository.bugatsinho'),
                     ('plugin.video.sporthdme', 'repository.bugatsinho'),
                     ('script.module.t0mm0.common', 'repository.bugatsinho'),




                                           # twilight0
                     ('plugin.video.alphatv.gr', 'repository.twilight0'),
                     ('plugin.video.antenna.gr', 'repository.twilight0'),
                     ('plugin.video.fashiontv.com', 'repository.twilight0'),
                     ('plugin.video.skai.gr', 'repository.twilight0'),
                     ('plugin.video.star.gr', 'repository.twilight0'),




                                           # autowidget 
                     ('plugin.program.autowidget', 'repository.autowidget'),
                     ('repository.autowidget', 'repository.autowidget'),


                                           # zeltorix'
                     ('repository.zeltorix', 'repository.zeltorix'),
                     ('plugin.video.zeltorix.worldcams.tv', 'repository.zeltorix'),
                     ('script.module.zeltorix.packages', 'repository.zeltorix'),
                     ('script.module.zeltorix.utilitys', 'repository.zeltorix'),
                     #('script.module.zeltorix.utilitys', 'repository.World'),



                                        # jurialmunkey
                     ('script.module.infotagger', 'repository.jurialmunkey'),


                                          # inputstreamhelper
                     ('script.module.inputstreamhelper', 'repository.xbmc.org'),
                     # ('script.module.inputstreamhelper', 'repository.aliunde'),
                     #('script.module.inputstreamhelper', 'repository.slyguy.inputstreamhelper'),

                     # ('repository.slyguy.inputstreamhelper', 'repository.slyguy'),



                                          #youtube
                     # ('plugin.video.youtube', 'repository.redwizard'),
                     ('plugin.video.youtube', 'repository.gkobu'),
                     #('plugin.video.youtube', 'repository.xbmc.org'),
                     # ('plugin.video.youtube', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     # ('plugin.video.youtube', 'repository.cMaNWizard'),



                                         # xbmc.org

                     ('inputstream.adaptive', 'repository.xbmc.org'),
                     ('inputstream.ffmpegdirect', 'repository.xbmc.org'),
                     ('inputstream.rtmp', 'repository.xbmc.org'),
                     ('vfs.libarchive', 'repository.xbmc.org'),
                     ('vfs.rar.inputstreamhelper', 'repository.xbmc.org'),
                     ('vfs.sftp', 'repository.xbmc.org'),

                     #('script.module.infotagger', 'repository.xbmc.org')

                     #('pvr.stalker', 'repository.xbmc.org'),


                     ('peripheral.joystick', 'repository.xbmc.org'),
                     # ('peripheral.joystick', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.module.requests', 'repository.xbmc.org'),
                     ('script.module.pyqrcode', 'repository.xbmc.org'),
                     ('inputstream.adaptive', 'repository.xbmc.org'),
                     ('pvr.stalker', 'repository.xbmc.org'),
                     
                     ('script.module.simplejson ', 'repository.xbmc.org'),


                     ('script.module.dateutil', 'repository.xbmc.org'),

                     ('plugin.audio.radio_de', 'repository.xbmc.org'),
                     ('weather.gismeteo', 'repository.xbmc.org'),

                     ('script.module.myconnpy', 'repository.xbmc.org'),
                     ('script.module.clouddrive.common', 'repository.xbmc.org'),
                     ('metadata.themoviedb.org.python', 'repository.xbmc.org'),


                     ('script.module.htmlement', 'repository.xbmc.org'),
                     ('script.module.pysocks', 'repository.xbmc.org'),
                     ('script.module.idna', 'repository.xbmc.org'),
                     ('script.module.beautifulsoup4', 'repository.xbmc.org'),
                     ('script.module.certifi', 'repository.xbmc.org'),
                     ('script.module.chardet', 'repository.xbmc.org'),

                     ('script.module.codequick', 'repository.xbmc.org'),
                     ('script.module.pyparsing', 'repository.xbmc.org'),
                     

                     ('script.module.simplejson', 'repository.xbmc.org'),
                     ('script.module.six', 'repository.xbmc.org'),
                     ('script.module.soupsieve', 'repository.xbmc.org'),
                     ('script.module.urllib3', 'repository.xbmc.org'),
                     ('script.module.websocket', 'repository.xbmc.org'),
                     ('script.module.requests-toolbelt', 'repository.xbmc.org'),

                     ('script.module.unidecode', 'repository.xbmc.org'),
                     # ('script.module.youtube.dl', 'repository.xbmc.org'),

                     # ('resource.images.studios.white', 'repository.xbmc.org'),




                                        # kentestvn   NEW
                     ('kentestvn', 'kentestvn'),
                     # ('script.module.requests', 'kentestvn'),
                     # ('script.module.urllib3', 'kentestvn'),
                     # ('script.module.six', 'kentestvn'),
                     # ('script.module.pysocks', 'kentestvn'),
                     # ('script.module.chardet', 'kentestvn'),
                     # ('script.module.certifi', 'kentestvn'),
                     # ('script.module.bottle', 'kentestvn'),
                     # ('kentestvn', 'kentestvn'),
                     # ('kentestvn', 'kentestvn'),
                     




                                       # vnmedia off #
                     ('plugin.video.vnmedia', 'repository.WorldOmega'),
                     # ('plugin.video.vnmedia', 'repovnmedia'),
                     ('repovnmedia', 'repovnmedia'),

                     #  ('script.module.dateutil', 'repovnmedia'),          23.910.0     @@@@@@

                     # ('script.module.htmlement', 'repovnmedia'),          2.0.0
                     # ('script.module.pysocks', 'repovnmedia'),            1.7.1
                     # ('script.module.idna', 'repovnmedia'),               3.7
                     # ('script.module.infotagger', 'repovnmedia')          0.0.8
                     # ('script.module.beautifulsoup4', 'repovnmedia'),     4.12.3
                     # ('script.module.certifi', 'repovnmedia'),            2024.07.04
                     # ('script.module.chardet', 'repovnmedia'),            5.2.0
                     #  ('script.module.clouddrive.common', 'repovnmedia'), 1.4.0
                     # ('script.module.cloudscraperkd', 'repovnmedia'),     1.271
                     # ('script.module.codequick', 'repovnmedia'),          1.2.0
                     # ('script.module.dateutil', 'repovnmedia'),           2.82
                     # ('script.module.pyparsing', 'repovnmedia'),          3.1.2

                     # ('script.module.pycryptodome', 'repovnmedia'),       3.4.3     @@@@@@

                     # ('script.module.simplejson', 'repovnmedia'),
                     # ('script.module.six', 'repovnmedia'),                1.16.0
                     # ('script.module.soupsieve', 'repovnmedia'),          2.2.5
                     # ('script.module.urllib3', 'repovnmedia'),            2.2.2 
                     # ('script.module.websocket', 'repovnmedia'),
                     # ('script.module.requests-toolbelt', 'repovnmedia'),  1.0.0


                     #('script.module.pyqrcode', 'repovnmedia'),            1.2.1.4
                     #('script.module.requests', 'repovnmedia'),            2.32.3


                                    #kentestvn off #
                     ('plugin.video.90phuttv', 'kodivietnam'),
                     ('kodivietnam', 'kodivietnam'),


                     # ('script.module.htmlement', 'kodivietnam'),
                     # ('script.module.pysocks', 'kodivietnam'),
                     # ('script.module.idna', 'kodivietnam'),               3.6
                     # ('script.module.infotagger', 'kodivietnam')          0.0.8
                     # ('script.module.beautifulsoup4', 'kodivietnam'),     4.12.3
                     # ('script.module.certifi', 'kodivietnam'),            2024.02.02
                     # ('script.module.chardet', 'kodivietnam'),            5.2.0
                     #  ('script.module.clouddrive.common', 'kodivietnam'), 1.4.0
                     # ('script.module.cloudscraperkd', 'kodivietnam'),
                     # ('script.module.codequick', 'kodivietnam'),
                     # ('script.module.dateutil', 'kodivietnam'),           2.82
                     # ('script.module.pyparsing', 'kodivietnam'),
                     

                     # ('script.module.simplejson', 'kodivietnam'),
                     # ('script.module.six', 'kodivietnam'),                1.16.0
                     # ('script.module.soupsieve', 'kodivietnam'),          2.2.5
                     # ('script.module.urllib3', 'kodivietnam'),            2.2.1
                     # ('script.module.websocket', 'kodivietnam'),
                     # ('script.module.requests-toolbelt', 'kodivietnam')



                     #('script.module.pyqrcode', 'kodivietnam'),
                     #('script.module.requests', 'kodivietnam'),            2.32.1



                             # arrownegra  -  repository.dregs
                     #('repository.arrownegra', 'repository.arrownegra'),
                     #('repository.dregs', 'repository.dregs),

                     ('plugin.video.aguia_de_ouro', 'repository.dregs'),
                     ('plugin.video.fenix-mac', 'repository.dregs'),

                     ('repository.arrownegra', 'repository.Worldrepo'),
                     ('repository.dregs', 'repository.Worldrepo'),



                                    # RD account  //  709
                     ('repository.709', 'repository.709'),
                     ('script.module.accountmgr', 'repository.709'),
                     ('script.module.acctview', 'repository.709'),



                                           # daddylive
                     ('plugin.video.daddylive', 'repository.Worldolympic'),
                     #('plugin.video.daddylive', 'repository.thecrew'),
                     #('plugin.video.daddylive', 'repository.aliunde'),
                     #('plugin.video.daddylive', 'repository.dexe'),



                                         # Netflix
                     ('repository.castagnait', 'repository.castagnait'),
                     ('plugin.video.netflix', 'repository.castagnait'),

                                         # funstersplace
                     ('plugin.video.gratis', 'repository.gkobu'),
                     ('repository.funstersplace', 'repository.funstersplace'),


                                         # dexe
                     ('repository.roooar', 'repository.roooar'),
                     #('repository.dexe', 'repository.roooar'),
                     ('plugin.video.BauBauVavoo', 'repository.dexe'),
                     ('plugin.video.GreenKlikPremium', 'repository.dexe'),

                     #('plugin.video.fen', 'repository.dexe'),
                     # ('repository.dexe', 'Worldrepo'),
                     ('repository.dexe', 'repository.dexe'),

                     ('plugin.video.free99', 'repository.dexe'),
                     ('script.free99.artwork', 'repository.dexe'),
                     ('plugin.video.playlistbee', 'repository.dexe'),


                                         # diggz
                     ('repository.diggz', 'repository.diggz'),
                     #('plugin.video.free99', 'repository.diggz'),
                     #('script.free99.artwork', 'repository.diggz'),


                                         # cMaNWizard
                     ('repository.cMaNWizard', 'repository.cMaNWizard'),
                     ('plugin.video.quicksilver', 'repository.cMaNWizard'),
                     ('script.module.quicksilverscrapers', 'repository.cMaNWizard'),
                     ('script.quicksilver.artwork', 'repository.cMaNWizard'),

                                        # homelander
                     ('repository.chainsrepo', 'repository.chainsrepo'),
                     ('plugin.video.homelander', 'repository.chainsrepo'),
                     ('script.module.homelanderscrapers', 'repository.chainsrepo'),
                     ('script.homelander.artwork', 'repository.chainsrepo'),


                                             # gigoro33-addon
                     ('repository.gigoro33-addon', 'repository.World'),
                     ('plugin.video.latinsports', 'repository.gigoro33-addon'),


                                             # REST
                     ('script.module.jetextractors', 'repository.loop'),

                     ('plugin.video.torquelite', 'repository.gearheads2'),

                     ('repository.KODIvertiDO_TEAM', 'repository.KODIvertiDO_TEAM'),
                     # ('plugin.video.KODIvertiDO', 'repository.KODIvertiDO_TEAM'),
                     ('plugin.video.KODIvertiDO', 'repository.World'),

                     ('plugin.video.vavooto', 'repository.michaz'),

                     ('repository.jellyfin.kodi', 'repository.jellyfin.kodi'),

                     ('plugin.video.thethunder', 'One.repo'),

                     ('repository.alado.tv', 'repository.Worldrepo'),
                     # ('repository.alado.tv', 'repository.alado.tv'),
                     ('plugin.video.train.mac.again', 'repository.alado.tv'),

                     ('repository.cocoscrapers', 'repository.cocoscrapers'),
                     ('script.module.cocoscrapers', 'repository.cocoscrapers'),

                     ('repository.lekma', 'repository.lekma'),
                     # ('plugin.video.invidious', 'repository.lekma'),

                     ('repository.rays.files', 'repository.rays.files'),

                     ('repository.Parrot', 'repository.Parrot'),

                     ('repository.subskip', 'repository.subskip'),


                     ('repository.kodifitzwell', 'repository.kodifitzwell'),
                     ('repository.azzyaddons', 'repository.azzyaddons'),
                     ('plugin.video.rumble', 'repository.azzyaddons'),


                     ('repository.animaniac', 'repository.animaniac'),
                     ('plugin.video.watchnixtoons2', 'repository.animaniac'),
                     
                     ('repository.madforit', 'repository.madforit'),



                     ('repository.LostSoul', 'repository.LostSoul'),
                     ('repository.redwizard', 'repository.redwizard'),
                     ('repository.NarcacistWizard', 'repository.Worldrepo'),
                     
                     ('repository.lattsrepo', 'repository.lattsrepo'),
                     ('resource.images.studios.white', 'repository.lattsrepo'),
                     # ('script.module.thetvdb', 'repository.lattsrepo'), --->    repository.gkobu



                     ('plugin.video.jetproxy', 'repository.loop'),

                     ('plugin.audio.radio_de_light', 'repository.kodinerds'),
                     ('plugin.video.playlistloader', 'repository.kodinerds'),



                     ('skin.xonfluence', 'hellyrepo.kodi')


                     ]


addon_database()

xbmcgui.Dialog().notification("Database", "[COLOR cornflowerblue]Addons33[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/database.webp', sound=False)
xbmc.sleep(1000)
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"addons.updatemode","value":0}}')
# xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')
# xbmcgui.Dialog().notification("Add-ons Updates...", "[COLOR green]ON[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/auto4.png', sound=False)
# xbmc.sleep(20000)
# xbmc.executebuiltin('UpdateLocalAddons()')
# xbmc.executebuiltin('UpdateAddonRepos()')
# xbmc.executebuiltin('ActivateWindow(AddonBrowser)')
