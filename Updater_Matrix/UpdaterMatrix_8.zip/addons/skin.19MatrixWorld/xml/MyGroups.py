﻿import xbmc

def MyGroups():
    xbmc.executebuiltin("ActivateWindow(Home)")
    xbmc.sleep(2000)
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(2000)
    xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.program.autowidget/?mode=group&refresh&reload,return)")

MyGroups()
