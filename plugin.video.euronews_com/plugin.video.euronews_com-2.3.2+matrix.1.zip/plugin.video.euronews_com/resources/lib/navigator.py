﻿# -*- coding: utf-8 -*-

from .common import *


if not xbmcvfs.exists(os.path.join(dataPath, 'settings.xml')):
	xbmcvfs.mkdirs(dataPath)
	xbmc.executebuiltin(f"Addon.OpenSettings({addon_id})")

def mainMenu():
	debug_MS("(navigator.mainMenu) -------------------------------------------------- START = mainMenu --------------------------------------------------")
	debug_MS(f"(navigator.mainMenu) ### BASE_URL = {BASE_URL} ###")
	FETCH_UNO = create_entries({'Title': translation(30607), 'Genre': 'Breaking News'})
	addDir({'mode': 'listTimeline', 'url': f"{BASE_DROID}/pages/timeline"}, FETCH_UNO)
	UNWANTED, (COMBI_SINGLE, COMBI_FIRST) = ['livingit', 'joboffers', '/paidpost', 'partner', 'service', '/tag', '/video'], ([] for _ in range(2))
	RESULTS = getUrl(f"{BASE_URL}/video", method='LOAD', RFE=f"{BASE_URL}/", TYPE='text/html; charset=utf-8', ORG=BASE_URL)
	CONTENT = fr"\{RESULTS}"
	DATA_ONE = re.findall(r'''<div id=["']adb-header-mainnav-2-sidebar["'](.*?)<span class=["']c-navigation-bar__link["']>''', CONTENT, re.S)
	for chtml in DATA_ONE:
		part = chtml.split('class="c-navigation-bar__linkandchevron"')
		for i in range(1 ,len(part), 1):
			entry = part[i]# <a class="c-navigation-bar__link" href="//de.euronews.com/my-europe" aria-label="Read more about My Europe">My Europe</a>
			ARTICLES = re.compile(r'''class=["']c-navigation-bar__link["'] href=["']([^"']*)["'] aria-label=[^>]*>(.*?)</a>''', re.S).findall(entry)
			for LINK, NAME in ARTICLES:
				NAME = cleaning(NAME.replace('\n', ''))
				if LINK and any(rs in LINK.lower() for rs in UNWANTED): continue
				debug_MS(f"(navigator.mainMenu[1]) ##### TITLE : {NAME} || URL : {LINK} || ARTICLES_CONTENT : {entry} #####")
				debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
				COMBI_SINGLE.append(NAME.lower())
				COMBI_FIRST.append([NAME, LINK, entry])
	if COMBI_FIRST:
		for title_one, news_one, elem in COMBI_FIRST:
			FETCH_DUE = create_entries({'Title': f"[B]{title_one}[/B]", 'Genre': title_one})
			addDir({'mode': 'SubTopics', 'url': f"{elem}</ul></div>", 'extras': news_one}, FETCH_DUE)
	DATA_TWO = re.compile(r'''<div class=["']c-navigation-bar__linkandchevron["']>\s*<span class=["']c-navigation-bar__link["']>(.*?)</ul></div>''', re.S).findall(CONTENT)
	if DATA_TWO:
		SUBART = re.compile(r'''<div class=["']c-navigation-bar__subitem__title["']>([^<]*)<''', re.S).findall(DATA_TWO[0])
		title_two = cleaning(SUBART[0].replace('\n', ''))
		if title_two.lower() not in COMBI_SINGLE:
			FETCH_TRE = create_entries({'Title': f"[B]{title_two}[/B]", 'Genre': title_two})
			addDir({'mode': 'SubTopics', 'url': f"{DATA_TWO[0]}</ul></div>"}, FETCH_TRE)
			debug_MS(f"(navigator.mainMenu[2]) ##### TITLE : {title_two} || REST_CONTENT : {DATA_TWO[0]} #####")
	FETCH_QUAT = create_entries({'Title': translation(30608), 'Image': f"{artpic}livestream.png"})
	addDir({'mode': 'playLIVE'}, FETCH_QUAT, folder=False)
	if enableADJUSTMENT:
		FETCH_CINQ = create_entries({'Title': translation(30609), 'Image': f"{artpic}settings.png"})
		addDir({'mode': 'aConfigs'}, FETCH_CINQ, folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def SubTopics(COMPACT, PHRASE):
	debug_MS("(navigator.SubTopics) -------------------------------------------------- START = SubTopics --------------------------------------------------")
	debug_MS(f"(navigator.SubTopics) ### COMPACT_LIST = {COMPACT} ### PHRASE = {PHRASE} ###")
	UNWANTED, UNIKAT = ['livingit', 'joboffers', '/paidpost', 'partner', 'service', '/tag', '/video'], set()
	DATA_ONE = re.findall(r'''<div class=["']c-navigation-bar__subitem c-links-list[^>]*>(.*?)</ul></div>''', COMPACT, re.S)
	for chtml in DATA_ONE: # START === <div class="c-navigation-bar__subitem c-links-list"> +++ ENDE === </ul></div>
		if PHRASE not in ['', 'None', None]: # HEADLINE === <div class="c-navigation-bar__subitem__title">Programme</div>
			HEADLINES = re.compile(r'''<div class=["']c-navigation-bar__subitem__title["']>([^<]*)<''', re.S).findall(chtml)
			for HEAD in HEADLINES:
				FETCH_DUE = create_entries({'Title': f"[B][COLOR lime]≡ ≡ ≡ {HEAD} ≡ ≡ ≡[/COLOR][/B]"})
				addDir({'mode': 'blankFUNC', 'url': '00'}, FETCH_DUE, folder=False)
				debug_MS(f"(navigator.SubTopics[1]) >>>>> MAIN_CATEGORY : {HEAD} >>>>>")
		ENTRIES = re.compile(r'''<a href=["']([^"']*)["'].*?links-list__link[^>]*>(.*?)</a>''', re.S).findall(chtml)
		for LINK, NAME in ENTRIES: # URL+CATEGORY === <a href="//de.euronews.com/my-europe/meine-europa-serie" class="c-links-list__link" aria-label="Read more about Meine Europa-Serie">Meine Europa-Serie</a>
			if LINK in UNIKAT or any(ts in LINK.lower() for ts in UNWANTED):
				continue
			UNIKAT.add(LINK)
			NAME = cleaning(NAME.replace('\n', ''))
			FETCH_TRE = create_entries({'Title': NAME, 'Genre': NAME})
			addDir({'mode': 'listVideos', 'url': LINK, 'extras': NAME}, FETCH_TRE)
			debug_MS(f"(navigator.SubTopics[2]) ##### SUB_CATEGORY : {NAME} || URL : {LINK} #####")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVideos(TARGET, CAT):
	debug_MS("(navigator.listVideos) -------------------------------------------------- START = listVideos --------------------------------------------------")
	debug_MS(f"(navigator.listVideos) ### START_URL = {TARGET} ### CATEGORY = {CAT} ###")
	SEND = {}
	(COMBI_EPISODE, SEND['videos']), UNIKAT, FOUND, API_DETECT = ([] for _ in range(2)), set(), 0, False
	URL_ONE = TARGET if TARGET.startswith('http') else f"https:{TARGET}" if TARGET.startswith('//') else BASE_URL+TARGET
	RESULT_ONE = getUrl(URL_ONE, method='LOAD', RFE=f"{BASE_URL}/", TYPE='text/html; charset=utf-8', ORG=BASE_URL) # https://de.euronews.com/internal/program/state-of-the-union?before=1519998565&extra=1&offset=13
	CONTENT = fr"\{RESULT_ONE}"
	MATCH = re.findall(r'data-api-url="([^"]+)"', CONTENT, re.S)
	if MATCH: API_LINK, API_DETECT = MATCH[-1], True
	elif not MATCH and TARGET.count('/') > 0: # WELT -> No Comment (url='/nocomment'/) + Euronews Witness (url='/programme/euronews-witness') === KEINE 'data-api-url' vorhanden !
		API_LINK, API_DETECT = f"{BASE_URL}/internal/program/{TARGET.split('/')[-1]}", True # NEW-JSON-FORMAT === https://de.euronews.com/internal/program/nocomment?extra=1
	if API_DETECT:
		URL_TWO = f"https:{API_LINK}?extra=1&offset=0&limit=70" if API_LINK.startswith('//') else f"{API_LINK}?extra=1"
		debug_MS(f"(navigator.listVideos[1]) ### URL_TWO : {URL_TWO} ###")
		RESULT_TWO = getUrl(URL_TWO, RFE=f"{BASE_URL}/", TYPE='application/json; charset=utf-8', ORG=BASE_URL)
		DATA = RESULT_TWO['articles'] if isinstance(RESULT_TWO, (dict, list)) and RESULT_TWO.get('articles', '') else RESULT_TWO if isinstance(RESULT_TWO, (dict, list)) else []
		for article in DATA:
			photo, Note_1, Note_2 = ("" for _ in range(3))
			startTIMES, aired, begins, duration, EURO_LINK, YOU_LINK = (None for _ in range(6))
			if isinstance(article, str):
				article = DATA[article]
			article = article['data'] if article.get('data', '') else article
			if len(article) == 0: continue
			debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
			debug_MS(f"(navigator.listVideos[2]) xxxxx ARTICLE-02 : {article} xxxxx")
			episID = str(article['id']).replace('article-', '').replace('header-', '').strip() if article.get('id', '') else '00'
			if episID in UNIKAT:
				continue
			UNIKAT.add(episID)
			name = cleaning(article['title'])
			if article.get('images', '') and article.get('images', {})[0].get('url', ''):
				photo = article['images'][0]['url'].replace('{{w}}x{{h}}', '1280x720') # OLD = 861x485
			if str(article.get('publishedAt')).isdecimal():
				CIPHER = datetime(1970,1,1) + timedelta(seconds=TGM(time.localtime(article['publishedAt'])))
				startTIMES = CIPHER.strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('-', '•', ':')
				aired = CIPHER.strftime('%d{0}%m{0}%Y').format('.') # FirstAired
				begins = CIPHER.strftime('%d{0}%m{0}%Y').format('.') # 09.03.2023 / OLDFORMAT
				if KODI_ov20:
					begins = CIPHER.strftime('%Y{0}%m{0}%dT%H{1}%M').format('-', ':') # 2023-03-09T12:30:00 / NEWFORMAT
			if startTIMES: Note_1 = translation(30610).format(startTIMES)
			Note_2 = cleaning(article.get('leadin', ''))
			if article.get('videos', '') and len(article['videos']) > 0:
				if 'duration' in str(article['videos']):
					duration = [int(vid.get('duration', [])) // 1000 for vid in article.get('videos', {})][-1]
				if 'url' in str(article['videos']):
					EURO_LINK = [vid.get('url', []) for vid in article.get('videos', {})][-1]
			if article.get('externalPartners', '') and article['externalPartners'].get('youtubeId', ''):
				YOU_LINK = article['externalPartners']['youtubeId']
			if EURO_LINK is None and YOU_LINK is None:
				continue
			FOUND += 1
			debug_MS(f"(navigator.listVideos[3]) ##### TITLE : {name} || THUMB : {photo} #####")
			debug_MS(f"(navigator.listVideos[3]) ##### YoutubeID : {YOU_LINK} || VIDEO : {EURO_LINK} || BEGINS : {begins} #####")
			FETCH_UNO = create_entries({'Title': name, 'Plot': Note_1+Note_2, 'Genre': CAT, 'Duration': duration,\
				'Date': begins, 'Aired': aired, 'Mediatype': 'movie', 'Image': photo, 'Reference': 'Single'})
			addDir({'mode': 'playCODE', 'IDENTiTY': episID}, FETCH_UNO, folder=False)
			SEND['videos'].append({'filter': episID, 'name': name, 'directLINK': EURO_LINK, 'youtubeID': YOU_LINK})
		with open(WORKFILE, 'w') as ground:
			json.dump(SEND, ground, indent=4, sort_keys=True)
	if FOUND == 0:
		debug_MS("(navigator.listVideos) ##### Keine VIDEO-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30525).format('Videos'), translation(30526).format(str(CAT)), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def listTimeline(TARGET):
	debug_MS("(navigator.listTimeline) ------------------------------------------------ START = listTimeline -----------------------------------------------")
	debug_MS(f"(navigator.listTimeline) ### START_URL = {TARGET} ###")
	SEND, counter = {}, 0
	COMBI_FIRST, COMBI_LINKS, COMBI_SECOND, COMBI_THIRD, SEND['videos'] = ([] for _ in range(5))
	DATA_ONE = getUrl(TARGET, TYPE='application/json; charset=utf-8', MLT=True)
	MERGING = [DATA_ONE]
	if DATA_ONE.get('pagination', '') and DATA_ONE['pagination'].get('next', '') and DATA_ONE['pagination']['next'].get('url', ''):
		if DATA_ONE['pagination']['next']['url'].startswith('/pages/timeline') and DATA_ONE['pagination']['next']['url'].endswith('slide=2'):
			debug_MS(f"(navigator.listTimeline) PAGES ### Now show NextPage : {BASE_DROID+DATA_ONE['pagination']['next']['url']} ### FOUND")
			DATA_TWO = getUrl(f"{BASE_DROID}{DATA_ONE['pagination']['next']['url']}", TYPE='application/json; charset=utf-8', MLT=True)
			MERGING += [DATA_TWO]
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listTimeline[1]) XXXXX CONTENT-01 : {MERGING} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	for each in MERGING:
		for item in each.get('pageContent', []):
			if item.get('type', '') == 'justin' and item.get('content', '') and len(item['content']) > 0:
				for article in item.get('content', []):
					debug_MS(f"(navigator.listTimeline[2]) xxxxx ITEM-02 : {article} xxxxx")
					debug_MS("---------------------------------------------")
					THUMB_1, NOTE_1 = ("" for _ in range(2))
					startTIMES_1, AIRED_1, BEGINS_1 = (None for _ in range(3))
					counter += 1
					episID_1 = str(article['id']).replace('article-', '').replace('header-', '').strip() if article.get('id', '') else '00'
					TITLE_1 = cleaning(article['title'])
					if article.get('image', '') and article['image'].get('url', ''):
						THUMB_1 = article['image']['url'].replace('{{w}}x{{h}}', '1280x720') # OLD = 861x485
					if str(article.get('uts')).isdecimal():
						CIPHER = datetime(1970,1,1) + timedelta(seconds=TGM(time.localtime(article['uts'])))
						startTIMES_1 = CIPHER.strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('-', '•', ':')
						AIRED_1 = CIPHER.strftime('%d{0}%m{0}%Y').format('.') # FirstAired
						BEGINS_1 = CIPHER.strftime('%d{0}%m{0}%Y').format('.') # 09.03.2023 / OLDFORMAT
						if KODI_ov20:
							BEGINS_1 = CIPHER.strftime('%Y{0}%m{0}%dT%H{1}%M').format('-', ':') # 2023-03-09T12:30:00 / NEWFORMAT
					if startTIMES_1: NOTE_1 = translation(30610).format(startTIMES_1)
					SHOWVIDEO_1 = article.get('showVideo', False)
					COMBI_FIRST.append([int(counter), episID_1, TITLE_1, THUMB_1, BEGINS_1, AIRED_1, NOTE_1, SHOWVIDEO_1])
					if article.get('link', '') and article['link'].get('url', ''):
						COMBI_LINKS.append([int(counter), f"{BASE_DROID}{article['link']['url']}"])
	if COMBI_FIRST:
		COMBI_SECOND = getMultiData(COMBI_LINKS)
		if COMBI_SECOND:
			DATA_DETAILS = json.loads(COMBI_SECOND)
			#log("++++++++++++++++++++++++")
			#log(f"(navigator.listTimeline[3]) XXXXX CONTENT-03 : {DATA_DETAILS} XXXXX")
			#log("++++++++++++++++++++++++")
			for elem in DATA_DETAILS:
				if elem is not None and elem.get('pageContent', '') and elem.get('pageContent', {})[0].get('content', ''):
					(THUMB_2, DESC_1, DESC_2), METER_2 = ("" for _ in range(3)), elem['Position']
					TAGLINE_2, DURATION_2, PLAYLINK_2 = (None for _ in range(3))
					debug_MS("---------------------------------------------")
					debug_MS(f"(navigator.listTimeline[3]) xxxxx ELEM-03 : {elem} xxxxx")
					SHORT = elem['pageContent'][0]['content'][0]
					LONGER = elem['pageContent'][2]['content'][0] if len(elem['pageContent']) > 2 and elem.get('pageContent', {})[2].get('content', '') else None
					markID_2 = str(SHORT['id']).replace('article-', '').replace('header-', '').strip() if SHORT.get('id', '') else '00'
					DESC_1 = SHORT.get('summary', '')
					if SHORT.get('image', '') and SHORT['image'].get('url', ''):
						THUMB_2 = SHORT['image']['url'].replace('{{w}}x{{h}}', '1280x720') # OLD = 861x485
					if VIDEO_METAS is True and LONGER and LONGER.get('text', ''):
						TAG_2 = re.compile(r'</style></head>.+?<h2>(.*?)</h2>', re.S).findall(LONGER['text'])
						TAGLINE_2 = cleaning(TAG_2[0]) if TAG_2 else None
						TAGLINE_2 = TAGLINE_2[:125]+'...' if TAGLINE_2 and len(TAGLINE_2) > 125 else TAGLINE_2
						STORY_2 = re.findall(r'<p[^>]*>(.*?)</p>', LONGER['text'], re.S)
						DESC_2 = '[CR]'.join([cleaning(sto) for sto in STORY_2]) if STORY_2 and len(STORY_2[0]) > 10 else ""
					if SHORT.get('video', ''):
						if elem.get('tracking', '') and elem['tracking'].get('adobe', '') and elem['tracking']['adobe'].get('customParams', ''):
							for entry in elem['tracking']['adobe']['customParams']:
								if 'videoduration' in entry.get('key', '') and str(entry.get('value')).isdecimal():
									DURATION_2 = int(entry['value']) # Wird in Sekunden angezeigt
						YTID_2 = SHORT['video'].get('id', None)
						PLAYLINK_2 = (SHORT['video'].get('videoFallback', {}).get('url', '') or SHORT['video'].get('url', ''))
						COMBI_THIRD.append([markID_2, THUMB_2, DESC_1, DESC_2, TAGLINE_2, DURATION_2, YTID_2, PLAYLINK_2])
	if COMBI_THIRD:
		RESULT = [a + b for a in COMBI_FIRST for b in COMBI_THIRD if a[1] == b[0]] # Zusammenführung von Liste1 und Liste2 - wenn die ID überein stimmt !!!
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.listTimeline[4]) XXXXX RESULT-04 : {RESULT} XXXXX")
		for da in sorted(RESULT, key=lambda cr: int(cr[0])): # 0-7 = Liste1 || 8-15 = Liste2
			debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
			debug_MS(f"(navigator.listTimeline[4]) ### Anzahl = {str(len(da))} || Eintrag : {da} ###")
			episID, name, Photo1, begins, aired, Note_1, showVID = da[1], da[2], da[3], da[4], da[5], da[6], da[7]
			markID, Photo2, Desc1, Desc2, tagline, duration, YOU_LINK, EURO_LINK = da[8], da[9], da[10], da[11], da[12], da[13], da[14], da[15]
			thumb = Photo2 if Photo2 != "" else Photo1
			FULL_DESC = Desc2 if len(Desc2) > len(Desc1) else Desc1
			plot = Note_1+FULL_DESC
			debug_MS(f"(navigator.listTimeline[5]) ##### TITLE : {name} || THUMB : {thumb} #####")
			debug_MS(f"(navigator.listTimeline[5]) ##### showVID : {showVID} || YoutubeID : {YOU_LINK} || VIDEO : {EURO_LINK} || BEGINS : {begins} #####")
			if showVID is True and EURO_LINK:
				FETCH_UNO = create_entries({'Title': name, 'Tagline': tagline, 'Plot': plot, 'Genre': 'Breaking News', 'Duration': duration,\
					'Date': begins, 'Aired': aired, 'Mediatype': 'movie', 'Image': thumb, 'Reference': 'Single'})
				addDir({'mode': 'playCODE', 'IDENTiTY': episID}, FETCH_UNO, folder=False)
				SEND['videos'].append({'filter': episID, 'name': name, 'directLINK': EURO_LINK, 'youtubeID': YOU_LINK})
		with open(WORKFILE, 'w') as ground:
			json.dump(SEND, ground, indent=4, sort_keys=True)
	else:
		debug_MS("(navigator.listTimeline[2]) ##### Keine TIMELINE-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30525).format('Videos'), translation(30526).format('NEWS – TICKER'), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def YouGetVideo(CODE):
	END_URL, MARK = (None for _ in range(2))
	TEST_URL = getUrl(f"https://www.youtube.com/oembed?format=json&url=http://www.youtube.com/watch?v={CODE}", method='TRACK', timeout=15)
	if TEST_URL.status_code in [200, 201, 202] and re.search(r'''["']provider_url["']:["']https://www.youtube.com/["']''', TEST_URL.text):
		END_URL, MARK = f"plugin://plugin.video.youtube/play/?video_id={CODE}", 'YOUTUBE'
	return (END_URL, MARK)

def playLIVE():
	debug_MS("(navigator.playLIVE) -------------------------------------------------- START = playLIVE --------------------------------------------------")
	LIVE_URL, STREAM, EURO_SIGN, YOUT_SIGN, YOUT_CIPHER = (False for _ in range(5))
	CHECK_ONE = getUrl(f"{BASE_DROID.replace('/tr', '/de')}/livestream/{SHORTS_DROID.replace('tr', 'de')}", method='TRACK', TYPE='application/json; charset=utf-8', MLT=True)
	if CHECK_ONE.status_code in [200, 201, 202]: # Available Languages: en, fr, de, it, es, pt, ru, gr, hu / Turkish in german - the rest in English
		ORIG_ONE = re.compile(r'''["']primary["']:["']([^"']*)["']''', re.S).findall(CHECK_ONE.text)
		ORIG_TWO = re.compile(r'''["']backup["']:["']([^"']*)["']''', re.S).findall(CHECK_ONE.text)
		EURO_SIGN = ORIG_ONE[0] if ORIG_ONE else ORIG_TWO[0] if ORIG_TWO else False
		if EURO_SIGN:
			debug_MS(f"(navigator.playLIVE[1]) ***** EURONEWS-DIRECT-STREAM FOUND : {EURO_SIGN} *****")
			LIVE_URL, STREAM = EURO_SIGN, 'DIRECT'
		else: log("(navigator.playLIVE[1]) XXXXX !!! EURONEWS-DIRECT-STREAM NOT FOUND - ACTION NOT SUCCESSFUL - SKIP !!! XXXXX")
	if not EURO_SIGN: # Available Languages: en, fr, de, it, es, pt, ru, el, hu / Turkish in german - the rest in English
		CHECK_TWO = getUrl(f"https://www.euronews.com/api/live/data?locale={SHORTS_DROID.replace('gr', 'el').replace('pe', 'fa').replace('tr', 'de')}", method='TRACK')
		if CHECK_TWO.status_code in [200, 201, 202]: # https://www.euronews.com/api/live/data?locale=en
			NUMERALS = re.compile(r'''["']videoId["']:["']([^"']*)["']''', re.S).findall(CHECK_TWO.text)
			YOUT_SIGN = NUMERALS[0] if NUMERALS else False
			debug_MS(f"(navigator.playLIVE[2]) ***** CHECKED YOUTUBE - ID IN CONTEXT : {YOUT_SIGN} *****")
		YOUT_CIPHER = YOUT_SIGN if YOUT_SIGN else CHANNEL_LIVE if CHANNEL_LIVE != '00' else False
		if YOUT_CIPHER:
			debug_MS(f"(navigator.playLIVE[3]) ***** TESTING - REDIRECTED : https://www.youtube.com/oembed?format=json&url=http://www.youtube.com/watch?v={YOUT_CIPHER} || (Youtube-Redirect-Test) *****")
			LIVE_URL, STREAM = YouGetVideo(YOUT_CIPHER)
		else: log("(navigator.playLIVE[3]) XXXXX !!! YOUTUBE - ID NOT FOUND - ACTION NOT SUCCESSFUL - SKIP !!! XXXXX")
	if LIVE_URL and STREAM in ['DIRECT', 'YOUTUBE']:
		debug_MS(f"(navigator.playLIVE) ### LIVE_URL : {LIVE_URL} ###")
		LTM = xbmcgui.ListItem(f"{translation(30611)}  ({SHORTS_DROID.upper()})", path=LIVE_URL)
		LTM.setMimeType('application/vnd.apple.mpegurl')
		if STREAM == 'DIRECT': LTM.setArt({'icon': icon, 'thumb': f"{artpic}livestream.png", 'poster': f"{artpic}livestream.png"})
		xbmc.Player().play(item=LIVE_URL, listitem=LTM)
	else:
		failing("(navigator.playLIVE) ##### Abspielen des Live-Streams NICHT möglich #####\n ########## KEINEN Live-Stream-Eintrag auf der Webseite von *euronews.com* gefunden !!! ##########")
		return dialog.notification(translation(30521).format('LIVE'), translation(30527), icon, 8000)

def playCODE(IDD):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS(f"(navigator.playCODE) ### EURONEWS_IDD = {IDD} ###")
	FINAL_URL, DIRECT_STREAM, YOUT_CIPHER = (False for _ in range(3))
	with open(WORKFILE, 'r') as wok:
		ARRIVE = json.load(wok)
		for elem in ARRIVE['videos']:
			if elem['filter'] != '00' and elem['filter'] == IDD:
				CLEAR_TITLE, DIRECT_STREAM, YOUT_CIPHER = elem['name'], elem['directLINK'], elem['youtubeID']
				debug_MS(f"(navigator.playCODE[1]) ### WORKFILE-Line : {elem} ###")
	if DIRECT_STREAM or YOUT_CIPHER:
		if DIRECT_STREAM: FINAL_URL = DIRECT_STREAM
		if PREFER_TUBE is True or not DIRECT_STREAM:
			if not YOUT_CIPHER:
				debug_MS(f"(navigator.playCODE[2]) ***** SEARCH FOR YOUTUBE - ID : {BASE_URL}/embed/{IDD} || (Youtube-Video-Search) *****")
				CHECK_ONE = getUrl(f"{BASE_URL}/embed/{IDD}", method='LOAD', RFE=f"{BASE_URL}/", ORG=BASE_URL).replace('\\', '').replace("&quot;", "\"")
				NUMERALS = re.compile(r'''["']videoid["']:["']([^"']*)["'],["']youtubevideoid["']:["']([^"']*)["'],''', re.S).findall(CHECK_ONE)
				YOUT_CIPHER = NUMERALS[0][1] if NUMERALS and NUMERALS[0][0] == IDD and NUMERALS[0][1] not in ['', 'none', 'None'] else False
			if YOUT_CIPHER:
				debug_MS(f"(navigator.playCODE[3]) ***** TESTING - REDIRECTED : https://www.youtube.com/oembed?format=json&url=http://www.youtube.com/watch?v={YOUT_CIPHER} || (Youtube-Redirect-Test) *****")
				VOD_URL, STREAM = YouGetVideo(YOUT_CIPHER)
				if VOD_URL and STREAM == 'YOUTUBE':
					FINAL_URL = VOD_URL
	if FINAL_URL:
		log(f"(navigator.playCODE) YTID : {YOUT_CIPHER} || StreamURL : {FINAL_URL}")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, xbmcgui.ListItem(path=FINAL_URL))
	else:
		failing("(navigator.playLIVE) ##### Abspielen des VOD-Streams NICHT möglich #####\n ########## KEINEN VOD-Stream-Eintrag auf der Webseite von *euronews.com* gefunden !!! ##########")
		return dialog.notification(translation(30521).format('VIDEO'), translation(30527), icon, 8000)

def addDir(params, listitem, folder=True):
	uws = build_mass(params)
	listitem.setPath(uws)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
