﻿from updatervar import *


delete_files = ['repository.test', 'repository.Kpoodle19', 'repository.Kpoodle20', 'repository.diggz', 'repository.encryptic', 'repository.Wherethemonsterslive', 'repository.wnt2', 'repository.test2', UpdaterMatrix_path, UpdaterMatrix_path29, UpdaterMatrix_path30]



base_path = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.themoviedb.helper')


dir_list = glob.iglob(os.path.join(base_path, "reconfigured_players"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)


base_path = xbmcvfs.translatePath('special://home/media/Downloads')

dir_list = glob.iglob(os.path.join(base_path, "CartoonsGR"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)


    xbmcvfs.delete('special://home/userdata/playercorefactory.xml')

    xbmc.sleep(5000)
    dialog.notification('Check Updates', 'Ελεγχος για ενημερώσεις προσθέτων', icon_auto2, sound=False)

def check_del_dir():
#    BG.create('[B]Αναζήτηση αχρείαστων αρχείων...[/B]', '')
    for path_list in delete_files:
        if exists(addons_path + '%s' % path_list) or exists('%s' % path_list):
            path_list = path_list.replace(UpdaterMatrix, '').replace(addons_path, '')
            dialog.notification('[B]Πραγματοποιήθηκε διαγραφή αρχείων...[/B]', path_list, icon_Build, sound=False)
        #    BG.update(66, '[B]Διαγραφή αχρείαστων αρχείων...[/B]', path_list)
            xbmc.sleep(1000)
            del_dir()


def del_dir():
    for ad in addons_data_path:
     for rr in delete_files:
       dir_list = glob.iglob(os.path.join(ad, rr))
       for path in dir_list:
           if os.path.isdir(path):
               shutil.rmtree(path)
           if os.path.isfile(path):
              os.remove(path)
#    BG.update(100, '[B]Διαγραφή αχρείαστων αρχείων...[/B]', Dialog_U4)
#    xbmc.sleep(500)
#    BG.close()

check_del_dir()
