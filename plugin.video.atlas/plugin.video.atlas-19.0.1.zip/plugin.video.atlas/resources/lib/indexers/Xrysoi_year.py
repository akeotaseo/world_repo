import xbmc, xbmcgui

def xrysoi_year():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]                                      Έτος κυκλοφορίας [/COLOR][/B]', 
['[B][COLOR=white]                                                          2022[/COLOR][/B]',
 '[B][COLOR=white]                                                          2021[/COLOR][/B]',
 '[B][COLOR=white]                                                          2020[/COLOR][/B]',
 '[B][COLOR=white]                                                          2019[/COLOR][/B]',
 '[B][COLOR=white]                                                          2018[/COLOR][/B]',
 '[B][COLOR=white]                                                          2017[/COLOR][/B]',
 '[B][COLOR=white]                                                          2016[/COLOR][/B]',
 '[B][COLOR=white]                                                     2013-2015[/COLOR][/B]'])

    if call:
        if call < 0:
            return
        func = funcs[call-8]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/tainiesonline/2022/,return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/tainiesonline/2021/,return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/tainiesonline/2020/,return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/tainiesonline/2019/,return)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/tainiesonline/2018/,return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/tainiesonline/2017/,return)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/tainiesonline/2016/,return)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/new-good/,return)')

xrysoi_year()
