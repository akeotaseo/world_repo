# -*- coding: utf-8 -*-
import os
import sys

import urllib
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import urllib3
import re
#import json
#import random
#import time
#mport html
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl
from resources.lib import jsunpack
   
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.maxsport')

mode = addon.getSetting('mode')
baseurl='https://maxsport.one'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0'

def build_url(query):
    return base_url + '?' + urlencode(query)

def tvList():
    hea={
        'User-Agent':UA
    }
    resp=requests.get(baseurl,headers=hea).text
    #resp1=resp.split('grid-container')[1]
    chans=re.compile('grid-item\"><a href=\"([^\"]+?)\".*<strong>([^<]+?)</strong></span').findall(resp)
    
    for c in chans:
        li=xbmcgui.ListItem(c[1])
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultTVShows.png', 'fanart': ''})
        url_li = build_url({'mode':'playTV','link':c[0]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_li, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)
    
def PlayStream(link):
    url_stream=''
    url=baseurl+link
    hea={
        'User-Agent':UA,
        'Referer':baseurl+'/'
    }
    resp=requests.get(url,headers=hea).text

    url1=re.compile('<iframe src=\"([^\"]+?)\"').findall(resp)[0]
    if 'buzztv' in url1 or 'sportz' in url1:
        if url1.startswith('//'):
            url1='https:'+url1
        hea={
            'User-Agent':UA,
            'Referer':url
        }
        resp1=requests.get(url1,headers=hea).text
        url2=re.compile('<iframe src=\"([^\"]+?)\"').findall(resp1)[0]
        if url2.startswith('//'):
            url2='https:'+url2
        #print(url2)
        hea={
            'User-Agent':UA,
            'Referer':url1
        }
        resp2=requests.get(url2,headers=hea).text
        packed = re.compile('(eval\(function\(p,a,c,k,e,(?:r|d).*)').findall(resp2)[0]
        unpacked=jsunpack.unpack(packed)
        #print(unpacked)
        stream=re.compile('var src=\"([^\"]+?)\"').findall(unpacked)[0]
        url_stream=stream+'|User-Agent='+UA+'&Referer='+url2
    
    if 'wecast.to' in url1:
        if url1.startswith('//'):
            url1='https:'+url1
        hea={
            'User-Agent':UA,
            'Referer':url
        }
        resp1=requests.get(url1,headers=hea).text
        packed = re.compile('(eval\(function\(p,a,c,k,e,(?:r|d).*)').findall(resp1)[0]
        unpacked=jsunpack.unpack(packed)
        #print(unpacked)
        stream=re.compile('file:\"([^\"]+?)\"').findall(unpacked)[0]
        url_stream=stream+'|User-Agent='+UA+'&Referer='+url1
        
    if 'sportkart' in url1: #olacast
        hea={
            'User-Agent':UA,
            'Referer':url
        }
        resp1=requests.get(url1,headers=hea).text
        url2=re.compile('<iframe src=\"([^\"]+?)\"').findall(resp1)[0]
        #print(url2)
        hea={
            'User-Agent':UA,
            'Referer':url1
        }
        resp2=requests.get(url2,headers=hea).text
        #print(resp2)
        streamURL=re.compile('source:\'([^\']+?)\'').findall(resp2)[-1]
        #print(streamURL)
        hea_prx={
            'Referer':url2,
            'User-Agent':UA
        }
        addon.setSetting('hea_prx',str(hea_prx))
        proxyport = addon.getSetting('proxyport')
        url_stream='http://127.0.0.1:%s/DADDYLIVE='%(str(proxyport))+streamURL
    
    if 'besthdplayer' in url1:#olacast
        hea={
            'User-Agent':UA,
            'Referer':url
        }
        resp1=requests.get(url1,headers=hea).text
        streamURL=re.compile('source:\'([^\']+?)\'').findall(resp1)[-1]
        #print(streamURL)
        hea_prx={
            'Referer':url1,
            'User-Agent':UA
        }
        addon.setSetting('hea_prx',str(hea_prx))
        proxyport = addon.getSetting('proxyport')
        url_stream='http://127.0.0.1:%s/DADDYLIVE='%(str(proxyport))+streamURL
        
    if 'pkcasts' in url1 or 'fcfooty' in url1:#BBC
        hea={
            'User-Agent':UA,
            'Referer':url
        }
        resp1=requests.get(url1,headers=hea).text
        s=re.compile('return\(\[([^\[]+?)\]').findall(resp1)[0]
        stream=s.replace(',','').replace('\"','').replace('\\','')
        url_stream=stream+'|User-Agent='+UA+'&Referer='+url1

    play_item = xbmcgui.ListItem(path=url_stream)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
    #import inputstreamhelper
    #PROTOCOL = 'hls'
    #is_helper = inputstreamhelper.Helper(PROTOCOL)
    #if is_helper.check_inputstream():
        #play_item = xbmcgui.ListItem(path=stream)
        #play_item.setMimeType('application/x-mpegurl')
        #play_item.setContentLookup(False)
        #if sys.version_info >= (3,0,0):
            #play_item.setProperty('inputstream', is_helper.inputstream_addon)
        #else:
            #play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)
        #play_item.setProperty('inputstream.adaptive.stream_headers', hdr)        
        #play_item.setProperty("IsPlayable", "true")
        #play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        
    #xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
   
    


mode = params.get('mode', None)

if not mode:
    tvList()
else:
    if mode=='playTV':
        link=params.get('link')
        PlayStream(link)    
