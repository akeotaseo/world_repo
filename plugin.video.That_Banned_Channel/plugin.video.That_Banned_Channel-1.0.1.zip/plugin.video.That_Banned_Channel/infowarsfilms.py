InfoWarsFilms = {'5 - InfoWarsFilms': [

                 {'name': 'Endgame: Blueprint for Global Enslavement',
                  'thumb': 'https://assets.infowarsmedia.com/images/ac917c98-5469-40bf-8bf6-6d7c52ce8d92-large.jpg',
                  'video': 'https://downloads.banned.video/videos/908d8bab-24ad-409f-91bd-11ff9f152fd0.mp4',
                  'genre': 'Documentaries'},
                  
                 {'name': 'The Obama Deception',
                  'thumb': 'https://assets.infowarsmedia.com/images/6e60cbaa-2e1c-47ff-b338-ed20ea9b96b9-large.jpg',
                  'video': 'https://downloads.banned.video/videos/1d5801cc-95cc-42df-bcab-9be6100ff35f.mp4',
                  'genre': 'Documentaries'},
                  
                 {'name': 'America Destroyed by Design',
                  'thumb': 'https://assets.infowarsmedia.com/images/8b82bf09-0b0c-4191-8165-5ffa3a5e3f74-large.jpg',
                  'video': 'https://downloads.banned.video/videos/16a1a0c5-bf2c-4ad1-aacd-414277b224a6.mp4',
                  'genre': 'Documentaries'},
                  
                 {'name': 'Dark Secrets Inside Bohemian Grove',
                  'thumb': 'https://assets.infowarsmedia.com/images/26706292-bf02-4942-bd96-26464527ae84-large.jpg',
                  'video': 'https://downloads.banned.video/videos/13be9470-3386-4edf-a434-491c08d9dba9.mp4',
                  'genre': 'Documentaries'},
                     
                 {'name': 'LOOSE CHANGE 2',
                  'thumb': 'https://assets.infowarsmedia.com/images/35892cd6-7278-44d3-8493-47481d6f3ea6-large.jpg',
                  'video': 'https://downloads.banned.video/videos/dac9f0b2-306e-4c60-adf3-a651cf55d42f.mp4',
                  'genre': 'Documentaries'},
                 
                 {'name': '9/11 The Road To Tyranny',
                  'thumb': 'https://assets.infowarsmedia.com/images/b695f9f8-3fba-4789-8f59-d75c8e3175e7-large.jpg',
                  'video': 'https://downloads.banned.video/videos/365f7df9-18b3-4e97-a49a-890cae46443e.mp4',
                  'genre': 'Documentaries'},
                  
                 {'name': 'Martial Law 911 Rise of The Police State',
                  'thumb': 'https://assets.infowarsmedia.com/images/d07a3877-7f94-426d-8858-d88255bfdace-large.jpg',
                  'video': 'https://downloads.banned.video/videos/a1975e94-711a-4212-abf4-1402b5980fa2.mp4',
                  'genre': 'Documentaries'},
                  
                 {'name': '9/11 CHRONICLES: Truth Rising',
                  'thumb': 'https://assets.infowarsmedia.com/images/ca4aac4b-b082-489b-8dce-0fd2593e2f46-large.jpg',
                  'video': 'https://downloads.banned.video/videos/283bdb4d-f7b9-48e7-80e5-ff30c047261c.mp4',
                  'genre': 'Documentaries'},
                 
                 {'name': 'Ben Livingston: The Father Of Weaponized Weather',
                  'thumb': 'https://assets.infowarsmedia.com/images/a78f503a-b2df-424a-94f1-ababe433161d-large.png',
                  'video': 'https://downloads.banned.video/videos/283d53a4-1b21-491d-92eb-fcd3a3293704.mp4',
                  'genre': 'Documentaries'},
                 
                 {'name': 'The Order of Death',
                  'thumb': 'https://assets.infowarsmedia.com/images/fcd5f100-26bc-4a2a-84ff-4af922a38e51-large.jpg',
                  'video': 'https://downloads.banned.video/videos/20e3f6c6-12c9-4392-b466-c5fb0611b105.mp4',
                  'genre': 'Documentaries'},
                 
                 {'name': 'TERRORSTORM - A History Of Government Sponsored Terror',
                  'thumb': 'https://assets.infowarsmedia.com/images/5021a81b-7161-4dae-9f15-c6658fb51c61-large.jpg',
                  'video': 'https://downloads.banned.video/videos/ad180cf9-9e14-42a9-9d31-4d026058e5a2.mp4',
                  'genre': 'Documentaries'},
                     
                 {'name': 'Charlotte Iserbyt - The Deliberate Dumbing Down of America',
                  'thumb': 'https://assets.infowarsmedia.com/images/3b25eac6-d485-436e-8366-626f46d8bf5f-large.jpg',
                  'video': 'https://downloads.banned.video/videos/35d267bf-6362-4f62-a59a-51cb35ff8927.mp4',
                  'genre': 'Documentaries'},
                  
                 {'name': 'The Cosmic Hoax: An Exposé',
                  'thumb': 'https://assets.infowarsmedia.com/images/99542494-07a6-4151-946d-27b7ad161d70-large.png',
                  'video': 'https://downloads.banned.video/videos/d728bd8d-366e-435b-a165-aad71b2a9d9e.mp4',
                  'genre': 'Documentaries'}
                 ]}
