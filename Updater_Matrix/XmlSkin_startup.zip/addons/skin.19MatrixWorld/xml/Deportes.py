﻿import xbmc, xbmcgui

def Deportes():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=http%3a%2f%2fbgtv.xyz%2fblack%2fimg%2ffanart.jpg&mode=1&name=Deportes&url=http%3a%2f%2fbgtv.xyz%2fblack%2f0-deportes.php")')
    xbmcgui.Dialog().notification("[B][COLOR orange]MicroJen[/COLOR][/B]", "Deportes", sound=False, icon='http://bgtv.xyz/black/img/deportes.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]MicroJen[/COLOR][/B]", "Deportes", sound=False, icon='http://bgtv.xyz/black/img/deportes.png')
Deportes()
