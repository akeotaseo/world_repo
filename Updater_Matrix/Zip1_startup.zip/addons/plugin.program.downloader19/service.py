﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui
from updatervar import *
from resources.lib.modules import check




if __name__ == '__main__':
	if not setting('updaterversion') == 'false':
		dialog.notification(Dialog_welcome, Dialog_Update, icon_Build, sound=False)
		xbmc.sleep(5000)
		dialog.notification('Καλή διασκέδαση!','   ', icon_hi, sound=False)
		xbmc.sleep(5000)
		check.updater()  #downloader_startup#
		check.notifyT()
		check.autoenable()
		check.var()
		check.players()
		check.delete()
		check.zip1()
		check.zip2()
		check.zip3()
		check.zip4()
		check.zip5()
		check.pvr()
		check.installation()
		check.setsetting()
		check.database()
		check.UpdateAddonRepos()
		check.xmlskin()




	else:
		dialog.notification(Dialog_welcome, Dialog_not_Updater, icon_Build, sound=False)
		check.UpdateAddonRepos()

	xbmc.sleep(1000)
	xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/Tools/ArtistslideshowCleanUp.py")')

#	dialog.notification('[B][COLOR orange]Το build είναι ενημερωμένο![/COLOR][/B]', '[COLOR white]Καλή διασκέδαση...[/COLOR]', icon_ok, sound=False)

	monitor = xbmc.Monitor()

	while not monitor.abortRequested():
		if monitor.waitForAbort(2*60*60):#διάστημα 2ωρών μεταξύ των ενημερώσεων
			break
		xbmc.executebuiltin('UpdateAddonRepos()')
		dialog.notification('Υπηρεσία ενημέρωσης', 'Εκκίνηση ενημερώσεων προσθέτων', icon_auto, sound=False)
