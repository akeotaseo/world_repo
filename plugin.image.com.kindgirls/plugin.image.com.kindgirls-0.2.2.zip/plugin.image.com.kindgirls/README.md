plugin.image.com.kindgirls
==========================

View photos and videos from https://www.kindgirls.com on Kodi

## Support

### Author

* Bitcoin (BTC): _1BDpCYE2x1TbXzk1VjVeg11wsBKqKGrmKL_
* Ethereum (ETH): _0xbb12d359681C1Ce43fc0552723ACF98673ee1124_
* Ripple (XRP): _rwu4XmSLDULFp5FshrtRi8r5gNCfPMwa25_
* Monero (XMR): _42eWgtdpjF64aiksM58NbVha9QupUemsGTXSyju3nRxGTnpcCedc2pNhE37Arpb6uE5JdMVCRhwHE7NZif6NLYAd4zhHkTh_

![1BDpCYE2x1TbXzk1VjVeg11wsBKqKGrmKL](resources/support/BTC_QR.png)
![0xbb12d359681C1Ce43fc0552723ACF98673ee1124](resources/support/ETH_QR.png)
![rwu4XmSLDULFp5FshrtRi8r5gNCfPMwa25](resources/support/XRP_QR.png)
![42eWgtdpjF64aiksM58NbVha9QupUemsGTXSyju3nRxGTnpcCedc2pNhE37Arpb6uE5JdMVCRhwHE7NZif6NLYAd4zhHkTh](resources/support/XMR_QR.png)

### Ukraine

* Bitcoin (BTC): _357a3So9CbsNfBBgFYACGvxxS6tMaDoa1P_
* Ethereum (ETH): _0x165CD37b4C644C2921454429E7F9358d18A45e14_
* Tether (USDT): _TEFccmfQ38cZS1DTZVhsxKVDckA8Y6VfCy_

![357a3So9CbsNfBBgFYACGvxxS6tMaDoa1P](resources/support_ua/BTC_QR.png)
![0x165CD37b4C644C2921454429E7F9358d18A45e14](resources/support_ua/ETH_QR.png)
![TEFccmfQ38cZS1DTZVhsxKVDckA8Y6VfCy](resources/support_ua/USDT_QR.png)

source: https://nazk.gov.ua/en/news/how-can-you-support-ukraine-during-the-wartime/

## Authors

- fr33p0rt <fr33p0rt@protonmail.com>
- DaM <kontakt@dpisarczyk.pl>

## 3rd party assets

##### fanart.jpg (all photos)

Photo by RODRIGO AMATUZZI from Pexels

##### QR codes for cryptocurrencies

Generated at https://www.cwaqrgen.com/

## License

GPL 2.0
