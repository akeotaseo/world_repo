﻿import xbmc, xbmcgui
def DialogFootball():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dracarys/?category=live_sport&mode=open_site_category&site=livetv&url=https%3a%2f%2flivetv751.me%2fenx%2fallupcomingsports%2f1%2f")')
    xbmcgui.Dialog().notification("[B][COLOR green]Dracarys[/COLOR][/B]", "[COLOR white]FOOTBALL[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/Dracarys.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR green]Dracarys[/COLOR][/B]", "[COLOR white]FOOTBALL[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/Dracarys.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR green]Dracarys[/COLOR][/B]", "[COLOR white]FOOTBALL[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/Dracarys.png')
    xbmc.sleep(4000)


DialogFootball()
