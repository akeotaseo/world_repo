﻿import os, sys, db, xbmc, sqlite3, glob, xbmcgui

# xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=fixaddonupdate")')

xbmcgui.Dialog().notification("Database", "Addons33", icon='special://home/addons/plugin.program.downloader19/resources/media/database.webp', sound=False)

from updatervar import *
from xbmcaddon import Addon
from xbmcvfs import translatePath
from xbmcgui import Dialog
from xbmc import log
from datetime import datetime
from xml.dom.minidom import parse

addon_xmls = []

BG = xbmcgui.DialogProgressBG()
addon_id        = 'plugin.program.downloader19'
addon           = xbmcaddon.Addon(addon_id)
addoninfo       = addon.getAddonInfo
ADDON_NAME      = addoninfo('name')
#ADDON_NAME = Addon().getAddonInfo('name')
DB_FOLDER = translatePath('special://database')
ADDONS_DB = os.path.join(DB_FOLDER, 'Addons33.db')
OK_DIALOG = Dialog().ok
YES_NO_DIALOG = Dialog().yesno

Database_Addons33 = [('repository.World', 'repository.World'),
                     ('repository.Worldolympic', 'repository.World'),
                     ('repository.Worldrepo', 'repository.World'),
                     ('repository.WorldNexus', 'repository.World'),
                     ('repository.WorldOmega', 'repository.World'),

                     ('plugin.video.playlistloaderworld', 'repository.World'),

                     ('plugin.switchback', 'repository.WorldNexus'),

                     ('plugin.video.kodikaraoke', 'repository.WorldNexus'),
                     # ('plugin.video.ytlite', 'repository.WorldNexus'),
                     


                     # ('script.module.youtube.dl', 'repository.World'),


                     ('plugin.program.downloaderstartup', 'repository.Worldolympic'),
                     ('skin.19MatrixWorld', 'repository.Worldolympic'),
                     ('plugin.program.myselect', 'repository.Worldolympic'),
                     ('plugin.program.simple.favourites', 'repository.Worldolympic'),
                     ('service.autoexec', 'repository.Worldolympic'),
                     ('service.subtitles.All_Subs', 'repository.Worldolympic'),
                     ('script.RealDebrid.vpn', 'repository.Worldolympic'),
                     # ('plugin.video.duffyou', 'Worldolympic'),
                     
                     
                                       # scrubsv2
                     #('plugin.video.scrubsv2', 'repository.WorldNexus'),
                     # ('plugin.video.scrubsv2', 'repository.jewrepo'),
                     # ('plugin.video.scrubsv2', 'repository.WorldOmega'),
                     ('plugin.video.scrubsv2', 'repository.redwizard'),
                                          ###

                     ('script.embuary.info', 'repository.Worldolympic'),
                     #('plugin.video.watchnixtoons2', 'repository.Worldolympic'),

                     ('plugin.video.macvod', 'repository.Worldolympic'),
                     # ('plugin.video.rumble', 'repository.Worldolympic'),
                     ('plugin.video.scrapee', 'repository.Worldolympic'),
                     ('service.world.build', 'repository.Worldolympic'),


                     ('plugin.video.cristalazul', 'repository.World'),

                     ('script.kelebek', 'repository.World'),
                     ('script.luar', 'repository.World'),
                     ('plugin.video.stalker', 'repository.World'),

                     ('repository.oliver', 'repository.Worldrepo'),
                     # ('script.black.bars.never', 'repository.World'),
                     ('script.black.bars.never', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),


                     ('plugin.video.90phuttv', 'repository.World'),
                     ('plugin.video.thethao', 'repository.World'),

                     ('plugin.video.vnmedia', 'repository.World'),
                     ('plugin.video.thapcam', 'repository.World'),

                     ('plugin.video.avdb', 'repository.World'),

                     ('plugin.video.iptvxc', 'repository.Worldolympic'),
                     ('plugin.audio.dashradio', 'repository.World'),
                     ('plugin.audio.mixcloud', 'repository.World'),
                     ('plugin.video.dracarys', 'repository.World'),
                     ('plugin.audio.radio_de_light', 'repository.World'),





                                        # resolveurl
                     ('script.module.resolveurl', 'repository.resolveurl'),




                                      # sportsdevil
                     ('plugin.video.sportsdevil', 'repository.World'),
                     ('script.module.streamlink', 'repository.World'),
                     ('script.module.pycountry', 'repository.World'),
                     # ('script.module.isodate', 'repository.gkobu'),
                     # ('script.module.pysocks', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),

                     # ('script.module.slproxy', 'repository.World'),
                     ('script.module.slproxy', 'repository.gujal'),




                                          # gkobu 

                     #('inputstream.adaptive', 'repository.gkobu'),
                     #('pvr.stalker', 'repository.gkobu'),

                     ('script.module.pysubs2', 'repository.gkobu'),


                     ('script.module.horus', 'repository.gkobu'),

                     ('plugin.video.duffyou', 'repository.gkobu'),
                     ('plugin.video.f4mTester', 'repository.gkobu'),
                     ('script.video.F4mProxy', 'repository.gkobu'),
                     ('plugin.video.live.streamspro', 'repository.gkobu'),


                     ('plugin.video.sporthdme', 'repository.gkobu'),

                     ('plugin.video.cartoonsgr', 'repository.gkobu'),
                     ('plugin.video.fmoviesto', 'repository.gkobu'),
                     ('plugin.video.gratis', 'repository.gkobu'),
                     ('plugin.video.lookmovietomb', 'repository.gkobu'),
                     ('plugin.video.thetvapp', 'repository.gkobu'),
                     ('plugin.video.fen', 'repository.gkobu'),
                     ('service.subtitles.subsource-net', 'repository.gkobu'),
                     ('service.subtitles.subscene', 'repository.gkobu'),
                     ('service.subtitles.subdl-com', 'repository.gkobu'),
                     # ('service.subtitles.a4ksubtitles', 'repository.gkobu'),

                     ('script.module.thetvdb', 'repository.gkobu'),
                     ('script.skin.helper.skinbackup', 'repository.gkobu'),
                     ('script.module.metadatautils', 'repository.gkobu'),
                     ('script.skin.helper.service', 'repository.gkobu'),
                     ('script.module.nemzzy', 'repository.gkobu'),
                     ('script.module.autocompletion', 'repository.gkobu'),
                     ('script.module.microjenscrapers', 'repository.gkobu'),
                     # ('script.module.microjenscrapers', 'repository.cMaNWizard'),

                     ('script.module.pyairtable', 'repository.gkobu'),
                     ('service.subtitles.localsubtitle', 'repository.gkobu'),
                     ('script.module.iso639', 'repository.gkobu'),
                     ('plugin.video.seren', 'repository.gkobu'),
                     ('context.seren', 'repository.gkobu'),

                     ('plugin.video.ert.gr', 'repository.gkobu'),
                     ('plugin.video.alphatv.gr', 'repository.gkobu'),
                     ('plugin.video.antenna.gr', 'repository.gkobu'),
                     ('plugin.video.skai.gr', 'repository.gkobu'),
                     ('plugin.video.star.gr', 'repository.gkobu'),


                                           #manalab
                     ('repository.manalab19', 'repository.manalab19'),
                     ('plugin.video.manalab', 'repository.manalab19'),
                     ('plugin.video.forecastweather', 'repository.manalab19'),
                     ('service.audio.tmdb.sync', 'repository.manalab19'),
                     ('plugin.video.dailymotion_com', 'repository.manalab19'),
                     ('plugin.video.earthtv', 'repository.manalab19'),
                     # ('plugin.video.antenna.gr', 'repository.manalab19'),
                     # ('plugin.video.ert.gr', 'repository.manalab19'),
                     ('service.subtitles.a4ksubtitles', 'repository.manalab19'),


                                           # bugatsinho
                     #('plugin.video.cartoonsgr', 'repository.bugatsinho'),
                     # ('plugin.video.sporthdme', 'repository.bugatsinho'),
                     ('script.module.t0mm0.common', 'repository.bugatsinho'),


                                           # twilight0
                     ('repository.twilight0', 'repository.twilight0'),
                     ('plugin.video.alivegr', 'repository.twilight0'),
                     ('script.module.tulip', 'repository.twilight0'),
                     # ('plugin.video.alphatv.gr', 'repository.twilight0'),
                     # ('plugin.video.antenna.gr', 'repository.twilight0'),
                     # ('plugin.video.fashiontv.com', 'repository.twilight0'),
                     # ('plugin.video.skai.gr', 'repository.twilight0'),
                     # ('plugin.video.star.gr', 'repository.twilight0'),



                                           #thecrew
                     ('repository.thecrew.alpha', 'repository.thecrew.alpha'),

                     ('plugin.video.thecrew', 'repository.thecrew.alpha'),
                     ('script.module.thecrew', 'repository.thecrew.alpha'),
                     ('script.thecrew.artwork', 'repository.thecrew.alpha'),



                                           # autowidget 
                     ('plugin.program.autowidget', 'repository.autowidget'),
                     ('repository.autowidget', 'repository.autowidget'),


                                           # zeltorix'
                     ('repository.zeltorix', 'repository.zeltorix'),
                     ('plugin.video.zeltorix.worldcams.tv', 'repository.zeltorix'),
                     ('script.module.zeltorix.packages', 'repository.zeltorix'),
                     ('script.module.zeltorix.utilitys', 'repository.zeltorix'),
                     #('script.module.zeltorix.utilitys', 'repository.World'),



                                        # jurialmunkey
                     # ('script.module.infotagger', 'repository.newdiamond'),
                     ('script.module.infotagger', 'repository.jurialmunkey'),
                     # ('plugin.video.themoviedb.helper', 'repository.jurialmunkey'),
                     # ('plugin.video.themoviedb.helper', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.module.jurialmunkey', 'repository.jurialmunkey'),
                     ('script.skinvariables', 'repository.jurialmunkey'),
                     ('plugin.video.themoviedb.helper', 'repository.gkobu'),
                     
                     



                                          # inputstreamhelper
                     ('script.module.inputstreamhelper', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     # ('script.module.inputstreamhelper', 'repository.aliunde'),
                     #('script.module.inputstreamhelper', 'repository.slyguy.inputstreamhelper'),

                     # ('repository.slyguy.inputstreamhelper', 'repository.slyguy'),



                                          #youtube
                     # ('plugin.video.youtube', 'repository.redwizard'),
                     # ('plugin.video.youtube', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('plugin.video.youtube', 'repository.xbmc.org'),
                     # ('plugin.video.youtube', 'repository.cMaNWizard'),
                     # ('plugin.video.youtube', 'repository.gkobu'),



                                         # xbmc.org

                     ('inputstream.adaptive', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('inputstream.ffmpegdirect', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('inputstream.rtmp', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('vfs.libarchive', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('vfs.rar.inputstreamhelper', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('vfs.sftp', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),

                     #('script.module.infotagger', 'b6a50484-93a0-4afb-a01c-8d17e059feda')

                     #('pvr.stalker', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.module.xbmcswift2', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),


                     ('peripheral.joystick', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     # ('peripheral.joystick', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.module.requests', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.module.pyqrcode', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('inputstream.adaptive', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('pvr.stalker', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),

                     ('script.module.simplejson ', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),


                     ('script.module.dateutil', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),

                     ('plugin.audio.radio_de', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('weather.gismeteo', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),

                     ('script.module.myconnpy', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.module.clouddrive.common', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('metadata.themoviedb.org.python', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),


                     ('script.module.htmlement', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.module.pysocks', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.module.idna', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.module.beautifulsoup4', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.module.certifi', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.module.chardet', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),

                     # ('script.module.codequick', 'repository.WorldNexus'),
                     ('script.module.codequick', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.module.pyparsing', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),


                     ('script.module.simplejson', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.module.six', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.module.soupsieve', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.module.urllib3', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.module.websocket', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.module.requests-toolbelt', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),

                     ('script.module.unidecode', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.speedtester', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.module.youtube.dl', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.module.bottle', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     ('script.radioparadise', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
                     # ('script.radioparadise', 'repository.xbmc.org'),
                     
                     

                     # ('resource.images.studios.white', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),



                     ('repository.giaitri', 'repository.giaitri'),
                     ('plugin.video.xembongda', 'repository.giaitri'),

                                        # kentestvn   NEW
                     ('kentestvn', 'kentestvn'),
                     # ('script.module.requests', 'kentestvn'),
                     # ('script.module.urllib3', 'kentestvn'),
                     # ('script.module.six', 'kentestvn'),
                     # ('script.module.pysocks', 'kentestvn'),
                     # ('script.module.chardet', 'kentestvn'),
                     # ('script.module.certifi', 'kentestvn'),
                     # ('script.module.bottle', 'kentestvn'),
                     # ('kentestvn', 'kentestvn'),
                     # ('kentestvn', 'kentestvn'),





                                       # vnmedia off #

                     # ('plugin.video.vnmedia', 'repovnmedia'),
                     ('repovnmedia', 'repovnmedia'),

                     #  ('script.module.dateutil', 'repovnmedia'),          23.910.0     @@@@@@

                     # ('script.module.htmlement', 'repovnmedia'),          2.0.0
                     # ('script.module.pysocks', 'repovnmedia'),            1.7.1
                     # ('script.module.idna', 'repovnmedia'),               3.7
                     # ('script.module.infotagger', 'repovnmedia')          0.0.8
                     # ('script.module.beautifulsoup4', 'repovnmedia'),     4.12.3
                     # ('script.module.certifi', 'repovnmedia'),            2024.07.04
                     # ('script.module.chardet', 'repovnmedia'),            5.2.0
                     #  ('script.module.clouddrive.common', 'repovnmedia'), 1.4.0
                     # ('script.module.cloudscraperkd', 'repovnmedia'),     1.271
                     # ('script.module.codequick', 'repovnmedia'),          1.2.0
                     # ('script.module.dateutil', 'repovnmedia'),           2.82
                     # ('script.module.pyparsing', 'repovnmedia'),          3.1.2

                     # ('script.module.pycryptodome', 'repovnmedia'),       3.4.3     @@@@@@

                     # ('script.module.simplejson', 'repovnmedia'),
                     # ('script.module.six', 'repovnmedia'),                1.16.0
                     # ('script.module.soupsieve', 'repovnmedia'),          2.2.5
                     # ('script.module.urllib3', 'repovnmedia'),            2.2.2 
                     # ('script.module.websocket', 'repovnmedia'),
                     # ('script.module.requests-toolbelt', 'repovnmedia'),  1.0.0


                     #('script.module.pyqrcode', 'repovnmedia'),            1.2.1.4
                     #('script.module.requests', 'repovnmedia'),            2.32.3


                                    #kentestvn off #
                     # ('plugin.video.90phuttv', 'kodivietnam'),
                     ('kodivietnam', 'kodivietnam'),


                     # ('script.module.htmlement', 'kodivietnam'),
                     # ('script.module.pysocks', 'kodivietnam'),
                     # ('script.module.idna', 'kodivietnam'),               3.6
                     # ('script.module.infotagger', 'kodivietnam')          0.0.8
                     # ('script.module.beautifulsoup4', 'kodivietnam'),     4.12.3
                     # ('script.module.certifi', 'kodivietnam'),            2024.02.02
                     # ('script.module.chardet', 'kodivietnam'),            5.2.0
                     #  ('script.module.clouddrive.common', 'kodivietnam'), 1.4.0
                     # ('script.module.cloudscraperkd', 'kodivietnam'),
                     # ('script.module.codequick', 'kodivietnam'),
                     # ('script.module.dateutil', 'kodivietnam'),           2.82
                     # ('script.module.pyparsing', 'kodivietnam'),


                     # ('script.module.simplejson', 'kodivietnam'),
                     # ('script.module.six', 'kodivietnam'),                1.16.0
                     # ('script.module.soupsieve', 'kodivietnam'),          2.2.5
                     # ('script.module.urllib3', 'kodivietnam'),            2.2.1
                     # ('script.module.websocket', 'kodivietnam'),
                     # ('script.module.requests-toolbelt', 'kodivietnam')



                     #('script.module.pyqrcode', 'kodivietnam'),
                     #('script.module.requests', 'kodivietnam'),            2.32.1



                             # arrownegra  -  repository.dregs
                     #('repository.arrownegra', 'repository.arrownegra'),
                     #('repository.dregs', 'repository.dregs),

                     ('plugin.video.aguia_de_ouro', 'repository.dregs'),
                     ('plugin.video.fenix-mac', 'repository.dregs'),

                     ('repository.arrownegra', 'repository.Worldrepo'),
                     ('repository.dregs', 'repository.Worldrepo'),



                                    # RD account  //  709
                     ('repository.709', 'repository.709'),
                     # ('script.module.accountmgr', 'repository.709'),
                     ('script.module.acctview', 'repository.709'),
                     ('script.module.debridmgr', 'repository.709'),
                     ('script.module.dbview', 'repository.709'),





                                           # daddylive
                     # ('plugin.video.daddylive', 'repository.Worldolympic'),
                     # ('plugin.video.daddylive', 'repository.thecrew'),
                     #('plugin.video.daddylive', 'repository.aliunde'),
                     #('plugin.video.daddylive', 'repository.dexe'),
                     # ('plugin.video.daddylive', 'repository.gwen84'),



                                         # Netflix
                     ('repository.castagnait', 'repository.castagnait'),
                     ('plugin.video.netflix', 'repository.castagnait'),

                                         # funstersplace
                     ('plugin.video.gratis', 'repository.gkobu'),
                     ('repository.funstersplace', 'repository.funstersplace'),


                                         # dexe
                     ('repository.roooar', 'repository.roooar'),
                     #('repository.dexe', 'repository.roooar'),
                     ('plugin.video.BauBauVavoo', 'repository.dexe'),
                     ('plugin.video.GreenKlikPremium', 'repository.dexe'),

                     #('plugin.video.fen', 'repository.dexe'),
                     # ('repository.dexe', 'Worldrepo'),
                     ('repository.dexe', 'repository.dexe'),

                     ('plugin.video.free99', 'repository.dexe'),
                     ('script.free99.artwork', 'repository.dexe'),
                     # ('plugin.video.playlistbee', 'repository.dexe'),


                                         # diggz
                     ('repository.diggz', 'repository.diggz'),
                     #('plugin.video.free99', 'repository.diggz'),
                     #('script.free99.artwork', 'repository.diggz'),


                                # cMaNWizard / Mad For It Repo
                     ('repository.cMaNWizard', 'repository.cMaNWizard'),
                     ('plugin.video.quicksilver', 'repository.madforit'),
                     ('script.module.quicksilverscrapers', 'repository.madforit'),
                     ('script.quicksilver.artwork', 'repository.madforit'),

                     ('plugin.video.halcyon', 'repository.madforit'),
                     ('plugin.video.neo_flix', 'repository.madforit'),
                     ('plugin.video.tvfree', 'repository.madforit'),


                                        # homelander
                     ('repository.chainsrepo', 'repository.chainsrepo'),
                     ('plugin.video.homelander', 'repository.chainsrepo'),
                     ('script.module.homelanderscrapers', 'repository.chainsrepo'),
                     ('script.homelander.artwork', 'repository.chainsrepo'),


                                        # gigoro33-addon
                     ('repository.gigoro33-addon', 'repository.World'),
                     ('plugin.video.latinsports', 'repository.gigoro33-addon'),


                                  #repository.mrfixit2001
                     ('repository.mrfixit2001', 'repository.mrfixit2001'),
                     # ('plugin.video.kodikaraoke', 'repository.mrfixit2001'),
                     ('plugin.video.ytlite', 'repository.mrfixit2001'),



                                           #gearheads2
                     ('repository.gearheads2', 'repository.Worldrepo'),
                     # ('repository.gearheads2', 'repository.gearheads2'),
                     ('plugin.video.torquelite', 'repository.gearheads2'),

                                             # REST


                     ('script.module.jetextractors', 'repository.loop'),
                     ('plugin.video.fen', 'repository.redwizard'),


                     ('repository.KODIvertiDO_TEAM', 'repository.KODIvertiDO_TEAM'),
                     # ('plugin.video.KODIvertiDO', 'repository.KODIvertiDO_TEAM'),
                     ('plugin.video.KODIvertiDO', 'repository.World'),

                     ('plugin.video.vavooto', 'repository.michaz'),
                     # ('plugin.video.vavooto', 'Bee-Queen'),

                     ('repository.jellyfin.kodi', 'repository.jellyfin.kodi'),

                     ('plugin.video.thethunder', 'One.repo'),

                     ('repository.alado.tv', 'repository.Worldrepo'),
                     # ('repository.alado.tv', 'repository.alado.tv'),
                     ('plugin.video.train.mac.again', 'repository.alado.tv'),

                     ('repository.cocoscrapers', 'repository.cocoscrapers'),
                     ('script.module.cocoscrapers', 'repository.cocoscrapers'),

                     ('repository.lekma', 'repository.lekma'),
                     # ('plugin.video.invidious', 'repository.lekma'),

                     ('repository.rays.files', 'repository.rays.files'),
                     ('plugin.video.everstream', 'repository.rays.files'),

                     ('repository.Parrot', 'repository.Parrot'),

                     ('repository.subskip', 'repository.subskip'),


                     ('repository.kodifitzwell', 'repository.kodifitzwell'),
                     ('repository.azzyaddons', 'repository.azzyaddons'),
                     ('plugin.video.rumble', 'repository.azzyaddons'),


                     ('repository.animaniac', 'repository.animaniac'),
                     ('plugin.video.watchnixtoons2', 'repository.animaniac'),



                     ('repository.LostSoul', 'repository.LostSoul'),
                     ('repository.redwizard', 'repository.redwizard'),
                     ('repository.NarcacistWizard', 'repository.Worldrepo'),

                     ('repository.lattsrepo', 'repository.lattsrepo'),
                     ('resource.images.studios.white', 'repository.lattsrepo'),
                     # ('script.module.thetvdb', 'repository.lattsrepo'), --->    repository.gkobu



                     # ('plugin.video.jetproxy', 'repository.loop'),
                     ('plugin.video.jetproxy', 'repository.Magnetic'),

                     ('MatrixFlix.Repo', 'MatrixFlix.Repo'),
                     ('plugin.video.matrixflix', 'MatrixFlix.Repo'),



                     ('repository.madforit', 'repository.madforit'),
                     ('repository.twistednutz', 'repository.twistednutz'),


                     # ('plugin.audio.radio_de_light', 'repository.kodinerds'),
                     ('plugin.video.playlistloader', 'repository.kodinerds'),
                     # ('script.module.youtube.dl', 'repository.kodinerds'),
                     ('plugin.video.earthtv', 'repository.kodinerds'),


                     ('repository.github', 'repository.github'),
                     ('plugin.video.torrest', 'repository.github'),


                     # ('script.module.futures', 'repository.github'),
                     # ('script.module.futures', 'repository.sarsaila'),
                     ('script.module.futures', 'repository.twilight0'),


                     ('repository.BrazucaPlay', 'repository.BrazucaPlay'),
                     ('plugin.video.BrazucaPlay.Matrix', 'repository.BrazucaPlay'),


                     ('repository.fubuz', 'repository.fubuz'),
                     ('plugin.video.daddylivehd', 'repository.fubuz'),

                     ('repository.thelab', 'repository.thelab'),
                     ('plugin.video.dream1click', 'repository.thelab'),
                     ('plugin.video.dreamtv', 'repository.thelab'),

                     ('repository.diamondrepo', 'repository.diamondrepo'),
                     ('repository.rdplayer', 'repository.rdplayer'),
                     ('plugin.program.rdtplayer', 'repository.rdplayer'),

                     ('repository.EzzerMacsWizard', 'repository.EzzerMacsWizard'),

                     ('repository.zero', 'repository.zero'),
                     ('plugin.video.f1rewind', 'repository.zero'),
                     ('plugin.video.fod', 'repository.zero'),
                     ('plugin.video.wrestlingrewind', 'repository.zero'),
                     ('plugin.video.z3r0cinema', 'repository.zero'),



                     ('plugin.video.acestream_channels', 'repository.acestream-channels'),
                     ('repository.acestream-channels', 'repository.acestream-channels'),

                                           # RO
                     ('repository.derzis', 'repository.derzis'),
                     ('plugin.video.filmzie', 'repository.derzis'),
                     ('plugin.video.rdslive', 'repository.derzis'),
                     ('plugin.video.pandamoviespw', 'repository.derzis'),

                     ('repository.hub', 'repository.hub'),
                     # ('plugin.video.vixmovie', 'repository.hub'),
                     ('plugin.video.vixmovie', 'repository.angelitto'),
                     ('plugin.video.hub', 'repository.hub'),
                     # ('plugin.video.hub', 'repository.angelitto'),
                     ('plugin.video.hublive', 'repository.hub'),
                     # ('plugin.video.hublive', 'Bee-Queen'),

                     ('repository.luc_repo', 'repository.Worldrepo'),
                     ('plugin.video.luc_kodi', 'repository.luc_repo'),
                     ('repository.derzis', 'repository.derzis'),
                     ('repository.angelitto', 'repository.angelitto'),
                     ('plugin.video.romanianpack', 'repository.angelitto'),
                     ('Bee-Queen', 'Bee-Queen'),
                     ('plugin.video.playlistbee', 'Bee-Queen'),
                     ('plugin.video.romyTVlist', 'Bee-Queen'),
                     ('plugin.video.rotv123', 'Bee-Queen'),
##############################################################################
                     ('repository.cbtv', 'repository.cbtv'),
                     ('plugin.video.cbtv', 'repository.cbtv'),
                     
                     ('repository.zeus768', 'repository.zeus768'),
                     ('repository.kodi.media', 'repository.kodi.media'),


                     # ('repository.oldsalt', 'repository.oldsalt'),
                     ('repository.oldsalt', 'repository.Worldrepo'),


                     ('repository.enigmawiz', 'repository.enigmawiz'),
                     ('repository.greekporn', 'repository.greekporn'),
                     ('repository.remod', 'repository.remod')


                     ]


def enable_addons():
    for name in glob.glob(os.path.join(addons_path,'*/addon.xml')):
        addon_xmls.append(name)
    addon_xmls.sort()
    addon_ids =[]
    for xml in addon_xmls:
        try:
            root = parse(xml)
            tag = root.documentElement
            _id = tag.getAttribute('id')
            addon_ids.append(_id)
        except:
            pass
    enabled=[]
    disabled=[]
    for x in addon_ids:
        try:
            xbmcaddon.Addon(id = x)
            enabled.append(x)
        except:
            disabled.append(x)
    for y in disabled:
        try:
            enable_db(y)
        except:
            pass
    # xbmc.executebuiltin('UpdateLocalAddons')
    # xbmc.executebuiltin('UpdateAddonRepos')
    # xbmc.sleep(500)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')

def enable_db(d_addon):
    """ create a database connection to a SQLite database """
    conn = None
    conn = sqlite3.connect(addons_db)
    c = conn.cursor()
    try:
        c.execute("SELECT id, addonID, enabled FROM installed WHERE addonID = ?", (d_addon,))
        found = c.fetchone()
        if found == None:
            # Insert a row of data
            c.execute('INSERT INTO installed (addonID , enabled, installDate) VALUES (?,?,?)', (d_addon, '1', installed_date))
        else:
            c.execute('UPDATE installed SET enabled = ? WHERE addonID = ? ', (1, d_addon,))
    except Exception as e:
        log('Failed to enable %s. Reason: %s' % (d_addon, e), xbmc.LOGINFO)
    conn.commit()
    conn.close()


def addon_database():
    db.addon_database(Database_Addons33, 1, True)
    try:
        con = sqlite3.connect(ADDONS_DB)
        cursor = con.cursor()
        # cursor.execute('DELETE FROM addonlinkrepo;',)
        # cursor.execute('DELETE FROM addons;',)
        cursor.execute('DELETE FROM package;',)
        # cursor.execute('DELETE FROM repo;',)
        cursor.execute('DELETE FROM update_rules;',)
        # cursor.execute('DELETE FROM version;',)
        con.commit()
    except sqlite3.Error as e:
        xbmc.log(f'{ADDON_NAME}: There was an error reading the database - {e}', xbmc.LOGINFO)
        return ''
    finally:
        try:
            if con:
                con.close()
        except UnboundLocalError as e:
            xbmc.log(f'{ADDON_NAME}: There was an error connecting to the database - {e}', xbmc.LOGINFO)
################################
    # BG.create('[B]\u0391\u03bd\u03b1\u03bc\u03bf\u03bd\u03ae \u03b3\u03b9\u03b1 \u03bf\u03bb\u03bf\u03ba\u03bb\u03ae\u03c1\u03c9\u03c3\u03b7 \u03b5\u03bd\u03b7\u03bc\u03ad\u03c1\u03c9\u03c3\u03b7\u03c2[/B]', '\u0394\u03b9\u03cc\u03c1\u03b8\u03c9\u03c3\u03b7 repository.redwizard \u03c3\u03c4\u03b7\u03bd Database - Addons33.db ...')
    # xbmc.sleep(5000)
    # BG.update(78, '[B]\u0391\u03bd\u03b1\u03bc\u03bf\u03bd\u03ae \u03b3\u03b9\u03b1 \u03bf\u03bb\u03bf\u03ba\u03bb\u03ae\u03c1\u03c9\u03c3\u03b7 \u03b5\u03bd\u03b7\u03bc\u03ad\u03c1\u03c9\u03c3\u03b7\u03c2[/B]', '\u0394\u03b9\u03cc\u03c1\u03b8\u03c9\u03c3\u03b7 repository.redwizard \u03c3\u03c4\u03b7\u03bd Database - Addons33.db ...')
    # xbmc.sleep(8000)
    # BG.close(
################################
    try:
        con = sqlite3.connect(ADDONS_DB)
        cursor = con.cursor()
        cursor.execute('VACUUM;',)
        con.commit()
    except sqlite3.Error as e:
        xbmc.log(f"Failed to vacuum data from the sqlite table: {e}", xbmc.LOGINFO)
    finally:
        try:
            if con:
                con.close()
        except sqlite3.Error:
            pass


addon_database()


xbmc.sleep(1000)
xbmcgui.Dialog().notification("Database", "[COLOR cornflowerblue]Addons33[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/database.webp', sound=False)
xbmc.sleep(1000)
# Official repositories only (default)
# xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"addons.updatemode","value":0}}')
# Any repositories
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"addons.updatemode","value":1}')




# xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')
# xbmcgui.Dialog().notification("Add-ons Updates...", "[COLOR green]ON[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/auto4.png', sound=False)
# xbmc.sleep(20000)
# xbmc.executebuiltin('UpdateLocalAddons()')
# xbmc.executebuiltin('UpdateAddonRepos()')
# xbmc.executebuiltin('ActivateWindow(AddonBrowser)')


# Tk
# xbmc.sleep(50000)
# enable_addons()



# Anyrepositories
    # xbmc.executebuiltin("Action(Close)")
# xbmc.executebuiltin("ActivateWindowAndFocus(SystemSettings, -195, )")
# xbmc.sleep(500)
# xbmc.executebuiltin('SendClick(-173)')
# xbmc.sleep(500)
# xbmc.executebuiltin('SendClick(-145)')
# xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"addons.updatemode","value":1}}')
# xbmc.sleep(500)
# xbmc.executebuiltin("Action(Close)")
# xbmc.executebuiltin('Action(Back)')
# xbmc.executebuiltin('Dialog.Close(all,true)')
# xbmc.executebuiltin('ActivateWindow(10000)')
    

    # while xbmc.getCondVisibility("Window.IsVisible(ServiceSettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        # xbmc.sleep(100)
    # xbmc.executebuiltin("Action(Play)")

