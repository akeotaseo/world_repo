import re
import xbmcaddon
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

def Menu():
	addDir('Latest Videos', 'https://xcum.com/', 31, 'special://home/addons/plugin.video.xxx/resources/art/xcum.png')
	addDir('Categories',    'https://xcum.com/', 32, 'special://home/addons/plugin.video.xxx/resources/art/xcum.png')

def Browse(url):
	r = OpenURL(url)
	m = re.compile('<div class="thumb">(.+?)</div>').findall(r)
	for item in m:
		
		try:    title = re.compile('<span class="inf"><span>(.+?)</span>').findall(item)[0]
		except: title = re.compile('button></button><div><b>(.+?)</b>').findall(item)[0]
		
		url   = re.compile('<a href="(.+?)"').findall(item)[0]
		import random
		random_id = random.randint(0,1000000)
		url = '%s&random_id=%s' % (url, str(random_id))
		
		try:    thumb = re.compile('<img data-original="(.+?)"').findall(item)[0]
		except: thumb = re.compile('<video playsinline poster="(.+?)" ').findall(item)[0]
		
		try:    time = re.compile('</span><span.+?/span><span>(.+?)</span><span.+?/span></span></a>').findall(item)[0]
		except: time = re.compile('<span class="duration">(.+?)</span>').findall(item)[0]
		time = time.replace('<span>', '')
		time = time.replace('</span>', '')
		
		if Setting('show_time') == 'true': title = '[B](%s)[/B] %s' % (time, title)
		
		addVideo(title, url, 33, thumb)
	n = re.compile('rel="canonical"><link href="(.+?)" rel="next">').findall(r)
	for page in n:
		addDir('Next page >', page, 31, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	Common.SetView()
		
def Categories(url):
	r = OpenURL(url)
	m = re.compile('<li><a href="(.+?)"><span>(.+?)</span></a></li>').findall(r)
	for url, title in m:
		addDir(title, 'https://xcum.com' + url, 31, 'special://home/addons/plugin.video.xxx/resources/art/xcum.png')
	
def PlayStream(url):
	if 'random_id=' in url:
		url = re.compile('(.+?)&random_id').findall(url)[0]
	r = OpenURL(url)
	m = re.compile('<source.+?src="(.+?)" title="(.+?)" type="video/mp4" />').findall(r)
	for stream_url, quality in m:
		if quality == '1080p':  Play(stream_url)
		elif quality == '720p': Play(stream_url)
		elif quality == '480p': Play(stream_url)
		elif quality == '360p': Play(stream_url)
		else: Play(stream_url)