﻿import xbmc, xbmcgui
xbmc.executebuiltin('Dialog.Close(all,true)')
xbmcgui.Dialog().notification("[B][COLOR yellow]KODIvertiDO[/COLOR][/B]", "IPTV", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/KODIvertiDO.gif')

def DialogKODIvertiDO():




    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=yellow]~ KODIvertiDO ~[/COLOR][/B]', 
['[B][CAPITALIZE][COLOR white]Canal 1 [I]Tv.Muchos paises[/I][/COLOR][/CAPITALIZE][/B]',
 '[B][CAPITALIZE][COLOR white]Canal 2 [I]Tv.Muchos paises.Gracias [COLOR orangered]AF1CIONADOS[/I][/COLOR][/CAPITALIZE][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.KODIvertiDO/?action=iptv_fran_opc&extra=1&page&plot&thumbnail=https%3a%2f%2fi.postimg.cc%2fm2tT1bYP%2fIMG-20230706-WA0006.jpg&title=%5bB%5d%5bCAPITALIZE%5d%5bCOLOR%20white%5d.Canal%201%20%5bI%5dTv.Muchos%20paises%5b%2fI%5d%5b%2fCOLOR%5d%5b%2fCAPITALIZE%5d%5b%2fB%5d&url")')
    xbmcgui.Dialog().notification("[B][COLOR orange]Keep calm and just wait[/COLOR][/B]", "[COLOR green]Περιμένετε...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/Pleasewait.png')
    xbmc.sleep(12000)
    xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png')
    xbmc.sleep(4000)

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.KODIvertiDO/?action=ace7&extra&page&plot&thumbnail=https%3a%2f%2fi.postimg.cc%2fm2tT1bYP%2fIMG-20230706-WA0006.jpg&title=%5bB%5d%5bCAPITALIZE%5d%5bCOLOR%20white%5d.Canal%202%20%5bI%5dTv.Muchos%20paises.Gracias%20%5bCOLOR%20orangered%5dAF1CIONADOS%5b%2fI%5d%5b%2fCOLOR%5d%5b%2fCAPITALIZE%5d%5b%2fB%5d&url")')
    xbmcgui.Dialog().notification("[B][COLOR orange]Keep calm and just wait[/COLOR][/B]", "[COLOR green]Περιμένετε...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/Pleasewait.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png')
    xbmc.sleep(4000)

DialogKODIvertiDO()

