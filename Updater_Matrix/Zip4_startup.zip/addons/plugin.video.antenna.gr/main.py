# -*- coding: utf-8 -*-
import os
import xbmcvfs
import xbmcaddon
import json
import time
import urllib.request
import sys
from urllib.parse import parse_qsl
import xbmcgui
import xbmc
from tulip import directory, control
from tulip.url_dispatcher import urldispatcher

# -------------------------------------------------------------------
# ΕΦΕΔΡΙΚΑ LINKS (BACKUPS) ΣΕ ΠΕΡΙΠΤΩΣΗ ΠΟΥ ΣΚΑΣΕΙ ΤΟ API ΤΟΥ ANT1
# -------------------------------------------------------------------
BACKUP_LINKS = {
    'live': 'https://mcdn.antennaplus.gr/live/media0/Ant1/HLS/Ant1.m3u8',
    'livemak': 'https://panel.gwebstream.eu:19360/tv100skg/720p.m3u8',
    'livecomedy': 'https://mcdn.antennaplus.gr/live/media0/Comedy/HLS/Comedy.m3u8',
    'livedrama': 'https://mcdn.antennaplus.gr/live/media0/Drama/HLS/Drama.m3u8'
}


@urldispatcher.register('root')
def root():
    addon_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
    
    self_list = [
        {'title': '[B]ANT1 Live[/B]', 'action': 'play', 'isFolder': 'False', 'icon': os.path.join(addon_path, 'media', 'ANT1_wite.png'), 'url': 'live'},
        {'title': '[B]MAK TV Live[/B]', 'action': 'play', 'isFolder': 'False', 'icon': os.path.join(addon_path, 'media', 'MAKEDONIA_TV_wite.png'), 'url': 'livemak'},
        {'title': '[B]ANT1 Comedy Live[/B]', 'action': 'play', 'isFolder': 'False', 'icon': os.path.join(addon_path, 'media', 'ANT1_comedy.png'), 'url': 'livecomedy'},
        {'title': '[B]ANT1 Drama Live[/B]', 'action': 'play', 'isFolder': 'False', 'icon': os.path.join(addon_path, 'media', 'ANT1_drama.png'), 'url': 'livedrama'}
    ]

    directory.add(self_list, content='videos')


import http.cookiejar

def get_live_url(channel_id):
    """Φέρνει το m3u8 link, μαζεύοντας πρώτα τα Cookies σαν πραγματικός browser"""
    window = xbmcgui.Window(10000)
    cache_url_key = 'ant1_url_cache_' + channel_id
    cache_time_key = 'ant1_time_cache_' + channel_id
    
    cached_url = window.getProperty(cache_url_key)
    cached_time = window.getProperty(cache_time_key)
    current_time = time.time()
    
    if cached_url and cached_time:
        if (current_time - float(cached_time)) < 1800:
            return cached_url

    # User-Agent
    ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    
    # 1. Φτιάχνουμε  τα Cookies
    cj = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    
    ref_page = 'Live' if channel_id == 'live' else channel_id
    main_url = 'https://www.antenna.gr/{}'.format(ref_page)
    
    # 2. Χτυπάμε την κεντρική πόρτα (main_url) για να πάρουμε τα Cookies της Cloudflare/ΑΝΤ1
    try:
        req_main = urllib.request.Request(main_url)
        req_main.add_header('User-Agent', ua)
        req_main.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
        opener.open(req_main)
    except Exception as e:
        xbmc.log("ANT1 Player Main Page Cookie Error: " + str(e), xbmc.LOGERROR)

    # 3. χτυπάμε το API έχοντας τα Cookies γεμάτα στο "opener"
    api_url = 'https://www.antenna.gr/templates/data/{}?cache={}'.format(channel_id, int(time.time() * 1000))
    req_api = urllib.request.Request(api_url)
    
    req_api.add_header('User-Agent', ua)
    req_api.add_header('Accept', 'application/json, text/javascript, */*; q=0.01')
    req_api.add_header('X-Requested-With', 'XMLHttpRequest')
    req_api.add_header('Referer', main_url)
    
    try:
        # Χρησιμοποιούμε το opener που έχει τα Cookies, ΟΧΙ το σκέτο urlopen
        with opener.open(req_api) as response:
            content = response.read().decode('utf-8')
            if content:
                data = json.loads(content)
                if data and 'url' in data:
                    fresh_url = data['url']
                    window.setProperty(cache_url_key, fresh_url)
                    window.setProperty(cache_time_key, str(current_time))
                    return fresh_url
    except Exception as e:
        xbmc.log("ANT1 Player API Error: " + str(e), xbmc.LOGERROR)
        pass
        
    return None


@urldispatcher.register('play', ['url'])
def play(url):
    
    # Aυτόματο STOP για να μην τρώμε IP ban στο ζάπινγκ
    if xbmc.Player().isPlaying():
        xbmc.Player().stop()
        xbmc.sleep(500)

    channel_id = url if url in BACKUP_LINKS else 'live'

    # 1. Προσπάθεια να πάρουμε το ΕΠΙΣΗΜΟ HD link
    dynamic_url = get_live_url(channel_id)
    
    if dynamic_url:
        final_url = dynamic_url
    # 2. Αν αποτύχει το επίσημο, ψάχνουμε Backup Link
    elif BACKUP_LINKS.get(channel_id):
        final_url = BACKUP_LINKS[channel_id]
        xbmcgui.Dialog().notification('ANT1 Player', 'Χρήση εφεδρικής ροής (Backup)', xbmcgui.NOTIFICATION_INFO, 3000)
    # 3. Αν αποτύχουν όλα, τερματίζει ειρηνικά
    else:
        xbmcgui.Dialog().notification('ANT1 Player', 'Αποτυχία φόρτωσης ροής', xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    # Η "ΑΣΠΙΔΑ" ΣΤΟ ΤΕΛΙΚΟ ΒΙΝΤΕΟ
    if 'm3u8' in final_url and '|' not in final_url:
        final_url += '|Referer=https://www.antenna.gr/&Origin=https://www.antenna.gr&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'

    dash = ('.m3u8' in final_url or '.mpd' in final_url) and control.kodi_version() >= 18.0
    meta = {'title': 'ANT1 Channels'}

    directory.resolve(
        final_url, dash=dash, meta=meta,
        mimetype='application/vnd.apple.mpegurl' if 'm3u8' in final_url else None,
        manifest_type='hls' if 'm3u8' in final_url else None
    )


def main():
    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get('action', 'root')
    urldispatcher.dispatch(action, params)

if __name__ == '__main__':
    main()