import sys
import os
import json
import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
from xbmcgui import ListItem
from xbmcvfs import translatePath
from routing import Plugin

from urllib.parse import quote
from datetime import datetime
from dateutil.tz import gettz, tzlocal

from resources.lib.arenavisionl import ArenaVision

addon = xbmcaddon.Addon()
plugin = Plugin()
plugin.name = addon.getAddonInfo("name")
ADDON_DATA_DIR = translatePath(addon.getAddonInfo("path"))
ICON = os.path.join(ADDON_DATA_DIR, "resources", "icon.png")
USER_DATA_DIR = translatePath(addon.getAddonInfo("profile"))
if not os.path.exists(USER_DATA_DIR):
    os.makedirs(USER_DATA_DIR)

av = ArenaVision(USER_DATA_DIR)


@plugin.route("/")
def root():
    list_items = []

    li = ListItem("Events", offscreen=True)
    url = plugin.url_for(events)
    list_items.append((url, li, True))

    li = ListItem("Channels", offscreen=True)
    url = plugin.url_for(channels)
    list_items.append((url, li, True))

    li = ListItem("Cache channels", offscreen=True)
    url = plugin.url_for(cache_channels)
    list_items.append((url, li, False))

    xbmcplugin.addDirectoryItems(plugin.handle, list_items)
    xbmcplugin.endOfDirectory(plugin.handle)


@plugin.route("/play.pvr")
def play():
    channel_id = int(plugin.args["channel_id"][0])
    channel = av.get_channel_by_id(channel_id)
    if not (channel.ace_cid or channel.ace_url):
        channel = av.resolve_channel(channel)
    if channel.ace_url:
        plugin_acelive = addon.getSetting("plugin_acelive")
        url = plugin_acelive.format(url=quote(channel.channel.ace_url, ""))
    elif channel.ace_cid:
        plugin_acestream = addon.getSetting("plugin_acestream")
        url = plugin_acestream.format(cid=quote(channel.ace_cid, ""))
    li = ListItem(path=url)
    li.setArt({"thumb": ICON, "icon": ICON})
    xbmcplugin.setResolvedUrl(plugin.handle, True, li)


@plugin.route("/play_event.pvr")
def play_event():
    event_id = int(plugin.args["event_id"][0])
    event = av.get_event_by_id(event_id)

    channels = []
    for ch in event.channels:
        channels.append((ch.channel_id.channel_id, "{0} {1}".format(ch.channel_id.title, ch.title)))
    if len(channels) > 1:
        dialog = xbmcgui.Dialog()
        ret = dialog.select("Choose Channel", [t[1] for t in channels])
        if ret >= 0:
            selected = channels[ret][0]
        else:
            return
    else:
        selected = channels[0][0]

    url = plugin.url_for(play, channel_id=selected)
    li = ListItem(path=url)
    li.setArt({"thumb": ICON, "icon": ICON})
    xbmcplugin.setResolvedUrl(plugin.handle, True, li)


@plugin.route("/channels")
def channels():
    list_items = []
    for ch in av.get_channels():
        if ch.events:
            ev_title = ch.events[0].title
            label = "{0} {1}".format(ch.title, ev_title)
        else:
            label = ch.title
        li = ListItem(label, offscreen=True)
        li.setInfo(type="Video", infoLabels={"Title": ch.title, "mediatype": "video"})
        li.setProperty("IsPlayable", "true")
        li.setArt({"thumb": ICON, "icon": ICON})
        url = plugin.url_for(play, channel_id=ch.channel_id)
        list_items.append((url, li, False))
    xbmcplugin.addDirectoryItems(plugin.handle, list_items)
    xbmcplugin.endOfDirectory(plugin.handle)


@plugin.route("/cache_channels")
def cache_channels():
    channels = av.get_channels()
    count = channels.count()
    dialog = xbmcgui.DialogProgress()
    dialog.create("ArenaVision", "Caching Channels...")
    c = 1
    for ch in channels:
        if not (ch.ace_cid or ch.ace_url):
            channel = av.resolve_channel(ch)
        dialog.update(c * 100 // count)
        c += 1
    dialog.close()
    dialog = xbmcgui.Dialog()
    dialog.notification(plugin.name, f"Chached {count} channels", xbmcgui.NOTIFICATION_INFO, 3000)
    return


@plugin.route("/events")
def events():
    """Find local timezone"""
    try:
        locale_timezone = json.loads(
            xbmc.executeJSONRPC(
                '{"jsonrpc": "2.0", "method": "Settings.GetSettingValue", "params": {"setting": "locale.timezone"}, "id": 1}'
            )
        )
        if "result" in locale_timezone:
            if locale_timezone["result"]["value"]:
                local_tzinfo = gettz(locale_timezone["result"]["value"])
            else:
                local_tzinfo = tzlocal()
        else:
            local_tzinfo = tzlocal()
    except:
        local_tzinfo = ""
    local_format = xbmc.getRegion("time").replace(":%S", "")

    list_items = []
    for event in av.get_events():
        _time = datetime.fromtimestamp(event.event_time, tz=gettz("UTC"))
        time_local = _time.astimezone(local_tzinfo).strftime(local_format)

        channel_lang = set()
        for ch in event.channels:
            channel_lang.add(ch.title)

        label = "[{0}] [COLOR=purple]{1}[/COLOR] [COLOR=yellow]{2}[/COLOR][CR]{3} {4}".format(
            time_local, event.sport, event.competition, event.event, "".join(channel_lang)
        )
        li = ListItem(label, offscreen=True)
        li.setInfo(type="Video", infoLabels={"Title": event.event, "mediatype": "video"})
        li.setProperty("IsPlayable", "true")
        li.setArt({"thumb": ICON, "icon": ICON})
        url = plugin.url_for(play_event, event_id=event.id)
        list_items.append((url, li, False))

    xbmcplugin.addDirectoryItems(plugin.handle, list_items)
    xbmcplugin.endOfDirectory(plugin.handle)


if __name__ == "__main__":
    plugin.run(sys.argv)
    del av
