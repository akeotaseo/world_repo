﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def DialogWolf():
        choice = xbmcgui.Dialog().yesno('[COLOR grey]Wherethemonsterslive/encryptic[/COLOR]', 'Η τελευταία ενημερώση των πρόσθετων[CR][B][COLOR white]TheOath Forked, Genesis, Bad Wolf, No Lives Matter,[CR]Wolf Pack, Frankenstein[/COLOR][/B][CR](κ. α απο τα αποθετήρια Wherethemonsterslive/encryptic),[CR]τα κάνει απεγκατάσταση, βγάζοντας σχετικό μήνυμα στην οθόνη, εφόσον έχετε εγκατεστημένο το πρόσθετο [B][COLOR purple]THE CREW[/COLOR][/B][CR][CR]Για να συνεχίσετε πατήστε [B][COLOR orange]Wolf[/COLOR][/B][CR]',
                                        nolabel='[B][COLOR white]Πίσω[/COLOR][/B]',yeslabel='[B][COLOR orange]Wolf[/COLOR][/B]')

        if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Wolf/Wolf.py")'),]

DialogWolf()
