# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests

class VikiStream:
    def __init__(self):
        self.ua = "Dalvik/2.1.0 (Linux; U; Android 5.1.1; AFTT Build/LVY48F)"
        self.base = "https://vikistream.com/embed2.php?player=desktop&live={}"

    def grab(self, channel):
        headers = {'User-Agent': self.ua}
        headers.update({'Referer': 'https://cdn1.link/'})
        url = self.base.format(channel)
        resp = requests.get(url, headers=headers).text
        resp = resp.replace('\n', '').split("return(")[1].split(".join")[0]
        hlsUrl = "".join(eval(resp)).replace("\\/", "/")
        headers.update({'Referer': 'https://vikistream.com/'})
        return hlsUrl, headers