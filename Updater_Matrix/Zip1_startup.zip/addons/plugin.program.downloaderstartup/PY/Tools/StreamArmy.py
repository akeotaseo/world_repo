import os, xbmc, xbmcvfs, xbmcgui


def streamarmy():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Fix NemesisAio[/COLOR]', 'Επιλέξτε [COLOR green]Remove Data[/COLOR][CR]Στην συνέχεια ανοίξτε τo πρόσθετo [COLOR orange]NemesisAio[/COLOR][CR]απο το SubMenu στις κατηγορίες[CR]MOVIES & TV (StreamArmy) - SPORTS (Live Now)',
                                        nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]')

        if choice == 1: xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader/settings.xml')


streamarmy()
