# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"

Baseurl = 'https://xrysoi.pro/'

def menu():
    addDir('[COLOR white] Πρόσφατες καταχωρήσεις[/COLOR]', Baseurl + 'category/tainiesonline/2022/', 44, 'https://xrysoi.pro/wp-content/uploads/2015/03/logo-GM.png', FANART, '')
    addDir('[COLOR white] Ανά έτος[/COLOR]', 'Baseurl', 46, 'https://xrysoi.pro/wp-content/uploads/2015/03/logo-GM.png', FANART, '')
    addDir('[COLOR white] Κατηγορίες[/COLOR]', 'Baseurl', 47, 'https://xrysoi.pro/wp-content/uploads/2015/03/logo-GM.png', FANART, '')
    addDir('[COLOR white] Αναζήτηση[/COLOR]', Baseurl, 45, 'https://www.freeiconspng.com/uploads/search-icon-png-22.png', FANART, '')
    views.selectView('menu', 'menu-view')

def xrysoimovies(url): #44
    p = client.request(url)
    try:
        m = re.compile('<div class=moviefilm>.+?<a href=(.+?)>.+?<img src=(.+?) alt="(.+?)".+?title=').findall(p)
    except IndexError:
        m = re.compile('<div class="moviefilm">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)".+?title=').findall(p)
    for url, icon, name in m:
        name = name.split('&#038;')[0].split('&#8217;')[0].split('&#8211;')[0]
        icon = icon.replace('-119x125', '')
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 43, icon, FANART, '')
    try:
        m = re.compile('class=nextpostslink rel=next href=(.+?)>»</a>').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 44, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
    views.selectView('movies', 'movie-view')

def get_links(name, url, iconimage, description): #45
    p = client.request(url)
    m = re.compile('href=(.+?)\s+').findall(p)
    link_list = ['aparat', 'flashx',  'hdvid', 'vidd',
                 'vidoza', 'vidlox', 'estream', 'clipwatching', 'thevideo', 'vidzi']
    for url in m:
        if any(x in url for x in link_list):
            name = url
            name = name.split('.')[0]
            name = name.replace('http://', '[B]Πάροχος...[/B]')
            name = name.replace('https://', '[B]Πάροχος...[/B]')
            addDir(name, url, 100, iconimage, FANART, str(description))
    else:
        m2 = re.compile('<iframe.+?src=(.+?)\s+').findall(p)
        for url in m2:
            if 'youtube' in url:
                Trailer = '[COLOR=lime]Τρέιλερ[/COLOR]'
                addDir(Trailer, url, 100, iconimage, FANART, str(description))

def search(url):
    keyb = xbmc.Keyboard('', 'Search')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = 'https://xrysoi.pro/?s=' + search
        xrysoimovies(url)

