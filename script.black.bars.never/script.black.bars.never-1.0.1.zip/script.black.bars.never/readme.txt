This is an addon that eliminates black bars, whether hardcoded or the video is just wide format

===================================================================
                           Installation
===================================================================

Launch Kodi >> Add-ons >> Get More >> .. >> Install from zip file

Feel free to ask any questions, submit feature/bug reports

Enjoy!