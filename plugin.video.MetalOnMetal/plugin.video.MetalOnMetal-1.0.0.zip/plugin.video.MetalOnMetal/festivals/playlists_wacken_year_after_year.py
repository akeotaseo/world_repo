import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_festivals


setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="

id_YEAR_2006 = "PLPfPNs01OQC3RGPlJiBauUJM4qDs7jiXZ"
id_YEAR_2007 = "PLPfPNs01OQC1175sDqcu88wbVgtuFQhIx"
id_YEAR_2008 = "PLPfPNs01OQC1GBti0v9shxdl6WHDm6cSz"
id_YEAR_2009 = "PLPfPNs01OQC37p9V0YXCV49H_Y3KzI83E"
id_YEAR_2011 = "PLPfPNs01OQC0SWNXRaqTlMKVhucD6OSVd"
id_YEAR_2012 = "PLPfPNs01OQC1x1v91zv0sYZ89Ld3zE-rg"
id_YEAR_2013 = "PLPfPNs01OQC12Ip5gcbtsZqHfCVqvupvJ"
id_YEAR_2014 = "PLPfPNs01OQC3WpWK6MAfKTUsJDuZ4nwvM"
id_YEAR_2015 = "PLPfPNs01OQC3T_ZdSPPC0s7gz2vzP7wIw"
id_YEAR_2016 = "PLPfPNs01OQC22ikUUW2BOzge27-VAEwQf"
id_YEAR_2017 = "PLPfPNs01OQC2ncq-F56xNLHfAX0v91TP4"
id_YEAR_2018 = "PLPfPNs01OQC3lGQh5ge9x8XB2Rpqt0V2n"
id_YEAR_2019 = "PLPfPNs01OQC2KzJbYebTDyo2z7J3D-Ss0"



if usa_duffyou:  ##Usamos plugin Duff You
    YEAR_2006 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2006).encode('utf-8')).decode('utf-8')
    YEAR_2007 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2007).encode('utf-8')).decode('utf-8')
    YEAR_2008 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2008).encode('utf-8')).decode('utf-8')
    YEAR_2009 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2009).encode('utf-8')).decode('utf-8')
    YEAR_2011 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2011).encode('utf-8')).decode('utf-8')
    YEAR_2012 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2012).encode('utf-8')).decode('utf-8')
    YEAR_2013 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2013).encode('utf-8')).decode('utf-8')
    YEAR_2014 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2014).encode('utf-8')).decode('utf-8')
    YEAR_2015 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2015).encode('utf-8')).decode('utf-8')
    YEAR_2016 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2016).encode('utf-8')).decode('utf-8')
    YEAR_2017 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2017).encode('utf-8')).decode('utf-8')
    YEAR_2018 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2018).encode('utf-8')).decode('utf-8')
    YEAR_2019 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2019).encode('utf-8')).decode('utf-8')
else:  ##Usamos pluin YouTube
    YEAR_2006 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2006)
    YEAR_2007 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2007)
    YEAR_2008 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2008)
    YEAR_2009 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2009)
    YEAR_2011 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2011)
    YEAR_2012 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2012)
    YEAR_2013 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2013)
    YEAR_2014 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2014)
    YEAR_2015 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2015)
    YEAR_2016 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2016)
    YEAR_2017 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2017)
    YEAR_2018 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2018)
    YEAR_2019 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2019)




def playlists(params):
    logo=logos_festivals.wacken(params)

          
    plugintools.add_item(  
        title="Wacken 2019",
        url=YEAR_2019,
        thumbnail=logo, folder=True ) 
          
    plugintools.add_item(  
        title="Wacken 2018",
        url=YEAR_2018,
        thumbnail=logo, folder=True ) 
             
    plugintools.add_item(  
        title="Wacken 2017",
        url=YEAR_2017,
        thumbnail=logo, folder=True ) 
             
    plugintools.add_item(  
        title="Wacken 2016",
        url=YEAR_2016,
        thumbnail=logo, folder=True ) 
          
    plugintools.add_item(  
        title="Wacken 2015",
        url=YEAR_2015,
        thumbnail=logo, folder=True ) 
     
    plugintools.add_item(  
        title="Wacken 2014",
        url=YEAR_2014,
        thumbnail=logo, folder=True ) 

    plugintools.add_item(  
        title="Wacken 2013",
        url=YEAR_2013,
        thumbnail=logo, folder=True ) 
          
          
    plugintools.add_item(  
        title="Wacken 2012",
        url=YEAR_2012,
        thumbnail=logo, folder=True ) 
     
    plugintools.add_item(  
        title="Wacken 2011",
        url=YEAR_2011,
        thumbnail=logo, folder=True ) 
          
    plugintools.add_item(  
        title="Wacken 2009",
        url=YEAR_2009,
        thumbnail=logo, folder=True ) 
                  
    plugintools.add_item(  
        title="Wacken 2008",
        url=YEAR_2008,
        thumbnail=logo, folder=True ) 
          
    plugintools.add_item(  
        title="Wacken 2007",
        url=YEAR_2007,
        thumbnail=logo, folder=True ) 
                  
    plugintools.add_item(  
        title="Wacken 2006",
        url=YEAR_2006,
        thumbnail=logo, folder=True ) 




