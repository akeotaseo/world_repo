import os, xbmc, xbmcvfs, xbmcgui, shutil, glob

base_path = xbmcvfs.translatePath('special://home/media/Downloads')

dir_list = glob.iglob(os.path.join(base_path, "CartoonsGR"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)




base_path = xbmcvfs.translatePath('special://home/userdata/addon_data')

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.themoviedb.helper/reconfigured_players"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

        #dir_list = glob.iglob(os.path.join(base_path, "script.tc.artwork"))
#for path in dir_list:
    #if os.path.isdir(path):
        #hutil.rmtree(path)
        
        #dir_list = glob.iglob(os.path.join(base_path, "script.tc.metadata"))
#for path in dir_list:
    #if os.path.isdir(path):
        #shutil.rmtree(path)
        
       # dir_list = glob.iglob(os.path.join(base_path, "repository.thecrew"))
#for path in dir_list:
    #if os.path.isdir(path):
        #shutil.rmtree(path)


#base_path = xbmc.translatePath('special://home/addons')

#dir_list = glob.iglob(os.path.join(base_path, "script.tvaddons.debug.log"))
#for path in dir_list:
   # if os.path.isdir(path):
    #    shutil.rmtree(path)

#dialog = xbmcgui.Dialog()
#dialog.ok("[COLOR orange]World build[/COLOR]", "[COLOR white]Delete[/COLOR]")
#xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)')