import xbmc, xbmcgui


def spchannels():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13, click_14, click_15, click_16, click_17)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]  ~ Sports Channels ~[/COLOR][/B]', 
['[COLOR=white]TvOne[/COLOR]    [COLOR=red](OFF...)[/COLOR]',
 '[COLOR=white]TvOne[/COLOR]  (F Sports)    [COLOR=red](OFF...)[/COLOR]',
 '[COLOR=white]TvOne11[/COLOR]    [COLOR=red](OFF...)[/COLOR]',
 '[COLOR=white]TvOne111[/COLOR]    [COLOR=red](OFF...)[/COLOR]',
 '[COLOR=white]TvOne1112[/COLOR]    [COLOR=red](OFF...)[/COLOR]',
 '[COLOR=white]TvOne112[/COLOR]    [COLOR=red](OFF...)[/COLOR]',

 '[COLOR lime]TV Loucos[COLOR yellow] Brasil[/COLOR]',
 '[COLOR=white][COLOR=white]DESPORTO/SPORTS [/COLOR][COLOR=green](Magellan)[/COLOR]',
 '[COLOR=white]**Sports** [/COLOR][COLOR=orange](LiveStreamsPro)[/COLOR]',

 '[COLOR=white]Ζωντανά Κανάλια [COLOR=red]daddylive[/COLOR]  ([COLOR orange]microjen[/COLOR])',

 # '[B][COLOR white]Ζωντανά Κανάλια[/COLOR][/B]  [B][COLORorange]Sport[COLORwhite]HD+[/COLOR][/B]  ([COLOR orange]microjen[/COLOR])',

 # '[B][COLOR white]tv adictos[/COLOR][/B]  (koditv)',
 # '[B]Latin Sports[/B]',

 '[COLOR=white]Elitegol[/COLOR] France [COLOR=purple](vstream)[/COLOR]',

 '[B][I][COLOR white]» [/I][COLOR orange]CANALI LIVE[/COLOR][/B][B]ITA[/B] [COLOR=green](Thegroove360)[/COLOR]',

 # 'AlexDang 4K Sport (playlistloader)',

 '[COLOR deepskyblue]Live Channels List [COLOR skyblue] (A-Z) [COLOR lime](the-loop)[/COLOR]',

 '[COLOR deepskyblue]GR[/COLOR]  ([COLOR red]OFF?...[/COLOR])',
 '[COLOR blue]Ζωντανά Κανάλια (Ελληνικά/Κυπριακά)[/COLOR]  ([COLOR orange]microjen[/COLOR])',
 'спорт  [COLOR red]RU[/COLOR]  (playlistloaderworld)',
 # '[COLOR blue]Ex[/COLOR]-[COLOR red]Yu[/COLOR]  (playlistloaderworld)',
 '[COLORwhite]SPORTS NETWORKS[/COLOR] - FIXED [COLOR red](madtitansports)[/COLOR]'])



    if call:
        if call < 0:
            return
        func = funcs[call-17]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone/list_channels/5")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone/list_sp_channels/5")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone11/list_channels/8")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone111/list_channels/1")')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone1111/list_channels/1")')
    
def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone112/list_channels/38")')


def click_7():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmcgui.Dialog().ok('[COLOR=yellow]BRAZIL[/COLOR]', '1- [COLOR green]Επιλέγουμε την κατηγορία που επιθυμούμε.[/COLOR][CR][CR]2- (f4mTester) [COLOR=lime]play with-->inputstream.ffmpegdirect.[/COLOR]')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvloucosbr")')
    xbmcgui.Dialog().notification("[COLOR lime]TV Loucos[COLOR yellow] Brasil[/COLOR]", "   ", sound=False, icon='https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/Flag_of_Brazil.svg/2560px-Flag_of_Brazil.svg.png')
    xbmc.sleep(4000)  
    xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png')
    

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.Magellan_Matrix/?fanart=https%3a%2f%2fwallpapercave.com%2fwp%2fwp7245862.jpg&mode=1&name=%5bCOLOR%20lime%5d%20%3e%20%5bCOLOR%20yellow%5dDESPORTO%2fSPORTS%20%5b%2fCOLOR%5d&url=https%3a%2f%2fpastebin.com%2fraw%2fz9jHvduv")')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart&mode=1&name=%2a%2aSports%2a%2a&url=https%3a%2f%2fiptv-org.github.io%2fiptv%2fcategories%2fsports.m3u")')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=live_tv")')

# def click_11():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/sporthd?description=Live%20TV%20Channels&iconimage=https%3a%2f%2fraw.githubusercontent.com%2fbugatsinho%2fbugatsinho.github.io%2fmaster%2fplugin.video.sporthdme%2ficon.png&mode=get_livetv&name=%5bB%5d%5bCOLOR%20white%5d%ce%96%cf%89%ce%bd%cf%84%ce%b1%ce%bd%ce%ac%20%ce%9a%ce%b1%ce%bd%ce%ac%ce%bb%ce%b9%ce%b1%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fsporthd.live%2flivetv")')

# def click_11():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.koditv/?extra=%5bB%5d%5bLOWERCASE%5d%5bCAPITALIZE%5d%5bCOLOR%20white%5dTV%20DEPORTES%5b%2fCAPITALIZE%5d%5b%2fLOWERCASE%5d%5b%2fCOLOR%5d%5b%2fB%5d&mode=tv_adictos2&thumbnail=https%3a%2f%2ffx-24.xyz%2fmychannel%2fpublic%2fsub_cat2_images%2f2083924114.png&url=54")')

# def click_11():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.latinsports/")')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vstream/?function=showTV&sFav=showTV&site=elitegol&siteUrl=lecteur%2f&title=Elitegol")')

def click_12():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thegroove360/thegroove/scripters/risroom/path%3DSport_canali.xml")')

# def click_13():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloader/?cache=0&epg&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloader%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5b1%5d&url=https%3a%2f%2fraw.githubusercontent.com%2fkgasaz%2f4kuhd%2fmaster%2fsports-channels-4k.m3u&uuid=885b5b8d-e4d1-4bb1-8713-63d6254a78c2")')

def click_13():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.the-loop/get_list/https://loopaddon.uk/files/k19/xmls/CHANNEL_LIST/1__all_categories.json")')

def click_14():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/GreekChannels_A.py")')

def click_15():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=live_greek")')

def click_16():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloaderworld/?cache=0&epg&iconimage=DefaultTVShows.png&index=32&logos&mode=10&name=SPORT%20%f0%9f%8f%86&url=https%3a%2f%2fmater.com.ua%2fip%2favto.m3u&uuid=0")')

# def click_18():
    # xbmcgui.Dialog().notification("[B][COLOR blue]Ex[/COLOR]-[COLOR red]Yu[/COLOR][/B] m3u8", "[COLOR orange]http://tv.premiumplus.tv:80[/COLOR]", sound=False, icon='https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Former_Yugoslavia_Flag_Map_%28With_Kosovo%29.png/1205px-Former_Yugoslavia_Flag_Map_%28With_Kosovo%29.png')
    # xbmc.sleep(3000)
    # xbmcgui.Dialog().notification("[B][COLOR green]lists / Channels[/COLOR][/B]", "[COLOR orange]They don't always work[/COLOR]", sound=False, icon='special://home/addons/plugin.video.playlistloaderworld/local/doestworkalltime.png')
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloaderworld/?cache=0&epg&iconimage=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloaderworld%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bex%5d&url=special%3a%2f%2fhome%2faddons%2fplugin.video.playlistloaderworld%2flocal%2fEx-Yu.m3u8&uuid=afd6453a-9192-4501-94d0-e891ee109db5")')


def click_17():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.madtitansports/search_json/https://magnetic.website/jet/TVGUIDE/TVGUIDE_Sports Networks.json?dialog=false&query=sports%20networks")')


spchannels()
