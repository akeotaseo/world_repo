from urllib3 import PoolManager
from xbmc import executebuiltin
from xbmcaddon import Addon
from shutil import rmtree
from os.path import exists
from xbmcvfs import translatePath
from json import loads
from resources.lib.kedon import userm
def autorun_addon():
    executebuiltin('UpdateAddonRepos()')
    packages_path = translatePath('special://home/addons/packages')
    if Addon().getSetting('auto_run') == 'true':
        executebuiltin('RunAddon(plugin.video.vnmedia)')
    if Addon().getSetting('auto_noti') == 'true':
        try:
            r = PoolManager(timeout=20.0).request('GET', 'https://speedtest.vn/get-ip-info', headers={'user-agent':userm}).data.decode('utf-8')
            a = ' '.join([c for c in reversed(loads(r).values())])
        except:
            a = 'VNNIC error'
        executebuiltin(f'Notification("KODI VIỆT NAM", {a}, 10000, {Addon().getAddonInfo("icon")})')
    if exists(packages_path):
        try:
            rmtree(packages_path)
        except:
            pass
autorun_addon()