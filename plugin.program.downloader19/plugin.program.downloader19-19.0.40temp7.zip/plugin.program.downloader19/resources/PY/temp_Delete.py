﻿import os, xbmc, xbmcvfs, xbmcgui


def temp_Delete():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Διαγραφή Προσωρινών Αρχείων[/COLOR]', '[COLOR white]Με αυτή την επιλογή θα γίνει διαγραφή του φακέλου[COLOR green] Προσωρινών Αρχείων[/COLOR] και θα πραγματοποιηθεί επαναφόρτωση του προφίλ, με αποτέλεσμα να παγώσει για λίγα δευτερόλεπτα η εικόνα.[CR][CR]Θέλετε να συνεχίσετε ?[/COLOR]',
                                        nolabel='[B][COLOR white]Όχι[/COLOR][/B]',yeslabel='[B][COLOR green]Ναι[/COLOR][/B]')

        if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/resources/PY/temp_DeletelFix.py")'), xbmcgui.Dialog().notification("[B][COLOR orange]Διαγραφή με επιτυχία ![/COLOR][/B]", "[COLOR white]Αναμονή για Reload Profile...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/rp.png'),
                         xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)'),
                         xbmc.sleep(2000),
                         xbmcgui.Dialog().notification("[B][COLOR orange]Reload Profile[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/reloadprofile.png'),]


temp_Delete()
