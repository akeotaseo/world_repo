from codequick import Route, Listitem, Resolver
from resources.lib.kedon import u90, getlinkvnm, tb, quangcao, getlink, referer, stream
from datetime import datetime
import re, sys
bc = u90('bongcam')
@Route.register
def index_bc(plugin, **kwargs):
	yield []
	resp = getlinkvnm(f'https://api.{bc}/v2/match/featured', f"https://{bc}")
	if (resp is not None):
		rd = resp.json()['data']
		for k in rd:
			item = Listitem()
			time = datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M %d-%m')
			cm = k['commentators']
			blv = ' - '.join((h['name'] for h in cm or []))
			ten = f'{time}: {k["name"]} ({blv})' if cm else f'{time}: {k["name"]}'
			ten = f'[B]{ten}[/B]' if k['match_status'] == 'live' else ten
			tenm = f'[COLOR yellow]{ten}[/COLOR]' if k['tournament']['is_featured'] else ten
			item.label = tenm
			item.info['plot'] = tb
			logotour = k['tournament']['logo']
			if logotour:
				item.art['thumb'] = item.art['fanart'] = logotour
			else:
				item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/nba.png'
			item.set_callback(list_bc, k['id'], tenm)
			yield item
	else:
		yield quangcao()
@Route.register
def list_bc(plugin, idk=None, title=None, **kwargs):
	yield []
	if idk is None or title is None:
		pass
	else:
		url = f'https://{bc}/truc-tiep/mkendo-{idk}'
		resp = getlink(url, url, 300)
		if (resp is not None) and ('.m3u8' in resp.text):
			html_content = re.sub(r"(\n\s*//.*)", "", resp.text)
			ref = re.search(r'let base\s*=\s*("|\')([^"\s]+)("|\')', html_content)[2]
			urls_and_names = re.findall(r'"url":"(.*?)".*?"name":"(.*?)"', resp.text)
			result = {name: url for url, name in urls_and_names}
			for name, urlplay in result.items():
				item = Listitem()
				tenm = f'{name} - {title}'
				item.label = tenm
				item.info['plot'] = tb
				item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/nba.png'
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{stream(urlplay)}{referer(ref)}', tenm, '')
				yield item
		else:
			yield quangcao()