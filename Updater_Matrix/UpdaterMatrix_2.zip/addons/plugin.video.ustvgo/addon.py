# -*- coding: utf-8 -*-
import os
import sys

import urllib
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import urllib3
import re
import json
import random

try:
    from urllib.parse import urlencode, quote_plus, quote, unquote
except ImportError:
    from urllib import urlencode, quote_plus, quote, unquote
    
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.ustvgo')
file_name = addon.getSetting('fname')
path_m3u = addon.getSetting('path_m3u')

mode = addon.getSetting('mode')

def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)

def add_item(ch_name, ch_site):
    li=xbmcgui.ListItem(ch_name)
    li.setProperty("IsPlayable", 'true')
    li.setInfo(type='video', infoLabels={'title': ch_name,'sorttitle': ch_name,'plot': ''})
    li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': '', 'fanart': ''})
    url_ch = build_url({'mode':'play','channel':ch_site})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_ch, listitem=li, isFolder=False)

def channelArrayGen():
    resp = requests.get('https://ustvgo.tv')
    ch_html_1 = re.compile('<ol>(.*)</ol>').findall(resp.text)[0]
    arr_ch_html = ch_html_1.split('</li>')
    ar_chan=[]
    for c in arr_ch_html:
        c_data=re.compile('a href="(.*)">(.*)</a>').findall(c)
        if len(c_data)!=0:
            ar_chan.append([c_data[0][0],c_data[0][1]])
    return ar_chan
    

def channels_gen():
    channels=channelArrayGen()
    for ch in channels:
        add_item(ch[1], ch[0])
    xbmcplugin.endOfDirectory(addon_handle)

def PlayStream(chUrl):
    resp=requests.get(chUrl)
    player_url_qry=re.compile('src=\'/player.php\?(.*)\'').findall(resp.text)[0]
    if len(player_url_qry)!=0:
        player_url='https://ustvgo.tv/player.php?'+ player_url_qry
        hdrs = {"Referer":"https://ustvgo.tv/"}
        resp_plr=requests.get(player_url,headers=hdrs)
        url_stream_ar=re.compile('hls_src=\'(.*)\';').findall(resp_plr.text)
        if len(url_stream_ar)!=0:
            url_stream=url_stream_ar[0]
            play_item = xbmcgui.ListItem(path=url_stream)
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
        else:
            xbmcgui.Dialog().notification('USTVGO', 'NEED USA IP VPN', xbmcgui.NOTIFICATION_INFO)

            
def generate_m3u(c):
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('USTVGO', 'Set the file name and target directory.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('USTVGO', 'Generate a list.', xbmcgui.NOTIFICATION_INFO)
    data = '#EXTM3U\n'
    for item in c:
        channelId = item[0]
        channelName = item[1]
        data += '#EXTINF:0 tvg-id="%s" group-title="USTVGO",%s\nplugin://plugin.video.ustvgo?action=play&channel=%s\n' % (channelName,channelName,channelId)

    f = xbmcvfs.File(path_m3u + file_name, 'w')
    f.write(data)
    f.close()
    xbmcgui.Dialog().notification('USTVGO', 'A list has been generated M3U.', xbmcgui.NOTIFICATION_INFO)

mode = params.get('mode', None)
action = params.get('action', '')

if action:
    if action=='play':
        channel_id = params.get('channel', '')
        PlayStream(channel_id)
        
    if action == 'BUILD_M3U':#
        ar_chan=channelArrayGen()   
        generate_m3u(ar_chan)#
    
else:

    if not mode:
        channels_gen()
        
    elif mode == 'play':
        channel_id = params.get('channel', '')
        PlayStream(channel_id)
        
    