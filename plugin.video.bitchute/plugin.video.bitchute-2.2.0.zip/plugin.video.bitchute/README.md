# plugin.video.bitchute

## NOTE: This add-on now targets KODI 19. 
## There is also a "KODI-LEIA" branch which, barring any changes by BitChute, should work for the moment. 

Welcome to my Bitchute addon for KODI

Watch Bitchute within KODI. You will need a login user id and password from the www.bitchute.com website. 

Once you have the login, either:

Select the settings option for this add-on
or
Open the add-on and select the first option on the main menu "Set your Bitchute user"

Enter your bitchute user id and password in to the settings panel. Select OK

Once you have completed your user details, you will then be able to use the options for subscriptions, notifications, favourites and watch later.

The plugin has to rely on scraping using the Beautiful Soup 4 library because there is no documented API for Bitchute. If anyone knows the API, and where 
the documentation is... feel free to let me know in the github issues. If there is a proper authentication mechanism (OAUTH2 for example) then it could remove
the need to store user_ids and password in KODI settings and making working with the site much easier and more reliable.

Please note: I don't care if you have a problem with Bitchute and its stance on free speech. That's your choice. Use something else instead.

## Installation
KODI repos like fusion often scrape old development version with bugs and then never update them. The current master branch here is tested and works.

If you are having problems with a repo version you can install a local version yourself:

Download the zip file from here and install it yourself. Code tab -> Green Code button -> Download zip. Then use the "Install from zip file" in the KODI addons menu.

You may need to have unknown sources set in KODI settings. Settings -> System -> Addons -> Unknown sources.

## Disclaimer

It's yours. If you break it, you can keep the pieces. If you want to add stuff feel free. You just need to follow the GPL and make your improvements available to others.

Like KODI, this add-in code is free and will remain so. If you'd like to support work on it, then it would be appreciated. Throw a few satoshis (Bitcoin) to:

![BC](assets/bcaddress.png)

3LNnxm4NbpcSs1eqSnndvx83zCx6mwqf7K
