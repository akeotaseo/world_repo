﻿import xbmc

def subsettings():
    if xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin("Action(Close)")
        xbmc.sleep(100)
        xbmc.executebuiltin("ActivateWindowAndFocus(Playersettings, -195,)")

    while xbmc.getCondVisibility("Window.IsVisible(playersettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")



    if not xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin("Action(Close)")
        xbmc.sleep(100)
        xbmc.executebuiltin("ActivateWindowAndFocus(Playersettings, -195,)")
        xbmc.sleep(100)
        xbmc.executebuiltin("Action(Pause)")

    while xbmc.getCondVisibility("Window.IsVisible(playersettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)

    xbmc.executebuiltin("Action(Play)")

subsettings()
