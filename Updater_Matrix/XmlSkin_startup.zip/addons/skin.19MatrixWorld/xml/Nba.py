import xbmc, xbmcgui



def Nba():
    funcs = (click_1, click_2,)
    call = xbmcgui.Dialog().select('[B][COLOR=blue]       NBA[/COLOR][/B]',
['[COLOR=blue]NBA[/COLOR] (The Loop)',

 '[COLOR=orange]NBA[/COLOR] (MyIPTV)'


 ])




    if call:
        if call < 1:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('RunScript("special://home/addons/skin.19MatrixWorld/xml/Dialog Spor/DialogLoopNBA.py")')
def click_2():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmcgui.Dialog().ok('[COLOR=orange]NBA[/COLOR] (MyIPTV)', '[COLOR lime]Επιλέγουμε URL και στη συνέχεια... στα [B][COLOR white]Ζωντανά Κανάλια[/COLOR][/B] ψάχνουμε την κατηγορία που μας ενδιαφέρει.[CR]Σε περίπτωση [COLOR white]Αποτυχίας Σύνδεσης[/COLOR], δοκιμάζουμε άλλο URL')
    xbmcgui.Dialog().notification("[B][COLOR darkorange]GKoBu Tools [/COLOR][/B]", "My[COLOR orangered]IPTV[/COLOR] iLoader", sound=False, icon='https://styles.redditmedia.com/t5_28w7mp/styles/communityIcon_j5m34lvey9041.jpg')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5cxcodes.jpg&mediatype=video&mode=get_remote_xcodes&name=World%20Build%20Telegram%20x-treme%20codes%20(ABN)&name2&page&season_number&url=%7b%22url%22%3a%20%22https%3a%2f%2fraw.githubusercontent.com%2fakeotaseo%2fworld_repo%2fmain%2fUpdater_Matrix%2fXML2%2fABN.txt%22%7d")')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png')
    



Nba()
