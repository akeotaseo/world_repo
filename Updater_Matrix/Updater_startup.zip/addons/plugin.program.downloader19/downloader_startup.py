﻿import os, glob, xbmc, xbmcgui, xbmcvfs, xbmcaddon, shutil
from updatervar import *
from resources.lib.GUIcontrol import txt_updater
from resources.lib.modules import db, addonsEnable
from resources.lib.modules.addonsEnable import enable_addons
from resources.lib.GUIcontrol.txt_updater import get_skinshortcutsversion, get_addonsrepos

skinshortcuts_version = get_skinshortcutsversion()
addons_repos_version = get_addonsrepos()
exists = os.path.exists

#addon_themoviedb       = xbmcaddon.Addon('plugin.video.themoviedb.helper')
#setting_themoviedb     = addon_themoviedb.getSetting
#setting_set_themoviedb = addon_themoviedb.setSetting

#addon_scrubsv2       = xbmcaddon.Addon('plugin.video.scrubsv2')
#setting_scrubsv2     = addon_scrubsv2.getSetting
#setting_set_scrubsv2 = addon_scrubsv2.setSetting

Database_Addons33 = [('repository.Worldolympic', 'repository.World'),
                     ('repository.World', 'repository.World'),
                     ('repository.Worldrepo', 'repository.World')]

addons_list_installation = ['repository.test', 'plugin.video.test']


delete_files = ['plugin.video.test', 'repository.test', UpdaterMatrix_path19]


#base_path = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.themoviedb.helper')

#dir_list = glob.iglob(os.path.join(base_path, "players"))
#for path in dir_list:
    #if os.path.isdir(path):
        #shutil.rmtree(path)

#dir_list = glob.iglob(os.path.join(base_path, "reconfigured_players"))
#for path in dir_list:
    #if os.path.isdir(path):
        #shutil.rmtree(path)




def Updater_Matrix():
    BG.create(Dialog_U1, Dialog_U2)
    xbmc.sleep(1000)
    BG.update(5, Dialog_U1, Dialog_U6)
    xbmc.sleep(3000)
    BG.update(15, Dialog_U1, Dialog_U2)
    check_addons_list()
    check_del_dir()
    xbmc.sleep(1000)




                                ### delete addons ands files ###

                                  #Εγκατάσταση νέων repository'
    if exists(UpdaterMatrix_path2): xbmcvfs.delete(UpdaterMatrix_path2), xbmc.sleep(1000)

                                    #Εγκατάσταση addon_data
    if exists(UpdaterMatrix_path3): xbmcvfs.delete(UpdaterMatrix_path3), xbmc.sleep(1000)

                                  #TheMovieDb Helper players
    #if os.path.exists(UpdaterMatrix_path6): xbmcvfs.delete(UpdaterMatrix_path6), xbmc.sleep(1000)

                                             #skin fix
    #if exists(UpdaterMatrix_path8): xbmcvfs.delete(UpdaterMatrix_path8), xbmc.sleep(1000)

                                             #ViewModes6.db
    if exists(UpdaterMatrix_path9): xbmcvfs.delete(UpdaterMatrix_path9), xbmc.sleep(1000)


    #if exists(UpdaterMatrix_path20): xbmcvfs.delete(UpdaterMatrix_path20), xbmc.sleep(1000)
    

    if exists(UpdaterMatrix_path21): xbmcvfs.delete(UpdaterMatrix_path21), xbmc.sleep(1000)

    #xbmcvfs.delete('special://home/userdata/playercorefactory.xml')
    #xbmc.sleep(500)
    #xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/players/atla_oipeirates.json')
    xbmc.sleep(500)
    #xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/players/atla_coolmoviezone.json')
    #xbmc.sleep(500)
    #xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/players/direct.homelander.json')
    #xbmc.sleep(500)
    #xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/players/tvone1112.json')
    #xbmc.sleep(1000)


    BG.update(25, Dialog_U1, 'Παρακαλώ περιμένετε...')

#    if not exists(UpdaterMatrix_path):
#        xbmc.executebuiltin(UpdaterMatrix_1)
#        xbmc.sleep(1000)

#    BG.update(36, Dialog_U1, Dialog_U2)

    if not exists(UpdaterMatrix_path2):
        xbmc.sleep(5000)
        xbmc.executebuiltin(UpdaterMatrix_2)
        xbmc.sleep(3000)
        BG.update(30, Dialog_U1, 'Fix repos for Nexus 20...')


    if not exists(UpdaterMatrix_path3):
        xbmc.sleep(5000)
        xbmc.executebuiltin(UpdaterMatrix_3)
        xbmc.sleep(3000)
        BG.update(40, Dialog_U1, 'addon_data')

#    if not exists(UpdaterMatrix_path4):
#        xbmc.sleep(1000)
#        xbmc.executebuiltin(UpdaterMatrix_4)
#        xbmc.sleep(5000)
#        BG.update(60, Dialog_U1, '4')

#    if not exists(UpdaterMatrix_path5):
#        xbmc.sleep(1000)
#        xbmc.executebuiltin(UpdaterMatrix_5)
#        xbmc.sleep(5000)
#        BG.update(79, Dialog_U1, '5')
#        xbmc.sleep(10000)

    #if not exists(UpdaterMatrix_path6):
        #xbmc.sleep(5000)
        #xbmc.executebuiltin(UpdaterMatrix_6)
        #xbmc.sleep(3000)
        #BG.update(45, Dialog_U1, 'TheMovieDb Helper players')


#    if not exists(UpdaterMatrix_path7):
#        xbmc.sleep(1000)
#        xbmc.executebuiltin(UpdaterMatrix_7)
#        xbmc.sleep(5000)
#        BG.update(79, Dialog_U1, '7')
#        xbmc.sleep(10000)

    #if not exists(UpdaterMatrix_path8):
        #xbmc.sleep(5000)
        #xbmc.executebuiltin(UpdaterMatrix_8)
        #xbmc.sleep(3000)
        #BG.update(50, Dialog_U1, 'skin fix...')


    if not exists(UpdaterMatrix_path9):
        xbmc.sleep(7000)
        xbmc.executebuiltin(UpdaterMatrix_9)
        xbmc.sleep(3000)
        BG.update(55, Dialog_U1, 'ViewModes')


        #xbmc.sleep(5000)
        #BG.update(60, Dialog_U1, Dialog_U6)


    #if not exists(UpdaterMatrix_path20):
        #xbmc.sleep(5000)
        #xbmc.executebuiltin(UpdaterMatrix_20)
        #xbmc.sleep(3000)
        #BG.update(60 , Dialog_U1, 'World Updater - Service...')


    if not exists(UpdaterMatrix_path21):
        xbmc.sleep(5000)
        xbmc.executebuiltin(UpdaterMatrix_21)
        xbmc.sleep(3000)
        BG.update(65 , Dialog_U1, 'addons...')

    #xbmc.sleep(8000)
    #BG.update(65, Dialog_U1, Dialog_U2)



    #xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/DeleteFoldersNow.py")')

#    addonsEnable.enable_addons()
#    BG.update(75, Dialog_U1, 'Ενεργοποίηση πρόσθετων...')
#    xbmc.sleep(10000)
    xbmc.sleep(5000)
    BG.update(75, Dialog_U1, 'Έλεγχος αποθετηρίων στο Database/Addons33...')
    xbmc.sleep(5000)

    db.addon_database(Database_Addons33, 1, True)
    BG.update(77, Dialog_U1, 'Περιμένετε...')
   #BG.update(78, Dialog_U1, 'Διόρθωση αναβάθμισης αποθετηρίου castagnait')
    xbmc.sleep(15000)

    if addons_repos_version > int(setting('addonsreposversion')):
        BG.update(80, Dialog_U1, 'Αναμονή λίγο ακόμη...')
        xbmc.sleep(20000)
        #BG.update(82, Dialog_U1, 'test...')
        #xbmc.sleep(10000)
        #BG.update(84, Dialog_U1, 'Αναμονή λίγο ακόμη...')
        #xbmc.sleep(10000)
        #BG.update(86, Dialog_U1, 'Ενεργοποίηση πρόσθετων...')
        #xbmc.sleep(10000)
        addonsEnable.enable_addons()
        setting_set('addonsreposversion', str(addons_repos_version))


    BG.update(92, Dialog_U1, 'Ελεγχος για ενημέρωση στο μενού του skin...')
    xbmc.sleep(10000)



    if skinshortcuts_version > int(setting('skinshortcutsversion')):
        xbmc.executebuiltin(skinshortcuts_menu)
        xbmc.sleep(5000)
        BG.update(96, Dialog_U1, 'Ενημέρωση μενού skin.')
        setting_set('skinshortcutsversion', str(skinshortcuts_version))
        xbmc.sleep(5000)
        BG.update(100, Dialog_U4, 'Θα ακολουθήσει... επαναφόρτωση του προφίλ')
        xbmc.sleep(5000)
        xbmcgui.Dialog().notification("[B][COLOR orange]Reload Profile[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/reloadprofile.png')
        xbmc.sleep(500)
        BG.update(100, Dialog_U4, 'Θα ακολουθήσει... και πάγωμα της εικόνας')
        xbmc.sleep(2000)
        xbmc.executebuiltin("LoadProfile(Master user)")
    xbmc.sleep(5000)
    BG.update(100, Dialog_U4, Dialog_U5)
    xbmc.sleep(5000)
    BG.update(100, Dialog_U4, Dialog_U5)


    BG.close()
    xbmcvfs.delete(downloader_startup_delete)



def check_addons_list():
    for addons_list in addons_list_installation:
        if not exists(addons_path + '%s' % addons_list):
            xbmc.sleep(1000)
            BG.update(28, 'Eγκατάσταση νέων πρόσθετων', addons_list)
            installAddon()


def check_del_dir():
    for path_list in delete_files:
        if exists(addons_path + '%s' % path_list) or exists('%s' % path_list):
            BG.update(33, 'Διαγραφή αχρείαστων αρχείων...', path_list)
            xbmc.sleep(1000)
            del_dir()

def installAddon():
    for addon_id in addons_list_installation:
      xbmc.executebuiltin('InstallAddon(%s)' % (addon_id))
      xbmc.sleep(100)
      xbmc.executebuiltin('SendClick(11)')
      xbmc.sleep(100)


def del_dir():
    for ad in addons_data_path:
     for rr in delete_files:
       dir_list = glob.iglob(os.path.join(ad, rr))
       for path in dir_list:
           if os.path.isdir(path):
               shutil.rmtree(path)
           if os.path.isfile(path):
              os.remove(path)

def set_setting():
    ###  ScrubsV2   ###
    if setting_scrubsv2('subtitles')=='false':
        xbmc.sleep(1000)
        setting_set_scrubsv2('subtitles', 'true')
        BG.update(93, Dialog_U1, 'Ενεργοποίηση υπότιτλων ScrubsV2...')
        xbmc.sleep(2000)
        setting_set_scrubsv2('subtitles.lang.1', 'Greek')
        BG.update(95, Dialog_U1, 'Επιλογή κύριας γλώσσας υπότιτλων σε Ελληνικά...')
        xbmc.sleep(2000)

    ###  TheMoviedb   ###
    if setting_themoviedb('widgets_nextpage')=='false':
        BG.update(97, Dialog_U1, 'Ενεργοποίηση next page των widgets')
        setting_set_themoviedb('widgets_nextpage', 'true')
        xbmc.sleep(3000)
        if setting_themoviedb('language')=='15' or setting_themoviedb('language')=='18':
            BG.update(99, Dialog_U1, 'Αλλαγή γλώσσας (Gr) TheMovieDb...')
            setting_set_themoviedb('language', '12')
            xbmc.sleep(3000)
            BG.update(100, Dialog_U4, 'Θα ακολουθήσει επαναφόρτωση κελύφους')
            xbmc.sleep(5000)
            BG.update(100, Dialog_U4, Dialog_U5)
            xbmc.sleep(2000)
            xbmc.executebuiltin("ReloadSkin()")
        else:
            BG.update(100, Dialog_U4, 'Θα ακολουθήσει επαναφόρτωση κελύφους')
            xbmc.sleep(5000)
            BG.update(100, Dialog_U4, Dialog_U5)
            xbmc.sleep(2000)
            xbmc.executebuiltin("ReloadSkin()")

    if setting_themoviedb('language')=='15' or setting_themoviedb('language')=='18':
        xbmc.sleep(1000)
        setting_set_themoviedb('language', '12')
        BG.update(99, Dialog_U1, 'Αλλαγή γλώσσας (Gr) TheMovieDb...')
        xbmc.sleep(3000)
        BG.update(100, Dialog_U4, 'Θα ακολουθήσει επαναφόρτωση κελύφους')
        xbmc.sleep(5000)
        BG.update(100, Dialog_U4, Dialog_U5)
        xbmc.sleep(2000)
        xbmc.executebuiltin("ReloadSkin()")
    else:
        if skinshortcuts_version > int(setting('skinshortcutsversion')):
            xbmc.sleep(5000)
            BG.update(100, Dialog_U4, 'Θα ακολουθήσει επαναφόρτωση κελύφους')
            xbmc.sleep(8000)
            BG.update(100, Dialog_U4, Dialog_U5)
            xbmc.executebuiltin("ReloadSkin()")

     #xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"videoplayer.stretch43","value":0}}')
     #xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"addons.updatemode","value":1}}')
     #xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"GUI.SetFullscreen","id":1,"params":{"fullscreen":"toggle"}}')
     #xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.ExecuteAction","id":1,"params":{"action":"togglefullscreen"}}')



#        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]TechNEWSology[/COLOR][/B]', '[COLOR white]      Επιθυμείτε την απενεργοποίηση των ενημερώσεων [CR]                        του TechNEWSology Updater ?[/COLOR]',
#                                        nolabel='[COLOR lime]Ενεργοποίηση[/COLOR]',yeslabel='[COLOR orange]Απενεργοποίηση[/COLOR]')
#        if choice == 1: [xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "plugin.program.downloader19","enabled":false}}'), xbmcgui.Dialog().ok("[COLOR lime]TechNEWSology Updater-Tools[/COLOR]", "[COLOR orange]Απενεργοποήθηκαν οι αυτόματες ενημερώσεις         του TechNEWSology Updater.[/COLOR]")]
#        else:
#            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "plugin.program.downloader19","enabled":true}}')


Updater_Matrix()
