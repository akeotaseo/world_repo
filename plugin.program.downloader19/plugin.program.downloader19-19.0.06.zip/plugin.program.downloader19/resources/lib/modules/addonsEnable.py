import xbmc, glob, os, sqlite3
import xbmc
from xbmc import log
from updatervar import *
from sqlite3 import dbapi2 as db_lib


def enable_addons():
	conn =db_lib.connect(os.path.join(xbmc.translatePath('special://profile/Database'),'Addons33.db'))
	conn.text_factory = str
	conn.executemany('update installed set enabled=1 where addonID = (?)',((val,) for val in os.listdir(xbmc.translatePath(os.path.join('special://home','addons')))))
	conn.commit()
	xbmc.executebuiltin('UpdateLocalAddons')
	xbmc.executebuiltin('UpdateAddonRepos')