﻿import xbmc, xbmcgui

    # xbmc.executebuiltin('ReloadSkin()')
    # xbmc.sleep(10000)
xbmc.executebuiltin('Dialog.Close(all,true)')
xbmc.executebuiltin('Action(Back)')
xbmc.executebuiltin('Dialog.Close(all,true)')
xbmc.executebuiltin('ActivateWindow(10000)')
def ReSetDataSkin():

    Dialog_Choice_0()






def Dialog_Choice_0():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]World[/COLOR][/B]', 'Επιστροφή στο Προκαθορισμένο [B]HOME MENU[/B].[CR]Θέλετε να εφαρμοστούν οι αλλαγές;',
                                        nolabel='Οχι',yeslabel='Ναι')
        if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/SkinMenuLAST2.py")')]
        if choice == 0: [xbmc.executebuiltin('Dialog.Close(all,true)'), xbmc.executebuiltin('Action(Back)'), xbmc.executebuiltin('Dialog.Close(all,true)'), xbmc.executebuiltin('ActivateWindow(10000)'),]

ReSetDataSkin()
