import urllib.request
import xbmcgui
import xbmcaddon
import xbmcplugin
import sys
import urllib.parse
import os

addon = xbmcaddon.Addon()
m3u_url = addon.getSetting("m3u_url")

logo_folder = os.path.join(addon.getAddonInfo('path'), 'resources', 'logos')

group_logos = {
    "Slovenija": os.path.join(logo_folder, "Slovenija.png"),
    "Hrvatska": os.path.join(logo_folder, "Hrvatska.png"),
    "Srbija": os.path.join(logo_folder, "Srbija.png"),
    "Makedonija": os.path.join(logo_folder, "Makedonija.png"),
    "Crna Gora": os.path.join(logo_folder, "CrnaGora.png"),
    "Bosna": os.path.join(logo_folder, "Bosna.png"),
    "EX-YU": os.path.join(logo_folder, "ex-yu.png"),
    "Filmovi": os.path.join(logo_folder, "Filmovi.png"),
    "Pink": os.path.join(logo_folder, "Pink.png"),
    "Muzika": os.path.join(logo_folder, "Muzika.png"),
    "Slovenia": os.path.join(logo_folder, "Slovenija.png"),
    "Croatia": os.path.join(logo_folder, "Hrvatska.png"),
    "Serbia": os.path.join(logo_folder, "Srbija.png"),
    "Macedonia": os.path.join(logo_folder, "Makedonija.png"),
    "Montenegro": os.path.join(logo_folder, "CrnaGora.png"),
    "Bosnia": os.path.join(logo_folder, "Bosna.png"),
    "EX-YU": os.path.join(logo_folder, "ex-yu.png"),
    "Movies": os.path.join(logo_folder, "Filmovi.png"),
    "Pink": os.path.join(logo_folder, "Pink.png"),
    "Music": os.path.join(logo_folder, "Muzika.png")
}

def parse_m3u_playlist(url):
    try:
        response = urllib.request.urlopen(url)
        lines = response.read().decode('utf-8').splitlines()

        channels = []
        channel_info = None
        channel_name = None
        channel_group = None
        channel_logo = None

        for line in lines:
            if line.startswith("#EXTINF:"):
                channel_info = line.replace("#EXTINF:-1 ", "").split(",")
                channel_name = channel_info[1]
                channel_group = line.split('group-title="')[1].split('"')[0]
                channel_logo = line.split('tvg-logo="')[1].split('"')[0]
            elif line.startswith("http"):
                channel_url = line
                channels.append({"name": channel_name, "url": channel_url, "group": channel_group, "logo": channel_logo})

        channels.sort(key=lambda x: x["name"])  

        return channels
    except urllib.error.URLError:
        xbmcgui.Dialog().ok("Error", "This list stopped working. Change / Generate a new list by selecting one of the generators.")
        return []

def show_group_list(channels):
    list_item = xbmcgui.ListItem(label="[COLOR white]State list[/COLOR]")
    list_item.setInfo("video", {"title": "State list"})
    list_item.setLabel("[B][COLOR lime]State list[/COLOR][/B]")
    url = sys.argv[0] + "?mode=channels"
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)

    groups = sorted(set(channel["group"] for channel in channels)) 

    for group in groups:
        list_item = xbmcgui.ListItem(label="[COLOR white]" + group + "[/COLOR]")
        list_item.setInfo("video", {"title": group})
        group_logo_path = group_logos.get(group)  
        if group_logo_path and os.path.exists(group_logo_path):  
            list_item.setArt({"thumb": group_logo_path}) 
        url = sys.argv[0] + "?mode=channels&group=" + urllib.parse.quote(group)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def show_channel_list(channels, group=""):
    if group:
        list_item = xbmcgui.ListItem(label="[COLOR white]Channel list[/COLOR]")
        list_item.setInfo("video", {"title": "Channel list"})
        list_item.setLabel("[B][COLOR lime]Channel list[/COLOR][/B]")
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=list_item, isFolder=True)

    for channel in channels:
        if channel["group"] == group:
            list_item = xbmcgui.ListItem(label="[COLOR white]" + channel["name"] + "[/COLOR]")
            list_item.setInfo("video", {"title": channel["name"]})
            list_item.setPath(channel["url"])
            if channel["logo"]:
                list_item.setArt({"thumb": channel["logo"]})  
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=channel["url"], listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def play_channel(url):
    list_item = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, list_item)

def run():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    mode = params.get("mode", None)

    channels = parse_m3u_playlist(m3u_url)

    if mode == "channels":
        group = params.get("group", "")
        show_channel_list(channels, group)
    else:
        show_group_list(channels)

    if len(sys.argv) > 1:
        if sys.argv[2] == "play":
            index = int(sys.argv[3])
            play_channel(channels[index]["url"])

run()
