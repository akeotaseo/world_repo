# -*- coding: utf-8 -*-
from urllib3.exceptions import InsecureRequestWarning
import xbmcgui
import uuid, requests, xmltodict
from urllib.parse import urlencode
from lib import config, utils, logger
from lib.broadcaster_result import BroadcasterResult

requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

mpd = config.getSetting("mpd")

LOGIN_URL = "https://api-ott-prod-fe.mediaset.net/PROD/play/idm/anonymous/login/v2.0"
ALLSTATION_URL = "https://feed.entertainment.tv.theplatform.eu/f/PR1GhC/mediaset-prod-all-stations-v2?sort=shortTitle|asc&form=cjson&httpError=true"
LICENSE_URL = "https://widevine.entitlement.theplatform.eu/wv/web/ModularDrm/getRawWidevineLicense?releasePid={pid}&account=http://access.auth.theplatform.com/data/Account/2702976343&schema=1.0&token={token}|Accept=*/*&Content-Type=|R{{SSM}}|"
STREAM_URL  = "https://api-ott-prod-fe.mediaset.net/PROD/play/playback/check/v2.0?sid={sid}"


def play(search):
    res = BroadcasterResult()

    clientId = str(uuid.uuid1())
    appName = "web//mediasetplay-web/5.2.4-6ad16a4"

    loginData = {
        "client_id": f"rtispa_mplayweb_{clientId}",
        "client_id": clientId,
        "platform": "pc",
        "appName": appName
    }

    tkRes = requests.post(LOGIN_URL, json=loginData, verify=False)
    token = tkRes.json()["response"]["beToken"]
    sid   = tkRes.json()["response"]["sid"]
    
    url = ""
    pid = ""
    callSign = ""

    formats = "MPEG-DASH" if mpd else "M3U"
    strmFormat = "dash+xml" if mpd else "x-mpegURL"

    # get Json
    items = requests.get(ALLSTATION_URL).json()["entries"]

    # search
    if search.startswith("$"):
        search = search.replace("$", "")
        callSign = search
    else:
        for item in items:
            if search.startswith("$"):
                _search = "$" + item["callSign"]
            else:
                _search = item["title"]

            if item.get("tuningInstruction") and _search == search:
                for key in item["tuningInstruction"]["urn:theplatform:tv:location:any"]:
                    if key["format"] == "application/{}".format(strmFormat):
                        try:
                            if (mpd and "widevine" in key["assetTypes"]):
                                pid = key["releasePids"][0]
                                break
                            elif not mpd:
                                break
                        except:
                            logger.error(f"No PublicUrls for {search} with format {strmFormat}")
                callSign = item["callSign"]
                break

    jsonStreamRequestData = {
        "channelCode":f"{callSign}",
        "streamType":"LIVE",
        "delivery":"Streaming",
        "createDevice":"true",
        "overrideAppName": appName
    }

    headersStreamRequest = {"Authorization": f"Bearer {token}", "User-Agent": utils.USER_AGENT}
    jsonStream = requests.post(STREAM_URL.format(sid=sid), json=jsonStreamRequestData, headers=headersStreamRequest).json()
    
    urlComposer = jsonStream["response"]["mediaSelector"]
    
    parameters = {}
    parameters = {x: urlComposer[x] for x in urlComposer if x not in ["url", "formats"]}
    parameters["formats"] = formats
    parameters["auth"] = token

    itemUrl = urlComposer["url"]
    smilUrl = f"{itemUrl}?" + urlencode(parameters)
    smilXml = requests.get(smilUrl).content.decode()

    xml = xmltodict.parse(smilXml)
    url = xml["smil"]["body"]["seq"]["switch"]["video"]["@src"]

    if url:
        # set manifest for IA
        res.ManifestType = "hls"

        if mpd:
            res.ManifestType = "mpd"
            res.ManifestUpdateParameter = "full"
            if pid:
                res.LicenseKey = LICENSE_URL.format(pid=pid, token=token)
        
        url = "{}|user-agent={}".format(url, utils.USER_AGENT)
        res.StreamHeader = "user-agent={}".format(utils.USER_AGENT)
        res.Url = url
    else:
        logger.error("No url found for: ", search)

    return res
