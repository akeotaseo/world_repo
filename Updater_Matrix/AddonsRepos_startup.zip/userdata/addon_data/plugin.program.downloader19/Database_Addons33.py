﻿from updatervar import *
import db


def addon_database():
    db.addon_database(Database_Addons33, 1, True)

Database_Addons33 = [('repository.Worldolympic', 'repository.World'),
                     ('repository.World', 'repository.World'),
                     ('plugin.video.watchnixtoons2', 'repository.thecrew'),
                     ('plugin.video.live.streamspro', 'repository.Worldolympic'),
                     ('plugin.video.macvod', 'repository.Worldolympic'),
                     ('plugin.video.rumble', 'repository.Worldolympic'),
                     ('repository.castagnait', 'repository.castagnait'),
                     ('plugin.program.downloader', 'repository.gkobu'),
                     ('plugin.video.duffyou', 'repository.gkobu'),


                     ('plugin.program.simple.favourites', 'repository.Worldolympic'),

                     ('script.realdebridsite', 'repository.Worldolympic'),
                     ('service.World.Build', 'repository.Worldolympic'),
                     
                     ('repository.twilight0', 'repository.twilight0'),
                     ('script.module.tulip', 'repository.twilight0'),
                     
                     ('script.kelebek', 'repository.World'),
                     ('script.luar', 'repository.World'),
                     
                     ('plugin.video.f4mTester', 'repository.gkobu'),
                     ('script.video.F4mProxy', 'repository.gkobu'),

                     ('repository.cMaNWizard', 'repository.cMaNWizard'),
                     ('plugin.video.quicksilver', 'repository.cMaNWizard'),
                     ('script.module.quicksilverscrapers', 'repository.cMaNWizard'),
                     ('script.quicksilver.artwork', 'repository.cMaNWizard'),

                     ('plugin.video.neo.tv', 'repository.7Plus'),
                     
                     ('plugin.video.daddylive', 'repository.World'),
                     ('repository.dab', 'repository.dab'),
                     
                     ('repository.rays.files', 'repository.rays.files'),
                     ('repository.roooar', 'repository.dexe'),
                     ('repository.dexe', 'repository.dexe'),
                     ('plugin.video.BauBauVavoo', 'repository.dexe'),
                     ('plugin.video.GreenKlikPremium', 'repository.dexe'),

                     ('repository.7Plus', 'repository.7Plus'),
                     ('repository.GMan', 'repository.Worldolympic'),
                     ('repository.chainsrepo', 'repository.chainsrepo'),

                     ('plugin.video.homelander', 'repository.thecrew'),
                     ('script.module.homelanderscrapers', 'repository.thecrew'),
                     ('script.homelander.artwork', 'repository.thecrew'),


                     ('plugin.video.atlas', 'repository.atlas'),
                     
                     ('repository.lekma', 'repository.lekma'),
                     ('plugin.video.invidious', 'repository.lekma'),
                     
                     ('repository.Kpoodle20', 'repository.Kpoodle20'),
                     ('repository.diggz', 'repository.diggz'),
                     ('repository.matrix', 'repository.matrix'),
                     
                     ('script.extendedinfo', 'repository.gkobu'),
                     ('repository.Worldrepo', 'repository.World')]


addon_database()
