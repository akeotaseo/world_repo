# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Sourced From Online Templates And Guides
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Thanks To: Google Search For This Template
# modified by: MUSICHALL
# Gracias a la librería plugintools de Jesús (www.mimediacenter.info)
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon

import base64

#from addon.common.addon import Addon

addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")

addonPath           = xbmcaddon.Addon().getAddonInfo("path")
mi_data = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.MotorHall/'))
mi_addon = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.MotorHall'))

setting = xbmcaddon.Addon().getSetting
if setting('youtube_usar') == "0":  ##Reproducir con Youtube
    usa_duffyou = False
else:  ##Reproducir con Duff You
    usa_duffyou = True

playlists = xbmc.translatePath(os.path.join('special://home/userdata/playlists', ''))

addonID = 'plugin.video.MotorHall'
#addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_search = "plugin://plugin.video.youtube/kodion/search/list/" 
YOUTUBE_playlist_ID_01 = "PLSyCRkPeE-W1WfpVkhneXJYqYL4TKoE1_" 
YOUTUBE_playlist_ID_1 = "PLqdMwxr9WNxbYZOD9tfAkWYfU-TeLHxfm"   
YOUTUBE_playlist_ID_2 = "PLwLzbpiEkbbT9icTNC1djLP1vGd470tBy"   
YOUTUBE_playlist_ID_3 = "PLwLzbpiEkbbTs9rzhvUL7IoC6-NhQhphl"   
YOUTUBE_playlist_ID_4 = "PLjhIeqP387oTWDPVEhqqblXL7Ga205h_w"   
YOUTUBE_playlist_ID_5 = "PL24ZdmosDg-ggS8j-WH2GH0FKf8pQp4LR" 
YOUTUBE_playlist_ID_6 = "PL4X6zqOb4P0PN17VsrbNBLDpZyFnNIzct"   
YOUTUBE_playlist_ID_7 = "PLjmKA1grZBxUhSxagY8n4pB9L3bECeSKF"   
YOUTUBE_playlist_ID_8 = "PLUCcQDwZTY8NE6ZE1H7Q5kzGPtAmOIMpy"   
YOUTUBE_playlist_ID_9 = "PLjoSk0WDQgyBG4F5bDELP3f0wFge3j1Rh"   
YOUTUBE_playlist_ID_10 = "PLRU7FpeJSiXwc09At3v3rByHf615tu_rB" 
YOUTUBE_playlist_ID_11 = "PLeR3l896wrjjOCcNOCfMr_eZQA24l6WdT"   
YOUTUBE_playlist_ID_12 = "PLF2BD14562E8F531B"   
YOUTUBE_playlist_ID_13 = "PLnm8sbYP4QfCcORuEYlnA7_U_zfiT4plL"   
YOUTUBE_playlist_ID_14 = "PL5bY4Gln8etuDjevpTPzxhM14eivsLqOH"   
YOUTUBE_playlist_ID_15 = "PL3xiDl5cSV5CWF2wnaClVJSDw5sQaJlP2" 
YOUTUBE_playlist_ID_16 = "PL7opCex-2Q1Mutovj0l6BenkMMLs-wmte"   
YOUTUBE_playlist_ID_17 = "PLBcmFJS2aaIKgrNWT5-BEWDPi5NcOjpk1"   
YOUTUBE_playlist_ID_18 = "PL5bY4Gln8ettCqczds1P7TQ6ElC_ZPfeK"   
YOUTUBE_playlist_ID_19 = "PLGCryESUB3Fp5C0FGK96nRumScHpQwXQh"   
YOUTUBE_playlist_ID_20 = "PLAf6NxVRk3G2gf8VEPAyI0wlrNW6pLIie" 
YOUTUBE_playlist_ID_21 = "PLF59_T2AmSqndDeFDesvYZB89kOYX48RA"   
YOUTUBE_playlist_ID_22 = "PLEfXFiSnCx3sEDa5FROk_KOWxdwkKGyyD"   
YOUTUBE_playlist_ID_23 = "PLpS8nPEj45zBS1u3j-LNtbxYDVAGdAcAj"   
YOUTUBE_playlist_ID_24 = "PL4lulvjuVTQHEXlfcGGopO3dNuFw-oZ1-"   
YOUTUBE_playlist_ID_25 = "PLfMJ23WrmYGWY-Brc-lKecpnqmFN27qr8"
YOUTUBE_playlist_ID_26 = "PLzZvLfrmXZ5adXDWbVN_qbmWcQExLt0Py"
YOUTUBE_playlist_ID_27 = "PL7opCex-2Q1M4LvfFiMc8xjpwbZyBopey"
YOUTUBE_playlist_ID_28 = "PLEfXFiSnCx3uq7Cvcz3793oWpuNL8fgFR"
YOUTUBE_playlist_ID_29 = "PLpMW-RoJpCsRMdVcmYLALRTkh4N7mWg6p"
YOUTUBE_playlist_ID_30 = "PLECz7AgfoI7di6VHxAo4N-bHQiLjwGIYF"
YOUTUBE_playlist_ID_31 = "PLN0tR9uwE8VZHR7w_xYOxGKAgNIaj0hn9"   
YOUTUBE_playlist_ID_32 = "PLUBzo4Ea6ItnXEQl85uFbaWFEC3B2vvZ1"   
YOUTUBE_playlist_ID_33 = "PLZzoBYZFh3a-4M2Sg4ans5AXOFj6Osf2T"   
YOUTUBE_playlist_ID_34 = "PLQ9zJeQYxxedf_FztjOx7mCVaEmXtrz4E"   
YOUTUBE_playlist_ID_35 = "PLkSyIShERC9ImUB903gzJb45xDNSBAdan"   
YOUTUBE_playlist_ID_36 = "PLk_7prudZ_tSfgnbkOA8rjG0UsGLghCZI"   
YOUTUBE_playlist_ID_37 = "PLzPuPE566OF81hFNeupuAlNJNs8nGm_je"   
YOUTUBE_playlist_ID_38 = "PLiU8-HoLAW75LwP0B3wO5zpkTeR4c1-Wb"   
YOUTUBE_playlist_ID_39 = "PLSmCFH46WIXaWHloGp9gx8CcwDvoGppcJ"   
YOUTUBE_playlist_ID_40 = "PLA3WoUys5BTVlXEat_jFySqDgJBv_rS18"   
YOUTUBE_playlist_ID_41 = "PL8v1k6AKPRBj11OzR39zCTa41IiHZa_am"   
YOUTUBE_playlist_ID_42 = "PLEd6_ENAz1OeH82S4egK1hi5XmX101qca"   
YOUTUBE_playlist_ID_43 = "PLiU8-HoLAW750TkjT0DokGLP7VOgDDr0Y"   
YOUTUBE_playlist_ID_44 = "PL-O4L2aN5v5_T8Z6OfuUmrBDVYvD28Tog"   
YOUTUBE_playlist_ID_45 = "PLcRlu6WsQ88aWvupaAi9zs6B3jy4dUKnt"   
YOUTUBE_playlist_ID_46 = "PLTY6RRCgflxX6ZrewX7xCqQ70nYrykg2s"   
YOUTUBE_playlist_ID_47 = "PLWIcO5h4se1ztZmXYxLOXqwG8ur8wQ4jH"   
YOUTUBE_playlist_ID_48 = "PLFBk0XHVzrA5adyjEqlbPounygXSOUJHr"   
YOUTUBE_playlist_ID_49 = "PLFBk0XHVzrA4TvO1qfcYRDkRP4utshUDJ"   
YOUTUBE_playlist_ID_50 = "PLFBk0XHVzrA5TnfsJLL4ydr8gBbpEaGBq"   
YOUTUBE_playlist_ID_51 = "PLFBk0XHVzrA6KcbSV2ZbPaw3UlhI_PU9z"   
YOUTUBE_playlist_ID_52 = "PLFBk0XHVzrA4z3z2bd-ICB8rSD-1ymMpR"   
YOUTUBE_playlist_ID_53 = "PL4SdRE2SHbUGLKDbdrWS0CHHEcZsIC2N9"   
YOUTUBE_playlist_ID_54 = "PLk_EGTbNF3qsvkdmVK-6o2Iz0O3ZRek2z"   
YOUTUBE_playlist_ID_55 = "PLKiR1OJfhMIG3UnJBo6ew91WseeRp3CqR"   
YOUTUBE_playlist_ID_56 = "PLSbZ4HTSZM8OYiiGRfEZijsMODmV97Yji"   
YOUTUBE_playlist_ID_57 = "PLgIXCcV9H8BZgjt7_60bDanmHspEMF0dm"   
YOUTUBE_playlist_ID_58 = "PLpS8nPEj45zDtEKft9PoYxunfN8e86LGB"   
YOUTUBE_playlist_ID_59 = "PLpS8nPEj45zCro96rtB0x_Jwm1nkQVNc1"   
YOUTUBE_playlist_ID_60 = "PLpS8nPEj45zCPR21j5rhTXHwe5Sute9kO"   
YOUTUBE_playlist_ID_61 = "PLpS8nPEj45zBLbHT_XUI3eSQE_-u58OV6"   
YOUTUBE_playlist_ID_62 = "PLpS8nPEj45zACA94ZFyq-7K17loIRJBiQ"   
YOUTUBE_playlist_ID_63 = "PLpS8nPEj45zCSjzxKGB_L1r-LwZ6nHJgg"   
YOUTUBE_playlist_ID_64 = "PLiMEovmvrI1lkHKnExnjoT_Hv_CjMnTvz"   
YOUTUBE_playlist_ID_65 = "PLnBsfATnF275hPrW6-1jApH7gAxFHYOOj"   
YOUTUBE_playlist_ID_66 = "PLR2bhck1_IHsaDs26SHNPP20WRRmmJJ9c"   
YOUTUBE_playlist_ID_67 = "PL1dCFImJyFkV3v4l-Kly5CcluS2WF6CTg"   
YOUTUBE_playlist_ID_68 = "PLpS8nPEj45zC50gG-PjrC8BHiSaQctsrl"   
YOUTUBE_playlist_ID_69 = "PLcf71QrJ6ud-dmAm2hp0GoFNWWg5y89OE"   
YOUTUBE_playlist_ID_70 = "PLpev97ja-ZJZvPuGsaAKn08A9IRSzL9kq" 


if usa_duffyou:  ##Usamos plugin Duff You
    YOUTUBE_search = "plugin://plugin.video.duffyou/?eydhY3Rpb24nOiAnb2lPTzAwT28nLCAnZmFuYXJ0JzogJ0M6XFxVc2Vyc1xcZGFyaW9cXEFwcERhdGFcXFJvYW1pbmdcXEtvZGlcXGFkZG9uc1xccGx1Z2luLnZpZGVvLmR1ZmZ5b3VcXGZhbmFydC5qcGcnLCAnaWNvbic6ICdDOlxcVXNlcnNcXGRhcmlvXFxBcHBEYXRhXFxSb2FtaW5nXFxLb2RpXFxhZGRvbnNcXHBsdWdpbi52aWRlby5kdWZmeW91XFxyZXNvdXJjZXNcXG1lZGlhXFxuZXdfc2VhcmNoLnBuZycsICdsYWJlbCc6IHUnW0JdTnVldmEgQlx4ZmFzcXVlZGFbL0JdJywgJ3BhZ2UnOiAxLCAncGxvdCc6IHUnW0JdQnVzY2FyWy9CXVtDUl1bQ1JdQnVzY2EgdW4gdmlkZW8sIHVuIGRpcmVjdG8sIHVuYSBwbGF5bGlzdCBvIHVuIGNhbmFsLicsICdxdWVyeSc6IFRydWUsICd0aXBvJzogJ3ZpZGVvJ30%3d"
else:
    #YOUTUBE_search = "plugin://plugin.video.youtube/kodion/search/list/" 
    YOUTUBE_search = "plugin://plugin.video.youtube/kodion/search/input/"



def run():
	plugintools.log('[%s %s] Running %s... ' % (addonName, addonVersion, addonName))

	# Obteniendo parámetros...
	params = plugintools.get_params()
    
	
	if params.get("action") is None:
		main_list(params)
	else:
		action = params.get("action")
		exec(action+"(params)")
        

	plugintools.close_item_list()   



# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec(action+"(params)")
    
    plugintools.close_item_list()



# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))
	
    plugintools.add_item( 
            
        #action="", 
        title="[COLOR yellow]Buscador[/COLOR]",
        url=YOUTUBE_search,
        thumbnail="https://i.imgur.com/roTQ3fL.png",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Motor Hall Videos y Curiosidades[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_01),
        thumbnail="https://i.imgur.com/5rQFxxM.jpg",
		fanart="https://i.imgur.com/5rQFxxM.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]24 H. Le Mans [/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_1),
        thumbnail="https://i.imgur.com/0ZNjqKu.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Autofacil[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_31),
        thumbnail="https://i.imgur.com/3CNrQIS.jpg",
		fanart="aqui va el fanart",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Campeonato Andalucia 4x4[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_2),
        thumbnail="https://i.imgur.com/YNosW94.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Campeonato Andalucia 4x4 II[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_3),
        thumbnail="https://i.imgur.com/oDlHrQB.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Campeonato De España Radiocontrol[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_32),
        thumbnail="https://i.imgur.com/O6PHsyw.jpg",
		fanart="aqui va el fanart",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Carreras De Karting[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_4),
        thumbnail="https://i.imgur.com/njmeOmM.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Carreras De Karting II[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_33),
        thumbnail="https://i.imgur.com/cMuxXjE.jpg",
		fanart="aqui va el fanart",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Carreras De Seat 600[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_34),
        thumbnail="https://i.imgur.com/PPHUWvL.jpg",
		fanart="aqui va el fanart",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Carreras F1 De Ayer y Hoy[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_35),
        thumbnail="https://i.imgur.com/SumyBvE.jpg",
		fanart="aqui va el fanart",
        folder=True )			

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Carreras Prohibidas[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_5),
        thumbnail="https://i.imgur.com/WJVFezC.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Carreras Prohibidas II[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_36),
        thumbnail="https://i.imgur.com/2iTirN4.jpg",
		fanart="aqui va el fanart",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Carreras TC[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_37),
        thumbnail="https://i.imgur.com/oXqNol2.jpg",
		fanart="aqui va el fanart",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Centimetros Cubicos[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_6),
        thumbnail="https://i.imgur.com/V5qKtzN.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Centimetros Cubicos Motos[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_7),
        thumbnail="https://i.imgur.com/sU7mctI.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Coches De Carreras[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_8),
        thumbnail="https://i.imgur.com/KvEm5iw.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dakar 2020 Resumenes[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_39),
        thumbnail="https://i.imgur.com/UnJwUKh.jpg",
		fanart="aqui va el fanart",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Dakar 2020 Resumen Por Etapas[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_38),
        thumbnail="https://i.imgur.com/O4Cq4gr.jpg",
		fanart="aqui va el fanart",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Deportes Motor Variado[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_40),
        thumbnail="https://i.imgur.com/jPKFRwM.jpg",
		fanart="aqui va el fanart",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Documentales Motor[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_41),
        thumbnail="https://i.imgur.com/BIZNPBP.jpg",
		fanart="aqui va el fanart",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Documentales Motos[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_42),
        thumbnail="https://i.imgur.com/N87q3aO.png",
		fanart="aqui va el fanart",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]El Mundo Del Karting[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_9),
        thumbnail="https://i.imgur.com/o7o8xcH.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Enduro[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_10),
        thumbnail="https://i.imgur.com/l6FHDyN.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Enduro MTB[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_11),
        thumbnail="https://i.imgur.com/3VMAVx0.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]F4 Campeonato De España 2019[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_43),
        thumbnail="https://i.imgur.com/XRnCN2X.jpg",
		fanart="aqui va el fanart",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Fabricas De Camiones[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_44),
        thumbnail="https://i.imgur.com/gkDKeuv.jpg",
		fanart="aqui va el fanart",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Fabricas De Coches[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_45),
        thumbnail="https://i.imgur.com/nCYURS9.jpg",
		fanart="aqui va el fanart",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Galicia Motor Resumenes[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_12),
        thumbnail="https://i.imgur.com/cYOuJ4c.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gas Monkey Latino[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_46),
        thumbnail="https://i.imgur.com/WJ4hLda.jpg",
		fanart="aqui va el fanart",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Gp Camiones España[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_13),
        thumbnail="https://i.imgur.com/fzkfCiq.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Historia De Barreiros[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_47),
        thumbnail="https://i.imgur.com/uLLuhkY.jpg",
		fanart="aqui va el fanart",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Historia De La F1[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_14),
        thumbnail="https://i.imgur.com/IT5Dy3f.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Historia Del Dakar[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_15),
        thumbnail="https://i.imgur.com/OnWt4iv.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Indy Car 2014[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_48),
        thumbnail="https://i.imgur.com/teDAZNX.jpg",
		fanart="aqui va el fanart",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Indy Car 2015[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_49),
        thumbnail="https://i.imgur.com/AGAbNMW.jpg",
		fanart="aqui va el fanart",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Indy Car 2016[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_50),
        thumbnail="https://i.imgur.com/4pIpxjN.jpg",
		fanart="aqui va el fanart",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Indy Car 2017[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_51),
        thumbnail="https://i.imgur.com/lmUJPGY.jpg",
		fanart="aqui va el fanart",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Indy Car 2018[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_52),
        thumbnail="https://i.imgur.com/xfOR2lY.jpg",
		fanart="aqui va el fanart",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Indy Car 2019[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_16),
        thumbnail="https://i.imgur.com/MoVaSFE.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Indy Car Crash[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_53),
        thumbnail="https://i.imgur.com/0tkb31C.jpg",
		fanart="aqui va el fanart",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Bañeza Hoy[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_17),
        thumbnail="https://i.imgur.com/Qapx5rn.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]La Gran Aventura De La F1[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_18),
        thumbnail="https://i.imgur.com/XqptYsA.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Lo Llevamos En La Sangre[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_19),
        thumbnail="https://i.imgur.com/yEypppj.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Locos Por Los Coches Latino[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_54),
        thumbnail="https://i.imgur.com/KPgNL0t.jpg",
		fanart="aqui va el fanart",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mega Fabricas De Coches[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_55),
        thumbnail="https://i.imgur.com/SmHVhNh.jpg",
		fanart="aqui va el fanart",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mistif Garage[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_56),
        thumbnail="https://i.imgur.com/tIluVvs.jpg",
		fanart="aqui va el fanart",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Montando Un Kart De Competicion[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_20),
        thumbnail="https://i.imgur.com/nTbzmPw.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Mundo Trial[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_57),
        thumbnail="https://i.imgur.com/DI7DR3J.jpg",
		fanart="aqui va el fanart",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Nascar[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_21),
        thumbnail="https://i.imgur.com/mR3svUQ.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pilotos De Leyenda[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_22),
        thumbnail="https://i.imgur.com/vIWZzdy.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Power Art Temporada 1[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_58),
        thumbnail="https://i.imgur.com/wKQy2Dj.jpg",
		fanart="aqui va el fanart",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Power Art Temporada 2[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_59),
        thumbnail="https://i.imgur.com/MGGac9N.jpg",
		fanart="aqui va el fanart",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Power Art Temporada 3[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_23),
        thumbnail="https://i.imgur.com/ga8NBs1.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Power Art Temporada 4[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_60),
        thumbnail="https://i.imgur.com/klDGcfX.jpg",
		fanart="aqui va el fanart",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Power Art Temporada 5[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_61),
        thumbnail="https://i.imgur.com/9JpLCTV.jpg",
		fanart="aqui va el fanart",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Power Art Temporada Pruebas[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_62),
        thumbnail="https://i.imgur.com/OTGZONJ.jpg",
		fanart="aqui va el fanart",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Power Art Temporada Tecnica[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_63),
        thumbnail="https://i.imgur.com/ngRVESg.jpg",
		fanart="aqui va el fanart",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pruebas Coches.net[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_24),
        thumbnail="https://i.imgur.com/gTHKVcw.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Pruebas Moto.net[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_25),
        thumbnail="https://i.imgur.com/BahNAfv.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Resumenes F1 2019[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_26),
        thumbnail="https://i.imgur.com/wpv1Har.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Resumenes Nascar 2019[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_27),
        thumbnail="https://i.imgur.com/fuX5CP7.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Seguridad En La Moto[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_28),
        thumbnail="https://i.imgur.com/VUu14Ai.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Solo Motos[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_64),
        thumbnail="https://i.imgur.com/tqIa7lN.jpg",
		fanart="aqui va el fanart",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Subidas Imposibles En Moto[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_29),
        thumbnail="https://i.imgur.com/JxQUaWI.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Super Estructuras Camiones[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_65),
        thumbnail="https://i.imgur.com/c7xld32.jpg",
		fanart="aqui va el fanart",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Super TC 2000[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_66),
        thumbnail="https://i.imgur.com/yQS5vnG.jpg",
		fanart="aqui va el fanart",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Titanes Mecanicos[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_67),
        thumbnail="https://i.imgur.com/5IpEqBT.jpg",
		fanart="aqui va el fanart",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Todo Power Art[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_68),
        thumbnail="https://i.imgur.com/kQY20tF.jpg",
		fanart="aqui va el fanart",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Trial FIM[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_69),
        thumbnail="https://i.imgur.com/JDpN67E.jpg",
		fanart="aqui va el fanart",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Vamos Sobre Ruedas[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_70),
        thumbnail="https://i.imgur.com/d1HKhhd.png",
		fanart="aqui va el fanart",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="[COLOR aqua]Zona Tecnica[/COLOR]",
        url=playlist_duffyou(YOUTUBE_playlist_ID_30),
        thumbnail="https://i.imgur.com/wJVDCzu.jpg",
		fanart="https://i.imgur.com/8LHHsA4.jpg",
        folder=True )
	
    	



def playlist_duffyou(id_playlist): 

    duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNUJywgJ2xhYmVsJzogJycsICdwYWdlJzogMSwgJ3Bsb3QnOiAiIiwgJ3F1ZXJ5JzogdSIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="

    if usa_duffyou:  ##Usamos plugin Duff You
        reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_playlist)
        miLista = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
    else:  ##Usamos Youtube
        miLista = "plugin://plugin.video.youtube/playlist/"+id_playlist+"/"
    
    return(miLista)

    


		
run()