﻿import xbmc, xbmcgui
def Backup():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('Action(Back)')
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('ActivateWindow(Home)')
    # xbmc.sleep(1000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση[/COLOR][/B]", "Black Ghost IPTV", sound=False, icon='http://addonbg.co/black/img/tp.png')
    xbmc.sleep(4000)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=http%3a%2f%2fblackaddon.com%2fgray%2fimg%2ffanart.jpg&mode=1&name=Television%20%5bB%5dIPTV%5b%2fB%5d%20&url=https://bs67.short.gy/bg_tele")')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=http%3a%2f%2fblackaddon.com%2fgray%2fimg%2ffanart.jpg&mode=1&name=Television%20%5bB%5dIPTV%5b%2fB%5d%20&url=https://bs67.short.gy/bg_tele")')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=http%3a%2f%2fblackaddon.com%2fgray%2fimg%2ffanart.jpg&mode=1&name=Television%20%5bB%5dIPTV%5b%2fB%5d%20&url=https://bs67.short.gy/bg_tele")')


    #xbmc.executebuiltin('Action(Back)')
    #xbmc.executebuiltin('Dialog.Close(all,true)')
    #xbmc.sleep(1000)

Backup()