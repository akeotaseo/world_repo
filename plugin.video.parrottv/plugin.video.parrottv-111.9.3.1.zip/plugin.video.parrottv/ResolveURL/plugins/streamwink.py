import re
import requests
from ..utils.browser import Firefox
from ..utils.resolve import Resolver
import js2py


class StreamWink(Resolver):
    def __init__(self):
        self.firefox = Firefox()

    def _removeDupes(self, d):
        result = {}
        for key,value in d.items():
            if value not in result.values():
                result[key] = value
        return result

    def _login(self, username='paighton', password='black'):
        cookies = self._removeDupes(requests.get("https://www.streamwink.com/").cookies)
        self.firefox.addHeaders({
            'Referer': 'https://www.streamwink.com/wp-login.php',
            'Origin': 'https://www.streamwink.com',
        })

        data = {
            'log': username,
            'pwd': password,
            'rememberme': 'forever',
            'wp-submit': 'Log In',
            'redirect_to': 'https://www.streamwink.com/wp-admin/',
            'testcookie': '1',
        }

        response = requests.post('https://www.streamwink.com/wp-login.php', cookies=cookies, headers=self.firefox.headers, data=data)
        cookies.update(self._removeDupes(response.cookies))
        return cookies

    def grab(self, channel):
        url = f"https://www.streamwink.com/{channel}.php"

        self.firefox.addHeader("Referer", "https://www.streamwink.com")

        if self.username and self.password: cookies = self._login(username=self.username, password=self.password)
        else: cookies = self._login()

        resp = requests.get(url, headers=self.firefox.headers, cookies=cookies)

        code = re.findall(r"<script type=\"text/javascript\">(.*?)</script>", resp.text.replace("\n", ""))[1]
        channel = re.findall(r"var channel=\"(.*?)\";", resp.text)[0]
        #x0x0 = re.findall(r"var x0x0=\"(.*?)\";", requests.get("https://www.streamwink.com/driver/flix.js?v=1.0.2", headers=headers).text)[0]
        # NOTE: If sdwx gets changed use regex + requests to make autoupdate
        x0x0 = "sdwx"
        jsfied = f'var channel = "{channel}"; var x0x0 = "{x0x0}"; '

        # get url that is obfuscated
        urlPattern = r"'url':(.*?),"
        obfuscatedUrl = re.findall(urlPattern, code)[0]

        # edit code so it returns .phtml url
        code = jsfied + code.split("window")[0]
        code += f";var phtmlUrl = {obfuscatedUrl}"

        # eval code so it works in python
        runner = js2py.EvalJs({'python_sum': sum})
        runner.execute(code)

        # get .phtml
        self.firefox.addHeader("Referer", url)
        url = url.replace(url.split("/")[-1], "") + runner.phtmlUrl.replace("../", "")
        pResp = requests.get(url, headers=self.firefox.headers)

        # finally, get url that contains hls stream
        self.firefox.addHeader("Referer", url)
        hlsUrl = re.findall(r"var whistler = \"(.*?)\"", pResp.text)[0]

        #if "herokuapp.com" in hlsUrl and "ustvgo" not in hlsUrl:
        #    hlsUrl = hlsUrl.split("herokuapp.com/")[1] # They're proxy is too slow, so removing it makes things faster

        return hlsUrl, self.firefox.headers