import xbmc, xbmcgui


def xrysoi_genre():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8)

    call = xbmcgui.Dialog().select('[B][COLOR=orange]                                            Κατηγορίες [/COLOR][/B]', 
['[B][COLOR=white]                                                    1GreekSubs[/COLOR][/B]',
 '[B][COLOR=white]                                                       Western[/COLOR][/B]',
 '[B][COLOR=white]                                                         Anime[/COLOR][/B]',
 '[B][COLOR=white]                                                   Animemovies[/COLOR][/B]',
 '[B][COLOR=white]                                                     Bollywood[/COLOR][/B]',
 '[B][COLOR=white]                                                    Collection[/COLOR][/B]',
 '[B][COLOR=white]                                                 Tainiesonline[/COLOR][/B]',
 '[B][COLOR=white]                                            Χριστουγεννιάτικες[/COLOR][/B]'])

    if call:
        if call < 0:
            return
        func = funcs[call-8]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https%3a%2f%2fxrysoi.pro%2fcategory%2f%ce%b5%ce%bb%ce%bb-%cf%84%ce%b1%ce%b9%ce%bd%ce%af%ce%b5%cf%82%2f,return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/western/,return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/anime/,return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/animemovies/,return)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/bollywood/,return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/collection/,return)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/tainiesonline/,return)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/x-mas/,return)')

xrysoi_genre()
