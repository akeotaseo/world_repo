﻿import xbmc, xbmcgui

def SportsSites():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/SportSites/hosts")')
    xbmcgui.Dialog().notification("[B][COLOR orange]MicroJen[/COLOR][/B]", "Sports[COLORviolet]Sites[/COLOR]", sound=False, icon='special://home/addons/script.module.jetextractors/icon.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]MicroJen[/COLOR][/B]", "Sports[COLORviolet]Sites[/COLOR]", sound=False, icon='special://home/addons/script.module.jetextractors/icon.png')
SportsSites()
