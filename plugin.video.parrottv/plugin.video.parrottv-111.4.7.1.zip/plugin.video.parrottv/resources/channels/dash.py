# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import xbmcgui
import xbmcplugin
import inputstreamhelper
import requests


class Dash:
    def __init__(self, handle):
        self.handle = handle
        self.API = "https://parrot-tv.pages.dev/JSON/Channels/dash.json"

    def play(self):
        channel = "animalplanet"
        resp = requests.get(self.API).json()[channel]
        isHelper = inputstreamhelper.Helper("mpd", drm=resp["drm"])
        if isHelper.check_inputstream():
            li = xbmcgui.ListItem(resp["name"], path=resp["url"])
            li.setProperty('inputstream', isHelper.inputstream_addon)
            li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            li.setProperty('inputstream.adaptive.license_type', resp["type"])
            li.setProperty('inputstream.adaptive.license_key', resp["key"] + '||R{SSM}|')
            xbmcplugin.setResolvedUrl(self.handle, True, li)
        else:
            xbmcgui.Dialog().ok("Error", "No inputstream helper found")

