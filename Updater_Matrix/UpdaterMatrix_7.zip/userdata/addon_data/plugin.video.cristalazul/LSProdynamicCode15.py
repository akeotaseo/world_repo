# -*- coding: utf-8 -*-
#$pyFunction
def GetLSProData(page_data,Cookie_Jar,m):
 import xbmc
 hola = xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)')
 return hola
