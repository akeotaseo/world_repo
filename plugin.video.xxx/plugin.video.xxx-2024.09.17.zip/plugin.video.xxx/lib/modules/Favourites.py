import xbmcaddon
from lib.modules import Common

OpenURL   = Common.OpenURL
addDir    = Common.addDir
addVideo  = Common.addVideo
Play      = Common.Play
Setting   = xbmcaddon.Addon().getSetting
#TVSetting = xbmcaddon.Addon('plugin.program.rays.files').getSetting

def Menu():
	if Setting('goodporn')   == 'true': addDir('GoodPorn',   'none', 70,  'special://home/addons/plugin.video.xxx/resources/art/goodporn.png'  )
	if Setting('hogtv')      == 'true': addDir('Hog.TV',     'none', 80,  'special://home/addons/plugin.video.xxx/resources/art/hogtv.png'     )
	if Setting('hqporner')   == 'true': addDir('HQPorner',   'none', 120, 'special://home/addons/plugin.video.xxx/resources/art/hqporner.png'  )
	if Setting('pornhat')    == 'true': addDir('PornHat',    'none', 60,  'special://home/addons/plugin.video.xxx/resources/art/pornhat.png'   )
	if Setting('pornohd')    == 'true': addDir('PornoHD',    'none', 20,  'special://home/addons/plugin.video.xxx/resources/art/pornohd.png'   )
	if Setting('pornone')    == 'true': addDir('PornOne',    'none', 130, 'special://home/addons/plugin.video.xxx/resources/art/pornone.png'   )
	if Setting('porntrex')   == 'true': addDir('PornTrex', 'none', 150,  'special://home/addons/plugin.video.xxx/resources/art/porntrex.png'   )
	if Setting('xcum')       == 'true': addDir('XCum',       'none', 30,  'special://home/addons/plugin.video.xxx/resources/art/xcum.png'      )
	if Setting('xhand')      == 'true': addDir('XHand',      'none', 90,  'special://home/addons/plugin.video.xxx/resources/art/xhand.png'     )
	if Setting('xozilla')    == 'true': addDir('XOZilla',    'none', 100, 'special://home/addons/plugin.video.xxx/resources/art/xozilla.png'   )
	if Setting('xtits')      == 'true': addDir('XTits',      'none', 40,  'special://home/addons/plugin.video.xxx/resources/art/xtits.png'     )
	
	#if Setting('mangovideo') == 'true': addDir('MangoVideo', 'none', 10,  'special://home/addons/plugin.video.xxx/resources/art/mangovideo.png')
	#if Setting('xhamster')   == 'true': addDir('XHamster',   'none', 110, 'special://home/addons/plugin.video.xxx/resources/art/xhamster.png'  )
	#if Setting('zbporn')     == 'true': addDir('ZBPorn',     'none', 50, 'special://home/addons/plugin.video.xxx/resources/art/zbporn.png'    )
	
	#if TVSetting('user') == 'Ray': addDir('Live TV',    'none', 2,  'special://home/addons/plugin.video.xxx/resources/art/live.png'    )
	#Common.addTask('Favourites',    'none', 3,  'none'    )