﻿import os, glob, xbmc, xbmcgui, xbmcvfs, xbmcaddon, shutil
from updatervar import *
#from resources.lib.modules.delete_addons import del_dir
from resources.lib.GUIcontrol import txt_updater
from resources.lib.modules import db, addonsEnable
from resources.lib.modules.addonsEnable import enable_addons
#from resources.lib.modules.installer_addons import installAddon
from resources.lib.GUIcontrol.txt_updater import get_skinshortcutsversion

skinshortcuts_version = get_skinshortcutsversion()



Database_Addons33 = [('plugin.video.fmoviesto', 'repository.gkobu'),
                     ('plugin.video.cartoonsgr', 'repository.gkobu'),
                     ('plugin.video.shadow', 'repository.gkobu'),
                     ('plugin.video.microjen', 'repository.gkobu'),
                     ('script.gkobu.pairwith', 'repository.gkobu'),
                     ('script.module.grs', 'repository.gkobu'),
                     ('plugin.program.downloader', 'repository.gkobu'),
                     ('script.module.oathscrapers', 'repository.gkobu'),
                     ('plugin.video.winner', 'repository.gkobu'),
                     ('plugin.video.duffyou', 'repository.gkobu'),
                     
                     ('repository.gknwiz', 'repository.gknwiz'),
                     ('plugin.program.G.K.N.Wizard', 'repository.gknwiz'),
                     
                     ('script.theoath.artwork', 'repository.encryptic'),
                     ('plugin.video.theoath', 'repository.encryptic'),
                     ('repository.encryptic', 'repository.encryptic'),
                     
                     ('plugin.video.subsmovies', 'repository.mbebe'),
                     ('plugin.video.darmowatv', 'repository.mbebe'),
                     ('plugin.video.sportliveevents', 'repository.mbebe'),
                     
                     ('plugin.video.mlbtv2', 'repository.World'),
                     ('plugin.program.mypreferences', 'repository.World'),
                     ('plugin.program.super.favourites', 'repository.World'),
                     ('service.World.Build', 'repository.World'),
                     ('plugin.program.downloader19', 'repository.World'),
                     ('plugin.video.uiiumovies', 'repository.World'),
                     ('plugin.image.World', 'repository.World'),
                     ('plugin.video.tvone', 'repository.World'),
                     ('plugin.video.tvone11', 'repository.World'),
                     ('plugin.video.tvone111', 'repository.World'),
                     ('plugin.video.tvone1111', 'repository.World'),
                     ('plugin.video.videodevil', 'repository.World'),
                     ('plugin.video.vidembed', 'repository.World'),
                     ('plugin.video.tc', 'repository.World'),
                     ('script.tc.artwork', 'repository.World'),
                     ('script.tc.metadata', 'repository.World'),
                     ('script.module.tc', 'repository.World'),
                     ('plugin.video.parrot', 'repository.World'),
                     ('script.module.parrot', 'repository.World'),
                     ('plugin.video.dramacool', 'repository.World'),
                     ('plugin.video.hdtrailers_net.reloaded', 'repository.World'),
                     
                     ('plugin.video.ghosttv', 'repository.tc'),
                     
                     ('plugin.video.atlas', 'repository.atlas'),
                     ('repository.atlas', 'repository.atlas'),
                     
                     ('plugin.video.amazon-test', 'repository.sandmann79-py3.plugins'),
                     ('plugin.video.jetproxy', 'repository.Magnetic'),
                     ('plugin.video.themoviedb.helper', 'repository.jurialmunkey'),
                     ('script.module.slproxy', 'repository.gujal'),
                     ('repository.octopus', 'repository.octopus'),
                     ('repo.garmedcen', 'repo.garmedcen'),
                     ('repository.gsource', 'repository.gsource'),
                     ('repository.loonaticsasylum', 'repository.loonaticsasylum'),
                     ('repository.matrix', 'repository.matrix'),
                     ('repository.newdiamond', 'repository.newdiamond'),
                     ('repository.Rising.Tides', 'repository.Rising.Tides'),
                     ('plugin.video.viacom.mtv', 'repository.kodinerds'),
                     ('script.module.jetextractors', 'repository.loop'),
                     ('vkkodi.repo', 'vkkodi.repo')]


                         ### Προσθέτεις εντός της αγκύλης τα πρόσθετα που επιθυμείς [  ] ###

addons_list_installation = ['plugin.video.live.streamspro', 'repository.gknwiz', 'plugin.program.autowidget', 'repository.atlas', 'repository.gsource', 'script.trakt', 'repository.7PlusREPO', 'repository.wltv', 'repository.arrownegra', 'repository.Wherethemonsterslive', 'script.module.grs', 'plugin.video.cumination', 'plugin.video.favourites', 'repository.ezra', 'repository.kodifitzwell', 'plugin.video.vogelspot', 'plugin.video.f4mTester',]

         ### Προσθέτεις εντός της αγκύλης τα πρόσθετα ή τα αρχεία που επιθυμείς να αφαιρέσεις [  ] ###

delete_files = ['repository.test', 'plugin.video.forkyou', 'script.module.forkyouscrapers', 'plugin.video.clickhere', 'repository.thecrew', 'plugin.video.thecrew', 'script.module.thecrew', 'script.thecrew.artwork', 'script.thecrew.metadata', 'plugin.video.darmowatv', 'repository.host505', 'repository.tikipeter', 'repository.venom', 'repository.camaradas.repo', 'repository.diamond-wizard-repo-k19', 'repository.diamond-wizard-repo-k19k18', 'repository.chainsrepo', 'repository.newdiamond', 'repository.testt']


def Updater_Matrix():

    BG.create(Dialog_U1, Dialog_U2)


    xbmc.sleep(500)
    BG.update(5, Dialog_U1, Dialog_U6)
    xbmc.sleep(5000)
    BG.update(25, Dialog_U1, Dialog_U6)
    #check_addons_list()
    #check_del_dir()
    #xbmc.sleep(5000)

    #db.addon_database(Database_Addons33, 1, True)
### Το ενεργοποιείς όταν θέλεις να περάσεις πρόσθετα ###
    #xbmc.sleep(5000)
    #installAddon()
    #xbmc.sleep(30000)
    #addonsEnable.enable_addons()


 
 
###########################################################################

    xbmc.sleep(5000)
    BG.update(36, Dialog_U1, 'Διαγραφή UpdaterMatrix')
    del_dir()                                     ### delete addons ands files ###
    if os.path.exists(UpdaterMatrix_path2): xbmcvfs.delete(UpdaterMatrix_path2), xbmc.sleep(1000)
    if os.path.exists(UpdaterMatrix_path3): xbmcvfs.delete(UpdaterMatrix_path3), xbmc.sleep(1000)
    #if os.path.exists(UpdaterMatrix_path4): xbmcvfs.delete(UpdaterMatrix_path4), xbmc.sleep(1000)
    if os.path.exists(UpdaterMatrix_path7): xbmcvfs.delete(UpdaterMatrix_path7), xbmc.sleep(1000)


 #   if not os.path.exists(UpdaterMatrix_path):
 #       xbmc.sleep(1000)
 #       xbmc.executebuiltin(UpdaterMatrix_1)
 #       xbmc.sleep(5000)
 #       BG.update(36, Dialog_U1, Dialog_U6)

    if not os.path.exists(UpdaterMatrix_path2):
        xbmc.sleep(5000)
        BG.update(39, Dialog_U1, 'Εγκατάσταση νέων repository')
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_2)
        xbmc.sleep(5000)
        BG.update(41, Dialog_U1, Dialog_U6)
        xbmc.sleep(10000)
        addonsEnable.enable_addons()

    if not os.path.exists(UpdaterMatrix_path3):
        xbmc.sleep(5000)
        BG.update(55, Dialog_U1, 'Εγκατάσταση addon_data')
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_3)
        xbmc.sleep(5000)
        BG.update(57, Dialog_U1, Dialog_U6)
        xbmc.sleep(10000)
        addonsEnable.enable_addons()
 
 #  if not os.path.exists(UpdaterMatrix_path4):
 #      xbmc.sleep(1000)
 #      xbmc.executebuiltin(UpdaterMatrix_4)
 #      xbmc.sleep(5000)
 #      BG.update(42, Dialog_U1, Dialog_U6)
      
 #  if not os.path.exists(UpdaterMatrix_path5):
 #      xbmc.sleep(1000)
 #      xbmc.executebuiltin(UpdaterMatrix_5)
 #      xbmc.sleep(5000)
 #      BG.update(45, Dialog_U1, Dialog_U6)
 #      xbmc.sleep(20000)
 #      addonsEnable.enable_addons()

 #  if not os.path.exists(UpdaterMatrix_path6):
 #      xbmc.sleep(1000)
 #      xbmc.executebuiltin(UpdaterMatrix_6)
 #      xbmc.sleep(5000)
 #      BG.update(48, Dialog_U1, Dialog_U6)
 #      xbmc.sleep(20000)
 #      addonsEnable.enable_addons()

    if not os.path.exists(UpdaterMatrix_path7):
        xbmc.sleep(5000)
        BG.update(65, Dialog_U1, 'Εγκατάσταση UpdaterMatrix...')
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_7)
        xbmc.sleep(5000)
        BG.update(67, Dialog_U1, Dialog_U6)
        xbmc.sleep(10000)
        addonsEnable.enable_addons()
        
 #  if not os.path.exists(UpdaterMatrix_path8):
 #      xbmc.sleep(1000)
 #      xbmc.executebuiltin(UpdaterMatrix_8)
 #      xbmc.sleep(5000)
 #      BG.update(54 , Dialog_U1, Dialog_U6)
 #      xbmc.sleep(20000)
 #      xbmc.sleep(20000)
###########################################################################
    check_addons_list()
    check_del_dir()
    xbmc.sleep(5000)

    BG.update(70, Dialog_U1, 'Έλεγχος αποθετηρίων στο Database/Addons33...')
    xbmc.sleep(3000)

    db.addon_database(Database_Addons33, 1, True)
    BG.update(72, Dialog_U1, 'Αναμονή λίγο ακόμη...')
    
    xbmc.sleep(7000)
    BG.update(74, Dialog_U1, 'Εγκατάσταση πρόσθετων...')
    installAddon()
    
    
    xbmc.sleep(5000)
    BG.update(80, Dialog_U1, 'Ενεργοποίηση πρόσθετων...')
    
    addonsEnable.enable_addons()
    
   # xbmc.sleep(5000)
   # BG.update(80, Dialog_U1, 'Εξαναγκαστική ενημέρωση πρόσθετων!')
   # xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=fixaddonupdate")')
   # xbmc.sleep(5000)
   # BG.update(85, Dialog_U1, 'Install all updates!')
   
   # xbmc.executebuiltin('RunAddon()'),
    xbmc.sleep(20000)
    BG.update(85, Dialog_U1, Dialog_U6)
    xbmc.sleep(20000)
    
    
    if skinshortcuts_version > int(setting('skinshortcutsversion')):
        xbmc.executebuiltin(skinshortcuts_menu)
        xbmc.sleep(10000)
        BG.update(90, Dialog_U1, 'Ενημέρωση στο μενού του skin...')
        setting_set('skinshortcutsversion', str(skinshortcuts_version))
        xbmc.sleep(5000)
        BG.update(95, Dialog_U4, 'Θα ακολουθήσει... επαναφόρτωση του προφίλ')
        xbmc.sleep(5000)
        BG.update(100, Dialog_U4, 'Θα ακολουθήσει... και πάγωμα της εικόνας')
        xbmc.sleep(8000)
        BG.update(100, Dialog_U4, Dialog_U5)
        xbmc.executebuiltin("LoadProfile(Master user)")
    xbmc.sleep(5000)
    BG.update(100, Dialog_U4, Dialog_U5)
    xbmc.sleep(5000)
    BG.update(100, Dialog_U4, Dialog_U5)

    BG.close()
    xbmcvfs.delete(downloader_startup_delete)

def check_addons_list():
    for addons_list in addons_list_installation:
        if not os.path.exists(addons_path + '%s' % addons_list):
            xbmc.sleep(1000)
            BG.update(70, 'Eγκατάσταση νέων πρόσθετων', addons_list)
            installAddon()

def check_del_dir():
    for path_list in delete_files:
        if os.path.exists(addons_path + '%s' % path_list) or os.path.exists('%s' % path_list):
            xbmc.sleep(1000)
            BG.update(75, 'Διαγραφή αχρείαστων αρχείων', path_list)
            del_dir()

def installAddon():
    for addon_id in addons_list_installation:
      xbmc.executebuiltin('InstallAddon(%s)' % (addon_id))
      xbmc.sleep(100)
      xbmc.executebuiltin('SendClick(11)')
      xbmc.sleep(100)




def del_dir():
    for ad in addons_data_path:
     for rr in delete_files:
       dir_list = glob.iglob(os.path.join(ad, rr))
       for path in dir_list:
           if os.path.isdir(path):
               shutil.rmtree(path)
           if os.path.isfile(path):
              os.remove(path)
              

# xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"videoplayer.stretch43","value":0}}')

# xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"addons.updatemode","value":1}}')

Updater_Matrix()
