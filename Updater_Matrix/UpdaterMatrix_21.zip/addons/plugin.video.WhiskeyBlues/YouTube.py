import os, xbmc, xbmcgui

def YouTube():
        choice = xbmcgui.Dialog().yesno('[B][COLOR red]YouTube[/COLOR][/B]', '[COLOR orange]Κανάλια & Λίστες απο το Πρόσθετο [COLOR red]YouTube[/COLOR]',
                                        yeslabel='[COLOR red]YouTube[/COLOR]', nolabel='[COLOR orange]Whiskey Blues[/COLOR]')
        if choice == 1:
            Tube()
        # if choice == 0:
            # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.WhiskeyBlues/?content_type=video",return)')



def Tube():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B][COLOR red]YouTube[/COLOR][/B]', 
['Moody Blues Lounge',
 'JAZZ & BLUES',
 'Dons Tunes'])
 



    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 





def click_1():
    Close()
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR red]YouTube[/COLOR]", sound=False, icon='special://home/addons/plugin.video.youtube/resources/media/icon.png')
    xbmc.sleep(4000)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/kodion/search/query/?category_label=Moody%20Blues%20Lounge&q=Moody%20Blues%20Lounge&type=video",return)')
    
def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/kodion/search/query/?category_label=JAZZ%20%26%20BLUES&q=JAZZ%20%26%20BLUES&type=video",return)')
    
def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/kodion/search/query/?category_label=Don%27s%20Tunes&q=Don%27s%20Tunes&type=video",return)')


def Close():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('Action(Back)')
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10000)')
    xbmc.sleep(4000)

YouTube()
