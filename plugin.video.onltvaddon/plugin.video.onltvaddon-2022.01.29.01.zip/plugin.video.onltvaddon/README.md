# Free BG/World Online TV
Video plugin for Free BG/World Online TV.

It is tested as well on Kodi for Windows and Android

How to install:

1. Copy the zip file plugin.video.onltvaddon.zip to a directory, where Kodi server has access to
	Windows -> <USERDIR>\AppData\Roaming\XBMC\addons\packages\ 
	Linux/OpenElec/LibreElec -> ~/.kodi/addons/packages/
2. Run Kodi and go to System -> Add-ons
3. From Add-ons menu select -> Install from zip file
4. Select the zip file plugin.video.onltvaddon.zip
5. Sports TV add-on will appear in the video addon list
6. Before you run it you have to provide login information 
	For this select the addon in the list and the PC use right mouse button. On AppleTV long press Menu on the remote control
