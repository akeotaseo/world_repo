import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_labels


setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="

arrayMenu = ([
            [ "New Releases",  "PLVWT5waYZYnmTEdT-B3liA0thpIms7Pc7"],
            [ "All Century Media Records Music Videos",  "PL8B6C0DAB78462F56"],
            [ "Classic Century Media Videos",  "PLFA2085CCB025E3B7"],
            [ "We Are Century Media - 30 Years Anniversary",  "PLVWT5waYZYnmR8YRo70uua6CMoer9ghaY"],
            [ "Loud & Heavy",  "PLVWT5waYZYnnCOs0ARVDeh4Z5OoyvT6ly"],
            [ "Metal For The Masses - SWEDISH INVASION!",  "PLVWT5waYZYnmud_DzzmWhOWXGgDEvExDZ"],
            [ "Gothic Metal",  "PLVWT5waYZYnngg8FvzuP7M0azkhFcYeVa"],
            [ "Metal Queens",      "PLVWT5waYZYnkoDdLRXmJlpjWUPB895WA6"],
            [ "Century Media Rock",  "PLVWT5waYZYnluyAbeGkEYE_8bR2m0xYfO"],
            [ "Death Metal",  "PLVWT5waYZYnmedeVz3FsEgfzPhGtTxitF"],
            [ "Death Metal/Grind (Century Media Bands)",  "PLVWT5waYZYnmZiRsVdD4XNhPzCISdEF8j"],
            [ "Black Metal",  "PLVWT5waYZYnkdgeYGcmOIn474uF-wo-US"],
            [ "Leaders of the Extreme!",  "PLB1357DD0B2462645"],
            [ "Century Media Records Lyric Videos",  "PL61FB67864E036E68"],
            [ "Tutorials/Playthroughs from Century Media Records' Artists",  "PL84FEBB669200C262"],
            [ "Ultimate Halloween Playlist",  "PLVWT5waYZYnlrCJ_o5SP-TmebZWrzXwwv"],

            [ "Arch Enemy - Collection",  "PLBB37BB95CF62AF23"],
            [ "Arch Enemy",  "PLVWT5waYZYnmcQBp62vaTXt3QabOfPp7C"],
            [ "Angelus Apatrida - Angelus Apatrida | Out Now",  "PLVWT5waYZYnnv6mNmfPhKfvSFwq382Efw"],  
            [ "At The Gates",  "PLVWT5waYZYnltcAIyw2y4bkHPqM7MYts8"],
            [ "At The Gates - The Nightmare Of Being | Out Now",  "PLVWT5waYZYnk3_vyXFFBH6EXqPWneQ15C"],
            [ "Cryptosis - Bionic Swarm | Out Now",  "PLVWT5waYZYnnng0QGvVEBYk8lcbJ337ah"],
            [ "Dark Tranquillity",  "PLVWT5waYZYnk-WTLDdANQ_Zl2n5v66L-8"],
            [ "Dark Tranquillity - Moment | OUT NOW",  "PLVWT5waYZYnm2vMp0Gfled3saGURPjCEA"],
            [ "Demons & Wizards",  "PLVWT5waYZYnkzUO_zW0WZJla1hfHbiSEo"],
            [ "Entombed A.D.",  "PLVWT5waYZYnnfeRpnjapgcyB8rDP9Spgh"],
            [ "Havok",  "PLVWT5waYZYnlhYTdoxxrSYmLS0z18i0cK"],
            [ "Iced Earth",  "PLVWT5waYZYnlFntEGWH3QH4M6cwVkSjkG"],
            [ "Insomnium",  "PLVWT5waYZYnnOuG1wO5Rmzx7c5CG7AMuf"],
            [ "Lacuna Coil",  "PLDCF5022DDA3F1933"],
            [ "Paradise Lost",  "PLVWT5waYZYnlgoF0bi3Y2Q8U2lWelE7y_"],          
            [ "Queensryche",  "PLVWT5waYZYnk-LMm74GE5-5BWsbb11iez"],
            #[ "",  ""],           
            [ "Enjoy at home",  "PLVWT5waYZYnlYy4PYfs1PdriJtaHqP5Be"],
            [ "Best Of | Metal Reaction Videos",  "PLVWT5waYZYnl3b0f4oa5wSMcQYWmVah5W"],
            [ "Unboxing",  "PLVWT5waYZYnk7dVMGVkvO7xOa2CpxeoI6"]])

def playlists(params):
    logo=logos_labels.century(params)

    for i in range(len(arrayMenu)):
        titulo = arrayMenu[i][0]
        id_canal = arrayMenu[i][1]
        if usa_duffyou:  ##Usamos plugin Duff You
            reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_canal)
            videos = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        else:  ##Usamos plugin YouTube
            videos = youtube.replace("MI-ID-PLAYLIST" , id_canal)
        
        plugintools.add_item( 
            title=titulo,
            url=videos,
            thumbnail=logo, folder=True )

