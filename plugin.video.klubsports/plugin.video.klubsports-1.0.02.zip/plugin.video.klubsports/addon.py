# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
#import base64
#import json
#import random
#import time
#from resources.lib import jsunpack
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.klubsports')

mode = addon.getSetting('mode')
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0'
baseurl='https://klubsports.xyz/'

def build_url(query):
    return base_url + '?' + urlencode(query)

def main_menu():
    items=[
        ['Schedule','schedule'],
        ['TV Channels','tv']
    ]
  
    for i in items:
        li=xbmcgui.ListItem(i[0])
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': i[0],'sorttitle': i[0],'plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': '', 'fanart': ''})
        url = build_url({'mode':i[1]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def tvList():
    hea={
        'user-agent':UA,
    }

    resp=requests.get(baseurl,headers=hea).text
    '''
    resp1=resp.split('<br />\n')
    chNames=[]
    channels=[]
    for r1 in resp1:
        if '<h4><span' in r1: #poziom: wydarzenia dla danej dyscypliny
            r2=r1.split('<br>\n')
            for e in r2: #poziom: wydarzenie
                if 'href' in e:
                    title=re.compile('([^<]+?)<br />').findall(e)
                    if len(title)>0:
                        e1=e.split('<br />')
                        for e2 in e1:
                            if 'href' in e2: #poziom: zrodlo
                                srcName=re.compile('([^<]+?)</a>').findall(e2)[0]
                                srcHref=re.compile('href=\"([^"]+?)\"').findall(e2)[0]
                                if srcName not in chNames:
                                    chNames.append(srcName)
                                    channels.append([srcName,srcHref])
                    #else:
                        #print(e)
    '''
    r1=resp.split('24/7 Channels')[1].split('</p>')[0].split('</a>')
    channels=[]
    for r in r1:
        if 'href' in r and '<strong>' in r:
            srcName=re.compile('<strong>([^<]+?)</strong>').findall(r)[0]
            srcHref=re.compile('<a href=\"([^\"]+?)\"').findall(r)[0]
            channels.append([srcName,srcHref])
    
    for c in channels:
        link=c[1]
        if link.startswith('/'):
            link=baseurl[:-1]+link
        li=xbmcgui.ListItem(c[0])
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': c[0],'sorttitle': c[0],'plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultTVShows.png', 'fanart': ''})
        url = build_url({'mode':'playSource','link':link})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)
    xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_TITLE)

def categList():
    hea={
        'user-agent':UA,
    }

    resp=requests.get(baseurl,headers=hea).text
    dysc=re.compile('<h4>.*>(.*)</span></h4>').findall(resp)
    resp1=resp.split('<br />\n')
    events=[]
    for r1 in resp1:
        if '<h4><span' in r1: #poziom: wydarzenia dla danej dyscypliny
            r2=r1.split('<br>\n')
            evnt=[]
            for e in r2: #poziom: wydarzenie
                if 'href' in e:
                    title=re.compile('([^<]+?)<br />').findall(e)
                    if len(title)>0:
                        title=title[0].replace('p>','').replace('/h4>\n','')
                        e1=e.split('<br />')
                        links=[]
                        for e2 in e1:
                            if 'href' in e2: #poziom: zrodlo
                                srcName=re.compile('([^<]+?)</a>').findall(e2)[0]
                                srcHref=re.compile('href=\"([^"]+?)\"').findall(e2)[0]
                                links.append([srcName,srcHref])
                        evnt.append([title,links])
                    #else:
                        #print(e)
            events.append(evnt)
    addon.setSetting('events',str(events))
    
    for n,d in enumerate(dysc):
        li=xbmcgui.ListItem(d)
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': d,'sorttitle': d,'plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart': ''})
        url = build_url({'mode':'events','categId':str(n)})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)
    
def eventList(categ):
    events=eval(addon.getSetting('events'))
    for n,e in enumerate(events[int(categ)]):
        hour_tit=e[0].split(' ',1)
        hour=hour_tit[0]
        tit=hour_tit[1]
        li=xbmcgui.ListItem('[B]'+hour+'[/B] '+tit)
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': e[0],'sorttitle': e[0],'plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart': ''})
        url = build_url({'mode':'getSource','categId':categ,'eventId':str(n)})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)
    
def getSource(categ,ev):
    
    links=eval(addon.getSetting('events'))[int(categ)][int(ev)][1]
    nameStream=[]
    for l in links:
        nameStream.append(l[0])
    select = xbmcgui.Dialog().select('Źródła', nameStream)
    if select > -1:
        url_stream=links[select][1]
        print(url_stream)
        xbmcplugin.setContent(addon_handle, 'videos')
        playSource(url_stream)
    else:
        quit()
    return


def playSource(u):
    '''
    #print(u)
    id_=str(200-int(u.split('id=')[-1]))
    url_stream='https://uload.ru.com/cdn/premium'+id_+'/chunks.m3u8'+'|Referer=https://player.licenses4.me/&User-Agent='+UA
    '''
    hea={
        'user-agent':UA,
        'referer':baseurl
    }
    resp=requests.get(u,headers=hea).text
    url1=re.compile('<iframe.*src=\"([^\"]+?)\"').findall(resp)[0]
    if not url1.startswith('http'):
        url1=baseurl+url1
    #print(url1)
    hea={
        'user-agent':UA,
        'referer':u
    }
    resp=requests.get(url1,headers=hea).text
    url2=re.compile('\'<iframe src=\"([^\"]+?)\"').findall(resp)[0]
    cid=url1.split('?')[-1]
    fid=str(int(cid.split('id=')[-1])-100)
    url2=url2.split('?')[0]+'?id='+fid
    #print(url2)
    hea={
        'user-agent':UA,
        'referer':url1
    }
    resp=requests.get(url2,headers=hea).text
    stream_url=re.compile('source:\'([^\']+?)\'').findall(resp)[-1]
    #print(stream_url)
    url_stream=stream_url+'|Referer='+url2+'&User-Agent='+UA
    print(url_stream)
    
    play_item = xbmcgui.ListItem(path=url_stream)
    play_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='tv':
        tvList()
        
    if mode=='schedule':
        categList()

    if mode=='events':
        categ=params.get('categId')
        eventList(categ)
        
    if mode=='getSource':
        categ=params.get('categId')
        ev=params.get('eventId')
        getSource(categ,ev)
        
    if mode=='playSource':
        link=params.get('link')
        playSource(link)

