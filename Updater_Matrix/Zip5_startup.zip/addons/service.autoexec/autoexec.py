﻿import xbmc, xbmcgui

xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":1}}')
xbmc.sleep(4000)
xbmcgui.Dialog().notification("[B][COLOR orange]...[/COLOR][/B]", "   ", sound=False, icon='special://home/addons/service.autoexec/icon.png')
