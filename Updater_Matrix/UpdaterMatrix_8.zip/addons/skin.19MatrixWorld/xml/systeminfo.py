﻿def searchsubsettings():
    xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin("ActivateWindowAndFocus(systeminfo)")
    xbmc.executebuiltin("Action(Pause)")
    xbmc.sleep(500)
    xbmc.executebuiltin('SendClick(-?)')
    while xbmc.getCondVisibility("Window.IsVisible(systeminfo)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")

searchsubsettings()
