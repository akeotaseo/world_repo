# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json, re
from tulip import bookmarks, directory, client, cache, control, youtube
from tulip.compat import zip, iteritems
from youtube_resolver import resolve as yt_resolver


class Indexer:

    def __init__(self):  

        self.list = []; self.data = []
        self.base_link = 'https://www.theories.gr'
        self.old_base = 'http://www.theories.gr'
        self.radio_base = 'http://theories.gr'
        self.yt20_channel = 'UC3AxYYw_-ig88NIsGaY7t2w'
        self.yt1_channel = 'UCkdIj6oZdca0dHy6BFQ_4vA'
        self.yt2_channel = 'UCYhH65nE2M8rGwMWvAlVu2A'
        self.yt3_channel = 'UC2rzC5dg2-2fHt09Ex-96Sw'
        self.yt4_channel = 'UCs4k2udZJFof6L-u5Ua9f7g'
        self.yt5_channel = 'UCNxUmg0o63EhSFPyclcvLuA'
        self.yt6_channel = 'UCARjvhFXTdzszk_sqcbhTMg'
        self.yt7_channel = 'UCHw_V7mw2dc6U9uqwUezfCA'
        self.yt8_channel = 'UCjAwOeaiDu9MJ874tJbqNpA'
        self.yt9_channel = 'UCtNzsNCF2xiaCzyzXxu9jQA'
        self.yt_key = ('AIzaSyA1iv-tIfJJYLlHgJTKs-jLh7JvS3XUn-8')
        self.elgr_link = 'https://wowzaprod269-i.akamaihd.net/hls/live/892521/97ef7da0/playlist.m3u8'  
        

    def root(self, audio_only=False):

        self.list = [
         
            
            
            {
                'title': control.lang(101),
                'action': 'archive1',
                'icon': 'ytf1.png'
            }
            ,
            {
                'title': control.lang(102),
                'action': 'archive2',
                'icon': 'ytf2.png'
            }
            ,
            {
                'title': control.lang(103),
                'action': 'archive3',
                'icon': 'ytf3.png'
            }
             ,
            {
                'title': control.lang(104),
                'action': 'archive4',
                'icon': 'ytf4.png'
            }
                         ,
            {
                'title': control.lang(105),
                'action': 'archive5',
                'icon': 'ytf5.png'
            }
                         ,
            {
                'title': control.lang(106),
                'action': 'archive6',
                'icon': 'ytf6.png'
            }
                          ,
            {
                'title': control.lang(107),
                'action': 'archive7',
                'icon': 'ytf7.png'
            }
                          ,
            {
                'title': control.lang(108),
                'action': 'archive8',
                'icon': 'ytf8.png'
            }
                            ,
            {
                'title': control.lang(109),
                'action': 'archive9',
                'icon': 'ytf9.png'
            }
            ,
            {
                'title': control.lang(120),
                'action': 'archive20',
                'icon': 'ytp20.png'
            }
          
        ]

        if audio_only:

            self.list = [self.list[1]] + [self.list[3]]

        for item in self.list:

            cache_clear = {'title': 32009, 'query': {'action': 'cache_clear'}}
            item.update({'cm': [cache_clear]})

        directory.add(self.list, content='videos')

 

    def archive1(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt1_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')

    def archive2(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt2_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')
        
    def archive3(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt3_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')
        
    def archive4(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt4_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')
        
    def archive5(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt5_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')
        
    def archive6(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt6_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')
        
    def archive7(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt7_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')
    
    def archive8(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt8_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')   

    def archive9(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt9_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')        
     
    def archive20(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 20, self.yt20_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')

   
    def episodes(self, url):

        if self.base_link in url:
            self.list = cache.get(self.episodes_listing, 3, url)
        elif self.radio_base in url:
            self.list = cache.get(self.pod_episodes, 3, url)
        else:
            self.list = cache.get(youtube.youtube(key=self.yt_key).playlist, 3, url)

        if self.list is None:

            return

        for i in self.list:

            i.update({'action': 'play', 'isFolder': 'False'})

        directory.add(self.list, content='videos')

    
    def videos(self, url):

        self.list = cache.get(self.video_listing, 3, url)

        if self.list is None:
            return

        for i in self.list:

            i.update({'action': 'play', 'isFolder': 'False'})

        directory.add(self.list)

   

    
    def play(self, url):

        resolved = self.resolve(url)
        
        if 'youtu' in resolved:
            resolved = self.yt_session(resolved)

        if 'youtu' in resolved:
            resolved = self.yt1_session(resolved)
        
        if 'youtu' in resolved:
            resolved = self.yt2_session(resolved)     

        if 'youtu' in resolved:
            resolved = self.yt3_session(resolved)  
         
        if 'youtu' in resolved:
            resolved = self.yt4_session(resolved)
        
        if 'youtu' in resolved:
            resolved = self.yt5_session(resolved)
            
        if 'youtu' in resolved:
            resolved = self.yt6_session(resolved)
        
        if 'youtu' in resolved:
            resolved = self.yt7_session(resolved)
            
        if 'youtu' in resolved:
            resolved = self.yt8_session(resolved)
        
        if 'youtu' in resolved:
            resolved = self.yt9_session(resolved)
         
        if 'youtu' in resolved:
            resolved = self.yt20_session(resolved)         

        if isinstance(resolved, tuple):

            stream, plot = resolved
            meta = {'plot': plot}

        else:

            stream = resolved
            meta = None

        icon = None

        if url == self.elgr_link:

            meta = {'title': 'EL.GR LIVE '}
               

        

        dash = ('dash' in stream or '.mpd' in stream or 'm3u8' in stream) and control.kodi_version() >= 18.0

        directory.resolve(
            url=stream, meta=meta, dash=dash, icon=icon,
            mimetype='application/vnd.apple.mpegurl' if 'm3u8' in stream else None,
            manifest_type='hls' if '.m3u8' in stream else None
        )


    

    

    def resolve(self, url):
        
        if len(url) == 1:

            link = self.yt_session(url)

        if len(url) == 1:

            link = self.yt1_session(url)

            return link
     
        if len(url) == 2:

            link = self.yt2_session(url)

            return link
            
        if len(url) == 2:

            link = self.yt3_session(url)

            return link
            
        if len(url) == 2:

            link = self.yt4_session(url)

            return link
            
        if len(url) == 2:

            link = self.yt5_session(url)

            return link
            
        if len(url) == 2:

            link = self.yt6_session(url)

            return link
            
        if len(url) == 2:

            link = self.yt7_session(url)

            return link
        
        if len(url) == 2:

            link = self.yt8_session(url)

            return link
            
        if len(url) == 2:

            link = self.yt9_session(url)

            return link
        
        if len(url) == 20:

            link = self.yt20_session(url)

            return link


        elif 'episode' in url:

            html = client.request(url)

            if url.startswith(self.elgr_base):

                url = re.search(r'["\'](.+?\.mp3)["\']', html).group(1)

                return url

            else:

                json_ = re.search(r'var data = ({.+?});', html).group(1)

                json_ = json.loads(json_)

                url = ''.join([self.play_link, json_['episode'][0]['media_item_file'], '.m3u8'])

                plot = client.stripTags(json_['episode'][0]['descr'])

                return url, plot

        else:

            return url


  

    @staticmethod
    def yt_session(link):

        streams = yt_resolver(link)

        try:
            addon_enabled = control.addon_details('inputstream.adaptive').get('enabled')
        except KeyError:
            addon_enabled = False

        if not addon_enabled:

            streams = [s for s in streams if 'mpd' not in s['title']]

        stream = streams[0]['url']

        return stream
