﻿# -*- coding: utf-8 -*-

import re
import os
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import shutil
import socket
import random
import time
import requests
import ssl
from urllib.parse import parse_qsl, urlparse, urlencode, quote, quote_plus, unquote_plus
from bs4 import BeautifulSoup, UnicodeDammit
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


socket.setdefaulttimeout(30)
HOST_AND_PATH				= sys.argv[0]
ADDON_HANDLE				= int(sys.argv[1])
dialog									= xbmcgui.Dialog()
addon									= xbmcaddon.Addon()
addon_id							= addon.getAddonInfo('id')
addon_name						= addon.getAddonInfo('name')
addon_version					= addon.getAddonInfo('version')
addon_desc						= addon.getAddonInfo('description')
addonPath							= xbmcvfs.translatePath(addon.getAddonInfo('path')).encode('utf-8').decode('utf-8')
dataPath								= xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode('utf-8').decode('utf-8')
tempDATA							= xbmcvfs.translatePath(os.path.join(dataPath, 'tempDATA', '')).encode('utf-8').decode('utf-8')
WORKS_FILE						= xbmcvfs.translatePath(os.path.join(dataPath, 'episode_data.json'))
FAVORIT_FILE						= xbmcvfs.translatePath(os.path.join(dataPath, 'favorites_SKYLINE.json'))
defaultFanart						= os.path.join(addonPath, 'resources', 'media', 'fanart.jpg')
icon										= os.path.join(addonPath, 'resources', 'media', 'icon.png')
artpic									= os.path.join(addonPath, 'resources', 'media', '').encode('utf-8').decode('utf-8')
flagpic								= os.path.join(addonPath, 'resources', 'media', 'country', '').encode('utf-8').decode('utf-8')
WEB_LANG							= {0: 'de', 1: 'en', 2: 'fr', 3: 'es', 4: 'it', 5: 'el', 6: 'pl', 7: 'ru', 8: 'hr', 9: 'sl'}[int(addon.getSetting('language'))]
# Available Languages(settings) ~ German=0|English=1|French=2|Spanish=3|Italian=4|Greek=5|Polish=6|Russian=7|Croatian=8|Slovenian=9
# Language Codes(SkylineWebCams) ~ 0: de|1: en|2: fr|3: es|4: it|5: el|6: pl|7: ru|8: hr|9: sl
CACHE_PERIOD					= int(addon.getSetting('cache_rhythm'))
LIMITATION						= int(addon.getSetting('max_entries'))
useThumbAsFanart			= addon.getSetting('use_fanart') == 'true'
LAST_STORED					= (int(addon.getSetting('last_agent_stored')) or 0)
ACTUAL_AGENT					= addon.getSetting('actual_user_agent')
enableBACK						= addon.getSetting('show_homebutton') == 'true'
PLACEMENT						= int(addon.getSetting('button_place'))
enableADJUSTMENT			= addon.getSetting('show_settings') == 'true'
DEB_LEVEL							= (xbmc.LOGINFO if addon.getSetting('enable_debug') == 'true' else xbmc.LOGDEBUG)
KODI_ov20							= int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) >= 20
KODI_un21							= int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) <= 20
# IMG_flags						= 'https://img.freeflagicons.com/thumb/round_icon/{}/{}_640.png'
FULL_URL							= f'https://www.skylinewebcams.com/{WEB_LANG}/webcam.html'
TOPS_URL							= f'https://www.skylinewebcams.com/{WEB_LANG}/top-live-cams.html'
NEWS_URL							= f'https://www.skylinewebcams.com/{WEB_LANG}/new-livecams.html'
LANG_URL							= f"https://www.skylinewebcams.com/{WEB_LANG}.html"
BASE_URL							= "https://www.skylinewebcams.com"

xbmcplugin.setContent(ADDON_HANDLE, 'movies')

def py3_dec(d, nom='utf-8', ign='ignore'):
	if isinstance(d, bytes):
		d = d.decode(nom, ign)
	return d

def translation(id):
	return addon.getLocalizedString(id)

def failing(content):
	log(content, xbmc.LOGERROR)

def debug_MS(content):
	log(content, DEB_LEVEL)

def log(msg, level=xbmc.LOGINFO):
	return xbmc.log(f"[{addon_id} v.{addon_version}]{str(msg)}", level)

def build_mass(body):
	return f"{HOST_AND_PATH}?{urlencode(body)}"

def getRandom():
	#remove random user agent
	return 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'

def _header(ORIGIN=None, REFERRER=None):
	header = {} # !!! Accept-Language only set if browser should offer these languages !!!
	header['Cache-Control'] = 'public, max-age=300'
	header['Accept'] = 'application/json, application/x-www-form-urlencoded, text/plain, */*'
	header['documentLifecycle'] = 'active'
	header['User-Agent'] = getRandom()
	header['DNT'] = '1'
	header['Upgrade-Insecure-Requests'] = '1'
	header['Accept-Encoding'] = 'gzip'
	if ORIGIN: header['Origin'] = ORIGIN
	if REFERRER: header['Referer'] = REFERRER
	return header

def getContent(url, method='GET', queries='TEXT', ORG=BASE_URL, REF=LANG_URL, headers={}, redirects=True, verify=True, data=None, json=None, timeout=30):
	ANSWER = None
	try:
		response = requests.request(method, url, headers=_header(ORG, REF), allow_redirects=redirects, verify=verify, timeout=timeout)
		ANSWER = response.json() if queries == 'JSON' else response.text if queries == 'TEXT' else response
		debug_MS(f"(common.getContent) === CALLBACK === STATUS : {response.status_code} || URL : {response.url} || HEADER : {_header(ORG, REF)} ===")
	except requests.exceptions.RequestException as exc:
		failing(f"(common.getContent) ERROR - EXEPTION - ERROR ##### URL : {url} === FAILURE : {exc} #####")
		dialog.notification(translation(30521).format('URL'), translation(30523).format(exc), icon, 12000)
		return sys.exit(0)
	return ANSWER

def preserve(store, data=None):
	if data is not None:
		with open(store, 'w') as topics:
			json.dump(data, topics, indent=2, sort_keys=True)
	else:
		with open(store, 'r') as topics:
			arrive = json.load(topics)
		return arrive

def clear_storage():
	debug_MS("(common.clear_storage) -------------------------------------------------- START = clear_storage --------------------------------------------------")
	debug_MS("(common.clear_storage) ========== Delete the Addon-Cache now ==========")
	if xbmcvfs.exists(tempDATA):
		shutil.rmtree(tempDATA, ignore_errors=True) # Delete tempDATA-Folder
	xbmc.sleep(1000)
	return dialog.ok(addon_id, translation(30501))

def cleanUmlaut(wrong):
	if wrong is not None:
		for wg in (('ä', 'ae'), ('Ä', 'Ae'), ('ü', 'ue'), ('Ü', 'Ue'), ('ö', 'oe'), ('Ö', 'Oe'), ('ß', 'ss')):
			wrong = wrong.replace(*wg)
		wrong = wrong.strip()
	return wrong

def clear_unknown(text):
	if text is not None:
		text = re.sub(r'<h3>.*?</h3>', '', text)
		for ea in (('<strong>', ''), ('</strong>', ''), ('<b>', ''), ('</b>', ''), ('<em>', ''), ('</em>', ''), ('<br>', ' '), ('</p>', '[CR]')):
			text = text.replace(*ea)
		convert = UnicodeDammit(text.strip()) # Declare unknown Encodings in Request-results (from bs4 import UnicodeDammit)
		return convert.unicode_markup
	return None

def create_entries(metadata, SIGNS=None):
	listitem = xbmcgui.ListItem(metadata['Title'])
	vinfo = listitem.getVideoInfoTag() if KODI_ov20 else {}
	if KODI_ov20: vinfo.setTitle(metadata['Title'])
	else: vinfo['Title'] = metadata['Title']
	if metadata.get('Tagline', ''):
		if KODI_ov20: vinfo.setTagLine(metadata['Tagline'])
		else: vinfo['Tagline'] = metadata['Tagline']
	description = metadata['plot_long'] if metadata.get('plot_long') not in ['', 'None', None] else ' '
	if KODI_ov20: vinfo.setPlot(description)
	else: vinfo['Plot'] = description
	if metadata.get('Country', ''):
		if KODI_ov20: vinfo.setCountries([metadata['Country']])
		else: vinfo['Country'] = metadata['Country']
	if str(metadata.get('Rating')).replace('.', '').isdecimal() and str(metadata.get('Voting')).isdecimal():
		if KODI_ov20: vinfo.setRating(float(metadata['Rating']), int(metadata['Voting']), 'user', True) # vinfo.setRating(4.6, 8940, "imdb", True) since NEXUS and UP
		else: listitem.setRating('user', float(metadata['Rating']), int(metadata['Voting']), True) # listitem.setRating("imdb", 4.6, 8940, True) below NEXUS (MATRIX)
	if metadata.get('Studio', ''):
		if KODI_ov20: vinfo.setStudios([metadata['Studio']])
		else: vinfo['Studio'] = metadata['Studio']
	if metadata.get('Mediatype', ''):
		if KODI_ov20: vinfo.setMediaType(metadata['Mediatype'])
		else: vinfo['Mediatype'] = metadata['Mediatype']
	picture, piclogo = metadata.get('Image', icon), metadata.get('Logo', None)
	listitem.setArt({'icon': icon, 'thumb': picture, 'poster': picture, 'clearlogo': piclogo})
	if useThumbAsFanart: listitem.setArt({'fanart': defaultFanart})
	if not KODI_ov20: listitem.setInfo('Video', vinfo)
	return listitem