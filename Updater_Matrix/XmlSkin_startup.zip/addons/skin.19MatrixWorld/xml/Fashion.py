import xbmc, xbmcgui


def Fashion():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]       Fashion[/COLOR][/B]',
['[COLOR=grey]Fashion TV Player[/COLOR]',
'[COLOR=grey]Fashion [/COLOR] MIDNIGHT SECRETS',
 '[COLOR=grey]Fashion[/COLOR]  playlistloaderworld'])


    if call:
        if call < 1:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.fashiontv.com/",return)')


def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsdevil/?item=title%3dMIDNIGHT%2bSECRETS%26cfg%3dftv.cfg%2540streams%2540MIDNIGHT%2bSECRETS%26url%3dhttps%253A%252F%252Fpastebin.com%252Fraw%252FpRbWnggL%26director%3dftv.com%26icon%3dhttps%253A%252F%252Ffiles.fashiontv.com%252Fwp-content%252Fuploads%252F2018%252F02%252Fapple-icon-180x180.png%26type%3drss%26genre%3dHighlights%26definedIn%3dhighlights%252Fftv.cfg&mode=1")')


def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloaderworld/?cache=0&epg&iconimage=DefaultTVShows.png&index=69&logos&mode=10&name=Fashion&url=https%3a%2f%2fdl.dropbox.com%2fscl%2ffi%2fur595ef4cqmfst951kboh%2f.NET_2.m3u%3frlkey%3d0cw1ficfrq0m6yg2udh16qn78%26st%3dmi2d2yud.m3u&uuid=0")')




Fashion()
