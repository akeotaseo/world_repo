﻿import xbmc, xbmcgui
def Backup():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('Action(Back)')
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('ActivateWindow(Home)')
    # xbmc.sleep(1000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση[/COLOR][/B]", "Agendas + Canales [B][COLOR lightpink]● Acestreams[/B] [/COLOR]", sound=False, icon='http://addonbg.co/black/img/acestream.png')
    xbmc.sleep(4000)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=http%3a%2f%2faddonbg.co%2fblack%2fimg%2ffanart.jpg&mode=1&name=Agendas%20%2b%20Canales%20%5bB%5d%5bCOLOR%20lightpink%5d%e2%97%8f%20Acestreams%5b%2fB%5d%20%5b%2fCOLOR%5d&url=http%3a%2f%2faddonbg.co%2fblack%2f0-plexus.php%3fm47")')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=http%3a%2f%2faddonbg.co%2fblack%2fimg%2ffanart.jpg&mode=1&name=Agendas%20%2b%20Canales%20%5bB%5d%5bCOLOR%20lightpink%5d%e2%97%8f%20Acestreams%5b%2fB%5d%20%5b%2fCOLOR%5d&url=http%3a%2f%2faddonbg.co%2fblack%2f0-plexus.php%3fm47")')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=http%3a%2f%2faddonbg.co%2fblack%2fimg%2ffanart.jpg&mode=1&name=Agendas%20%2b%20Canales%20%5bB%5d%5bCOLOR%20lightpink%5d%e2%97%8f%20Acestreams%5b%2fB%5d%20%5b%2fCOLOR%5d&url=http%3a%2f%2faddonbg.co%2fblack%2f0-plexus.php%3fm47")')


    #xbmc.executebuiltin('Action(Back)')
    #xbmc.executebuiltin('Dialog.Close(all,true)')
    #xbmc.sleep(1000)


def Livetv_setMj_on():
    addon_microjen       = xbmcaddon.Addon('plugin.video.microjen')
    setting_microjen     = addon_microjen.getSetting
    setting_set_microjen = addon_microjen.setSetting
    if not setting_microjen('enable_ace_links')=='true':
        xbmc.sleep(1000)
        setting_set_microjen('enable_ace_links', 'true')

Backup()