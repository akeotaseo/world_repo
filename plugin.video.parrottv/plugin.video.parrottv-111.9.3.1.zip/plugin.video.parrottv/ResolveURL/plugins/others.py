# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests
from ..utils.resolve import Resolver

class Others(Resolver):
    def __init__(self):
        self.ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36'
        self.channels = requests.get('https://parrot-tv.pages.dev/api/Channels/m3u8.json', headers=self.headers).json()

    def grab(self, channel):
        country = channel.split('-')[0]
        channel = channel.split('-')[1]
        return self.channels[country][channel], {'User-Agent': self.ua}