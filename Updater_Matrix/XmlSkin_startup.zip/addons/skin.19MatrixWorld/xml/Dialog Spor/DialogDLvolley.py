﻿import xbmc, xbmcgui

def DialogDLvolley():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/?mode=showChannels&trType=Volleyball")')
    xbmcgui.Dialog().notification("[B][COLOR red]Daddylive[/COLOR][/B]", "[COLOR blue]VOLLEY[/COLOR][COLOR gold]BALL[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/volleyball.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR red]Daddylive[/COLOR][/B]", "[COLOR blue]VOLLEY[/COLOR][COLOR gold]BALL[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/volleyball.png')
DialogDLvolley()


