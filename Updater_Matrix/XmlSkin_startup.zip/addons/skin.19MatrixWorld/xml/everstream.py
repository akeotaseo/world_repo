﻿import xbmc, xbmcgui
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "plugin.video.everstream","enabled":true}}')
xbmcgui.Dialog().notification("[B][COLOR orange]Everstream[/COLOR][/B]", "   ", sound=False, icon='https://ynsfashion.co.uk/thewiz/repo/zips/plugin.video.everstream/icon.png')
xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.everstream/")')