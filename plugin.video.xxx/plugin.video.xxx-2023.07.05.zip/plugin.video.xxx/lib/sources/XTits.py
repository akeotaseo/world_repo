import re
import xbmcaddon
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

BaseURL = 'https://www.xtits.com'
Thumb   = 'special://home/addons/plugin.video.xxx/resources/art/xtits.png'


def Menu():
	addDir('Latest Videos',      BaseURL + '/latest-updates/1/', 41, Thumb)
	addDir('Most Viewed Videos', BaseURL + '/most-popular/1/',   41, Thumb)
	addDir('Top Rated Videos',   BaseURL + '/top-rated/1/',      41, Thumb)
	addDir('Categories',         BaseURL + '/categories/',     42, Thumb)

def Browse(url):
	r = OpenURL(url)
	r = r.replace('\n', '')
	r = r.replace('	', '')
	m = re.compile('<div class="item thumb-item  ">(.+?)</div></a></div>').findall(r)
	for i in m:
		title = re.compile('title="(.+?)"').findall(i)[0]
		time  = re.compile('<span class="label time"><i class="icon-hd"></i>(.+?)</span>').findall(i)[0]
		url   = re.compile('href="(.+?)"').findall(i)[0]
		thumb = re.compile(' thumb="(.+?)"').findall(i)[0]
		if Setting('show_time') == 'true': title = '[B](%s)[/B] %s' % (time, title)
		import random
		random_id = random.randint(0,1000000)
		url = '%s&random_id=%s' % (url, str(random_id))
		if time.startswith('19:'): pass
		elif time.startswith('18:'): pass
		elif time.startswith('17:'): pass
		elif time.startswith('16:'): pass
		elif time.startswith('15:'): pass
		elif time.startswith('14:'): pass
		elif time.startswith('13:'): pass
		elif time.startswith('12:'): pass
		elif time.startswith('11:'): pass
		elif time.startswith('10:'): pass
		elif time.startswith('9:'): pass
		elif time.startswith('8:'): pass
		elif time.startswith('7:'): pass
		elif time.startswith('6:'): pass
		elif time.startswith('5:'): pass
		elif time.startswith('4:'): pass
		elif time.startswith('3:'): pass
		elif time.startswith('2:'): pass
		elif time.startswith('1:'): pass
		else: addVideo(title, url, 43, thumb)
	#n = re.compile('<li class="item-pagin is_last">\n.+?<a class="link" href="(.+?)" ').findall(r)
	n = re.compile('<li class="item-pagin is_last">\n						<a class="link" href="(.+?)" data-action="ajax"').findall(r)
	for NextPage in n:
		addDir('Next page >' + NextPage, BaseURL + NextPage, 41, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	Common.SetView()

def Categories(url):
	r = OpenURL(url)
	m = re.compile('<a class="link" href="https://www\.xtits\.com/categories/(.+?)/" title="(.+?)">').findall(r)
	for content_id, title in m:
		addDir(title, 'https://www.xtits.com/categories/%s/' % content_id, 41, Thumb)
	n = re.compile('<li class="item-pagin is_last">\n						<a class="link" href="(.+?)"').findall(r)
	for NextPage in n:
		addDir('Next page >', BaseURL + NextPage, 42, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')

def PlayStream(url):
	if 'random_id=' in url:
		url = re.compile('(.+?)&random_id').findall(url)[0]
	r = OpenURL(url)
	m = re.compile('video_url: \'(.+?)\'').findall(r)
	for url in m:
		Play(url)
