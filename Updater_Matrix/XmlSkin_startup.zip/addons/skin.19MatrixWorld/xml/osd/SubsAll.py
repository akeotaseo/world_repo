﻿import xbmc

def SubsAll():
  #  xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin("ActivateWindowAndFocus(OSDSubtitleSettings)")
    xbmc.executebuiltin("Action(Pause)")
    xbmc.sleep(500)
    xbmc.executebuiltin('SendClick(-178)')
    while xbmc.getCondVisibility("Window.IsVisible(OSDSubtitleSettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")

SubsAll()
