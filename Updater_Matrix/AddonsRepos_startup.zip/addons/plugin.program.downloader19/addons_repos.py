
ADDONS_REPOS = [('repository.Worldolympic', 'repository.World'),
                     ('repository.World', 'repository.World'),
                     ('plugin.video.watchnixtoons2', 'repository.thecrew'),
                     ('plugin.video.live.streamspro', 'repository.Worldolympic'),
                     ('plugin.video.macvod', 'repository.Worldolympic'),
                     ('plugin.video.rumble', 'repository.Worldolympic'),
                     ('repository.castagnait', 'repository.castagnait'),
                     ('plugin.program.downloader', 'repository.gkobu'),
                     
                     ('script.realdebridsite', 'repository.Worldolympic'),
                     ('service.World.Build', 'repository.Worldolympic'),
                     
                     ('repository.twilight0', 'repository.twilight0'),
                     ('script.module.tulip', 'repository.twilight0'),
                     
                     ('script.kelebek', 'repository.World'),
                     ('script.luar', 'repository.World'),
                     
                     ('plugin.video.f4mTester', 'repository.World'),
                     ('script.video.F4mProxy', 'repository.gkobu'),
                     
                     ('plugin.video.neo.tv', 'repository.7Plus'),
                     
                     ('plugin.video.daddylive', 'repository.World'),
                     
                     ('repository.rays.files', 'repository.rays.files'),
                     ('repository.roooar', 'repository.roooar'),
                     ('repository.dexe', 'repository.dexe'),
                     ('plugin.video.BauBauVavoo', 'repository.dexe'),
                     ('plugin.video.GreenKlikPremium', 'repository.dexe'),
                     
                     ('plugin.video.quicksilver', 'repository.cMaNWizard'),
                     ('script.module.quicksilverscrapers', 'repository.cMaNWizard'),
                     ('script.quicksilver.artwork', 'repository.cMaNWizard'),
                     ('repository.cMaNWizard', 'repository.cMaNWizard'),
                     
                     ('plugin.video.atlas', 'repository.atlas'),
                     
                     ('repository.lekma', 'repository.lekma'),
                     ('plugin.video.invidious', 'repository.lekma'),
                     
                     ('repository.Kpoodle20', 'repository.Kpoodle20'),
                     ('repository.diggz', 'repository.diggz'),
                     ('repository.matrix', 'repository.matrix'),
                     
                     ('script.extendedinfo', 'repository.gkobu'),
                     ('repository.Worldrepo', 'repository.World')]