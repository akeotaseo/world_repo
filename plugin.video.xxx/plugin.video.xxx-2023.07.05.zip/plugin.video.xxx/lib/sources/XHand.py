import re
import xbmcaddon
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

BaseURL = 'https://xhand.com'
Thumb   = 'special://home/addons/plugin.video.xxx/resources/art/xhand.png'


def Menu():
	addDir('Latest Videos',      BaseURL + '/latest-updates/', 91, Thumb)
	addDir('Most Viewed Videos', BaseURL + '/most-popular/',   91, Thumb)
	addDir('Top Rated Videos',   BaseURL + '/top-rated/',      91, Thumb)
	addDir('Categories',         BaseURL + '/categories/',     92, Thumb)
	addDir('Sites',              BaseURL + '/sites/',          92, Thumb)

def Browse(url):
	r = OpenURL(url)
	r = r.replace('\n', '')
	r = r.replace('	', '')
	m = re.compile('<div class="item col  ">(.+?)</div>').findall(r)
	for i in m:
		url   = re.compile(' href="(.+?)"').findall(i)[0]
		thumb = re.compile('data-original="(.+?)"').findall(i)[0]
		if not thumb.startswith('http'): thumb = 'http:' + thumb
		time  = re.compile('<span class="card__time">(.+?)</span>').findall(i)[0]
		title = re.compile('title="(.+?)"').findall(i)[0]
		if Setting('show_time') == 'true': title = '[B](%s)[/B] %s' % (time, title)
		url = '%s&random_id=%s' % (url, RandomID())
		if time.startswith('19:'): pass
		elif time.startswith('18:'): pass
		elif time.startswith('17:'): pass
		elif time.startswith('16:'): pass
		elif time.startswith('15:'): pass
		elif time.startswith('14:'): pass
		elif time.startswith('13:'): pass
		elif time.startswith('12:'): pass
		elif time.startswith('11:'): pass
		elif time.startswith('10:'): pass
		elif time.startswith('9:'): pass
		elif time.startswith('8:'): pass
		elif time.startswith('7:'): pass
		elif time.startswith('6:'): pass
		elif time.startswith('5:'): pass
		elif time.startswith('4:'): pass
		elif time.startswith('3:'): pass
		elif time.startswith('2:'): pass
		elif time.startswith('1:'): pass
		else: addVideo(title, url, 93, thumb)
	n = re.compile('arrow-next"><a href="(.+?)"').findall(r)
	for NextPage in n:
		addDir('Next page >', BaseURL + NextPage, 91, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	Common.SetView()

def Categories(url):
	r = OpenURL(url + 'total-videos/')
	r = r.replace('\n', '')
	r = r.replace('	', '')
	m = re.compile('<div class="categories__col.+?>(.+?)</div>').findall(r)
	for i in m:
		title = re.compile('title="(.+?)"').findall(i)[0]
		url   = re.compile('href="(.+?)"').findall(i)[0]
		try: thumb = re.compile('<img class="thumb" src="(.+?)"').findall(i)[0]
		except: thumb = Thumb
		addDir(title.title(), url, 91, thumb)
	
	n = re.compile('arrow-next"><a href="(.+?)"').findall(r)
	for NextPage in n:
		addDir('Next page >', BaseURL + NextPage, 91, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	
def PlayStream(url):
	if 'random_id=' in url: url = re.compile('(.+?)&random_id').findall(url)[0]
	r = OpenURL(url)
	try: video = re.compile('video_alt_url: \'(.+?)\'').findall(r)[0]
	except: video = re.compile('video_url: \'(.+?)\'').findall(r)[0]
	Play(video)

def RandomID():
	import random
	random_id = str(random.randint(0,1000000))
	return random_id