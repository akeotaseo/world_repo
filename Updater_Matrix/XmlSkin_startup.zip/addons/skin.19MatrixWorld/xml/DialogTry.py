﻿import xbmc, xbmcgui

def DialogTry():

    xbmcgui.Dialog().notification("[B][COLOR orange]Try![/COLOR][/B]", "[COLOR green]Ισως σταθήτε τυχαιροί...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/dice.gif')

    #xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Try![/COLOR][/B]", "[COLOR green]Ισως σταθήτε τυχαιροί...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/dice.gif')
    xbmcgui.Dialog().notification("[B][COLOR orange]Try![/COLOR][/B]", "[COLOR green]Ισως σταθήτε τυχαιροί...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/dice.gif')
    #xbmc.sleep(4000)
    #xbmcgui.Dialog().notification("[B][COLOR orange]Does' t work all time[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png')
    #xbmc.sleep(4000)
    #xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.program.autowidget/?mode=group&refresh&reload)")

DialogTry()
