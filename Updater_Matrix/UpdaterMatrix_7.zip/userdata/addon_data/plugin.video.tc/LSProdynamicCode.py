#$pyFunction
def GetLSProData(page_data,Cookie_Jar,m,url = ''):
    import re
    from resources.lib.modules import control
    if not control.infoLabel('Container.PluginName') == 'plugin.video.thecrew': return
    page_data = page_data.split('EPL Standings', 1)[-1]
    e = re.findall('item"><a href="([^"]*)(?:.*?g>)([^<]*)', page_data)
    sort = [('https://daddylive.click'+i[0],i[1]) for i in e]
    return sorted(sort,key=lambda thecrew: (thecrew[1]))