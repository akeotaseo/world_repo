#default.py
import os
import sys
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import xbmcplugin
import requests
import urllib.parse

from resources.lib import filmzie
from resources.lib.subtitles import search_subtitles, download_subtitle, subs_path

addon = xbmcaddon.Addon()
handle = int(sys.argv[1])
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))

action = params.get("action")
category = params.get("category")
page = int(params.get("page", "1"))
per_page = int(addon.getSetting("movies_per_page") or 30)

ICON_PATH = os.path.join(addon.getAddonInfo('path'), 'resources', 'media', 'categories')
SUB_LANGUAGES = addon.getSetting('subs_languages') or 'ro'

CATEGORY_ICON_MAP = {
    "Action": "actiune.png",
    "Adventure": "aventuri.png",
    "Biography": "biografic.png",
    "Drama": "drama.png",
    "Thriller": "thriller.png",
    "Animation": "animatie.png",
    "Comedy": "comedie.png",
    "Documentary": "documentar.png",
    "Romance": "romantic.png",
    "Family": "familie.png",
    "Fantasy": "fantastic.png",
    "Horror": "horror.png",
    "History": "istoric.png",
    "Music": "muzica.png",
    "Musical": "muzica.png",
    "Mystery": "mister.png",
    "News": "stiri.png",
    "Reality-TV": "reality.png",
    "Sci-Fi": "sf.png",
    "War": "militar.png",
    "Western": "western.png",
    "Crime": "crima.png",
    "Short": "short.png",
    "European Production": "european.png",
    "Căutare": "search.png"
}

def get_stream_url(video_id):
    url = f"https://filmzie.com/api/v1/video/stream/{video_id}"
    try:
        response = requests.get(url, timeout=10)

        if response.ok:
            data = response.json()
            return data.get("data", {}).get("source", {}).get("hlsV2")
    except Exception as e:
        xbmc.log(f"[Filmzie] ❌ Eroare în get_stream_url: {e}", xbmc.LOGERROR)
    return None

#==========LISTARE==========

def get_category_icon(name):
    filename = CATEGORY_ICON_MAP.get(name)

    if not filename:
        fallback_name = name.lower().replace(" ", "").replace("-", "").replace("…", "")
        filename = f"{fallback_name}.png"

    path = os.path.join(ICON_PATH, filename)
    return path if xbmcvfs.exists(path) else ""

def list_categories():
    search_url = f"{sys.argv[0]}?action=search"
    li = xbmcgui.ListItem(label="Căutare…")
    icon_path = get_category_icon("Căutare")
    if icon_path:
        li.setArt({"thumb": icon_path, "icon": icon_path})
    xbmcplugin.addDirectoryItem(handle, search_url, li, isFolder=True)

    categories = filmzie.get_categories()
    for cat in categories:
        url = f"{sys.argv[0]}?action=list_movies&category={cat['id']}&page=1"
        li = xbmcgui.ListItem(label=cat["name"])
        icon_path = get_category_icon(cat["name"])
        if icon_path:
            li.setArt({"thumb": icon_path, "icon": icon_path})
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def list_movies(category, page):
    offset = (page - 1) * per_page
    movies = filmzie.get_movies_by_category(category, limit=per_page, offset=offset)

    for movie in movies:
        li = xbmcgui.ListItem(label=movie["title"])
        li.setArt({
            "thumb": movie["poster"],
            "icon": movie["poster"],
            "poster": movie["poster"],
            "fanart": movie["fanart"]
        })
        li.setInfo("video", {"title": movie["title"], "plot": movie["plot"]})
        li.setProperty("IsPlayable", "true")
        play_url = f"{sys.argv[0]}?action=play&id={movie['video_id']}&imdb_id={movie.get('imdb_id', '')}"


        context_menu = []
        if movie.get("trailer_id"):
            trailer_url = f"{sys.argv[0]}?action=play_trailer&id={movie['trailer_id']}"
            context_menu.append(("Trailer", f"PlayMedia({trailer_url})"))
        li.addContextMenuItems(context_menu)

        xbmcplugin.addDirectoryItem(handle, play_url, li, isFolder=False)

    if len(movies) == per_page:
        next_url = f"{sys.argv[0]}?action=list_movies&category={category}&page={page + 1}"
        li = xbmcgui.ListItem(label=">> Pagina următoare...")
        xbmcplugin.addDirectoryItem(handle, next_url, li, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

#==========REDARE==========

def play_movie(params):
    video_id = params.get("id")
    imdb_id = params.get("imdb_id")
    stream_url = get_stream_url(video_id)
    if not stream_url:
        xbmcgui.Dialog().notification('Filmzie', '❌ Nu s-a găsit URL-ul de redare.', xbmcgui.NOTIFICATION_ERROR)
        return

    listitem = xbmcgui.ListItem(label="Filmzie")
    listitem.setPath(stream_url)
    listitem.setMimeType('application/vnd.apple.mpegurl')
    listitem.setProperty('inputstream', 'inputstream.adaptive')
    listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
    listitem.setContentLookup(False)

    subtitle_files = []
    if imdb_id:
        lang_list = SUB_LANGUAGES.split(",")
        for lang in lang_list:
            subs = search_subtitles(imdb_id, lang)
            for idx, sub in enumerate(subs):
                subfile = download_subtitle(sub, subs_path, index=idx)
                if subfile:
                    subtitle_files.append(subfile)


        if subtitle_files:
            listitem.setSubtitles(subtitle_files)
    handle = int(sys.argv[1])
    xbmcplugin.setResolvedUrl(handle, succeeded=True, listitem=listitem)

def play_trailer(video_id):
    stream_url = filmzie.get_stream_url(video_id)

    if not stream_url:
        xbmcgui.Dialog().notification("Filmzie", "Trailer indisponibil.", xbmcgui.NOTIFICATION_ERROR)
        return

    li = xbmcgui.ListItem(path=stream_url)
    li.setMimeType("application/vnd.apple.mpegurl")
    li.setProperty("inputstream", "inputstream.adaptive")
    li.setProperty("inputstream.adaptive.manifest_type", "hls")
    li.setProperty("inputstream.adaptive.stream_selection_type", "adaptive")
    xbmcplugin.setResolvedUrl(handle, True, li)

#==========CĂUTARE==========

def search_movies_ui(query=None, page=1):
    if not query:
        keyboard = xbmcgui.Dialog().input("Caută pe Filmzie", type=xbmcgui.INPUT_ALPHANUM)
        if not keyboard:
            return
        query = keyboard

    per_page = int(xbmcaddon.Addon().getSetting("per_page") or 30)
    offset = (page - 1) * per_page
    movies = filmzie.search_movies(query, limit=per_page, offset=offset)

    if not movies:
        xbmcgui.Dialog().notification("Căutare Filmzie", "Niciun rezultat găsit.", xbmcgui.NOTIFICATION_INFO)
        return

    for movie in movies:
        title = movie.get("title", "Fără titlu")
        plot = movie.get("description", "")
        year = movie.get("releaseYear")
        duration = movie.get("duration", 0)
        genres = [genre["name"] for genre in movie.get("genres", [])]
        video_id = movie.get("mainVideoId")

        poster_key = movie.get("images", {}).get("poster", {}).get("amazonKey", "")
        logo_key = movie.get("images", {}).get("logo", {}).get("amazonKey", "")
        poster = f"https://img.filmzie.com/cdn/v7/https://d3qxhvuywdalwo.cloudfront.net/{poster_key}?w=200&q=70" if poster_key else ""
        logo = f"https://img.filmzie.com/cdn/v7/https://d3qxhvuywdalwo.cloudfront.net/{logo_key}?w=200&q=70" if logo_key else ""

        li = xbmcgui.ListItem(label=title)
        li.setInfo("video", {
            "title": title,
            "plot": plot,
            "year": int(year) if year else 0,
            "duration": int(duration),
            "genre": ", ".join(genres)
        })
        li.setArt({
            "poster": poster,
            "thumb": poster,
            "fanart": poster,
            "logo": logo
        })

        li.setProperty("IsPlayable", "true")
        context_menu = []
        if movie.get("trailerVideoIds"):
            trailer_id = movie["trailerVideoIds"][0]
            trailer_url = f"{sys.argv[0]}?action=play_trailer&id={trailer_id}"
            context_menu.append(("Trailer", f'RunPlugin("{trailer_url}")'))
        li.addContextMenuItems(context_menu)

        url = f"{sys.argv[0]}?action=play&id={video_id}"
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)

    if len(movies) == per_page:
        next_page_url = f"{sys.argv[0]}?action=search&query={urllib.parse.quote_plus(query)}&page={page+1}"
        li = xbmcgui.ListItem(label="Pagina următoare ▶")
        xbmcplugin.addDirectoryItem(handle, next_page_url, li, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

#==========PARAMETRII==========

if action == "list_movies" and category:
    list_movies(category, page)
elif action == "play":
    video_id = params.get("id")
    imdb_id = params.get("imdb_id")
    if video_id:
        play_movie(params)
elif action == "play_trailer":
    trailer_id = params.get("id")
    if trailer_id:
        play_trailer(trailer_id)
elif action == "search":
    query = params.get("query")
    search_movies_ui(query, page)
else:
    list_categories()
