# -*- coding: utf-8 -*-

import resources.lib.ripe_addon as addon

# Runs the add-on from here.
if __name__ == "__main__":
    addon.run()
