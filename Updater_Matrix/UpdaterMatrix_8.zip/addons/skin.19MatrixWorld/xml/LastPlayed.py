﻿import xbmc

def LastPlayed():
    #xbmc.executebuiltin("ActivateWindow(Home)")
    #xbmc.sleep(1000)
    xbmc.executebuiltin("Action(Close)")
    #xbmc.sleep(1000)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.last_played/",return)')

LastPlayed()
