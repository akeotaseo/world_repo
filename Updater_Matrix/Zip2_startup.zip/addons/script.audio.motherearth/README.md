# script.audio.motherearth
Mother Earth Radio - Hi Res Audio and Vinyl 192kHz/24bit FLAC streaming

Version 2.3

Choose FLAC or AAC-stream in addon options.
