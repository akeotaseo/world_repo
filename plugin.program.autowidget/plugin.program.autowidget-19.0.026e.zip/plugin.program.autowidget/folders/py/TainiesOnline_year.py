import xbmc, xbmcgui


def tainiesonline_year():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13, click_14,
             click_15, click_16, click_17, click_18, click_19, click_20, click_21, click_22, click_23, click_24, click_25, click_26, click_27,
             click_28, click_29, click_30, click_31, click_32, click_33, click_34, click_35, click_36, click_37, click_38, click_39, click_40,
             click_41, click_42, click_43, click_44, click_45, click_46, click_47, click_48, click_49, click_50, click_51, click_52, click_53,
             click_54, click_55, click_56, click_57, click_58, click_59, click_60, click_61, click_62, click_63, click_64, click_65, click_66,
             click_67, click_68, click_69, click_70, click_71, click_72, click_73, click_74, click_75, click_76, click_77, click_78, click_79,
             click_80, click_81, click_82, click_83, click_84, click_85, click_86, click_87, click_88, click_89, click_90, click_91, click_92,
             click_93, click_94, click_95, click_96, click_97, click_98, click_99, click_100, click_101, click_102, click_103)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]                                      Έτος κυκλοφορίας [/COLOR][/B]', 
['[B][COLOR=white]                                                          2022[/COLOR][/B]',
 '[B][COLOR=white]                                                          2021[/COLOR][/B]',
 '[B][COLOR=white]                                                          2020[/COLOR][/B]',
 '[B][COLOR=white]                                                          2019[/COLOR][/B]',
 '[B][COLOR=white]                                                          2018[/COLOR][/B]',
 '[B][COLOR=white]                                                          2017[/COLOR][/B]',
 '[B][COLOR=white]                                                          2016[/COLOR][/B]',
 '[B][COLOR=white]                                                          2015[/COLOR][/B]',
 '[B][COLOR=white]                                                          2014[/COLOR][/B]',
 '[B][COLOR=white]                                                          2013[/COLOR][/B]',
 '[B][COLOR=white]                                                          2012[/COLOR][/B]',
 '[B][COLOR=white]                                                          2011[/COLOR][/B]',
 '[B][COLOR=white]                                                          2010[/COLOR][/B]',
 '[B][COLOR=white]                                                          2009[/COLOR][/B]',
 '[B][COLOR=white]                                                          2008[/COLOR][/B]',
 '[B][COLOR=white]                                                          2007[/COLOR][/B]',
 '[B][COLOR=white]                                                          2006[/COLOR][/B]',
 '[B][COLOR=white]                                                          2005[/COLOR][/B]',
 '[B][COLOR=white]                                                          2004[/COLOR][/B]',
 '[B][COLOR=white]                                                          2003[/COLOR][/B]',
 '[B][COLOR=white]                                                          2002[/COLOR][/B]',
 '[B][COLOR=white]                                                          2001[/COLOR][/B]',
 '[B][COLOR=white]                                                          2000[/COLOR][/B]',
 '[B][COLOR=white]                                                          1999[/COLOR][/B]',
 '[B][COLOR=white]                                                          1998[/COLOR][/B]',
 '[B][COLOR=white]                                                          1997[/COLOR][/B]',
 '[B][COLOR=white]                                                          1996[/COLOR][/B]',
 '[B][COLOR=white]                                                          1995[/COLOR][/B]',
 '[B][COLOR=white]                                                          1994[/COLOR][/B]',
 '[B][COLOR=white]                                                          1993[/COLOR][/B]',
 '[B][COLOR=white]                                                          1992[/COLOR][/B]',
 '[B][COLOR=white]                                                          1991[/COLOR][/B]',
 '[B][COLOR=white]                                                          1990[/COLOR][/B]',
 '[B][COLOR=white]                                                          1989[/COLOR][/B]',
 '[B][COLOR=white]                                                          1988[/COLOR][/B]',
 '[B][COLOR=white]                                                          1987[/COLOR][/B]',
 '[B][COLOR=white]                                                          1986[/COLOR][/B]',
 '[B][COLOR=white]                                                          1985[/COLOR][/B]',
 '[B][COLOR=white]                                                          1984[/COLOR][/B]',
 '[B][COLOR=white]                                                          1983[/COLOR][/B]',
 '[B][COLOR=white]                                                          1982[/COLOR][/B]',
 '[B][COLOR=white]                                                          1981[/COLOR][/B]',
 '[B][COLOR=white]                                                          1980[/COLOR][/B]',
 '[B][COLOR=white]                                                          1979[/COLOR][/B]',
 '[B][COLOR=white]                                                          1978[/COLOR][/B]',
 '[B][COLOR=white]                                                          1977[/COLOR][/B]',
 '[B][COLOR=white]                                                          1976[/COLOR][/B]',
 '[B][COLOR=white]                                                          1975[/COLOR][/B]',
 '[B][COLOR=white]                                                          1974[/COLOR][/B]',
 '[B][COLOR=white]                                                          1973[/COLOR][/B]',
 '[B][COLOR=white]                                                          1972[/COLOR][/B]',
 '[B][COLOR=white]                                                          1971[/COLOR][/B]',
 '[B][COLOR=white]                                                          1970[/COLOR][/B]',
 '[B][COLOR=white]                                                          1969[/COLOR][/B]',
 '[B][COLOR=white]                                                          1968[/COLOR][/B]',
 '[B][COLOR=white]                                                          1967[/COLOR][/B]',
 '[B][COLOR=white]                                                          1966[/COLOR][/B]',
 '[B][COLOR=white]                                                          1965[/COLOR][/B]',
 '[B][COLOR=white]                                                          1964[/COLOR][/B]',
 '[B][COLOR=white]                                                          1963[/COLOR][/B]',
 '[B][COLOR=white]                                                          1962[/COLOR][/B]',
 '[B][COLOR=white]                                                          1961[/COLOR][/B]',
 '[B][COLOR=white]                                                          1960[/COLOR][/B]',
 '[B][COLOR=white]                                                          1959[/COLOR][/B]',
 '[B][COLOR=white]                                                          1958[/COLOR][/B]',
 '[B][COLOR=white]                                                          1957[/COLOR][/B]',
 '[B][COLOR=white]                                                          1956[/COLOR][/B]',
 '[B][COLOR=white]                                                          1955[/COLOR][/B]',
 '[B][COLOR=white]                                                          1954[/COLOR][/B]',
 '[B][COLOR=white]                                                          1953[/COLOR][/B]',
 '[B][COLOR=white]                                                          1952[/COLOR][/B]',
 '[B][COLOR=white]                                                          1951[/COLOR][/B]',
 '[B][COLOR=white]                                                          1950[/COLOR][/B]',
 '[B][COLOR=white]                                                          1949[/COLOR][/B]',
 '[B][COLOR=white]                                                          1948[/COLOR][/B]',
 '[B][COLOR=white]                                                          1947[/COLOR][/B]',
 '[B][COLOR=white]                                                          1946[/COLOR][/B]',
 '[B][COLOR=white]                                                          1945[/COLOR][/B]',
 '[B][COLOR=white]                                                          1944[/COLOR][/B]',
 '[B][COLOR=white]                                                          1943[/COLOR][/B]',
 '[B][COLOR=white]                                                          1942[/COLOR][/B]',
 '[B][COLOR=white]                                                          1941[/COLOR][/B]',
 '[B][COLOR=white]                                                          1940[/COLOR][/B]',
 '[B][COLOR=white]                                                          1939[/COLOR][/B]',
 '[B][COLOR=white]                                                          1938[/COLOR][/B]',
 '[B][COLOR=white]                                                          1937[/COLOR][/B]',
 '[B][COLOR=white]                                                          1936[/COLOR][/B]',
 '[B][COLOR=white]                                                          1935[/COLOR][/B]',
 '[B][COLOR=white]                                                          1934[/COLOR][/B]',
 '[B][COLOR=white]                                                          1933[/COLOR][/B]',
 '[B][COLOR=white]                                                          1932[/COLOR][/B]',
 '[B][COLOR=white]                                                          1931[/COLOR][/B]',
 '[B][COLOR=white]                                                          1930[/COLOR][/B]',
 '[B][COLOR=white]                                                          1929[/COLOR][/B]',
 '[B][COLOR=white]                                                          1928[/COLOR][/B]',
 '[B][COLOR=white]                                                          1927[/COLOR][/B]',
 '[B][COLOR=white]                                                          1926[/COLOR][/B]',
 '[B][COLOR=white]                                                          1925[/COLOR][/B]',
 '[B][COLOR=white]                                                          1924[/COLOR][/B]',
 '[B][COLOR=white]                                                          1923[/COLOR][/B]',
 '[B][COLOR=white]                                                          1922[/COLOR][/B]',
 '[B][COLOR=white]                                                          1921[/COLOR][/B]',
 '[B][COLOR=white]                                                          1920[/COLOR][/B]'])

    if call:
        if call < 0:
            return
        func = funcs[call-103]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2022/,return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2021/,return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2020/,return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2019/,return)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2018/,return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2017/,return)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2016/,return)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2015/,return)')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2014/,return)')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2013/,return)')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2012/,return)')

def click_12():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2011/,return)')

def click_13():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2010/,return)')

def click_14():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2009/,return)')

def click_15():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2008/,return)')

def click_16():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2007,return)')

def click_17():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2006/,return)')

def click_18():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2005/,return)')

def click_19():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2004/,return)')

def click_20():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2003/,return)')

def click_21():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2002/,return)')

def click_22():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2001/,return)')

def click_23():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2000/,return)')

def click_24():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1999/,return)')

def click_25():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1998/,return)')

def click_26():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1997/,return)')

def click_27():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1996/,return)')

def click_28():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1995/,return)')

def click_29():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1994/,return)')

def click_30():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1993/,return)')

def click_31():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1992/,return)')

def click_32():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1991/,return)')

def click_33():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1990/,return)')

def click_34():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1989/,return)')

def click_35():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1988/,return)')

def click_36():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1987/,return)')

def click_37():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1986/,return)')

def click_38():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1985/,return)')

def click_39():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1984/,return)')

def click_40():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1983/,return)')

def click_41():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1982/,return)')

def click_42():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1981/,return)')

def click_43():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1980/,return)')

def click_44():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1979/,return)')

def click_45():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1978/,return)')

def click_46():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1977/,return)')

def click_47():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1976/,return)')

def click_48():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1975/,return)')

def click_49():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1974/,return)')

def click_50():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1973/,return)')

def click_51():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1972/,return)')

def click_52():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1971/,return)')

def click_53():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1970/,return)')

def click_54():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1969/,return)')

def click_55():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1968/,return)')

def click_56():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1967/,return)')

def click_57():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1966/,return)')

def click_58():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1965/,return)')

def click_59():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1964/,return)')

def click_60():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1963/,return)')

def click_61():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1962/,return)')

def click_62():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1961/,return)')

def click_63():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1960/,return)')

def click_64():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1959/,return)')

def click_65():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1958/,return)')

def click_66():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1957/,return)')

def click_67():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1956/,return)')

def click_68():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1955/,return)')

def click_69():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1954/,return)')

def click_70():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1953/,return)')

def click_71():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1952/,return)')

def click_72():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1951/,return)')

def click_73():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1950/,return)')

def click_74():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1949/,return)')

def click_75():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1948/,return)')

def click_76():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1947/,return)')

def click_77():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1946/,return)')

def click_78():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1945/,return)')

def click_79():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1944/,return)')

def click_80():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1943/,return)')

def click_81():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1942/,return)')

def click_82():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1941/,return)')

def click_83():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1940/,return)')

def click_84():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1939/,return)')

def click_85():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1938/,return)')

def click_86():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1937/,return)')

def click_87():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1936/,return)')

def click_88():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1935/,return)')

def click_89():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1934/,return)')

def click_90():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1933/,return)')

def click_91():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1932/,return)')

def click_92():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1931/,return)')

def click_93():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1930/,return)')

def click_94():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1929/,return)')

def click_95():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1928/,return)')

def click_96():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1927/,return)')

def click_97():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1926/,return)')

def click_98():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1925/,return)')

def click_99():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1924/,return)')

def click_100():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1923/,return)')

def click_101():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1922/,return)')

def click_102():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1921/,return)')

def click_103():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/1920/,return)')

#tainiesonline_year()
