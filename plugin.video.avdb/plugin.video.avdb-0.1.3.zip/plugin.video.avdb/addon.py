from urllib.parse import urlencode, parse_qsl, unquote, quote_plus, urlparse
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from html import unescape
from xbmc import executebuiltin
from pickle import load, dump
from time import sleep
from xbmcvfs import translatePath
import re, sys, os, urlquick, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/605.1.15 EdgA/132.0.0.0'
avdb = 'https://avdbapi.com'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
def addDir(title=None, img=None, plot=None, search_key=None, mode=None, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img, 'fanart': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(plot)
    setContent(HANDLE, 'videos')
    if search_key is not None:
        list_item.addContextMenuItems([('Xóa khỏi lịch sử', f'RunPlugin({addon_url}?mode=remove&key={search_key})')])
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=30, max_age=luu, headers={'user-agent': UA,'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}/'
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def search_history_clear():
    write_file('historys.pkl', [])
    executebuiltin('Container.Refresh()')
def remove_search_history(search_key):
    content = read_file('historys.pkl') or []
    if search_key in content:
        content.remove(search_key)
        write_file('historys.pkl', content)
    executebuiltin('Container.Refresh()')
def main():
    addDir('Tìm kiếm', searchimg, 'Tìm kiếm', None, 'timkiem')
    T = {
    'Phim mới': f'{avdb}/api.php/provide/vod/?ac=detail',
    'Censored': f'{avdb}/api.php/provide/vod/?ac=detail&t=1',
    'Uncensored': f'{avdb}/api.php/provide/vod/?ac=detail&t=2',
    'Uncensored Leaked': f'{avdb}/api.php/provide/vod/?ac=detail&t=9',
    'Chinese AV': f'{avdb}/api.php/provide/vod/?ac=detail&t=10'}
    for k in T:
        addDir(k, ICON, k, None, 'ds_avdb', url = T[k], p=1)
    endOfDirectory(HANDLE)
def find():
    addDir('Tìm kiếm', searchimg, 'Tìm kiếm', None, 'search')
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, ICON, m, search_key = m, mode = 'tim_avdb', key = m)
        addDir('Xóa lịch sử', searchimg, 'Xóa lịch sử', None, 'removeall', is_folder=False)
    endOfDirectory(HANDLE)
def timkiem(query, next_page):
    sr = quote_plus(query)
    match = f'{avdb}/api.php/provide/vod?ac=detail&wd={sr}'
    n = f'{match}&pg={next_page}' if '?' in match else f'{match}?pg={next_page}'
    resp = getlink(n, n, 1000)
    data = resp.json()['list']
    for item in data:
        for episode in [item['episodes']]:
            for data_key in episode['server_data']:
                if 'link_embed' in episode['server_data'][data_key]:
                    server_name = episode['server_name']
                    slug = episode['server_data'][data_key]['slug']
                    name = unescape(item['name'])
                    poster_url = item['poster_url']
                    description = unescape(item['description'])
                    link_embed = episode['server_data'][data_key]['link_embed']
                    linkplay = link_embed.split('?s=')[1]
                    ref = link_embed.split('?s=')[0]
                    tenphim = f"[COLOR yellow]{slug}[/COLOR] [COLOR red]{server_name}[/COLOR] {name}"
                    addDir(tenphim, poster_url, description, None, 'play_vn', linkplay = linkplay, ref = ref, is_folder=False)
    if int(next_page) < resp.json()['pagecount']:
        nextp = int(next_page) + 1
        addDir(f'Trang {nextp}', nextimg, f'Trang {nextp}', None, 'ds_avdb', url = match, p=nextp)
    endOfDirectory(HANDLE)
    sleep(600)
    executebuiltin('Container.Refresh()')
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        main()
    elif params['mode'] == 'ds_avdb':
        next_page = params['p']
        match = params['url']
        n = f'{match}&pg={next_page}' if '?' in match else f'{match}?pg={next_page}'
        resp = getlink(n, n, 1000)
        data = resp.json()['list']
        for item in data:
            for episode in [item['episodes']]:
                for data_key in episode['server_data']:
                    if 'link_embed' in episode['server_data'][data_key]:
                        server_name = episode['server_name']
                        slug = episode['server_data'][data_key]['slug']
                        name = unescape(item['name'])
                        poster_url = item['poster_url']
                        description = unescape(item['description'])
                        link_embed = episode['server_data'][data_key]['link_embed']
                        if '?s=' in link_embed:
                            linkplay = link_embed.split('?s=')[1]
                            ref = link_embed.split('?s=')[0]
                            tenphim = f"[COLOR yellow]{slug}[/COLOR] [COLOR red]{server_name}[/COLOR] {name}"
                            addDir(tenphim, poster_url, description, None, 'play_vn', linkplay = linkplay, ref = ref, is_folder=False)
        if int(next_page) < resp.json()['pagecount']:
            nextp = int(next_page) + 1
            addDir(f'Trang {nextp}', nextimg, f'Trang {nextp}', None, 'ds_avdb', url = match, p=nextp)
        endOfDirectory(HANDLE)
        sleep(600)
        executebuiltin('Container.Refresh()')
    elif params['mode'] =='search':
        query = xbmcgui.Dialog().input(u'Tìm: tên phim ...', type=xbmcgui.INPUT_ALPHANUM)
        if query:
            search_history_save(query)
            timkiem(query, 1)
        else:
            find()
    elif params['mode'] =='timkiem':
        find()
    elif params['mode'] =='tim_avdb':
        timkiem(params['key'], 1)
    elif params['mode'] == 'play_vn':
        play_item = xbmcgui.ListItem(offscreen=True)
        linkplay = re.sub(r'\s+', '%20', params['linkplay'].strip(), flags=re.UNICODE)
        hdr = f"verifypeer=false&User-Agent={unquote(UA)}&Referer={referer(params['ref'])}"
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
    elif params['mode'] == 'remove':
        search_key = params.get('key')
        remove_search_history(search_key)
    elif params['mode'] == 'removeall':
        search_history_clear()
try:
    router(sys.argv[2][1:])
except:
    pass