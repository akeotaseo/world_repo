import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_big_concerts

setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="


arrayMenu = ([
            [ "My favourite concerts",               "PLGuhlLazJwGvWsd-Um02vHrRsx-n2sX4G"],
            [ "Concerts I",                          "PLuoBnWTW40Msf7SnQfcakGUSlhJCLwNzZ"],
            [ "Concerts II",                         "PLeoiBqD9wuZ2rhjqNlP0zEY7nypWg8_2t"],
            [ "Concerts III",                        "PLpPPrzGMnMUlaa__5yBIstqQn1dsVD_QA"], 
            [ "Concerts IV",                         "PLIQm6xoobT2pTUH16L-Mzj1wygfjcNJbB"],
            [ "Concerts V",                          "PL48654284EEAE026A"],
            [ "Death Metal Concerts",                "PLXkKiokRx8AlATGbdLP2T_CfrLFcs7jEM"],
            [ "Symphonic Metal Bands Live Concerts", "PL_fi_PxIa4WMiCkNx1jt60MN8CKs9-383"],
            [ "Thrash Metal Concerts I",             "PLmYNgzG7_vMg5ZnjA5A6Vyr9Y3xJ2OO9t"],
            [ "Thrash Metal Concerts II",            "PLpPPrzGMnMUklONYu4E273UImJiZfxE8f"],
            [ "Death Metal Concerts",                "PLpPPrzGMnMUkM9OWhvAm8VrceuZZCjzcV"],
            [ "Metal - Melodic Rock - Full Concerts I",  "PLHrguy3J2ka2NrIba_vzXMw6ZCOSeJagd"],    
            [ "Metal - Melodic Rock - Full Concerts II", "PLHrguy3J2ka2r2ZqshbZSKNfLJ4AW_yUj"],
            [ "Black Metal Live Shows I",            "PLhWbPRawCyD7tsHb3VMcAvdYO50sc7E1B"],
            [ "Black Metal Live Shows II",           "PLpPPrzGMnMUlrO3YdhQC5OuLSIvxS8Gec"]
            ])

def playlists(params):
    logo=logos_big_concerts.full_concerts(params)

    for i in range(len(arrayMenu)):
        titulo = arrayMenu[i][0]
        id_canal = arrayMenu[i][1]
        if usa_duffyou:  ##Usamos plugin Duff You
            reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_canal)
            videos = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        else:  ##Usamos plugin YouTube
            videos = youtube.replace("MI-ID-PLAYLIST" , id_canal)
        
        plugintools.add_item( 
            title=titulo,
            url=videos,
            thumbnail=logo, folder=True )





