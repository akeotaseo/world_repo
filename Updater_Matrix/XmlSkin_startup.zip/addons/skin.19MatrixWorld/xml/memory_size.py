import xbmc, xbmcgui
Kodi_version = float(xbmc.getInfoLabel("System.BuildVersion")[:4])

def advanced_qui_set():
    selection = xbmcgui.Dialog().select('[COLOR orange]Caching[/COLOR]',
                                       ['[B][COLOR white]Μέγεθος Μνήμης[/COLOR][/B]',
                                        '[B][COLOR white]Επαναφορά στην Προεπιλογή (20MB)[/COLOR][/B]'])
    if 19.9 <= Kodi_version <= 21.0:
        if selection==0:
            xbmc.executebuiltin("ActivateWindowAndFocus(ServiceSettings, -94, )")
            xbmc.sleep(500)
            xbmc.executebuiltin('SendClick(-78)')
        elif selection==1:
            xbmc.executebuiltin("ActivateWindowAndFocus(ServiceSettings, -94, )")
            xbmc.sleep(500)
            xbmc.executebuiltin('SendClick(-72)')

    if 21.0 <= Kodi_version <= 22.0:
        if selection==0:
            xbmc.executebuiltin("ActivateWindowAndFocus(ServiceSettings, -194, )")
            xbmc.sleep(500)
            xbmc.executebuiltin('SendClick(-178)')
        elif selection==1:
            xbmc.executebuiltin("ActivateWindowAndFocus(ServiceSettings, -194, )")
            xbmc.sleep(500)
            xbmc.executebuiltin('SendClick(-172)')

advanced_qui_set()

