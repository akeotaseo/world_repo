#! /usr/bin/env python3
from resources.lib import hsk

hsk.__add_item__('Peter Fox',hsk.__get_youtube_search__('@peterfoxofficial'),hsk.__get_image__('Peter Fox.jpg'),'Plot ?',is_folder=True)
hsk.__add_item__('TOP 100 Songs of 2023 - Billboard Hot 100 - Music Playlist 2023',hsk.__get_youtube_playlist__('PLDIoUOhQQPlXr63I_vwF9GD8sAKh77dWU'),hsk.__get_image__('billboard-top-100.webp'),'Plot ?',is_folder=True)
hsk.__add_item__('Top 100 Songs of 2023 - Best Music Hits 2023',hsk.__get_youtube_playlist__('PL3oW2tjiIxvQ98ZTLhBh5soCbE1mC3uAT'),hsk.__get_image__('Top 100 Charts.jpg'),'Plot ?',is_folder=True)
hsk.__add_item__('VIVA Top 100 - Charts 2023',hsk.__get_youtube_playlist__('PL3-sRm8xAzY89yb_OB-QtcCukQfFe864A'),hsk.__get_image__('VIVA Top 100.jpg'),'Plot ?',is_folder=True)
hsk.__add_item__('Spotify Top Hits 2023',hsk.__get_youtube_playlist__('PLOHoVaTp8R7d3L_pjuwIa6nRh4tH5nI4x'),hsk.__get_image__('Spotify Top Hits 2023.jpg'),'Plot ?',is_folder=True)
hsk.__end_of_directory__()
