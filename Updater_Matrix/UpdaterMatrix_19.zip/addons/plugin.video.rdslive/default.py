# -*- coding: utf-8 -*-
import sys
import re
import json
import html
import urllib.parse
from urllib.parse import urlparse
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# ------------- Config -------------
addon = xbmcaddon.Addon()
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = "https://rds.live"
AJAX_URL = f"{BASE_URL}/wp-admin/admin-ajax.php"

COMMON_HEADERS = {
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36",
    "Accept-Language": "ro-RO,ro;q=0.9,en-US;q=0.8,en;q=0.7",
    "Accept": "*/*",
}

SESSION = requests.Session()
SESSION.headers.update(COMMON_HEADERS)

def log(msg, lvl=xbmc.LOGINFO):
    xbmc.log(f"[RDSLive] {msg}", lvl)

# ------------- Settings helpers -------------
def get_setting_max_sources(default_val: int = 4) -> int:
    try:
        raw = addon.getSetting("max_sources")
        if not raw:
            return default_val
        val = int(raw)
        return min(6, max(1, val))
    except Exception:
        return default_val

def get_setting_manual_token() -> str:

    try:
        return (addon.getSetting("manual_token") or "").strip()
    except Exception:
        return ""

# ------------- Utils -------------
def _strip_html(s: str) -> str:
    return re.sub(r"<[^>]+>", "", s or "")

def _clean_category_title(title: str) -> str:
    t = _strip_html(title)
    t = html.unescape(t or "").replace("\xa0", " ")
    t = re.sub(r"\s*\b\d+\s*canale\s*TV\b", "", t, flags=re.IGNORECASE)
    t = re.sub(r"\s*\(\s*\d+\s*\)\s*$", "", t)
    t = re.sub(r"\s+", " ", t)
    return t.strip()

def _clean_channel_title(t: str) -> str:
    t = html.unescape(t or "").replace("\xa0", " ")
    t = re.sub(r"\b(online|gratis|HD)\b", "", t, flags=re.IGNORECASE)
    t = re.sub(r"\s+", " ", t).strip(" -–—")
    return t.strip()


def mask_val(s: str | None, keep_head: int = 3, keep_tail: int = 2) -> str:
    if not s:
        return ""
    if len(s) <= keep_head + keep_tail:
        return "*" * max(len(s), 1)
    return f"{s[:keep_head]}***{s[-keep_tail:]}"

def mask_slug(slug: str | None) -> str:
    if not slug:
        return ""
    if len(slug) <= 2:
        return slug[0] + "*"
    return slug[:2] + "***"

def _clean_webp(url: str | None) -> str | None:
    if not url:
        return url
    return url[:-5] if url.endswith(".webp") else url

def _first(src: str, pat: str) -> str | None:
    m = re.search(pat, src, re.DOTALL | re.IGNORECASE)
    return m.group(1).strip() if m else None

def _extract_poster(article_html: str) -> str | None:
    p = _first(article_html, r'<img[^>]+src="([^"]+)"')
    if p and not p.startswith("data:image/svg+xml"):
        return _clean_webp(p)
    p = _first(article_html, r'data-lazy-src="([^"]+)"')
    if p:
        return _clean_webp(p)
    srcset = _first(article_html, r'<source[^>]+srcset="([^"]+)"')
    if srcset:
        first_url = srcset.split(",")[0].strip().split()[0]
        return _clean_webp(first_url)
    return None

def _extract_slug_from_url_or_html(post_url: str, html: str) -> str | None:
    slug = _first(html, r'<link rel="canonical" href="https://rds\.live/([^/]+)/"')
    if slug:
        return slug
    try:
        p = urlparse(post_url)
        bits = [b for b in p.path.split("/") if b]
        if bits:
            return bits[-1]
    except Exception:
        pass
    return None

def _choose_referer(final_url: str, page_referer: str) -> str:
    if "token=" in final_url or "embed-video2.php" in final_url:
        return "https://ivanturbinca.com/"
    if final_url.lower().endswith(".html"):
        return final_url
    return page_referer or BASE_URL + "/"

def _append_headers(url: str, referer: str) -> str:
    ua = urllib.parse.quote(COMMON_HEADERS["User-Agent"], safe="")
    ref = urllib.parse.quote(referer, safe="")
    try:
        org = "{uri.scheme}://{uri.netloc}".format(uri=urlparse(referer))
    except Exception:
        org = BASE_URL
    org = urllib.parse.quote(org, safe="")
    acc = urllib.parse.quote("*/*", safe="")
    return f"{url}|User-Agent={ua}&Referer={ref}&Origin={org}&Accept={acc}"

def add_manual_token_if_any(url: str) -> tuple[str, bool]:
    tok = get_setting_manual_token()
    if tok and "magicplaces.eu" in url and "token=" not in url:
        sep = "&" if "?" in url else "?"
        return f"{url}{sep}token={tok}&remote=no_check_ip", True
    return url, False

def extract_m3u8_from_html_container(container_url: str, base_referer: str) -> tuple[str | None, str]:
    try:
        hdrs = {**COMMON_HEADERS, "Referer": base_referer}
        r = SESSION.get(container_url, headers=hdrs, timeout=12)
        r.raise_for_status()
        html = r.text
        m = re.search(r'<source[^>]+src="([^"]+\.m3u8[^"]*)"', html, re.I)
        if m:
            return m.group(1).replace("&amp;", "&"), container_url
        m = re.search(r'(https?://[^\s"\']+\.m3u8[^\s"\']*)', html, re.I)
        if m:
            return m.group(1), container_url
    except requests.RequestException as e:
        log(f"Eroare container HTML: {e}", xbmc.LOGWARNING)
    return None, base_referer

# ------------- Categorii & Canale -------------
def extract_categories():
    url = f"{BASE_URL}/categorii/"
    try:
        r = SESSION.get(url, timeout=15)
        r.raise_for_status()
    except requests.RequestException as e:
        log(f"Eroare categorii: {e}", xbmc.LOGERROR)
        return []

    cats, seen_links = [], set()

    for link, raw_title in re.findall(
        r'<li[^>]*class="menu-item[^"]*">.*?<a href="(https://rds\.live/categorie/[^"]+)"[^>]*>(.*?)</a>',
        r.text, re.DOTALL | re.IGNORECASE
    ):
        link = link.strip()
        if link in seen_links:
            continue
        title = _clean_category_title(raw_title)
        if not title:
            continue
        cats.append({"title": title, "link": link})
        seen_links.add(link)

    cats.insert(0, {"title": "Toate", "link": f"{BASE_URL}/canale-tv-1/"})
    return cats

def _extract_lista_canale(html: str) -> str | None:
    return _first(html, r'<div class="lista-canale">(.*?)</div>')

def extract_all_channels():
    url = f"{BASE_URL}/canale-tv-1/"
    try:
        r = SESSION.get(url, timeout=15)
        r.raise_for_status()
    except requests.RequestException as e:
        log(f"Eroare canale (Toate): {e}", xbmc.LOGERROR)
        return []
    bloc = _extract_lista_canale(r.text)
    if not bloc:
        log("Nu am găsit lista-canale pentru Toate", xbmc.LOGWARNING)
        return []
    channels = []
    for post_id, article_html in re.findall(
        r'<article id="post-(\d+)"[^>]*class="[^"]*canal[^"]*"[^>]*>(.*?)</article>',
        bloc, re.DOTALL | re.IGNORECASE
    ):
        title = _first(article_html, r'<a[^>]+class="post-thumbnail"[^>]+title="([^"]+)"')
        if title:
            title = _clean_channel_title(title)
        link = _first(article_html, r'<a[^>]+class="post-thumbnail"[^>]+href="([^"]+)"')
        poster = _extract_poster(article_html)
        if title and link:
            channels.append({"id": post_id, "title": title, "link": link, "poster": poster})
    return channels

def extract_channel_items(category_url: str, category_name: str):
    try:
        r = SESSION.get(category_url, timeout=15)
        r.raise_for_status()
    except requests.RequestException as e:
        log(f"Eroare canale ({category_name}): {e}", xbmc.LOGERROR)
        return []
    bloc = _extract_lista_canale(r.text)
    if not bloc:
        log(f"Fără bloc canale pentru {category_name}", xbmc.LOGWARNING)
        return []
    channels = []
    for post_id, article_html in re.findall(
        rf'<article id="post-(\d+)"[^>]*class="[^"]*categorie-{re.escape(category_name)}[^"]*"[^>]*>(.*?)</article>',
        bloc, re.DOTALL | re.IGNORECASE
    ):
        title = _first(article_html, r'<a[^>]+class="post-thumbnail"[^>]+title="([^"]+)"')
        if title:
            title = _clean_channel_title(title)
        link = _first(article_html, r'<a[^>]+class="post-thumbnail"[^>]+href="([^"]+)"')
        poster = _extract_poster(article_html)
        if title and link:
            channels.append({"id": post_id, "title": title, "link": link, "poster": poster})
    return channels

# ------------- rdsAjax / Checker / Embed -------------
_RDSAJAX_PATTERNS = [
    re.compile(r'var\s+rdsAjax\s*=\s*(\{.*?\});', re.S),
    re.compile(r'\brdsAjax\s*=\s*(\{.*?\});', re.S),
]

def _parse_rdsajax(html: str) -> dict | None:
    blob = None
    for pat in _RDSAJAX_PATTERNS:
        m = pat.search(html)
        if m:
            blob = m.group(1)
            break
    if not blob:
        return None
    try:
        return json.loads(blob)
    except Exception:
        tmp = re.sub(r'([{,]\s*)([A-Za-z0-9_]+)\s*:', r'\1"\2":', blob)
        tmp = tmp.replace("'", '"').replace("\\/", "/")
        try:
            return json.loads(tmp)
        except Exception:
            pass
    rds = {}
    for k in ("ajax_url", "nonce", "checker", "site", "site_ts", "site_sig", "ts", "sig"):
        rds[k] = _first(blob, rf'"{k}"\s*:\s*"([^"]+)"')
    return rds

def extract_nonce_and_page_vars(post_url: str):
    try:
        r = SESSION.get(post_url, timeout=15)
        r.raise_for_status()
    except requests.RequestException as e:
        log(f"Eroare GET post_url: {e}", xbmc.LOGERROR)
        return None

    html = r.text
    rdsAjax = _parse_rdsajax(html)

    nonce = checker = site = site_ts = site_sig = None
    if rdsAjax:
        checker = str((rdsAjax.get("checker") or "")).replace("\\/", "/")
        nonce   = rdsAjax.get("nonce")
        site    = rdsAjax.get("site") or "rds.live"
        site_ts = rdsAjax.get("ts") or rdsAjax.get("site_ts")
        site_sig= rdsAjax.get("sig") or rdsAjax.get("site_sig")

    if not (checker and site_ts and site_sig):
        m = re.search(r'https?://(?:www\.)?ivanturbinca\.com/checker\.php\?([^"\'\s>]+)', html, re.I)
        if m:
            qs = dict(urllib.parse.parse_qsl(m.group(1)))
            checker = "https://ivanturbinca.com/checker.php"
            site    = qs.get("site", site) or "rds.live"
            site_ts = qs.get("ts", site_ts)
            site_sig= qs.get("sig", site_sig)

    if not site:
        site = _first(html, r'"site"\s*:\s*"([^"]+)"') or "rds.live"
    if not site_ts:
        site_ts = _first(html, r'"(?:site_)?ts"\s*:\s*"?(\d+)"?') or _first(html, r'[\?&]ts=(\d+)')
    if not site_sig:
        site_sig = _first(html, r'"(?:site_)?sig"\s*:\s*"([a-f0-9]+)"') or _first(html, r'[\?&]sig=([a-f0-9]+)')
    if not nonce:
        nonce = _first(html, r'"nonce"\s*:\s*"([^"]+)"') or _first(html, r'nonce\s*[:=]\s*"([^"]+)"')

    slug = _extract_slug_from_url_or_html(post_url, html)
    log(f"Page vars: nonce={mask_val(nonce)}, slug={mask_slug(slug)}; ts={site_ts or '-'} sig={mask_val(site_sig or '')}")

    return {
        "nonce": nonce,
        "checker": checker,
        "site": site or "rds.live",
        "site_ts": str(site_ts) if site_ts else None,
        "site_sig": str(site_sig) if site_sig else None,
        "slug": slug or "",
    }

def call_admin_ajax(post_id: str, tab: str, nonce: str | None, referer: str):
    data = {"action": "get_video_source", "tab": tab, "post_id": post_id}
    if nonce:
        data["nonce"] = nonce
    headers = {
        **COMMON_HEADERS,
        "Referer": referer,
        "Origin": BASE_URL,
        "X-Requested-With": "XMLHttpRequest",
        "Accept": "application/json, text/plain, */*",
    }
    try:
        r = SESSION.post(AJAX_URL, data=data, headers=headers, timeout=15)
        r.raise_for_status()
        js = r.json()
        if js.get("success"):
            return js.get("data")
        log(f"AJAX fără sursă (tab={tab}): {r.text[:160]}...", xbmc.LOGWARNING)
    except requests.RequestException as e:
        log(f"Eroare admin-ajax (tab={tab}): {e}", xbmc.LOGERROR)
    except ValueError:
        log("AJAX nu e JSON valid", xbmc.LOGERROR)
    return None

def fetch_checker_token(checker: str, site: str, ts: str, sig: str, referer: str):
    headers = {
        **COMMON_HEADERS,
        "Referer": referer,
        "Origin": BASE_URL,
        "Accept": "application/json, text/plain, */*",
        "Cache-Control": "no-cache",
    }
    try:
        r = SESSION.get(checker, params={"site": site, "ts": ts, "sig": sig}, headers=headers, timeout=12)
        r.raise_for_status()
        try:
            js = r.json()
        except ValueError:
            js = {
                "token": _first(r.text, r'"token"\s*:\s*"([^"]+)"') or _first(r.text, r'token=([a-f0-9-]+)'),
                "timestamp": _first(r.text, r'"timestamp"\s*:\s*"([^"]+)"') or _first(r.text, r'timestamp=(\d+)'),
            }
        token = js.get("token") or js.get("hash") or js.get("sig")
        timestamp = js.get("timestamp") or js.get("ts")
        if token and timestamp:
            return token, str(timestamp)
        log(f"Checker fără token/timestamp: {r.text[:160]}...", xbmc.LOGERROR)
    except requests.RequestException as e:
        log(f"Eroare checker: {e}", xbmc.LOGERROR)
    return None, None

def _parse_stream_pref_from_m3u8(m3u8_url: str) -> tuple[str | None, str | None]:
    try:
        u = urlparse(m3u8_url)
        host = u.netloc
        pref = host.split(".")[0] if host else None
        parts = [p for p in u.path.split("/") if p]
        stream = parts[0] if parts else None
        return stream, pref
    except Exception:
        return None, None

def resolve_embed_video2(source_url: str, token: str, timestamp: str, referer: str) -> str | None:
    headers = {
        **COMMON_HEADERS,
        "Referer": referer,
        "Origin": BASE_URL,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }
    params = {"source": source_url, "token": token, "timestamp": timestamp}
    try:
        r = SESSION.get("https://ivanturbinca.com/embed-video2.php", headers=headers, params=params, timeout=12)
        r.raise_for_status()
        m = re.search(r'<source[^>]+src="([^"]+\.m3u8[^"]*)"', r.text, re.I)
        if m:
            return m.group(1).replace("&amp;", "&")
    except requests.RequestException as e:
        log(f"Eroare embed-video2: {e}", xbmc.LOGERROR)
    return None

def resolve_hls_embed(data_obj, base_url: str, site: str, ts: str, sig: str, referer: str) -> str | None:
    stream = None
    pref = None
    if isinstance(data_obj, dict):
        stream = data_obj.get("stream") or data_obj.get("channel")
        pref = data_obj.get("pref") or data_obj.get("host") or data_obj.get("node")
    if (not stream or not pref) and base_url:
        s, p = _parse_stream_pref_from_m3u8(base_url)
        stream = stream or s
        pref = pref or p
    if not (stream and pref):
        return None

    headers = {
        **COMMON_HEADERS,
        "Referer": referer,
        "Origin": BASE_URL,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }
    params = {"stream": stream, "pref": pref, "site": site, "ts": ts, "sig": sig}
    try:
        r = SESSION.get("https://ivanturbinca.com/hls-embed.php", headers=headers, params=params, timeout=12)
        r.raise_for_status()
        m = re.search(r'<source[^>]+src="([^"]+\.m3u8[^"]*)"', r.text, re.I)
        if m:
            return m.group(1).replace("&amp;", "&")
        return None
    except requests.RequestException as e:
        log(f"Eroare hls-embed: {e}", xbmc.LOGERROR)
    return None

def _build_base_m3u8_from_data(data_obj):
    if isinstance(data_obj, str):
        return data_obj.replace("\\/", "/")
    if isinstance(data_obj, dict):
        if data_obj.get("stream") and data_obj.get("pref"):
            return f"https://{data_obj['pref']}.magicplaces.eu/{data_obj['stream']}/video.m3u8"
        src = data_obj.get("source") or data_obj.get("url")
        if src:
            return src
    return None

# ------------- Pipeline surse -------------
def extract_video_sources(post_id: str, post_url: str):
    page = extract_nonce_and_page_vars(post_url)

    referer = f"{BASE_URL}/"
    if page and page.get("slug"):
        referer = f"{BASE_URL}/{page['slug'].strip('/')}/"

    nonce   = page.get("nonce")    if page else None
    checker = page.get("checker")  if page else None
    site    = page.get("site")     if page else "rds.live"
    site_ts = page.get("site_ts")  if page else None
    site_sig= page.get("site_sig") if page else None

    max_sources = get_setting_max_sources(default_val=4)

    if get_setting_manual_token():
        log("Manual token prezent în setări.", xbmc.LOGINFO)
    else:
        log("Manual token NU este setat.", xbmc.LOGINFO)

    token = timestamp = None
    if checker and site_ts and site_sig:
        token, timestamp = fetch_checker_token(checker, site, site_ts, site_sig, referer)
        if not (token and timestamp):
            log("Fără token/timestamp – voi încerca fallback", xbmc.LOGWARNING)
    else:
        log("Nu am ts/sig – voi încerca fallback (HTML container sau token manual)", xbmc.LOGWARNING)

    tokenized, plain = [], []
    seen_plain = set()

    for i in range(1, max_sources + 1):
        tab = f"tab{i}"
        data_obj = call_admin_ajax(post_id, tab, nonce, referer)
        if not data_obj:
            continue

        base_url = _build_base_m3u8_from_data(data_obj)
        if not base_url:
            if isinstance(data_obj, str) and data_obj.startswith("http"):
                base_url = data_obj
            else:
                log(f"Tab {tab}: răspuns necunoscut: {data_obj}", xbmc.LOGWARNING)
                continue

        final_url = None
        final_ref = referer

        if token and timestamp and base_url.endswith(".m3u8"):
            final_url = resolve_embed_video2(base_url, token, timestamp, referer)
            final_ref = referer

        if (not final_url) and site_ts and site_sig:
            try:
                u = resolve_hls_embed(data_obj, base_url, site, site_ts, site_sig, referer)
                if u:
                    final_url = u
                    final_ref = referer
            except Exception as e:
                log(f"Eroare la hls-embed: {e}", xbmc.LOGERROR)

        probe = final_url or base_url
        if not probe.lower().endswith(".m3u8"):
            u, ref2 = extract_m3u8_from_html_container(probe, referer)
            if u:
                final_url = u
                final_ref = ref2

        if not final_url:
            final_url = base_url

        if "token=" not in final_url and "magicplaces.eu" in final_url:
            new_u, used_manual = add_manual_token_if_any(final_url)
            if used_manual:
                log(f"Am folosit tokenul manual din setări: {mask_val(get_setting_manual_token(), 6, 6)}", xbmc.LOGINFO)
                final_url = new_u

        if final_url in seen_plain:
            continue
        seen_plain.add(final_url)

        ref = _choose_referer(final_url, final_ref)
        entry = _append_headers(final_url, ref)
        log(f"URL final pentru {tab}: {final_url}")

        if "token=" in final_url:
            tokenized.append(entry)
        else:
            plain.append(entry)

    results = tokenized + plain

    uniq, seen = [], set()
    for u in results:
        if u and u not in seen:
            seen.add(u)
            uniq.append(u)
    return uniq

# ------------- UI -------------
def list_categories():
    assets = {
        "Toate": {
            "fanart": "special://home/addons/plugin.video.rdslive/resources/media/fanart.webp",
            "logo": "special://home/addons/plugin.video.rdslive/resources/media/toate.webp",
            "thumb": "special://home/addons/plugin.video.rdslive/resources/media/toate.webp",
        },
        "Generaliste": {
            "fanart": "special://home/addons/plugin.video.rdslive/resources/media/generaliste.webp",
            "logo": "special://home/addons/plugin.video.rdslive/resources/media/generaliste.webp",
            "thumb": "special://home/addons/plugin.video.rdslive/resources/media/generaliste.webp",
        },
        "Copii": {
            "fanart": "special://home/addons/plugin.video.rdslive/resources/media/copii.webp",
            "logo": "special://home/addons/plugin.video.rdslive/resources/media/copii.webp",
            "thumb": "special://home/addons/plugin.video.rdslive/resources/media/copii.webp",
        },
        "Filme": {
            "fanart": "special://home/addons/plugin.video.rdslive/resources/media/filme.webp",
            "logo": "special://home/addons/plugin.video.rdslive/resources/media/filme.webp",
            "thumb": "special://home/addons/plugin.video.rdslive/resources/media/filme.webp",
        },
        "Sport": {
            "fanart": "special://home/addons/plugin.video.rdslive/resources/media/sport.webp",
            "logo": "special://home/addons/plugin.video.rdslive/resources/media/sport.webp",
            "thumb": "special://home/addons/plugin.video.rdslive/resources/media/sport.webp",
        },
        "Stiri": {
            "fanart": "special://home/addons/plugin.video.rdslive/resources/media/stiri.webp",
            "logo": "special://home/addons/plugin.video.rdslive/resources/media/stiri.webp",
            "thumb": "special://home/addons/plugin.video.rdslive/resources/media/stiri.webp",
        },
        "Documentare": {
            "fanart": "special://home/addons/plugin.video.rdslive/resources/media/documentare.webp",
            "logo": "special://home/addons/plugin.video.rdslive/resources/media/documentare.webp",
            "thumb": "special://home/addons/plugin.video.rdslive/resources/media/documentare.webp",
        },
        "Muzica": {
            "fanart": "special://home/addons/plugin.video.rdslive/resources/media/muzica.webp",
            "logo": "special://home/addons/plugin.video.rdslive/resources/media/muzica.webp",
            "thumb": "special://home/addons/plugin.video.rdslive/resources/media/muzica.webp",
        },
        "Diverse": {
            "fanart": "special://home/addons/plugin.video.rdslive/resources/media/diverse.webp",
            "logo": "special://home/addons/plugin.video.rdslive/resources/media/diverse.webp",
            "thumb": "special://home/addons/plugin.video.rdslive/resources/media/diverse.webp",
        },
        "Religioase": {
            "fanart": "special://home/addons/plugin.video.rdslive/resources/media/religioase.webp",
            "logo": "special://home/addons/plugin.video.rdslive/resources/media/religioase.webp",
            "thumb": "special://home/addons/plugin.video.rdslive/resources/media/religioase.webp",
        },
    }
    for c in extract_categories():
        url = f"{sys.argv[0]}?action=list_category&category_url={urllib.parse.quote_plus(c['link'])}"
        li = xbmcgui.ListItem(label=c["title"])
        a = assets.get(c["title"], assets["Toate"])
        li.setArt({"fanart": a["fanart"], "icon": a["logo"], "thumb": a["thumb"]})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_channels_for_category(category_url):
    if category_url.rstrip("/") == f"{BASE_URL}/canale-tv-1":
        channels = extract_all_channels()
    else:
        category_name = category_url.rstrip("/").split("/")[-1]
        channels = extract_channel_items(category_url, category_name)

    for ch in channels:
        play_url = (f"{sys.argv[0]}?action=play"
                    f"&post_id={ch['id']}"
                    f"&post_url={urllib.parse.quote_plus(ch['link'])}")
        li = xbmcgui.ListItem(label=ch["title"])
        li.setArt({
            "thumb": ch.get("poster") or "",
            "icon": ch.get("poster") or "",
            "fanart": "special://home/addons/plugin.video.rdslive/resources/media/fanart.webp",
        })
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(HANDLE, play_url, li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_channel(post_id, post_url):
    mode = addon.getSetting("play_mode")  # "0" automat, "1" manual
    if not post_id or not post_url:
        xbmcgui.Dialog().notification("Eroare", "Parametri lipsă (post).", xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    sources = extract_video_sources(post_id, post_url)
    if not sources:
        xbmcgui.Dialog().notification("Eroare", "Nu am putut obține sursa video.", xbmcgui.NOTIFICATION_ERROR, 5000)
        return

    if mode == "1" and len(sources) > 1:
        options = [f"Sursa {i+1}" for i in range(len(sources))]
        idx = xbmcgui.Dialog().select("Selectați sursa video", options)
        if idx == -1:
            xbmcgui.Dialog().notification("Informație", "Selecția a fost anulată.", xbmcgui.NOTIFICATION_INFO, 3000)
            return
        url = sources[idx]
    else:
        url = sources[0]

    log(f"Redare: {url}")
    li = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

# ------------- Router -------------
def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")
    if action == "list_category":
        list_channels_for_category(params.get("category_url", ""))
    elif action == "play":
        play_channel(params.get("post_id"), params.get("post_url"))
    else:
        list_categories()

if __name__ == "__main__":
    router(sys.argv[2][1:])
