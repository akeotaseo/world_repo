# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
OIPEIRATES = 'https://oipeirates.club'


def menu_year(): #97
    addDir('[COLOR white]2020[/COLOR]', OIPEIRATES + '/genre/2020/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]2019[/COLOR]', OIPEIRATES + '/genre/2019/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]2018[/COLOR]', OIPEIRATES + '/genre/2018/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]2017[/COLOR]', OIPEIRATES + '/genre/2017/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]2016[/COLOR]', OIPEIRATES + '/genre/2016/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]2013-2015[/COLOR]', OIPEIRATES + '/genre/2013-2015/', 96, ART + 'oipeirates.png', FANART, '')


def menu_genre(): #98
    addDir('[COLOR white]Περιπέτεια-Δράσης[/COLOR]', OIPEIRATES + '/genre/drasis/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Κωμωδίες[/COLOR]', OIPEIRATES + '/genre/komodies/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Θρίλερ[/COLOR]', OIPEIRATES + '/genre/thriller/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Τρόμου[/COLOR]', OIPEIRATES + '/genre/tromou/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Επ-φαντασίας[/COLOR]', OIPEIRATES + '/genre/ep-fantasias/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Φαντασίας[/COLOR]', OIPEIRATES + '/genre/fantasias/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Έγκλημα[/COLOR]', OIPEIRATES + '/genre/egklima/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Μυστήριο[/COLOR]', OIPEIRATES + '/genre/mystery/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Πολέμου[/COLOR]', OIPEIRATES + '/genre/war/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Γουέστερν[/COLOR]', OIPEIRATES + '/genre/western/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Δράμα[/COLOR]', OIPEIRATES + '/genre/drama/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Ρομαντικές[/COLOR]', OIPEIRATES + '/genre/romantikes/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Ντοκιμαντέρ[/COLOR]', OIPEIRATES + '/genre/documentary/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Μουσικές[/COLOR]', OIPEIRATES + '/genre/music/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Χορευτικές[/COLOR]', OIPEIRATES + '/genre/xoreftikes/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Χριστουγιεννιάτικες[/COLOR]', OIPEIRATES + '/genre/x-mas/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Φιλμογραφίες[/COLOR]', OIPEIRATES + '/genre/filmography/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Συλλογές[/COLOR]', OIPEIRATES + '/genre/collection/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Ελλ-ταινίες[/COLOR]', OIPEIRATES + '/genre/ell-tainies/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Bollywood[/COLOR]', OIPEIRATES + '/genre/Bollywood/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Anime-series[/COLOR]', OIPEIRATES + '/genre/anime/', 96, ART + 'oipeirates.png', FANART, '')
    addDir('[COLOR white]Anime-movies[/COLOR]', OIPEIRATES + '/genre/animemovies/', 96, ART + 'oipeirates.png', FANART, '')


def oipeirates(url): #96
    hdrs = {'Referer': OIPEIRATES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    
    m = re.compile('<div class="movief1"><a href="(.+?)">(.+?)</a></div>', re.DOTALL).findall(p)
    for url, name in m:
        name = name.replace('-)',')').replace('- )',')').replace('&#038;','').replace('&#8217;','').replace('&#8211;','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 99, '', FANART, '')
    try:
        m = re.compile('</u></span><span class="page"><a href="(.+?)"').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 96, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass


def get_links(name, url, iconimage, description): #99
    hdrs = {'Referer': OIPEIRATES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile(' href="(.+?)" target="_blank"').findall(p)
    link_list = ['aparat', 'flashx', 'hdvid', 'vidd',
                 'vidoza', 'vidlox', 'estream', 'clipwatching', 'thevideo', 'vidzi']
    for url in m:
        if any(x in url for x in link_list):
            name = url
            name = name.split('.')[0]
            name = name.replace('http://', '[B]Πάροχος...[/B]')
            name = name.replace('https://', '[B]Πάροχος...[/B]')
            addDir(name, url, 100, '', '', str(description))
    else:
        m2 = re.compile('<iframe.+?src="(.+?)"').findall(p)
        for url in m2:
            if 'youtube' in url:
                Trailer = '[COLOR=lime]Τρέιλερ[/COLOR]'
                addDir(Trailer, url, 100, '', '', str(description))
            else:
                addDir('[B][COLOR orange]Δεν υπάρχει διαθέσιμο Τρέιλερ[/COLOR][/B]', '', 100, '', '', str(description))

def search(url): #95
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = 'https://oipeirates.club/?s=' + search
        oipeirates(url)
