# -*- coding: utf-8 -*-
#$pyFunction
def GetLSProData(page_data,Cookie_Jar,m):
 import xbmc, xbmcaddon
 hola = '5.1.53'
 __addon__ = xbmcaddon.Addon('script.module.resolveurl')
 __addonname__ = __addon__.getAddonInfo('version')
 if not hola==__addonname__:
    return instaladorepo()
 else:
    return '[COLOR green]SI.[/COLOR] tiene la Ultima version, la ' + __addonname__	  

def instaladorepo():
 import xbmc, xbmcaddon
 hola = xbmc.getCondVisibility('System.HasAddon(repository.resolverurl)')
 if hola==0:
     __addon__ = xbmcaddon.Addon('script.module.resolveurl')
     __addonname__ = __addon__.getAddonInfo('version')
     xbmc.executebuiltin('InstallAddon(repository.resolverurl)')
     return '[COLOR red]NO,[/COLOR] tiene la [COLOR red]' + __addonname__ + '[COLOR white] y la ultima es la[/COLOR][COLOR red] 5.1.53[/COLOR], Tampoco tiene su repositorio para que se actualice, Asique forzaremos la instalacion.[COLOR red] Si no le actualiza No le funcionara ni la seccion de SERIES ni la de CINE.[/COLOR]'
 else:
     __addon__ = xbmcaddon.Addon('script.module.resolveurl')
     __addonname__ = __addon__.getAddonInfo('version')  
     return '[COLOR red]NO,[/COLOR] esta en proceso... de momento tiene la ' + __addonname__ + '[COLOR white] y la ultima es la[/COLOR][COLOR red] 5.1.53[/COLOR] si no le actualiza solo, fuerce el repositorio de resolverurl, [COLOR red]Mientras no le actualiza No le funcionara ni la seccion de SERIES ni la de CINE.[/COLOR]'
	
