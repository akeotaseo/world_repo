# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

from ..utils.browser import Firefox
from ..utils.resolve import Resolver
import requests
import re

class TV247(Resolver):
    def __init__(self):
        pass
    
    def grab(self, channel):
        firefox = Firefox()
        firefox.addHeader("Referer", "https://tv247us.com")
        resp = requests.get(f"https://tv247us.com/watch/{channel}/", headers=firefox.headers)
        baseUrl = re.findall(r"baseUrl = \"(.*?)\";", resp.text)[0]
        channelName = re.findall(r"channelName = \"(.*?)\";", resp.text)[0]
        return baseUrl + channelName + ".m3u8", firefox.headers
