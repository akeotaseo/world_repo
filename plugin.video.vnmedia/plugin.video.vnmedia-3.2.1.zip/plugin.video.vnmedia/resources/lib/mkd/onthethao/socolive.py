from codequick import Route, Listitem, Resolver
from resources.lib.kedon import fu, getlinkvnm, tb, quangcao
from json import loads
from datetime import datetime
from calendar import timegm
from time import gmtime
import re
@Route.register
def index_socolive(plugin, **kwargs):
	yield []
	yield Listitem.from_dict(**{'label': 'TẤT CẢ CÁC TRẬN',
	'info': {'plot': tb},
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/soco.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/soco.png'},
	'callback': live_socolive})
	timestamp = timegm(gmtime())
	url = f'https://json.vnres.co/match_recommend.json?v={timestamp}'
	resp = getlinkvnm(url, url)
	if (resp is not None):
		nd = re.search(r'(\{.*\})', resp.text, re.DOTALL)[1]
		m = loads(nd)
		mh = m['data']['matches']
		for k in mh:
			tg = datetime.fromtimestamp(int(k['matchTime'])/1000).strftime('%H:%M %d/%m')
			item = Listitem()
			tenm = f"{tg}: {k['hostName']} vs {k['guestName']}"
			item.label = tenm
			item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/soco.png'
			item.info['plot'] = tb
			item.set_callback(room_soco, k['scheduleId'], tenm, timestamp)
			yield item
	else:
		yield quangcao()
@Route.register
def room_soco(plugin, roomnum=None, title=None, timestamp=None, **kwargs):
	yield []
	if roomnum is None or title is None or timestamp is None:
		pass
	else:
		linkref = fu('http://bit.ly/socolive')
		url = f'https://json.vnres.co/match_recommend.json?v={timestamp}'
		resp = getlinkvnm(url, url)
		if (resp is not None):
			nd = re.search(r'(\{.*\})', resp.text, re.DOTALL)[1]
			m = loads(nd)
			mh = m['data']['matches']
			v = ((l['nickName'], l['icon'], l['anchor']['roomNum']) for k in mh for l in k['anchors'] if k['scheduleId'] == roomnum)
			for k in v:
				tenm = f'{title} - {k[0]}'
				item = Listitem()
				item.label = tenm
				item.art['thumb'] = item.art['fanart'] = k[1]
				item.info['plot'] = tb
				item.set_callback(Resolver.ref('/resources/lib/kedon:playsocolive'), k[2], timestamp, linkref, tenm)
				yield item
		else:
			yield quangcao()
@Route.register
def live_socolive(plugin, **kwargs):
	yield []
	linkref = fu('http://bit.ly/socolive')
	timestamp = timegm(gmtime())
	url = f'http://json.vnres.co/all_live_rooms.json?v={timestamp}'
	resp = getlinkvnm(url, url)
	if (resp is not None):
		nd = re.search(r'(\{.*\})', resp.text, re.DOTALL)[1]
		m = loads(nd)
		mh = m['data']['hot']
		for k in mh:
			item = Listitem()
			tenm = f'{k["title"]} ({k["anchor"]["nickName"]})'
			item.label = tenm
			item.art['thumb'] = item.art['fanart'] = k['cover']
			item.info['plot'] = f'{k["notice"]}\n{tb}'
			item.set_callback(Resolver.ref('/resources/lib/kedon:playsocolive'), k['roomNum'], timestamp, linkref, tenm)
			yield item
	else:
		yield quangcao()