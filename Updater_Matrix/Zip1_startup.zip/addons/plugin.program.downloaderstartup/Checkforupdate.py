﻿# -*- coding: utf-8 -*-
import xbmc
from updatervar import *
from resources.lib.modules import check


if __name__ == '__main__':
    if not setting('updaterversion') == 'false':
        dialog.notification(Dialog_welcome, Dialog_Update, icon_Build, sound=False)
        check.notifyT()
        check.autoenable()
        check.var()
        check.players()
        check.delete()
        check.zip1()
        check.zip2()
        check.zip3()
        check.zip4()
        check.zip5()
        check.installation()
        check.updater()
        check.setsetting()
        check.database()
        check.UpdateAddonRepos()
        check.xmlskin()

    xbmc.sleep(10000)
    if not setting('updaterversion') == 'false': xbmcgui.Dialog().notification("[B][COLOR orange]Το build είναι ενημερωμένο![/COLOR][/B]", "[COLOR white]Καλή διασκέδαση...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/ok.gif')