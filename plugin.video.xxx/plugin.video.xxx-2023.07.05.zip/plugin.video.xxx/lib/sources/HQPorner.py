import re
import xbmcaddon
import datetime
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

BaseURL = 'https://hqporner.com'
Thumb   = 'special://home/addons/plugin.video.xxx/resources/art/hqporner.png'

def Menu():
	addDir('Latest Videos',       BaseURL + '/hdporn/1',       121, Thumb)
	addDir('Top Rated Videos',    BaseURL + '/top/1',         121, Thumb)
	addDir('Categories',          BaseURL + '/categories',   122, Thumb)
	
	#addDir('Most Watched Videos', BaseURL + '/most-viewed/', 121, Thumb)
	#addDir('Popular Today',       BaseURL + '/best/daily',   121, Thumb)
	#addDir('Popular This Week',   BaseURL + '/best/weekly',  121, Thumb)
	#addDir('Popular This Month',  BaseURL + '/best/monthly', 121, Thumb)
	#addDir('Channels',            BaseURL + '/channels',     122, Thumb)

def Browse(url):
	pageURL = url
	r = OpenURL(url)
	r1 = r.replace('\\/', '/')
	r1 = r.replace('\n', '')
	m = re.compile('<section class="box feature">(.+?)</section>').findall(r1, re.MULTILINE)
	for i in m:
		if '/?q' not in i:
			url   = re.compile('<a href="(.+?)"').findall(i)[0]
			thumb = re.compile('src="(.+?)"').findall(i)[0]
			if not thumb.startswith('https'): thumb = 'https:' + thumb
			title = re.compile('alt="(.+?)"').findall(i)[0]
			title = title.title()
			time  = re.compile('<span class="icon fa-clock-o meta-data">(.+?)</span>').findall(i)[0]
			if Setting('show_time') == 'true': title = '[B](%s)[/B] %s' % (time, title)
			url = '%s&random_id=%s' % (url, RandomID())
			addVideo(title, BaseURL + url, 123, thumb)
	n = re.compile('<ul class="actions pagination">(.+?)</ul>').findall(r1)[0]
	NextPage = re.compile('<a href="(.+?)"').findall(n)[-1]
	addDir('Next Page >', BaseURL + NextPage, 121, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	Common.SetView()

def Categories(url):
	r = OpenURL(url)
	m = re.compile('<section class="box feature"><a href="(.+?)" class=".+?" style=".+?"><img src="(.+?)" alt="(.+?)"').findall(r)
	for url, thumb, title in m:
		title = title.title()
		if not thumb.startswith('http'): thumb = 'https:' + thumb
		addDir(title, BaseURL + url, 121, thumb)
	
def PlayStream(url):
	if 'random_id=' in url: url = re.compile('(.+?)&random_id').findall(url)[0]
	r = OpenURL(url)
	video_id = re.compile('src="//mydaddy\.cc/video/(.+?)/"').findall(r)[0]
	r = OpenURL('https://mydaddy.cc/video/%s/' % video_id)
	video = re.compile('<a href=\'(.+?)\'').findall(r)[-1]
	if not video.startswith('http'): video = 'https:' + video
	Play(video)

def RandomID():
	import random
	random_id = str(random.randint(0,1000000))
	return random_id