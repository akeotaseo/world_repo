from json import loads
from re import findall
from time import time

from web_api_request import WebApiRequest, headers, https_checking


class Provider:
    web = WebApiRequest()

    def _ozolio(self, link: str) -> str:
        oid = findall(r"oid=\w+_\w+", self.web.request_get(link).text)[0].split("=")[1]
        refer = findall(r"https://.*?/", link)[0]
        id_ = self.web.request_get(
            f"https://relay.ozolio.com/ses.api?cmd=init&oid={oid}&ver=5&channel=0&control=1&document={refer}").json()[
            "session"]["id"]
        return self.web.request_get(
            f"https://relay.ozolio.com/ses.api?cmd=open&oid={id_}&output=1&format=M3U8&profile=AUTO") \
            .json()["output"]["source"]

    def youtube_stream(self, link: str) -> str:
        response = self.web.request_get(link)
        if response and response is not int and response is not dict:
            return findall(r"https://manifest.googlevideo.com/api/manifest/hls.*?m3u8", response.text)[0]

    def earthcam(self, link: str) -> dict:
        link_play = ""
        referer = findall(r"https://.*?/", link)[0]
        response = self.web.request_get(link)
        if response and response is not int and response is not dict:
            if "/cams/" in link:
                link_js = "https://www.earthcam.com" + findall(r"/js.*?auto", response.text)[0]
                response_link_js = self.web.request_get(link_js)
                if response_link_js and response_link_js is not int and response_link_js is not dict:
                    link_iframe = "https:" + findall(r"//.*current", response_link_js.text)[0]
                    response_link_iframe = self.web.request_get(link_iframe)
                    if response_link_iframe and response_link_iframe is not int and response_link_iframe is not dict:
                        link_play = findall(r"https.*m3u8", response_link_iframe.text)[0].replace("\\", "").split("?")[
                            0]
            elif "/projects/" in link:
                link_flv = "https:" + findall(r"//.*?flv", response.text)[0]
                response_link_flv = self.web.request_get(link_flv)
                if response_link_flv and response_link_flv is not int and response_link_flv is not dict:
                    link_iframe = "https:" + findall(r"//.*current", response_link_flv.text)[0]
                    vid = link_iframe.split("vid=")[1].split(".")[0]
                    response_link_iframe = self.web.request_get(link_iframe)
                    if response_link_iframe and response_link_iframe is not int and response_link_iframe is not dict:
                        link_play = findall(r"https.*m3u8", response_link_iframe.text)[0].replace("\\", "").split("?")[
                            0].replace(".flv", f"{vid}.flv"),
            elif "public.earthcam" in link or "share.earthcam" in link:
                response = self.web.request_get(link).text
                link_json = findall(r"window.earthcam.domain = .*?';", response)[0].split("'")[1] + \
                            findall(r"window.earthcam.domain\+.*?';", response)[0].split("'")[1]
                response_2 = self.web.request_get(link_json).text
                response_3 = self.web.request_get(
                    "https://share.earthcam.net" + loads(response_2)['projects'][0]['servers'][0]['api']).json()
                link_play = response_3["views"][0]["live"]["regular"]["stream"]
            else:
                json_data = loads(findall(r'\{"cam":.*?null}', response.text)[0])
                name_cam = findall(r'var currentName.*?";', response.text)[0].split('"')[1]
                link_play = json_data["cam"][name_cam]["stream"].split("?")[0]
            if link_play:
                return {
                    "type": "hls",
                    "link_play": link_play,
                    "add_headers": {
                        "Referer": referer,
                    }
                }

    def angelcam(self, link: str) -> str:
        response = self.web.request_get(link)
        if response and response is not int and response is not dict:
            return findall(r"source:.*',", response.text)[0].split("'")[1]

    def thousand(self, link: str) -> dict:
        return {
            "type": "hls",
            "link_play": link,
            "add_headers": {
                "Origin": "https://worldcams.tv",
                "Sec-Fetch-Dest": "empty",
                "Sec-Fetch-Mode": "cors",
            }
        }

    def pacpark(self, link: str) -> str:
        return self._ozolio(link)

    def ipcamlive(self, link: str) -> str:
        response = self.web.request_get(link).text
        address = findall(r"var address = .*?';", response)[0].split("'")[1]
        streamid = findall(r"var streamid = .*?';", response)[0].split("'")[1]
        return f"{address}streams/{streamid}/stream.m3u8"

    def skylinewebcams(self, link: str) -> str:
        phpsessid = findall(r"PHPSESSID=\w+", self.web.request_get(link).headers["set-cookie"])[0].split("=")[1]
        return f"https://hd-auth.skylinewebcams.com/live.m3u8?a={phpsessid}"

    def galveston(self, link: str) -> str:
        response = self.web.request_get(link).text
        domain = findall(r'domain:.*?",', response)[0].split('"')[1]
        camera_doc = findall(r'camera_doc:.*?",', response)[0].split('"')[1]
        json_data_1 = self.web.request_get(
            f"{domain}/ses.api?cmd=init&oid={camera_doc}&ver=5&channel=0&control=1&document={link}").json()
        json_data_2 = self.web.request_get(
            f"{json_data_1['session']['server']}/ses.api?cmd=open&oid={json_data_1['session']['id']}&output=1&format=M3U8&profile=AUTO").json()
        return json_data_2["output"]["source"]

    def earthtv(self, link: str) -> str:
        response = self.web.request_get(link).text
        token = findall(r"token: .*?',", response)[0].split("'")[1]
        json_data = self.web.request_get(
            f"https://livecloud.earthtv.com/api/v1/media.getPlayerConfig?playerToken={token}").json()
        return json_data["streamUris"]["hls"]

    def whatsupcams(self, link: str) -> str:
        response = self.web.request_get(
            f"https://services.whatsupcams.com/streams/{link.split('/')[4]}?jsonp=true").text
        return loads(response.strip("streamData(").strip(", 200);"))["hls"]["url"]

    def aspects_holidays(self, link: str) -> str:
        return self._ozolio(link)

    def balticlivecam(self, link: str) -> str:
        response = self.web.request_get(link).text
        ajaxurl = findall(r"ajaxurl = '.*?'", response)[0].split("'")[1]
        action = findall(r"action:.*?',", response)[0]
        id_ = findall(r"id: \d+", response)[0]
        embed = findall(r"embed:\d+", response)[0]
        post = {
            action.split(":")[0]: action.split("'")[1],
            id_.split(":")[0]: id_.split(" ")[1],
            embed.split(":")[0]: embed.split(":")[1],
        }
        response_2 = self.web.request_post(ajaxurl, data=post).text
        return findall(r"src: '.*?'", response_2)[0].split("'")[1]

    def ibiza_style(self, link: str) -> str:
        return self.earthtv(link)

    def video_nest(self, link: str) -> str:
        response = self.web.request_get(link).text
        uuid = findall(r"uuid=\w+", response)[0].split("=")[1]
        token = findall(r'data-token="\w+"', response)[0].split('"')[1]
        json_data = self.web.request_get(
            f"https://video.nest.com/api/dropcam/cameras.get_by_public_token?token={token}&_={int(time())}").json()
        return f"https://{json_data['items'][0]['live_stream_host']}/nexus_aac/{uuid}/playlist.m3u8?public={token}"

    @staticmethod
    def iframe_link_check(link: str, name) -> dict:
        # from view import View
        # View().output_logs(link)
        if link:
            link_start = findall(r"https://.*?/", link)[0].split("/")[2]
            title = f"{name} [COLOR=grey]({link_start})[/COLOR]"
            if "youtube" in link:
                if link.startswith("https://www.youtube.com/watch?v="):
                    link = link
                else:
                    link = "https://www.youtube.com/watch?v=" + link.split("/")[4].split("?")[0]
                router = "youtube"
            elif "angelcam" in link:
                router = "angelcam"
            elif "video.nest" in link:
                router = "video_nest"
            elif "skylinewebcams" in link:
                router = "skylinewebcams"
            elif "galveston" in link:
                router = "galveston"
            elif "whatsupcams" in link:
                router = "whatsupcams"
            elif "aspects-holidays" in link:
                router = "aspects-holidays"
            elif "balticlivecam" in link:
                router = "balticlivecam"
            elif "ibiza-style" in link:
                router = "ibiza-style"
            elif "pacpark" in link:
                router = "pacpark"
            elif "earthtv" in link:
                router = "earthtv"
            elif "earthcam" in link:
                router = "earthcam"
            elif "ipcamlive" in link:
                if link.endswith(".m3u8"):
                    router = "play"
                else:
                    router = "ipcamlive"

            elif "theiet" in link or \
                    "volusia" in link:
                title = f"[COLOR=pink]Ресурс параноиков[/COLOR] {name} [COLOR=grey]({link_start})[/COLOR]"
                router = ""

            elif "rtsp" in link or \
                    "livefromiceland" in link or \
                    "sochi.camera" in link or \
                    "livecam-pro" in link or \
                    "mall.tv" in link or \
                    "ustream" in link or \
                    "flughafen-zuerich" in link or \
                    "new.livestream" in link or \
                    "rhombussystems" in link:
                title = f"[COLOR=red]Не нашлось рабочей ссылки[/COLOR] {name} [COLOR=grey]({link_start})[/COLOR]"
                router = ""

            elif "timetechnology" in link or \
                    "vossaskyen" in link or \
                    "resortcams" in link or \
                    "akamaized" in link or \
                    "videos.sapo" in link:
                router = "hls"

            elif "1000eyes" in link or \
                    "streamlock" in link or \
                    "cdn-surfline" in link or \
                    "fullcityservers" in link or \
                    "brucity" in link or \
                    "camzonecdn" in link or \
                    "toya.net" in link or \
                    "terrafox" in link or \
                    "profi-net" in link or \
                    "camsecure" in link:
                router = "play"

            else:
                raise ValueError(f"Не известная ссылка на трансляцию - {link}")

            return {
                "title": title,
                "data": link,
                "play": True,
                "router": router,
            }
