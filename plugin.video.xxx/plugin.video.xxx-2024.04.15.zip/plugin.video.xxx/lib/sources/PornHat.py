import re
import xbmcaddon
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

BaseURL = 'https://www.pornhat.com'
Thumb   = 'special://home/addons/plugin.video.xxx/resources/art/pornhat.png'


def Menu():
	addDir('Latest Videos',      BaseURL,                61, Thumb)
	addDir('Most Viewed Videos', BaseURL + '/trending/', 61, Thumb)
	addDir('Top Rated Videos',   BaseURL + '/popular/',  61, Thumb)
	addDir('Categories',         BaseURL + '/tags/',     62, Thumb)

def Browse(url):
	r = OpenURL(url)
	m = re.compile('<a href="(.+?)" title="(.+?)"  data-preview-custom=".+?" >\n.+?<img class="thumb lazy-load" src=".+?" data-original="(.+?)"').findall(r)
	for url, title, thumb in m:
		thumb = thumb.replace('640x360/1.jpg', 'preview.jpg')
		time = GetTime(url)
		if Setting('show_time') == 'true': title = '[B](%s)[/B] %s' % (time, title)
		import random
		random_id = random.randint(0,1000000)
		url = '%s&random_id=%s' % (url, str(random_id))
		addVideo(title, BaseURL + url, 63, thumb)
	n = re.compile('<li class="pagination-next"><a href="(.+?)">Next</a></li>').findall(r)
	for NextPage in n:
		addDir('Next page >', BaseURL + NextPage, 61, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	Common.SetView()
		
def Categories(url):
	r = OpenURL(url)
	m = re.compile('<a class="item" href="(.+?)"><i class="fa fa-tag"></i>(.+?)</a>').findall(r)
	for content_id, title in m:
		addDir(title.title(), BaseURL + content_id, 61, Thumb)
		
def GetTime(url):
	r = OpenURL(BaseURL + url)
	t = re.compile('<li><i class="fa fa-clock-o"></i> <span>(.+?)</span></li>').findall(r)[0]
	return(t)
	
def PlayStream(url):
	if 'random_id=' in url:
		url = re.compile('(.+?)&random_id').findall(url)[0]
	r = OpenURL(url)
	url = re.compile('<a class="download-link" href="(.+?)"').findall(r)[-1]
	Play(url)
