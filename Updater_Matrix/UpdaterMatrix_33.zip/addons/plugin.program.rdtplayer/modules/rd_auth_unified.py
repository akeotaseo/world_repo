import xbmcaddon
import xbmc
import xbmcgui

ADDON = xbmcaddon.Addon()
API_KEY = ADDON.getSetting("api_key")

def get_rd_headers():
    if not API_KEY:
        xbmcgui.Dialog().ok("Real-Debrid Error", "Missing API Key. Please enter it in the add-on settings.")
        return None
    return {"Authorization": f"Bearer {API_KEY}"}
