# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests
import re
from ..utils.browser import Firefox
from ..utils.resolve import Resolver

class TA3(Resolver):
    def __init__(self):
        self.api = "https://embed.livebox.cz/ta3_v2/live-source.js"

    def grab(self, channel):
        firefox = Firefox()
        r = requests.get(self.api, headers=firefox.headers)
        matches = re.findall("\"src\" : \"([^}]*)\"", r.content.decode('utf-8'))
        src = None
        for match in matches:
            if '1.smil' in match:
                src = match
                break
        src = src.replace('|','%7C')
        if src.startswith('//'):
            src = 'https:' + src
        return src, firefox.headers