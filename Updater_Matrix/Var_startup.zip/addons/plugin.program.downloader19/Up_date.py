﻿import xbmc, xbmcgui
def Test():
    xbmcgui.Dialog().notification("Check Updates", "Ελεγχος για ενημερώσεις προσθέτων", icon='special://home/addons/plugin.program.downloader19/resources/media/auto2.png', sound=False)

    xbmc.executebuiltin('ActivateWindow(2139)')

Test()