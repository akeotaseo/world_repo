# -*- coding: utf-8 -*-
#$pyFunction
def GetLSProData(page_data,Cookie_Jar,m):
    import xbmcgui
    dialog = xbmcgui.Dialog()
    dialog.textviewer("""[COLOR aqua]CRISTAL AZUL[/COLOR]""", """[COLOR white]Que Scripts/Depencias tengo instalados?:[/COLOR]

[COLOR lightskyblue]-[COLOR white]Version kodi:  19.1[/COLOR]

[COLOR lightskyblue]-[COLOR white]Acceso a Repositorios (Actualizaciones):  [COLOR green]SI.[/COLOR][/COLOR]

[COLOR lightskyblue]-[COLOR white]Inputstream Adaptative:  [COLOR green]SI.[/COLOR] [COLOR white]version instalada 19.0.0[/COLOR][/COLOR]

[COLOR lightskyblue]-[COLOR white]ResolveUrl:  [COLOR green]SI.[/COLOR] version instalada 5.1.53[/COLOR]

[COLOR lightskyblue]-[COLOR white]Actualizado ResolveUrl? [COLOR green]SI.[/COLOR] tiene la Ultima version, la 5.1.53

[COLOR lightskyblue]-[COLOR white]Horus: [COLOR red]NO, le recomendamos que lo instale. Si no lo instala, NO podra ver gran parte de la seccio­n Deporte.[/COLOR][/COLOR]

[COLOR lightskyblue]-[COLOR white]Youtube: [COLOR green]SI.[/COLOR]


  [COLOR aqua]Lea todo hasta el final e instale lo que le falte en la siguiente pantalla, si tiene problemas en la instalacion, instale desde la seccion navaja suiza, fuente kodileia, carpeta ayuda, el repositorio de urlresolve se llama repository.xbmchub.[/COLOR]



[COLOR lightskyblue]-[COLOR white]Recuerde que necesita estos scripts/addons, [/COLOR][COLOR white]Tenga siempre actualizadas estas dependencias, gracias a todos ellos por su trabajo.[/COLOR]

[COLOR lightskyblue]-[COLOR white]¿Y donde conseguirlos actualizados?[/COLOR]
[COLOR white]En nuestra fuente: [COLOR gold]https://fuentekodileia.github.io[/COLOR]
[COLOR white]Tambien en Luar[/COLOR]

[COLOR lightskyblue]-[COLOR white]Que hago si todavia no me funciona:[/COLOR]
[COLOR white]Estamos en telegram: [COLOR gold]https://t.me/addonfestaycristal [COLOR white]y en [COLOR gold]https://t.me/kodi18[/COLOR]








                                                                                                                                                          [COLOR aqua]Cristal Azul[/COLOR]""")
    return 'https://pastebin.com/raw/J7JmvXZj'
