
# STAR Player addon for Kodi

## About

STAR Live and on-demand broadcasts

Kodi Addon for https://www.star.gr

This addon is not published nor endorsed by star.gr

This addon offers content available in Greece

Icons sourced from flaticon.com ([Licence](https://file000.flaticon.com/downloads/license/license.pdf "Licence"))
Main artwork from https://www.star.gr

License
-------
This software is released under the [GPL 3.0 license] [1].

[1]: http://www.gnu.org/licenses/gpl-3.0.html