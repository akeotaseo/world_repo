﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import json
import xbmcvfs
import time
from datetime import datetime, timedelta
from collections import OrderedDict
from urllib.parse import urlencode

from .common import *


if not xbmcvfs.exists(os.path.join(dataPath, 'settings.xml')):
	xbmcvfs.mkdirs(dataPath)
	xbmc.executebuiltin('addon.openSettings({})'.format(addon_id))

def mainMenu():
	debug_MS("(navigator.mainMenu) -------------------------------------------------- START = mainMenu --------------------------------------------------")
	debug_MS("(navigator.mainMenu) ### BASE_URL = {0} ###".format(BASE_URL))
	addDir(translation(30607), icon, {'mode': 'listTimeline', 'url': BASE_DROID+'/pages/timeline'})
	un_WANTED = ['/video', 'livingit', '/paidpost', 'partner']
	COMBI_ONE, COMBI_TWO, COMBI_REST = ([] for _ in range(3))
	content = getUrl(BASE_URL)
	results_1 = re.findall('<div class="js-programs-menu c-programs-menu c-header-sub-menu(.+?)<div class="c-programs-menu__footer', content, re.S)
	for chtml in results_1:
		debug_MS("(navigator.mainMenu) xxxxx RESULT-01 : {0} xxxxx".format(str(chtml)))
		part = chtml.split('<div class="c-programs-menu')
		for i in range(1,len(part),1):
			entry = part[i]
			if 'list-item__link' in entry:
				main_NAME = re.compile(r'class=["\']u-display-inline-block.*?>([^<]+?)(?:</a>|</span>)', re.S).findall(entry)[0]
				main_NAME = cleaning(main_NAME)
				match_URL = re.compile(r'<a href="([^"]+?)"\s*class=["\']u-display-inline-block', re.S).findall(entry)
				main_URL = match_URL[0] if match_URL else None
				if main_URL and any(x in main_URL.lower() for x in un_WANTED): continue
				debug_MS("(navigator.mainMenu[1]) no.01 ##### TITLE : {0} || URL : {1} || COMBINATION : {2} #####".format(main_NAME, str(main_URL), str(entry)))
				COMBI_ONE.append(main_NAME.lower())
				COMBI_TWO.append([main_NAME, main_URL, entry])
	if COMBI_TWO:
		for title_one, news_one, elem in COMBI_TWO:
			addDir(title_one, icon, {'mode': 'SubTopics', 'url': elem, 'extras': news_one})
	results_2 = re.findall('<div class="c-menu-more c-header-sub-menu(.+?)<li class="js-programs_links list-item list-item', content, re.S)
	for item in results_2:
		match = re.compile(r' href="([^"]+?)" aria-label.*?>([^<]+?)(?:</a>|</span>)', re.S).findall(item)
		for link, title in match:
			rest_NAME = cleaning(title) if title not in ['', 'none', 'None'] else None
			rest_URL = link if link not in ['', 'none', 'None', None] else None
			COMBI_REST.append([rest_NAME, rest_URL])
	if COMBI_ONE and COMBI_REST:
		for title_two, news_two in COMBI_REST:
			if title_two and news_two and title_two.lower() not in COMBI_ONE and not any(z in news_two.lower() for z in un_WANTED):
				addDir(title_two, icon, {'mode': 'listVideos', 'url': news_two})
				debug_MS("(navigator.mainMenu[2]) no.02 ##### TITLE : {0} || URL : {1} #####".format(title_two, news_two))
	addDir(translation(30608), artpic+'livestream.png', {'mode': 'playLIVE'}, folder=False)
	if enableADJUSTMENT:
		addDir(translation(30609), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def SubTopics(first_LIST, first_PLUS):
	debug_MS("(navigator.SubTopics) -------------------------------------------------- START = SubTopics --------------------------------------------------")
	debug_MS("(navigator.SubTopics) ### first_LIST = {0} ### first_PLUS = {1} ###".format(first_LIST, str(first_PLUS)))
	ISOLATED = set()
	if first_PLUS not in ['', 'None', None]:
		addDir('NEWS', icon, {'mode': 'listVideos', 'url': first_PLUS})
	match = re.compile(r'<a href="([^"]+?)".*?list-item__link.*?>(.+?)</a>', re.S).findall(first_LIST)
	for sub_URL, sub_THEME in match:
		if sub_URL in ISOLATED:
			continue
		ISOLATED.add(sub_URL)
		sub_THEME = cleaning(sub_THEME).replace('\n', '')
		addDir(sub_THEME, icon, {'mode': 'listVideos', 'url': sub_URL, 'extras': sub_THEME})
		debug_MS("(navigator.SubTopics[1]) no.01 ##### TITLE : {0} || URL : {1} #####".format(sub_THEME, sub_URL))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVideos(url, CAT):
	debug_MS("(navigator.listVideos) -------------------------------------------------- START = listVideos --------------------------------------------------")
	debug_MS("(navigator.listVideos) ### startURL = {0} ### CATEGORY = {1} ###".format(url, str(CAT)))
	SEND = {}
	COMBI_EPISODE, SEND['videos'] = ([] for _ in range(2))
	api_FOUND = False
	ISOLATED = set()
	new_URL = url if url.startswith('http') else 'https:'+url if url.startswith('//') else BASE_URL+url
	content = getUrl(new_URL) # https://de.euronews.com/api/program/state-of-the-union?before=1519998565&extra=1&offset=13
	match = re.findall('data-api-url="([^"]+)"', content, re.S)
	if match:
		API_URL = match[-1]
		api_FOUND = True
	else:
		if url.count('/') == 1:# WELT -> No Comment (url='/nocomment', KEINE 'data-api-url' vorhanden)
			API_URL = BASE_URL+'/api/program'+url
			api_FOUND = True
		elif url.count('/') > 1 and '/program' in url:# WELT -> Euronews Witness (url='//de.euronews.com/programme/euronews-witness', KEINE 'data-api-url' vorhanden)
			API_URL = BASE_URL+'/api/program/'+url.split('/')[-1]
			api_FOUND = True
	if api_FOUND:
		url2 = 'https:'+API_URL+'?extra=1&offset=0&limit=50' if API_URL.startswith('//') else API_URL+'?extra=1'
		debug_MS("(navigator.listVideos[1]) no.01 ### URL-2 : {0} ###".format(url2))
		result = getUrl(url2, REF=BASE_URL)
		JS = json.loads(result, object_pairs_hook=OrderedDict)
		DATA = JS['articles'] if 'articles' in JS and JS.get('articles', '') else JS
		for item in DATA:
			debug_MS("(navigator.listVideos[2]) no.02 xxxxx ARTICLE-01 : {0} xxxxx".format(str(item)))
			photo, Note_1, description = ("" for _ in range(3))
			begins, digs, duration, play_LINK, YTID = (None for _ in range(5))
			if isinstance(item, str):
				item = DATA[item]
			if 'data' in item and item.get('data', ''):
				item = item['data']
			if len(item) == 0: continue
			debug_MS("(navigator.listVideos[2]) no.02 xxxxx ARTICLE-02 : {0} xxxxx".format(str(item)))
			episID = (str(item.get('id', '')).replace('article-', '').replace('header-', '') or '00')
			name = cleaning(item['title'])
			if item.get('images', '') and item.get('images', {})[0].get('url', ''):
				photo = item['images'][0]['url'].replace('{{w}}x{{h}}', '1024x576') # OLD = 861x485
			if str(item.get('publishedAt', '')).isdigit():
				begins = datetime.fromtimestamp(item['publishedAt']).strftime('%d{0}%m{0}%Y').format('.')
				digs = datetime.fromtimestamp(item['publishedAt']).strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('-', '•', ':')
			if digs: Note_1 = translation(30610).format(digs)
			description = (cleaning(item.get('leadin', '')) or "")
			plot = Note_1+description
			if 'videos' in item and len(item['videos']) > 0:
				if 'duration' in str(item['videos']):
					duration = [int(vid.get('duration', []))/1000 for vid in item.get('videos', {})][-1]
				if 'url' in str(item['videos']):
					play_LINK = [vid.get('url', []) for vid in item.get('videos', {})][-1]
				if item.get('externalPartners', '') and item.get('externalPartners', {}).get('youtubeId', ''):
					YTID = item['externalPartners']['youtubeId']
			if play_LINK is None or play_LINK in ISOLATED:
				continue
			ISOLATED.add(play_LINK)
			debug_MS("(navigator.listVideos[3]) no.03 ##### TITLE : {0} || THUMB : {1} #####".format(str(name), photo))
			debug_MS("(navigator.listVideos[3]) no.03 ##### YoutubeID : {0} || VIDEO : {1} || AIRED : {2} #####".format(str(YTID), play_LINK, str(begins)))
			COMBI_EPISODE.append([name, episID, play_LINK, YTID, photo, plot, duration, begins])
	if COMBI_EPISODE:
		for name, episID, play_LINK, YTID, photo, plot, duration, begins in COMBI_EPISODE:
			liz = xbmcgui.ListItem(name, path=HOST_AND_PATH+'?IDENTiTY='+episID+'&mode=playCODE')
			if plot in ['', 'None', None]: plot = "..."
			if KODI_ov20:
				videoInfoTag = liz.getVideoInfoTag()
				videoInfoTag.setTitle(name)
				videoInfoTag.setTagLine(None)
				videoInfoTag.setPlot(plot)
				if duration: videoInfoTag.setDuration(int(duration))
				if begins: videoInfoTag.setDateAdded(begins)
				if begins: videoInfoTag.setFirstAired(begins)
				videoInfoTag.setGenres(['News'])
				videoInfoTag.setStudios(['euronews'])
				videoInfoTag.setMediaType('movie')
			else:
				info = {}
				info['Title'] = name
				info['Tagline'] = None
				info['Plot'] = plot
				info['Duration'] = duration
				if begins: info['Date'] = begins
				if begins: info['Aired'] = begins
				if begins: info['Year'] = begins[6:10]
				info['Genre'] = 'News'
				info['Studio'] = 'euronews'
				info['Mediatype'] = 'movie'
				liz.setInfo(type='Video', infoLabels=info)
			liz.setArt({'icon': icon, 'thumb': photo, 'poster': photo, 'fanart': defaultFanart})
			if photo and useThumbAsFanart and photo != icon and not artpic in photo:
				liz.setArt({'fanart': photo})
			liz.setProperty('IsPlayable', 'true')
			liz.setContentLookup(False)
			xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=HOST_AND_PATH+'?IDENTiTY='+episID+'&mode=playCODE', listitem=liz)
			SEND['videos'].append({'url': play_LINK, 'filter': episID, 'name': name, 'pict': photo, 'cycle': duration, 'transmit': YTID})
		with open(WORKFILE, 'w') as ground:
			json.dump(SEND, ground, indent=4, sort_keys=True)
	else:
		debug_MS("(navigator.listVideos) ##### Keine VIDEO-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30525).format('Videos'), translation(30526).format(str(CAT)), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listTimeline(url):
	debug_MS("(navigator.listTimeline) ------------------------------------------------ START = listTimeline -----------------------------------------------")
	debug_MS("(navigator.listTimeline) ### startURL = {0} ###".format(url))
	SEND = {}
	COLLECTED, COMBI_FIRST, COMBI_LINKS, COMBI_SECOND, COMBI_THIRD, SEND['videos'] = ([] for _ in range(6))
	counter = 0
	content_2 = ""
	content_1 = getUrl(url)
	DATA_ONE = json.loads(content_1)
	if 'pagination' in DATA_ONE and DATA_ONE.get('pagination', {}).get('next', '') and DATA_ONE.get('pagination', []).get('next', {}).get('url', ''):
		nextPG = DATA_ONE['pagination']['next']['url']
		if nextPG.startswith('/pages/timeline') and nextPG.endswith('slide=2'):
			nextURL = BASE_DROID+nextPG
			debug_MS("(navigator.listTimeline) PAGES ### Now show NextPage : {0} ### FOUND".format(nextURL))
			content_2 = getUrl(nextURL)
	COLLECTED = '['+content_1+','+content_2+']'
	READY = json.loads(COLLECTED, object_pairs_hook=OrderedDict)
	debug_MS("++++++++++++++++++++++++")
	debug_MS("(navigator.listTimeline[1]) no.01 XXXXX CONTENT-01 : {0} XXXXX".format(str(READY)))
	debug_MS("++++++++++++++++++++++++")
	for each in READY:
		if 'pageContent' in each and len(each['pageContent']) > 0:
			for elem in each.get('pageContent', []):
				if elem.get('type', '') == 'justin' and 'content' in elem and len(elem['content']) > 0:
					for item in elem.get('content', []):
						debug_MS("(navigator.listTimeline[2]) no.02 xxxxx ITEM-01 : {0} xxxxx".format(str(item)))
						THUMB_1, NOTE_1 = ("" for _ in range(2))
						AIRED_1, DIGS_1 = (None for _ in range(2))
						counter += 1
						episID_1 = (str(item.get('id', '')).replace('article-', '').replace('header-', '') or '00')
						TITLE_1 = cleaning(item['title'])
						if item.get('image', '') and item.get('image', {}).get('url', ''):
							THUMB_1 = item['image']['url'].replace('{{w}}x{{h}}', '1024x576') # OLD = 861x485
						if str(item.get('uts', '')).isdigit():
							AIRED_1 = datetime.fromtimestamp(item['uts']).strftime('%d{0}%m{0}%Y').format('.')
							DIGS_1 = datetime.fromtimestamp(item['uts']).strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('-', '•', ':')
						if DIGS_1: NOTE_1 = translation(30610).format(DIGS_1)
						SHOWVIDEO_1 = (item.get('showVideo', False) or False)
						COMBI_FIRST.append([int(counter), episID_1, TITLE_1, THUMB_1, AIRED_1, NOTE_1, SHOWVIDEO_1])
						if item.get('link', '') and item.get('link', {}).get('url', ''):
							COMBI_LINKS.append(BASE_DROID+item['link']['url'])
	if COMBI_FIRST:
		COMBI_SECOND = getMultiData(COMBI_LINKS)
		if COMBI_SECOND:
			DATA_TWO = json.loads(COMBI_SECOND, object_pairs_hook=OrderedDict)
			#log("++++++++++++++++++++++++")
			#log("(navigator.listTimeline[3]) no.03 XXXXX CONTENT-02 : {0} XXXXX".format(str(DATA_TWO)))
			#log("++++++++++++++++++++++++")
			for elem in DATA_TWO:
				if elem is not None and 'pageContent' in elem and elem.get('pageContent', {})[0].get('content', ''):
					DESC_1, DESC_2 = ("" for _ in range(2))
					TAGLINE_2, DURATION_2, PLAYLINK_2 = (None for _ in range(3))
					debug_MS("(navigator.listTimeline[3]) no.03 xxxxx ELEM-02 : {0} xxxxx".format(str(elem)))
					SHORT = elem['pageContent'][0]['content'][0]
					LONGER = elem['pageContent'][2]['content'][0] if elem.get('pageContent', {})[2].get('content', '') else None
					markID_2 = (str(SHORT.get('id', '')).replace('article-', '').replace('header-', '') or '00')
					DESC_1 = (SHORT.get('summary', '') or "")
					if VIDEO_LONG and LONGER and LONGER.get('text', ''):
						TAG_2 = re.compile(r'</style></head>.+?<h2>(.*?)</h2>', re.S).findall(LONGER['text'])
						STORY_2 = re.findall(r'<p[^>]*>(.*?)</p>', LONGER['text'], re.S)
						if STORY_2:
							for snippet in STORY_2:
								DESC_2 = DESC_2+cleaning(snippet)+'[CR]'
						TAGLINE_2 = cleaning(TAG_2[0]) if TAG_2 else None
						if TAGLINE_2 and len(TAGLINE_2) > 125:
							TAGLINE_2 = TAGLINE_2[:125]+'...'
					if SHORT.get('video', ''):
						if elem.get('tracking', '') and elem.get('tracking', {}).get('adobe', '') and elem.get('tracking', []).get('adobe', {}).get('customParams', ''):
							for entry in elem['tracking']['adobe']['customParams']:
								if 'videoduration' in entry.get('key', '') and str(entry.get('value')).isdigit():
									DURATION_2 = int(entry['value'])# Wird in Sekunden angezeigt
						YTID_2 = (SHORT.get('video', {}).get('id', None) or None)
						PLAYLINK_2 = (SHORT.get('video', []).get('videoFallback', {}).get('url', '') or SHORT.get('video', {}).get('url', ''))
						COMBI_THIRD.append([markID_2, DESC_1, DESC_2, TAGLINE_2, DURATION_2, YTID_2, PLAYLINK_2])
	if COMBI_THIRD:
		RESULT = [a + b for a in COMBI_FIRST for b in COMBI_THIRD if a[1] == b[0]] # Zusammenführung von Liste1 und Liste2 - wenn die ID überein stimmt !!!
		#log("++++++++++++++++++++++++")
		#log("(navigator.listTimeline[4]) no.04 XXXXX RESULT-03 : {0} XXXXX".format(str(RESULT)))
		#log("++++++++++++++++++++++++")
		for da in sorted(RESULT, key=lambda k: k[0], reverse=False):
			debug_MS("---------------------------------------------") ### Liste2 beginnt mit Nummer:7 ###
			debug_MS("(navigator.listTimeline[4]) no.04 ### Anzahl = {0} || Eintrag : {1} ###".format(str(len(da)), str(da)))
			episID, name, photo, begins, Note_1, showVID = da[1], da[2], da[3], da[4], da[5], da[6]
			markID, DESC_1, DESC_2, tagline, duration, youtubeID, play_LINK = da[7], da[8], da[9], da[10], da[11], da[12], da[13]
			COMP_DESC = da[9] if len(da[9]) > 10 else da[8] # COMP_DESC = DESC_2 if len(DESC_2) > 10 else DESC_1
			plot = Note_1+COMP_DESC
			debug_MS("(navigator.listTimeline[5]) no.05 ##### TITLE : {0} || THUMB : {1} #####".format(str(name), photo))
			debug_MS("(navigator.listTimeline[5]) no.05 ##### showVID : {0} || YoutubeID : {1} || VIDEO : {2} || AIRED : {3} #####".format(str(showVID), str(youtubeID), play_LINK, str(begins)))
			if showVID is True and play_LINK:
				liz = xbmcgui.ListItem(name, path=HOST_AND_PATH+'?IDENTiTY='+episID+'&mode=playCODE')
				if plot in ['', 'None', None]: plot = "..."
				if KODI_ov20:
					videoInfoTag = liz.getVideoInfoTag()
					videoInfoTag.setTitle(name)
					videoInfoTag.setTagLine(tagline)
					videoInfoTag.setPlot(plot)
					if duration: videoInfoTag.setDuration(int(duration))
					if begins: videoInfoTag.setDateAdded(begins)
					if begins: videoInfoTag.setFirstAired(begins)
					videoInfoTag.setGenres(['News'])
					videoInfoTag.setStudios(['euronews'])
					videoInfoTag.setMediaType('movie')
				else:
					info = {}
					info['Title'] = name
					info['Tagline'] = tagline
					info['Plot'] = plot
					info['Duration'] = duration
					if begins: info['Date'] = begins
					if begins: info['Aired'] = begins
					if begins: info['Year'] = begins[6:10]
					info['Genre'] = 'News'
					info['Studio'] = 'euronews'
					info['Mediatype'] = 'movie'
					liz.setInfo(type='Video', infoLabels=info)
				liz.setArt({'icon': icon, 'thumb': photo, 'poster': photo, 'fanart': defaultFanart})
				if photo and useThumbAsFanart and photo != icon and not artpic in photo:
					liz.setArt({'fanart': photo})
				liz.setProperty('IsPlayable', 'true')
				liz.setContentLookup(False)
				xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=HOST_AND_PATH+'?IDENTiTY='+episID+'&mode=playCODE', listitem=liz)
				SEND['videos'].append({'url': play_LINK, 'filter': episID, 'name': name, 'pict': photo, 'cycle': duration, 'transmit': youtubeID})
		with open(WORKFILE, 'w') as ground:
			json.dump(SEND, ground, indent=4, sort_keys=True)
	else:
		debug_MS("(navigator.listTimeline) ##### Keine TIMELINE-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30525).format('Videos'), translation(30526).format(translation(30606)), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playLIVE():
	debug_MS("(navigator.playLIVE) ------------------------------------------------ START = playLIVE -----------------------------------------------")
	LiveURL, youtubeID, testCODE = (False for _ in range(3))
	req_FIRST = 'https://www.euronews.com/api/live/data?locale={}'.format(langDROID.replace('gr', 'el').replace('pe', 'fa')) # https://www.euronews.com/api/live/data?locale=en
	content = getUrl(req_FIRST, method='TRACK')
	if content.status_code == 200 and re.search(r'"videoId":', content.text):
		youtubeID = content.json()['videoId']
		debug_MS("(navigator.playLIVE[1]) no.01 ***** youtubeID : {0} *****".format(str(youtubeID)))
	testCODE = youtubeID if youtubeID else channelLIVE if channelLIVE != '00' else False
	if testCODE:
		log("(navigator.playLIVE[2]) no.02 ##### TRY -  TO - PLAY - VIA - YOUTUBE = YES #####")
		response = getUrl('https://www.youtube.com/watch?v='+testCODE, method='TRACK')
		if response.status_code == 200 and re.search(r'"isLive":true', response.text):
			LiveURL = '{}?video_id={}'.format('plugin://plugin.video.youtube/play/', testCODE)
	else: log("(navigator.playLIVE[2]) no.02 ##### TESTING NOT FOUND - ACTION NOT SUCCESSFUL - SKIP #####")
	if LiveURL:
		debug_MS("(navigator.playLIVE) ### LiveURL : {0} ###".format(LiveURL))
		LTM = xbmcgui.ListItem(path=LiveURL, label=translation(30611))
		LTM.setMimeType('application/vnd.apple.mpegurl')
		xbmc.Player().play(item=LiveURL, listitem=LTM)
	else:
		failing("(navigator.playLIVE) ##### Abspielen des Live-Streams NICHT möglich ##### URL : {0} #####\n   ########## KEINEN Live-Stream-Eintrag auf der Webseite von *euronews.com* gefunden !!! ##########".format(url))
		return dialog.notification(translation(30521).format('LIVE', ''), translation(30527), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playCODE(IDD):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS("(navigator.playCODE) ### IDD = {0} ###".format(IDD))
	finalURL = False
	with open(WORKFILE, 'r') as wok:
		ARRIVE = json.load(wok)
		for elem in ARRIVE['videos']:
			if elem['filter'] != '00' and elem['filter'] == IDD:
				finalURL = elem['url']
				name = elem['name']
				photo = elem['pict']
				duration = elem['cycle']
				youtubeID = elem['transmit']
				debug_MS("(navigator.playCODE[1]) no.01 ### WORKFILE-Line : {0} ###".format(str(elem)))
	if finalURL:
		if PlayTUBE:
			if youtubeID is None:
				log("(navigator.playCODE[2]) no.02 ##### SECOND - TRY -  TO - GET - youtubeID #####")
				content = getUrl(BASE_URL+'/embed/'+IDD).replace('\\', '').replace("&quot;", "\"")
				match = re.compile(r'"videoid":"([^"]+?)","youtubevideoid":"([^"]+?)",', re.S).findall(content)
				youtubeID = match[0][1] if match and match[0][0] == IDD and match[0][1] not in ['', 'none', 'None'] else None
			if youtubeID:
				log("(navigator.playCODE[2]) no.02 ##### TRY -  TO - PLAY - VIA - YOUTUBE = YES #####")
				response = getUrl('https://www.youtube.com/oembed?format=json&url=http://www.youtube.com/watch?v='+youtubeID, method='TRACK')
				if response.status_code == 200 and re.search(r'"provider_url":"https://www.youtube.com/"', response.text):
					finalURL = '{}?video_id={}'.format('plugin://plugin.video.youtube/play/', str(youtubeID))
		log("(navigator.playCODE) YTID : {0} || StreamURL : {1}".format(str(youtubeID), finalURL))
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, xbmcgui.ListItem(path=finalURL))

def addDir(name, image, params={}, plot=None, folder=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		videoInfoTag = liz.getVideoInfoTag()
		videoInfoTag.setTitle(name), videoInfoTag.setPlot(plot), videoInfoTag.setStudios(['euronews'])
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Studio': 'euronews'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)
