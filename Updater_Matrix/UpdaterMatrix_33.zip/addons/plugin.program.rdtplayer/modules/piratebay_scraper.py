# -*- coding: utf-8 -*-
import requests
from bs4 import BeautifulSoup

BASE = "https://thepiratebay11.com"

HEADERS = {
    "User-Agent": "Mozilla/5.0"
}

def fetch(url):
    try:
        r = requests.get(url, headers=HEADERS, timeout=10)
        if r.status_code == 200:
            return r.text
    except:
        pass
    return ""

def parse(html):
    results = []
    if not html:
        return results

    soup = BeautifulSoup(html, "html.parser")

    rows = soup.select("table#searchResult tr")
    for row in rows:
        tds = row.find_all("td")
        if len(tds) < 2:
            continue

        name_tag = tds[1].find("a", href=True)
        magnet_tag = tds[1].find("a", href=True, title="Download this torrent using magnet")

        if not name_tag or not magnet_tag:
            continue

        label = name_tag.get_text(strip=True)
        magnet = magnet_tag["href"]

        details = tds[1].find("font")
        size = "Unknown"
        seeders = tds[2].get_text(strip=True) if len(tds) > 2 else "0"
        leechers = tds[3].get_text(strip=True) if len(tds) > 3 else "0"

        if details:
            text = details.get_text()
            if "Size" in text:
                size = text.split("Size")[1].split(",")[0].strip(" :")

        results.append({
            "label": label,
            "magnet": magnet,
            "size": size,
            "seeders": seeders,
            "leechers": leechers,
        })

    return results


# ---------------------------
# PUBLIC SCRAPER FUNCTIONS
# ---------------------------

def search(query):
    q = query.replace(" ", "%20")
    html = fetch(f"{BASE}/search/{q}/0/99/0")
    return parse(html)

def top_movies():
    html = fetch(f"{BASE}/top/201")
    return parse(html)

def trending():
    html = fetch(f"{BASE}/top/207")
    return parse(html)

def top_tv():
    html = fetch(f"{BASE}/top/205")
    return parse(html)

def movies_4k():
    html = fetch(f"{BASE}/search/uhd/0/99/0")
    return parse(html)
