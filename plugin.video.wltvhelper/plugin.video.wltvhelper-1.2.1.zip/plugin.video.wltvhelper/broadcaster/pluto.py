# -*- coding: utf-8 -*-

# Film:
# Film, Film+, Film Azione, Film Romantici, Film Romantici+, Film Thriller, Film Classici, Cinema Italiano, Film Commedia, Film Drama

# Serie:
# Serie, Serie+, Serie Teen, Serie Teen+, Consulenze Illegali, Le sorelle McLeod, Mutant X, Andromeda

# Crime:
# Crime

# Intrattenimento
# Ex On The Beach, Catfish, Catfish+, Real Life, Real Life+, Anime, Young & Fabulous, Young & Fabulous+, Dating, 16 Anni e Incinta, Scherzi e risate, Il Banco dei Pugni, People are Awesome, FailArmy, The Pet Collective, Just for Laughs

# Musica:
# Clubbing TV, Loupe

# Sport:
# Sport, IGN, World Poker Tour

# Bambini:
# Super! SpongeBob, Super! Spongebob+, Super! Eroi, Super! iCarly, Super! iCarly+, Super! Pop, Super! Pop+, Super! Star

# Documentari:
# Documentari, Natura

import uuid, requests, sys
from lib import logger, utils
from lib.broadcaster_result import BroadcasterResult

if utils.IsPY3:
    from urllib.parse import unquote
else:
    from urllib import unquote

HOST = "https://api.pluto.tv"
UUID = uuid.uuid1().hex


def play(search):
    res = BroadcasterResult()

    search = unquote(search)
    channelsUrl = "{}/v2/channels.json?deviceId={}".format(HOST, UUID)

    channels = {
        ch.get("slug"): ch.get("stitched", {}).get("urls", [{}])[0].get("url", "")
        for ch in requests.get(channelsUrl).json()
    }
    url = channels.get(search)

    if not url:
        channels = {
            ch.get("hash"): ch.get("stitched", {}).get("urls", [{}])[0].get("url", "")
            for ch in requests.get(channelsUrl).json()
        }
        url = channels.get(search.replace("$", "#"))

    if url:
        url = url.replace("deviceType=&", "deviceType=web&")
        url = url.replace("deviceMake=&", "deviceMake=firefox&")
        url = url.replace("deviceModel=&", "deviceModel=firefox&")
        url = url.replace("appName=&", "appName=web&")
        url = url.replace("sid=&", "sid={}&".format(UUID))

        res.Url = url
        res.ManifestType = "hls"

    return res
