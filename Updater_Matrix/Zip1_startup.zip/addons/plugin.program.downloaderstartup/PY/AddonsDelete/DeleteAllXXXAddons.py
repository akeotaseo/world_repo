import os, xbmc, xbmcvfs, xbmcgui, shutil, glob

base_path = xbmcvfs.translatePath('special://home/addons')

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.pantydropper"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "script.module.audrey"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

#dir_list = glob.iglob(os.path.join(base_path, "script.module.resolveurl.xxx"))
#for path in dir_list:
    #if os.path.isdir(path):
        #hutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.cumination"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.videodevil"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.empflix"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.fantasticc"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.jizzplanet"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.vilhaoxxx"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.area.69.k19"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.alix"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.pelotube"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.image.com.kindgirls"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.uiiumovies"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.adulthideout"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.blueballs"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.devilwolf19"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.adultseverywhere"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.choposex"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.pantydropper"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "script.module.audrey"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.sc19"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.cb19"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.cb20"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.co.bellesa.free"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.yourdaddy"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.com.pornky"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)


base_path = xbmcvfs.translatePath('special://home/userdata/addon_data')

#dir_list = glob.iglob(os.path.join(base_path, "plugin.video.tc"))
#for path in dir_list:
    #if os.path.isdir(path):
        #shutil.rmtree(path)

#base_path = xbmc.translatePath('special://home/addons')

#dir_list = glob.iglob(os.path.join(base_path, "script.tvaddons.debug.log"))
#for path in dir_list:
   # if os.path.isdir(path):
    #    shutil.rmtree(path)

#dialog = xbmcgui.Dialog()
#dialog.ok("[COLOR orange]World build[/COLOR]", "[COLOR white]Delete[/COLOR]")
#xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)')
xbmc.sleep(2000)
if os.path.exists(base_path): xbmcgui.Dialog().notification("[B][COLOR red]Delete[/COLOR] Adult Addons[/B]", "[COLOR white]Τα πρόσθετα [COLOR pink]XXX[/COLOR] αφαιρέθηκαν με επιτυχία![/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/clean.png')
xbmc.sleep(5000)
xbmcgui.Dialog().notification("[B][COLOR red]Ok[/COLOR][/B]", "[COLOR white]Αναμονή για Reload Profile...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/rp.png')
xbmc.sleep(5000)
xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)')
xbmc.sleep(5000)
xbmcgui.Dialog().notification("[B][COLOR orange]Reload Profile[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/reloadprofile.png')
