from codequick import Route, Listitem
from resources.lib.kedon import getlink, quangcao, ace
from datetime import datetime, timedelta, date
from bs4 import BeautifulSoup
@Route.register
def index_highlights365(plugin, **kwargs):
	yield []
	url = 'http://highlights365.com/broadcasts'
	resp = getlink(url, url, 1000)
	if (resp is not None):
		soup = BeautifulSoup(resp.content, 'html.parser')
		for episode in soup.select('div.broadcast-item'):
			linktrans = episode.select('div.team-info a')
			for linktran in linktrans:
				link = linktran['href']
				ten = linktran.get_text(strip=True)
			times = episode.select('div.time')
			for time in times:
				item = Listitem()
				timex = time.get_text(strip=True)
				if len(timex)==4:
					y = f'{date.today()}T0{timex}'
				else:
					y = f'{date.today()}T{timex}'
				tenm = f'{(datetime.fromisoformat(y) + timedelta(hours=7)).strftime("%H:%M")} {ten}'
				item.label = tenm
				item.art['thumb'] = item.art['fanart'] = f"https:{episode.select_one('div.c-flag img')['data-src']}"
				item.set_callback(laylink_highlights365, f'https://highlights365.com{link}', tenm)
				yield item
	else:
		yield quangcao()
@Route.register
def laylink_highlights365(plugin, url=None, ten=None, **kwargs):
	yield []
	if url is None or ten is None:
		pass
	else:
		resp = getlink(url, url, 1000)
		if (resp is not None) and ('acestream://' in resp.text):
			soup = BeautifulSoup(resp.content, 'html.parser')
			soups = soup.select('div.link-list.acestream a')
			for index, number in enumerate(soups):
				item = Listitem()
				item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/acestream.png'
				tenm = f'Link {index+1}-{ten}'
				item.label = tenm
				item.set_callback(ace(number['href'], tenm))
				yield item
		else:
			yield quangcao()