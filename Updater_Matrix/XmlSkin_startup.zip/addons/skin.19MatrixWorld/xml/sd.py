import xbmc, xbmcgui
xbmcgui.Dialog().ok('[B][COLOR silver]SportsDevil[/COLOR][/B]', 'Κατηγορίες απο το πρόσθετο [COLOR=silver]SportsDevil[/COLOR] 2024.04.28[CR](οι οποίες υπολειτουργούν... ή δεν λειτουργούν καθόλου)')

def sd():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13, click_14)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]       sd[/COLOR][/B]',
['[COLOR=orange]P2PStreams[/COLOR]',
 '[COLOR=tomato]VIPStand[/COLOR]',
 '[COLOR=darkorange]SportStream365[/COLOR]',
 '[COLOR=silver]MamaHD TV[/COLOR]',
 '[COLOR=firebrick]Worldstreams.net[/COLOR]',
 '[COLOR=royalblue]Cricfree.tv[/COLOR]',
 '[COLOR=teal]GolvarTV[/COLOR]',
 '[COLOR=slategray]DaddyLive[/COLOR]',
 '[COLOR=gray]TheTVApp[/COLOR]',
 '[COLOR=red]Live TV[/COLOR] [COLOR=blue]ru[/COLOR]',
 '[COLOR=orangered]RojaDirecta[/COLOR]',
 '[COLOR=white]LiveOn Sports[/COLOR]',
 '[COLOR=orange]Sport247.live[/COLOR]',
 '[B][COLOR green]Live Now                                                            --->[/COLOR][/B]'])


    if call:
        if call < 1:
            return
        func = funcs[call-14]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsdevil/?item=title%3dP2PStreams%26director%3dhttps%253A%252F%252Fp2pstreams.live%252F%26icon%3dC%253A%255CPortableApps%255Ckodi%255CMy%2bKODI%2b21%255CKodi%255Cportable_data%255Caddons%255Cplugin.video.sportsdevil%255Cresources%255Cimages%255Cp2p-streams.png%26url%3dlivesports%252Fp2pstreams.cfg%26type%3drss%26genre%3dLive%2bSports%26definedIn%3dlivesports.cfg&mode=1")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsdevil/?item=title%3dVIPStand%2b%26director%3dvipstand.pm%26icon%3dC%253A%255CPortableApps%255Ckodi%255CMy%2bKODI%2b21%255CKodi%255Cportable_data%255Caddons%255Cplugin.video.sd%255Cresources%255Cimages%255Cvipstand.png%26url%3dlivesports%252Fvipstand.cfg%26type%3drss%26genre%3dLive%2bSports%26definedIn%3dlivesports.cfg&mode=1")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsdevil/?item=title%3dSportStream365%26director%3dlivestream365%26icon%3dhttp%253A%252F%252Fcdns.livestreamapi.ru%252Fimg%252Flogo_ls365.png%26url%3dlivesports%252Fsportstream365_wss.cfg%26type%3drss%26genre%3dLive%2bSports%26definedIn%3dlivesports.cfg&mode=1")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsdevil/?item=title%3dMamaHD%2bTV%26director%3dmamahd.org%26icon%3dC%253A%255CPortableApps%255Ckodi%255CMy%2bKODI%2b21%255CKodi%255Cportable_data%255Caddons%255Cplugin.video.sportsdevil%255Cresources%255Cimages%255Cmamahd.png%26url%3dtv%252Fmamahdtv.cfg%26type%3drss%26genre%3dTV%26definedIn%3dtv.cfg&mode=1")')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsdevil/?item=title%3dWorldstreams.net%26director%3dworldstreams.net%26icon%3dhttps%253A%252F%252Fworldstreams.net%252Fassets%252Fimages%252Flogo.png%26url%3dtv%252Fworldstreams.cfg%26type%3drss%26genre%3dTV%26definedIn%3dtv.cfg&mode=1")')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsdevil/?item=title%3dCricfree.tv%26director%3dcricfree.tv%26icon%3dhttps%253A%252F%252Fcricfree.io%252Fassets%252Fimages%252Flogo.png%26url%3dtv%252Fcricfree.tv.cfg%26type%3drss%26genre%3dTV%26definedIn%3dtv.cfg&mode=1")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsdevil/?item=title%3dGolvarTV%26director%3dgolvar.xyz%26icon%3dhttps%253A%252F%252Fglvrtv.link%252Flogo.png%26url%3dtv%252Fgolvar.cfg%26type%3drss%26genre%3dTV%26definedIn%3dtv.cfg&mode=1")')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsdevil/?item=title%3dDaddyLive%26director%3ddaddylivehd.sx%26icon%3dhttps%253A%252F%252Fi.imgur.com%252F8EL6mr3.png%26url%3dlivesports%252Fdaddylive.cfg%26type%3drss%26genre%3dLive%2bSports%26definedIn%3dlivesports.cfg&mode=1")')
    
def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsdevil/?item=title%3dTheTVApp%26director%3dhttps%253A%252F%252Fthetvapp.to%252F%26icon%3dC%253A%255CPortableApps%255Ckodi%255CMy%2bKODI%2b21%255CKodi%255Cportable_data%255Caddons%255Cplugin.video.sportsdevil%255Cresources%255Cimages%255Cthetvapp.png%26url%3dcustoms%252Fthetvapp.cfg%26type%3drss%26genre%3dLive%2bTV%26definedIn%3dcustoms.cfg&mode=1")')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsdevil/?item=title%3dLiveTV.ru%26director%3dLiveTV.ru%26icon%3dC%253A%255CPortableApps%255Ckodi%255CMy%2bKODI%2b21%255CKodi%255Cportable_data%255Caddons%255Cplugin.video.sportsdevil%255Cresources%255Cimages%255Clivetv_ru.png%26url%3dlivesports%252Flivetv.ru.cfg%26type%3drss%26genre%3dLive%2bSports%26definedIn%3dlivesports.cfg&mode=1")')
    
def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsdevil/?item=title%3dRojaDirecta.me%26director%3dRojaDirecta.me%26icon%3dC%253A%255CPortableApps%255Ckodi%255CMy%2bKODI%2b21%255CKodi%255Cportable_data%255Caddons%255Cplugin.video.sportsdevil%255Cresources%255Cimages%255Croja.jpg%26url%3dlivesports%252Frojadirecta.me.cfg%26type%3drss%26genre%3dLive%2bSports%26definedIn%3dlivesports.cfg&mode=1")')

def click_12():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsdevil/?item=title%3d%255BCOLOR%253Dorange%255D%252A%252A%252ASchedule%252A%252A%252A%255B%252FCOLOR%255D%26type%3donce%26cfg%3dliveonsx.cfg%2540Schedule%26url%3dhttps%253A%252F%252Fonlive.sx%252Flist%26director%3dliveon.sx%26icon%3dC%253A%255CPortableApps%255Ckodi%255CMy%2bKODI%2b21%255CKodi%255Cportable_data%255Caddons%255Cplugin.video.sportsdevil%255Cresources%255Cimages%255Csportstv.png%26genre%3dTV%26definedIn%3dtv%252Fliveonsx.cfg&mode=1")')

def click_13():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsdevil/?item=title%3dSport247.live%26director%3dsport247.live%26icon%3dC%253A%255CPortableApps%255Ckodi%255CMy%2bKODI%2b21%255CKodi%255Cportable_data%255Caddons%255Cplugin.video.sportsdevil%255Cresources%255Cimages%255Csports365live.png%26url%3dlivesports%252Fss247.cfg%26type%3drss%26genre%3dLive%2bSports%26definedIn%3dlivesports.cfg&mode=1",return)')

def click_14():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/Live_Now.py")')


sd()
