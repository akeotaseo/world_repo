[![GitHub release](https://img.shields.io/github/release/eracknaphobia/plugin.video.nbcsnliveextra.svg)](https://github.com/eracknaphobia/plugin.video.nbcsnliveextra/releases)
![License](https://img.shields.io/badge/license-GPL%20(%3E%3D%202)-orange)
[![Contributors](https://img.shields.io/github/contributors/eracknaphobia/plugin.video.nbcsnliveextra.svg)](https://github.com/eracknaphobia/plugin.video.nbcsnliveextra/graphs/contributors)

plugin.video.nbcsnliveextra
======================

KODI plugin NBC Sports Live Extra

This plugin was built to watch** live and archive video of NBC Sports events 


Thread: http://forum.kodi.tv/showthread.php?tid=207159

** Most streams require a valid Cable / Satellite provider account to view
