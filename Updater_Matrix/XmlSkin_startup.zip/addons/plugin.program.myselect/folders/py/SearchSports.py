import xbmc, xbmcgui


def SearchSports():
    funcs = (click_1, click_2, click_3, click_4)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]       Search Sports...[/COLOR][/B]',
 ['[COLOR=white]Αναζήτηση Ζωντανών Αγώνων[/COLOR]',
  '[COLORyellow][B][I]>>>> Scraper Search >>>>[/I][/B][/COLOR]',
 'SEARCH EVENTS (daddylive)  ([COLOR red]OFF?...[/COLOR])',
 '[B][COLOR green]Live_Now[/COLOR][/B]'])

 #'[I][COLORlime] --- [COLORyellow] Search Scrapers [COLORlime] --- [/COLOR][/I] (torquelite)',

    if call:
        if call < 1:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/get_list/http://gknwizard.eu/repo/Builds/GKoBu/xmls/search_matches.json",return)')
    xbmcgui.Dialog().notification("[B][COLOR orange]Αναζήτηση Ζωντανών Αγώνων[/COLOR][/B]",'[COLOR white]Για ευκολία, πληκτρολογήστε NBA ή Basket ή FOOTBALL ή Soccer κ.τ.λ (πεζά ή κεφαλαία) και περιμένετε ...[/COLOR]' , icon ='special://home/addons/plugin.image.World/resources/media/addonset foto/sports-app.png')


def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/pvr_sport_search/search/*?include=7&orig=http%3a%2f%2fracingondemand.xyz%2fnoneofyourebusiness%2fjson%2flive%2fscraper.json")')


# def click_2():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.koditv/?extra=1&mode=mega_buscar&thumbnail=https%3a%2f%2fi.imgur.com%2fsLNFVk7.jpg&url")')


def click_3():
   xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/?mode=menu&serv_type=search")')

def click_4():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/Live_Now.py")')


SearchSports()
