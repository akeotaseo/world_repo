﻿import xbmc
#  Ηχητ. Ροή
def audioflow():
    if xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin("ActivateWindowAndFocus(osdaudiosettings)")
        xbmc.sleep(500)
        xbmc.executebuiltin('SendClick(-176)')
    while xbmc.getCondVisibility("Window.IsVisible(osdaudiosettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")



    if not xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin("ActivateWindowAndFocus(osdaudiosettings)")
        xbmc.executebuiltin("Action(Pause)")
        xbmc.sleep(500)
        xbmc.executebuiltin('SendClick(-176)')
    while xbmc.getCondVisibility("Window.IsVisible(osdaudiosettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")

audioflow()
