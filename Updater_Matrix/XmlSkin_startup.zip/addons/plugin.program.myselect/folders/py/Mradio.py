import xbmc, xbmcgui


def mradio():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10)
    call = xbmcgui.Dialog().select('[B][COLOR=orange] Music / Radio ~[/COLOR][/B]', 
['[B][COLOR=white]ROCK4U[/COLOR][/B] (Addon)',
 '[B][COLOR=white]Music Hall[/COLOR][/B] (Addon)',
 '[B][COLOR=white]Now Thats What I Call Music[/COLOR][/B] (Addon)',
 '[B][COLOR=white]Tube Music[/COLOR][/B] (Addon)',


 '[B][COLOR=white]YOUTUBE LISTS[/COLOR][/B]',
 '[B][COLOR=white]YOUTUBE LISTS RADIO[/COLOR][/B]',

 '[B][COLOR=white]MAD TV LIVE[/COLOR][/B]',


 '[B][COLOR=white]Relaxing Music[/COLOR][/B]',


 '[B][COLOR=white]Youtube radio live streams[/COLOR][/B]',

 '[B][COLOR=white]Ogdoo Music [/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-10]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.ROCK4U/?fanart=https%3a%2f%2fia801505.us.archive.org%2f32%2fitems%2ffanart_20200502%2ffanart.gif&mode=1&name=%20%5bCOLOR%20chartreuse%5d%5bB%5dVenha%20curtir%20os%20melhores%20shows%20de%20Rock%20e%20Metal%5b%2fB%5d%5b%2fCOLOR%5d%20%20%5bCOLOR%20darkred%5d%5bB%5dAQUI%20!%5b%2fB%5d%5b%2fCOLOR%5d&url=6148523063484D364C79397759584E305A574A706269356A62323076636D46334C304E4D636C6C5955573179")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.musichall/")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.now_music/",return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tubemusic/",return)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.youtube/kodion/search/query/?q=music&search_type=playlist)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.youtube/kodion/search/query/?event_type=live&q=radio&search_type=video)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/channel/UCs3cho4vcDuCze0tk3W9iVQ/")')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/kodion/search/query/?q=Relaxing%20Music")')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/kodion/search/query/?event_type=live&q=radio&search_type=video&sf_options=meta%3Dplot%253D%25255BB%25255D%2525CE%252596%2525CF%252589%2525CE%2525BD%2525CF%252584%2525CE%2525B1%2525CE%2525BD%2525CE%2525AC%25255B%25252FB%25255D%2526votes%253D0%2526label%253D%25255BB%25255D%2525CE%252596%2525CF%252589%2525CE%2525BD%2525CF%252584%2525CE%2525B1%2525CE%2525BD%2525CE%2525AC%25255B%25252FB%25255D%26desc%3D%5BB%5D%CE%96%CF%89%CE%BD%CF%84%CE%B1%CE%BD%CE%AC%5B%2FB%5D%26_options_sf")')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/channel/UC_9sM_ILdFeEWXCdRLUC-Pw/")')


mradio()
