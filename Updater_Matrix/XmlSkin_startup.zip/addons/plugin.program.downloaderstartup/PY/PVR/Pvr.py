import xbmc, xbmcgui


def pvr():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ PVR~[/COLOR][/B]', 
    

['1- [COLOR coral]Βοηθός ρύθμισης [COLOR blue]Stalker Client[/COLOR]',


 '[COLOR darkorchid]Επιλογή Γκρουπ[/COLOR]',

 '[COLOR=white][COLOR blue]Ρυθμίσεις Stalker[/COLOR] [/COLOR]',
  '[COLOR orange]Restart Pvr Stalker[/COLOR]', 


 '2- [COLOR lime]Stalker_portal[/COLOR] [B][COLOR deepskyblue]IPTV Links [COLOR lime] Online[/COLOR][/B]',
 '3- [COLOR lime]Αυτ/μένη αντικατάσταση πύλης Pvr Stalker[/COLOR] (Mac-Url)',



 'Ρυθμίσεις PVR',

 '[COLOR deepskyblue]Ιστότοποι Stalker[/COLOR]',

 'Καθαρισμός δεδομένων',

 '[COLOR blue]Ρυθμίσεις IPTV Simple Client[/COLOR]',
 '[COLOR lime]Install  last update [COLOR yellow]addon data [COLOR=blue]Pvr Stalker[/COLOR] / [COLOR blue]IPTV Simple Client[/COLOR]',
 'Πελάτες PVR'
  
 ],)


    if call:
        if call < 0:
            return
        func = funcs[call-12]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.downloader/stalkerindex/")')
    

def click_2():
    xbmc.executebuiltin('SendClick(28)')

def click_3():
    xbmc.executebuiltin('Addon.Opensettings(pvr.stalker)')

def click_4():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/DialogRestartPvrStalker.py")')

def click_5():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/Stalker_portal.py")')

def click_6():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/mac_list_0.py")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(pvrsettings)')

def click_8():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/Browser_Portal_Stalker.py")')

def click_9():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/clear_pvr_data.py")')

def click_10():
    xbmcgui.Dialog().ok('[B][COLOR cornflowerblue]PVR[/COLOR][/B]', 'Μετά απο οποιαδήποτε αλλαγή, πριν εισέλθετε στα ΚΑΝΑΛΙΑ.. δώστε χρόνο.. μεχρι να γίνει η φόρτωση (Καναλιών / Εισαγωγή οδηγού απο πελάτες)')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":true}}')
    xbmc.executebuiltin('Action(Back)')
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10000)')
    xbmc.executebuiltin('Addon.Opensettings(pvr.iptvsimple)')


def click_11():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/set_setting_PvrLast.py")')
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_5.py")')

def click_12():
    xbmc.executebuiltin('ActivateWindow(10040,"addons://user/kodi.pvrclient")')
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_5.py")')


pvr()
