﻿import xbmc, xbmcgui

def DialogDLbasket():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/?mode=showChannels&trType=Basketball")')
    xbmcgui.Dialog().notification("[B][COLOR red]Daddylive[/COLOR][/B]", "[COLOR orangered]BASKETBALL[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/DL.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR red]Daddylive[/COLOR][/B]", "[COLOR orangered]BASKETBALL[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/DL.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR red]Daddylive[/COLOR][/B]", "[COLOR orangered]BASKETBALL[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/DL.png')
DialogDLbasket()
