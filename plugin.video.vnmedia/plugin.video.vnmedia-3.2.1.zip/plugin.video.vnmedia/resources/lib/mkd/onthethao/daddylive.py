from codequick import Route, Listitem, Resolver
from resources.lib.kedon import getlink, quangcao
from bs4 import BeautifulSoup
from html import unescape
from urllib.parse import urlparse
from functools import lru_cache
from datetime import datetime, timedelta
from base64 import b64encode, b64decode
import re
@lru_cache(maxsize=None)
def convert_time_to_gmt_plus_7(time_str):
	try:
		time_obj = datetime.strptime(time_str, '%H:%M')
		gmt_plus_7_time_obj = time_obj + timedelta(seconds=21600)
		return gmt_plus_7_time_obj.strftime('%H:%M')
	except:
		return time_str
@Route.register
def index_daddy(plugin, **kwargs):
	yield []
	url = 'https://daddylivehd.sx/'
	resp = getlink(url, url, 1000)
	if (resp is not None):
		rt = resp.text
		if 'h2 style' in rt:
			matches = re.findall(r"<h2 style.*?>(.*?)</h2>(.*?)(?=<h2|$)", rt, re.DOTALL)
			for k in matches:
				if 'href' in k[1]:
					be = b64encode(k[1].encode('utf-8')).decode('utf-8')
					item = Listitem()
					item.label = k[0]
					item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/daddy-live-hd-channels-list.jpg'
					item.set_callback(list_daddy, be, url)
					yield item
		else:
			soup = BeautifulSoup(resp.content, 'html.parser')
			x = soup.select('a')[-1]['href']
			respx = getlink(x, x, 1000)
			rtx = respx.text
			if (respx is not None):
				matches = re.findall(r"<h2 style.*?>(.*?)</h2>(.*?)(?=<h2|$)", rtx, re.DOTALL)
				for k in matches:
					if 'href' in k[1]:
						be = b64encode(k[1].encode('utf-8')).decode('utf-8')
						item = Listitem()
						item.label = k[0]
						item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/daddy-live-hd-channels-list.jpg'
						item.set_callback(list_daddy, be, x)
						yield item
			else:
				yield quangcao()
	else:
		yield quangcao()
@Route.register
def list_daddy(plugin, textok=None, x=None, **kwargs):
	yield []
	if textok is None or x is None:
		pass
	else:
		g = b64decode(textok).decode('utf-8')
		matches = re.findall(r'(\d{2}:\d{2}) (.*?)<(.*?)(?=<hr|$)', g)
		for k in matches:
			tg = convert_time_to_gmt_plus_7(k[0])
			be = b64encode(k[2].encode('utf-8')).decode('utf-8')
			item = Listitem()
			tenm = unescape(f'{tg} {k[1]}')
			item.label = tenm
			item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/daddy-live-hd-channels-list.jpg'
			item.set_callback(channel_daddy, be, tenm, x)
			yield item
@Route.register
def channel_daddy(plugin, channelok=None, tentran=None, x=None, **kwargs):
	yield []
	if channelok is None or tentran is None or x is None:
		pass
	else:
		g = b64decode(channelok).decode('utf-8')
		urls = re.findall(r'href="(.*?)"(.*?)noopener">(.*?)<\/a', g)
		v = urlparse(x)
		for k in urls:
			item = Listitem()
			link = f'{v.scheme}://{v.netloc}{k[0]}' if k[0].startswith('/') else k[0]
			tenm = f'[COLOR yellow]{k[2]}[/COLOR] - {tentran}'
			item.label = tenm
			item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/daddy-live-hd-channels-list.jpg'
			item.set_callback(Resolver.ref('/resources/lib/kedon:ifr_bongda'), link, tenm)
			yield item