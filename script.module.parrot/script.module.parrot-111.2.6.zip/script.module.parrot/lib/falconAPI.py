from urllib.parse import urlencode
import random
import requests
import xbmcaddon
import os
import sys

class FalconAPI:
    def __init__(self) -> None:
        self._ADDON = xbmcaddon.Addon()
        self._FALCON_ADDON = xbmcaddon.Addon("plugin.video.parrottv")
        self.apis = {
            #"Falcon": "https://falconpanel.parrotdevelopers.repl.co/api/",
            "Falcon Load Balancer 1": "https://falconlb01.serverthreefour.repl.co/api/",
            "Falcon Load Balancer 2": "https://falconlb02.serverthreefour.repl.co/api/",
            "Falcon Load Balancer 3": 'https://falconlb03.serverfivesix.repl.co/api/',
            "Falcon Load Balancer 4": 'https://falconlb04.serverfivesix.repl.co/api/',
        }

        #statuses = requests.get("https://stats.uptimerobot.com/api/getMonitorList/XPP2xF48QP?page=1").json()["psp"]["monitors"]
        #working = []
        #for status in statuses:
        #    if status["statusClass"] != "success": continue
        #    if status["name"] not in self.apis: continue
        #    working.append(self.apis[status["name"]])

        #self.api = random.choice(working)
        self.api = random.choice(list(self.apis.values()))

        device = "Mozilla/5.0 (Unknown; Unknown)"
        if os.name == "nt":
            device = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
        elif sys.platform == "linux":
            device = "Mozilla/5.0 (X11; Linux x86_64)"
        elif sys.platform == "darwin":
            device = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)"

        self.userAgent = f"{device} FalconModule/{self._ADDON.getAddonInfo('version') or '0.0.0'} Falcon/{self._FALCON_ADDON.getAddonInfo('version') or '0.0.0'}"

    def createURL(self, dir, **kwargs):
        if len(kwargs) == 0: return f"{self.api}{dir}"
        return f"{self.api}{dir}?{urlencode(kwargs)}"
    