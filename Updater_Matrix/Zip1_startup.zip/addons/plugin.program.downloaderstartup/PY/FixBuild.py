﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def fixbuildin():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Επανέλεγχος ενημερώσεων του build[/COLOR]', 'Θέλετε να κάνετε επανέλεγχο για ενημερώσεις του build?[CR][COLOR blue]Με αυτή την επιλογή, θα εγκατασταθούν (ξανά) οι τελευταίες ενημερώσεις του build.[/COLOR]',
        
                                        nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR green]Επανέλεγχος[/COLOR][/B]')

        if choice == 1: [xbmcvfs.delete('special://home/addons/plugin.program.downloader19/downloader_startup.py'), 
                         xbmc.sleep(500),
                         xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/UpdaterMatrixDelete.py")'),
                         #xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/settings.xml'),
                         xbmc.sleep(1000),
                         
                         xbmcvfs.delete('special://home/addons/plugin.video.vnmedia/service.py'),
                         xbmc.sleep(1000),

                         xbmcgui.Dialog().notification("[B][COLOR orange]Επανέλεγχος...[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild.png'),
                         xbmc.sleep(4000),
                         xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/Database_Addons33.py'),
                         xbmc.sleep(500),
                         xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/addons_list_installation.py'),
                         xbmc.sleep(500),
                         xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/delete_files.py'),
                         xbmc.sleep(500),
                         xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/set_setting.py'),
                         xbmc.sleep(1000),

                         xbmcgui.Dialog().notification("[B][COLOR orange]Ok...[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloaderstartup/resources/media/FixBuild.png', sound=False),

                         xbmc.sleep(4000),
                         xbmcgui.Dialog().notification("[B][COLOR orange]Επανεκκίνηση World Updater Service[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/icon.gif', sound=False),
                         xbmc.sleep(4000),
                         xbmcgui.Dialog().notification("[B][COLOR orange]Επανεκκίνηση World Updater Service[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/icon.gif', sound=False),
                         xbmc.sleep(4000),
                         xbmc.executebuiltin('RunScript("special://home/userdata/addon_data/plugin.program.downloader19/set_setting_FixBuild.py")'),
                         xbmc.sleep(1000),
                         #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/service.py")'),
                         #xbmcgui.Dialog().notification("[B][COLOR orange]Διαγραφή με επιτυχία ![/COLOR][/B]", "[COLOR white]Αναμονή για Reload Profile...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/rp.png'),
                         #xbmc.sleep(1000),
                         #xbmc.executebuiltin('LoadProfile("Master user")'),
                         #xbmc.sleep(2000),
                         ]
                         
                         
fixbuildin()
