import requests, bs4, resolveurl
from resources.lib.browserHeaders import headers

server = "https://sbplay2.com/e/"

def urlfind(iframe_html):
    soup = bs4.BeautifulSoup(iframe_html, 'html.parser')
    links = soup.find_all('li', {'class': 'linkserver', 'data-status': '1'})
    for link in links:
        return server + link['data-video'].split('/e/')[1]


def grab(url):
    html = requests.get(url, headers=headers).text
    soup = bs4.BeautifulSoup(html, 'html.parser')
    iframe = soup.find('iframe')
    iframe_url = iframe['src'].replace("//", "https://")
    iframe_html = requests.get(iframe_url, headers=headers).text
    URLtoResolve = urlfind(iframe_html)
    print(URLtoResolve)
    resolved = ""
    if resolveurl.HostedMediaFile(URLtoResolve):
        resolved = resolveurl.resolve(URLtoResolve)
    return resolved
