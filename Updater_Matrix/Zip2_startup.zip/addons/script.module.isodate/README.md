# script.module.isodate

ISO 8601 date/time parser repacked for Kodi
- https://github.com/back-to/script.module.isodate

Based on isodate library for Python.
- https://github.com/gweis/isodate
- https://pypi.org/project/isodate/
