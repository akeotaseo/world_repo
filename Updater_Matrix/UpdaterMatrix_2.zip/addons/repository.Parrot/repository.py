# -*- coding: utf-8 -*-
# Author: Parrot Developers

import xbmc
import time
import xbmcaddon
import hashlib
try:
    from urllib.request import urlopen
except ImportError:
    from urllib2 import urlopen



if __name__ == '__main__':
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        _ADDON = xbmcaddon.Addon()
        if _ADDON.getSettingBool('informed') == False:
            _ADDON.openSettings()
            _ADDON.setSetting('informed', 'true')
            
        username = _ADDON.getSetting("username")
        password = _ADDON.getSetting("password")
        if username == "" or password == "":
            _ADDON.setSetting("verified", "false")
            time.sleep(1)
            continue
        hash = ""
        if password.startswith("HASH-"):
            hash = password[5:]
        else:
            hash = hashlib.sha512(hashlib.sha256(hashlib.md5(password.encode()).hexdigest().encode()).hexdigest().encode()).hexdigest()
        url = "https://Database.parrotdevelopers.repl.co/login?username={}&hash={}".format(username, hash)
        resp = urlopen(url).read().decode('utf-8')
        if resp == "True":
            _ADDON.setSetting("verified", "true")
            mins = 10
            time.sleep(mins * 60)
        else:
            _ADDON.setSetting("verified", "false")
            time.sleep(3)




