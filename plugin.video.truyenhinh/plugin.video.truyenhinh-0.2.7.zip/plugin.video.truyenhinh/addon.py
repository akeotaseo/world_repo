from urllib.parse import urlencode, parse_qsl, unquote, urlparse, quote_plus
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from xbmcvfs import translatePath
from pickle import load, dump
from htmlement import fromstring
import os, re, sys, xbmcgui, requests
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
PATH = Addon().getAddonInfo('path')
ICON = Addon().getAddonInfo('icon')
addon_id = Addon().getAddonInfo('id')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
bm = 'http://lite.baomoi.com/'
UA = 'OTT Navigator/1.7.3.1 (Linux; Android 16; Pixel 9 Pro Build/AP4A.251212) ExoPlayerLib/2.19.1'
UAM = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/605.1.15 Edg/140.0.0.0'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
sre1 = re.compile(r'\n((http|https|udp|rtp|acestream):(.*?)\n)')
sre2 = re.compile(r'[,](?!.*[,])(.*)')
sre3 = re.compile(r'group-title="(.*?)"')
sre4 = re.compile(r'tvg-logo="(.*?)"')
sre5 = re.compile(r'http-user-agent=(.*?)\n')
sre6 = re.compile(r'http-referrer=(.*?)\n')
sre7 = re.compile(r'license_key=(.*?)\n')
def addDir(title, logo, plot, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': logo, 'thumb': logo, 'poster': logo, 'fanart': logo})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(plot)
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref):
    r = requests.get(url, timeout=30, headers={'user-agent': UAM,'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def getlinkip(url, ref):
    r = requests.get(url, timeout=30, headers={'user-agent': UA,'accept-encoding':'gzip','referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}/'
def hlsvtv(idx):
    idp = re.sub(r'.*?vtv\.mediacdn\.vn/', 'https://cdn-videos.vtv.vn/', idx) if 'vtv.mediacdn.vn' in idx else idx
    return f'{idp}/master.m3u8'
def domhtml(root, xpath, attribute=None, default=None):
    element = root.find(xpath)
    return default if element is None else element.get(attribute, ' '.join(element.itertext()).strip())
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def find():
    addDir('Tìm kiếm', searchimg, 'Tìm kiếm', 'search')
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, searchimg, m, 'timvtv', p=1, key = m)
    endOfDirectory(HANDLE)
def timkiem(query, nextpage):
    search_query = quote_plus(query)
    next_page = int(nextpage)
    u = f'https://vtv.vn/timelinesearch/{next_page}.htm?type=2&keywords={search_query}&sort=0&time=0'
    resp = getlink(u, u).text
    root = fromstring(resp).iterfind('.//div[@class="box-category-item"]//a[@class="box-category-link-with-avatar img-resize"]')
    for k in root:
        logo = domhtml(k, './/img', attribute='src')
        title = k.get('title')
        idplay = k.get('href')
        addDir(title, logo, 'playvtv', url=idplay, is_folder=False)
    trang = str(next_page + 1)
    addDir(f'Trang {trang}', nextimg, trang, 'timvtv', p=trang, key=query)
    endOfDirectory(HANDLE)
def tinthethao():
    u = 'https://thethao.vtv.vn/timeline-detaivideo/trang-1.htm'
    resp = getlink(u, u).text
    root = fromstring(resp).iterfind('.//div[@class="box-category-item"]//a[@class="box-category-link-with-avatar img-resize"]')
    for k in root:
        logo = domhtml(k, './/img', attribute='src')
        title = k.get('title')
        idplay = k.get('href')
        linkplay = f"https://thethao.vtv.vn{idplay}" if idplay.startswith('/') else idplay
        addDir(title, logo, title, 'playvtv', url=linkplay, is_folder=False)
    endOfDirectory(HANDLE)
def baomoi(p, idbm=None):
    if idbm is None:
        resp = getlink(bm, bm).text
        idbm = re.search(r'buildId":"(.*?)"', resp)[1]
    next_page = int(p)
    url = f'{bm}_next/data/{idbm}/video.json' if next_page==1 else f'{bm}_next/data/{idbm}/video/{p}.json'
    kq = getlink(url, bm).json()['pageProps']['resp']['data']['content']['items']
    for k in kq:
        idp = k.get('id', '')
        name = k.get('title', '')
        mota = k.get('description', name)
        logo = k.get('thumbL', '')
        if name:
            addDir(name, logo, mota, 'index_bm', idp = idp, idbm=idbm)
    trang = str(next_page + 1)
    addDir(f'Trang {trang}', nextimg, trang, 'baomoi', p=trang , idbm=idbm)
    endOfDirectory(HANDLE)
def index_bm(idp, idbm):
    url = f'{bm}_next/data/{idbm}/content/detail/{idp}.json'
    kq = getlink(url, bm).json()['pageProps']['resp']['data']['content']
    getjs = kq['bodys']
    for i, k in enumerate(getjs):
        if k['type'] == 'video':
            link = k['content']
            logo = k['poster']
            try:
                name = re.sub(r'<[^>]+>', '', getjs[i + 1]['content'])
            except:
                description = kq['description']
                title = kq['title']
                name = description if description else title
            addDir(name, logo, name, 'play', id=link, is_folder=False)
    endOfDirectory(HANDLE)
def main():
    addDir('Tìm video', searchimg, 'Tìm video', 'timkiem')
    addDir('Giới thiệu', ICON, 'Giới thiệu', 'play', id='https://live.fptplay53.net/fnxhd2/f-channel1_vhls.smil/chunklist.m3u8', is_folder=False)
    addDir('Tin nóng', ICON, 'Tin nóng', 'baomoi', p=1)
    addDir('Tin mới', ICON, 'Tin mới', 'tinmoi_vtvvn', p=1)
    addDir('Tin thể thao', ICON, 'Tin thể thao', 'tinthethao')
    T = {'Truyền hình FPT': 'https://raw.githubusercontent.com/ntd249/ntdiptv/main/fptudp',
        'Cơ bản': 'https://tiny.cc/phaptx5',
        'VTV': 'https://kodi.ddns.vn/iptv/vtv.demo.txt',
        'VMTTV': 'https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/vmttv',
        'AlexDang 4K Sport': 'https://raw.githubusercontent.com/kgasaz/4kuhd/master/sports-channels-4k.m3u',
        'IPTV-ORG All': 'https://iptv-org.github.io/iptv/index.m3u',
        'IPTV-ORG Vietnam': 'https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/vn.m3u',
        'IPTV-ORG Category': 'https://iptv-org.github.io/iptv/index.category.m3u',
        'IPTV-ORG Language': 'https://iptv-org.github.io/iptv/index.language.m3u',
        'IPTV-ORG Country': 'https://iptv-org.github.io/iptv/index.country.m3u',
        'IPTV-ORG Region': 'https://iptv-org.github.io/iptv/index.region.m3u'
        }
    for k in T:
        addDir(k, ICON, k, 'list_iptv', id=T[k])
    endOfDirectory(HANDLE)
def search():
    query = xbmcgui.Dialog().input(u'Nhập từ khóa tìm kiếm ...', type=xbmcgui.INPUT_ALPHANUM)
    if query:
        search_history_save(query)
        timkiem(query, 1)
    else:
        find()
def tinmoi_vtvvn(p):
    next_page = int(p)
    url = f'https://vtv.vn/timelinevideo/new/{next_page}.htm'
    resp = getlink(url, url).text
    root = fromstring(resp).iterfind('.//div[@class="box-category-item"]//a[@class="box-category-link-with-avatar img-resize"]')
    for k in root:
        logo = domhtml(k, './/img', attribute='src')
        title = k.get('title')
        play = k.get('href')
        addDir(title, logo, title, 'playvtv', url=play, is_folder=False)
    trang = str(next_page + 1)
    addDir(f'Trang {trang}', nextimg, trang, 'tinmoi_vtvvn', p=trang)
    endOfDirectory(HANDLE)
def list_iptv(url):
    texturl = getlinkip(url, url).text
    group = re.findall(r'group-title="(.*?)"', texturl)
    if len(group) > 1:
        addDir('TẤT CẢ CÁC KÊNH', ICON, 'All', 'little_iptv', id=url)
        ld = list(dict.fromkeys(group))
        um = []
        um = [k for tk in ld for k in (tk.split(';') if ';' in tk else [tk]) if k != '' and k not in um]
        for p in um:
            addDir(p.strip(), ICON, p, 'info_iptv', id=url, tk=p)
    else:
        ketqua = re.sub(r'(#EXTM3U|#[^EX|^KODI])(.*)', '', texturl).split('#EXTINF')
        for kq in ketqua:
            s1 = sre1.search(kq)
            s2 = sre2.search(kq)
            s7 = sre7.search(kq)
            if s1 and s2 and not s7:
                s3 = sre3.search(kq)
                s4 = sre4.search(kq)
                s5 = sre5.search(kq)
                s6 = sre6.search(kq)
                nhomkenh = s3[1] if s3 else 'TỔNG HỢP'
                logo = s4[1] if s4 else ICON
                user = s5[1] if s5 else UA
                ref = s6[1] if s6 else ''
                tenm = f'{s2[1].strip()} - {nhomkenh}'
                addDir(tenm, logo, tenm, 'play', id=s1[1], ref=ref, user=user, is_folder=False)
    endOfDirectory(HANDLE)
def info_iptv(url, tk):
    texturl = getlinkip(url, url).text
    ketqua = re.sub(r'(#EXTM3U|#[^EX|^KODI])(.*)', '', texturl).split('#EXTINF')
    for kq in ketqua:
        s1 = sre1.search(kq)
        s2 = sre2.search(kq)
        s7 = sre7.search(kq)
        if s1 and s2 and any(((not s7 and f'group-title="{tk}"' in kq and ';' not in kq), (tk in kq and ';' in kq))):
            s4 = sre4.search(kq)
            s5 = sre5.search(kq)
            s6 = sre6.search(kq)
            logo = s4[1] if s4 else ICON
            user = s5[1] if s5 else UA
            ref = s6[1] if s6 else ''
            addDir(s2[1].strip(), logo, s2[1], 'play', id=s1[1], ref=ref, user=user, is_folder=False)
    endOfDirectory(HANDLE)
def little_iptv(url):
    texturl = getlinkip(url, url).text
    ketqua = re.sub(r'(#EXTM3U|#[^EX|^KODI])(.*)', '', texturl).split('#EXTINF')
    for kq in ketqua:
        s1 = sre1.search(kq)
        s2 = sre2.search(kq)
        s7 = sre7.search(kq)
        if s1 and s2 and not s7:
            s3 = sre3.search(kq)
            s4 = sre4.search(kq)
            s5 = sre5.search(kq)
            s6 = sre6.search(kq)
            nhomkenh = s3[1] if s3 else 'TỔNG HỢP'
            logo = s4[1] if s4 else ICON
            user = s5[1] if s5 else UA
            ref = s6[1] if s6 else ''
            tenm = f'{s2[1].strip()} - {nhomkenh}'
            addDir(tenm, logo, tenm, 'play', id=s1[1], ref=ref, user=user, is_folder=False)
    endOfDirectory(HANDLE)
def playvtv(u):
    url = f"https://vtv.vn/{u}" if u.startswith('/') else u
    resp = getlink(url, url).text
    vfile = hlsvtv(domhtml(fromstring(resp), './/div[@type="VideoStream"]', attribute='data-vid'))
    linkplay = re.sub(r'\s+', '%20', vfile.strip(), flags=re.UNICODE)
    hdr = f'verifypeer=false&User-Agent={UAM}&Referer=https://vtv.vn/'
    play_item = xbmcgui.ListItem(offscreen=True)
    play_item.setProperty('inputstream', 'inputstream.adaptive')
    play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
    play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def play(idp, ref=None, user=None):
    linkplay = re.sub(r'\s+', '%20', idp.strip(), flags=re.UNICODE)
    user = unquote(user)
    play_item = xbmcgui.ListItem(offscreen=True)
    if '.m3u8' in linkplay:
        hdr = f'verifypeer=false&User-Agent={user}'
        if ref:
            hdr += f'&Referer={referer(ref)}'
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
        play_item.setPath(linkplay)
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'search': search,
        'timkiem': find,
        'tinthethao': tinthethao,
        'baomoi': partial(baomoi, params.get('p'), params.get('idbm')),
        'timvtv': partial(timkiem, params.get('key'), params.get('p')),
        'index_bm': partial(index_bm, params.get('idp'), params.get('idbm')),
        'tinmoi_vtvvn': partial(tinmoi_vtvvn, params.get('p')),
        'list_iptv': partial(list_iptv, params.get('id')),
        'info_iptv': partial(info_iptv, params.get('id'), params.get('tk')),
        'little_iptv': partial(little_iptv, params.get('id')),
        'playvtv': partial(playvtv, params.get('url')),
        'play': partial(play, params.get('id'), params.get('ref'), params.get('user', UA))
    }
    action_map.get(params.get('mode'), main)()
try:
    router(sys.argv[2][1:])
except:
    pass