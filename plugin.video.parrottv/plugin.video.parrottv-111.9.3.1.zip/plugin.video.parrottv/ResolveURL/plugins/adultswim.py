# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

from ..utils.browser import Firefox
from ..utils.resolve import Resolver

class AdultSwim(Resolver):
    def __init__(self):
        pass

    def grab(self, channel):
        firefox = Firefox()
        firefox.addHeader("Referer", "https://www.adultswim.com/")
        return f"https://adultswim-vodlive.cdn.turner.com/live/{channel}/stream.m3u8", firefox.headers