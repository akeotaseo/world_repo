﻿from updatervar import *

dialog.notification('Εγκατάσταση αρχείων...', 'Αναμονή για ολοκλήρωση', icon_install, sound=False)
xbmc.sleep(500) 

addons_list_installation = ['repository.test', 'service.subtitles.opensubtitles-com', 'service.subtitles.subscene', 'plugin.program.myselect', 'repository.cocoscrapers', 'repository.jellyfin.kodi','repository.alado.tv', 'repository.zeltorix', 'repository.test2']


def check_addons_list():
    for addons_list in addons_list_installation:
        if not exists(addons_path + '%s' % addons_list):
            xbmc.sleep(1000)
            installAddon()


def installAddon():
    for addon_id in addons_list_installation:
      xbmc.executebuiltin('InstallAddon(%s)' % (addon_id))
      xbmc.sleep(100)
      xbmc.executebuiltin('SendClick(11)')
      xbmc.sleep(100)

check_addons_list()
