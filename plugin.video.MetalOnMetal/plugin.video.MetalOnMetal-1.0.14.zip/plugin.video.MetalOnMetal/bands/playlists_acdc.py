import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_bands

setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="


arrayMenu = ([
            [ "AC/DC Vevo Videos",          "PL_naYG4q-3ksJEpXoDBfzWU3nngCiYMhn"],  
            [ "Remembering Bon Scott",  "PL_naYG4q-3ksaytJF94t44o5BA7Owe-1r"],
            [ "Official Videos",  "PLJm4EXci-OQ76YCyQcRJLCZo2hwMxG_Do"],
            [ "DVD's Family Jewels",  "PL7OxlLDVkISUOTMnq8JvaI36WH5H5AMjD"],
            [ "1970's Live",  "PLx1MDbsLNfVQ_4kbSQ2qP7Kh-BfpWZEzE"],          
            [ "1980's Live",  "PLx1MDbsLNfVSSPAtSnfc7FR9A9M3mJQHt"],   
            [ "1990's Live",  "PLx1MDbsLNfVS5qi1DdTW1Mi3Yizqqn5gk"],          
            [ "2000's Live",  "PLx1MDbsLNfVQfLBqmbxjsYJG3j_B3TkCp"],   
            [ "1970's Videos",  "PLx1MDbsLNfVT3EgqkKI8BCRFMcBfKihHt"],          
            [ "1980's Videos",  "PLx1MDbsLNfVQMR8ocCtX02ZMDEb13Q840"],          
            [ "1990's Videos",  "PLx1MDbsLNfVRXR1AdmqItdcX4dfqIQAxs"],          
            [ "2000's Videos",  "PLx1MDbsLNfVQjZ5b4r_28Wb9EhrEYNH2U"], 
            [ "1991 - Live Donington - HD",  "PLatZaR-LgI2a5jLdRRifKT3TLMYQu8uYh"],       
            [ "1996 - No Bull - Live Madrid Las Ventas",  "PLwItFtSCuSo6Rj2uqUp0TC43N5G1A4gqN"],   
            [ "2009 - Live At River Plate",  "PL_naYG4q-3kslMKHDhQhcJM17p0HhZP-d"],
            [ "Live shows","PLGuhlLazJwGvlGz9LEsoAelTAswFts2gG"]])
def playlists(params):
    logo=logos_bands.acdc(params)

    for i in range(len(arrayMenu)):
        titulo = arrayMenu[i][0]
        id_canal = arrayMenu[i][1]
        if usa_duffyou:  ##Usamos plugin Duff You
            reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_canal)
            videos = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        else:  ##Usamos plugin YouTube
            videos = youtube.replace("MI-ID-PLAYLIST" , id_canal)
        
        plugintools.add_item( 
            title=titulo,
            url=videos,
            thumbnail=logo, folder=True )





