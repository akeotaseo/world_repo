import os, xbmcgui

def ErtflixYesNo():
        choice = xbmcgui.Dialog().yesno('[B][COLOR=blue]ERT[/COLOR][COLOR=red]FLIX[/COLOR][/B]', '[COLOR white]Πατήστε [COLOR=blue]ERT[/COLOR][COLOR=red]FLIX[/COLOR] για να μεταφερθείτε στο site https://www.ertflix.gr/[/COLOR]',
                                        nolabel='[COLOR white]Όχι τώρα[/COLOR]',yeslabel='[COLOR=blue]ERT[/COLOR][COLOR=red]FLIX[/COLOR]')
        if choice == 1: xbmc.executebuiltin('RunScript("special://home/addons/skin.19MatrixWorld/xml/DialogContextPair/Ertflix.py")')

ErtflixYesNo()