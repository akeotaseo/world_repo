# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
MYVIDEOLINKS = control.setting('myvideolinks') or 'https://go2.myvideolinks.net/'


def myvideolinks(url): #102
    hdrs = {'Referer': MYVIDEOLINKS,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    try:
        m = re.compile('<h2 class="entry-title" itemprop="headline" ><a href="(.+?)">(.+?)</a></h2>.+?<img src="(.+?)"', re.DOTALL).findall(p)
    except IndexError:
        m = re.compile('<h2 class="entry-title" itemprop="headline" ><a href="(.+?)">(.+?)</a></h2>', re.DOTALL).findall(p)
    for url, name, icon in m:
        name = clear_Title(name)
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 103, icon , FANART, '')
    try:
        m = re.compile('<a class="nextpostslink" rel="next" href="(.+?)">').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 102, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass


def get_links(name, url, iconimage, description): #103
    hdrs = {'Referer': MYVIDEOLINKS,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m2 = re.compile('<a href="(.+?)">').findall(p)
    for url in m2:
        if 'youtube' in url:
            Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
            addDir(Trailer, url, 100, ART + 'youtube.png', FANART, str(description))
    else:
        m = re.compile('<li><a href="(.+?)" class="autohyperlink" target="_blank">(.+?)</a></li>').findall(p)
        t =  re.compile('<h4>(.+?)</h4>').findall(p)
        for url, link in m:
            for name in t:
                name = clear_Title(name)
                if 'mixdrop' in url:
                    addDir(name, url, 100, iconimage, FANART, str(description))
                elif 'userload' in url:
                    addDir(name, url, 100, iconimage, FANART, str(description))
                else:
                     continue


def get_links1(name, url, iconimage, description): #88
    hdrs = {'Referer': MYVIDEOLINKS,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m2 = re.compile('<a href="(.+?)">').findall(p)
    for url in m2:
        if 'youtube' in url:
            Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
            addDir(Trailer, url, 100, ART + 'youtube.png', FANART, str(description))
    else:
        m = re.compile('<li><a href="(.+?)" class="autohyperlink" target="_blank">').findall(p)
        for url in m:
    #        name = url
            if 'mixdrop' in url:
                link = '[B][COLOR=lime]Mixdrop[COLOR=white] | [/COLOR][/B]'
                addDir((link + name), url, 100, iconimage, FANART, str(description))
            elif 'userload' in url:
                link = '[B][COLOR=lime]Userload[COLOR=white] | [/COLOR][/B]'
                addDir((link + name), url, 100, iconimage, FANART, str(description))


def search(url): #101
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = 'https://go2.myvideolinks.net/?s=' + search
        myvideolinks(url)

def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    return txt
