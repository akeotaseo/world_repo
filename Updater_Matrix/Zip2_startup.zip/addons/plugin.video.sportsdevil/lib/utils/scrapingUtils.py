# -*- coding: utf-8 -*-


from . import regexUtils
import re
import urllib.parse as urllib
import urllib.parse as urlparse


def findJS(data):
    idName = r'(?:f*id|ch)'
    jsName = r'([^\"\']+?\.js[^\"\']*?)'
    regex = r"(?:java)?scr(?:'\+')?ipt.*?" + idName + r"\s*=\s*[\"']([^\"']+)[\"'][^<]*</scr(?:'\+')?ipt\s*>[^<]*<scr(?:'\+')?ipt[^<]*src=[\"']" + jsName + r"[\"']"
    
    jscript = regexUtils.findall(data, regex)
    if jscript:
        jscript = filter(lambda x: x[1].find('twitter') == -1, jscript)
        jscript = filter(lambda x: x[1].find('pushpublish') == -1, jscript)
        jscript = filter(lambda x: x[1].find('intercept') == -1, jscript)
        return list(jscript)
    
    return None


def findPHP(data, streamId):
    regex = r"document.write\('.*?src=['\"]*(.*?.(?:php|html)[^&\"]*).*?['\" ]*.*?\)"
    try:
        php = regexUtils.findall(data, regex)
        if php:
            return re.sub(r"\'\+\s*(?:[fc]*id|ch)\s*\+\'", "%s" % streamId, php[0])
        
        regex = "document.write\('.*?src=['\"]*(.*?(?:f*id|ch)\s*\+'\.html*).*?['\" ]*.*?\)"
        html = regexUtils.findall(data, regex)
        if html:
            return re.sub(r"\'\+\s*(?:f*id|ch)\s*\+\'", "%s" % streamId, html[0])
        
        regex = "document.write\('.*?src=\"(.*?(?:f*id|ch)[^\"]+)\".*?['\" ]*.*?\)"
        html = regexUtils.findall(data, regex)
        if html:
            return re.sub(r"\'\+\s*(?:f*id|ch)\s*\+\'", "%s" % streamId, html[0])
        
    except:
        pass
    
    return None

def findRTMP(url, data):
    #if data.lower().find('rtmp') == -1:
    #    return None
    try:
        text = str(data)
    except:
        text = data
    
    #method 1
    #["'=](http://[^'" ]*.swf[^'" ]*file=([^&"']+)[^'" ]*&streamer=([^"'&]+))
    #streamer=([^&"]+).*?file=([^&"]+).*?src="([^"]+.swf)"
    
    # method 2
    #"([^"]+.swf\?.*?file=(rtmp[^&]+)&.*?id=([^&"]+)[^"]*)"

    sep1 = '[\'"&\? ]'
    sep2 = '(?:[\'"]\s*(?:,|\:)\s*[\'"]|=)'
    value = '([^\'"&]+)'


    method1 = True
    method2 = False
    radius = 400

    playpath = ''
    swfUrl = ''

    rtmp = regexUtils.findall(text, sep1 + 'streamer' + sep2 + value)
    if not rtmp:
        tryMethod2 = regexUtils.findall(text, sep1 + 'file' + sep2 + value)
        if tryMethod2 and tryMethod2[0].startswith('rtmp'):
            method1 = False
            method2 = True
            rtmp = tryMethod2
            
    if rtmp:
        for r in rtmp:
            
            tmpRtmp = r.replace('/&','').replace('&','')
                        
            idx = text.find(tmpRtmp)
            
            min_idx = 0
            max_idx = len(text) - 1
            
            start = idx-radius
            if start < min_idx:
                start = min_idx
                
            end = idx+radius
            if end > max_idx:
                end = max_idx
            
            area = text[start:end]
            
            clipStart = idx+len(tmpRtmp)
            if clipStart < max_idx:
                text = text[clipStart:]
            if method1:
                playpath = regexUtils.findall(area, sep1 + 'file' + sep2 + value)
            if method2:
                playpath = regexUtils.findall(area, sep1 + 'id' + sep2 + value)
                if playpath:
                    tmpRtmp = tmpRtmp + '/' + playpath[0]
            
            if playpath:
                swfUrl = regexUtils.findall(area, 'SWFObject\([\'"]([^\'"]+)[\'"]')
                if not swfUrl:
                    swfUrl = regexUtils.findall(area, sep1 + '([^\'"& ]+\.swf)')
                    if not swfUrl:
                        swfUrl = regexUtils.findall(data, sep1 + '([^\'"& ]+\.swf)')

                if swfUrl:
                    finalSwfUrl = swfUrl[0]
                    if not finalSwfUrl.startswith('http'):
                        finalSwfUrl = urlparse.urljoin(url, finalSwfUrl)
                    
                    regex = '://(.*?)/'
                    server = regexUtils.findall(tmpRtmp, regex)
                    if server:
                        if server[0].find(':') == -1:
                            tmpRtmp = tmpRtmp.replace(server[0], server[0] + ':1935')
                    
                    return [tmpRtmp, playpath[0], finalSwfUrl]
    
    return None


def getHostName(url):
    scheme = urlparse.urlparse(url)
    if scheme:
        return scheme.netloc.replace('www.','')
    return None


def findFrames(data):
    if data.lower().find('frame') == -1:
        return None
    return regexUtils.findall(data, "((?:frame|FRAME)[^>]*)>")


def findContentRefreshLink(page, data):
    
    regex = '0;\s*url=((?![^\'" ]+rojadirecta)[^\'" ]+)'
    links = regexUtils.findall(data, regex)
    if links:
        return links[0]
    
    regex = 'window\.location(?:\.href)?\s*=\s*[\'"](http(?![^\'" ]+creditcardpay|[^\'" ]+streamlive.to\/premium)[^\'"]+)[\'"]'
    links = regexUtils.findall(data, regex)
    if links:
        return links[0]
    
    regex = 'frame\s*scrolling=\"auto\"\s*noresize\s*src\s*=\s*[\'"]([^\'"]+)[\'"]'
    links = regexUtils.findall(data, regex)
    if links:
        return links[0]
    
    #hd**ee.fv/cr**hd.fv/sp**ts4u.tv
    regex = '<a\s*href="((?![^"]+HDlivestream)[^"]+)"\s*target="_blank"><img\s*(?:src="[^"]+"\s*height="\d+"\s*width="\d+"\s*longdesc="[^"]+"|class="alignnone"\s*src="[^"]*"\s*alt="[^"]*"\s*width="\d\d\d"\s*height="\d\d\d")'
    links = regexUtils.findall(data, regex)
    if links:
        return urlparse.urljoin(urllib.unquote(page), links[0]).strip()
    
    #cr**hd.com
    regex = '<a\s*href="([^"]+)"\s*title="[^"]*"><img\s*(?:src="[^"]+"\s*height="\d+"\s*width="\d+"\s*longdesc="[^"]+"|class="aligncenter"\s*alt="[^"]*"\s*title="[^"]*"\s*src="[^"]*"\s*width="\d\d\d"\s*height="\d\d\d")'
    links = regexUtils.findall(data, regex)
    if links:
        return urlparse.urljoin(urllib.unquote(page), links[0]).strip()
    
    #spo***live.com
    regex = '<a\s*href="([^"]+)"\s*title=""><img\s*data-scalestrategy="crop"\s*width="\d\d\d"\s*height="\d\d\d"'
    links = regexUtils.findall(data, regex)
    if links:
        return urlparse.urljoin(urllib.unquote(page), links[0]).strip()

    return None


def findEmbedPHPLink(data):
    regex = '<script\s+(?:type="text/javascript"\s+)?src="((?![^"]+localtimes)(?![^"]+bodelen\.com)(?![^"]+adcash)(?![^"]+ajax-poll)[^"]+\.php\?[^"]+)"\s*>\s*</script>'

    links = regexUtils.findall(data, regex)
    if links:
        return links[0]

    return None


def findVideoFrameLink(page, data):
    # print('[SportsDevil] %s' % repr(data))
    minheight = 300
    minwidth = 300

    #clean html and js comments
    regex = r"^\s*<!--[\s\S]*?-->|<!--[\s\S]*?-->|\/\*[\s\S]*?\*\/|^\s*\/\/.*$"
    data = re.sub(regex, '', data, 0, re.M)

    frames = findFrames(data)
    if not frames:
        return None
    
    # viewhd.me
    iframes = regexUtils.findall(data, r'iframe\s+name="\w+"\s+src="([^"]+)"\s+frameborder="0"\s+scrolling="no"\s+allowfullscreen>')
    if iframes:
        return urlparse.urljoin(urllib.unquote(page), iframes[0]).strip()

    # sebn
    iframes = regexUtils.findall(data, r'<iframe\s+class=".*?"\s+src="([^"]+)"\s+allowfullscreen=true\s+frameBorder="0"\s+scrolling="no">')
    if iframes:
        return urlparse.urljoin(urllib.unquote(page), iframes[0]).strip()

    # joker
    m = regexUtils.findall(data, r'div\s+id=[\'"]player["\'].*?<iframe.*?src=[\'"]?(?![^>]*ads\d*\.\w+)(?![^>]*blogspot)(?![^>]*widgets)(?![^>]*shop)(?![^>]*embed)([^\s>\'"]+)')
    if m:
        return urlparse.urljoin(urllib.unquote(page), m[0]).strip()

    m = regexUtils.findall(data, r'<iframe.*?src="https?:\/\/jokerstream.uk\/.*?\.php\?id=([^"]+)')
    if m:
        return urlparse.urljoin(urllib.unquote(page), m[0]).strip()

    m = regexUtils.findall(data, r'<iframe.*?src="https?:\/\/freecricstream.com\/.*?\.php\?id=([^"]+)')
    if m:
        return urlparse.urljoin(urllib.unquote(page), m[0]).strip()
    
    # tgotv
    m = regexUtils.findall(data, r'<iframe.*?src="https:\/\/em\.tgo-tv\.co\/player\/frame\.php\?([^"]+)')
    if m:
        return urlparse.urljoin("" if "https:" in m[0] else "https:", m[0]).strip()

    m = regexUtils.findall(data, r'<iframe.*?src=".*?\/\/extrafreetv\.com\/player\/frame\.php\?([^"]+)')
    if m:
        return urlparse.urljoin("" if "https:" in m[0] else "https:", m[0]).strip()

    # m = regexUtils.findall(data, r'<iframe.*?src="https:\/\/sportkart1\.xyz\/tv\/scplayer-\'\+channel\+\'\.php')
    # if m:
    #     channel = regexUtils.findall(page, r'scplayer.php\?([\d]+)')[0]
    #     return "https://sportkart1.xyz/tv/scplayer-{}.php".format(channel)
    
    m = regexUtils.findall(data, r'<iframe.*?src="https:\/\/extrafreetv\.com\/embed\/(channel|em)\.php\?\'\+channel\+\'')
    if m:
        channel = regexUtils.findall(page, r'channels.php\?([\d]+)')[0]
        return "https://extrafreetv.com/embed/{}.php?{}".format(m[0], channel)
    
    # m = regexUtils.findall(data, r'<iframe.*?src="https:\/\/livetvon\.click\/embed\/stream-\'\+channel\+\'\.php')
    m = regexUtils.findall(data, r'<iframe.*?src="(https:.*?)\'\+channel\+\'\.php')
    if m:
        try:
            channel = regexUtils.findall(page, r'(?:channel|live|player|scplayer|em)\.php\?([\d]+)')[0]
        except:
            channel = regexUtils.findall(page, r'\/([\d]+)\.php')[0]
        #return "https://livetvon.click/embed/stream-{}.php".format(channel)
        return "{}{}.php".format(m[0], channel)
    
    m = regexUtils.findall(data, r'<iframe.*?src="(https:.*?\.php\?id=)\'\+channel\+\'')
    if m:
        try:
            channel = regexUtils.findall(page, r'(?:channel|live|player|scplayer|em)\.php\?([\d]+)')[0]
        except:
            channel = regexUtils.findall(page, r'\/([\d]+)\.php')[0]
        return "{}{}".format(m[0], channel)

    
    # m = regexUtils.findall(data, r'<iframe.*?src="https:\/\/livetvon\.click\/embed\/stream-\'\+channel\+\'\.php')
    # if m:
    #     channel = regexUtils.findall(page, r'\/([\d]+)\.php')[0]
    #     return "https://livetvon.click/embed/stream-{}.php".format(channel)

    ### Main redirects

    iframes = regexUtils.findallIgnoreCase(data, "(frame(?!border)(?![^>]*blogspot|[^>]*cbox\.ws|[^>]*publi|[^>]*creditcardpay|[^>]*dailymotion|[^>]*adsplus|[^>]*popunder\.bid|[^>]*guide\.|[^>]*chat\d*\.\w+|[^>]*\/chat\/|[^>]*ad122m|[^>]*adshell|[^>]*capacanal|[^>]*waframedia|[^>]*banner|[^>]*maxtags|[^>]*s\/a1\.php|[^>]*ads\.\w+|[^>]*adca.php|[^>]*\/ad\"\+|[^>]*right-sidebar)[^>]*\s(?:height|HEIGHT)\s*=\s*[\"']*([\%\d]+)(?:px)?[\"']*[^>]*>)")
    if iframes:
        for iframe in iframes:            
            if iframe[1] == '100%' or iframe[1] == '90%' or iframe[1] == '80%':
                height = minheight + 1
            else:
                height = int(iframe[1])
            if height > minheight:
                m = regexUtils.findall(iframe[0], "[\"'\s](?:width|WIDTH)\s*=\s*[\"']*(\d+[%]*)(?:px)?[\"']*")
                if m:
                    if m[0] == '100%' or m[0] == '90%' or m[0] == '80%':
                        width = minwidth + 1
                    else:
                        width = int(m[0])
                    #print('width', width)
                    
                    if width > minwidth:
                        m = regexUtils.findall(iframe[0], '[\'"\s]+(?:src|SRC)\s*=\s*["\']*\s*([^>"\' ]+)\s*[>"\']*')
                        
                        if m:
                            if 'premiertv' in page:
                                page = page + '/'
                            if 'stream365.xyz' in page and '?id=http' in m[0]:
                                return m[0].split('?id=')[1]
                            if re.search(r'getParameterByName\([\"\']id[\'\"]\)', data) and m[0].endswith("?id="):
                                m[0] += page.split('?id=')[1]
                            return urlparse.urljoin(urllib.unquote(page), m[0]).strip()


    # Alternative 1
    iframes = regexUtils.findall(data, "(frame(?![^>]*cbox\.ws|[^>]*capacanal|[^>]*ads\.\w+|[^>]*chat[\?\.]\w+|[^>]*creditcardpay|[^>]*dailymotion)[^>]*[\"; ]height\d?:\s*(\d+)[^>]*>)")
    
    if iframes:
        for iframe in iframes:
            height = int(iframe[1])
            if height > minheight or "height:100%" in iframe[0]:
                m = regexUtils.findall(iframe[0], "[\"\';\s]width\d?:\s*(\d+)")
                if m:
                    width = int(m[0])
                    if width > minwidth or "width:100%" in iframe[0]:
                        m = regexUtils.findall(iframe[0], '[\"\';\s](?:src|SRC)=["\']*\s*([^>"\'\s]+)\s*[>"\']*')
                        if m:
                            return urlparse.urljoin(urllib.unquote(page), m[0]).strip()

    # Alternative 2 (no height)
    iframes = regexUtils.findall(data, "(frame(?![^>]*cbox\.ws|[^>]*capacanal|[^>]*ads\.\w+|[^>]*chat[\?\.]\w+|[^>]*creditcardpay|[^>]*dailymotion)[^>]*[\"; ]width:\s*(\d+)[^>]*>)")
    if iframes:
        for iframe in iframes:
            width = int(iframe[1])
            if width > minwidth or "width:100%" in iframe[0]:
                m = regexUtils.findall(iframe[0], '[\"\'; ](?:src|SRC)=["\']*\s*([^>"\' ]+)\s*[>"\']*')
                if m:
                    return urlparse.urljoin(urllib.unquote(page), m[0]).strip()

    # Alternative 3 (Frameset)
    m = regexUtils.findall(data, '<(?:FRAMESET|frameset)[^>]+100%[^>]+>\s*<(?:FRAME|frame)[^>]+src="([^"]+)"')
    if m:
        return urlparse.urljoin(urllib.unquote(page), m[0]).strip()
    
    m = regexUtils.findall(data, r'playStream\(\'iframe\',\s*\'[^\']*(https*:[^\']+)\'\)')
    if m:
        return urlparse.urljoin(urllib.unquote(page), m[0]).strip()

    #sportsh**tv
    m = regexUtils.findall(data, r'<iframe.*?src="(.*?stream[^"]+)"\s*allowfullscreen>')
    if m:
        return urlparse.urljoin(urllib.unquote(page), m[0]).strip()

    #stre***d
    m = regexUtils.findall(data, r'<iframe\s*class="embed[^"]+"\s*name="video[^"]+"\s*src="([^"]+)"')
    if m:
        return urlparse.urljoin(urllib.unquote(page), m[0]).strip()

    #telelatino
    m = regexUtils.findall(data, r'<iframe\s*class="embed.*?src="(https.*?telelatinohd.*?)"')
    if m:
        return urlparse.urljoin(urllib.unquote(page), m[0]).strip()
    
    #totalsport
    m = regexUtils.findall(data, r'<iframe\s+allowFullScreen="true"\s+align="center".*?src="(https://totalsport[^"]+)')
    if m:
        return urlparse.urljoin(urllib.unquote(page), m[0]).strip()

    #cablegratis
    if 'cablegratis' in page:
        m = regexUtils.findall(data, r'onclick="setURL\(\'([^\']+)')
        if m:
            return urlparse.urljoin(urllib.unquote(page), m[0]).strip()

    return None
