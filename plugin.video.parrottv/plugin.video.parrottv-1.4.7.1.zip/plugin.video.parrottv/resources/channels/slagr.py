# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

class Slagr:
    def __init__(self):
        self.ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36'
        self.channels = {
            'slagr': 'https://stream-6.mazana.tv/slagr.m3u',
            'slagr2': 'https://stream-33.mazana.tv/slagr2.m3u',
            'premium': 'https://arenasportslovakia.ddns.net/hls/slager.m3u8'
        }

    def grab(self, channel):
        headers = {'User-Agent': self.ua}
        hlsurl = self.channels[channel]
        return hlsurl, headers