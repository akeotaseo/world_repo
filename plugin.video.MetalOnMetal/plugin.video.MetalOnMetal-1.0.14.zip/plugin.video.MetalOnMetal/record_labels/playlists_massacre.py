import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_labels


setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="

arrayMenu = ([
            [ "Official Videos", "PLwnziV82UWav--o9BD2BP-kOuB1Aelutd"],           
            [ "Singles", "PLwnziV82UWav2UQs5EIG8iKnO5-ZIC8mG"],     
            [ "The Best Of Massacre Records", "PLwnziV82UWauKeCABMeNN7SjjMgAuKju_"],           
            [ "Lyric Videos", "PLwnziV82UWasZt75LNkqhyALv4jd7tIhk"],           
            [ "Hard Rock", "PLwnziV82UWauH3g41vOUlmP_hOTG2AsBT"],           
            [ "Heavy Metal", "PLwnziV82UWaszlTDt0LJLSvibd2gGGENZ"],           
            [ "Power Metal", "PLwnziV82UWauwbcg4tvS35xB53cZCNV7o"],           
            [ "Gothic Metal", "PLwnziV82UWavBHYof1SCaXGtE4WsUDt5y"],           
            [ "Symphonic Metal", "PLwnziV82UWastchJTfonqmN6ka4CH76Jv"],  
            [ "Female Fronted Metal", "PLwnziV82UWasZT_GqxpqRVqXraqrylA13"],           
            [ "Progressive Metal", "PLwnziV82UWaupOrk4Ql2JmuMdnmoSzZbU"],           
            [ "Melodic Metal", "PLwnziV82UWatvtxG7ig1X7U2fsFwVPwDl"],           
            [ "Thrash Metal", "PLwnziV82UWauglqetlLk4VIyrbIa26mOc"],           
            [ "Death Metal", "PLwnziV82UWavJ2T928vXjAFLHw6gJKf4H"],           
            [ "Doom Metal", "PLwnziV82UWat3FEzBnyEK4Oe3feb7mjV_"],           
            [ "Full Albums", "PLwnziV82UWavUPnbtMsv7oQwZtfq63weG"]])

def playlists(params):
    logo=logos_labels.massacre(params)

    for i in range(len(arrayMenu)):
        titulo = arrayMenu[i][0]
        id_canal = arrayMenu[i][1]
        if usa_duffyou:  ##Usamos plugin Duff You
            reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_canal)
            videos = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        else:  ##Usamos plugin YouTube
            videos = youtube.replace("MI-ID-PLAYLIST" , id_canal)
        
        plugintools.add_item( 
            title=titulo,
            url=videos,
            thumbnail=logo, folder=True )

