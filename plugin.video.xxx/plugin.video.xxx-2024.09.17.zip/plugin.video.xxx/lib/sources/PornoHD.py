import random
import re
import xbmcaddon
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

def Menu():
	addDir('Latest Videos',      "https://en.pornohd.porn/",              21, 'special://home/addons/plugin.video.xxx/resources/art/pornohd.png')
	addDir('Most Viewed Videos', 'https://en.pornohd.porn/most-popular/', 21, 'special://home/addons/plugin.video.xxx/resources/art/pornohd.png')
	addDir('Top Rated Videos',   'https://en.pornohd.porn/the-best/',     21, 'special://home/addons/plugin.video.xxx/resources/art/pornohd.png')
	addDir('Categories',         'https://en.pornohd.porn/',              22, 'special://home/addons/plugin.video.xxx/resources/art/pornohd.png')

def Browse(url):
	r = OpenURL(url)
	r = r.replace('\n', '')
	#m = re.compile(' <img src="(.+?)" alt="(.+?)" onmouseover="rotationStart\(this, \'https://en\.pornohd\.blue/thumbs/(.+?)/thumb\', 11\)" onmouseout="rotationStop\(this\)">').findall(r, re.MULTILINE)
	m = re.compile('<div class="preview_screen">(.+?)</a>').findall(r)
	for i in m:
		title = re.compile('alt="(.+?)" on').findall(i)[0]
		url = re.compile('blue/thumbs/(.+?)/thumb').findall(i)[0]
		url = 'https://en.pornohd.porn/embed/' + url
		thumb = re.compile('<img src="(.+?)" alt').findall(i)[0]
		time = re.compile('<div class="duration">(.+?)</div>').findall(i)[0]
		random_id = random.randint(0,1000000)
		url = '%s&random_id=%s' % (url, str(random_id))
		if Setting('show_time') == 'true': title = '[B](%s)[/B] %s' % (time, title)
		
		if time.startswith('19:'): pass
		elif time.startswith('18:'): pass
		elif time.startswith('17:'): pass
		elif time.startswith('16:'): pass
		elif time.startswith('15:'): pass
		elif time.startswith('14:'): pass
		elif time.startswith('13:'): pass
		elif time.startswith('12:'): pass
		elif time.startswith('11:'): pass
		elif time.startswith('10:') and len(time) < 6: pass
		elif time.startswith('09:') and len(time) < 6: pass
		elif time.startswith('08:') and len(time) < 6: pass
		elif time.startswith('07:') and len(time) < 6: pass
		elif time.startswith('06:') and len(time) < 6: pass
		elif time.startswith('05:') and len(time) < 6: pass
		elif time.startswith('04:') and len(time) < 6: pass
		elif time.startswith('03:') and len(time) < 6: pass
		elif time.startswith('02:') and len(time) < 6: pass
		elif time.startswith('01:') and len(time) < 6: pass
		elif time.startswith('00:'): pass
		else: addVideo(title.replace('&#x27;', "'").replace('&#8217;', "'"), url, 23, thumb)
		
	n = re.compile('<a href="(.+?)">Next&raquo;</a>').findall(r)
	for page in n:
		addDir('Next page >', page, 21, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	Common.SetView()
		
def Categories(url):
	r = OpenURL(url)
	m = re.compile('<a href="(.+?)">(.+?)</a>').findall(r)
	for url, title in m:
		if '/categories/' in url and title != 'Categories':
			addDir(title, url, 21, 'special://home/addons/plugin.video.xxx/resources/art/pornohd.png')
	
def PlayStream(url):
	if 'random_id=' in url:
		url = re.compile('(.+?)&random_id').findall(url)[0]
	r = OpenURL(url)
	if '1080p' in r:
		m = re.compile('\[1080p\] (.+?)\.mp4').findall(r)
		for url in m:
			Play(url + '.mp4')
	elif '720p' in r:
		m = re.compile('\[720p\] (.+?)\.mp4').findall(r)
		for url in m:
			Play(url + '.mp4')
	elif '480p' in r:
		m = re.compile('\[480p\] (.+?)\.mp4').findall(r)
		for url in m:
			Play(url + '.mp4')
	elif '360p' in r:
		m = re.compile('\[360p\] (.+?)\.mp4').findall(r)
		for url in m:
			Play(url + '.mp4')
	elif '240p' in r:
		m = re.compile('\[240p\] (.+?)\.mp4').findall(r)
		for url in m:
			Play(url + '.mp4')
	else:
		pass
