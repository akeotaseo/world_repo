# -*- coding: utf-8 -*-

#  DNS Leak-Test a Kodi addon too check your DNS Settings - Modified by GKoBu
#  Copyright (C) 2020  Space2Walker
#      This program is free software: you can redistribute it and/or modify
#      it under the terms of the GNU General Public License as published by
#      the Free Software Foundation, either version 3 of the License, or
#      (at your option) any later version.
#
#      This program is distributed in the hope that it will be useful,
#      but WITHOUT ANY WARRANTY; without even the implied warranty of
#      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#      GNU General Public License for more details.
#
#      You should have received a copy of the GNU General Public License
#      along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys, re
import xbmcaddon
import xbmcgui
import xbmcvfs
import json
from platform import system as system_name
from random import randint
from subprocess import call as system_call
import urllib.request as urllib2
import time

addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo("name")
thumb = xbmcvfs.translatePath(addon.getAddonInfo("icon"))
dp = xbmcgui.DialogProgressBG()
def perform_ping(short=False):
    """
    builds the identification and performs the series of pings
    to <idenification>.bash.ws too trigger the DNS requests

    :return: identification
    """
    identification = str(randint(1000000, 9999999))
    if short:
        time_limit = 20
        start_time = time.time()
        for x in range(0, 10):
            ping_command(".".join([str(x), identification, "bash.ws"]))
            elapsed_time = time.time() - start_time
            if elapsed_time >= time_limit:
                break
    else:
        try:
            dp.create(addon_name, "DNS test running")
            for x in range(0, 10):
                dp.update(100-(100-x*10), addon_name, "DNS test running")
                ping_command(".".join([str(x), identification, "bash.ws"]))
        finally:
            dp.close()
    return identification


def get_response(identification):
    """
    Gets the response data from the bash.ws api

    :param str identification: The ID
    :return:
    """
    headers = {
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    }    
    url = f"https://bash.ws/dnsleak/test/{identification}?json"
    req = urllib2.Request(url)
    for key in headers:
        req.add_header(key, headers[key])
    resp = urllib2.urlopen(req)
    response = resp.read().decode("utf-8")
    resp.close()
    parsed_data = json.loads(response)
    return parsed_data


def ping_command(host):
    """
    Perform a Platform specific PING command

    :param str host: The host to Ping
    """
    param = "-n" if system_name().lower() == "windows" else "-c"
    command = ["ping", param, "1", host]
    if system_name().lower() == "windows":
        system_call(command, creationflags=0x00000008)
    else:
        system_call(command)

def list_data(parsed_data, d_type):
    """
    parses a sub element off the parsed_data from bash.ws
    and displays it in kodi

    :param list parsed_data: The Response from bash.ws
    :param d_type: The Type to list
    """
    rep = ""
    for dns_server in parsed_data:
        if dns_server["type"] == d_type:
            if dns_server["country_name"]:
                if dns_server["asn"]:
                    rep += f"{dns_server['ip']} [{dns_server['country_name']}, {dns_server['asn']}]\n"
                else:
                    rep += f"{dns_server['ip']} [{dns_server['country_name']}, {dns_server['asn']}]\n"
            else:
                rep += "" + str(dns_server["ip"]) + "\n"
    return rep

def is_vpn(ip):
    testurl = "https://ipinfo.io/widget/demo/{}?dataset=proxy-vpn-detection".format(ip)
    headers = {
        'cache-control': 'no-cache',
        'content-type': 'application/json',
        'pragma': 'no-cache',
        'referer': 'https://ipinfo.io/products/proxy-vpn-detection-api',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    }

    try:
        req = urllib2.Request(testurl)
        for key in headers:
            req.add_header(key, headers[key])
        resp = urllib2.urlopen(req)
        response = resp.read().decode("utf-8")
        resp.close()
        parsed_data = json.loads(response)
        vpn_result = parsed_data["data"].get("vpn")
        vpn_service = parsed_data["data"].get("service", "")
    except Exception as e:
        if str(e) == 'HTTP Error 403: Forbidden':
            return "ERROR", "ERROR"
        else:
            return False, ""
    return vpn_result, vpn_service

def dns_report(short=False):
    ip_asn_name = ''
    report = ''
    ip = ''
    try:
        identification = perform_ping(short)
        data = get_response(identification)
        report2 = list_data(data, "ip")
        report += "Your IP Address:\n[COLORgold]{}[/COLOR]".format(report2)

        servers = 0
        for dns_server in data:
            if dns_server["type"] == "dns":
                servers += 1

        if servers == 0:
            report += "No DNS servers found\n"

        else:
            if servers == 1:
                report += "\nYou are using one DNS server:\n"
            else:
                report += "\nYou are using {} DNS servers:\n".format(str(servers))
            report3 = list_data(data, "dns")
            try:
                ip_asn = re.match(r"[^[]*\[([^]]*)\]", report2).groups()[0]
                ip_asn_name = re.split(r'AS\d+', ip_asn)[1].strip()
                if ip_asn_name in report3:
                    report3 = report3.replace(ip_asn_name, "[COLORred]{}[/COLOR]".format(ip_asn_name))
            except:
                pass
            report += "[COLORgold]{}[/COLOR]".format(report3)

        report += "\nConclusion:\n"

        for dns_server in data:
            if dns_server["type"] == "conclusion":
                if dns_server["ip"] == "DNS may be leaking.":
                    report += "[COLORgold]DNS may be leaking[/COLOR]"
                elif dns_server["ip"] == "DNS is not leaking.":
                    report += "[COLORgold]DNS is not leaking[/COLOR]"
        ip = report2.split("[")[0].strip()
    except:
        pass
    return report, ip_asn_name, ip
    
def dialog_report():
    report, ip_asn_name, ip = dns_report(short=False)
    if report:
        if "[COLORred]" in report:
            isvpn, vpn_serv = is_vpn(ip)
            if isvpn == True:
                report += "\n\nYour VPN service:\n[COLORgold]{}[/COLOR]".format(vpn_serv)
            elif isvpn == "ERROR":
                report += "\n\nYour VPN service:\n[COLORgold]{}[/COLOR]".format(vpn_serv)
        return xbmcgui.Dialog().textviewer('DNS Leak Test Report', report)
    else:
        return xbmcgui.Dialog().notification(addon_name, "DNS Leak Test - No info", thumb, 3000, False)

def dialog_warning():
    report, ip_asn_name, ip = dns_report(short=True)
    if report:
        if "[COLORred]" in report:
            isvpn, vpn_serv = is_vpn(ip)
            if not isvpn:
                return xbmcgui.Dialog().textviewer('Προειδοποίηση DNS', "Φαίνεται ότι χρησιμοποιούνται DNS του Internet παρόχου σας \n[B][COLORwhite]{}[/COLOR][/B]".format(ip_asn_name)+
                                                                "\n\nΥπάρχει σοβαρή πιθανότητα κάποια πρόσθετα να μην έχουν πρόσβαση στους ιστοτόπους στους οποίους ψάχνουν δεδομένα με αποτέλεσμα είτε να υπολειτουργούν είτε να εμφανίζουν σφάλματα."+
                                                                "\n\n[B][COLORyellow]Δεν δεχόμαστε αναφορές για προβλήματα στα Build και τα πρόσθετα αν βλέπετε αυτήν την προειδοποίηση!!![/COLOR][/B]")
            elif isvpn == "ERROR":
                return xbmcgui.Dialog().notification(addon_name, "Έλεγχος DNS. Πιθανή χρήση VPN.", thumb, 5000, False)
            else:
                return xbmcgui.Dialog().notification(addon_name, "Έλεγχος DNS. Χρήση VPN ({}).".format(vpn_serv), thumb, 5000, False)
        else:
            return xbmcgui.Dialog().notification(addon_name, "Έλεγχος DNS OK!!", thumb, 3000, False)
    else:
        return xbmcgui.Dialog().notification(addon_name, "DNS Test - Αδυναμία λήψης πληροφορίας", thumb, 3000, False)

