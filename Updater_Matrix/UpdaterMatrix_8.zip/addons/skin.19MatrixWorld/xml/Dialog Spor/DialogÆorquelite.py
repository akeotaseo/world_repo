﻿import xbmc, xbmcgui

def DialogΤorquelite():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.torquelite/",return)')
    xbmc.sleep(200)
    xbmcgui.Dialog().notification("[B][COLOR yellow]Τorquelite[/COLOR][/B]", "   ", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/Torque Lite.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR yellow]Τorquelite[/COLOR][/B]", "   ", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/Torque Lite.png')
DialogΤorquelite()