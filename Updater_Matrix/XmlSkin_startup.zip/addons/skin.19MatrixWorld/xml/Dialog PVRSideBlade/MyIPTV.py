﻿import xbmc, xbmcgui

def MyIPTV():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.myiptv/")')
    xbmcgui.Dialog().notification("[B][COLOR orange]My IPTV[/COLOR][/B]", "   ", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/iptv.png')
    xbmc.sleep(4000)
MyIPTV()
