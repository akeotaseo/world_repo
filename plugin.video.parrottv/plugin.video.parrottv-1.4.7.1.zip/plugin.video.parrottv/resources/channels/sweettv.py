# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests
from requests.structures import CaseInsensitiveDict
import random
from string import ascii_lowercase, ascii_uppercase, digits
import uuid
import time
import json
import resources
import xbmcaddon
_ADDON = xbmcaddon.Addon()

ALPHABET = ascii_lowercase + ascii_uppercase + digits
USERDATA = resources.translatePath('special://userdata/addon_data/plugin.video.parrottv')


userAgents = [
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:101.0) Gecko/20100101 Firefox/101.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:99.0) Gecko/20100101 Firefox/99.0",
    "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:77.0) Gecko/20190101 Firefox/77.0",
    "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:77.0) Gecko/20100101 Firefox/77.0",
    "Mozilla/5.0 (X11; Linux ppc64le; rv:75.0) Gecko/20100101 Firefox/75.0",
    "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:39.0) Gecko/20100101 Firefox/75.0",
    "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.10; rv:75.0) Gecko/20100101 Firefox/75.0",
    "Mozilla/5.0 (X11; Linux; rv:74.0) Gecko/20100101 Firefox/74.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.13; rv:61.0) Gecko/20100101 Firefox/73.0",
    "Mozilla/5.0 (X11; OpenBSD i386; rv:72.0) Gecko/20100101 Firefox/72.0",
    "Mozilla/5.0 (Windows NT 6.3; WOW64; rv:71.0) Gecko/20100101 Firefox/71.0",
    "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:70.0) Gecko/20191022 Firefox/70.0",
    "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:70.0) Gecko/20190101 Firefox/70.0",
    "Mozilla/5.0 (Windows; U; Windows NT 9.1; en-US; rv:12.9.1.11) Gecko/20100821 Firefox/70"
]

def genUA():
    return random.choice(userAgents)

def emailGenerator():
    email = ""
    for i in range(random.randint(5,10)):
        email += random.choice(ALPHABET)
    email += "@gmail.com"
    return email

def passwordGenerator():
    password = ""
    for i in range(20):
        password += random.choice(ALPHABET)
    return password

def genIP():
    ip = ""
    opt = random.randint(1,5)
    if opt == 1:
        ip = '5.178.'+ str(random.randint(48,63))+'.'+str(random.randint(0,255))
    elif opt == 2:
        ip = '84.47.'+ str(random.randint(0,127))+'.'+str(random.randint(0,255))
    elif opt == 3:
        ip = '91.191.'+ str(random.randint(64,127))+'.'+str(random.randint(0,255))
    elif opt == 4:
        ip = '178.'+ str(random.randint(143,143))+'.'+str(random.randint(0,255))+'.'+str(random.randint(0,255))
    elif opt == 5:
        ip = '178.'+ str(random.randint(40,41))+'.'+str(random.randint(0,255))+'.'+str(random.randint(0,255))
    return ip

class SweetTV:
    def __init__(self):
        self.UA = genUA()
        self.UUID = str(uuid.uuid4())
        self.IP = genIP()
        self.versionString = "3.1.04"

    def getM3U8(self, token, channelID):
        url = "https://api.sweet.tv/TvService/OpenStream.json"
        headers = CaseInsensitiveDict()
        headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0"
        headers["Accept"] = "application/json, text/plain, */*"
        headers["Accept-Language"] = "en"
        headers["Content-Type"] = "application/json"
        headers["Authorization"] = "Bearer " + token
        headers["X-Device"] = "1;22;0;2;3.1.04"
        headers["Origin"] = "https://sweet.tv"
        headers["DNT"] = "1"
        headers["Connection"] = "keep-alive"
        headers["Referer"] = "https://sweet.tv/"
        headers["Sec-Fetch-Dest"] = "empty"
        headers["Sec-Fetch-Mode"] = "cors"
        headers["Sec-Fetch-Site"] = "same-site"
        headers["Sec-GPC"] = "1"
        headers["TE"] = "trailers"
        data = '{"channel_id":"'+str(channelID)+'","accept_scheme":["HTTP_HLS"],"multistream":true}'
        resp = requests.post(url, headers=headers, data=data).json()
        address = resp["http_stream"]["host"]["address"]
        port = resp["http_stream"]["host"]["port"]
        url = resp["http_stream"]["url"]
        hlsUrl = "http://{address}:{port}{url}".format(address=address, port=port, url=url)
        return hlsUrl

    # Idk why but this site uses one api for login and register
    def login(self, email, password):
        url = "https://api.sweet.tv/SigninService/Email.json"
        headers = CaseInsensitiveDict()
        headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0"
        headers["Accept"] = "application/json, text/plain, */*"
        headers["Accept-Language"] = "en"
        headers["Content-Type"] = "application/json"
        headers["X-Device"] = "1;22;0;2;3.1.04"
        headers["Origin"] = "https://sweet.tv"
        headers["DNT"] = "1"
        headers["Connection"] = "keep-alive"
        headers["Referer"] = "https://sweet.tv/"
        headers["Sec-Fetch-Dest"] = "empty"
        headers["Sec-Fetch-Mode"] = "cors"
        headers["Sec-Fetch-Site"] = "same-site"
        headers["TE"] = "trailers"
        data = '{"device":{"type":"DT_Web_Browser","application":{"type":"AT_SWEET_TV_Player"},"model":"'+self.UA+'","firmware":{"versionCode":1,"versionString":"'+self.versionString+'"},"uuid":"'+self.UUID+'","supported_drm":{"widevine_modular":true}},"email":"'+email+'","password":"'+password+'"}'
        resp = requests.post(url, headers=headers, data=data).json()
        return {'refresh_token': resp['refresh_token'], 'access_token': resp['access_token'], 'expires_in': int(time.time()) + (3 * 60 * 60)}

    def genCreds(self):
        email = emailGenerator()
        password = passwordGenerator()
        resp = self.login(email, password)
        # Now + 6 days
        expire = int(time.time()) + (6 * 24 * 60 * 60)
        jsonf = {
            'email': email,
            'password': password,
            'expire': expire
        }
        _ADDON.setSetting('SweetTVcreds', json.dumps(jsonf))
        return resp['access_token']

    def grab(self, channel):
        headers = {'User-Agent': self.UA}
        headers.update({'Referer': 'https://sweet.tv/'})
        headers.update({'X-Forwarded-For': self.IP})
        token = ""
        if _ADDON.getSetting('SweetTVcreds') != "":
            creds = json.loads(_ADDON.getSetting('SweetTVcreds'))
            if time.time() > creds['expire']:
                token = self.genCreds()
            else:
                token = self.login(creds['email'], creds['password'])['access_token']
        else:
            token = self.genCreds()
        hlsUrl = self.getM3U8(token, channel)
        headers.update({'Authorization': 'Bearer ' + token})
        return hlsUrl, headers
