import xbmc, xbmcgui


def Quickly():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Quickly~[/COLOR][/B]', 
['[B][COLOR=white]Ταινιες - Προβολές[/COLOR][/B] (blacklodge)',
 '[B][COLOR=white]Σειρές -  Με πολλούς ψήφους[/COLOR][/B] (blacklodge)',
 '[B][COLOR=white]LIVE EVENTS[/COLOR][/B] (sporthdme)',
 '[B][COLOR=white]TODAYS SPORTING EVENTS[/COLOR][/B] (madtitansportsr)',
 '[B][COLOR=white]Xrysoi - Παιδικά Μεταγλωτισμένα[/COLOR][/B] (mj-cartoonsgr)',
 '[B][COLOR=white]Xrysoi - Παιδικά Υπότιτλοι[/COLOR][/B] (mj-cartoonsgr)',
 '[B][COLOR=white]Ζωντανή Τηλεόραση[/COLOR][/B] (AliveGR)',
 '[B][COLOR=white]Sophisticated[/COLOR][/B] (eradio)',
 '[B][COLOR=white]Αναζήτηση[/COLOR][/B] (YouTube)'])


    if call:
        if call < 0:
            return
        func = funcs[call-9
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Quickly/1.py")')

def click_2():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Quickly/2.py")')

def click_3():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Quickly/3.py")')

def click_4():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Quickly/4.py")')
    
def click_5():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Quickly/5.py")')

def click_6():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Quickly/6.py")')

def click_7():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Quickly/7.py")')

def click_8():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Quickly/8.py")')

def click_9():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Quickly/9.py")')

Quickly()
