import sys
import requests
import xbmcplugin
import xbmcgui
import xbmc
import re
import urllib.parse

# Verificăm dacă rulăm pe Android
is_android = xbmc.getCondVisibility('System.Platform.Android')

# Funcția pentru a extrage lista de categorii folosind regex
def extract_categories():
    url = 'https://emisiuni.live/categorii/'
    headers = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Referer': 'https://emisiuni.live/',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    }

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
    except requests.exceptions.RequestException:
        return []

    response_text = response.text

    # Extragem categoriile din HTML folosind regex
    categories = []
    regex_pattern = r'<li .*?class="menu-item.*?"><a href="(https://emisiuni\.live/categorie/.*?)".*?>(.*?)</a>'
    matches = re.findall(regex_pattern, response_text)

    for match in matches:
        link, title = match
        categories.append({'title': title.strip(), 'link': link.strip()})

    return categories

# Funcția pentru a extrage lista de canale dintr-o categorie folosind regex
def extract_channel_items(category_url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Referer': category_url,
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    }

    try:
        response = requests.get(category_url, headers=headers)
        response.raise_for_status()
    except requests.exceptions.RequestException:
        return []

    response_text = response.text

    # Extragem articolele care conțin informații despre canale folosind regex
    channels = []
    regex_pattern = r'<article.*?class=".*?canal.*?">(.*?)</article>'
    articles = re.findall(regex_pattern, response_text, re.DOTALL)

    for article in articles:
        try:
            # Extragem titlul din atributul title al tagului <a>
            title_match = re.search(r'<a class="post-thumbnail".*?title="(.*?)"', article)
            title = re.sub(r'\b(online|gratis)\b', '', title_match.group(1), flags=re.IGNORECASE).strip() if title_match else None

            # Extragem link-ul canalului din atributul href al tagului <a>
            link_match = re.search(r'<a class="post-thumbnail".*?href="(.*?)"', article)
            link = link_match.group(1).strip() if link_match else ''

            # Extragem posterul din atributul src al tagului <img>
            poster_match = re.search(r'<img.*?src="(.*?)"', article)
            poster = poster_match.group(1).strip() if poster_match else ''

            if title:
                channels.append({'title': title, 'poster': poster, 'link': link})
        except Exception:
            continue

    return channels

# Funcția pentru a extrage URL-ul playerului din pagina postului TV
def extract_player_url(channel_url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',
        'Referer': channel_url,
        'Accept-Language': 'ro-RO,ro;q=0.9,en-US;q=0.8,en;q=0.7',
    }

    try:
        # Solicită pagina canalului
        response = requests.get(channel_url, headers=headers)
        response.raise_for_status()
    except requests.exceptions.RequestException:
        return None

    # Extrage URL-ul iframe-ului din script
    iframe_url_match = re.search(r'iframe\.src = `([^`]+)`', response.text)
    iframe_url = iframe_url_match.group(1) if iframe_url_match else None

    if not iframe_url:
        return None

    try:
        # Solicită sursa iframe-ului
        iframe_response = requests.get(iframe_url, headers=headers)
        iframe_response.raise_for_status()
    except requests.exceptions.RequestException:
        return None

    # Extrage URL-ul streamului din sursa HTML a iframe-ului
    video_url_match = re.search(r'<source src="([^"]+)"', iframe_response.text)
    video_url = video_url_match.group(1) if video_url_match else None

    return video_url

# Funcția pentru a reda un canal selectat
def play_channel(link):
    player_url = extract_player_url(link)
    if player_url:
        list_item = xbmcgui.ListItem(path=player_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, list_item)
    else:
        xbmcgui.Dialog().notification('Eroare', 'Nu am putut obține URL-ul playerului.', xbmcgui.NOTIFICATION_ERROR, 5000)

# Funcția pentru a lista canalele dintr-o categorie selectată
def list_channels_for_category(category_url):
    channels = extract_channel_items(category_url)
    for channel in channels:
        url = f"{sys.argv[0]}?action=play&link={urllib.parse.quote_plus(channel['link'])}"
        list_item = xbmcgui.ListItem(label=channel['title'])

        # Setăm thumb, icon și fundalul fanart.webp pentru fiecare canal
        list_item.setArt({
            'thumb': channel['poster'],
            'icon': channel['poster'],
            'fanart': 'special://home/addons/plugin.video.rdslive/fanart.webp'  # Setează fundalul
        })

        list_item.setProperty('IsPlayable', 'true')  # Marcăm elementul ca redabil
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

# Funcția pentru a lista categoriile în interfața Kodi
def list_categories():
    categories = extract_categories()
    for category in categories:
        url = f"{sys.argv[0]}?action=list_category&category_url={urllib.parse.quote_plus(category['link'])}"
        list_item = xbmcgui.ListItem(label=category['title'])
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

# Funcția principală pentru a gestiona acțiunile
def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    if params and 'action' in params:
        if params['action'] == 'play':
            play_channel(params['link'])
        elif params['action'] == 'list_category':
            category_url = params['category_url']
            list_channels_for_category(category_url)
    else:
        list_categories()

# Main entry point
if __name__ == '__main__':
    router(sys.argv[2][1:])
