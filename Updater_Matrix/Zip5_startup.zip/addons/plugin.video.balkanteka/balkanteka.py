import xbmcgui
import xbmcplugin
import sys
import os
import xbmcaddon

# Balkan Dzo Addon by Dzon Dzoe

def show_categories():
    categories = [
        {"name": "[B][COLOR deepskyblue]Domaci Filmovi[/B][/COLOR]", "addon_id": "plugin.video.domfilm"},
        {"name": "[B][COLOR deepskyblue]Domaci Filmovi[/B] [I](filmske kolekcije)[/I][/COLOR]", "addon_id": "plugin.video.domfilmfr"},
        {"name": "[B][COLOR deepskyblue]Domace Serije[/B] [I](emitovanje u toku)[/I][/COLOR]", "addon_id": "plugin.video.domserijenew"},
        {"name": "[B][COLOR deepskyblue]Domace Serije[/B] [I](zavrsene serije)[/I][/COLOR]", "addon_id": "plugin.video.domserijefinal"},
        {"name": "[B][COLOR deepskyblue]Crtani - Animirani Filmovi (sinhronizovano)[/B][/COLOR]", "addon_id": "plugin.video.crtanianim"},
        {"name": "[B][COLOR deepskyblue]Crtani - Animirani Filmovi (sinhronizovano)[/B] [I](filmske kolekcije)[/I][/COLOR]", "addon_id": "plugin.video.crtanianimfr"},
        {"name": "[B][COLOR deepskyblue]Crtane - Animirane Serije[/B] [I](epizodne)[/I][/COLOR]", "addon_id": "plugin.video.crtanser"},
        {"name": "[B][COLOR deepskyblue]---------------------------------------------------------------------------------[/B][/COLOR]", "addon_id": "skip"},
        {"name": "[B][COLOR deepskyblue]4K Filmovi[/B][/COLOR]", "addon_id": "plugin.video.4kfilm"},
        {"name": "[B][COLOR deepskyblue]Strani Filmovi[/B][/COLOR]", "addon_id": "plugin.video.strfilm"},
        {"name": "[B][COLOR deepskyblue]Strani Filmovi[/B] [I](filmske kolekcije)[/I][/COLOR]", "addon_id": "plugin.video.strfilmfr"},
        {"name": "[B][COLOR deepskyblue]Strane Serije[/B] [I](emitovanje u toku)[/I][/COLOR]", "addon_id": "plugin.video.strserijenew"},
        {"name": "[B][COLOR deepskyblue]Strane Serije[/B] [I](zavrsene serije)[/I][/COLOR]", "addon_id": "plugin.video.strserijefinal"},
    ]

    addon_folder = xbmcaddon.Addon().getAddonInfo('path')
    icons_folder = os.path.join(addon_folder, 'resources', 'icons')

    for category in categories:
        path = "plugin://" + category["addon_id"]
        list_item = xbmcgui.ListItem(label=category["name"])
        icon_filename = f"{category['addon_id']}.png"
        icon_path = os.path.join(icons_folder, icon_filename)
        if os.path.exists(icon_path):
            list_item.setArt({'thumb': icon_path, 'icon': icon_path})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=path, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

if __name__ == '__main__':
    show_categories()
