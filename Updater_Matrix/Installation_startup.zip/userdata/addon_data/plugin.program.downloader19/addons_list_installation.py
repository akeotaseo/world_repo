﻿from updatervar import *

dialog.notification('Εγκατάσταση αρχείων...', 'Αναμονή για ολοκλήρωση', icon_install, sound=False)
xbmc.sleep(500) 

addons_list_installation = ['repository.test', 'plugin.video.dracarys', 'repository.giaitri', 'repository.rdplayer', 'repository.angelitto', 'Bee-Queen', 'repository.fanvodpl', 'repository.thecrew.alpha', 'repository.arkane14', 'repository.cbtv', 'repository.kodi.media', 'repository.remod', 'repository.enigmawiz', 'repository.zeus768', 'repository.wetdreams69', 'repository.fivebanger', 'repository.test2']

def check_addons_list():
    for addons_list in addons_list_installation:
        if not exists(addons_path + '%s' % addons_list):
            xbmc.sleep(1000)
            installAddon()


def installAddon():
    for addon_id in addons_list_installation:
      xbmc.executebuiltin('InstallAddon(%s)' % (addon_id))
      xbmc.sleep(1000)
      xbmc.executebuiltin('SendClick(11)')
      xbmc.sleep(500)
check_addons_list()
