from urllib.parse import urlencode, parse_qsl, unquote, urlparse
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from datetime import datetime
import re, sys, urlquick, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_name = Addon().getAddonInfo('name')
ICON = Addon().getAddonInfo('icon')
UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/605.1.15 EdgA/132.0.0.0'
ref = 'https://t.fdcdn.xyz/'
apitc = 'https://q.thapcamn.xyz/api/match/'
def addDir(title, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': ICON})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=20, max_age=luu, headers={'user-agent': UA,'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}/'
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        url = f'{apitc}featured/mt'
        resp = getlink(url, url,-1)
        r2 = resp.json()['data']
        for k in r2:
            time = datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M %d/%m')
            tg = f'[COLOR red]{time}[/COLOR]' if 'live' in k['match_status'] else time
            blv = ' - '.join((h['name'] for h in k["commentators"] or []))
            tenm = f'[COLOR yellow]{k["name"]}[/COLOR] {blv}' if blv else k['name']
            tenv = f'{tg} {tenm}'
            addDir(tenv, 'list_thapcam', idk = str(k['id']), name=tenv, ref=ref)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'list_thapcam':
        u = f'{apitc}{params["idk"]}/meta'
        resp = getlink(u, u, -1)
        kq = resp.json()['data']
        kp = kq['play_urls']
        for k in kp:
            tenm = f'{k["name"]} - {params["name"]}'
            addDir(tenm, 'play', id = k['url'], is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'play':
        play_item = xbmcgui.ListItem(offscreen=True)
        linkplay = re.sub(r'\s+', '%20', params['id'].strip(), flags=re.UNICODE)
        hdr = f"verifypeer=false&User-Agent={unquote(UA)}&Referer={ref}"
        if 'm3u8' in linkplay:
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
            play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
        else:
            linkplay = f"{linkplay}|{hdr}"
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
if __name__ == '__main__':
    router(sys.argv[2][1:])