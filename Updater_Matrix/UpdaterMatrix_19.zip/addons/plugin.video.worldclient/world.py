import xbmcgui
import xbmcaddon
import xbmcplugin
import re
import sys
import urllib.parse
import xbmc
import urllib.request

# Balkan Dzo Addon by Dzon Dzoe

addon = xbmcaddon.Addon()
m3u_url = addon.getSetting("m3u_url")

def play_channel_with_user_agent(channel_name, channel_url):
    try:
        user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"
        headers = {"User-Agent": user_agent}
        req = urllib.request.Request(channel_url, headers=headers)
        with urllib.request.urlopen(req) as response:
            xbmc.log("Pokretanje reprodukcije kanala: {}".format(channel_name))
            xbmc.log("URL kanala sa korisničkim agentom: {}".format(channel_url))
            xbmc.Player().play(response.geturl(), listitem=xbmcgui.ListItem(channel_name))
    except Exception as e:
        xbmcgui.Dialog().ok('Greška', 'Došlo je do greške prilikom reprodukcije kanala: {}'.format(e))

def parse_m3u_playlist(url):
    try:
        user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"
        request = urllib.request.Request(url)
        request.add_header('User-Agent', user_agent)
        response = urllib.request.urlopen(request)

        lines = response.read().decode('utf-8').splitlines()

        categories = {}
        current_category = None

        for line in lines:
            line = line.strip()
            if line.startswith("#EXTINF:"):
                channel_info = re.search(r'tvg-name="([^"]*)" tvg-logo="([^"]*)" group-title="([^"]*)"', line)
                if channel_info:
                    current_category = channel_info.group(3)
                    if current_category not in categories:
                        categories[current_category] = []
            elif line.startswith("http") and current_category:
                channel_name = channel_info.group(1) if channel_info.group(1) else "Unknown"
                channel_logo = channel_info.group(2) if channel_info.group(2) else ""
                channel_url = line.strip()
                categories[current_category].append({"name": channel_name, "logo": channel_logo, "url": channel_url})

        return categories
    except urllib.error.URLError:
        xbmcgui.Dialog().ok("Greška", "Ova lista je prestala sa radom. Izaberite drugu listu.")
        return {}

def run():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get("action", None)
    category = params.get("category", None)

    if not action:
        categories = parse_m3u_playlist(m3u_url)
        for category in categories.keys():
            list_item = xbmcgui.ListItem(label="[B][COLOR deepskyblue]{}[/COLOR][/B]".format(category))
            url = "{}?action=list_channels&category={}".format(sys.argv[0], urllib.parse.quote(category))
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif action == "list_channels" and category:
        categories = parse_m3u_playlist(m3u_url)
        channels = categories.get(urllib.parse.unquote(category), [])
        for channel in channels:
            list_item = xbmcgui.ListItem(label="[COLOR deepskyblue]{}[/COLOR]".format(channel["name"]))
            list_item.setInfo("video", {"title": channel["name"]})
            list_item.setArt({"thumb": channel["logo"]})
            url = "{}?action=play_channel&channel_name={}&channel_url={}".format(sys.argv[0], urllib.parse.quote(channel["name"]), urllib.parse.quote(channel["url"]))
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif action == "play_channel" and params.get("channel_url"):
        if xbmc.Player().isPlaying():
            xbmc.Player().stop()
            xbmc.log("Prethodni kanal je zaustavljen.")
        channel_name = params.get("channel_name", "Unknown Channel")
        channel_url = params["channel_url"]
        play_channel_with_user_agent(channel_name, channel_url)

if __name__ == "__main__":
    run()
