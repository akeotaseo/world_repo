import six

if __name__ == '__main__':
	if six.PY3: from resources.lib import matrix
	else: from resources.lib import leia