import xbmc, xbmcgui

def daddylive():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Daddylive ~[/COLOR][/B]', 
['[COLORred][B]Daddylive[/COLOR][/B] (microjen)',
 '[B][COLOR=white]Daddylive[/COLOR][/B]',
 '[COLOR=white]Live Sports[/COLOR] (gratis)',
 '[COLOR=white]Sports Genres[/COLOR] (vstream)  [COLOR red]OFF...[/COLOR]',
 '[COLOR red][B]Daddylive(test)[/COLOR][/B] (microjen)',
 '[COLORgoldenrod] Mixed Live Sports Events[/COLOR] (Asgard - microjen)  [COLOR red]OFF...[/COLOR]',
 '[COLOR white]Αγώνες [COLOR lime]Ζωντανά...[/COLOR] (Atlas)',
 '[COLOR=white]Daddylive[/COLOR] (the-loop)',
 '[COLOR=white]Daddylive[/COLOR] (Μadtitansports)',
 # '[COLOR=white]DADDYLIVE[/COLOR] (VN Media)',
 # '[COLOR=white]DADDYLIVE[/COLOR] (90phuttv)',
  '[COLOR=white]DADDYLIVE[/COLOR] (Black Ghost)',
 '[B][COLOR white]DaddyLive HD [COLOR lime] ¡novedad![/COLOR][/B] (koditv)',


 '[B][COLOR red]<---                                                                      [COLOR grey]Back[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-12]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=sched")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/?mode=menu&serv_type=sched")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.gratis/?_id&description=Live%20Sports&episode_number&fanart=C%3a%5cPortableApps%5ckodi%5cMy%20KODI%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.gratis%5cfanart.jpg&foldername&icon=C%3a%5cPortableApps%5ckodi%5cMy%20KODI%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.gratis%5cicon.png&mediatype&mode=live_main&name=Live%20Sports&name2&page&season_number&url")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vstream/?function=showGenres&sFav=showGenres&site=daddyhd&siteUrl=schedule%2fschedule-generated.json&title=DaddyHD")')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/sportjetextractors/games/Daddylive")')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://script.module.mixedsports/?mode=menu&serv_type=sched")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.atlas/?mode=menu&serv_type=sched")')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.the-loop/sportjetextractors/games/Daddylive")')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.madtitansports/sportjetextractors/games/Daddylive")')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=http%3a%2f%2fbgtv.xyz%2fblack%2fimg%2ffanart.jpg&mode=1&name=%20%20%5bCOLOR%20lightcyan%5d%5bB%5dAGENDA%20%5b%2fCOLOR%5d%5bCOLOR%20lightblue%5dDADDYLIVE%5b%2fCOLOR%5d%5b%2fB%5d%20%20%5bCOLOR%20lightslategray%5d%20%20%5b%2fCOLOR%5d%20%20&url=http%3a%2f%2fbgtv.xyz%2floves.php%3fdaddy",return)')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.koditv/?action=DaddyLiveHD&extra&page&plot&thumbnail=https%3a%2f%2fguruhitech.com%2fwp-content%2fuploads%2f2023%2f01%2fdaddylive-icon.webp&title=%5bB%5d%5bCOLOR%20white%5dDaddyLive%20HD%20%5bCOLOR%20lime%5d%20%c2%a1novedad!%5b%2fCOLOR%5d%5b%2fB%5d&url")')


def click_12():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/Live_Now.py")')
daddylive()
