import sys
from urllib.parse import urlencode
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
from resources.channels import *
from kodiez import KodiEZ
from routing import Plugin

plugin = Plugin()
_ADDON = xbmcaddon.Addon()
_URL = f"plugin://{_ADDON.getAddonInfo('id')}"
_KODIEZ = KodiEZ(_ADDON, plugin.handle)
_PLAYLIST = 'special://home/addons/'+_ADDON.getAddonInfo('id')+'/resources/playlist.m3u'
_ADDON_NAME = _ADDON.getAddonInfo('name') 





@plugin.route('/')
def root():
    xbmcplugin.setContent(plugin.handle, 'Home')
    xbmcplugin.setPluginCategory(plugin.handle, "Home")
    _KODIEZ.addItemToScreen('Search', '', 'https://i.ibb.co/5MLs6jQ/search.png', f"{_URL}/search", True)
    _KODIEZ.addItemToScreen('Channels', '', 'https://i.ibb.co/KrtXTdy/list.png', f"{_URL}/channels", True)
    _KODIEZ.addItemToScreen('Categories', '', 'https://i.ibb.co/HXsphPN/categories.png', f"{_URL}/categories", True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/search')
def search():
    xbmcplugin.setContent(plugin.handle, 'Search')
    xbmcplugin.setPluginCategory(plugin.handle, "Search")
    query = _KODIEZ.inpt("Enter search query:", False)
    if query:
        m3ufile = open(xbmcvfs.translatePath(_PLAYLIST), 'r', encoding="utf-8").read()
        names, logos, urls = [], [], []
        for line in m3ufile.split('\n'):
            if '#EXTINF:' in line:
                names.append(line.split(',')[1])
                logos.append(line.split('tvg-logo="')[1].split('"')[0])
            elif 'plugin' in line:
                urls.append(line)
        for name, logo, url in zip(names, logos, urls):
            if query.lower() in name.lower():
                _KODIEZ.addItemToScreen(name, '', logo, url, False)
        xbmcplugin.endOfDirectory(plugin.handle)
    else:
        xbmcgui.Dialog().ok(_ADDON_NAME, 'No search query entered.')
        exit()

@plugin.route('/channels')
def channels():
    xbmcplugin.setContent(plugin.handle, 'Channels')
    xbmcplugin.setPluginCategory(plugin.handle, "Channels")
    m3ufile = open(xbmcvfs.translatePath(_PLAYLIST), 'r', encoding="utf-8").read()
    names, logos, urls = [], [], []
    for line in m3ufile.split('\n'):
        if '#EXTINF:' in line:
            names.append(line.split(',')[1])
            logos.append(line.split('tvg-logo="')[1].split('"')[0])
        elif 'plugin' in line:
            urls.append(line)
    for name, logo, url in zip(names, logos, urls):
        _KODIEZ.addItemToScreen(name, '', logo, url, False)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/categories/')
def categories():
    xbmcplugin.setContent(plugin.handle, 'Categories')
    xbmcplugin.setPluginCategory(plugin.handle, "Categories")
    m3ufile = open(xbmcvfs.translatePath(_PLAYLIST), 'r', encoding="utf-8").read()
    categories = []
    for line in m3ufile.split('\n'):
        if line.startswith('#EXTINF:'):
            line = line.split('group-title="')[1].split('"')[0]
            categories.append(line)
    categories = list(dict.fromkeys(categories))
    for category in categories:
        _KODIEZ.addItemToScreen(category, '', '', f"{_URL}/category/{category}", True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/category/<category>')
def category(category):
    xbmcplugin.setContent(plugin.handle, 'Categories')
    xbmcplugin.setPluginCategory(plugin.handle, "Categories")
    m3ufile = open(xbmcvfs.translatePath(_PLAYLIST), 'r', encoding="utf-8").read()
    names, logos, urls, categories = [], [], [], []
    for line in m3ufile.split('\n'):
        if '#EXTINF:' in line:
            names.append(line.split(',')[1])
            logos.append(line.split('tvg-logo="')[1].split('"')[0])
            categories.append(line.split('group-title="')[1].split('"')[0])
        elif 'plugin' in line:
            urls.append(line)
    for i in range(len(names)):
        if categories[i] == category:
            _KODIEZ.addItemToScreen(names[i], '', logos[i], urls[i], False)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/play/<module>/<stream>')
def play(module, stream):
    if module == "123TV":module = "N123TV"
    hlsurl, headers = eval(f"{module}().grab('{stream}')")
    li = xbmcgui.ListItem(path=hlsurl+'|'+urlencode(headers))
    xbmcplugin.setResolvedUrl(plugin.handle, True, li)


@plugin.route('/ISS')
def iptvsimpleSetup():
    try:
        pisc = xbmcaddon.Addon('pvr.iptvsimple')
    except:
        xbmcgui.Dialog().ok(_ADDON_NAME, 'Please install IPTV Simple.')
        xbmcplugin.setResolvedUrl(plugin.handle, False, xbmcgui.ListItem())
        return
    pisc.setSetting('m3uPathType','1')
    pisc.setSetting('m3uUrl', 'https://bit.ly/ParrotTVAddonIPTVSimple')
    pisc.setSetting('startNum','1')

if __name__ == "__main__":
    open(xbmcvfs.translatePath(_PLAYLIST), 'w', encoding="utf-8").write(requests.get("http://parrot-tv.pages.dev/playlist.m3u").text)
plugin.run(sys.argv)
