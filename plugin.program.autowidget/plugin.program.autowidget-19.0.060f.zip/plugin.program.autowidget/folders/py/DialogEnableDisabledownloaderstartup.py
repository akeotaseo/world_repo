﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def DialogEnableDisabledownloaderstartup():        
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Enable/Disable Updater builds[/COLOR]', '[CR][B]Ενεργοποίηση-Απενεργοποίηση αυτόματης ενημέρωσης του build.[/B][CR][CR]Για να συνεχίσετε πατήστε [B][COLOR green]Συνέχεια[/COLOR][/B]',
                                        nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR green]Συνέχεια[/COLOR][/B]')
                                        
        if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/EnableDisabledownloaderstartup.py")'),
                        ]
                         
DialogEnableDisabledownloaderstartup()
