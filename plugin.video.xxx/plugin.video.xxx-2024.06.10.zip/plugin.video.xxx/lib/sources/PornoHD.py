import re
import xbmcaddon
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

def Menu():
	addDir('Latest Videos',      'https://en.pornohd.porn/',              21, 'special://home/addons/plugin.video.xxx/resources/art/pornohd.png')
	addDir('Most Viewed Videos', 'https://en.pornohd.porn/most-popular/', 21, 'special://home/addons/plugin.video.xxx/resources/art/pornohd.png')
	addDir('Top Rated Videos',   'https://en.pornohd.porn/the-best/',     21, 'special://home/addons/plugin.video.xxx/resources/art/pornohd.png')
	addDir('Categories',         'https://en.pornohd.porn/',              22, 'special://home/addons/plugin.video.xxx/resources/art/pornohd.png')

def Browse(url):
	r = OpenURL(url)
	#m = re.compile(' <img src="(.+?)" alt="(.+?)" onmouseover="rotationStart\(this, \'https://en\.pornohd\.porn/thumbs/(.+?)/thumb\', 11\)" onmouseout="rotationStop\(this\)">').findall(r)
	#m = re.compile(' <img src="(.+?)" alt="(.+?)" onmouseover="rotationStart\(this, \'https://en\.pornohd\.blue/thumbs/(.+?)/thumb\', 11\)" onmouseout="rotationStop\(this\)">').findall(r)
	m = re.compile('  <img src="(.+?)" alt="(.+?)" onmouseover="rotationStart\(this, \'https://imghd\.cdnvids\.com/thumbs/(.+?)/thumb\', 11\)" onmouseout="rotationStop\(this\)">').findall(r)
	for thumb, title, url in m:
		import random
		random_id = random.randint(0,1000000)
		url = '%s&random_id=%s' % (url, str(random_id))
		addVideo(title.replace('&#x27;', "'").replace('&#8217;', "'"), url, 23, thumb)
	n = re.compile('<a href="(.+?)">Next&raquo;</a>').findall(r)
	for page in n:
		addDir('Next page >', page, 21, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	Common.SetView()
		
def Categories(url):
	r = OpenURL(url)
	m = re.compile('<a href="(.+?)">(.+?)</a>').findall(r)
	for url, title in m:
		if '/categories/' in url and title != 'Categories':
			addDir(title, url, 21, 'special://home/addons/plugin.video.xxx/resources/art/pornohd.png')
	
def PlayStream(url):
	if 'random_id=' in url:
		url = re.compile('(.+?)&random_id').findall(url)[0]
	r = OpenURL('https://en.pornohd.porn/embed/' + url)
	if '1080p' in r:
		m = re.compile('\[1080p\] (.+?)\.mp4').findall(r)
		for url in m:
			Play(url + '.mp4')
	elif '720p' in r:
		m = re.compile('\[720p\] (.+?)\.mp4').findall(r)
		for url in m:
			Play(url + '.mp4')
	elif '480p' in r:
		m = re.compile('\[480p\] (.+?)\.mp4').findall(r)
		for url in m:
			Play(url + '.mp4')
	elif '360p' in r:
		m = re.compile('\[360p\] (.+?)\.mp4').findall(r)
		for url in m:
			Play(url + '.mp4')
	elif '240p' in r:
		m = re.compile('\[240p\] (.+?)\.mp4').findall(r)
		for url in m:
			Play(url + '.mp4')
	else:
		pass
