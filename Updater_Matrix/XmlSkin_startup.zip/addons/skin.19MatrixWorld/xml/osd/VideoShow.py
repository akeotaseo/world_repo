﻿import xbmc
# Video Stream
def videoshow():
    if xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin("ActivateWindowAndFocus(osdvideosettings)")
        xbmc.sleep(500)
    if xbmc.getCondVisibility('system.platform.android'):
        xbmc.executebuiltin('SendClick(-180)')
    else:
        xbmc.executebuiltin('SendClick(-180)')

    while xbmc.getCondVisibility("Window.IsVisible(osdvideosettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")



    if not xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin("ActivateWindowAndFocus(osdvideosettings)")
        xbmc.sleep(500)
        xbmc.executebuiltin("Action(Pause)")
    if xbmc.getCondVisibility('system.platform.android'):
        xbmc.executebuiltin('SendClick(-180)')
    else:
        xbmc.executebuiltin('SendClick(-180)')

    while xbmc.getCondVisibility("Window.IsVisible(osdvideosettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")

videoshow()
