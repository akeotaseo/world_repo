import xbmc
from addon import genPlaylist

if __name__ == '__main__':
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        genPlaylist()
        if monitor.waitForAbort(1 * 60 * 60): break
