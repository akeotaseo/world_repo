# datPiff Addon for Kodi

Addon for http://www.datpiff.com/

## Installation

1. Click on the Code button above and click download zip
2. In Kodi use the install from zip file option

## Support

This version of the addon supports version 19 (Matrix) and above. If you are using an older version of Kodi and would like to use this plugin click [here](https://github.com/michaelfdeberry/plugin.audio.datpiff/tree/prematrix) and follow the installation instructions above.
