import xbmc, xbmcgui


def butterfingers():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Butter Fingers ~[/COLOR][/B]', 
['[B][COLOR=white]Ani-Mate[/COLOR][/B]',
 '[B][COLOR=white]Butter Fingers Movies[/COLOR][/B]',
 '[B][COLOR=white]Channels[/COLOR][/B]',
 '[B][COLOR=white]Diy Fix[/COLOR][/B]',
 '[B][COLOR=white]Docula[/COLOR][/B]',
 '[B][COLOR=white]Kidz Club[/COLOR][/B]',
 '[B][COLOR=white]Muzic[/COLOR][/B]',
 '[B][COLOR=white]Risque[/COLOR][/B]',
 '[B][COLOR=white]Sportz[/COLOR][/B]',
 '[B][COLOR=white]Super Flix[/COLOR][/B]',
 '[B][COLOR=white]Wrestlers[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-11]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.animate/")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.bfingers/")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.channels/")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.diyfix/")')
    
def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.docula/")')
    
def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.kidzclub/")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.muzic/")')
    
def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.risque/")')
    
def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportz/")')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.superflix/")')
    
def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.wrestlers/")')


butterfingers()
