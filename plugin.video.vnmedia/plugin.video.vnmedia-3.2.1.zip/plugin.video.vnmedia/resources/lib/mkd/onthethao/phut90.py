from codequick import Route, Listitem, Resolver
from resources.lib.kedon import u90, getlinkvnm, tb, quangcao, getlink, referer, stream
from datetime import datetime
from functools import lru_cache
import re, sys
u9 = u90('90')
@lru_cache(maxsize=None)
def respphut90():
	tr = f"https://{u9}"
	resp90 = getlinkvnm(tr, tr)
	if (resp90 is not None):
		html_content = re.sub(r"(\n\s*//.*)", "", resp90.text)
		ref = re.search(r'base_embed_url\s*=\s*("|\')([^"\s]+)("|\')', html_content)[2]
	else:
		ref = tr
	return ref
ref = respphut90()
@Route.register
def index_90p(plugin, **kwargs):
	yield []
	resp = getlinkvnm('https://api.vebo.xyz/api/match/featured/mt', f"https://{u9}")
	if (resp is not None):
		rd = resp.json()['data']
		for k in rd:
			item = Listitem()
			time = datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M %d-%m')
			cm = k['commentators']
			blv = ' - '.join((h['name'] for h in cm or []))
			ten = f'{time}: {k["name"]} ({blv})' if cm else f'{time}: {k["name"]}'
			ten = f'[B]{ten}[/B]' if k['match_status'] == 'live' else ten
			tenm = f'[COLOR yellow]{ten}[/COLOR]' if (k['is_featured'] or k['tournament']['unique_tournament']['is_featured']) else ten
			item.label = tenm
			item.info['plot'] = tb
			logotour = k['tournament']['logo']
			if logotour:
				item.art['thumb'] = item.art['fanart'] = logotour
			else:
				item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/vebo.png'
			item.set_callback(list_90p, k['id'], tenm)
			yield item
	else:
		yield quangcao()
@Route.register
def list_90p(plugin, idk=None, title=None, **kwargs):
	yield []
	if idk is None or title is None:
		pass
	else:
		url = f'http://api.vebo.xyz/api/match/{idk}/meta'
		resp = getlinkvnm(url, url)
		if (resp is not None) and ('.m3u8' in resp.text):
			kq = resp.json()
			kp = kq['data']['play_urls']
			for k in kp:
				item = Listitem()
				tenm = f'{k["name"]} - {title}'
				item.label = tenm
				item.info['plot'] = tb
				item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/90p.png'
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{stream(k["url"])}{referer(ref)}', tenm, '')
				yield item
		else:
			yield quangcao()
@Route.register
def xemlai_90p(plugin, pl=None, page=None, **kwargs):
	yield []
	if pl is None or page is None:
		pass
	else:
		url = f'https://api.vebo.xyz/api/news/mitom/list/{pl}/{page}'
		resp = getlink(url, ref, 1000)
		if (resp is not None):
			kq = resp.json()
			kl = kq['data']['list']
			if f:= kq['data']['highlight']:
				item = Listitem()
				item.label = f['name']
				item.info['plot'] = tb
				item.art['thumb'] = item.art['fanart'] = f['feature_image']
				item.set_callback(Resolver.ref('/resources/lib/kedon:list_re90'), f"https://api.vebo.xyz/api/news/mitom/detail/{f['id']}", ref, f['name'])
				yield item
			for k in kl:
				item1 = Listitem()
				item1.label = k["name"]
				item1.info['plot'] = tb
				item1.art['thumb'] = item1.art['fanart'] = k['feature_image']
				item1.set_callback(Resolver.ref('/resources/lib/kedon:list_re90'), f"https://api.vebo.xyz/api/news/mitom/detail/{k['id']}", ref, k["name"])
				yield item1
			item2 = Listitem()
			item2.label = f'Trang {page + 1}'
			item2.info['plot'] = tb
			item2.art['thumb'] = item2.art['fanart'] = f'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
			item2.set_callback(xemlai_90p, pl, page + 1)
			yield item2
		else:
			yield quangcao()
def create_list_item(k2, is_featured):
	item2 = Listitem()
	time = datetime.fromtimestamp(int(k2['timestamp'])/1000).strftime('%H:%M %d-%m')
	if k2['commentators']:
		tenm = f'{time}: {k2["name"]} ({k2["commentators"][0]["name"]})'
	else:
		tenm = f'{time}: {k2["name"]}'
	item2.label = tenm
	item2.info['plot'] = tb
	logotour2 = k2['tournament']['logo']
	if logotour2:
		item2.art['thumb'] = item2.art['fanart'] = logotour2
	else:
		item2.art['thumb'] = item2.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/vebo.png'
	item2.set_callback(list_90p, k2['id'], tenm)
	return item2