# -*- coding: utf-8 -*-
import os
import sys
import json
import time
import urllib.request
import re
import http.cookiejar
from urllib.parse import parse_qsl

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

# Πληροφορίες του Addon
ADDON_URL = sys.argv[0]
ADDON_HANDLE = int(sys.argv[1])
ADDON_PATH = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))

# -------------------------------------------------------------------
# ΕΦΕΔΡΙΚΑ LINKS (BACKUPS) ΓΙΑ ΤΑ LIVE
# -------------------------------------------------------------------
BACKUP_LINKS = {
    'live': 'https://mcdn.antennaplus.gr/live/media0/Ant1/HLS/Ant1.m3u8',
    'livemak': 'https://panel.gwebstream.eu:19360/tv100skg/720p.m3u8',
    'livecomedy': 'https://mcdn.antennaplus.gr/live/media0/Comedy/HLS/Comedy.m3u8',
    'livedrama': 'https://mcdn.antennaplus.gr/live/media0/Drama/HLS/Drama.m3u8'
}

# -------------------------------------------------------------------
# ΠΛΗΡΟΦΟΡΙΕΣ ΚΑΝΑΛΙΩΝ (ΚΑΘΑΡΑ ΕΛΛΗΝΙΚΑ)
# -------------------------------------------------------------------
CHANNEL_INFO = {
    'live': {'title': 'ANT1 Live', 'icon': 'ANT1_wite.png'},
    'livemak': {'title': 'MAK TV Live', 'icon': 'MAKEDONIA_TV_wite.png'},
    'livecomedy': {'title': 'ANT1 Comedy Live', 'icon': 'ANT1_comedy.png'},
    'livedrama': {'title': 'ANT1 Drama Live', 'icon': 'ANT1_drama.png'},
    'weather': {'title': 'ANT1 Δελτίο Καιρού', 'icon': 'ANT1_wite.png'}
}

# -------------------------------------------------------------------
# ΚΕΝΤΡΙΚΟ ΜΕΝΟΥ
# -------------------------------------------------------------------
def root():
    xbmcplugin.setPluginCategory(ADDON_HANDLE, 'ANT1 Player')
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    
    for channel_id, info in CHANNEL_INFO.items():
        title = info['title']
        icon_name = info['icon']
        
        list_item = xbmcgui.ListItem(label=title)
        
        icon_path = os.path.join(ADDON_PATH, 'media', icon_name)
        list_item.setArt({'icon': icon_path, 'thumb': icon_path})
        
        list_item.setInfo('video', {'title': title})
        list_item.setProperty('IsPlayable', 'true')
        
        if channel_id == 'weather':
            url = f"{ADDON_URL}?action=weather"
        else:
            url = f"{ADDON_URL}?action=play&url={channel_id}"
            
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, isFolder=False)
        
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

# -------------------------------------------------------------------
# ΛΗΨΗ ΣΗΜΕΡΙΝΟΥ ΚΑΙΡΟΥ (ΑΠΟΚΛΕΙΣΤΙΚΑ JSONPLAYER + HTTP TRICK)
# -------------------------------------------------------------------
def play_weather():
    ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    weather_page = 'https://www.antenna.gr/news/weather'
    
    try:
        html = urllib.request.urlopen(urllib.request.Request(weather_page, headers={'User-Agent': ua})).read().decode('utf-8')
        cid_match = re.search(r'cid=([^"\'&\\s]+)', html)
        if not cid_match: return
        
        cid = cid_match.group(1)
        api_url = f"https://nkv.antenna.gr/templates/data/jsonPlayer?cid={cid}"
        data = json.loads(urllib.request.urlopen(urllib.request.Request(api_url, headers={'User-Agent': ua, 'Referer': weather_page})).read().decode('utf-8'))
        
        stream_url = data.get('url')
        if stream_url:
            # Αφαίρεση HTTPS για να παίξει το mp4 χωρίς προβλήματα
            stream_url = stream_url.replace('https://', 'http://')
            
            # Δημιουργία ListItem για το Kodi
            li = xbmcgui.ListItem(path=stream_url)
            li.setInfo('video', {'title': data.get('title', 'Δελτίο Καιρού')})
            
            # Εδώ είναι το "κλειδί": δεν βάζουμε τίποτα άλλο, το αφήνουμε να το παίξει ο Player
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)
    except Exception as e:
        xbmc.log(f"WEATHER ERROR: {str(e)}", xbmc.LOGERROR)

# -------------------------------------------------------------------
# ΛΗΨΗ LIVE LINK
# -------------------------------------------------------------------
def get_live_url(channel_id):
    window = xbmcgui.Window(10000)
    cache_url_key = 'ant1_url_cache_' + channel_id
    cache_time_key = 'ant1_time_cache_' + channel_id
    
    cached_url = window.getProperty(cache_url_key)
    cached_time = window.getProperty(cache_time_key)
    current_time = time.time()
    
    if cached_url and cached_time:
        if (current_time - float(cached_time)) < 1800:
            return cached_url

    ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    
    cj = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    
    ref_page = 'Live' if channel_id == 'live' else channel_id
    main_url = f'https://www.antenna.gr/{ref_page}'
    
    try:
        req_main = urllib.request.Request(main_url)
        req_main.add_header('User-Agent', ua)
        req_main.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
        opener.open(req_main)
    except Exception:
        pass

    api_url = f'https://www.antenna.gr/templates/data/{channel_id}?cache={int(time.time() * 1000)}'
    req_api = urllib.request.Request(api_url)
    
    req_api.add_header('User-Agent', ua)
    req_api.add_header('Accept', 'application/json, text/javascript, */*; q=0.01')
    req_api.add_header('X-Requested-With', 'XMLHttpRequest')
    req_api.add_header('Origin', 'https://www.antenna.gr')
    req_api.add_header('Referer', main_url)
    
    try:
        with opener.open(req_api) as response:
            content = response.read().decode('utf-8')
            if content:
                data = json.loads(content)
                if data and 'url' in data:
                    fresh_url = data['url']
                    window.setProperty(cache_url_key, fresh_url)
                    window.setProperty(cache_time_key, str(current_time))
                    return fresh_url
    except Exception as e:
        xbmc.log(f"ANT1 Player API Error: {str(e)}", xbmc.LOGERROR)
        
    return None

# -------------------------------------------------------------------
# ΑΝΑΠΑΡΑΓΩΓΗ LIVE
# -------------------------------------------------------------------
def play(channel_id):
    if xbmc.Player().isPlaying():
        xbmc.Player().stop()
        xbmc.sleep(500)

    dynamic_url = get_live_url(channel_id)
    
    if dynamic_url:
        final_url = dynamic_url
    elif BACKUP_LINKS.get(channel_id):
        final_url = BACKUP_LINKS[channel_id]
    else:
        xbmcgui.Dialog().notification('ANT1 Player', 'Αποτυχία φόρτωσης ροής', xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
        return

    if 'm3u8' in final_url and '|' not in final_url:
        final_url += '|Referer=https://www.antenna.gr/&Origin=https://www.antenna.gr&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'

    play_item = xbmcgui.ListItem(path=final_url)
    
    info = CHANNEL_INFO.get(channel_id, {'title': 'ANT1 Channels', 'icon': 'ANT1_wite.png'})
    current_title = info['title']
    icon_path = os.path.join(ADDON_PATH, 'media', info['icon'])
    
    play_item.setArt({'icon': icon_path, 'thumb': icon_path, 'poster': icon_path})
    play_item.setInfo('video', {'title': current_title})
    
    if '.m3u8' in final_url:
        play_item.setMimeType('application/vnd.apple.mpegurl')
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')

    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=play_item)

# -------------------------------------------------------------------
# ROUTER
# -------------------------------------------------------------------
def router():
    param_string = sys.argv[2][1:]
    params = dict(parse_qsl(param_string))
    
    action = params.get('action')
    
    if action == 'play':
        play(params.get('url', 'live'))
    elif action == 'weather':
        play_weather()
    else:
        root()

if __name__ == '__main__':
    router()