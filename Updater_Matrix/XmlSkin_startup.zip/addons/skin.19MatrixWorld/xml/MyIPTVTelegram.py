﻿import xbmc, xbmcgui

def MyIPTVTelegram():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/get_remote_xcodes/https%3A%2F%2Fraw.githubusercontent.com%2Fakeotaseo%2Fworld_repo%2Fmain%2FUpdater_Matrix%2FXML%2F%257BAllTelegram%257D2.txt")')
    xbmcgui.Dialog().notification("[B]My[COLOR orangered]IPTV[/COLOR][/B]", "World build Telegram x-treme codes", sound=False, icon='https://styles.redditmedia.com/t5_28w7mp/styles/communityIcon_j5m34lvey9041.jpg')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B]My[COLOR orangered]IPTV[/COLOR][/B]", "World build Telegram x-treme codes", sound=False, icon='https://styles.redditmedia.com/t5_28w7mp/styles/communityIcon_j5m34lvey9041.jpg')
MyIPTVTelegram()
