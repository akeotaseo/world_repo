import xbmc, xbmcgui


def Error():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Error[/COLOR][/B]', 
['[B][COLOR blue]Προβολή σφαλμάτων στο Log[/COLOR][/B]',
 '[COLOR blue]Προβολή τελευταίου σφάλματος στο Log[/COLOR]',
 #'[B][COLOR blue]Ανέβασμα αρχείου Log[/COLOR][/B]'
 ])



    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 0



def click_1():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=viewerrorlog",return)')

def click_2():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=viewerrorlast")')

#def click_3():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=uploadlog")')
    
Error()
