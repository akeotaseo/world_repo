﻿from updatervar import *
import db


def addon_database():
    db.addon_database(Database_Addons33, 1, True)

Database_Addons33 = [('repository.Worldolympic', 'repository.World'),
                     ('repository.World', 'repository.World'),

                     ('script.module.jetextractors', 'repository.Worldolympic'),

                     ('plugin.video.watchnixtoons2', 'repository.Worldolympic'),
                     ('plugin.video.rumble', 'repository.Worldolympic'),
                     ('plugin.video.live.streamspro', 'repository.Worldolympic'),
                     ('plugin.video.macvod', 'repository.Worldolympic'),
                     ('plugin.video.rumble', 'repository.Worldolympic'),

                     ('plugin.program.downloader', 'repository.gkobu'),
                     ('plugin.video.duffyou', 'repository.gkobu'),
                     ('plugin.video.youtube', 'repository.gkobu'),
                     ('script.module.grs', 'repository.gkobu'),
                     ('script.extendedinfo', 'repository.gkobu'),
                     ('plugin.video.f4mTester', 'repository.gkobu'),
                     ('script.video.F4mProxy', 'repository.gkobu'),


                     ('script.module.html5lib', 'repository.xbmc.org'),
                     #('script.module.inputstreamhelper', 'repository.xbmc.org'),
                     ('script.module.inputstreamhelper', 'repository.slyguy'),


                     ('repository.StreamArmy', 'repository.StreamArmy'),
                     ('plugin.video.nemesisaio', 'repository.StreamArmy'),
                     ('script.module.nemzzyscrapers', 'repository.StreamArmy'),
                     ('script.module.webencodings', 'repository.StreamArmy'),
                     

                     ('plugin.program.simple.favourites', 'repository.Worldolympic'),

                     ('script.realdebridsite', 'repository.Worldolympic'),
                     ('service.World.Build', 'repository.Worldolympic'),
                     ('script.embuary.info', 'repository.Worldolympic'),


                     ('repository.twilight0', 'repository.twilight0'),
                     ('script.module.tulip', 'repository.twilight0'),


                     ('script.black.bars.never', 'repository.World'),
                     ('service.autohideosd', 'repository.World'),

                     ('plugin.video.dazn', 'repository.World'),

                     ('script.kelebek', 'repository.World'),
                     ('script.luar', 'repository.World'),
                     ('plugin.video.stalker', 'repository.World'),
                     ('plugin.video.daddylive', 'repository.World'),


                     ('repository.castagnait', 'repository.castagnait'),
                     ('context.themoviedb.helper', 'repository.jurialmunkey'),
                     ('script.module.jurialmunkey', 'repository.jurialmunkey'),


                     ('repository.cMaNWizard', 'repository.cMaNWizard'),
                     ('plugin.video.quicksilver', 'repository.cMaNWizard'),
                     ('script.module.quicksilverscrapers', 'repository.cMaNWizard'),
                     ('script.quicksilver.artwork', 'repository.cMaNWizard'),



                     ('repository.dab', 'repository.dab'),


                     ('repository.octopus', 'repository.octopus'),
                     ('repository.hasamba', 'repository.hasamba'),
                     ('repository.axbmcuser', 'repository.axbmcuser'),
                     ('repository.xtasyd', 'repository.xtasyd'),


                     ('repository.rays.files', 'repository.rays.files'),
                     ('repository.roooar', 'repository.dexe'),
                     ('repository.dexe', 'repository.dexe'),
                     ('plugin.video.BauBauVavoo', 'repository.dexe'),
                     ('plugin.video.GreenKlikPremium', 'repository.dexe'),




                     ('repository.chainsrepo', 'repository.chainsrepo'),
                     ('plugin.video.homelander', 'repository.chainsrepo'),
                     ('script.module.homelanderscrapers', 'repository.chainsrepo'),
                     ('script.homelander.artwork', 'repository.chainsrepo'),


                     ('repository.subskip', 'repository.subskip'),


                     ('repository.lekma', 'repository.lekma'),
                     ('plugin.video.invidious', 'repository.lekma'),

                     ('repository.diggz', 'repository.diggz'),
                     ('repository.matrix', 'repository.matrix'),
                     
                     

                     ('plugin.video.atlas', 'repository.atlas'),

                     ('repository.GMan', 'repository.Worldolympic'),
                     ('repository.deAIO', 'repository.Worldolympic'),

                     ('repository.Worldrepo', 'repository.World')]


addon_database()
