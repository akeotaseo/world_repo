﻿import xbmc
# Ρυθμίσεις
def videosettings():
    if xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin("Action(Close)")
        xbmc.executebuiltin("ActivateWindowAndFocus(systemsettings, -199,)")
        xbmc.sleep(100)
        xbmc.executebuiltin("ActivateWindowAndFocus(PlayerSettings)")
        xbmc.sleep(100)
    while xbmc.getCondVisibility("Window.IsVisible(PlayerSettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")



    if not xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin("Action(Close)")
        xbmc.sleep(100)
        xbmc.executebuiltin("ActivateWindowAndFocus(PlayerSettings)")
        
        xbmc.executebuiltin("Action(Pause)")
        xbmc.sleep(100)
    while xbmc.getCondVisibility("Window.IsVisible(PlayerSettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")




    xbmc.executebuiltin("Action(Play)")

videosettings()
