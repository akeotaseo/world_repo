﻿import os, xbmc, xbmcgui, webbrowser, xbmcaddon
def Backup():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('Action(Back)')
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('ActivateWindow(Home)')
    # xbmc.sleep(1000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση[/COLOR][/B]", "BlackGhost", sound=False, icon='http://addonbg.co/black/img/icon.png')
    xbmc.sleep(4000)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=http%3a%2f%2fbg-tv.xyz%2fblack%2fimg%2ffanart.jpg&mode=1&name=BlackGhost&url=http%3a%2f%2fgknwizard.eu%2frepo%2fBuilds%2fGKoBu%2fxmls%2fbglist")')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=http%3a%2f%2fbg-tv.xyz%2fblack%2fimg%2ffanart.jpg&mode=1&name=BlackGhost&url=http%3a%2f%2fgknwizard.eu%2frepo%2fBuilds%2fGKoBu%2fxmls%2fbglist")')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=http%3a%2f%2fbg-tv.xyz%2fblack%2fimg%2ffanart.jpg&mode=1&name=BlackGhost&url=http%3a%2f%2fgknwizard.eu%2frepo%2fBuilds%2fGKoBu%2fxmls%2fbglist")')


    #xbmc.executebuiltin('Action(Back)')
    #xbmc.executebuiltin('Dialog.Close(all,true)')
    #xbmc.sleep(1000)

Backup()