﻿import xbmc



xbmc.executebuiltin('PlayMedia("plugin://script.autoruns/?path=C%3A%5CPortableApps%5Ckodi%5CMy+kodi%5CKodi%5Cportable_data%5Caddons%5Cplugin.video.netflix%7Cservice.py&mode=1&name=Netflix+%5BB%5D%5BCOLOR+lime%5D%28Enabled%29%5B%2FCOLOR%5D%5B%2FB%5D")')