import base64
import re
import xbmcaddon
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

def Menu():
	r = OpenURL('http://etvserv.xyz:55337/enigma2.php?username=4qE8d78yk&password=BBpb8721su&type=get_live_streams&cat_id=7')
	m = re.compile('<channel>(.+?)</channel>').findall(r)
	for c in m:
		url = re.compile('<stream_url><!\[CDATA\[(.+?)\]\]></stream_url>').findall(c)[0]
		try: img = re.compile('<desc_image><!\[CDATA\[(.+?)\]\]></desc_image>').findall(c)[0]
		except: img = 'none'
		channel_name = re.compile('<title>(.+?)</title>').findall(c)[0]
		channel_name = base64.b64decode(channel_name)
		channel_name = channel_name.decode('utf-8')
		channel_name = channel_name.replace('\n', '').replace('\r', '').title()
		if '[' in channel_name: channel_name = re.compile('(.+?) \[').findall(channel_name)[0]
		channel_name = channel_name.strip()
	
		addVideo(channel_name.upper(), url, 1, img)
	