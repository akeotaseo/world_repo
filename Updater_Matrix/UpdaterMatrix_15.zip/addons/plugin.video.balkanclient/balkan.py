import xbmcgui
import xbmcplugin
import json
import urllib.request
import sys
import xbmcaddon
import urllib.parse
import random
import xbmc

addon = xbmcaddon.Addon()

JSON_URL = addon.getSetting('json_url')

def load_data_from_json():
    try:
        response = urllib.request.urlopen(JSON_URL)
        data = json.load(response)
        return data
    except Exception as e:
        xbmcgui.Dialog().ok('Greska', 'Greska u otvaranju liste. Provjerite vasu konekciju. Pokusajte ponovo.\n{}'.format(e))
        return None

def check_url(url):
    try:
        response = urllib.request.urlopen(url)
        return response.getcode() == 200
    except:
        return False

def show_countries_list():
    data = load_data_from_json()
    if not data:
        return
    
    for country in data['countries']:
        list_item = xbmcgui.ListItem(label=country['country'])
        icon_path = addon.getAddonInfo('path') + '/resources/icons/' + country['country'] + '.png'
        list_item.setArt({'icon': icon_path})
        url = '{0}?action=channels&country={1}'.format(sys.argv[0], country['country'])
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def show_channels_list(country):
    data = load_data_from_json()
    if not data:
        return
    
    for channel in data['channels']:
        if channel['country'] == country:
            list_item = xbmcgui.ListItem(label=channel['channel'])
            list_item.setArt({'thumb': channel['logo']})  
            list_item.setInfo('video', {'title': channel['channel']})  
            
            id1 = channel.get('id1')
            id2 = channel.get('id2')
            id3 = channel.get('id3')
            
            url = '{0}?action=play&id1={1}&id2={2}&id3={3}'.format(sys.argv[0], id1, id2, id3)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def play_channel(id1, id2, id3):
    data = load_data_from_json()
    if not data:
        return
    
    urls = data['urls']
    
    url_group = None
    
    if id1 is not None:
        url_group = 'urls1'
        chosen_id = id1
    elif id2 is not None:
        url_group = 'urls2'
        chosen_id = id2
    elif id3 is not None:
        url_group = 'urls3'
        chosen_id = id3
    else:
        xbmcgui.Dialog().ok('Greška', 'Nijedna lista nije pronadjena za ovaj kanal.')
        return
    
    url = random.choice(urls[url_group])
    
    channel_url = url + chosen_id
    
    logo = ''  
    channel_name = ''  
    
    for channel in data['channels']:
        if (url_group == 'urls1' and channel['id1'] == chosen_id) or \
           (url_group == 'urls2' and channel['id2'] == chosen_id) or \
           (url_group == 'urls3' and channel['id3'] == chosen_id):
            channel_name = channel['channel']
            logo = channel['logo']  
            break
    
    if not channel_name:
        xbmcgui.Dialog().ok('Greška', 'Izabrani kanal nije pronađen.')
        return
    
    list_item = xbmcgui.ListItem(channel_name)
    list_item.setArt({'thumb': logo})  
    list_item.setInfo('video', {'title': channel_name})  
    
    if check_url(channel_url):  
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=list_item)
        xbmc.Player().play(channel_url, list_item)
    else:
        xbmcgui.Dialog().ok('Izabrani stream link za ovaj kanal ne radi.', 'Pokrenite ponovo kanal da se izabere novi stream link.')

def run_addon():
    params = dict(urllib.parse.parse_qsl(sys.argv[2].replace('?', '')))
    action = params.get('action', None)
    
    if action is None:
        show_countries_list()
    elif action == 'channels':
        country = params['country']
        show_channels_list(country)
    elif action == 'play':
        id1 = params.get('id1')
        id2 = params.get('id2')
        id3 = params.get('id3')
        play_channel(id1, id2, id3)

if __name__ == '__main__':
    run_addon()
