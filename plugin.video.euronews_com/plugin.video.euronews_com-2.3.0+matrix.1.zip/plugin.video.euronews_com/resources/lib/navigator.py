﻿# -*- coding: utf-8 -*-

from .common import *


if not xbmcvfs.exists(os.path.join(dataPath, 'settings.xml')):
	xbmcvfs.mkdirs(dataPath)
	xbmc.executebuiltin(f"Addon.OpenSettings({addon_id})")

def mainMenu():
	debug_MS("(navigator.mainMenu) -------------------------------------------------- START = mainMenu --------------------------------------------------")
	debug_MS(f"(navigator.mainMenu) ### BASE_URL = {BASE_URL} ###")
	addDir(translation(30607), icon, {'mode': 'listTimeline', 'url': BASE_DROID+'/pages/timeline'})
	UNWANTED = ['/video', 'livingit', '/paidpost', 'partner']
	COMBI_ONE, COMBI_TWO, COMBI_REST = ([] for _ in range(3))
	content = getUrl(BASE_URL)
	results_1 = re.findall('<div class="js-programs-menu c-programs-menu c-header-sub-menu(.+?)<div class="c-programs-menu__footer', content, re.S)
	for chtml in results_1:
		debug_MS(f"(navigator.mainMenu[1]) xxxxx RESULT-01 : {str(chtml)} xxxxx")
		part = chtml.split('<div class="c-programs-menu')
		for i in range(1 ,len(part), 1):
			entry = part[i]
			if 'list-item__link' in entry:
				main_NAME = re.compile(r'class=["\']u-display-inline-block.*?>([^<]+?)(?:</a>|</span>)', re.S).findall(entry)[0]
				main_NAME = cleaning(main_NAME)
				NEW_URL = re.compile(r'<a href="([^"]+?)"\s*class=["\']u-display-inline-block', re.S).findall(entry)
				main_URL = NEW_URL[0] if NEW_URL else None
				if main_URL and any(x in main_URL.lower() for x in UNWANTED): continue
				debug_MS(f"(navigator.mainMenu[1]) ##### TITLE : {main_NAME} || URL : {str(main_URL)} || COMBINATION : {str(entry)} #####")
				COMBI_ONE.append(main_NAME.lower())
				COMBI_TWO.append([main_NAME, main_URL, entry])
	if COMBI_TWO:
		for title_one, news_one, elem in COMBI_TWO:
			addDir(title_one, icon, {'mode': 'SubTopics', 'url': elem, 'extras': news_one})
	results_2 = re.findall('<div class="c-menu-more c-header-sub-menu(.+?)<li class="js-programs_links list-item list-item', content, re.S)
	for item in results_2:
		match = re.compile(r' href="([^"]+?)" aria-label.*?>([^<]+?)(?:</a>|</span>)', re.S).findall(item)
		for link, title in match:
			rest_NAME = cleaning(title) if title not in ['', 'none', 'None'] else None
			rest_URL = link if link not in ['', 'none', 'None', None] else None
			COMBI_REST.append([rest_NAME, rest_URL])
	if COMBI_ONE and COMBI_REST:
		for title_two, news_two in COMBI_REST:
			if title_two and news_two and title_two.lower() not in COMBI_ONE and not any(z in news_two.lower() for z in UNWANTED):
				addDir(title_two, icon, {'mode': 'listVideos', 'url': news_two})
				debug_MS(f"(navigator.mainMenu[2]) ##### TITLE : {title_two} || URL : {news_two} #####")
	addDir(translation(30608), artpic+'livestream.png', {'mode': 'playLIVE'}, folder=False)
	if enableADJUSTMENT:
		addDir(translation(30609), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def SubTopics(first_LIST, first_PLUS):
	debug_MS("(navigator.SubTopics) -------------------------------------------------- START = SubTopics --------------------------------------------------")
	debug_MS(f"(navigator.SubTopics) ### first_LIST = {first_LIST} ### first_PLUS = {str(first_PLUS)} ###")
	UNIKAT = set()
	if first_PLUS not in ['', 'None', None]:
		addDir('NEWS', icon, {'mode': 'listVideos', 'url': first_PLUS})
	match = re.compile(r'<a href="([^"]+?)".*?list-item__link.*?>(.+?)</a>', re.S).findall(first_LIST)
	for sub_URL, sub_THEME in match:
		if sub_URL in UNIKAT:
			continue
		UNIKAT.add(sub_URL)
		sub_THEME = cleaning(sub_THEME).replace('\n', '')
		addDir(sub_THEME, icon, {'mode': 'listVideos', 'url': sub_URL, 'extras': sub_THEME})
		debug_MS(f"(navigator.SubTopics[1]) ##### TITLE : {sub_THEME} || URL : {sub_URL} #####")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVideos(url, CAT):
	debug_MS("(navigator.listVideos) -------------------------------------------------- START = listVideos --------------------------------------------------")
	debug_MS(f"(navigator.listVideos) ### START_URL = {url} ### CATEGORY = {str(CAT)} ###")
	SEND = {}
	COMBI_EPISODE, SEND['videos'] = ([] for _ in range(2))
	api_FOUND = False
	UNIKAT = set()
	NEW_URL = url if url.startswith('http') else 'https:'+url if url.startswith('//') else BASE_URL+url
	content = getUrl(NEW_URL) # https://de.euronews.com/api/program/state-of-the-union?before=1519998565&extra=1&offset=13
	match = re.findall('data-api-url="([^"]+)"', content, re.S)
	if match:
		API_URL, api_FOUND = match[-1], True
	else:
		if url.count('/') == 1:# WELT -> No Comment (url='/nocomment', KEINE 'data-api-url' vorhanden)
			API_URL, api_FOUND = BASE_URL+'/api/program'+url, True
		elif url.count('/') > 1 and '/program' in url:# WELT -> Euronews Witness (url='//de.euronews.com/programme/euronews-witness', KEINE 'data-api-url' vorhanden)
			API_URL, api_FOUND = BASE_URL+'/api/program/'+url.split('/')[-1], True
	if api_FOUND:
		URL_TWO = f"https:{API_URL}?extra=1&offset=0&limit=50" if API_URL.startswith('//') else f"{API_URL}?extra=1"
		debug_MS(f"(navigator.listVideos[1]) ### URL_TWO : {URL_TWO} ###")
		result = getUrl(URL_TWO, REF=BASE_URL)
		JS = json.loads(result, object_pairs_hook=OrderedDict)
		DATA = JS['articles'] if JS.get('articles', '') else JS
		for item in DATA:
			photo, Note_1, Note_2 = ("" for _ in range(3))
			startTIMES, aired, begins, duration, EURO_LINK, YOU_LINK = (None for _ in range(6))
			if isinstance(item, str):
				item = DATA[item]
			item = item['data'] if item.get('data', '') else item
			if len(item) == 0: continue
			debug_MS(f"(navigator.listVideos[2]) xxxxx ARTICLE-02 : {str(item)} xxxxx")
			episID = str(item['id']).replace('article-', '').replace('header-', '').strip() if item.get('id', '') else '00'
			name = cleaning(item['title'])
			if item.get('images', '') and item.get('images', {})[0].get('url', ''):
				photo = item['images'][0]['url'].replace('{{w}}x{{h}}', '1280x720') # OLD = 861x485
			if str(item.get('publishedAt')).isdigit():
				startTIMES = datetime.fromtimestamp(item['publishedAt']).strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('-', '•', ':')
				aired = datetime.fromtimestamp(item['publishedAt']).strftime('%d{0}%m{0}%Y').format('.') # FirstAired
				begins = datetime.fromtimestamp(item['publishedAt']).strftime('%d{0}%m{0}%Y').format('.') # 09.03.2023 / OLDFORMAT
				if KODI_ov20:
					begins = datetime.fromtimestamp(item['publishedAt']).strftime('%Y{0}%m{0}%dT%H{1}%M').format('-', ':') # 2023-03-09T12:30:00 / NEWFORMAT
			if startTIMES: Note_1 = translation(30610).format(startTIMES)
			Note_2 = cleaning(item.get('leadin', ''))
			if item.get('videos', '') and len(item['videos']) > 0:
				if 'duration' in str(item['videos']):
					duration = [int(vid.get('duration', [])) // 1000 for vid in item.get('videos', {})][-1]
				if 'url' in str(item['videos']):
					EURO_LINK = [vid.get('url', []) for vid in item.get('videos', {})][-1]
				if item.get('externalPartners', '') and item['externalPartners'].get('youtubeId', ''):
					YOU_LINK = item['externalPartners']['youtubeId']
			if EURO_LINK is None or EURO_LINK in UNIKAT:
				continue
			UNIKAT.add(EURO_LINK)
			uvz = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'playCODE', 'IDENTiTY': episID}))
			plot = Note_1+Note_2
			debug_MS(f"(navigator.listVideos[3]) ##### TITLE : {name} || THUMB : {photo} #####")
			debug_MS(f"(navigator.listVideos[3]) ##### YoutubeID : {str(YOU_LINK)} || VIDEO : {str(EURO_LINK)} || BEGINS : {str(begins)} #####")
			COMBI_EPISODE.append([uvz, episID, name, photo, EURO_LINK, YOU_LINK, plot, duration, aired, begins])
	if COMBI_EPISODE:
		for uvz, episID, name, photo, EURO_LINK, YOU_LINK, plot, duration, aired, begins in COMBI_EPISODE:
			LEM = xbmcgui.ListItem(name)
			if plot in ['', 'None', None]: plot = "..."
			if KODI_ov20:
				vinfo = LEM.getVideoInfoTag()
				vinfo.setTitle(name)
				vinfo.setPlot(plot)
				if str(duration).isdigit(): vinfo.setDuration(int(duration))
				if begins: LEM.setDateTime(begins)
				if aired: vinfo.setFirstAired(aired)
				if str(aired[6:10]).isdigit(): vinfo.setYear(int(aired[6:10]))
				vinfo.setGenres(['News'])
				vinfo.setStudios(['euronews'])
				vinfo.setMediaType('movie')
			else:
				vinfo = {}
				vinfo['Title'] = name
				vinfo['Plot'] = plot
				if str(duration).isdigit(): vinfo['Duration'] = duration
				if begins: vinfo['Date'] = begins
				if aired: vinfo['Aired'] = aired
				if str(aired[6:10]).isdigit(): vinfo['Year'] = aired[6:10]
				vinfo['Genre'] = 'News'
				vinfo['Studio'] = 'euronews'
				vinfo['Mediatype'] = 'movie'
				LEM.setInfo(type='Video', infoLabels=vinfo)
			LEM.setArt({'icon': icon, 'thumb': photo, 'poster': photo, 'fanart': defaultFanart})
			if photo and useThumbAsFanart and photo != icon and not artpic in photo:
				LEM.setArt({'fanart': photo})
			LEM.setProperty('IsPlayable', 'true')
			LEM.setContentLookup(False)
			xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=uvz, listitem=LEM)
			SEND['videos'].append({'filter': episID, 'url': EURO_LINK, 'name': name, 'transmit': YOU_LINK})
		with open(WORKFILE, 'w') as ground:
			json.dump(SEND, ground, indent=4, sort_keys=True)
	else:
		debug_MS("(navigator.listVideos) ##### Keine VIDEO-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30525).format('Videos'), translation(30526).format(str(CAT)), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listTimeline(url):
	debug_MS("(navigator.listTimeline) ------------------------------------------------ START = listTimeline -----------------------------------------------")
	debug_MS(f"(navigator.listTimeline) ### START_URL = {url} ###")
	SEND = {}
	COLLECTED, COMBI_FIRST, COMBI_LINKS, COMBI_SECOND, COMBI_THIRD, SEND['videos'] = ([] for _ in range(6))
	counter, content_2 = 0, ""
	content_1 = getUrl(url)
	DATA_ONE = json.loads(content_1)
	if DATA_ONE.get('pagination', '') and DATA_ONE['pagination'].get('next', '') and DATA_ONE['pagination']['next'].get('url', ''):
		NEXT_PAGE = DATA_ONE['pagination']['next']['url']
		if NEXT_PAGE.startswith('/pages/timeline') and NEXT_PAGE.endswith('slide=2'):
			SECOND = BASE_DROID+NEXT_PAGE
			debug_MS(f"(navigator.listTimeline) PAGES ### Now show NextPage : {SECOND} ### FOUND")
			content_2 = getUrl(SECOND)
	COLLECTED = '['+content_1+','+content_2+']'
	READY = json.loads(COLLECTED, object_pairs_hook=OrderedDict)
	debug_MS("++++++++++++++++++++++++")
	debug_MS(f"(navigator.listTimeline[1]) XXXXX CONTENT-01 : {str(READY)} XXXXX")
	debug_MS("++++++++++++++++++++++++")
	for each in READY:
		if each.get('pageContent', '') and len(each['pageContent']) > 0:
			for elem in each.get('pageContent', []):
				if elem.get('type', '') == 'justin' and elem.get('content', '') and len(elem['content']) > 0:
					for item in elem.get('content', []):
						debug_MS(f"(navigator.listTimeline[2]) no.02 xxxxx ITEM : {str(item)} xxxxx")
						THUMB_1, NOTE_1 = ("" for _ in range(2))
						startTIMES_1, AIRED_1, BEGINS_1 = (None for _ in range(3))
						counter += 1
						episID_1 = str(item['id']).replace('article-', '').replace('header-', '').strip() if item.get('id', '') else '00'
						TITLE_1 = cleaning(item['title'])
						if item.get('image', '') and item['image'].get('url', ''):
							THUMB_1 = item['image']['url'].replace('{{w}}x{{h}}', '1280x720') # OLD = 861x485
						if str(item.get('uts')).isdigit():
							startTIMES_1 = datetime.fromtimestamp(item['uts']).strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('-', '•', ':')
							AIRED_1 = datetime.fromtimestamp(item['uts']).strftime('%d{0}%m{0}%Y').format('.') # FirstAired
							BEGINS_1 = datetime.fromtimestamp(item['uts']).strftime('%d{0}%m{0}%Y').format('.') # 09.03.2023 / OLDFORMAT
							if KODI_ov20:
								BEGINS_1 = datetime.fromtimestamp(item['uts']).strftime('%Y{0}%m{0}%dT%H{1}%M').format('-', ':') # 2023-03-09T12:30:00 / NEWFORMAT
						if startTIMES_1: NOTE_1 = translation(30610).format(startTIMES_1)
						SHOWVIDEO_1 = (item.get('showVideo', False) or False)
						COMBI_FIRST.append([int(counter), episID_1, TITLE_1, THUMB_1, BEGINS_1, AIRED_1, NOTE_1, SHOWVIDEO_1])
						if item.get('link', '') and item['link'].get('url', ''):
							COMBI_LINKS.append(BASE_DROID+item['link']['url'])
	if COMBI_FIRST:
		COMBI_SECOND = getMultiData(COMBI_LINKS)
		if COMBI_SECOND:
			DATA_TWO = json.loads(COMBI_SECOND, object_pairs_hook=OrderedDict)
			#log("++++++++++++++++++++++++")
			#log(f"(navigator.listTimeline[3]) XXXXX CONTENT-03 : {str(DATA_TWO)} XXXXX")
			#log("++++++++++++++++++++++++")
			for elem in DATA_TWO:
				if elem is not None and elem.get('pageContent', '') and elem.get('pageContent', {})[0].get('content', ''):
					DESC_1, DESC_2 = ("" for _ in range(2))
					TAGLINE_2, DURATION_2, PLAYLINK_2 = (None for _ in range(3))
					debug_MS(f"(navigator.listTimeline[3]) xxxxx ELEM-03 : {str(elem)} xxxxx")
					SHORT = elem['pageContent'][0]['content'][0]
					LONGER = elem['pageContent'][2]['content'][0] if elem.get('pageContent', {})[2].get('content', '') else None
					markID_2 = str(SHORT['id']).replace('article-', '').replace('header-', '').strip() if SHORT.get('id', '') else '00'
					DESC_1 = SHORT.get('summary', '')
					if VIDEO_METAS is True and LONGER and LONGER.get('text', ''):
						TAG_2 = re.compile(r'</style></head>.+?<h2>(.*?)</h2>', re.S).findall(LONGER['text'])
						STORY_2 = re.findall(r'<p[^>]*>(.*?)</p>', LONGER['text'], re.S)
						if STORY_2:
							for snippet in STORY_2:
								DESC_2 = DESC_2+cleaning(snippet)+'[CR]'
						TAGLINE_2 = cleaning(TAG_2[0]) if TAG_2 else None
						if TAGLINE_2 and len(TAGLINE_2) > 125:
							TAGLINE_2 = TAGLINE_2[:125]+'...'
					if SHORT.get('video', ''):
						if elem.get('tracking', '') and elem['tracking'].get('adobe', '') and elem['tracking']['adobe'].get('customParams', ''):
							for entry in elem['tracking']['adobe']['customParams']:
								if 'videoduration' in entry.get('key', '') and str(entry.get('value')).isdigit():
									DURATION_2 = int(entry['value']) # Wird in Sekunden angezeigt
						YTID_2 = SHORT['video'].get('id', None)
						PLAYLINK_2 = (SHORT['video'].get('videoFallback', {}).get('url', '') or SHORT['video'].get('url', ''))
						COMBI_THIRD.append([markID_2, DESC_1, DESC_2, TAGLINE_2, DURATION_2, YTID_2, PLAYLINK_2])
	if COMBI_THIRD:
		RESULT = [a + b for a in COMBI_FIRST for b in COMBI_THIRD if a[1] == b[0]] # Zusammenführung von Liste1 und Liste2 - wenn die ID überein stimmt !!!
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.listTimeline[4]) XXXXX RESULT-04 : {str(RESULT)} XXXXX")
		#log("++++++++++++++++++++++++")
		for da in sorted(RESULT, key=lambda k: k[0], reverse=False):
			debug_MS("---------------------------------------------") ### Liste2 beginnt mit Nummer:8 ###
			debug_MS(f"(navigator.listTimeline[4]) no.04 ### Anzahl = {str(len(da))} || Eintrag : {str(da)} ###")
			episID, name, photo, begins, aired, Note_1, showVID = da[1], da[2], da[3], da[4], da[5], da[6], da[7]
			markID, Desc1, Desc2, tagline, duration, YOU_LINK, EURO_LINK = da[8], da[9], da[10], da[11], da[12], da[13], da[14]
			uvz = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'playCODE', 'IDENTiTY': episID}))
			FULL_DESC = Desc2 if len(Desc2) > len(Desc1) else Desc1 # FULL_DESC = DESC_2 if len(DESC_2) > len(DESC_1) else DESC_1
			plot = Note_1+FULL_DESC
			debug_MS(f"(navigator.listTimeline[5]) ##### TITLE : {name} || THUMB : {photo} #####")
			debug_MS(f"(navigator.listTimeline[5]) ##### showVID : {str(showVID)} || YoutubeID : {str(YOU_LINK)} || VIDEO : {str(EURO_LINK)} || BEGINS : {str(begins)} #####")
			if showVID is True and EURO_LINK:
				LSM = xbmcgui.ListItem(name)
				if plot in ['', 'None', None]: plot = "..."
				if KODI_ov20:
					vinfo = LSM.getVideoInfoTag()
					vinfo.setTitle(name)
					vinfo.setTagLine(tagline)
					vinfo.setPlot(plot)
					if str(duration).isdigit(): vinfo.setDuration(int(duration))
					if begins: LSM.setDateTime(begins)
					if aired: vinfo.setFirstAired(aired)
					if str(aired[6:10]).isdigit(): vinfo.setYear(int(aired[6:10]))
					vinfo.setGenres(['News'])
					vinfo.setStudios(['euronews'])
					vinfo.setMediaType('movie')
				else:
					vinfo = {}
					vinfo['Title'] = name
					vinfo['Tagline'] = tagline
					vinfo['Plot'] = plot
					if str(duration).isdigit(): vinfo['Duration'] = duration
					if begins: vinfo['Date'] = begins
					if aired: vinfo['Aired'] = aired
					if str(aired[6:10]).isdigit(): vinfo['Year'] = aired[6:10]
					vinfo['Genre'] = 'News'
					vinfo['Studio'] = 'euronews'
					vinfo['Mediatype'] = 'movie'
					LSM.setInfo(type='Video', infoLabels=vinfo)
				LSM.setArt({'icon': icon, 'thumb': photo, 'poster': photo, 'fanart': defaultFanart})
				if photo and useThumbAsFanart and photo != icon and not artpic in photo:
					LSM.setArt({'fanart': photo})
				LSM.setProperty('IsPlayable', 'true')
				LSM.setContentLookup(False)
				xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=uvz, listitem=LSM)
				SEND['videos'].append({'filter': episID, 'url': EURO_LINK, 'name': name, 'transmit': YOU_LINK})
		with open(WORKFILE, 'w') as ground:
			json.dump(SEND, ground, indent=4, sort_keys=True)
	else:
		debug_MS("(navigator.listTimeline[2]) ##### Keine TIMELINE-List - Kein Eintrag gefunden #####")
		return dialog.notification(translation(30525).format('Videos'), translation(30526).format('NEWS – TICKER'), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playLIVE():
	debug_MS("(navigator.playLIVE) -------------------------------------------------- START = playLIVE --------------------------------------------------")
	LIVE_URL, youtubeID, TEST_CODE = (False for _ in range(3))
	req_FIRST = f"https://www.euronews.com/api/live/data?locale={langDROID.replace('gr', 'el').replace('pe', 'fa')}" # https://www.euronews.com/api/live/data?locale=en
	content = getUrl(req_FIRST, method='TRACK')
	if content.status_code == 200 and re.search(r'"videoId":', content.text):
		youtubeID = content.json()['videoId']
		debug_MS(f"(navigator.playLIVE[1]) no.01 ***** youtubeID : {youtubeID} *****")
	TEST_CODE = youtubeID if youtubeID else channelLIVE if channelLIVE != '00' else False
	if TEST_CODE:
		log("(navigator.playLIVE[2]) no.02 ##### TRY -  TO - PLAY - VIA - YOUTUBE = YES #####")
		TEST_URL = getUrl('https://www.youtube.com/watch?v='+TEST_CODE, method='TRACK')
		if TEST_URL.status_code == 200 and re.search(r'"isLive":true', TEST_URL.text):
			LIVE_URL = f"plugin://plugin.video.youtube/play/?video_id={TEST_CODE}"
	else: log("(navigator.playLIVE[2]) no.02 ##### TESTING NOT FOUND - ACTION NOT SUCCESSFUL - SKIP #####")
	if LIVE_URL:
		debug_MS(f"(navigator.playLIVE) ### LIVE_URL : {LIVE_URL} ###")
		LTM = xbmcgui.ListItem(path=LIVE_URL, label=translation(30611))
		LTM.setMimeType('application/vnd.apple.mpegurl')
		xbmc.Player().play(item=LIVE_URL, listitem=LTM)
	else:
		failing("(navigator.playLIVE) ##### Abspielen des Live-Streams NICHT möglich #####\n ########## KEINEN Live-Stream-Eintrag auf der Webseite von *euronews.com* gefunden !!! ##########")
		return dialog.notification(translation(30521).format('LIVE', ''), translation(30527), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playCODE(IDD):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS(f"(navigator.playCODE) ### IDD = {IDD} ###")
	FINAL_URL = False
	with open(WORKFILE, 'r') as wok:
		ARRIVE = json.load(wok)
		for elem in ARRIVE['videos']:
			if elem['filter'] != '00' and elem['filter'] == IDD:
				FINAL_URL = elem['url']
				name = elem['name']
				youtubeID = elem['transmit']
				debug_MS(f"(navigator.playCODE[1]) no.01 ### WORKFILE-Line : {str(elem)} ###")
	if FINAL_URL:
		if preferTUBE is True:
			if youtubeID is None:
				log("(navigator.playCODE[2]) no.02 ##### SECOND - TRY -  TO - GET - youtubeID #####")
				content = getUrl(BASE_URL+'/embed/'+IDD).replace('\\', '').replace("&quot;", "\"")
				match = re.compile(r'"videoid":"([^"]+?)","youtubevideoid":"([^"]+?)",', re.S).findall(content)
				youtubeID = match[0][1] if match and match[0][0] == IDD and match[0][1] not in ['', 'none', 'None'] else None
			if youtubeID:
				log("(navigator.playCODE[2]) no.02 ##### TRY -  TO - PLAY - VIA - YOUTUBE = YES #####")
				TEST_URL = getUrl('https://www.youtube.com/oembed?format=json&url=http://www.youtube.com/watch?v='+youtubeID, method='TRACK')
				if TEST_URL.status_code == 200 and re.search(r'"provider_url":"https://www.youtube.com/"', TEST_URL.text):
					FINAL_URL = f"plugin://plugin.video.youtube/play/?video_id={youtubeID}"
		log(f"(navigator.playCODE) YTID : {str(youtubeID)} || StreamURL : {FINAL_URL}")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, xbmcgui.ListItem(path=FINAL_URL))

def addDir(name, image, params={}, plot=None, folder=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		vinfo = liz.getVideoInfoTag()
		vinfo.setTitle(name), vinfo.setPlot(plot), vinfo.setStudios(['euronews'])
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Studio': 'euronews'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and useThumbAsFanart and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)
