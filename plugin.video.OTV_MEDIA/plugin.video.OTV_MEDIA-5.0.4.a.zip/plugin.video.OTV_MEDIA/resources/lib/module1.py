import request
s = requests.Session()

import urllib as urllib2
import urllib


def captoken():
    UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36'
    key = "6Ldd07ogAAAAACktG1QNsMTcUWuwcwtkneCnPDOL"
    co = "aHR0cHM6Ly9icy50bzo0NDM."
    sa = ''
    lang = 'de'
    cb = 's5kxgdpbca0j'
    headers1 = {'user-agent':UA,
               'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
               'Content-Type':'application/x-www-form-urlencoded;charset=utf-8',
               'Referer':'https://bs.to/'
                }

    url1 = 'https://www.google.com/recaptcha/api.js'
    s = requests.session()
    req = s.get(url1, headers=headers1)
    #data = req.text
    data =to_utf8(req.text)
    v = re.findall("releases\/(.*?)\/", data)[0]

    url2 = "https://www.google.com/recaptcha/api2/anchor?ar=1&k=" + key + "&co=" + co + "&hl=de&v=" + v + "&size=invisible&cb=" + cb

    req = s.get(url2)
    data = req.text
    data = data.replace('\x22', '"')
   # logger.info("body : %s" % data)
    print("anchor.data----: %s" % data)
    c = re.findall("recaptcha-token.*?=(.*?)>", data)[0]

    vh = "12637701362"
    response="eyJyZXNwb25zZSI6IiIsInMiOiI5ZDc1IiwiZSI6ImJXMXZDS2cifQ.."
    vh = "12637701362"
    #bg = = "!A"
    #bg = "!8_Wg9fAKAAQeBEEZbQEHDwHKN4_T5XgjCesKV2jccFjc5UFBGOM1Nx5sv9oNU0ryuOvpxqOwu8aKTnESoxzrYyV2ZORFwibdx6_nQBkchNAkDXXhoPyO94svmBoA4Wh5WVu8g1vfMnxPUcWnwNLOAMRxu4g8QvNUF-dlGUZMxWTG2lS3sFx1dpJRzk7SF5J7EKC0zfrq5GvcOoegcyBkPlVv1oUL913IJvLPyov19fuFrT-8JwsQQtrEsyx97PQQ5fcO9651H0UxVbZtEFbglpJpo_Cuw1bTR8ccwLyQ1m5KtMObCUDCluQhhd7awW8enMabj1vcFMP05Mgr08Sk1OyRepNb2VzLrKJF0nDFKE9cYVg3Wys96e7X45gnBR1Svgxxfklhc6im6LrrJgSYAFjyspsLw4kB0fHcV7buC-ybeX32zB_ZJJiMyLcNfJMf5bEuId0FB3G_EVZwszQTCU7X4ZCEJ5bKReNMiPzqprnnyFPtvjrYKCFDj9NTJf7LuSGoIX0UP-riHT06la_BUI0zYHCWwpPTFH5wCjqpkC8BL6U9cNuR5fktNJ3SLRF5Ul-E5N_kPBjxgPPzW_DHQMiGm3CglpWoQEKJxVb7VJey58BqllplGfLLQzCcATZui5keFJfnDJAWcr2r5p-tkAQx4GaZWtVOxB72z7N0TLKvfl_TWJ0LBYLRHHAM-HCmdXKrkwAMBULS0DsPieDoDcYqLzBiAd_WmsGQcl3RCuXPTbSWUZqwFgz4aSSoGlTjavzuVZtQ_1E9_DZBgYmfhXhgvspWUiwcD5mHRGcanoeKfDCIzyq0JxZFuAdkLLuYmJZbKku5bTWp8HnFtF1OPqGlylcImGPSoMSHaE9rYkfdCipyjHFxZdo1s1Vg4DrGLph9ClTjBLqF4OLCPGzAO1XKfRs9SUTYSMXYjSSqsnDxcoj2ZKRkHwy_Dt65KOsTBU_Vn7EDIggYWuJ6wnpbt4qyp4UIrTxZLedr07vmRYHkyMPxBM8cVc3pYWdBbRq0IuI_gYstqEBEE6EwOBBjOkmOnFwz"
    _chr = urllib.parse.quote_plus("[39,16,26]")
    url3 = "https://www.google.com/recaptcha/api2/reload?k=" + key
#    post_data = {"6MY32oPwFCn9SUKWt8czDsDw¤03AKH6MRGA8hBCrz8xOjdpLkzTbN1YI0EiXHbrWyQvjJfAGNnTfPGCs6OF9Ou679QCYX-X58X8n3gLAXkmaD5YBLUn8irvrdzImZuTXZTR4jJyJI3TwUs2nA-9FofG4W_T0W3K0scOYHN9XVTloyArND6SkuF_z8m-3NZgcTEbQ31S_fL_dE-S-MJ1aCKJGVYOh0hKXe0Ld34UHGc5RhZ7tqixX3PeMYNaUopX7yU1V4mM5Ipi5qR9qS_acEYXQ3EfiGWWbG4XqDxqXTlTSmm8U4433SbwRl0qoJRU-KhVjXoobioSW-3ddC7pDKPmXWNh0FfX4hOe6ok2Jv1wZKmXpX9k9_MS4bS5SuYFO2b8NW5UHeEUOZEuKPq-gNiXwynOvLQQG_02m4D3LsmYIn4YzK9REvCGJCr7uskj6XOmdWOZn0jH96m2Awl8-ymJINrBBgf-j8gmydbR4eH-jsF0jCfxtaouDbS0JPfiLUmghBfT0LsL_jC4au3dhUOCaIfWRqByENUn1ODpTl2U5TU1tmpSx0JjQ97fs-QoQdDuU-x_9kHrBqVCWMU7vicZYl2qNYVMvdDt5bfUN94GP2bmkPiZwZLGuZChmksrThFU2PVe8rQGxn3C_D3k4Rg6YgeCyaDU6XsDkMIAArLKzZKZ9Hy-XBNcV9STiYV3iDXrxyEs4sesW-KVjcJ1vMXtMbXt9658rmhGCCKl7AnV8-qHz72mr2wIX-Iw8AZH7f7s622d1Y5W85eVPGsbb2pYTm6svZKIwZpqFgfODsFYzl91W9kUn0lXQLdeMwJIzjNpes8SL6cDo8iBfbrAbmvqz-Fe3FTep5eVY7ALhqACW1niMWmPof8Cvp37txUklposqjN4m3rJunOx7jSpnIh-4DCbNKrCCEcoKwXkhLK_h-csGN3PHAhvRdsgYn7Lbr6WeJhrhREd3ARUmzsreTT5lqJ5i8sybcjljDLBxF5mHJ1SkdCiIPdL6mOV5Ns2S6EN2GaHunyap7x8OQZaDljRdsMOYL4uaTCQNVo_dfObFkEErTbo5FodUjvA87xz5iy40gvXuc5oWEEohtYdUA3JAdt1aTHuw_GeUp2a0ny--yoCZumK8HhfaidqjilBDSsy77r1q14F50hoGiTOWYmKBlyYuiqYrYowLQ8E5A0acuWPzVQbUb5MgvXzAVy0X-ngsqhtOrFO3wHAWuGUitUc1FWDaBuwAkgOiY8o-PecSyfdiPgj6knHs3tO7LaMsUZYFEpOf5wvriglJKRJcCD8WBuSFrAJQNlIkYTOqc79CDyZNLupd-Ns3FzRmmCOG5jA1KVmAgVJnMMO9k0pv7bcW-MomN0uJk3VNsdC-UcSdpkM7amJNBsTmd5tu7e0Bxdb7Y3xvE7mDbVuTgYTk8RgVpzlsaHqkeDQ79Fb56lbdSlUnBcMwlJJsDgnDjObyjNNgwdMt9vWRy62puEhFsTA7MkjWFHGKHTXn8SeGi03MyE4UMOfMRKQRCD5ynpaTpJMYWTcbK1MuIdheyBvWdaJbm65YYxu1uGSPwc_sYSXC8M4N3kSSzz20WjzmQ[60,86,60]"Ç!W12gXVgKAAQeHqE4bQEHDwEOkPhbW6m_Vc8sTo1eI8AEaHOM6c0T-1YU2Q4aPr1Vj1kFQgJH-y3Uoj0AzP3FigIwwPHRs7SSyINdj_NyIfCJFBbC9xfWcm3ncEG-QIRiaYDxW5pX_XvzMQuAak_ZBW05NR5QU0MRwlkZCGEUyidhhNKCLQWKm2kPXaICD5V7YjwWSLSk3jQ02XqKlE4jRzZFO7fgAgZWbawz49pvMqzLjzKg1NSevzq7Vm2UYGk9GACwtoeDsolFIQEkpa02f7vrA3KEHq-K_uVO_DUbjtnGioWIRmWb83qjyUSNgaR98tfmB6hmuyjg0RVZHyXMAgIAWAyUPP7rdBXkX5j0r9LjdLRVzQwzAXwdChvynZqrnAFReAMgaQtbh0Sv9O02iFRqvCY043cRVv9tZC4jWIEYGOXja4jGmOTjoQk1a8cJ0PZtJcqTBtd7PAPuMg3qOOW3vaniKIBVO7aH49ZhizuarXNaKs0mrZSFHqgUyqAl5k7ZRcD-SQaZQ0s4ADjMWLUCa_HYay98KSyYaKBZIjWg-USyMkUB4UpaO59M_1f2c1ZwjZN6fXiMIdo04hjEGvz3PQYRYG5lv4a5nCFrAc55PzSuwmWu-VLDRUDk3AhZiaWt_QaeTvhvr4xCiPHzdeYnp9XnkiezdHk1YPAKd1tskRRqa10Y3Kwu0hQ695pKksyjUQv5NFbLsP_2Sk3iOXmMPlm6NOhLQk2Y19wpnvCclHl-BLXnA6ThmdjEJ_09EgKAhJ7JXQ-ajNddqbVElE1nIc9TNTjgsPoOvUwQ-C_zKPzspubfwYtVD8yhKc3sEAePRA*-807322225?Ì%02kiS0P41LKXjEUg_uPYkW1LLCTduZZLYQUx8peYkWosEQnCnnhdVg7qxKmiWzcQ9e6ng11COvPPqY6HPBv12tOIZEInH9SwjnNoIPzav7RtSSa-tM0dl1QQ4Tni-8l2OnsM-YXbB9CR2lfEqUHGw2it1mKMUR4qfzxg4fHzu9DBijwcjVL7P_1KTqecxNpy2-EZinL_2ElPMCjhvZt8dS4J58jBelYwFQ3GonxhWhLuyK2mXzsU-fKrh2FGPvfTrUU_G6TZAeecfHIupA_RgYdTuN2x4w_sbYYLOBEijs-AdZ43fBytUufkHbJ-bGFJbn8wpVGiu0hMwi94GCnuTwyIemqTxQ2eRwvcRcr_zBjKbtggvemnk-EWFwsQBP3nD7SM0r6sdWk3AuDA_krrKF2B10woqeMO88EGYzsdCVWGi3hpUg7XxMGaV-f9lY9oSGJfJ2RYxUpPRCkF2puIhVo7q8FZUy-QbbZW0ByxVsMYfd4O8xAVDf7HtGFSTyfhcYsjGPWuaouMfW4_G9jJxpt06QKakG2BZuNkQVay2-Upcf94nN2uCwwE2cKfWElGGvBoghoT7GUB_l9gUUIW56ydmm9EvNZuZEBxtdbbyL2eayQVEea8NE3l37gxhd6oCKX2G9Qgui9HgOGBVltQNRHmp5SRZju3zWVfO1FR2rdkYGlivwx8tj7P5No2fsegRUpDI_jploeAVR6mvFROKpNcWfY7ZywxIhLXvH1uazwJjac_NRGaZ4OAhXZnPCjRwr-QWeH7k4lmhtr7_O3er5RJOjcLyVlzCwDdxupzdGVSMxPAsa5_XNDqgnhU3eKXgGGeC4RtMf3fX5liPntM_eHq09f0-fLjnIFGNzAA4lZsB_3aX1OlnXMLJFVCT19U1f7ncAmxugsP_N3Wl3BdNhbz1IFyb0gVkatDORWyVze9kcab0Nk2kxOEnh57kAhpbmdUEPW6q6R1Wsrgxb53UyzEvpsQdXVGu5DR1Z9cJLUSMthUNTozE_zFhndwSSqWrEQ-GyPnrLGqi2BA_e7ruJYOJ7-1khafYSH-C-f82ednoMTaK3RpaULre8WaCu8sZfoPKBBd8pNMhT4LPEzdirM4ZRYaV-jhflb_dHlKlzR84cMHa93Bjy-ombnT09FhMxe72NJHOCgp_js4aI5OcAhxpo8DsJ0OwsgMxecbqCzaJxR0TVLbPIDlW0d09baLbHCmLba7wKF6Syvw4c6nUGE-B4edNS8IKHydopt0aS3u39iphv8U-fKrh2D48s_soPnrP7PQ1ca7iHE2GvPMoYJLWDECfpQsJgL34GU563fRPZorMABaUptwyL4neDTGJf-EkT5um1RdYhdYGS3OX5i8dmtP6EjaQsgYjhI7ZD1VusgEdO4W39UiCsvQNPo2u4vo1rOMZFobF8vJJg63eQTaBxxAbZoDgNRdYmsoEOXiq4BxNfsL2LouR9_VsmMvkWE_HA_Vyd5wCJ06PvAgxTMTZBzyVi8wIP3iz6RpRisf5KWuh2zY8oqAXMXSns_QwbJ3WB0OCuOpLUbe1LGevkdIOSYG55SFglc4pL6jmFEtCqKYdSm2u_zFNddL3NGayz_NAfrrdHmp2z-FCkYL_NzqmtOwXcG3g3lRdteILKpOrDh5ssq_4TIWYBS1qq70XRV948_4ymMr0PnaDtu8MYIfUF2VSpPMMbZ65G0FZp_bpYIPAyipkmMbzEVjExiVdjaIGQlmk4NQ3eIHmHiKixAQfOqXM3y9plenxPpnNEkdYiLr2PEm_8Qo6mLLyKzme8CUYbsHh-V9h1OAmVoKlHRaOnu71Z2Tb505asfTqXGbC4BJGd9boJ2KtsSFCapngQDOA0AgNUZrRHBmMwMoUdnvV5j94efcrR4yU5jlXabrvFkuw1SNAd7gNAkRywetJTrC8NWKIpQFINq7GAiRooM4oZXHICCpvirf2Rom9_w9Ie60VIGCl4Rw4aabiDFuUqs86grzB5UhrttbwR4KhAgZUqN4eL1Gi6PdiqprvIXl2yBpidcraN0arrRY0inngAjhw0vgCS6Xo6TRjlswCNFajCTlpfOgGI2OY-yAjbdLtPkqjvv9aj5bvBGqCo9kTdrW2DzBuoswXWGTN4jx4iskeMn-g7QpvhrXdTXiVxxE-YsPcMWN9uOIFYJPCGBWJmPg1Y4qv0jxbeb8dWY670hNObczaL0G67AtkhJLYK2R_nvFVVbPX_E-TkA00V6ndAA6IrrIqVIir9jJWjdjhTU6avDNKfLDqR1i26vYmapjtAUqOp9sEV5Xl3F2KgtnzRJGn8BdykMHmM2XG1hQqmKsFCFupx_MohZu8N0Kd2P48gZDz5VWQhNoJSpS2BQ90rLDrPpzT2TFlfcsINIuSrA4vW9LfKEN4stoMjY6yIFKW1dlFWaXn2BGGkf3cHVmXygUwdKsGDHJw5wlIe6_7IF6R2OwERYO_7idYlNMHPZyiCAZ9lPQ0OYi86h9LrOv1OGOZ0iYpitvhQkCcxSg2hbi_Pmtmq_UZZ6usJh6KxPkZTna38z53e78WMmSe1kJxhL71TmS30g0lkrIHE2yy4vVXTXvk61qQt-oNcn7D8TF4wvz9M5aU2QJKfb7jS4Ce6DRNeqPvJXx_yhAxasjRFyOXruMmf7Pq-ipiu-w6MGSsCQWChc4nMXeH8_RLh9_BAj56reoVUZDE-VlfxcM6XImyI0R6qvEqRYbh9xxUkKHiIlqSy_45b6XeCEyCthUbgX_2FDucktMPS3615iJhlcoqMJaUC0VKp7ggQ4TY_TVpnLYRVY7G8A1peM4CO2KWqCInYr684iNfnNQHNnKx5Rp6gObkW4e67CRlhsMcOmSs7h4rc9IWCIW8yB1XWaf2_kl81NRCYrWu6z5oyvX4bJqz8TNLiqLjIVaUx_YycaXZOkCmpBtEn4_uDntsvuwRfsfmKElsogcUf4fE9zNhs70iNoXY_iQ4hO_0OIG10SMrgMsDRVuCufRbdJn6Nlp8yuYHcpPb82Bgz-4xLpix9R9nltH_MVPABf50ZaLqJ1WaxQ41bK79_El4wQopVKqy6x5lk_chY6-n7D5IkOn6Mmmp6AB1nbH4AEF_tPIjVJDPAzeYngQCeX_RAldzyLr7N3On2w5Kib3wUliYzgQ0mpgPLY2D__NNos37GnKKrh4_h3a38y5nmMoGRXmrDhR6eNASLYDf7ytyv9b6RJqm_DJpVpfTEUWAt-YdW43C9DhuogEHbWvi_02Nx-BAdKu0HVSOtewgY3W17kNRkKQaI12n5SVCYa0ERj202vsDRIC87SRXk9IFPpuhBwV8p78UQn6d5jFfucMDWo66Ag1HeMfkBoKl7gY4UsT9J2B9vOdAL3Cs6hlZg7_-MWjHzTMxqNH7Upq99AAujt_lJV-A4_85kdPI-2ulxhNSVMDXDV-AyP__dGrFCU1oubgkSlrP7y85n8gCEIee5u9iocIFR0eLreNMaYL_F0x0u_wjdZnFEyhpoL8SYmLf1EZ-o84bH4ucxAlenpjOKXmzywA2j6-_MSyHytM9WL7JDR14n_0dSGbYBj2JncDqY0WGwv02bJnVC0KmrBIQh6UBOmODoBpBWZOyL0V4uPgue33G6kZllKbnI1-Qy_o2dajaPkSqqB9BncfzRT6qvflPYZ7TKy10ywo4UnG7Gjtpxv05QWiW0CKErsv_LYWI2hllU5TQC0R1p-MiVI3r8VeOxcMffrXkIFBCnPg5baLRxQYzebDnD4GH7etOpuLNHU2M8xldin_A7TpbzdM5N4_rLGCVyAs6JmeU2hFIcOIZH5DCBEJraZYCS4e09jVoTsDGLGOaqt0bU4e19Cdllsz_PnGw5RxJiLzyKmmT0gY9eq_dHFCIxvUnZprUDEZxsOQeVI27-i5opNYFRHiz7hxPjsL-NGqZ2AxIe7LjIlaTxQAtbKDcEUV3tuonX5bBADRzpN4LSn-08ChVlMkAOHWf3hNJgbbpKF2UzQUzcqfgF0t9vPErY5vHBjt0sOcRUIXA9C1bms8LP3il5BlVhbzvLmOf1Ao5eK3qHliDwvc1ZaPNDEF_teUXVovJ-i5hoNYKSnur6iBWjMP1NGqh1Q0_frTrJ1-JyP41bKTTEkiAtPAdXJLK_zhnptwWSYCx8CZgmtD7OnCq4RlFhLr1JmGPzgRAc6jZGE6Ku_gjYpjVCjxtrOMXTYi39i1intUBQHer6hxLisH3LWuV1AtCfrXfHlWOwvgpaJ_XEklzsukjVY29_DNun9QHRn248CNRkMcDOGqb2hJEfbvlJFyOzgEvbqbYFUZ5uPAjXZjDAjptq94NTIS49SxXls4COHeh4BhOhL3rKmKX0As1dKziGU5_vvYuY57JCEB4rOYTUorD9zJdnNQNRXin5h5YkMXxMGma1gg7erLtIVuFxP0wZZ3PDkd5s-gZWJHE_TVjotsQQ4Ct7CVbk8f3Nm-k4BBBgLnwJ1-LygM7caXVFE2Gt_AfXpfPATxpqOEaUYSz8ixclM_9PHan5hhHhsDyMGWR0Ao9erDbGlSHwfslZJ7SCURvrugdUoe5-DJnodkDQnyx6RtNjMb8L2eX1hBHeLfhIFqRyf0raqTbD0t1tO4mVo-__jhxpN4JSIK76ylTks38PG-d3BdIgrjnJmGTzv4xcKvcGUt7uvUpW5LFBD9zrOEPTom98SpZmNMHQXGj4h1Sh8HtLGed0QQ3drHoGVaBwPMxZJr8Aj952N5XlcP68Wqo1g0EaqGy5htUibz8MGad3AZGeq_tJoGHv_pdY9waSH927y1bkokCQG6lzQQ2fir(6Ldd07ogAAAAACktG1QNsMTcUWuwcwtkneCnPDOL"}
    post_data = {"v":v,
	               #"reason":"fi",
	               "c":c,
	               "k":key,
	              # "co":co,
	              # "hl":"en",
	               #"size":"invisible",
	              # "chr":_chr,
	               #"vh":vh,
	               #"vh":vh,
	              # "bg":bg
	               }

    headers = {'user-agent':UA,
               'Cookie':'__Secure-3PAPISID/,__Secure-3PSID/,__Secure-3PSIDCC/,__Secure-ENID/,_Secure-1PAPISID/,__Secure-1PSID/,__Secure-1PSIDCC/,__Secure-ENID/',
               'Accept':'*/*',
               'Content-Type':'application/x-www-form-urlencoded;charset=utf-8',
               'Referer':url2
                }
    #cap_data = dict(v=vvv , reason=reason, c=c, k=k, co=co, hl=hl, size=size, sa=sa, chr=chr, vh=vh, bg=bg)
    req_url3 = s.post(url3, data=post_data, headers=headers)
    #html = req_url3.text
    html =to_utf8(req_url3.text)
    token3 = re.search(r'"rresp","(.*?)",', html)
    print("reload.html----: %s" % html)
    print("reload.html----: %s" % token3)

if __name__ == '__main__':
  captoken()