import xbmc, xbmcaddon
from updatervar import *

def Livetv_setMj_on ():
    addon_microjen       = xbmcaddon.Addon('plugin.video.microjen')
    setting_microjen     = addon_microjen.getSetting
    setting_set_microjen = addon_microjen.setSetting
    if not setting_microjen('enable_ace_links')=='true':
        xbmc.sleep(1000)
        setting_set_microjen('enable_ace_links', 'true')



Livetv_setMj_on ()
