import xbmc, xbmcgui




xbmcgui.Dialog().notification("[B][COLOR blue]Ex[/COLOR]-[COLOR red]Yu[/COLOR][/B] m3u8", "[COLOR orange]http://tv.premiumplus.tv:80[/COLOR]", sound=False, icon='https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Former_Yugoslavia_Flag_Map_%28With_Kosovo%29.png/1205px-Former_Yugoslavia_Flag_Map_%28With_Kosovo%29.png')
xbmc.sleep(3000)
xbmcgui.Dialog().notification("[B][COLOR green]lists / Channels[/COLOR][/B]", "[COLOR orange]They don't always work[/COLOR]", sound=False, icon='special://home/addons/plugin.video.playlistloaderworld/local/doestworkalltime.png')
xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloaderworld/?cache=0&epg&iconimage=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloaderworld%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bex%5d&url=special%3a%2f%2fhome%2faddons%2fplugin.video.playlistloaderworld%2flocal%2fEx-Yu.m3u8&uuid=afd6453a-9192-4501-94d0-e891ee109db5")')
