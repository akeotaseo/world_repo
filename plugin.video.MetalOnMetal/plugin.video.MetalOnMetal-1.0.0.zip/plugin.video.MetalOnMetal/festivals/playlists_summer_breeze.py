import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_festivals


setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="

id_YEAR_2019 = "PLGuhlLazJwGtzJ35j2DR2ex37FF3deNAY" 
id_YEAR_2018 = "PLGuhlLazJwGuZ4nfBggf5FuJCGqzzOv93" 
id_YEAR_2017 = "PLGuhlLazJwGvWHxUet6WD9xOrOz_Dof4P" 
id_YEAR_2005 = "PLGuhlLazJwGvZete56hgSqUUu2tuknT2f" 
id_YEAR_2002 = "PLGuhlLazJwGte_CIsxhidwnqoj4pIHdDD" 

if usa_duffyou:  ##Usamos plugin Duff You
    YEAR_2002 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2002).encode('utf-8')).decode('utf-8')
    YEAR_2005 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2005).encode('utf-8')).decode('utf-8')
    YEAR_2017 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2017).encode('utf-8')).decode('utf-8')
    YEAR_2018 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2018).encode('utf-8')).decode('utf-8')
    YEAR_2019 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2019).encode('utf-8')).decode('utf-8')
    
    # = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_).encode('utf-8')).decode('utf-8')

else:  ##Usamos pluin YouTube
	YEAR_2002 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2002)
	YEAR_2005 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2005)
	YEAR_2017 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2017)
	YEAR_2018 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2018)
	YEAR_2019 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2019)

    # =  youtube.replace("MI-ID-PLAYLIST" , id_)


def playlists(params):
    logo=logos_festivals.summer_breeze(params)
    
    plugintools.add_item( 
        title="Summer Breeze Festival 2019",
        url=YEAR_2019,
        thumbnail=logo, folder=True )
 
    plugintools.add_item( 
        title="Summer Breeze Festival 2018",
        url=YEAR_2018,
        thumbnail=logo, folder=True )
 
    plugintools.add_item( 
        title="Summer Breeze Festival 2017",
        url=YEAR_2017,
        thumbnail=logo, folder=True )
 
    plugintools.add_item( 
        title="Summer Breeze Festival 2005",
        url=YEAR_2005,
        thumbnail=logo, folder=True )

    plugintools.add_item( 
        title="Summer Breeze Festival 2002",
        url=YEAR_2002,
        thumbnail=logo, folder=True )

 
