import urllib
import urllib.error
import urllib.parse
import urllib.request
import re
import xbmcplugin
import xbmcgui
import os
import sys
import datetime
import string
import xbmcaddon
import base64
import xbmc
import xbmcvfs
import xbmcgui

fanart = 'special://home/addons/plugin.video.xxx/fanart.jpg'
setting = xbmcaddon.Addon('plugin.video.xxx')

def AddFavourites(url, name, iconimage):
	file = xbmcvfs.translatePath(os.path.join('special://userdata/addon_data/plugin.video.xxx', 'favourites.xml'))
	entry = '<i title="%s" icon="%s" url="%s" />\n' % (name, iconimage, url)
	AppendFile(file, entry)

def RemoveFavourites(url, name, iconimage):
	file = xbmcvfs.translatePath(os.path.join('special://userdata/addon_data/plugin.video.xxx', 'favourites.xml'))
	favs = OpenFile(file)
	entry = '<i title="%s" icon="%s" url="%s" />' % (name, iconimage, url)
	new = favs.replace(entry, '')
	WriteFile(file, new)
	
def OpenFile(file):
	data = open(file, 'r', encoding='utf-8')
	data = data.read()
	return data

def WriteFile(file, entry):
	f = open(file, 'w', encoding='utf-8')
	f.write(entry)
	f.close()

def AppendFile(file, entry):
	f = open(file, 'a', encoding='utf-8')
	f.write(entry)
	f.close()
	
def Play(url):
	resolved = url
	item     = xbmcgui.ListItem(path=resolved)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
	
def OpenURL(url):
	req      = urllib.request.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11')
	response = urllib.request.urlopen(req)
	link     = response.read()
	response.close()
	link     = link.decode('utf-8')
	return link
	
def addVideo(name,url,mode,iconimage):
	file = xbmcvfs.translatePath(os.path.join('special://userdata/addon_data/plugin.video.xxx', 'favourites.xml'))
	if not os.path.exists(file): WriteFile(file, '')
	u  = sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
	ok = True
	liz = xbmcgui.ListItem(name)
	liz.setArt({'icon': iconimage, 'thumb': iconimage})
	liz.setInfo('video', {'Title': name})
	liz.setProperty("IsPlayable","true")
	
	try:
		favs = OpenFile(file)
		cm = []
		if '&random' in url:
			check = re.compile('(.+?)&random').findall(url)[0]
		else:
			check = url
		if check not in favs: cm.append(('Add to Recommendations', 'PlayMedia(plugin://plugin.video.xxx/?url=%s&mode=3&name=%s&iconimage=%s)' % (url, name, iconimage)))
		else: cm.append(('Remove from Recommendations', 'PlayMedia(plugin://plugin.video.xxx/?url=%s&mode=4&name=%s&iconimage=%s)' % (url, name, iconimage)))
		liz.addContextMenuItems(cm)
	except:
		pass
	
	ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

def addDir(name,url,mode,iconimage):
	u = sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
	ok=True
	liz = xbmcgui.ListItem(name)
	liz.setArt({'icon': iconimage, 'thumb': iconimage})
	liz.setProperty("IsPlayable","false")
	ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
	
def addTask(name, url, mode, iconimage):
    u = sys.argv[0] + "?url=" + urllib.parse.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.parse.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name)
    liz.setArt({'icon': iconimage, 'thumb': iconimage})
    liz.setProperty("IsPlayable","false")
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def SetView():
	Setting = xbmcaddon.Addon().getSetting
	if Setting('custom_view') == 'true':
		xbmc.executebuiltin('Container.SetViewMode(%s)' % str(Setting('custom_view_id')))