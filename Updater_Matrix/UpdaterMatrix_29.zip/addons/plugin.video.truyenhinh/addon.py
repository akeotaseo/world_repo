from urllib.parse import urlencode, parse_qsl, unquote, urlparse
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
import re, sys, xbmcgui, urlquick
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
ICON = Addon().getAddonInfo('icon')
UA = 'OTT Navigator/1.7.1.6 (Linux; Android 14; Pixel 9 Pro Build/AP4A.241212) ExoPlayerLib/2.19.1'
sre1 = re.compile(r'\n((http|https|udp|rtp|acestream):(.*?)\n)')
sre2 = re.compile(r'[,](?!.*[,])(.*)')
sre3 = re.compile(r'group-title="(.*?)"')
sre4 = re.compile(r'tvg-logo="(.*?)"')
sre5 = re.compile(r'http-user-agent=(.*?)\n')
sre6 = re.compile(r'http-referrer=(.*?)\n')
sre7 = re.compile(r'license_key=(.*?)\n')
def addDir(title, logo, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': logo, 'thumb': logo, 'poster': logo, 'fanart': logo})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlinkip(url, ref):
    r = urlquick.get(url, timeout=30, max_age=1000, headers={'user-agent': UA,'accept-encoding':'gzip','referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}/'
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        T = {'Truyền hình FPT1': 'https://raw.githubusercontent.com/ntd249/ntdiptv/main/fptudp',
            'Truyền hình FPT2': 'https://raw.githubusercontent.com/thanh51/repository.thanh51/master/ONETV.m3u',
            'CV Media': 'https://cvtv.xyz',
            'DakLakTV': 'https://raw.githubusercontent.com/luongtamlong/Dak-Lak-IPTV/main/daklakiptv.m3u',
            'VietNgaTV': 'https://raw.githubusercontent.com/phuhdtv/vietngatv/master/vietngatv.m3u',
            'VMTTV': 'https://dl.dropboxusercontent.com/s/7rj3pwr5b48ce3u/vmttv.txt?dl=0',
            'Khang IPTV': 'http://khanggtivi.xyz/iptv',
            'TV360': 'https://tth.vn/tv360',
            'Truyenhinhclick': 'https://tv.truyenhinh.click',
            'CaLemGTV': 'https://raw.githubusercontent.com/KevinNitroG/Entertainment/m3u/playlists/calemtv.m3u',
            'HaNoiIPTV': 'https://raw.githubusercontent.com/HaNoiIPTV/HaNoiIPTV.m3u/master/Danh%20s%C3%A1ch%20k%C3%AAnh/G%C3%B3i%20ch%C3%ADnh%20th%E1%BB%A9c/H%C3%A0%20N%E1%BB%99i%20IPTV.m3u',
            'AXT 4K Sport': 'https://raw.githubusercontent.com/MrToBun007/AXT/main/4K-UHD.m3u',
            'AlexDang 4K Sport': 'https://raw.githubusercontent.com/kgasaz/4kuhd/master/sports-channels-4k.m3u',
            '4K UHD TV': 'https://raw.githubusercontent.com/kgasaz/4kuhd/master/sports-channels-4k.m3u',
            'IPTV-ORG All': 'https://iptv-org.github.io/iptv/index.m3u',
            'IPTV-ORG Category': 'https://iptv-org.github.io/iptv/index.category.m3u',
            'IPTV-ORG Language': 'https://iptv-org.github.io/iptv/index.language.m3u',
            'IPTV-ORG Country': 'https://iptv-org.github.io/iptv/index.country.m3u',
            'IPTV-ORG Region': 'https://iptv-org.github.io/iptv/index.region.m3u'
            }
        for k in T:
            addDir(k, ICON, 'list_iptv', id=T[k])
        endOfDirectory(HANDLE)
    elif params['mode'] == 'list_iptv':
        url = params['id']
        addDir('TẤT CẢ CÁC KÊNH', ICON, 'little_iptv', id=url)
        texturl = getlinkip(url, url).text
        group = re.findall(r'group-title="(.*?)"', texturl)
        ld = list(dict.fromkeys(group))
        um = []
        um = [k for tk in ld for k in (tk.split(';') if ';' in tk else [tk]) if k != '' and k not in um]
        for p in um:
            addDir(p, ICON, 'info_iptv', id=url, tk=p)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'info_iptv':
        url = params['id']
        tk = params['tk']
        texturl = getlinkip(url, url).text
        ketqua = re.sub(r'(#EXTM3U|#[^EX|^KODI])(.*)', '', texturl).split('#EXTINF')
        for kq in ketqua:
            s1 = sre1.search(kq)
            s2 = sre2.search(kq)
            s4 = sre4.search(kq)
            s5 = sre5.search(kq)
            s6 = sre6.search(kq)
            s7 = sre7.search(kq)
            logo = s4[1] if s4 else ICON
            user = s5[1] if s5 else UA
            ref = s6[1] if s6 else None
            if s1 and s2 and any(((not s7 and f'group-title="{tk}"' in kq and ';' not in kq), (tk in kq and ';' in kq))):
                addDir(s2[1], logo, 'play', id=s1[1], ref=ref, user=user, is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'little_iptv':
        url = params['id']
        texturl = getlinkip(url, url).text
        ketqua = re.sub(r'(#EXTM3U|#[^EX|^KODI])(.*)', '', texturl).split('#EXTINF')
        for kq in ketqua:
            s1 = sre1.search(kq)
            s2 = sre2.search(kq)
            s3 = sre3.search(kq)
            s4 = sre4.search(kq)
            s5 = sre5.search(kq)
            s6 = sre6.search(kq)
            s7 = sre7.search(kq)
            nhomkenh = s3[1] if s3 else 'TỔNG HỢP'
            logo = s4[1] if s4 else ICON
            user = s5[1] if s5 else UA
            ref = s6[1] if s6 else None
            if s1 and s2 and not s7:
                tenm = f'{s2[1]} - {nhomkenh}'
                addDir(tenm, logo, 'play', id=s1[1], ref=ref, user=user, is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'play':
        play_item = xbmcgui.ListItem(offscreen=True)
        linkplay = re.sub(r'\s+', '%20', params['id'].strip(), flags=re.UNICODE)
        user = unquote(params.get('user', UA))
        if 'm3u8' in linkplay:
            hdr = f'verifypeer=false&User-Agent={user}'
            if params.get('ref'):
                hdr += f'&Referer={referer(params["ref"])}'
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
            play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
            play_item.setPath(linkplay)
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
if __name__ == '__main__':
    router(sys.argv[2][1:])