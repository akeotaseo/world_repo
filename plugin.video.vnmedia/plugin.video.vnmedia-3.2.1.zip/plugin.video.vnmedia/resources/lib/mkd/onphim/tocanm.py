from codequick import Route, Listitem, Resolver, Script
from resources.lib.kedon import __addonnoti__, __addonname__, getlink, getlinkvnm, quangcao, tb
from concurrent.futures import ThreadPoolExecutor, as_completed
from xbmcgui import DialogProgress
from urllib.parse import quote_plus
from bs4 import BeautifulSoup
from functools import lru_cache
import re
x = 'https://tocanime.co'
@lru_cache(maxsize=None)
def get_info_tocanm(x):
	r = getlinkvnm(x,x)
	try:
		soup = BeautifulSoup(r.content, 'html.parser')
		soups = soup.select('div.col-md-9')
		for k in soups:
			try:
				img = k.select_one('div.movie-thumb img.mb20')['data-original']
			except:
				img = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/tocanm.png'
			try:
				title = k.select_one('div.movie-title-box h1').get_text(strip=True)
				name2 = k.select_one('div.movie-title-box p').get_text(strip=True)
				ten = f'{title} - {name2}'
			except:
				ten = __addonname__
			try:
				mota = k.select_one('div.box-content').get_text(strip=True)
			except:
				mota = tb
			return (ten, img, mota)
	except:
		return None
@lru_cache(maxsize=None)
def process_url(url):
	try:
		data = get_info_tocanm(url)
		return url, data
	except:
		return url, None
@Route.register
def search_tocanm(plugin, search_query=None, **kwargs):
	yield []
	if search_query is None:
		pass
	else:
		dialog = DialogProgress()
		dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
		next_page = 0
		sr = quote_plus(search_query)
		url = f'{x}/content/search?t=kw&q={sr.replace(" ","+")}&p={next_page}'
		r = getlink(url, url, 1800)
		if (r is not None) and ('col-lg-3' in r.text):
			soup = BeautifulSoup(r.content, 'html.parser')
			soups = soup.select('div.row div.card-item-content a')
			urls = [k['href'] for k in soups]
			length = len(urls)
			if length>0:
				count = 0
				with ThreadPoolExecutor(length) as ex:
					future_to_url = (ex.submit(process_url, url) for url in urls)
					ac = as_completed(future_to_url)
					for k in ac:
						l, data = k.result()
						if data is not None:
							if (dialog.iscanceled()):
								break
							count += 1
							done = int((count/length)*100)
							dialog.update(done, f'Đang giải mã {length} dữ liệu...\nLoading... [COLOR yellow]{done} %[/COLOR]')
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = data[2]
							item.info['mediatype'] = 'movie'
							item.art['thumb'] = item.art['fanart'] = data[1]
							item.set_callback(episode_tocanm, l, data[0], data[2], data[1])
							yield item
				if f'&p={str(int(next_page) + 1)}' in r.text:
					item1 = Listitem()
					item1.label = f'Trang {str(int(next_page) + 2)}'
					item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
					item1.set_callback(ds_tocanm, f'{x}/content/search?t=kw&q={sr.replace(" ","+")}', next_page + 1)
					yield item1
		else:
			Script.notify(__addonnoti__, 'Không tìm thấy kết quả')
			yield quangcao()
		dialog.close()
@Route.register
def index_tocanm(plugin, **kwargs):
	yield Listitem.search(search_tocanm)
	dulieu = {
	'Phim mới': f'{x}/content/search?t=ft&gr=&nt=&y=&mt=',
	'Phim bộ': f'{x}/content/search?t=ft&gr=&nt=&y=&mt=tvshow',
	'Chiếu rạp': f'{x}/content/search?t=ft&gr=&nt=&y=&mt=cinema',
	'Hoạt hình Trung Quốc': f'{x}/content/search?t=ft&gr=&nt=CN&y=&mt=',
	'Anime tình cảm': f'{x}/content/search?t=ft&gr=romance&nt=&y=&mt=',
	'Anime hành động': f'{x}/content/search?t=ft&gr=action&nt=&y=&mt='
	}
	yield Listitem.from_dict(**{'label': 'Thể loại',
	'info': {'plot': tb},
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/tocanm.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/tocanm.png'},
	'callback': tocanm_tl})
	yield Listitem.from_dict(**{'label': 'Quốc gia',
	'info':{'plot':tb},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/tocanm.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/tocanm.png'},
	'callback': tocanm_qg})
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.info['plot'] = tb
		item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/tocanm.png'
		item.set_callback(ds_tocanm, dulieu[k], 0)
		yield item
@Route.register
def tocanm_tl(plugin, **kwargs):
	dulieu = {
		'Tất cả': f'{x}/content/search?t=ft&gr=&nt=&y=&mt=',
		'18+': f'{x}/content/search?t=ft&gr=r18&nt=&y=&mt=',
		'Đam mỹ': f'{x}/content/search?t=ft&gr=boylove&nt=&y=&mt=',
		'Âm nhạc': f'{x}/content/search?t=ft&gr=music&nt=&y=&mt=',
		'Bách hợp': f'{x}/content/search?t=ft&gr=girllove&nt=&y=&mt=',
		'Blu-ray': f'{x}/content/search?t=ft&gr=blu-ray&nt=&y=&mt=',
		'Car': f'{x}/content/search?t=ft&gr=car&nt=&y=&mt=',
		'Cartoon': f'{x}/content/search?t=ft&gr=cartoon&nt=&y=&mt=',
		'Coming of age': f'{x}/content/search?t=ft&gr=coming-of-age&nt=&y=&mt=',
		'Cổ trang': f'{x}/content/search?t=ft&gr=historical-drama&nt=&y=&mt=',
		'Demon': f'{x}/content/search?t=ft&gr=demon&nt=&y=&mt=',
		'Dị giới': f'{x}/content/search?t=ft&gr=parallel-worlds&nt=&y=&mt=',
		'Doujinshi': f'{x}/content/search?t=ft&gr=doujinshi&nt=&y=&mt=',
		'Drama': f'{x}/content/search?t=ft&gr=drama&nt=&y=&mt=',
		'Ecchi': f'{x}/content/search?t=ft&gr=ecchi&nt=&y=&mt=',
		'Game': f'{x}/content/search?t=ft&gr=game&nt=&y=&mt=',
		'Hài hước': f'{x}/content/search?t=ft&gr=comedy&nt=&y=&mt=',
		'Hành động': f'{x}/content/search?t=ft&gr=action&nt=&y=&mt=',
		'Harem': f'{x}/content/search?t=ft&gr=harem&nt=&y=&mt=',
		'Hentai': f'{x}/content/search?t=ft&gr=hentai&nt=&y=&mt=',
		'Học đường': f'{x}/content/search?t=ft&gr=school&nt=&y=&mt=',
		'Josei': f'{x}/content/search?t=ft&gr=josei&nt=&y=&mt=',
		'Khoa huyễn': f'{x}/content/search?t=ft&gr=sci-fi&nt=&y=&mt=',
		'Kid': f'{x}/content/search?t=ft&gr=kid&nt=&y=&mt=',
		'Kiếm hiệp': f'{x}/content/search?t=ft&gr=kiem-hiep&nt=&y=&mt=',
		'Kinh dị': f'{x}/content/search?t=ft&gr=horror&nt=&y=&mt=',
		'Ma cà rồng': f'{x}/content/search?t=ft&gr=vampire&nt=&y=&mt=',
		'Martial Arts': f'{x}/content/search?t=ft&gr=martial-art-2&nt=&y=&mt=',
		'Mecha': f'{x}/content/search?t=ft&gr=mecha&nt=&y=&mt=',
		'Ngôn tình': f'{x}/content/search?t=ft&gr=sentimental&nt=&y=&mt=',
		'Đời thường': f'{x}/content/search?t=ft&gr=daily-life&nt=&y=&mt=',
		'One shot': f'{x}/content/search?t=ft&gr=one-shot&nt=&y=&mt=',
		'Parody': f'{x}/content/search?t=ft&gr=parody&nt=&y=&mt=',
		'Phép thuật': f'{x}/content/search?t=ft&gr=magic&nt=&y=&mt=',
		'Phiêu lưu': f'{x}/content/search?t=ft&gr=adventure&nt=&y=&mt=',
		'Police': f'{x}/content/search?t=ft&gr=police&nt=&y=&mt=',
		'Romance': f'{x}/content/search?t=ft&gr=romance-2&nt=&y=&mt=',
		'Samurai': f'{x}/content/search?t=ft&gr=samurai&nt=&y=&mt=',
		'Seinen': f'{x}/content/search?t=ft&gr=seinen&nt=&y=&mt=',
		'Shoujo': f'{x}/content/search?t=ft&gr=shoujo&nt=&y=&mt=',
		'Shoujo ai': f'{x}/content/search?t=ft&gr=shoujo-ai&nt=&y=&mt=',
		'Shounen': f'{x}/content/search?t=ft&gr=shounen&nt=&y=&mt=',
		'Shounen ai': f'{x}/content/search?t=ft&gr=shounen-ai&nt=&y=&mt=',
		'Siêu năng lực': f'{x}/content/search?t=ft&gr=mutant&nt=&y=&mt=',
		'Slice of life': f'{x}/content/search?t=ft&gr=slice-of-life&nt=&y=&mt=',
		'Space': f'{x}/content/search?t=ft&gr=space&nt=&y=&mt=',
		'Thám tử': f'{x}/content/search?t=ft&gr=detector&nt=&y=&mt=',
		'Thể thao': f'{x}/content/search?t=ft&gr=sport&nt=&y=&mt=',
		'Tiên hiệp': f'{x}/content/search?t=ft&gr=tien-hiep&nt=&y=&mt=',
		'Tình cảm': f'{x}/content/search?t=ft&gr=romance&nt=&y=&mt=',
		'Tokusatsu': f'{x}/content/search?t=ft&gr=tokusatsu&nt=&y=&mt=',
		'Tragedy': f'{x}/content/search?t=ft&gr=tragedy&nt=&y=&mt=',
		'Trinh thám': f'{x}/content/search?t=ft&gr=detective&nt=&y=&mt=',
		'Trùng sinh': f'{x}/content/search?t=ft&gr=reincarnation&nt=&y=&mt=',
		'Vampire': f'{x}/content/search?t=ft&gr=vampire-2&nt=&y=&mt=',
		'Viễn tưởng': f'{x}/content/search?t=ft&gr=fiction&nt=&y=&mt=',
		'Võ thuật': f'{x}/content/search?t=ft&gr=martial-art&nt=&y=&mt=',
		'Webtoon': f'{x}/content/search?t=ft&gr=webtoon&nt=&y=&mt=',
		'Xuyên không': f'{x}/content/search?t=ft&gr=time-travel&nt=&y=&mt=',
		'Yaoi': f'{x}/content/search?t=ft&gr=yaoi&nt=&y=&mt=',
		'Yuri': f'{x}/content/search?t=ft&gr=yuri&nt=&y=&mt='
	}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.info['plot'] = tb
		item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/tocanm.png'
		item.set_callback(ds_tocanm, dulieu[k], 0)
		yield item
@Route.register
def tocanm_qg(plugin, **kwargs):
	dulieu = {
		'Đài Loan': f'{x}/content/search?t=ft&gr=&nt=TW&y=&mt=',
		'Ấn Độ': f'{x}/content/search?t=ft&gr=&nt=IN&y=&mt=',
		'Âu Mỹ': f'{x}/content/search?t=ft&gr=&nt=US-UK&y=&mt=',
		'Hàn Quốc': f'{x}/content/search?t=ft&gr=&nt=KR&y=&mt=',
		'Hồng Kông': f'{x}/content/search?t=ft&gr=&nt=HK&y=&mt=',
		'Mỹ': f'{x}/content/search?t=ft&gr=&nt=US&y=&mt=',
		'Nhật Bản': f'{x}/content/search?t=ft&gr=&nt=JP&y=&mt=',
		'Phillipines': f'{x}/content/search?t=ft&gr=&nt=PH&y=&mt=',
		'Thái Lan': f'{x}/content/search?t=ft&gr=&nt=TH&y=&mt=',
		'Trung Quốc': f'{x}/content/search?t=ft&gr=&nt=CN&y=&mt=',
		'Việt Nam': f'{x}/content/search?t=ft&gr=&nt=VN&y=&mt=',
	}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.info['plot'] = tb
		item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/tocanm.png'
		item.set_callback(ds_tocanm, dulieu[k], 0)
		yield item
@Route.register
def ds_tocanm(plugin, url=None, next_page=None, **kwargs):
	yield []
	if url is None or next_page is None:
		pass
	else:
		dialog = DialogProgress()
		dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
		trangtiep = f'{url}&p={next_page}' if '?' in url else f'{url}?p={next_page}'
		r = getlink(trangtiep, trangtiep, 1000)
		if (r is not None) and ('col-lg-3' in r.text):
			soup = BeautifulSoup(r.content, 'html.parser')
			soups = soup.select('div.row div.card-item-content a')
			urls = [k['href'] for k in soups]
			length = len(urls)
			if length>0:
				count = 0
				with ThreadPoolExecutor(length) as ex:
					future_to_url = (ex.submit(process_url, url) for url in urls)
					ac = as_completed(future_to_url)
					for k in ac:
						l, data = k.result()
						if data is not None:
							if (dialog.iscanceled()):
								break
							count += 1
							done = int((count/length)*100)
							dialog.update(done, f'Đang giải mã {length} dữ liệu...\nLoading... [COLOR yellow]{done} %[/COLOR]')
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = data[2]
							item.info['mediatype'] = 'movie'
							item.art['thumb'] = item.art['fanart'] = data[1]
							item.set_callback(episode_tocanm, l, data[0], data[2], data[1])
							yield item
				if f'&p={str(int(next_page) + 1)}' in r.text:
					item1 = Listitem()
					item1.label = f'Trang {str(int(next_page) + 2)}'
					item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
					item1.set_callback(ds_tocanm, url, str(int(next_page) + 1))
					yield item1
		else:
			yield quangcao()
		dialog.close()
@Route.register
def episode_tocanm(plugin, url=None, title=None, info=None, img=None, **kwargs):
	yield []
	if url is None or title is None or info is None or img is None:
		pass
	else:
		try:
			idm = re.search(r'_(\w+)\.html$', url)[1]
			urlx = f'{x}/content/subitems?mid={idm}&type=all'
			r = getlink(urlx, url, 1000)
			if (r is not None) and 'data' in r.text:
				soup = BeautifulSoup(r.json()['data'], 'html.parser')
				soups = soup.select('div.me-list a')
				for k in soups:
					item = Listitem()
					tenm = f'{k.get_text(strip=True)} - {title}'
					ux = k['href']
					item.label = tenm
					item.info['plot'] = info
					item.art['thumb'] = item.art['fanart'] = img
					item.set_callback(Resolver.ref('/resources/lib/kedon:play_tocanm'), tenm, ux, x)
					yield item
			else:
				yield quangcao()
		except:
			yield quangcao()
