﻿import xbmc

def playlist():
    xbmc.executebuiltin("Action(back)")

    xbmc.sleep(1000)
    xbmc.executebuiltin("Action(playlist)")


playlist()
