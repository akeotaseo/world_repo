from conf.common import CommonResolver


class GiveMeNbaStreams(CommonResolver):

    def set_servers(self):
        return ['givemenbastreams.com']

    def find_stream(self):
        return [r"source: '([^']+)'"]
