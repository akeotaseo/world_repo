import xbmc, xbmcgui


def Library():
    funcs = (click_1, click_2, click_3, click_4)
    call = xbmcgui.Dialog().select('[B]Βιβλιοθήκη[/B]', 
['[B]Ταινίες[/B] [B][COLOR orange]Βιβλιοθήκη[/COLOR][/B] (kodi)',
 '[B]Σειρές[/B] [B][COLOR orange]Βιβλιοθήκη[/COLOR][/B] (kodi)',
 '[COLOR green] Embuary Helper [/COLOR]',
 '[COLOR white] Library Data Provider [/COLOR]'
 ])
 



    if call:
        if call < 0:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




def click_1():
    xbmc.executebuiltin('ActivateWindow(Videos,library://video/movies,return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(Videos,library://video/tvshows,return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://script.embuary.helper/",return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://service.library.data.provider/",return)')


Library()
