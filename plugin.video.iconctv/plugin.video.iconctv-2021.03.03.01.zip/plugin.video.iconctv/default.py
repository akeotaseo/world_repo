# -*- coding: utf-8 -*-
import re
import sys
import requests
import xbmc, xbmcplugin,xbmcgui,xbmcaddon
import urllib
try:
  import urllib.request
except:
  import urllib2
import base64
import os
import datetime
import urllib3

KodiV = xbmc.getInfoLabel('System.BuildVersion')
KodiV = int(KodiV[:2])

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


BASE_URL = base64.b64decode('aHR0cDovL2hiYnR2LWFzLmNvbm5lY3RtZWRpYS5odS9haC9nZXRzdHJlYW11cmwucGhwP2lkPWljb25jZXJ0cw==')
epg_url = "https://www.cgates.lt/tv-kanalai/iconcerts-hd/"

UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36'

s = requests.Session()

def CATEGORIES():
    response = requests.get(BASE_URL)
    r = response.content
    try:
        headers_new = {'user-agent': UA}
        response_epg = s.get(epg_url, headers=headers_new)
        r_epg = response_epg.text
        desctemp=r_epg.replace('\n','')
        desctemp=desctemp.replace('\r','')
        desctemp=desctemp.replace('\t','')
        tempdesc = re.search('<tr class="programa_now">(.+?)</table>',desctemp)
        matchdesc = re.compile('<td class="laikas">(.+?)</td>.+?vc_toggle_title">(.+?)<br />').findall(tempdesc.group(1))
        desc=''
        now_time = datetime.datetime.now()
        for stime, ttitle in matchdesc:
            desc=desc+'[COLOR CC00FF00]'+stime+'[/COLOR]'+'\n'+ttitle+'\n'
    except:
        desc=''
            
    addLink('iConcerts TV',r,2,desc,'https://cdn.tvpassport.com/image/station/240x135/stingray-iconcerts.png')


def PLAY(url):
        link = url
        if KodiV >= 19:
            li = xbmcgui.ListItem(path=link)
        else:       
            li = xbmcgui.ListItem(iconImage=iconimage, thumbnailImage=iconimage, path=link)
        li.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage })
        li.setInfo('video', { 'title': name })
        try:
          xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
        except:
          xbmc.executebuiltin("Notification('Error','Missing video!')")          
		
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


def addDir(name,url,mode,iconimage,count,groupID):
        if KodiV >= 19:
            u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)+"&count="+str(count)+"&groupID="+str(groupID)
            liz=xbmcgui.ListItem(name)
        else:
            u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&count="+str(count)+"&groupID="+str(groupID)
            liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        ok=True
        liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage })
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addLink(name,url,mode,plot,iconimage):
        if KodiV >= 19:
            u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
            liz=xbmcgui.ListItem(name)
        else:
            u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
            liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        ok=True
        liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage })
        liz.setInfo( type="Video", infoLabels={ "Title": name, "plot": plot } )
        liz.setProperty("IsPlayable" , "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok   

params=get_params()
url=None
name=None
iconimage=None
mode=None
count=None
groupID=None

if KodiV >= 19:
    try:
            url=urllib.parse.unquote_plus(params["url"])
    except:
            pass
    try:
            name=urllib.parse.unquote_plus(params["name"])
    except:
            pass
    try:
            name=urllib.parse.unquote_plus(params["iconimage"])
    except:
            pass
    try:
            mode=int(params["mode"])
    except:
            pass
    try:
            count=int(params["count"])
    except:
            pass
    try:
            groupID=int(params["groupID"])
    except:
            pass
else:
    try:
            url=urllib.unquote_plus(params["url"])
    except:
            pass
    try:
            name=urllib.unquote_plus(params["name"])
    except:
            pass
    try:
            name=urllib.unquote_plus(params["iconimage"])
    except:
            pass
    try:
            mode=int(params["mode"])
    except:
            pass
    try:
            count=int(params["count"])
    except:
            pass
    try:
            groupID=int(params["groupID"])
    except:
            pass

if mode==None or url==None or len(url)<1:
        print ("")
        CATEGORIES()

elif mode==4:
        print (""+url)
        SUBCATEGORIES(name,url,mode)

elif mode==1:
        print (""+url)
        INDEXPAGES(name,url,mode,count,groupID)

elif mode==2:
        print (""+url)
        PLAY(url)
        
xbmcplugin.setContent(int(sys.argv[1]), 'movies')
xbmc.executebuiltin('Container.SetViewMode(504)')
xbmcplugin.endOfDirectory(int(sys.argv[1]))