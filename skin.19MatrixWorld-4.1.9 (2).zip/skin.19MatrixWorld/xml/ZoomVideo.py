﻿import xbmc

def videozoom2():
  #  xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin("ActivateWindowAndFocus(osdvideosettings)")
    xbmc.executebuiltin("Action(Pause)")
    xbmc.sleep(500)
    if xbmc.getCondVisibility('system.platform.android'):
        xbmc.executebuiltin('SendClick(-76)')
    else:
        xbmc.executebuiltin('SendClick(-75)')

    while xbmc.getCondVisibility("Window.IsVisible(osdvideosettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")

videozoom2()
