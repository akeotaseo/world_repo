import xbmc, xbmcgui


def ShortCut():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Mix~[/COLOR][/B]', 
['[B][COLOR=orange]ΠΡΟΤΙΜΗΣΕΙΣ[/COLOR][/B]',
'[B][COLOR=gold]ΑΝΑΖΗΤΗΣΗ[/COLOR][/B]',
 # '[COLOR=lime]Free Section[/COLOR] (Black Lightning / Shadow)',
 '[COLOR=orange]Ταινιες - Προβολές[/COLOR] (Blacklodge)',
 '[COLOR=orange]Σειρές -  Με πολλούς ψήφους[/COLOR] (Blacklodge)',
 '[B][COLOR green]Πλήρες Πρόγραμμα Αγώνων[/COLOR][/B]  (MicroJen-SportHD)',
 '[B][COLOR=green]Live Sports[/COLOR][/B] (MicroJen - daddylive)',
 '[COLOR=cornflowerblue]SPORTS TV[/COLOR] (Tvone112)  ([COLOR red]OFF?...[/COLOR])',
 '[COLOR=cornflowerblue]LIVE TV[/COLOR] (MicroJen-daddylive)',
 '[COLOR=hotpink]Xrysoi - Παιδικά[/COLOR] (MicroJen - cartoonsgr)',
 # '[COLOR=hotpink]Xrysoi - Παιδικά Μεταγλωτισμένα[/COLOR] (MicroJen - cartoonsgr)',
 # '[COLOR=hotpink]Xrysoi - Παιδικά Υπότιτλοι[/COLOR] (MicroJen - cartoonsgr)',
 '[B][COLORdodgerblue]Greek Android IPTV (Full list)[/COLOR][/B] (MicroJen - Ελληνικές M3U)',
 '[COLOR=blue]Sophisticated[/COLOR] (Eradio)'])


    if call:
        if call < 0:
            return
        func = funcs[call-11]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.mypreferences/?content_type=video&fanart=special%3a%2f%2fhome%2faddons%5cplugin.program.mypreferences%5cfanart.jpg&image=special%3a%2f%2fhome%2faddons%5cplugin.program.mypreferences%5cicon.png&label=My%20Preferences&mode=400&path=special%3a%2f%2fprofile%2faddon_data%2fplugin.program.mypreferences%5cSuper%20Favourites%5cMy%20Preferences")')


def click_2():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/SearchTk/SearchAll.py")')

# def click_3():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.shadow/?all_w=%7b%7d&data&dates=%20&description=%20&eng_name=%20&episode=%20&fanart=https%3a%2f%2fcmanbuilds.com%2fNEW%2520BLACK%2520LIGHTING%2fart%2ffanart.jpg&fav_status=false&heb_name=%20&iconimage=https%3a%2f%2fcmanbuilds.com%2fNEW%2520BLACK%2520LIGHTING%2fart%2ficon.png&id&image_master&isr=0&last_id&mode=189&mypass&name=Free%20Section&original_title=Free%20Section&search_db&season=%20&show_original_year=%20&tmdbid=%20&url=https%3a%2f%2fcmanbuilds.com%2fNEW%2520BLACK%2520LIGHTING%2fMOVIES%2fFree-Main.xml&video_data=%7b%22title%22%3a%20%22Free%20Section%22%2c%20%22mediatype%22%3a%20%22movie%22%2c%20%22TVshowtitle%22%3a%20%22%22%2c%20%22season%22%3a%200%2c%20%22episode%22%3a%200%2c%20%22OriginalTitle%22%3a%20%22Free%20Section%22%2c%20%22year%22%3a%20%22%22%2c%20%22rating%22%3a%20%220%22%2c%20%22plot%22%3a%20%22%20%22%2c%20%22Tag%22%3a%20%22189%22%2c%20%22trailer%22%3a%20%22%22%2c%20%22id%22%3a%20%22%22%7d",return)') 


def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.blacklodge/?action=movies&url=trending")') 

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.blacklodge/?action=tvshows&url=views")')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/sporthd?description=Daily%20events%20list&iconimage=https%3a%2f%2fraw.githubusercontent.com%2fbugatsinho%2fbugatsinho.github.io%2fmaster%2fplugin.video.sporthdme%2ficon.png&mode=events&name=%5bB%5d-%20%5bCOLOR%20white%5dSport%5bCOLOR%20gold%5dHD%5bCOLOR%20white%5d%20-%20%ce%a0%ce%bb%ce%ae%cf%81%ce%b5%cf%82%20%ce%a0%cf%81%cf%8c%ce%b3%cf%81%ce%b1%ce%bc%ce%bc%ce%b1%20%ce%91%ce%b3%cf%8e%ce%bd%cf%89%ce%bd%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fsuper.league.do%2f")')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=sched")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone112/list_channels/38")')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=live_tv")')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.myselect/?group=xrysoi-test-1726556845.0809326&mode=group&refresh&reload")')

# def click_9():
    # xbmc.executebuiltin('PlayMedia("plugin://plugin.video.microjen/run_plug/plugin.video.cartoonsgr%2F%3Fdescription%26amp%3Biconimage%3Dnone%26amp%3Bmode%3Dxrysoiposts%26amp%3Bname%3D%2520%26amp%3Burl%3Dhttps%3A%2F%2Fxrysoi.pro%2Fcategory%2F%25ce%25ba%25ce%25b9%25ce%25bd-%25cf%2583%25cf%2587%25ce%25ad%25ce%25b4%25ce%25b9%25ce%25b1%2F")')

# def click_10():
    # xbmc.executebuiltin('PlayMedia("plugin://plugin.video.microjen/run_plug/plugin.video.cartoonsgr%2F%3Fdescription%26amp%3Biconimage%3Dnone%26amp%3Bmode%3Dxrysoiposts%26amp%3Bname%3D%2520%26amp%3Burl%3Dhttps%3A%2F%2Fxrysoi.pro%2Fcategory%2F%25ce%25ba%25ce%25b9%25ce%25bd-%25cf%2583%25cf%2587%25ce%25ad%25ce%25b4%25ce%25b9%25ce%25b1-subs%2F")')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/get_list/m3ucat|eJzLKCkpsNLXT8/OK8+sSixK0Ust1S9KLcjXdyrNzEkp1nf3zncq1a/IzSnWT8xLKcrPTNHLNS4FACTOE9Y=|all_categories")')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10502,"plugin://plugin.audio.eradio.gr/?action=radios&title=Sophisticated&url=http%3a%2f%2feradio.mobi%2fcache%2f1%2f1%2fmedialist_categoryID11.json")')


ShortCut()
