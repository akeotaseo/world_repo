﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob
xbmcgui.Dialog().notification("Ρυθμίσεις......", "addon_data", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild2.png', sound=False)
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"screensaver.mode","value":"screensaver.xbmc.builtin.dim"},"id":"1"}')
from updatervar import *

Dialog_U1                 = '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]'
Dialog_U4                 = '[B]Ολοκληρώθηκε με επιτυχία[/B]'

def set_setting():
    ###  Blacklodge  ###
    # addon_blacklodge       = xbmcaddon.Addon('plugin.video.blacklodge')
    # setting_blacklodge     = addon_blacklodge.getSetting
    # setting_set_blacklodge = addon_blacklodge.setSetting
    # if setting_blacklodge('lists.provider')=='0':
        # setting_set_blacklodge('lists.provider', '1')


    ###  Everstream  ###
    addon_everstream       = xbmcaddon.Addon('plugin.video.everstream')
    setting_everstream     = addon_everstream.getSetting
    setting_set_everstream = addon_everstream.setSetting
    if setting_everstream('lists.provider')=='0':
        setting_set_everstream('lists.provider', '1')


    ###  Apex_Sports  ###
    if xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.apex_sports')):
        addon_apex_sports       = xbmcaddon.Addon('plugin.video.apex_sports')
        setting_apex_sports     = addon_apex_sports.getSetting
        setting_set_apex_sports = addon_apex_sports.setSetting
        if setting_apex_sports('livetv_base')=='http://livetv853.me':
            setting_set_apex_sports('livetv_base', 'https://livetv872.me')


    ###  ===Homelander===   ###
    #BG.update(30, Dialog_U1, 'Ενημέρωσης ρυθμίσεων...')
    #addon_homelander     = xbmcaddon.Addon('plugin.video.homelander')
    #setting_homelander     = addon_homelander.getSetting
    #setting_set_homelander = addon_homelander.setSetting
    #if setting_homelander('subtitles')=='false':
        #xbmc.sleep(1000)
        #setting_set_homelander('subtitles', 'true')
        #BG.update(33, Dialog_U1, 'Ενεργοποίηση υποτίτλων Homelander...')
        #xbmc.sleep(2000)
        #setting_set_homelander('subtitles.lang.1', 'Greek')
        #setting_set_homelander('subtitles.lang.2', 'English')
        #BG.update(39, Dialog_U1, 'Επιλογή κύριας γλώσσας υποτίτλων σε Ελληνικά...')
        #xbmc.sleep(2000)
    #if setting_homelander('providers.lang')=='English':
        #xbmc.sleep(1000)
        #setting_set_homelander('providers.lang', 'Greek+English')
        #BG.update(45, Dialog_U1, 'Επιλογή παρόχων σε Greek+English...')
        #xbmc.sleep(2000)




            ###  ===myiptv===   ###
    # addon_myiptv       = xbmcaddon.Addon('plugin.video.myiptv')
    # setting_myiptv     = addon_myiptv.getSetting
    # setting_set_myiptv = addon_myiptv.setSetting
    # if setting_myiptv('player_type')=='1':
        # xbmc.sleep(500)
        # setting_set_myiptv('player_type', '0')



##daddylive
    addon_daddylive       = xbmcaddon.Addon('plugin.video.daddylive')
    setting_daddylive     = addon_daddylive.getSetting
    setting_set_daddylive = addon_daddylive.setSetting
    if setting_daddylive('time_format')=='0':
        xbmc.sleep(500)
        setting_set_daddylive('time_format', '1')
    if setting_daddylive('mode')=='0':
        xbmc.sleep(500)
        setting_set_daddylive('mode', '1')



##f4mTester
    addon_f4mTester       = xbmcaddon.Addon('plugin.video.f4mTester')
    setting_f4mTester     = addon_f4mTester.getSetting
    setting_set_f4mTester = addon_f4mTester.setSetting
    if setting_f4mTester('ask')=='false':
        xbmc.sleep(500)
        setting_set_f4mTester('ask', 'true')
    if setting_f4mTester('player_type')=='1':
        xbmc.sleep(500)
        setting_set_f4mTester('player_type', '0')



##  Scrapee 
if xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.scrapee')):
    addon_scrapee       = xbmcaddon.Addon('plugin.video.scrapee')
    setting_scrapee     = addon_scrapee.getSetting
    setting_set_scrapee = addon_scrapee.setSetting
    if setting_scrapee('movie_download_directory')=='special://profile/addon_data/plugin.video.scrapee/Movies Downloads/':
        xbmc.sleep(500)
        setting_set_scrapee('movie_download_directory', 'special://home/media/Downloads/Scrapee')

    addon_scrapee       = xbmcaddon.Addon('plugin.video.scrapee')
    setting_scrapee     = addon_scrapee.getSetting
    setting_set_scrapee = addon_scrapee.setSetting
    if setting_scrapee('tvshow_download_directory')=='special://profile/addon_data/plugin.video.scrapee/TV Show Downloads/':
        xbmc.sleep(500)
        setting_set_scrapee('tvshow_download_directory', 'special://home/media/Downloads/Scrapee')

    addon_scrapee       = xbmcaddon.Addon('plugin.video.scrapee')
    setting_scrapee     = addon_scrapee.getSetting
    setting_set_scrapee = addon_scrapee.setSetting
    if setting_scrapee('premium_download_directory')=='special://profile/addon_data/plugin.video.scrapee/Premium Downloads/':
        xbmc.sleep(500)
        setting_set_scrapee('premium_download_directory', 'special://home/media/Downloads/Scrapee')

    addon_scrapee       = xbmcaddon.Addon('plugin.video.scrapee')
    setting_scrapee     = addon_scrapee.getSetting
    setting_set_scrapee = addon_scrapee.setSetting
    if setting_scrapee('image_download_directory')=='special://profile/addon_data/plugin.video.scrapee/Image Downloads/':
        xbmc.sleep(500)
        setting_set_scrapee('image_download_directory', 'special://home/media/Downloads/Scrapee')





BG.create(Dialog_U1, Dialog_U4)
xbmc.sleep(1000)
BG.update(100, Dialog_U1, Dialog_U4)
BG.close()
#            xbmc.executebuiltin("ReloadSkin()")

set_setting()
