from conf.common import CommonResolver


class LiveSport365(CommonResolver):

    def set_servers(self):
        return ['https://live-sport365.com']

    def find_stream(self):
        return [r"file:.*?[\'|\"]([^\'|\"]+)\sor"]
