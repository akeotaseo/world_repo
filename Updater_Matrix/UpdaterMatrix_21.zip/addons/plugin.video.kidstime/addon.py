# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import sys
from tulip.compat import parse_qsl
from xbmc import getInfoLabel
from resources.lib import kids


params = dict(parse_qsl(sys.argv[2].replace('?','')))

action = params.get('action')
url = params.get('url')

fp = getInfoLabel('Container.FolderPath')

if action is None:
    kids.Indexer().root(audio_only='audio' in fp)

elif action == 'addBookmark':
    from tulip import bookmarks
    bookmarks.add(url)

elif action == 'deleteBookmark':
    from tulip import bookmarks
    bookmarks.delete(url)

elif action == 'bookmarks':
    kids.Indexer().bookmarks()

elif action == 'videos':
    kids.Indexer().videos(url)

elif action == 'play':
    kids.Indexer().play(url)


elif action == 'archive1':
    kids.Indexer().archive1()

elif action == 'archive2':
    kids.Indexer().archive2()

elif action == 'archive3':
    kids.Indexer().archive3()

elif action == 'archive4':
    kids.Indexer().archive4()

elif action == 'archive5':
    kids.Indexer().archive5()

elif action == 'archive6':
    kids.Indexer().archive6()
    
elif action == 'archive7':
    kids.Indexer().archive7()
    
elif action == 'archive8':
    kids.Indexer().archive8()

elif action == 'archive9':
    kids.Indexer().archive9()

elif action == 'archive10':
    kids.Indexer().archive10()

elif action == 'archive11':
    kids.Indexer().archive11()

elif action == 'archive12':
    kids.Indexer().archive12()
    
elif action == 'archive13':
    kids.Indexer().archive13()
    
elif action == 'archive14':
    kids.Indexer().archive14()

elif action == 'archive15':
    kids.Indexer().archive15()

elif action == 'archive16':
    kids.Indexer().archive16()

elif action == 'archive17':
    kids.Indexer().archive17()

elif action == 'archive18':
    kids.Indexer().archive18()
    
elif action == 'archive19':
    kids.Indexer().archive19()

elif action == 'archive20':
    kids.Indexer().archive20()

elif action == 'archive21':
    kids.Indexer().archive21()

elif action == 'archive22':
    kids.Indexer().archive22()

elif action == 'archive23':
    kids.Indexer().archive23()

elif action == 'archive24':
    kids.Indexer().archive24()


elif action == 'episodes':
    kids.Indexer().episodes(url)


elif action == 'cache_clear':
    from tulip import cache
    cache.clear(withyes=False)
