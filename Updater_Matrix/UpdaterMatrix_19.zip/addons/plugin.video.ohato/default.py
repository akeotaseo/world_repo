import sys
import json
import urllib
import requests
import unicodedata
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from collections import defaultdict
from resources.lib.epg import get_epg_now_next, get_epg_day_schedule, download_epg

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

CHANNELS_JSON_URL = "https://derzis.xyz/channels_final_epg.json"
DEFAULT_LOGO = f"special://home/addons/{ADDON.getAddonInfo('id')}/resources/media/flags/un.png"

ISO_MAP = {
    "Albania": "al", "Arabia": "sa", "Balkans": "yu", "Bulgaria": "bg", "France": "fr",
    "Germany": "de", "Georgia": "ge", "Italy": "it", "Netherlands": "nl", "Poland": "pl",
    "Portugal": "pt", "Romania": "ro", "Russia": "ru", "Spain": "es", "Turkey": "tr",
    "United Kingdom": "gb", "USA": "us"
}

CACHE = {
    'channels': [],
    'by_country': defaultdict(list)
}

AUTO_PLAY = ADDON.getSettingBool("auto_play_first_source")
SHOW_EPG_CONTEXT = ADDON.getSettingBool("show_epg_context")
SHOW_EPG_NOW = ADDON.getSettingBool("show_epg_now")
PER_PAGE = ADDON.getSettingInt("per_page")

def normalize(text):
    if not text:
        return ""
    text = unicodedata.normalize('NFKD', text)
    return ''.join(c for c in text if not unicodedata.combining(c)).lower().strip()

def build_url(query):
    return BASE_URL + '?' + urllib.parse.urlencode(query)

def fetch_channels():
    try:
        response = requests.get(CHANNELS_JSON_URL)
        response.raise_for_status()
        channels = response.json()
        CACHE['channels'] = channels
        for ch in channels:
            country = ch.get('group-title', 'Unknown')
            CACHE['by_country'][country].append(ch)
        xbmc.log(f"Fetched {len(channels)} channels from JSON.", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"Error fetching channels: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", "Could not load channel list")

def list_countries(params=None):
    # Adaugăm opțiunea "Căutare"
    SEARCH_ICON = f"special://home/addons/{ADDON.getAddonInfo('id')}/resources/media/search.png"
    li = xbmcgui.ListItem("Căutare")
    li.setArt({'icon': SEARCH_ICON, 'thumb': SEARCH_ICON})
    url = build_url({'action': 'search_channel_prompt'})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    countries = list(CACHE['by_country'].keys())
    if 'Romania' in countries:
        countries.remove('Romania')
        countries.insert(0, 'Romania')
    countries.sort()
    for country_key in countries:
        channels = CACHE['by_country'][country_key]
        if not channels:
            continue
        display_name = country_key
        iso_code = ISO_MAP.get(display_name, 'un')
        thumb = f"https://raw.githubusercontent.com/derzis/artwork/main/posters/{iso_code}.png"
        icon = f"https://raw.githubusercontent.com/derzis/artwork/main/flags/{iso_code}.png"
        url = build_url({'action': 'list_channels', 'country': display_name, 'page': 1})
        li = xbmcgui.ListItem(display_name)
        li.setArt({'icon': icon, 'thumb': thumb})
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def add_channel_item(name, logo, url, plot=None, epg_url=None, is_playable=False):
    li = xbmcgui.ListItem(name)
    li.setArt({'icon': logo, 'thumb': logo, 'fanart': logo})
    li.setInfo('video', {'title': name})
    if plot:
        li.setInfo('video', {'plot': plot})
    if epg_url:
        li.addContextMenuItems([("Vezi EPG complet", f"RunPlugin({epg_url})")])
    li.setProperty('IsPlayable', 'true' if is_playable else 'false')
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=not is_playable)

def list_channels(country_name, page=1):
    if not CACHE['channels']:
        fetch_channels()

    page = int(page)
    xbmc.log(f"Listing channels for: {country_name} (Page {page})", xbmc.LOGINFO)
    all_channels = []
    for key in CACHE['by_country']:
        if normalize(key) == normalize(country_name):
            all_channels = CACHE['by_country'][key]
            break
    if not all_channels:
        xbmc.log(f"No channels found for country: {country_name}", xbmc.LOGWARNING)
        return

    start = (page - 1) * PER_PAGE
    end = start + PER_PAGE
    paginated = all_channels[start:end]

    grouped = defaultdict(list)
    for ch in paginated:
        grouped[normalize(ch['name'])].append(ch)

    for group, items in grouped.items():
        main = items[0]
        display_name = main.get('name') or main.get('tvg-name')
        logo = main.get('tvg-logo') if main.get('tvg-logo', '').startswith('http') else main.get('icon') or DEFAULT_LOGO
        ids = main['id'] if isinstance(main['id'], list) else [main['id']]
        url = build_url({'action': 'choose_source', 'name': display_name, 'ids': json.dumps(ids)}) if len(ids) > 1 and not AUTO_PLAY else build_url({'action': 'play', 'id': json.dumps(ids) if len(ids) > 1 else ids[0]})
        is_playable = AUTO_PLAY or len(ids) == 1
        tvg_id = main.get('tvg-id', '')

        plot = get_epg_now_next(tvg_id) if SHOW_EPG_NOW and tvg_id else None
        epg_url = build_url({'action': 'show_epg', 'tvg_id': tvg_id}) if SHOW_EPG_CONTEXT and tvg_id else None

        add_channel_item(display_name, logo, url, plot, epg_url, is_playable)

    if end < len(all_channels):
        next_url = build_url({'action': 'list_channels', 'country': country_name, 'page': page + 1})
        li = xbmcgui.ListItem(f"[Pagina următoare →]")
        li.setArt({'icon': DEFAULT_LOGO, 'thumb': DEFAULT_LOGO})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=next_url, listitem=li, isFolder=True)

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)

def choose_source(name, ids):
    for cid in ids:
        name_variant = f"{name} (Source {cid})"
        url = build_url({'action': 'play', 'id': cid})
        li = xbmcgui.ListItem(name_variant)
        li.setArt({'icon': DEFAULT_LOGO, 'thumb': DEFAULT_LOGO})
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'title': name_variant})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_channel(cid):
    try:
        ids = json.loads(cid) if cid.startswith('[') else [cid]
    except Exception:
        ids = [cid]

    session = requests.Session()
    for channel_id in ids:
        try:
            response = session.get(f"https://oha.to/play/{channel_id}/index.m3u8", allow_redirects=True, timeout=15)
            response.raise_for_status()
            stream_url = response.url
            if not stream_url.endswith(".m3u8"):
                continue
            li = xbmcgui.ListItem(path=stream_url)
            li.setMimeType('application/vnd.apple.mpegurl')
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.setResolvedUrl(HANDLE, True, li)
            return
        except Exception as e:
            xbmc.log(f"Error resolving stream for ID {channel_id}: {e}", xbmc.LOGERROR)

    xbmcgui.Dialog().notification("Eroare", "Nicio sursă validă pentru redare.")

def show_epg_dialog(tvg_id):
    plot = get_epg_day_schedule(tvg_id)
    xbmcgui.Dialog().textviewer("EPG pentru azi", plot)

def search_channel_prompt():
    query = xbmcgui.Dialog().input("Caută un post TV:", type=xbmcgui.INPUT_ALPHANUM)
    if query:
        url = build_url({'action': 'search_channel', 'query': query})
        xbmc.executebuiltin(f'Container.Update("{url}")')

def search_channel(query):
    if not CACHE['channels']:
        fetch_channels()

    if not query:
        return

    query_norm = normalize(query)
    matches = [ch for ch in CACHE['channels'] if query_norm in normalize(ch.get('name', ''))]

    if not matches:
        xbmcgui.Dialog().notification("Căutare", "Niciun post găsit.", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    grouped = defaultdict(list)
    for ch in matches:
        grouped[normalize(ch['name'])].append(ch)

    for group, items in grouped.items():
        main = items[0]
        display_name = main.get('name') or main.get('tvg-name')
        logo = main.get('tvg-logo') if main.get('tvg-logo', '').startswith('http') else main.get('icon') or DEFAULT_LOGO
        ids = main['id'] if isinstance(main['id'], list) else [main['id']]
        url = build_url({'action': 'choose_source', 'name': display_name, 'ids': json.dumps(ids)}) if len(ids) > 1 and not AUTO_PLAY else build_url({'action': 'play', 'id': json.dumps(ids) if len(ids) > 1 else ids[0]})
        is_playable = AUTO_PLAY or len(ids) == 1
        tvg_id = main.get('tvg-id', '')

        plot = get_epg_now_next(tvg_id) if SHOW_EPG_NOW and tvg_id else None
        epg_url = build_url({'action': 'show_epg', 'tvg_id': tvg_id}) if SHOW_EPG_CONTEXT and tvg_id else None

        add_channel_item(display_name, logo, url, plot, epg_url, is_playable)

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)

def router(params):
    action = params.get('action')
    if not action:
        fetch_channels()
        list_countries()
    elif action == 'list_channels':
        list_channels(params.get('country'), params.get('page', 1))
    elif action == 'choose_source':
        name = params.get('name', 'Unknown')
        ids = json.loads(params.get('ids', '[]'))
        choose_source(name, ids)
    elif action == 'play':
        play_channel(params.get('id'))
    elif action == 'show_epg':
        show_epg_dialog(params.get('tvg_id'))
    elif action == 'force_refresh_epg':
        download_epg()
        xbmcgui.Dialog().notification("EPG", "EPG forțat reîncărcat.")
    elif action == 'search_channel_prompt':
        search_channel_prompt()
    elif action == 'search_channel':
        search_channel(params.get('query'))

if __name__ == '__main__':
    router(dict(urllib.parse.parse_qsl(sys.argv[2][1:])))
