# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
icon_DOC = ART + 'doc.png'
DOC = 'https://ntokimanter.gr/'



def menu_genre(): #117
    addDir('[COLOR white]ΚΟΙΝΩΝΙΑ[/COLOR]', DOC + 'videoscategory/koinonika', 118, icon_DOC, FANART, '')
    addDir('[COLOR white]ΙΣΤΟΡΙΑ[/COLOR]', DOC + 'videoscategory/istoria', 118, icon_DOC, FANART, '')
    addDir('[COLOR white]ΜΥΣΤΗΡΙΟ[/COLOR]', DOC + 'videoscategory/mistirio', 118, icon_DOC, FANART, '')
    addDir('[COLOR white]ΝΤΟΚΙΜΑΝΤΕΡ ΜΕ ΖΩΑ[/COLOR]', DOC + 'videoscategory/ntokimanter-me-zoa', 118, icon_DOC, FANART, '')
    addDir('[COLOR white]ΞΕΝΑ ΝΤΟΚΙΜΑΝΤΕΡ[/COLOR]', DOC + 'videoscategory/ksena-ntokimanter', 118, icon_DOC, FANART, '')
    addDir('[COLOR white]ΘΡΗΣΚΕΙΑ[/COLOR]', DOC + 'videoscategory/thriskeia', 118, icon_DOC, FANART, '')
    addDir('[COLOR white]ΕΠΙΣΤΗΜΗ[/COLOR]', DOC + 'videoscategory/epistimi', 118, icon_DOC, FANART, '')
    addDir('[COLOR white]ΠΕΡΙΒΑΛΛΟΝ[/COLOR]', DOC + 'videoscategory/reriballon', 118, icon_DOC, FANART, '')
    addDir('[COLOR white]ΟΙΚΟΝΟΜΙΑ[/COLOR]', DOC + 'videoscategory/oikonomia', 118, icon_DOC, FANART, '')
    addDir('[COLOR white]ΠΟΛΙΤΙΚΗ[/COLOR]', DOC + 'videoscategory/politiki', 118, icon_DOC, FANART, '')


def ntokimanter(url): #118
    hdrs = {'Referer': DOC,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<div class="col-sm-4 col-xs-6 item responsive-height">.+?\s<div class="item-img">.+?\s<a href="(.+?)"><.+? src="(.+?)" class="img-responsive wp-post-image" alt="(.+?)"', re.DOTALL).findall(p)
    for url, icon, name in m:
        name = clear_Title(name)
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 119, icon, FANART, '')
    try:
        n = re.compile('<a class="next page-numbers" href="(.+?)">').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', n, 118, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass


def get_links(name, url, iconimage, description): #119
    hdrs = {'Referer': DOC,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<iframe.+?src="(.+?)"').findall(p)
    for url in m:
        if not 'https:' in url:
            url = 'https:' + url
            addDir(name, url, 100, iconimage, FANART, str(description))
        else:
            url = url
            addDir(name, url, 100, iconimage, FANART, str(description))


def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    return txt
