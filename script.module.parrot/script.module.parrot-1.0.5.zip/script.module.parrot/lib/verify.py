import hashlib
import xbmcaddon


def isVerified():
    PARROTID = xbmcaddon.Addon('repository.Parrot')
    try:
        if PARROTID.getSetting("verified") == 'true':
            return True
    except: pass
    return False

