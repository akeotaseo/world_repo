﻿import xbmc, xbmcaddon, xbmcgui
from updatervar import *

dialog.notification('[B][COLOR orange]Γίνεται έλεγχος![/COLOR][/B]', '[COLOR white]Παρακαλώ περιμένετε...[/COLOR]', icon_ok2, sound=False)
# xbmc.sleep(4000)

def set_setting_FixBuild():


    ###  plugin.program.downloader19   ###

    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('addonsreposversion')=='0':
        xbmc.sleep(500)
        setting_set_downloader19('addonsreposversion', '0')
        xbmc.sleep(500)
        xbmcgui.Dialog().notification("[B][COLOR orange]addonsreposversion[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild.png', sound=False)

    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('deleteversion')=='0':
        xbmc.sleep(500)
        setting_set_downloader19('deleteversion', '0')
        xbmc.sleep(500)
        xbmcgui.Dialog().notification("[B][COLOR orange]deleteversion[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild.png', sound=False)


    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('installationversion')=='0':
        xbmc.sleep(500)
        setting_set_downloader19('installationversion', '0')
        xbmc.sleep(500)
        xbmcgui.Dialog().notification("[B][COLOR orange]installationversion[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild.png', sound=False)


    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('playersversion')=='0':
        xbmc.sleep(500)
        setting_set_downloader19('playersversion', '0')
        xbmc.sleep(500)
        xbmcgui.Dialog().notification("[B][COLOR orange]playersversion[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild.png', sound=False)


    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('zip1version')=='0':
        xbmc.sleep(500)
        setting_set_downloader19('zip1version', '0')
        xbmc.sleep(500)
        xbmcgui.Dialog().notification("[B][COLOR orange]zip1version[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild.png', sound=False)


    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('zip2version')=='0':
        xbmc.sleep(500)
        setting_set_downloader19('zip2version', '0')
        xbmc.sleep(500)
        xbmcgui.Dialog().notification("[B][COLOR orange]zip2version[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild.png', sound=False)


    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('zip3version')=='0':
        xbmc.sleep(500)
        setting_set_downloader19('zip3version', '0')
        xbmc.sleep(500)
        xbmcgui.Dialog().notification("[B][COLOR orange]zip3version[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild.png', sound=False)


    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('zip4version')=='0':
        xbmc.sleep(500)
        setting_set_downloader19('zip4version', '0')
        xbmc.sleep(500)
        xbmcgui.Dialog().notification("[B][COLOR orange]zip4version[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild.png', sound=False)


    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('zip5version')=='0':
        xbmc.sleep(500)
        setting_set_downloader19('zip5version', '0')
        xbmc.sleep(500)
        xbmcgui.Dialog().notification("[B][COLOR orange]zip5version[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild.png', sound=False)


    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('pvrversion')=='0':
        xbmc.sleep(500)
        setting_set_downloader19('pvrversion', '0')
        xbmc.sleep(500)
        xbmcgui.Dialog().notification("[B][COLOR orange]pvrversion[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild.png', sound=False)


    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('varversion')=='0':
        xbmc.sleep(500)
        setting_set_downloader19('varversion', '0')
        xbmc.sleep(500)
        xbmcgui.Dialog().notification("[B][COLOR orange]varversion[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild.png', sound=False)


    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('setsettingversion')=='0':
        xbmc.sleep(500)
        setting_set_downloader19('setsettingversion', '0')
        xbmc.sleep(500)
        xbmcgui.Dialog().notification("[B][COLOR orange]setsettingversion[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild.png', sound=False)


    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('xmlskinversion')=='0':
        xbmc.sleep(500)
        setting_set_downloader19('xmlskinversion', '0')
        xbmc.sleep(500)
        xbmcgui.Dialog().notification("[B][COLOR orange]xmlskinversion[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild.png', sound=False)


    #addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    #setting_downloader19     = addon_downloader19.getSetting
    #setting_set_downloader19 = addon_downloader19.setSetting
    #if not setting_downloader19('notifyversion')=='0':
        #xbmc.sleep(500)
        #setting_set_downloader19('notifyversion', '0')
        #xbmc.sleep(500)
        #xbmcgui.Dialog().notification("[B][COLOR orange]notifyversion[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild.png', sound=False)


        xbmc.sleep(1000)
        xbmcgui.Dialog().notification("[B][COLOR orange]Ok...[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild2.png')
        xbmc.sleep(1000)


    #dialog.notification('[B][COLOR orange]Reload Profile[/COLOR][/B]', '[COLOR white]Παρακαλώ περιμένετε...[/COLOR]', icon_reloadprofile, sound=False)
    #xbmc.sleep(4000)
    #xbmc.executebuiltin("LoadProfile(Master user)")

    #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/ForceClose.py")'),

    #xbmc.sleep(5000)
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/service.py")'),
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/service.py")')





#            xbmc.executebuiltin("ReloadSkin()")

set_setting_FixBuild()
