﻿import xbmc

def SetingsKodi():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    #xbmc.sleep(1000)
    #xbmc.executebuiltin("Action(Close)")
    #xbmc.sleep(1000)
    xbmc.executebuiltin("ActivateWindow(Settings,return)")

SetingsKodi()
