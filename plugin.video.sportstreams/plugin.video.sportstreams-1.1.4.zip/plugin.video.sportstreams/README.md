<h1>Sport Streams</h1>
<p>
Sportovní přenosy z různých zdrojů:<br><br>

ČT4 Sport Plus (ČT4 Sport + extra přenosy)<br>
TVcom.cz (živé přenosy i archiv různých sportů a soutěží)<br>
Huste.tv (živé přenosy i archiv ze slovenských soutěží)<br>
Volej.tv (přenosy volejbalových soutěží)<br>
Ping-pong.tv (přenosy ze soutěží stolního tenisu)<br>
Tipos.sk (přenosy slovenského basketbalu)<p>

v1.1.4 (22.1.2025)<br>
- přidání Tipos.sk<br><br>

v1.1.3 (14.1.2025)<br>
- úprava přehrávání ČT4 Sport/Plus<br><br>

v1.1.1/2 (5.1.2025)<br>
- odstranění Ettu.tv a Niké.sk<br>
- přidání live streamů pro Volej.tv<br><br>

v1.1.0 (30.12.2024)<br>
- ošetření nedostupnosti webu (ettu.tv)<br><br>

v1.0.9 (14.8.2024)<br>
- přepsání Volej.tv po úpravě webu<br><br>
</p>
