import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob
xbmcgui.Dialog().notification("ResolveURL", "[B][COLOR green]Fix Settings[/COLOR][/B]", icon='special://home/addons/script.module.resolveurl/icon.png', sound=False)
from xbmc import executebuiltin
from xbmcaddon import Addon
from os.path import exists,join
from os import makedirs
from xbmcvfs import translatePath
def Resolveurl():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]  ~ Resolveurl ~[/COLOR][/B]', 
['[B][COLOR green]Fix Settings ResolveURL[/COLOR][/B]',
 '[B]ResolveURL[/B] : Settings',
 'Εξουσιοδότηση - Επαναφορά Derbid',
 '[COLOR FF32D3FE][B]Account Manager[/B][/COLOR] [COLOR gold][B]Lite[/B][/COLOR]',
 '[COLOR teal]RealDebrid[/COLOR]',
 'HELP'


 ])


    if call:
        if call < 0:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    ResolveurlDialog()

def click_2():
    xbmc.executebuiltin('Addon.OpenSettings(script.module.resolveurl)')

def click_3():
    derbid_authorize()

def click_4():
    debridmgr()

def click_5():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.realdebrid")')

def click_6():
    Help_Realdebrid()



def debridmgr():
    # xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.module.debridmgr")')
    if xbmc.getCondVisibility('System.HasAddon({})'.format('script.module.acctmgr')):
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('Action(Back)')
    # xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('RunScript("script.module.acctmgr")')
    
    if not xbmc.getCondVisibility('System.HasAddon({})'.format('script.module.acctmgr')):
        
        
        xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.module.acctmgr")')
        xbmc.sleep(12000)
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('Action(Back)')
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('ActivateWindow(10000)')
        xbmc.executebuiltin('RunScript("script.module.acctmgr")')
        xbmc.executebuiltin('RunScript("script.module.acctmgr")')
        xbmc.executebuiltin('RunScript("script.module.acctmgr")')





#######################
def ResolveurlDialog():
        xbmcgui.Dialog().ok('[COLOR orange]Resolveurl[/COLOR]', 'Αν στις ρυθμίσεις του [B][COLOR orange]resolve url[/COLOR][/B] δεν βγάζει settings (για να κάνετε εξουσιοδότηση σε RD ή σε άλλες υπηρεσίες κ.τ.λ)[CR]τότε μάλλον έχετε τρέξει παρόχους πριν ολοκληρωθούν τα update και κρέμασε...') 
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Διαγραφή addon_data Resolveurl[/COLOR]', 'Με αυτή την επιλογή θα διαγραφούν οι ρυθμίσεις του [COLOR orange]Resolveurl[/COLOR]', 
                                        nolabel='[B][COLOR white]Άκυρο...[/COLOR][/B]',yeslabel='[B][COLOR green]Διαγραφή[/COLOR][/B]')
        
        if choice == 1: [ResolveurlDelete(),
                         xbmc.sleep(1000),
                         xbmcaddon.Addon('script.module.resolveurl').setSetting('init_setting', 'done'),
                       # xbmc.sleep(2000),
                       # xbmc.executebuiltin('Dialog.Close(all,true)'),
                       # xbmc.executebuiltin('Action(Back)'),
                       # xbmc.executebuiltin('Dialog.Close(all,true)')


                       # xbmc.executebuiltin('PlayMedia("plugin://plugin.video.blacklodge/?action=smuSettings")'),

                           xbmc.executebuiltin('RunScript("special://home/addons/skin.19MatrixWorld/xml/FixResolveurl.py")'),
                         ]

def ResolveurlDelete():
    base_path = xbmcvfs.translatePath('special://home/userdata/addon_data')

    dir_list = glob.iglob(os.path.join(base_path, "script.module.resolveurl"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)


    resolveur = translatePath('special://home/userdata/addon_data/script.module.resolveurl')

    if not exists(resolveur):
        makedirs(resolveur)
    resolveurfolders = 'script.module.resolveurl'
    xbmcgui.Dialog().notification("ResolveURL", "[B][COLOR red]Delete Settings[/COLOR][/B]", icon='special://home/addons/script.module.resolveurl/icon.png', sound=False)




#######################
def Help_Realdebrid():
    funcs = (click__1, click__2, click__3)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Real Debrid / URL Resolver ~[/COLOR][/B]', 
['[B][COLOR=white]Foto[/COLOR][/B]',

 '[B][COLOR=white]video[/COLOR][/B]',

 '[B][COLOR=white]Site[/COLOR][/B]',
  ])


    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click__1():
    xbmc.executebuiltin('ActivateWindow(10002,"special://home/media/ResolveURL/",return)')

def click__2():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.youtube/play/?video_id=HrZctOPGvdM")')

def click__3():
    xbmc.executebuiltin('RunScript("script.realdebridsite")')


#######################
def derbid_authorize():
    funcs = (action___1, action___2, action___3, action___4, action___5, action___6, action___7, action___8, action___9, action___10)
    selection = xbmcgui.Dialog().select('[B][COLOR=orange]Εξουσιοδότηση - Επαναφορά Derbid[/COLOR][/B]', 
['[B][COLOR=white][COLOR=lime]Authorize [COLOR=white]Real-Derbid[/COLOR][/B]',
 '[B][COLOR=white][COLOR=lime]Authorize [COLOR=white]AllDerbid[/COLOR][/B]',
 '[B][COLOR=white][COLOR=lime]Authorize [COLOR=white]Premiumize.me[/COLOR][/B]',
 '[B][COLOR=white][COLOR=lime]Authorize [COLOR=white]Debrid-Link.fr[/COLOR][/B]',
 '[B][COLOR=white][COLOR=lime]Authorize [COLOR=white]Link Snappy[/COLOR][/B]',
 '[B][COLOR=white][COLOR=orange]Reset [COLOR=white]Real-Debrid[/COLOR][/B]',
 '[B][COLOR=white][COLOR=orange]Reset [COLOR=white]AllDebrid[/COLOR][/B]',
 '[B][COLOR=white][COLOR=orange]Reset [COLOR=white]Premiumize.me[/COLOR][/B]',
 '[B][COLOR=white][COLOR=orange]Reset [COLOR=white]Debrid-Link.fr[/COLOR][/B]',
 '[B][COLOR=white][COLOR=orange]Reset [COLOR=white]Link Snappy[/COLOR][/B]'])

    if selection:
        if selection < 0:
            return 
        func = funcs[selection-10]
        return func()
    else:
        func = funcs[selection]
        return func()
    return 

def action___1():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)')

def action___2():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_ad)')

def action___3():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_pm)')

def action___4():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_dl)')

def action___5():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_ls)')

def action___6():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_rd)')

def action___7():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_ad)')

def action___8():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_pm)')

def action___9():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_dl)')

def action___10():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_ls)')


def textBox(heading, announce):
    class TextBox():

        def __init__(self, *args, **kwargs):
            self.WINDOW = 10147
            self.CONTROL_LABEL = 1
            self.CONTROL_TEXTBOX = 5
            xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, ))
            self.win = xbmcgui.Window(self.WINDOW)
            xbmc.sleep(500)
            self.setControls()

        def setControls(self):
            self.win.getControl(self.CONTROL_LABEL).setLabel(heading)
            try:
                f = open(announce)
                text = f.read()
            except:
                text = announce
            self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
            return

    TextBox()
    while xbmc.getCondVisibility('Window.IsVisible(10147)'):
        xbmc.sleep(500)


def change():
    changelog = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.program.downloaderstartup/PY/Changelog/changelog4.txt'))
    heading = '[B][COLOR green]Fix Settings ResolveURL[/COLOR][/B]'
    f = open(changelog, 'r', encoding='utf-8')
    lines = f.readlines()
    announce = ''
    for line in lines:
        if not line.strip():
            break

        announce += line
    f.close()
    textBox(heading, announce)



Resolveurl()
