# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
icon_anymovies = 'https://www.downloads-anymovies.co/sitebuilder/images/download-anymovie_logo-312x45.jpg'
ANYMOVIES = 'https://www.downloads-anymovies.co'


def menu_year(): #91
    addDir('[COLOR white]2022[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2022', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2021[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2021', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2020[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2020', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2019[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2019', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2018[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2018', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2017[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2017', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2016[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2016', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2015[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2015', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2014[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2014', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2013[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2013', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2012[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2012', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2011[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2011', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2010[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2010', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2009[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2009', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2008[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2008', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2007[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2007', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2006[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2006', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2005[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2005', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2004[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2004', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2003[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2003', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2002[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2002', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2001[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2001', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]2000[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=2000', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1999[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1999', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1998[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1998', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1997[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1997', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1996[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1996', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1995[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1995', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1994[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1994', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1993[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1993', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1992[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1992', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1991[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1991', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1990[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1990', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1989[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1989', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1988[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1988', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1987[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1987', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1986[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1986', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1985[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1985', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1984[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1984', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1983[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1983', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1982[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1982', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1981[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1981', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1980[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1980', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1979[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1979', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1978[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1978', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1977[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1977', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1976[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1976', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1975[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1975', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1974[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1974', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1973[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1973', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1972[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1972', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1971[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1971', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1970[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1970', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1969[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1969', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1968[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1968', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1967[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1967', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1966[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1966', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1965[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1965', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1964[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1964', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1963[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1963', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]1962[/COLOR]', ANYMOVIES + '/movies/search.php?zoom_query=1962', 94, icon_anymovies, FANART, '')


def menu_genre(): #92
    addDir('[COLOR white]Action[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Action', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]Adventure[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Adventure', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]Sport[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Sport', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]Sci-Fi[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Sci-Fi', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]Horror[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Horror', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]Thriller[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Thriller', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]Comedy[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Comedy', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]Crime[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Crime', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]Western[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Western', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]Animation[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Animation', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]Documentary[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Documentary', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]Romance[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Romance', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]War[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=War', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]Drama[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Drama', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]Family[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Family', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]Fantasy[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Fantasy', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]History[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=History', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]Biography[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Biography', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]Mystery[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Mystery', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]Music[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Music', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]Musical[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Musical', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]Biography[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Biography', 94, icon_anymovies, FANART, '')
    addDir('[COLOR white]Mystery[/COLOR]', ANYMOVIES + '/movies/movies.php?zoom_query=Mystery', 94, icon_anymovies, FANART, '')

def anymovies(url): #94
    hdrs = {'Referer': ANYMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<img src="(.+?)" alt="" class="result_image" /></a></div><div class="result_title"><a href="(.+?)">(.+?)</a>', re.DOTALL).findall(p)
    for icon, url, name in m:
        name = name.replace(')',')').replace('Watch ','').replace(' Full Movie Online Free','').replace('&#39;s','').replace('Free','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 93, icon, FANART, '')
    try:
        m = re.compile('<a href="(.+?)">Next &gt;&gt;</a> </div>.+?</div>').findall(p)[0]
        m = m.replace('amp;','')
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', (ANYMOVIES+m), 94, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass


def get_links(name, url, iconimage, description): #93
    hdrs = {'Referer': ANYMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<span class="text"><a href="(.+?)" target="_blank"><b>').findall(p)
    for url in m:
        name = url
        addDir(name, url, 100, '', FANART, str(description))
