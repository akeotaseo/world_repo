## 2.3
- Mother Earth Jazz channel url changed

## 2.2
- added Mother Earth Jazz channel

## 2.1
- updated to https 
- added artist fanart background when available

## v2.0

- metadata for the streams
- classical and instrumental stream

## v1.0

- Initial release
