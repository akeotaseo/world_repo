﻿# -*- coding: utf-8 -*-

import re
import os
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import shutil
import socket
import random
import time
import requests
import ssl
from urllib.parse import parse_qsl, urlparse, urlencode, quote, quote_plus, unquote_plus
from bs4 import BeautifulSoup, UnicodeDammit
from concurrent.futures import *
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


socket.setdefaulttimeout(30)
HOST_AND_PATH				= sys.argv[0]
ADDON_HANDLE				= int(sys.argv[1])
dialog									= xbmcgui.Dialog()
addon									= xbmcaddon.Addon()
addon_id							= addon.getAddonInfo('id')
addon_name						= addon.getAddonInfo('name')
addon_version					= addon.getAddonInfo('version')
addon_desc						= addon.getAddonInfo('description')
addonPath							= xbmcvfs.translatePath(addon.getAddonInfo('path')).encode('utf-8').decode('utf-8')
dataPath								= xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode('utf-8').decode('utf-8')
tempDATA							= xbmcvfs.translatePath(os.path.join(dataPath, 'tempDATA', '')).encode('utf-8').decode('utf-8')
WORKS_FILE						= xbmcvfs.translatePath(os.path.join(dataPath, 'episode_data.json'))
FAVORIT_FILE						= xbmcvfs.translatePath(os.path.join(dataPath, 'favorites_SKYLINE.json'))
defaultFanart						= os.path.join(addonPath, 'resources', 'media', 'fanart.jpg')
icon										= os.path.join(addonPath, 'resources', 'media', 'icon.png')
artpic									= os.path.join(addonPath, 'resources', 'media', '').encode('utf-8').decode('utf-8')
flagpic								= os.path.join(addonPath, 'resources', 'media', 'country', '').encode('utf-8').decode('utf-8')
WEB_LANG							= {0: 'de', 1: 'en', 2: 'fr', 3: 'es', 4: 'it', 5: 'el', 6: 'pl', 7: 'ru', 8: 'hr', 9: 'sl'}[int(addon.getSetting('language'))]
# Available Languages(settings) ~ German=0|English=1|French=2|Spanish=3|Italian=4|Greek=5|Polish=6|Russian=7|Croatian=8|Slovenian=9
# Language Codes(SkylineWebCams) ~ 0: de|1: en|2: fr|3: es|4: it|5: el|6: pl|7: ru|8: hr|9: sl
CACHE_PERIOD					= int(addon.getSetting('cache_rhythm'))
LIMITATION						= int(addon.getSetting('max_entries'))
showWEATHER					= (True if addon.getSetting('show_weather') == 'true' else False)
useThumbAsFanart			= addon.getSetting('use_fanart') == 'true'
LAST_STORED					= (int(addon.getSetting('last_agent_stored')) or 0)
ACTUAL_AGENT					= addon.getSetting('actual_user_agent')
enableBACK						= addon.getSetting('show_homebutton') == 'true'
PLACEMENT						= int(addon.getSetting('button_place'))
enableADJUSTMENT			= addon.getSetting('show_settings') == 'true'
DEB_LEVEL							= (xbmc.LOGINFO if addon.getSetting('enable_debug') == 'true' else xbmc.LOGDEBUG)
KODI_ov20							= int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) >= 20
KODI_un21							= int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) <= 20
# IMG_flags						= 'https://img.freeflagicons.com/thumb/round_icon/{}/{}_640.png'
FULL_URL							= f'https://www.skylinewebcams.com/{WEB_LANG}/webcam.html'
TOPS_URL							= f'https://www.skylinewebcams.com/{WEB_LANG}/top-live-cams.html'
NEWS_URL							= f'https://www.skylinewebcams.com/{WEB_LANG}/new-livecams.html'
LANG_URL							= f"https://www.skylinewebcams.com/{WEB_LANG}.html"
BASE_URL							= "https://www.skylinewebcams.com"

xbmcplugin.setContent(ADDON_HANDLE, 'movies')

def py3_dec(d, nom='utf-8', ign='ignore'):
	if isinstance(d, bytes):
		d = d.decode(nom, ign)
	return d

def translation(id):
	return addon.getLocalizedString(id)

def failing(content):
	log(content, xbmc.LOGERROR)

def debug_MS(content):
	log(content, DEB_LEVEL)

def log(msg, level=xbmc.LOGINFO):
	return xbmc.log(f"[{addon_id} v.{addon_version}]{str(msg)}", level)

def build_mass(body):
	return f"{HOST_AND_PATH}?{urlencode(body)}"

def getRandom():
	WEBBROWSER = [['%s.0' % i for i in range(18, 50)], ['37.0.2062.103', '37.0.2062.120', '37.0.2062.124', '38.0.2125.101','38.0.2125.104',
		'38.0.2125.111', '39.0.2171.71', '39.0.2171.95', '39.0.2171.99', '40.0.2214.93', '40.0.2214.111', '40.0.2214.115', '39.0.2171.99',
		'40.0.2214.93', '40.0.2214.111', '40.0.2214.115', '42.0.2311.90', '42.0.2311.135', '42.0.2311.152', '43.0.2357.81', '43.0.2357.124',
		'44.0.2403.155', '44.0.2403.157', '45.0.2454.101', '45.0.2454.85', '46.0.2490.71', '46.0.2490.80', '46.0.2490.86', '47.0.2526.73',
		'47.0.2526.80', '49.0.2623.112', '50.0.2661.86'], ['11.0'], ['8.0', '9.0', '10.0', '10.6']]
	WINDOWS = ['Windows NT 10.0', 'Windows NT 7.0', 'Windows NT 6.3', 'Windows NT 6.2', 'Windows NT 6.1', 'Windows NT 6.0',
		'Windows NT 5.1', 'Windows NT 5.0']
	FEATURES = ['; WOW64', '; Win64; IA64', '; Win64; x64', '']
	RANDOM_AGENT = ['Mozilla/5.0 ({windows}{features}; rv:{browser}) Gecko/20100101 Firefox/{browser}',
		'Mozilla/5.0 ({windows}{features}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{browser} Safari/537.36',
		'Mozilla/5.0 ({windows}{features}; Trident/7.0; rv:{browser}) like Gecko']
	index = random.randrange(len(RANDOM_AGENT))
	releases = {'windows': random.choice(WINDOWS), 'features': random.choice(FEATURES), 'browser': random.choice(WEBBROWSER[index])}
	new_agent = RANDOM_AGENT[index].format(**releases)
	if ((ACTUAL_AGENT == "") or (LAST_STORED < time.time() - (15 * 60))): # Time in Seconds : 15*60 = 15 min.
		addon.setSetting('actual_user_agent', new_agent), addon.setSetting('last_agent_stored', str(int(time.time())))
		debug_MS(f"(common.getRandom) === CREATED NEW AGENT === AGENT : {new_agent} || TIME : {int(time.time())} ===")
	else: new_agent = ACTUAL_AGENT
	return new_agent

def _header(ORIGIN=None, REFERRER=None):
	header = {} # !!! Accept-Language only set if browser should offer these languages !!!
	header['Cache-Control'] = 'public, max-age=300'
	header['Accept'] = 'application/json, application/x-www-form-urlencoded, text/plain, */*'
	header['documentLifecycle'] = 'active'
	header['User-Agent'] = getRandom()
	header['DNT'] = '1'
	header['Upgrade-Insecure-Requests'] = '1'
	header['Accept-Encoding'] = 'gzip'
	if ORIGIN: header['Origin'] = ORIGIN
	if REFERRER: header['Referer'] = REFERRER
	return header

def getMultiData(MURLS, method='GET', ORG=BASE_URL, REF=LANG_URL, timeout=5, retries=2):
	COMBI_NEW, number = [], len(MURLS)
	def download(pos, extra, url):
		UNCHECK = ssl.create_default_context()
		UNCHECK.check_hostname = False
		UNCHECK.verify_mode = ssl.CERT_NONE
		connector = urllib3.PoolManager(block=True, ssl_context=UNCHECK, maxsize=20)
		with connector.request(method, LANG_URL, headers=_header(ORG, REF), preload_content=False, redirect=True, timeout=timeout, retries=retries) as mrs:
			if mrs.status in [200, 201, 202, 300, 301, 302]:
				response = connector.request(method, url, headers=_header(ORG, REF), redirect=True, timeout=timeout, retries=retries)
				if response.status in [200, 201, 202, 300, 301, 302]:
					debug_MS(f"(common.getMultiData[1]) === POS : {pos} === URL : {url} === HEADER : {_header(ORG, REF)} ===")
					return [pos, extra, url, py3_dec(response.data)]
				else:
					failing(f"(common.getMultiData[1]) ERROR - RESPONSE - ERROR ##### POS : {pos} === STATUS : {response.status} === URL : {url} #####")
					return [pos, extra, url, None]
		connector.clear()
	with ThreadPoolExecutor() as executor:
		picker = [executor.submit(download, pos, extra, url) for pos, extra, url in MURLS]
		wait(picker, timeout=30, return_when=ALL_COMPLETED)
		for ii, future in enumerate(as_completed(picker), 1):
			try:
				COMBI_NEW.append(future.result())
			except Exception as exc:
				failing(f"(common.getMultiData[2]) ERROR - EXEPTION - ERROR ##### FUTURE_RESULT : {future.result()} === FAILURE : {exc} #####")
				dialog.notification(translation(30521).format('DETAILS'), translation(30523).format(exc), icon, 10000)
				executor.shutdown()
		if COMBI_NEW:
			matching = [flop for flop in COMBI_NEW[:] if flop[3] is None]
			if len(matching) == number or len(matching) > 10:
				dialog.notification(translation(30521).format('DETAILS'), translation(30524), icon, 10000)
		return COMBI_NEW

def getContent(url, method='GET', queries='TEXT', ORG=BASE_URL, REF=LANG_URL, headers={}, redirects=True, verify=True, data=None, json=None, timeout=30):
	ANSWER = None
	try:
		response = requests.request(method, url, headers=_header(ORG, REF), allow_redirects=redirects, verify=verify, timeout=timeout)
		ANSWER = response.json() if queries == 'JSON' else response.text if queries == 'TEXT' else response
		debug_MS(f"(common.getContent) === CALLBACK === STATUS : {response.status_code} || URL : {response.url} || HEADER : {_header(ORG, REF)} ===")
	except requests.exceptions.RequestException as exc:
		failing(f"(common.getContent) ERROR - EXEPTION - ERROR ##### URL : {url} === FAILURE : {exc} #####")
		dialog.notification(translation(30521).format('URL'), translation(30523).format(exc), icon, 12000)
		return sys.exit(0)
	return ANSWER

def preserve(store, data=None):
	if data is not None:
		with open(store, 'w') as topics:
			json.dump(data, topics, indent=2, sort_keys=True)
	else:
		with open(store, 'r') as topics:
			arrive = json.load(topics)
		return arrive

def clear_storage():
	debug_MS("(common.clear_storage) -------------------------------------------------- START = clear_storage --------------------------------------------------")
	debug_MS("(common.clear_storage) ========== Delete the Addon-Cache now ==========")
	if xbmcvfs.exists(tempDATA):
		shutil.rmtree(tempDATA, ignore_errors=True) # Delete tempDATA-Folder
	xbmc.sleep(1000)
	return dialog.ok(addon_id, translation(30501))

def cleanUmlaut(wrong):
	if wrong is not None:
		for wg in (('ä', 'ae'), ('Ä', 'Ae'), ('ü', 'ue'), ('Ü', 'Ue'), ('ö', 'oe'), ('Ö', 'Oe'), ('ß', 'ss')):
			wrong = wrong.replace(*wg)
		wrong = wrong.strip()
	return wrong

def clear_unknown(text):
	if text is not None:
		text = re.sub(r'<h3>.*?</h3>', '', text)
		for ea in (('<strong>', ''), ('</strong>', ''), ('<b>', ''), ('</b>', ''), ('<em>', ''), ('</em>', ''), ('<br>', ' '), ('</p>', '[CR]')):
			text = text.replace(*ea)
		convert = UnicodeDammit(text.strip()) # Declare unknown Encodings in Request-results (from bs4 import UnicodeDammit)
		return convert.unicode_markup
	return None

def create_entries(metadata, SIGNS=None):
	listitem = xbmcgui.ListItem(metadata['Title'])
	vinfo = listitem.getVideoInfoTag() if KODI_ov20 else {}
	if KODI_ov20: vinfo.setTitle(metadata['Title'])
	else: vinfo['Title'] = metadata['Title']
	if metadata.get('Tagline', ''):
		if KODI_ov20: vinfo.setTagLine(metadata['Tagline'])
		else: vinfo['Tagline'] = metadata['Tagline']
	description = metadata['plot_long'] if metadata.get('plot_long') not in ['', 'None', None] else ' '
	if KODI_ov20: vinfo.setPlot(description)
	else: vinfo['Plot'] = description
	if metadata.get('Country', ''):
		if KODI_ov20: vinfo.setCountries([metadata['Country']])
		else: vinfo['Country'] = metadata['Country']
	if str(metadata.get('Rating')).replace('.', '').isdecimal() and str(metadata.get('Voting')).isdecimal():
		if KODI_ov20: vinfo.setRating(float(metadata['Rating']), int(metadata['Voting']), 'user', True) # vinfo.setRating(4.6, 8940, "imdb", True) since NEXUS and UP
		else: listitem.setRating('user', float(metadata['Rating']), int(metadata['Voting']), True) # listitem.setRating("imdb", 4.6, 8940, True) below NEXUS (MATRIX)
	if metadata.get('Studio', ''):
		if KODI_ov20: vinfo.setStudios([metadata['Studio']])
		else: vinfo['Studio'] = metadata['Studio']
	if metadata.get('Mediatype', ''):
		if KODI_ov20: vinfo.setMediaType(metadata['Mediatype'])
		else: vinfo['Mediatype'] = metadata['Mediatype']
	picture, piclogo = metadata.get('Image', icon), metadata.get('Logo', None)
	listitem.setArt({'icon': icon, 'thumb': picture, 'poster': picture, 'clearlogo': piclogo})
	if useThumbAsFanart: listitem.setArt({'fanart': defaultFanart})
	if not KODI_ov20: listitem.setInfo('Video', vinfo)
	return listitem
