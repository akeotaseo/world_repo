# -*- coding: utf-8 -*-
import requests
from lib import scrapers
from lib.broadcaster_result import BroadcasterResult

BASE_URL = "https://sportitalia.com/{}/"

CHANNELS = {
    "sihd": "sportitalia-hd-live",
    "calcio": "si-solocalcio-hd",
    "motori": "si-motori-hd",
    "live24": "silive24-hd"
}

def play(search):
    res = BroadcasterResult
    url = ""

    if search in CHANNELS:
        requrl = BASE_URL.format(CHANNELS[search])
        data = requests.get(requrl).text
        url = scrapers.findSingleMatch(data, r"source\s*=\s?'([^']+)")

    if url:
        res.Url = url
        res.ManifestType = "hls"

    return res
