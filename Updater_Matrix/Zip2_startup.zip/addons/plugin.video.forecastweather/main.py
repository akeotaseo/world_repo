﻿import sys
import urllib.parse
import urllib.request
import re
import ssl
import xbmcgui
import xbmcplugin
import xbmcaddon

# Βασικές ρυθμίσεις
BASE_URL = "https://www.forecastweather.gr"
START_URL = BASE_URL + "/kameres.html"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
ADDON_HANDLE = int(sys.argv[1])

# Δημιουργία Context για παράκαμψη SSL errors
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

def get_html(url):
    req = urllib.request.Request(url)
    req.add_header('User-Agent', USER_AGENT)
    try:
        response = urllib.request.urlopen(req, context=ctx)
        return response.read().decode('utf-8')
    except Exception as e:
        # Μόνο σε σοβαρό σφάλμα σύνδεσης (π.χ. κομμένο ίντερνετ) βγάζουμε μήνυμα
        xbmcgui.Dialog().notification('Σφάλμα Σύνδεσης', str(e), xbmcgui.NOTIFICATION_ERROR)
        return None

def build_url(query):
    return sys.argv[0] + '?' + urllib.parse.urlencode(query)

# Έλεγχος αν η ροή είναι ενεργή (Health Check)
def is_stream_online(url, referer):
    req = urllib.request.Request(url)
    req.add_header('User-Agent', USER_AGENT)
    req.add_header('Referer', referer)
    try:
        # Timeout 5 δευτερόλεπτα για να μην περιμένει αιώνια
        with urllib.request.urlopen(req, context=ctx, timeout=5) as response:
            if response.getcode() == 200:
                return True
    except:
        return False
    return False

def list_categories():
    html = get_html(START_URL)
    if not html: return

    pattern = r'<div class="subcategory-img"><a href="([^"]+)"><img src="([^"]+)"[^>]+></a></div><h3><a href="[^"]+">([^<]+)</a></h3>'
    matches = re.findall(pattern, html)

    for link, img, title in matches:
        full_link = BASE_URL + link if not link.startswith('http') else link
        clean_img = img.split('#')[0]
        full_img = BASE_URL + clean_img if not clean_img.startswith('http') else clean_img
        
        url = build_url({'mode': 'list_cameras', 'link': full_link})
        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': full_img, 'icon': full_img})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_cameras(url):
    html = get_html(url)
    if not html: return

    pattern = r'<div class="subcategory-img"><a href="([^"]+)"><img src="([^"]+)"[^>]+></a></div><h3><a href="[^"]+">([^<]+)</a></h3>'
    matches = re.findall(pattern, html)

    for link, img, title in matches:
        full_link = BASE_URL + link if not link.startswith('http') else link
        clean_img = img.split('#')[0]
        clean_img = clean_img.split('?')[0]
        full_img = BASE_URL + clean_img if not clean_img.startswith('http') else clean_img

        play_url = build_url({'mode': 'play', 'link': full_link, 'title': title, 'icon': full_img})
        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': full_img, 'icon': full_img})
        li.setInfo('video', {'title': title})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_camera(url, title, icon):
    # Αφαιρέθηκε το popup "Ανάκτηση ροής..."
    
    html = get_html(url)
    if not html: return

    # Regex για εύρεση του m3u8
    pattern = r'["\'](https?://[^"\']+\.m3u8)["\']'
    match = re.search(pattern, html)

    if match:
        stream_url = match.group(1)
        
        # ΕΛΕΓΧΟΣ: Πριν δώσουμε το link στο Kodi, ελέγχουμε αν απαντάει
        if is_stream_online(stream_url, url):
            headers = '|User-Agent={}&Referer={}'.format(
                urllib.parse.quote(USER_AGENT), 
                urllib.parse.quote(url)
            )
            final_url = stream_url + headers
            
            li = xbmcgui.ListItem(label=title)
            li.setArt({'thumb': icon, 'icon': icon})
            li.setInfo('video', {'title': title})
            li.setPath(final_url)
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=li)
        else:
            # Μήνυμα ΜΟΝΟ αν η κάμερα είναι Offline
            xbmcgui.Dialog().notification('Camera Offline', 'Η ζωντανή ροή δεν είναι διαθέσιμη', xbmcgui.NOTIFICATION_WARNING, 5000)
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, listitem=xbmcgui.ListItem())
            
    else:
        # Fallback για YouTube Embeds
        yt_pattern = r'youtube\.com/embed/([^"\?]+)'
        yt_match = re.search(yt_pattern, html)
        if yt_match:
            yt_id = yt_match.group(1)
            final_url = f"plugin://plugin.video.youtube/play/?video_id={yt_id}"
            li = xbmcgui.ListItem(label=title)
            li.setPath(final_url)
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=li)
        else:
            # Μήνυμα αν δεν βρεθεί καθόλου λινκ βίντεο
            xbmcgui.Dialog().notification('Σφάλμα', 'Δεν βρέθηκε ροή βίντεο', xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, listitem=xbmcgui.ListItem())

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    mode = params.get('mode')

    if mode is None:
        list_categories()
    elif mode == 'list_cameras':
        list_cameras(params['link'])
    elif mode == 'play':
        play_camera(params['link'], params.get('title', 'Camera'), params.get('icon', ''))

if __name__ == '__main__':
    router(sys.argv[2][1:])