import requests
import xbmcaddon
import xbmcgui
from falconAPI import FalconAPI

authAddonID = "repository.Parrot"
_ADDON_NAME = xbmcaddon.Addon(authAddonID).getAddonInfo('name')

def getUsername(): return xbmcaddon.Addon(authAddonID).getSetting("username")
def getPassword(): return xbmcaddon.Addon(authAddonID).getSetting("password")

def offlineMode(): exit()

def login():
    username = getUsername()
    password = getPassword()
    if username == "" or password == "":
        xbmcaddon.Addon(authAddonID).setSetting('verified', 'false')
        xbmcgui.Dialog().notification(_ADDON_NAME, "Login failed", xbmcgui.NOTIFICATION_INFO, 5000)
        xbmcaddon.Addon(authAddonID).openSettings()
        return False
    
    FALCON_API = FalconAPI()
    
    headers = {
        'User-Agent': FALCON_API.userAgent,
    }

    data = {
        "username": username,
        "password": password,
    }

    for addon_ in ["script.module.parrot", "plugin.video.parrottv", "repository.Parrot", "plugin.video.kukajto"]:
        try: data[addon_] = xbmcaddon.Addon(addon_).getAddonInfo("version")
        except: pass


    try:
        jsonResp = requests.post(FALCON_API.createURL("login"), verify=False, headers=headers, data=data).json()
    except Exception as e:
        xbmcgui.Dialog().notification(_ADDON_NAME, "Login Failed due to server error, please try again later", xbmcgui.NOTIFICATION_INFO, 5000)
        return False

    if jsonResp['status'] == 'success':
        xbmcaddon.Addon(authAddonID).setSetting('verified', 'true')
        xbmcaddon.Addon(authAddonID).setSetting('token', jsonResp["token"])
        return True
    else:
        xbmcaddon.Addon(authAddonID).setSetting('verified', 'false')
        xbmcaddon.Addon(authAddonID).setSetting('token', '')
        xbmcgui.Dialog().notification(_ADDON_NAME, "Login failed", xbmcgui.NOTIFICATION_INFO, 5000)
        xbmcaddon.Addon(authAddonID).openSettings()
        return False
