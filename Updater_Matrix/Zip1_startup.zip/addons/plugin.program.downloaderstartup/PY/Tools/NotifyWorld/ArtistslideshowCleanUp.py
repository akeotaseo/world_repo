﻿import os, xbmc, xbmcvfs, xbmcgui, shutil, glob



                       #script.artistslideshow
base_path = xbmcvfs.translatePath('special://home/userdata/addon_data/script.artistslideshow')

dir_list = glob.iglob(os.path.join(base_path, "ArtistInformation"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)


base_path = xbmcvfs.translatePath('special://home/userdata/addon_data/script.artistslideshow')

dir_list = glob.iglob(os.path.join(base_path, "ArtistSlideshow"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)