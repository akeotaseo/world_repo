# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

from .utils.resolve import Resolver
from .plugins import *

def resolve(module, channel, username="", password="", data_file="./data.json"):
    """
    Args:
        module (str): Plugin to use
        channel (str): Channel to grab
        username (str): Not required, some sources have defaults
        password (str): Not required, some sources have defaults
        data_file (str): Where to store data, default: ./data.json

    Returns:
        rmf (ResolvedMediaFile): use .url or .headers to get data, .test() to test if stream works
    """

    # Filename / Classname in python cannot start with int
    if module[0].isdigit(): module = f"N{module}"

    return Resolver(data_file).resolve(module, channel, username=username, password=password)
    