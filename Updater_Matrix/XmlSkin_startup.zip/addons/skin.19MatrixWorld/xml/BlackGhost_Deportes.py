﻿import os, xbmc, xbmcgui, webbrowser, xbmcaddon
def Backup():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('Action(Back)')
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('ActivateWindow(Home)')
    # xbmc.sleep(1000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση[/COLOR][/B]", "Black ghost Deportes", sound=False, icon='http://addonbg.co/black/img/deportes.png')
    xbmc.sleep(4000)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=http%3a%2f%2fblackaddon.com%2fgray%2fimg%2ffanart.jpg&mode=1&name=Deportes&url=https://bs67.short.gy/bg_deportes")')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=http%3a%2f%2fblackaddon.com%2fgray%2fimg%2ffanart.jpg&mode=1&name=Deportes&url=https://bs67.short.gy/bg_deportes")')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=http%3a%2f%2fblackaddon.com%2fgray%2fimg%2ffanart.jpg&mode=1&name=Deportes&url=https://bs67.short.gy/bg_deportes")')


    #xbmc.executebuiltin('Action(Back)')
    #xbmc.executebuiltin('Dialog.Close(all,true)')
    #xbmc.sleep(1000)

Backup()