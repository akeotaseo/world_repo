﻿import xbmc, xbmcaddon
from updatervar import *


def set_setting():


    ###  plugin.program.downloader19   ###

    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('addonsreposversion')=='0':
        xbmc.sleep(1000)
        setting_set_downloader19('addonsreposversion', '0')

        xbmc.sleep(2000)



#            xbmc.executebuiltin("ReloadSkin()")

set_setting()
