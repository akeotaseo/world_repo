﻿import xbmc, xbmcgui
# Αναζήτηση
def searchsubsettings():
    if xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin("ActivateWindowAndFocus(OSDSubtitleSettings)")
        xbmc.sleep(500)
        xbmcgui.Dialog().notification("[B][COLOR orange]Διαδρομή Αποθήκευσης Υποτίτλων[/COLOR][/B]", "[COLOR green]userdata/subs[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/sub.png')
        xbmc.sleep(500)
        xbmc.executebuiltin('SendClick(-177)')
    while xbmc.getCondVisibility("Window.IsVisible(OSDSubtitleSettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")



    if not xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin("ActivateWindowAndFocus(OSDSubtitleSettings)")
        xbmc.executebuiltin("Action(Pause)")
        xbmc.sleep(500)
        xbmcgui.Dialog().notification("[B][COLOR orange]Διαδρομή Αποθήκευσης Υποτίτλων[/COLOR][/B]", "[COLOR green]userdata/subs[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/sub.png')
        xbmc.sleep(500)
        xbmc.executebuiltin('SendClick(-177)')
    while xbmc.getCondVisibility("Window.IsVisible(OSDSubtitleSettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")

searchsubsettings()
