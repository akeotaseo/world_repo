# -*- coding: utf-8 -*-
# Module: security
# Author: Zeltorix
# Created on: 2023.11.21
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
from view import View
import keyring


class Locker:
    __slots__ = []
    _view = View()

    def set_data(self, label: str, data: str) -> bool:
        keyring.set_password(
            self._view.id_plugin,
            label,
            data,
        )
        return True

    def get_data(self, label: str) -> str:
        return keyring.get_password(
            self._view.id_plugin,
            label,
        )

    def delete_data(self, label: str) -> bool:
        keyring.delete_password(
            self._view.id_plugin,
            label,
        )
        return True
