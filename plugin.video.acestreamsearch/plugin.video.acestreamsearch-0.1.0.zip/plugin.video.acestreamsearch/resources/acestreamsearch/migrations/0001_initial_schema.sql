CREATE TABLE IF NOT EXISTS channels 
(id TEXT, name TEXT, status INTEGER, address TEXT);

PRAGMA user_version=0001;
