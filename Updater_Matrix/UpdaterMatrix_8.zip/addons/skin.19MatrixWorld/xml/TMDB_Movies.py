﻿import xbmc, xbmcgui

def TMDB_Movies():
    xbmcgui.Dialog().notification("[B][COLOR green]TMDB Movies[/COLOR][/B]", "[COLOR lime]Popular[/COLOR]", sound=False, icon='special://home/addons/plugin.video.themoviedb.helper/icon.png')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.themoviedb.helper/?info=dir_movie")')
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.themoviedb.helper/?info=popular&tmdb_type=movie")')

TMDB_Movies()