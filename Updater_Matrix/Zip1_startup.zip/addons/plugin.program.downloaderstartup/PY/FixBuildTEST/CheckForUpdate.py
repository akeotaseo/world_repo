﻿# -*- coding: utf-8 -*-
import xbmc
from updatervar import *
from resources.lib.modules import check


if __name__ == '__main__':
	if not setting('updaterversion') == 'false':

		BG.create(Dialog_U1, 'Έλεγχος για ενημέρωση του Build')
		xbmc.sleep(1000)
#		check.UpdateAddonRepos()
		check.updater()  #downloader_startup#
#		check.notifyT()
		check.autoenable()
		check.var()
		check.setsetting()
		check.players()
		check.delete()
		BG.update(40, Dialog_U1, 'Έλεγχος για ενημέρωση του Build')
		xbmc.sleep(1000)
		check.zip1()
		check.zip2()
		check.zip3()
		check.zip4()
		check.zip5()
		check.pvr()
		BG.update(80, Dialog_U1, 'Έλεγχος για ενημέρωση του Build')
		xbmc.sleep(1000)
		check.installation()
		check.database()
		check.xmlskin()
		BG.update(100, Dialog_U1, 'Το build φαίνεται ενημερωμένο')
		xbmc.sleep(3000)
		dialog.notification('   ','   ', icon_ok, sound=False)
		xbmc.sleep(5000)
		xbmc.executebuiltin("ReloadSkin()")
