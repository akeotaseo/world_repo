import xbmc, xbmcgui


def wolf():
    funcs = (click_1, click_2, click_3, click_4)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Wolf ~[/COLOR][/B]', 
['[B][COLOR=purple]---Διαγραφή The Crew---[/B][B][COLOR purple][/COLOR][/B]',
 '[B][COLOR=firebrick]No Lives Matter[/COLOR][/B]',
 '[B][COLOR=white]Wolf Pack[/COLOR][/B]',
 '[B][COLOR yellow]Big Bad Wolf[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/DeleteTheCrew/DeleteTheCrew.py")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.nlm,return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.wolfpack,return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.bigbadwolf,return)')


wolf()
