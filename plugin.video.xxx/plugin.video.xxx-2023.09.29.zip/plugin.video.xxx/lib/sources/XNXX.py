import re
import xbmcaddon
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

BaseURL = 'https://www.xnxx.com'
Thumb   = 'special://home/addons/plugin.video.xxx/resources/art/xnxx.png'


def Menu():
	addDir('Today\'s Selection', BaseURL + '/todays-selection', 161, Thumb)
	#addDir('Most Viewed Videos', BaseURL + '/most-popular/1/',   161, Thumb)
	#addDir('Top Rated Videos',   BaseURL + '/top-rated/1/',      161, Thumb)
	#addDir('Categories',         BaseURL + '/categories/',     162, Thumb)

def Browse(url):
	r = OpenURL(url)
	r = r.replace('\n', '')
	r = r.replace('	', '')
	m = re.compile('<a href="(.+?)"><img src="(.+?)" data-src="(.+?)" data-idcdn=".+?" data-videoid=".+?" id=".+?" alt="" /></a></div></div><div class=".+?">.+?title="(.+?)".+?\n.+?\n(.+?)min').findall(r)
	for url, thumb, title, time in m:
		time = time + 'mins'
		url = BaseURL + url
		if Setting('show_time') == 'true': title = '[B](%s)[/B] %s' % (time, title)
		import random
		random_id = random.randint(0,1000000)
		url = '%s&random_id=%s' % (url, str(random_id))
		addVideo(title, url, 163, thumb)
	n = re.compile('<li class="item-pagin is_last">\n.+?<a class="link" href="(.+?)" ').findall(r)
	for NextPage in n:
		addDir('Next page >' + NextPage, BaseURL + NextPage, 161, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	Common.SetView()

def Categories(url):
	r = OpenURL(url)
	m = re.compile('<a class="link" href="https://www\.xtits\.com/categories/(.+?)/" title="(.+?)">').findall(r)
	for content_id, title in m:
		addDir(title, 'https://www.xtits.com/categories/%s/' % content_id, 161, Thumb)
	n = re.compile('<li class="item-pagin is_last">\n						<a class="link" href="(.+?)"').findall(r)
	for NextPage in n:
		addDir('Next page >', BaseURL + NextPage, 162, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')

def PlayStream(url):
	if 'random_id=' in url:
		url = re.compile('(.+?)&random_id').findall(url)[0]
	r = OpenURL(url)
	m = re.compile('video_url: \'(.+?)\'').findall(r)
	for url in m:
		Play(url)
