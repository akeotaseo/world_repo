from codequick import Route, Listitem, Resolver
from resources.lib.kedon import __addonnoti__, __addonname__, getlink, getlinkvnm, quangcao, tb, stream, referer
from xbmcgui import DialogProgress
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import quote_plus
from functools import lru_cache
import re
@lru_cache(maxsize=None)
def get_info_ophim(x):
	r = getlinkvnm(f'https://ophim1.com/v1/api/phim/{x}','https://ophim1.com/')
	try:
		kq = r.json()
		try:
			img = kq['data']['seoOnPage']['seoSchema']['image']
		except:
			img = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/ophim.png'
		try:
			ten = kq['data']['seoOnPage']['titleHead']
		except:
			ten = __addonname__
		try:
			mota = re.sub('<.*?>', '', kq['data']['item']['content'])
		except:
			mota = tb
		return (ten, img, mota)
	except:
		return None
@lru_cache(maxsize=None)
def process_url(url):
	try:
		data = get_info_ophim(url)
		return url, data
	except:
		return url, None
@Route.register
def search_ophim(plugin, search_query=None, **kwargs):
	yield []
	if search_query is None:
		pass
	else:
		dialog = DialogProgress()
		dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
		next_page = 1
		sr = quote_plus(search_query)
		url = f'https://ophim1.com/v1/api/tim-kiem?keyword={sr.replace(" ","+")}&page={next_page}'
		resp = getlink(url, url, 1800)
		if (resp is not None):
			ri = resp.json()['data']['items']
			urls = [k['slug'] for k in ri if 'phim-18' not in str(k)]
			length = len(urls)
			if length>0:
				count = 0
				with ThreadPoolExecutor(length) as ex:
					future_to_url = (ex.submit(process_url, url) for url in urls)
					ac = as_completed(future_to_url)
					for future in ac:
						l, data = future.result()
						if data is not None:
							if (dialog.iscanceled()):
								break
							count += 1
							done = int((count/length)*100)
							dialog.update(done, f'Đang giải mã {length} dữ liệu...\nLoading... [COLOR yellow]{done} %[/COLOR]')
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = data[2]
							item.info['mediatype'] = 'movie'
							item.art['thumb'] = item.art['fanart'] = data[1]
							item.set_callback(id_ophim, l)
							yield item
				item1 = Listitem()
				item1.label = f'Trang {next_page + 1}'
				item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
				item1.set_callback(ds_searchophim, search_query, next_page + 1)
				yield item1
		else:
			yield quangcao()
		dialog.close()
@Route.register
def ds_searchophim(plugin, search_query=None, next_page=None, **kwargs):
	yield []
	if search_query is None or next_page is None:
		pass
	else:
		dialog = DialogProgress()
		dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
		sr = quote_plus(search_query)
		url = f'https://ophim1.com/v1/api/tim-kiem?keyword={sr.replace(" ","+")}&page={next_page}'
		resp = getlink(url, url, 1800)
		if (resp is not None):
			ri = resp.json()['data']['items']
			urls = [k['slug'] for k in ri if 'phim-18' not in str(k)]
			length = len(urls)
			if length>0:
				count = 0
				with ThreadPoolExecutor(length) as ex:
					future_to_url = (ex.submit(process_url, url) for url in urls)
					ac = as_completed(future_to_url)
					for future in ac:
						l, data = future.result()
						if data is not None:
							if (dialog.iscanceled()):
								break
							count += 1
							done = int((count/length)*100)
							dialog.update(done, f'Đang giải mã {length} dữ liệu...\nLoading... [COLOR yellow]{done} %[/COLOR]')
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = data[2]
							item.info['mediatype'] = 'movie'
							item.art['thumb'] = item.art['fanart'] = data[1]
							item.set_callback(id_ophim, l)
							yield item
				item1 = Listitem()
				item1.label = f'Trang {next_page + 1}'
				item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
				item1.set_callback(ds_searchophim, search_query, next_page + 1)
				yield item1
		else:
			yield quangcao()
		dialog.close()
@Route.register
def index_ophim(plugin, **kwargs):
	yield Listitem.search(search_ophim)
	dulieu = {
	'Phim mới': '/home',
	'Phim bộ': '/danh-sach/phim-bo',
	'Phim bộ hoàn thành': '/danh-sach/phim-bo-hoan-thanh',
	'Phim lẻ': '/danh-sach/phim-le',
	'TV shows': '/danh-sach/tv-shows',
	'Hoạt hình': '/danh-sach/hoat-hinh',
	'Phim thuyết minh': '/danh-sach/phim-thuyet-minh',
	'Phim lồng tiếng': '/danh-sach/phim-long-tieng',
	'Phim phụ đề': '/danh-sach/phim-vietsub',
	'Phim phụ đề độc quyền': '/danh-sach/subteam',
	}
	yield Listitem.from_dict(**{'label': 'Thể loại',
	'info': {'plot': tb},
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/ophim.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/ophim.png'},
	'callback': op_tl})
	yield Listitem.from_dict(**{'label': 'Quốc gia',
	'info':{'plot':tb},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/ophim.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/ophim.png'},
	'callback': op_qg})
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.info['plot'] = tb
		item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/ophim.png'
		item.set_callback(ds_ophim, dulieu[k], 1)
		yield item
@Route.register
def op_tl(plugin, **kwargs):
	dulieu = {
	'Hành Động': '/the-loai/hanh-dong',
	'Tình Cảm': '/the-loai/tinh-cam',
	'Hài Hước': '/the-loai/hai-huoc',
	'Cổ Trang': '/the-loai/co-trang',
	'Tâm Lý': '/the-loai/tam-ly',
	'Hình Sự': '/the-loai/hinh-su',
	'Chiến Tranh': '/the-loai/chien-tranh',
	'Thể Thao': '/the-loai/the-thao',
	'Võ Thuật': '/the-loai/vo-thuat',
	'Viễn Tưởng': '/the-loai/vien-tuong',
	'Phiêu Lưu': '/the-loai/phieu-luu',
	'Khoa Học': '/the-loai/khoa-hoc',
	'Kinh Dị': '/the-loai/kinh-di',
	'Âm Nhạc': '/the-loai/am-nhac',
	'Thần Thoại': '/the-loai/than-thoai',
	'Tài Liệu': '/the-loai/tai-lieu',
	'Gia Đình': '/the-loai/gia-dinh',
	'Chính kịch': '/the-loai/chinh-kich',
	'Bí ẩn': '/the-loai/bi-an',
	'Học Đường': '/the-loai/hoc-duong',
	'Kinh Điển': '/the-loai/kinh-dien'
	}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.info['plot'] = tb
		item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/ophim.png'
		item.set_callback(ds_ophim, dulieu[k], 1)
		yield item
@Route.register
def op_qg(plugin, **kwargs):
	dulieu = {
	'Trung Quốc': '/quoc-gia/trung-quoc',
	'Hàn Quốc': '/quoc-gia/han-quoc',
	'Nhật Bản': '/quoc-gia/nhat-ban',
	'Thái Lan': '/quoc-gia/thai-lan',
	'Âu Mỹ': '/quoc-gia/au-my',
	'Đài Loan': '/quoc-gia/dai-loan',
	'Hồng Kông': '/quoc-gia/hong-kong',
	'Ấn Độ': '/quoc-gia/an-do',
	'Anh': '/quoc-gia/anh',
	'Pháp': '/quoc-gia/phap',
	'Canada': '/quoc-gia/canada',
	'Quốc Gia Khác': '/quoc-gia/quoc-gia-khac',
	'Đức': '/quoc-gia/duc',
	'Tây Ban Nha': '/quoc-gia/tay-ban-nha',
	'Thổ Nhĩ Kỳ': '/quoc-gia/tho-nhi-ky',
	'Hà Lan': '/quoc-gia/ha-lan',
	'Indonesia': '/quoc-gia/indonesia',
	'Nga': '/quoc-gia/nga',
	'Mexico': '/quoc-gia/mexico',
	'Ba lan': '/quoc-gia/ba-lan',
	'Úc': '/quoc-gia/uc',
	'Thụy Điển': '/quoc-gia/thuy-dien',
	'Malaysia': '/quoc-gia/malaysia',
	'Brazil': '/quoc-gia/brazil',
	'Philippines': '/quoc-gia/philippines',
	'Bồ Đào Nha': '/quoc-gia/bo-dao-nha',
	'Ý': '/quoc-gia/y',
	'Đan Mạch': '/quoc-gia/dan-mach',
	'UAE': '/quoc-gia/uae',
	'Na Uy': '/quoc-gia/na-uy',
	'Thụy Sĩ': '/quoc-gia/thuy-si',
	'Châu Phi': '/quoc-gia/chau-phi',
	'Nam Phi': '/quoc-gia/nam-phi',
	'Ukraina': '/quoc-gia/ukraina',
	'Ả Rập Xê Út': '/quoc-gia/a-rap-xe-ut'
	}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.info['plot'] = tb
		item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phim/ophim.png'
		item.set_callback(ds_ophim, dulieu[k], 1)
		yield item
@Route.register
def ds_ophim(plugin, match=None, next_page=None, **kwargs):
	yield []
	if match is None or next_page is None:
		pass
	else:
		dialog = DialogProgress()
		dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
		n = f'https://ophim1.com/v1/api{match}?page={next_page}'
		resp = getlink(n, n, 1800)
		if (resp is not None):
			ri = resp.json()['data']['items']
			urls = [k['slug'] for k in ri if 'phim-18' not in str(k)]
			length = len(urls)
			if length>0:
				count = 0
				with ThreadPoolExecutor(length) as ex:
					future_to_url = (ex.submit(process_url, url) for url in urls)
					ac = as_completed(future_to_url)
					for future in ac:
						l, data = future.result()
						if data is not None:
							if (dialog.iscanceled()):
								break
							count += 1
							done = int((count/length)*100)
							dialog.update(done, f'Đang giải mã {length} dữ liệu...\nLoading... [COLOR yellow]{done} %[/COLOR]')
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = data[2]
							item.info['mediatype'] = 'movie'
							item.art['thumb'] = item.art['fanart'] = data[1]
							item.set_callback(id_ophim, l)
							yield item
				item1 = Listitem()
				item1.label = f'Trang {next_page + 1}'
				item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
				item1.set_callback(ds_ophim, match, next_page + 1)
				yield item1
		else:
			yield quangcao()
		dialog.close()
@Route.register
def id_ophim(plugin, idk=None, **kwargs):
	yield []
	if idk is None:
		pass
	else:
		t = f'https://ophim1.com/v1/api/phim/{idk}'
		resp = getlink(t, t, 1800)
		if (resp is not None):
			try:
				kq = resp.json()
				ke = kq['data']['item']['episodes']
				title = kq['data']['seoOnPage']['titleHead']
				mota = re.sub('<.*?>', '', kq['data']['item']['content'])
				anh = kq['data']['seoOnPage']['seoSchema']['image']
				item2 = Listitem()
				item2.label = f'TRAILER: [I]{title}[/I]'
				item2.art['thumb'] = item2.art['fanart'] = anh
				item2.info['plot'] = mota
				item2.set_callback(Resolver.ref('/resources/lib/mkd/onyoutube/tim:trailer_youtube'), title)
				yield item2
				b = ((k1['server_name'], k2['name'], k2['link_m3u8'], k2['link_embed']) for k1 in ke for k2 in k1['server_data'] if 'link_m3u8' in k2)
				for k in b:
					item = Listitem()
					tenm = f"[COLOR yellow]{k[0]}[/COLOR] Tập {k[1]} - {title}"
					item.label = tenm
					item.info['plot'] = mota
					item.art['thumb'] = item.art['fanart'] = anh
					item.set_callback(Resolver.ref('/resources/lib/kedon:list_xl90p'), f'{stream(k[2])}{referer(k[3])}', tenm)
					yield item
			except:
				pass
		else:
			yield quangcao()