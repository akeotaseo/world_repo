# Importuri necesare
import re
import os
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import requests
import resolveurl
from bs4 import BeautifulSoup
import sys
import urllib.parse

addon_handle = int(sys.argv[1])

# Configurații URL
BASE_URL = "https://fshd.uk/"
FILME_URL = f"{BASE_URL}film/"

def main_menu():
    """
    Creează meniul principal al addon-ului.
    """
    # Directorul local al addon-ului
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    icon_path = f"{addon_path}/resources/icons/"
    background_path = f"{icon_path}background.jpg"  # Fundalul

    # Categorii pentru meniu
    categories = [
        {"name": "Filme", "action": "list_films", "icon": f"{icon_path}movies.png"},
        {"name": "Seriale", "action": "list_seriale", "icon": f"{icon_path}tv.png"},
        {"name": "Copii", "action": "list_copii", "icon": f"{icon_path}movies.png"},
        {"name": "Căutare", "action": "search", "icon": f"{icon_path}search.png"},
    ]

    # Creează iteme pentru meniu
    for category in categories:
        url = build_url({"action": category["action"]})
        li = xbmcgui.ListItem(label=category["name"])
        li.setArt({
            'icon': category["icon"],
            'thumb': category["icon"],
            'fanart': background_path  # Setează background-ul
        })
        li.setInfo('video', {'title': category["name"], 'plot': f"Accesați categoria {category['name']}"})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)

    # Setează fanart-ul general pentru întregul meniu
    xbmcplugin.setPluginFanart(handle=int(sys.argv[1]), image=background_path)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

# Funcții helper
def build_url(query):
    """
    Construcție URL pentru Kodi.
    """
    return sys.argv[0] + '?' + urllib.parse.urlencode(query)

def clean_title(title):
    """
    Curăță titlul eliminând textul suplimentar.
    Ex: "Apocalypse Z: The Beginning of the End (2024) online subtitrat"
    Devine: "Apocalypse Z: The Beginning of the End (2024)"
    """
    # Elimină "online subtitrat" sau alte astfel de expresii
    cleaned_title = re.sub(r'\s*online|subtitrat|subtitrare|română|fără|engleză\s*', '', title, flags=re.IGNORECASE).strip()
    return cleaned_title

# Funcția pentru listarea filmelor
def list_films(page=1):
    """
    Listează filmele de pe site, cu suport pentru paginare și postere ca fundal.
    """
    current_url = f"{BASE_URL}category/film/page/{page}/"
    xbmc.log(f"Accessing film page URL: {current_url}", level=xbmc.LOGINFO)

    try:
        # Fetch content from the URL
        response = requests.get(current_url)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')

        # Find all films on the page
        films = soup.find_all('div', class_='video-item')

        if not films:
            xbmcgui.Dialog().ok("Eroare", "Nu s-au găsit filme pentru această pagină.")
            return

        for film in films:
            try:
                # Extract film details
                title = film.find('h3').text.strip()
                title = clean_title(title)  # Curăță titlul folosind funcția clean_title
                url = film.find('a')['href']
                image_url = film.find('img')['src']  # Poster image URL
                raw_id = film.get('id', 'ID indisponibil')
                video_id = raw_id.replace('post-', '') if 'post-' in raw_id else raw_id

                # Create a ListItem
                li = xbmcgui.ListItem(label=title)
                li.setArt({
                    'icon': image_url,
                    'thumb': image_url,
                    'fanart': image_url  # Use the poster as background
                })
                li.setInfo('video', {'title': title, 'plot': f"Film: {title}"})
                list_url = build_url({'action': 'play', 'url': video_id, 'title': title})
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=list_url, listitem=li, isFolder=False)
            except Exception as e:
                xbmc.log(f"Eroare la procesarea filmului: {e}", level=xbmc.LOGERROR)

        # Add "Next Page" button
        next_page_url = build_url({'action': 'list_films', 'page': page + 1})
        li = xbmcgui.ListItem(label=f"Pagina {page + 1} >")
        li.setArt({'icon': '', 'thumb': '', 'fanart': ''})
        li.setInfo('video', {'title': f"Pagina {page + 1}", 'plot': "Vezi mai multe filme"})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=next_page_url, listitem=li, isFolder=True)

        # End directory
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    except requests.RequestException as e:
        xbmcgui.Dialog().ok("Eroare", f"A apărut o eroare la accesarea paginii: {e}")
        xbmc.log(f"Request error: {e}", level=xbmc.LOGERROR)
    except Exception as e:
        xbmcgui.Dialog().ok("Eroare", f"A apărut o eroare: {e}")
        xbmc.log(f"Unexpected error: {e}", level=xbmc.LOGERROR)

#SERIALE
def list_seriale(page=1):
    """
    Listează serialele de pe site-ul specificat, cu suport pentru paginare și postere ca fundal.
    """
    base_url = "https://fshd.uk/vezi-online/"
    seriale_url = f"{base_url}page/{page}/" if page > 1 else base_url
    xbmc.log(f"Accessing seriale page URL: {seriale_url}", level=xbmc.LOGINFO)

    try:
        # Trimite cererea către URL
        response = requests.get(seriale_url)
        response.raise_for_status()

        # Parsează conținutul paginii
        soup = BeautifulSoup(response.content, "html.parser")
        seriale = soup.find_all('div', class_='cactus-post-item')

        if not seriale and page == 1:
            xbmcgui.Dialog().ok("Eroare", "Nu s-au găsit seriale.")
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
            return

        # Parcurge fiecare serial și îl adaugă în listă
        for serial in seriale:
            try:
                # Găsește titlul și URL-ul serialului
                title_tag = serial.find('h3', class_='cactus-post-title')
                title = title_tag.text.strip()
                url = title_tag.find('a')['href']

                # Găsește URL-ul imaginii (poster)
                image_tag = serial.find('img')
                image_url = image_tag['src'] if image_tag else ""

                # Creează un ListItem pentru serial
                li = xbmcgui.ListItem(label=title)
                li.setArt({
                    'icon': image_url,
                    'thumb': image_url,
                    'fanart': image_url  # Setează posterul ca fundal
                })
                li.setInfo('video', {'title': title, 'plot': f"Serial: {title}"})

                # Construiește URL-ul pentru afișarea surselor
                list_url = build_url({'action': 'list_seasons', 'url': url, 'title': title})
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=list_url, listitem=li, isFolder=True)
            except Exception as e:
                xbmc.log(f"Eroare la procesarea serialului: {e}", level=xbmc.LOGERROR)

        # Adaugă butonul "Next Page"
        next_page_url = build_url({'action': 'list_seriale', 'page': page + 1})
        li = xbmcgui.ListItem(label="Pagina Următoare >>")
        li.setArt({'icon': '', 'thumb': '', 'fanart': ''})
        li.setInfo('video', {'title': "Pagina Următoare", 'plot': "Vezi mai multe seriale"})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=next_page_url, listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    except requests.RequestException as e:
        xbmcgui.Dialog().ok("Eroare", f"A apărut o eroare la accesarea paginii: {e}")
        xbmc.log(f"Request error: {e}", level=xbmc.LOGERROR)
    except Exception as e:
        xbmcgui.Dialog().ok("Eroare", f"A apărut o eroare: {e}")
        xbmc.log(f"Unexpected error: {e}", level=xbmc.LOGERROR)

def list_copii(page=1):
    """
    Listează filmele de pe site, cu suport pentru paginare și postere ca fundal.
    """
    current_url = f"{BASE_URL}pentru-copii/dublate/page/{page}/"
    xbmc.log(f"Accessing film page URL: {current_url}", level=xbmc.LOGINFO)

    try:
        # Fetch content from the URL
        response = requests.get(current_url)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')

        # Find all films on the page
        films = soup.find_all('div', class_='video-item')

        if not films:
            xbmcgui.Dialog().ok("Eroare", "Nu s-au găsit filme pentru această pagină.")
            return

        for film in films:
            try:
                # Extract film details
                title = film.find('h3').text.strip()
                title = clean_title(title)  # Curăță titlul folosind funcția clean_title
                url = film.find('a')['href']
                image_url = film.find('img')['src']  # Poster image URL
                raw_id = film.get('id', 'ID indisponibil')
                video_id = raw_id.replace('post-', '') if 'post-' in raw_id else raw_id

                # Create a ListItem
                li = xbmcgui.ListItem(label=title)
                li.setArt({
                    'icon': image_url,
                    'thumb': image_url,
                    'fanart': image_url  # Use the poster as background
                })
                li.setInfo('video', {'title': title, 'plot': f"Film: {title}"})
                list_url = build_url({'action': 'play', 'url': video_id, 'title': title})
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=list_url, listitem=li, isFolder=False)
            except Exception as e:
                xbmc.log(f"Eroare la procesarea filmului: {e}", level=xbmc.LOGERROR)

        # Add "Next Page" button
        next_page_url = build_url({'action': 'list_copii', 'page': page + 1})
        li = xbmcgui.ListItem(label=f"Pagina {page + 1} >")
        li.setArt({'icon': '', 'thumb': '', 'fanart': ''})
        li.setInfo('video', {'title': f"Pagina {page + 1}", 'plot': "Vezi mai multe filme"})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=next_page_url, listitem=li, isFolder=True)

        # End directory
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    except requests.RequestException as e:
        xbmcgui.Dialog().ok("Eroare", f"A apărut o eroare la accesarea paginii: {e}")
        xbmc.log(f"Request error: {e}", level=xbmc.LOGERROR)
    except Exception as e:
        xbmcgui.Dialog().ok("Eroare", f"A apărut o eroare: {e}")
        xbmc.log(f"Unexpected error: {e}", level=xbmc.LOGERROR)

def get_video_source(post_id, server_nr):
    """
    Obține URL-ul video pentru un anumit server și un anumit ID de postare.
    """
    try:
        url = "https://fshd.uk/wp-content/themes/serialenoi/field-ajax3.php"
        payload = {"post_id": post_id, "server_nr": server_nr}
        headers = {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Referer": f"{BASE_URL}{post_id}/",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
            "X-Requested-With": "XMLHttpRequest"
        }

        response = requests.post(url, data=payload, headers=headers)
        response.raise_for_status()

        soup = BeautifulSoup(response.content, "html.parser")
        iframe = soup.find("iframe")
        iframe_url = iframe["src"] if iframe else None

        return iframe_url
    except Exception as e:
        xbmc.log(f"Eroare la obținerea sursei video: {e}", level=xbmc.LOGERROR)
        return None

def resolve_redirect(url):
    """
    Verifică dacă URL-ul conține 'player.php', efectuează redirecționarea și verifică domeniul
    față de 'domain.txt' pentru a-l înlocui dacă este necesar.
    """
    if "player.php" in url:
        try:
            # Headers pentru a simula un browser
            headers = {
                "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
                "Referer": url,  # Referer este URL-ul inițial
            }

            # Efectuează cererea GET cu redirecționări activate
            response = requests.get(url, headers=headers, allow_redirects=True)

            if response.status_code == 200:
                final_url = response.url
                xbmc.log(f"Redirected URL: {final_url}", level=xbmc.LOGINFO)

                # Verifică domeniul și înlocuiește dacă este necesar
                updated_url = check_and_replace_domain(final_url)
                xbmc.log(f"Updated URL after domain check: {updated_url}", level=xbmc.LOGINFO)

                return updated_url
            else:
                xbmc.log(f"Failed to resolve redirect for URL: {url}, Status Code: {response.status_code}", level=xbmc.LOGERROR)
                return None
        except requests.exceptions.RequestException as e:
            xbmc.log(f"Request exception during redirect: {e}", level=xbmc.LOGERROR)
            return None
        except Exception as e:
            xbmc.log(f"Unexpected error resolving redirect: {e}", level=xbmc.LOGERROR)
            return None

    # Returnează URL-ul original dacă nu este nevoie de redirect
    return url


def check_and_replace_domain(url):
    """
    Verifică dacă domeniul din URL se află în 'domain.txt' și îl înlocuiește cu 'waaw.ac'.
    """
    try:
        # Citește domeniile din domain.txt
        domain_file_path = xbmcvfs.translatePath("special://home/addons/plugin.video.fsonline/resources/domain.txt")
        with open(domain_file_path, 'r') as file:
            domains = file.read().splitlines()

        # Extrage domeniul din URL
        parsed_url = urllib.parse.urlparse(url)
        domain = parsed_url.netloc

        if domain in domains:
            # Înlocuiește domeniul
            updated_url = url.replace(domain, "waaw.ac")
            xbmc.log(f"Domain {domain} replaced with waaw.ac in URL: {updated_url}", level=xbmc.LOGINFO)
            return updated_url
    except Exception as e:
        xbmc.log(f"Error checking/replacing domain: {e}", level=xbmc.LOGERROR)

    # Returnează URL-ul original dacă nu este găsit un domeniu care să fie înlocuit
    return url

def play_video(post_id, title=None, season=None, episode=None):
    """
    Preia sursele disponibile pentru un episod/film, permite selectarea unui server
    și tratează redirecționările pentru URL-uri care conțin 'player.php'.
    """
    # Construim URL-ul episodului
    episode_url = f"{BASE_URL}wp-content/themes/serialenoi/field-ajax3.php"

    try:
        payload = {"post_id": post_id}
        headers = {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Referer": f"{BASE_URL}{post_id}/",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
            "X-Requested-With": "XMLHttpRequest"
        }

        # Obține lista serverelor
        response = requests.post(episode_url, data=payload, headers=headers)
        response.raise_for_status()

        soup = BeautifulSoup(response.content, "html.parser")
        servers = [
            {"name": server.text.strip().replace("Server: ", ""), "id": server.get("data-server")}
            for server in soup.find_all("label", id="change_server")
            if server.text.strip() and server.get("data-server")
        ]

        if not servers:
            xbmcgui.Dialog().ok("Eroare", "Nu s-au găsit surse pentru acest episod.")
            return

        # Afișăm lista serverelor disponibile
        server_names = [server["name"] for server in servers]
        selected_index = xbmcgui.Dialog().select("Selectați un server", server_names)

        if selected_index == -1:
            return  # Utilizatorul a anulat selecția

        server = servers[selected_index]

        # Construim request-ul pentru a obține sursa video
        payload["server_nr"] = server["id"]
        response = requests.post(episode_url, data=payload, headers=headers)
        response.raise_for_status()

        # Parsează iframe-ul cu sursa video
        soup = BeautifulSoup(response.content, "html.parser")
        iframe = soup.find("iframe")
        iframe_url = iframe["src"] if iframe else None

        if not iframe_url:
            xbmcgui.Dialog().ok("Eroare", "Nu s-a găsit sursa pentru serverul selectat.")
            return

        # Verificăm și înlocuim domeniul, dacă este necesar
        parsed_url = urllib.parse.urlparse(iframe_url)
        source_domain = parsed_url.netloc
        domain_file_path = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), "resources", "domain.txt")

        if os.path.exists(domain_file_path):
            with open(domain_file_path, 'r') as f:
                domains = [line.strip() for line in f.readlines() if line.strip()]

            if source_domain in domains:
                new_netloc = "waaw.ac"
                iframe_url = parsed_url._replace(netloc=new_netloc).geturl()

        # Tratează redirecționările pentru URL-ul iframe
        resolved_url = resolve_redirect(iframe_url)

        if not resolved_url:
            xbmcgui.Dialog().ok("Eroare", "Nu s-a putut rezolva redirecționarea.")
            return

        # Utilizează resolveurl pentru a rezolva URL-ul real
        final_url = resolveurl.resolve(resolved_url)
        if not final_url:
            xbmcgui.Dialog().ok("Eroare", "Nu s-a putut rezolva URL-ul sursei video.")
            return

        # Construim titlul complet al episodului
        episode_title = title or "Episod Necunoscut"
        if season and episode:
            episode_title += f" - Sezonul {season}, Episodul {episode}"

        # Creează ListItem și redă videoclipul
        li = xbmcgui.ListItem(path=final_url)
        li.setInfo('video', {'title': episode_title, 'plot': f"Redare pentru {episode_title}"})
        xbmc.Player().play(final_url, li)

    except requests.RequestException as e:
        xbmcgui.Dialog().ok("Eroare", f"Eroare la obținerea surselor: {e}")
    except Exception as e:
        xbmcgui.Dialog().ok("Eroare", f"A apărut o eroare: {e}")

def list_seasons(url, title):
    """
    Extrage și afișează sezoanele unui serial.
    """
    response = requests.get(url)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, 'html.parser')

    serial_poster_tag = soup.find('div', class_='poster').find('img')
    serial_poster_url = serial_poster_tag['src'] if serial_poster_tag else ""

    episoade = soup.select('.episodios li')
    sezoane = {}
    for episod in episoade:
        sezon_info = episod.find('div', class_='numerando').text.strip()
        sezon_match = re.search(r"Sezonul (\d+)", sezon_info)
        if sezon_match:
            sezon_number = sezon_match.group(1)
            if sezon_number not in sezoane:
                sezoane[sezon_number] = []
            sezoane[sezon_number].append(episod)

    for sezon in sorted(sezoane.keys(), key=int):
        sezon_title = f"Sezonul {sezon}"
        sezon_url = build_url({
            'action': 'list_episodes',
            'url': url,
            'season': sezon,
            'title': title
        })

        sezon_poster_tag = soup.find('div', class_='season-poster')
        sezon_poster_url = sezon_poster_tag.find('img')['src'] if sezon_poster_tag else serial_poster_url

        li = xbmcgui.ListItem(label=sezon_title)
        li.setArt({'icon': sezon_poster_url, 'thumb': sezon_poster_url, 'fanart': sezon_poster_url})
        li.setInfo('video', {'title': sezon_title, 'plot': f"Lista episoadelor din {sezon_title}"})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=sezon_url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def list_episodes(serial_url, season, title):
    """
    Afișează episoadele dintr-un sezon specific.
    """
    response = requests.get(serial_url)
    soup = BeautifulSoup(response.text, 'html.parser')

    serial_poster_tag = soup.find('div', class_='poster').find('img')
    serial_poster_url = serial_poster_tag['src'] if serial_poster_tag else ""

    episoade = soup.select('.episodios li')
    episodes_sorted = []
    for episod in episoade:
        try:
            sezon_info = episod.find('div', class_='numerando').text.strip()
            sezon_match = re.search(rf"Sezonul {season}", sezon_info)
            if sezon_match:
                episod_number_match = re.search(r"Episodul (\d+)", sezon_info)
                if episod_number_match:
                    episod_number = int(episod_number_match.group(1))
                    episod_url = episod.find('a')['href']

                    episod_response = requests.get(episod_url)
                    episod_soup = BeautifulSoup(episod_response.text, 'html.parser')
                    revealed_div = episod_soup.find('div', class_='revealed')

                    post_id = revealed_div['data-id'] if revealed_div and 'data-id' in revealed_div.attrs else None
                    episodes_sorted.append((episod_number, post_id))
        except Exception as e:
            xbmc.log(f"Error processing episode: {e}", xbmc.LOGERROR)

    episodes_sorted.sort(key=lambda x: x[0])

    for episod_number, post_id in episodes_sorted:
        li = xbmcgui.ListItem(label=f"Episodul {episod_number}")
        li.setArt({'icon': serial_poster_url, 'thumb': serial_poster_url, 'fanart': serial_poster_url})
        li.setInfo('video', {'title': f"{title} - S{season}E{episod_number}", 'plot': f"Sezonul {season}, Episodul {episod_number}"})
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=f"{sys.argv[0]}?action=play&post_id={post_id}&title={urllib.parse.quote_plus(title)}&season={season}&episode={episod_number}",
            listitem=li,
            isFolder=False
        )

    xbmcplugin.endOfDirectory(addon_handle)

def search():
    """
    Funcție pentru a căuta filme și seriale.
    """
    keyboard = xbmc.Keyboard('', 'Introduceți termenul de căutare')
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return

    search_query = keyboard.getText()
    if not search_query:
        xbmcgui.Dialog().ok("Eroare", "Introduceți un termen valid de căutare.")
        return

    xbmc.log(f"Căutare inițiată pentru termenul: {search_query}", xbmc.LOGINFO)

    # Creează URL-ul de căutare
    search_url = f"https://fshd.uk/?s={urllib.parse.quote_plus(search_query)}"

    try:
        response = requests.get(search_url)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, "html.parser")

        # Extrage lista de rezultate
        search_results = soup.find_all("div", class_="blog-item")

        if not search_results:
            xbmcgui.Dialog().ok("Rezultate", "Nu s-au găsit rezultate pentru termenul căutat.")
            return

        # Procesare rezultate căutare
        added_items = set()  # Set pentru a preveni duplicatele
        for result in search_results:
            try:
                title_tag = result.find("h3").find("a")
                title = title_tag.text.strip()
                url = title_tag["href"]

                # Verificăm dacă este un film sau un serial
                is_serial = "/vezi-online/" in url

                # Extrage post_id din atributul 'id' (pentru filme)
                post_id = result.get("id", "").replace("post-", "") if not is_serial else None

                # Previne duplicatele folosind un set
                if url in added_items:
                    continue
                added_items.add(url)

                image_tag = result.find("img")
                image_url = image_tag["src"] if image_tag else ""

                description_tag = result.find("div", class_="blog-excerpt")
                description = description_tag.text.strip() if description_tag else ""

                # Creează ListItem pentru rezultat
                li = xbmcgui.ListItem(label=title)
                li.setArt({
                    'icon': image_url,
                    'thumb': image_url,
                    'fanart': image_url  # Setează posterul ca fundal
                })
                li.setInfo('video', {'title': title, 'plot': description})

                # URL pentru a reda filme sau afișa sezoanele pentru seriale
                if is_serial:
                    list_url = build_url({'action': 'list_seasons', 'url': url})
                    is_folder = True
                else:
                    list_url = build_url({'action': 'play', 'post_id': post_id})
                    is_folder = False

                xbmcplugin.addDirectoryItem(handle=addon_handle, url=list_url, listitem=li, isFolder=is_folder)
            except Exception as e:
                xbmc.log(f"Eroare la procesarea unui rezultat: {e}", xbmc.LOGERROR)
                continue

        xbmcplugin.endOfDirectory(addon_handle)

    except Exception as e:
        xbmcgui.Dialog().ok("Eroare", f"A apărut o eroare: {e}")
        xbmc.log(f"Search error: {e}", xbmc.LOGERROR)

def refresh_domain_file():
    addon = xbmcaddon.Addon()
    addon_path = addon.getAddonInfo('path')
    domain_file_path = os.path.join(addon_path, "resources", "domain.txt")
    domain_file_url = "https://derzis.xyz/domain.txt"

    try:
        response = requests.get(domain_file_url, timeout=10)
        response.raise_for_status()

        with open(domain_file_path, "w") as domain_file:
            domain_file.write(response.text)

        xbmcgui.Dialog().ok("Succes", "Fișierul domain.txt a fost actualizat cu succes.")
        xbmc.log("domain.txt updated successfully.", level=xbmc.LOGINFO)
    except requests.RequestException as e:
        xbmcgui.Dialog().ok("Eroare", f"Nu s-a putut descărca domain.txt: {e}")
        xbmc.log(f"Error updating domain.txt: {e}", level=xbmc.LOGERROR)
    except Exception as e:
        xbmcgui.Dialog().ok("Eroare", f"A apărut o eroare neașteptată: {e}")
        xbmc.log(f"Unexpected error updating domain.txt: {e}", level=xbmc.LOGERROR)

# Dispatcher-ul acțiunilor
def router(paramstring):
    """
    Gestionează acțiunile rutei.
    """
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get('action')
    post_id = params.get('post_id')  # ID-ul episodului sau al filmului
    url = params.get('url')  # URL-ul serialului
    season = params.get('season')  # Sezon selectat
    title = params.get('title')  # Titlul serialului sau al filmului
    episode = params.get('episode')  # Episodul selectat
    page = int(params.get('page', 1))  # Pagina curentă (default 1)

    if action == 'list_films':
        list_films(page)
    elif action == 'list_seriale':
        list_seriale(page)
    elif action == 'list_copii':
        list_copii(page)
    elif action == 'list_seasons':
        if url and title:  # Verifică dacă sunt ambele parametri
            list_seasons(url, title)
        else:
            xbmcgui.Dialog().ok("Eroare", "URL-ul sau titlul serialului nu este disponibil.")
    elif action == 'list_episodes':
        if url and season and title:
            list_episodes(url, season, title)
        else:
            xbmcgui.Dialog().ok("Eroare", "Detalii incomplete pentru episoade.")
    elif action == 'search':
        search()
    elif action == 'play':
        # Gestionarea redării pentru episoade și filme
        if post_id:  # Dacă avem `post_id`, presupunem că redăm un episod
            play_video(post_id, title=title, season=season, episode=episode)
        elif url:  # Dacă avem `url`, presupunem că redăm un film
            play_video(url, title=title)
        else:
            xbmcgui.Dialog().ok("Eroare", "Nu s-a putut găsi o sursă validă pentru redare.")
    elif action == 'refresh_domain':
        refresh_domain_file()
    else:
        main_menu()

# Punctul de intrare în addon
if __name__ == '__main__':
    router(sys.argv[2][1:])
