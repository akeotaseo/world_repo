﻿import xbmc, xbmcgui
def Test():

    xbmc.executebuiltin('ActivateWindow(2139)')

Test()