from http.server import BaseHTTPRequestHandler
from socketserver import TCPServer
from urllib.parse import parse_qs, urlparse, urlencode,quote,unquote
#import base64
import re
import socket
from contextlib import closing
import requests
import sys
import xbmcaddon, xbmc, xbmcgui
addon = xbmcaddon.Addon('plugin.video.maxsport')

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0'

class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):

    def do_HEAD(self):

        self.send_response(200)
        self.end_headers()

    def do_GET(self):
        """Handle http get requests, used for manifest"""

        path = self.path
        if 'DADDYLIVE' in(self.path) and '.m3u8' in (self.path):#
            url=self.path.split('DADDYLIVE=')[-1]
            try:
                hea=eval(addon.getSetting('hea_prx'))
                result = requests.get(url, headers=hea, verify=False, timeout = 30).content
                result = result.decode(encoding='utf-8', errors='strict')
                #print(result)
                proxyport = addon.getSetting('proxyport')
                replaceFROM = "http"
                replaceTO = 'http://127.0.0.1:%s/DADDYLIVE='%(str(proxyport))+'http'
                manifest_data = result.replace(replaceFROM,replaceTO)
                #print(manifest_data)
                self.send_response(200)
                self.send_header('Content-type', 'application/x-mpegURL')
                self.end_headers()
                self.wfile.write(manifest_data.encode(encoding='utf-8', errors='strict'))
            except Exception:
                self.send_response(500)
                self.end_headers()
        
        if (self.path).endswith('.ts') and 'DADDYLIVE=' in (self.path):#
            url=(self.path).split('DADDYLIVE=')[-1]
            hea=eval(addon.getSetting('hea_prx'))
            result=requests.get(url, headers=hea, verify=False, timeout = 30).content

            self.send_response(200)
            self.send_header('Content-type', 'application/vnd.apple.mpegurl')
            self.end_headers()

            self.wfile.write(result)

        else:

            return

    #def do_POST(self):


def find_free_port():
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
        s.bind(('', 0))
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        addon.setSetting('proxyport',str(s.getsockname()[1]))
        return s.getsockname()[1]


address = '127.0.0.1'  # Localhost

port = find_free_port()
server_inst = TCPServer((address, port), SimpleHTTPRequestHandler)
# The follow line is only for test purpose, you have to implement a way to stop the http service!
server_inst.serve_forever()