# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Sourced From Online Templates And Guides
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon and Duff You
# Gracias a la librería plugintools de Jesús (www.mimediacenter.info)
# Thanks To: Google Search For This Template
# Modified: Pulse
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from logos import logos_guitar

addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")

xbmc.executebuiltin('Container.SetViewMode(500)')

###########################################################
################ THIRD MENU - PLAYLISTS ###################
###########################################################

### PLAYLISTS FESTIVALS

def function_wacken_year_after_year(params):
    from festivals import playlists_wacken_year_after_year
    playlists_wacken_year_after_year.playlists(params) 

def function_wacken_by_genre(params):
    from festivals import playlists_wacken_by_genre
    playlists_wacken_by_genre.playlists(params) 

def function_hellfest(params):
    from festivals import playlists_hellfest
    playlists_hellfest.playlists(params) 

def function_resurrection(params):
    from festivals import playlists_resurrection
    playlists_resurrection.playlists(params) 
  
def function_rock_hard_festival(params):
    from festivals import playlists_rock_hard_festival
    playlists_rock_hard_festival.playlists(params)   

def function_bloodstock(params):
    from festivals import playlists_bloodstock
    playlists_bloodstock.playlists(params) 
   
def function_summer_breeze(params):
    from festivals import playlists_summer_breeze
    playlists_summer_breeze.playlists(params) 

def function_rockstadt_fest(params):
    from festivals import playlists_rockstadt_fest
    playlists_rockstadt_fest.playlists(params) 
   
   
###########################################################
################ SECOND MENU ##############################
###########################################################
 
def festivals(params):
    from logos import logos_festivals

    logo_wacken=logos_festivals.wacken(params)
    plugintools.add_item(action="function_wacken_year_after_year",title="Wacken (Year after year)", thumbnail=logo_wacken, folder=True ) 
    
    logo_wacken=logos_festivals.wacken(params)
    plugintools.add_item(action="function_wacken_by_genre",title="Wacken (by Genre)", thumbnail=logo_wacken, folder=True )   
    
    logo_hellfest=logos_festivals.hellfest(params)
    plugintools.add_item(action="function_hellfest",title="Hellfest", thumbnail=logo_hellfest, folder=True ) 
 
    logo_resurrection=logos_festivals.resurrection(params)
    plugintools.add_item(action="function_resurrection",title="Resurrection", thumbnail=logo_resurrection, folder=True ) 
  
    logo_rock_hard_festival=logos_festivals.rock_hard_festival(params)
    plugintools.add_item(action="function_rock_hard_festival",title="Rock Hard Festival", thumbnail=logo_rock_hard_festival, folder=True ) 
    
    logo_summer_breeze=logos_festivals.summer_breeze(params)
    plugintools.add_item(action="function_summer_breeze",title="Summer Breeze", thumbnail=logo_summer_breeze, folder=True ) 
    
    logo_bloodstock=logos_festivals.bloodstock(params)
    plugintools.add_item(action="function_bloodstock",title="Bloostock", thumbnail=logo_bloodstock, folder=True )    
     
    logo_rockstadt_fest=logos_festivals.rockstadt_fest(params)
    plugintools.add_item(action="function_rockstadt_fest",title="RockStadt Fest", thumbnail=logo_rockstadt_fest, folder=True ) 


###########################################################
################ FUNCTION RUN() ###########################
###########################################################
def run():
    plugintools.log("docu.run")

    # Obteniendo parámetros...
    params = plugintools.get_params()


    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec(action+"(params)")

    plugintools.close_item_list()            

###########################################################
################ MAIN MENU #############################
###########################################################
def main_list(params):
    logo_01=logos_guitar.logo_01(params)
    logo_02=logos_guitar.logo_02(params)
    logo_03=logos_guitar.logo_03(params)
    logo_04=logos_guitar.logo_04(params)
    logo_05=logos_guitar.logo_05(params)
    logo_06=logos_guitar.logo_06(params)
    logo_07=logos_guitar.logo_07(params)
    logo_08=logos_guitar.logo_08(params)
    logo_09=logos_guitar.logo_09(params)
    logo_10=logos_guitar.logo_10(params)
    logo_11=logos_guitar.logo_11(params)
    logo_12=logos_guitar.logo_12(params)
    logo_13=logos_guitar.logo_13(params)
    
    plugintools.log("docu.main_list "+repr(params))
     
    plugintools.add_item( 
        action="festivals", 
        title="Festivals",
        thumbnail=logo_02,
        folder=True ) 

run()
