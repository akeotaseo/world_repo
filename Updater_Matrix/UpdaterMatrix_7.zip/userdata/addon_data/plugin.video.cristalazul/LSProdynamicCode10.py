# -*- coding: utf-8 -*-
#$pyFunction
def GetLSProData(page_data,Cookie_Jar,m,finalurl='plugin.video.cristalazul'):#cLrJIhsDApL

  if 'cristalazul' in finalurl:
     return '[COLOR green]SI.[/COLOR]'
  else:
     return '[COLOR red]NO, SU COMPAÑIA LE ESTÁ CAPANDO ACCESO A WEBS CAMBIE DNS O USE VPN.[/COLOR]'
