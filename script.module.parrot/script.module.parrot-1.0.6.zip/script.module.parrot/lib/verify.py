import xbmcaddon

def isVerified():
    PARROTID = ""
    try: 
        PARROTID = xbmcaddon.Addon('plugin.video.parrottv')
        if PARROTID.getSetting('verified') == 'true': return True
        else: return False
    except: return False
