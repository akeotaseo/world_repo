# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests
import re

class DaddyLive:
    def __init__(self):
        self.ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'

    def get_m3u8(self): 
        url = "https://player.licenses4.me/player.php?id=premium51&test=true"
        headers = {
            'User-Agent': self.ua,
            'Referer': 'https://licenses4.me/',
        }
        resp = requests.get(url, headers=headers)
        match = re.findall(r'source:\'(.*?)\',', resp.text)
        return match[1].replace('51', '{}')

    def grab(self, channel):
        headers = {'User-Agent': self.ua}
        headers.update({'Referer': 'https://widevine.licenses4.me/'})
        hlsurl = self.get_m3u8().format(channel)
        return hlsurl, headers
