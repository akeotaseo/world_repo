# -*- coding: utf-8 -*-
#$pyFunction
def GetLSProData(page_data,Cookie_Jar,m):
 import xbmc
 xbmc.executebuiltin('UpdateAddonRepos')
 xbmc.executebuiltin('UpdateAddonRepos')
 hola = xbmc.getCondVisibility('System.HasAddon(script.module.resolveurl)')
 return hola
