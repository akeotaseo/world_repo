import xbmc, xbmcgui

def fix_widgets():
    choice = xbmcgui.Dialog().select('[B][COLOR white]Όταν κάποιο widget ή εικονίδιο δεν εμφανίζεται κάνουμε τα εξής βήματα:[/COLOR][/B]', ['[B][COLOR orange]1. [COLOR white]Καθαρισμός cache-packages-thumbnails[/COLOR][/B]', '[B][COLOR orange]2. [COLOR white]Convert Paths to special[/COLOR][/B]'])
    funcs = (clean, convert)

    if choice:
        if choice < 0:
            return
        func = funcs[choice-2]
        return func()
    else:
        func = funcs[choice]
        return func()
    return 

def clean():
        xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=fullclean)')

def convert():
        xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=convertpath)')

fix_widgets()
