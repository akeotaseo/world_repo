# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import sys
import os
import io
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
import json as j
import requests
import hashlib
import m3u
from resources.channels import *
from collections import OrderedDict
import resources
import base64
import random
import string
from bs4 import BeautifulSoup
from kodiez import KodiEZ
from routing import Plugin
from imgs import getIMG
try: from urllib.parse import urlencode, quote_plus
except ImportError: from urllib import urlencode, quote_plus

pythonVersion = sys.version_info[0]
plugin = Plugin()
_ADDON = xbmcaddon.Addon()
_URL = "plugin://{}".format(_ADDON.getAddonInfo('id'))
_KODIEZ = KodiEZ(_ADDON, plugin.handle)
_PLAYLIST = 'special://home/addons/'+_ADDON.getAddonInfo('id')+'/resources/playlist.m3u'
_USERDATA = 'special://home/userdata/addon_data/'+_ADDON.getAddonInfo('id')
_ADDON_DIR = "special://home/addons/"+_ADDON.getAddonInfo('id')
_ADDON_NAME = _ADDON.getAddonInfo('name')
groupsFile = resources.translatePath(_USERDATA+"/groups.json")
# Basic auth
if _ADDON.getAddonInfo('author') != "Parrot Developers": exit()
if _ADDON.getAddonInfo('id') != "plugin.video.parrottv": exit()
_USERNAME = _ADDON.getSetting("username")
# _PASSWORD = _ADDON.getSetting("password")
_CUSTOMPLAYLIST_DIR = os.path.join(resources.translatePath(_USERDATA), "CustomPlaylist")
_CUSTOMPLAYLIST_FILE = os.path.join(_CUSTOMPLAYLIST_DIR, "list.json")
if not os.path.exists(_CUSTOMPLAYLIST_DIR): os.makedirs(_CUSTOMPLAYLIST_DIR)
if not os.path.exists(_CUSTOMPLAYLIST_FILE): io.open(_CUSTOMPLAYLIST_FILE, 'w', encoding="utf-8").write('{}')

_EPGNOW = requests.get("https://parrot-epgnow.pages.dev/guide.json").json()


def formatString(string):
    if pythonVersion == 2:
        return string.encode("utf-8")
    return string

def randString(length):
    return ''.join(random.choice(string.ascii_letters) for _ in range(length))

def addDir(name, genre, icon, url, showPlot=True):
    list_item = xbmcgui.ListItem(label=name)
    if showPlot: plot = name
    list_item.setInfo('video', {'title': name,'genre': genre,'plot': plot,'mediatype': 'video'})
    list_item.setArt({'thumb': icon, 'icon': icon, 'fanart': 'https://cdn.wallpapersafari.com/14/97/Bir3IC.jpg'})
    xbmcplugin.addDirectoryItem(plugin.handle, url, list_item, True)

def addChannel(name, icon, url, id, showAddToPlaylist=True, removeFromPlaylistID = ""):
    list_item = xbmcgui.ListItem(label=name)
    plot = ""
    if id in _EPGNOW and id != "":
        plot = "[COLOR blue]{}[/COLOR]".format(_EPGNOW[id]['title'])
    list_item.setInfo('video', {'title': name,'genre': '','plot': plot,'mediatype': 'video'})
    list_item.setArt({'thumb': icon, 'icon': icon, 'fanart': 'https://cdn.wallpapersafari.com/14/97/Bir3IC.jpg'})
    if "/play/" in url:
        parts = url.split("/")
        module = parts[4]
        stream = parts[5]
        list_item.setProperty('IsPlayable', 'true')
        contextMenuItems = [('Report not working', 'RunPlugin(plugin://plugin.video.parrottv/report/{}/{})'.format(module, stream))]
        if showAddToPlaylist:
            args = "{}|{}|{}|{}".format(name, icon, url, id)
            args = base64.b64encode(args.encode("utf-8")).decode("utf-8")
            contextMenuItems.append(('Add to custom playlist', 'RunPlugin(plugin://plugin.video.parrottv/customAdd/{})'.format(args)))
        if removeFromPlaylistID != "":
            contextMenuItems.append(('Remove from custom playlist', 'RunPlugin(plugin://plugin.video.parrottv/customRemove/{})'.format(removeFromPlaylistID)))
        list_item.addContextMenuItems(contextMenuItems)

    xbmcplugin.addDirectoryItem(plugin.handle, url, list_item, False)

colors = ["white", "black", "gradient"]
color = colors[int(_ADDON.getSetting("selectColor"))]

try:
    _REPO = xbmcaddon.Addon('repository.diggzmatrix')
except:
    xbmcgui.Dialog().ok("Error", "Please install the Parrot repository.")
    exit()

def genPlaylist():
    groups = []
    _ADDON = xbmcaddon.Addon()
    apiURL = "https://parrot-tv.pages.dev/JSON/Groups/"
    if _ADDON.getSettingBool("CZSK"):
        groups.append("SK")
        groups.append("CZ")
        groups.append("SweetTV")
    if _ADDON.getSettingBool("USTVGO"): groups.append("USTVGO")
    if _ADDON.getSettingBool("SlingTV"): groups.append("SlingTV")
    if _ADDON.getSettingBool("TV247"): groups.append("TV247")
    if _ADDON.getSettingBool("123TV"): groups.append("123TV")
    if _ADDON.getSettingBool("S2W"): groups.append("S2W")
    if _ADDON.getSettingBool("RBTV"): groups.append("RBTV")
    if _ADDON.getSettingBool("US"): groups.append("US")
    if _ADDON.getSettingBool("PlutoTV"): groups.append("PlutoTV")
    all = "#EXTM3U\n"
    for group in groups:
        resp = j.loads(requests.get(apiURL+group+".json").text, object_pairs_hook=OrderedDict)
        for item in resp:
            name = resp[item]["name"]
            logo = resp[item]["logo"]
            group = resp[item]["group"]
            url = resp[item]["url"]
            id = "0"
            disabled = False
            if "id" in resp[item]: id = resp[item]["id"]
            if "disabled" in resp[item]: disabled = resp[item]["disabled"]
            if not disabled:
                if pythonVersion == 2: all += '#EXTINF:-1 tvg-logo="{}" group-title="{}" tvg-id="{}" tvg-name="{}" ,{}\n{}\n'.format(logo.encode("utf-8"), group.encode("utf-8"), id.encode("utf-8"), name.encode("utf-8"), name.encode("utf-8"), url.encode("utf-8"))
                else: all += '#EXTINF:-1 tvg-logo="{}" group-title="{}" tvg-id="{}" tvg-name="{}" ,{}\n{}\n'.format(logo, group, id, name, name, url)
    if pythonVersion == 2:
        all = all.decode("utf-8")
    
    io.open(resources.translatePath(_PLAYLIST), 'w', encoding='utf-8').write(all)

def stopifPlaying():
    if xbmc.Player().isPlaying():
        xbmc.Player().stop()

@plugin.route('/')
def root():
    xbmcplugin.setContent(plugin.handle, 'Home')
    xbmcplugin.setPluginCategory(plugin.handle, "Home")
    if not os.path.exists(resources.translatePath(_PLAYLIST)): genPlaylist()
    stopifPlaying()
    addDir('[COLOR gold]Search[/COLOR]', '', getIMG('search', color), "{}/search".format(_URL), True)
    addDir('[COLOR gold]Channels[/COLOR]', '', getIMG('list', color), "{}/channels".format(_URL), True)
    addDir('[COLOR gold]Categories[/COLOR]', '', getIMG('grid', color), "{}/categories".format(_URL), True)
    addDir('[COLOR gold]Custom Playlist[/COLOR]', '', getIMG('pencilWithWrench', color), "{}/custom".format(_URL), True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/search')
def search():
    xbmcplugin.setContent(plugin.handle, 'Search')
    xbmcplugin.setPluginCategory(plugin.handle, "Search")
    stopifPlaying()
    query = _KODIEZ.inpt("Enter search query:", False)
    if query:
        names, logos, urls, groups, ids = m3u.parse("names,logos,urls,groups,ids")
        for name, logo, url, group, id in zip(names, logos, urls, groups, ids):
            if query.lower() in name.lower():
                addChannel("[COLOR gold]{}: {}[/COLOR]".format(group, formatString(name)), logo, url, id)
        xbmcplugin.endOfDirectory(plugin.handle)
    else:
        xbmcgui.Dialog().ok(_ADDON_NAME, 'No search query entered.')
        exit()

@plugin.route('/channels')
def channels():
    xbmcplugin.setContent(plugin.handle, 'Channels')
    xbmcplugin.setPluginCategory(plugin.handle, "Channels")
    stopifPlaying()
    names, logos, urls, ids = m3u.parse("names,logos,urls,ids")
    for name, logo, url, id in zip(names, logos, urls, ids):
        addChannel("[COLOR gold]{}[/COLOR]".format(formatString(name)), logo, url, id)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/categories/')
def categories():
    xbmcplugin.setContent(plugin.handle, 'Categories')
    xbmcplugin.setPluginCategory(plugin.handle, "Categories")
    stopifPlaying()
    groups = m3u.parse("groups")
    # remove duplicates
    groups = list(set(groups))
    for group in groups:
        img = ""
        if group == "SK": img = "sk"
        elif group == "CZ": img = "cz"
        elif group == "SweetTV": img = "cz"
        else: img = "us"
        addDir('[COLOR gold]{}[/COLOR]'.format(group), '', getIMG(img, "universal"), "{}/category/{}".format(_URL, group), True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/category/<category>')
def category(category):
    xbmcplugin.setContent(plugin.handle, 'Categories')
    xbmcplugin.setPluginCategory(plugin.handle, "Categories")
    stopifPlaying()
    names, logos, urls, groups, ids = m3u.parse("names,logos,urls,groups,ids")
    for name, logo, url, group, id in zip(names, logos, urls, groups, ids):
        if group == category:
            addChannel("[COLOR gold]{}[/COLOR]".format(formatString(name)), logo, url, id)
    xbmcplugin.endOfDirectory(plugin.handle)


@plugin.route('/custom')
def custom():
    xbmcplugin.setContent(plugin.handle, 'Custom Playlist')
    xbmcplugin.setPluginCategory(plugin.handle, "Custom Playlist")
    stopifPlaying()
    customList = io.open(resources.translatePath(_CUSTOMPLAYLIST_FILE), 'r', encoding='utf-8').read()
    if customList == "{}":
        xbmcgui.Dialog().ok(_ADDON_NAME, 'No channels added to custom playlist.')
        exit()
    customList = j.loads(customList)
    for item in customList:
        name = customList[item]["name"]
        logo = customList[item]["logo"]
        url = customList[item]["url"]
        id = customList[item]["id"]
        addChannel("[COLOR gold]{}[/COLOR]".format(formatString(name)), logo, url, id, showAddToPlaylist=False, removeFromPlaylistID=item)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/customAdd/<args>')
def customAdd(args):
    args = base64.b64decode(args).decode("utf-8")
    args = args.split("|")
    customList = io.open(resources.translatePath(_CUSTOMPLAYLIST_FILE), 'r', encoding='utf-8').read()
    customList = j.loads(customList)
    customList.update({randString(30): {"name": args[0], "logo":args[1], "url": args[2], "id": args[3]}})
    io.open(resources.translatePath(_CUSTOMPLAYLIST_FILE), 'w', encoding='utf-8').write(j.dumps(customList))
    xbmcgui.Dialog().ok(_ADDON_NAME, 'Channel added to custom playlist.')
    xbmc.executebuiltin("Container.Refresh")

@plugin.route('/customRemove/<id>')
def customRemove(id):
    customList = io.open(resources.translatePath(_CUSTOMPLAYLIST_FILE), 'r', encoding='utf-8').read()
    customList = j.loads(customList)
    del customList[id]
    io.open(resources.translatePath(_CUSTOMPLAYLIST_FILE), 'w', encoding='utf-8').write(j.dumps(customList))
    xbmcgui.Dialog().ok(_ADDON_NAME, 'Channel removed from custom playlist.')
    xbmc.executebuiltin("Container.Refresh")



@plugin.route('/play/<module>/<stream>')
def play(module, stream):
    stopifPlaying()
    if not os.path.exists(resources.translatePath("{}/LICENSE".format(_ADDON_DIR))) or hashlib.sha256(io.open(resources.translatePath("{}/LICENSE".format(_ADDON_DIR)), "rb").read()).hexdigest() != "2684de17300e0a434686f1ec7f8af6045207a4b457a3fe04b2b9ce655e7c5d50":
        li = xbmcgui.ListItem(path="https://r.mtdv.me/cdn/rick.mp4")
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(plugin.handle, True, li)
    elif module == "SlingTV":
        SlingTV(plugin.handle).grab(stream) # Flase-positive error.
    else:
        if module == "123TV":module = "N123TV"
        hlsurl, headers = eval("{module}().grab('{stream}')".format(module=module, stream=stream))
        li = xbmcgui.ListItem(path=hlsurl+'|'+urlencode(headers))
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(plugin.handle, True, li)
        
@plugin.route('/report/<module>/<stream>')
def report(module, stream):
    stopifPlaying()
    url = "https://reports.parrotdevelopers.repl.co/report?module={}&stream={}&user={}".format(module, stream, _USERNAME)
    resp = requests.get(url)
    if resp.status_code == 200:
        xbmcgui.Dialog().ok(_ADDON_NAME, "Thank you for reporting. We will review your report and take appropriate action.")
    else:
        xbmcgui.Dialog().ok(_ADDON_NAME, "Something went wrong. Please try again later.")
    

@plugin.route('/ISS')
def iptvsimpleSetup():
    try:
        pisc = xbmcaddon.Addon('pvr.iptvsimple')
    except:
        xbmcgui.Dialog().ok(_ADDON_NAME, 'Please install IPTV Simple.')
        xbmcplugin.setResolvedUrl(plugin.handle, False, xbmcgui.ListItem())
        return
    pisc.setSetting('m3uPathType','0')
    pisc.setSetting('m3uPath', resources.translatePath(_PLAYLIST))
    pisc.setSetting('m3uRefreshMode','1')
    pisc.setSetting('m3uRefreshIntervalMins','30')
    pisc.setSetting('startNum','1')
    pisc.setSetting('epgPathType','0')
    pisc.setSetting('epgPath', 'http://parrot-epg.pages.dev/epg.xml.gz')
    pisc.setSetting('epgCache', 'false')
    xbmcgui.Dialog().ok(_ADDON_NAME, 'IPTV Simple has been configured. Please restart Kodi.')

@plugin.route('/InstallEPG')
def installEPG():
    try:
        pisc = xbmcaddon.Addon('pvr.iptvsimple')
    except:
        xbmcgui.Dialog().ok(_ADDON_NAME, 'Please install IPTV Simple.')
        xbmcplugin.setResolvedUrl(plugin.handle, False, xbmcgui.ListItem())
        return
    pisc.setSetting('epgPathType','0')
    pisc.setSetting('epgPath', 'http://parrot-epg.pages.dev/epg.xml.gz')
    pisc.setSetting('epgCache', 'false')
    xbmcgui.Dialog().ok(_ADDON_NAME, 'EPG Successfully Installed to IPTV Simple. Please restart Kodi.')

@plugin.route('/Credits')
def credits():
    list = requests.get("https://images-ddg.pages.dev/list.json").json()
    text = "Created by:\n   Parrot Developers\nImages by:\n"
    credits = []
    for item in list: 
        if not list[item]['credits'].split(" - ")[0] in credits:
            credits.append(list[item]['credits'].split(" - ")[0])
    for credit in credits:
        text += "   {}\n".format(credit)
    xbmcgui.Dialog().textviewer("Credits", text)

@plugin.route('/login')
def login():
    username = _ADDON.getSetting('username')
    password = _ADDON.getSetting('password')
    if username == "" or password == "":
        _ADDON.setSetting('verified', 'false')
        xbmcgui.Dialog().ok(_ADDON_NAME, "Please enter your username and password.")
    headers = {"password": quote_plus(password)}
    headers.update({"password": quote_plus(password)})
    resp = requests.get("https://login.parrotdevelopers.repl.co/login", headers=headers)
    if resp.text == "True":
        _ADDON.setSetting('verified', 'true')
        genPlaylist()
        xbmcgui.Dialog().ok(_ADDON_NAME, "Login successful.")
    else:
        _ADDON.setSetting('verified', 'false')
        xbmcgui.Dialog().ok(_ADDON_NAME, "Login failed. Please try again.")

@plugin.route('/forceUpdate')
def forceUpdate():
    genPlaylist()
    xbmcgui.Dialog().ok(_ADDON_NAME, 'Playlist updated.')


if __name__ == "__main__":
    plugin.run(sys.argv)
