﻿import xbmc, xbmcgui, xbmcvfs
xbmcgui.Dialog().notification("[B][COLOR blue]GR[/COLOR][/B]", "[COLOR orange]m3u8[/COLOR]", sound=False, icon='https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Flag_of_Greece.svg/510px-Flag_of_Greece.svg.png')

xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloaderworld/?cache=0&epg&iconimage=special://home/addons%5cplugin.video.playlistloaderworld%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bGr%5d&url=special%3a%5chome%5caddons%5cplugin.video.playlistloaderworld%5clocal%5cGR.m3u8&uuid=4aed0f9e-1b81-46ae-ad51-ff9bb621c74a")')


