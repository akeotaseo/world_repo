﻿import xbmc, xbmcgui
# Λήψη
def DownloadSubsSettings():
    if xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin("ActivateWindow(SubtitleSearch)")
    while xbmc.getCondVisibility("Window.IsVisible(OSDSubtitleSettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")



    if not xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin("ActivateWindow(SubtitleSearch)")

    while xbmc.getCondVisibility("Window.IsVisible(OSDSubtitleSettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")

DownloadSubsSettings()
