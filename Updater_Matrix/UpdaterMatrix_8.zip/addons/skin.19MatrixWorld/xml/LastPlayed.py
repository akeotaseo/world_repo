﻿import xbmc

def LastPlayed():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(200)
    #xbmc.executebuiltin("ActivateWindow(Home)")
    #xbmc.sleep(200)
    xbmc.executebuiltin("RunAddon(plugin.video.last_played,return)")
    xbmc.sleep(100)
    xbmc.executebuiltin("RunAddon(plugin.video.last_played,return)")

LastPlayed()
