# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests
import base64
import re
import xbmcaddon
import xbmcgui
from bs4 import BeautifulSoup


class N123TV:
    def __init__(self):
        self.ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'
        self.Addon = xbmcaddon.Addon()

    def getDecryptionServer(self):
        if self.Addon.getSetting('123TVcustomDecryptionServer') == 'true':
            customURL = self.Addon.getSetting('123TVcustomDecryptionServerURL')
            if not customURL.endswith('/'): customURL += '/'
            return customURL
        else:
            return 'https://new.parrotdevelopers.repl.co/'

    def grab(self, channel):
        headers = {'User-Agent': self.ua}
        hlsurl = ""
        if self.Addon.getSetting('123TVproxy') == 'true':
            proxy = self.Addon.getSetting('123TVproxyURL')
            if not proxy.endswith('/'): proxy += '/'
            hlsurlMain = proxy + "gen.php?c=" + channel
        else:
            #headers.update({'X-Forwarded-For': '207.244.71.79'})
            url = "http://live94today.com/watch/{channel}".format(channel=channel)
            code = requests.get(url, headers=headers).text
            hlsurlMain = ""
            try:
                soup = BeautifulSoup(code, "html.parser")
                iframe = soup.find("iframe", id="123tv-frame")
                iframe_src = iframe["src"]
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'DNT': '1',
                    'Connection': 'keep-alive',
                    'Referer': 'http://live94today.com/',
                    'Upgrade-Insecure-Requests': '1',
                    'Sec-GPC': '1'
                }
                hlsurlMain = requests.get(iframe_src, headers=headers).text.split("source:'")[1].split("'")[0]
                headers.update({'Referer': 'http://azureedge.xyz/'})
            except:
                code0 = "['" + code.replace("\n", "").split(".join('')")[0].split("['")[1].split(";")[0]
                code0 = code0.split("['")[1].split("']")[0].replace("','", "")
                codes = re.findall(r"\[(.*?)\]", code)
                jsonauth = "?1&json=" + code.replace('\n', '').split('?1&json=')[1].split("';}")[0]
                arr = []
                for c in codes:
                    try:
                        if c.split(',')[3].isdigit():
                            arr.append(c)
                    except:
                        pass
                arr = str(arr)
                arr = arr.replace("['", "").replace("']", "").replace("', '", "|")
                arr = base64.b64encode(arr.encode()).decode()
                url2 = "{N123TV}?json={code0}&all={arr}".format(N123TV=N123TV().getDecryptionServer(), code0=code0, arr=arr)
                headers.update({'Referer': 'http://live94today.com/'})
                r = requests.get(url2, headers=headers).text + jsonauth
                r2 = requests.get(r, headers=headers).text.split('[{"file":"')[1].split('","')[0].replace("\\/", "/")
                hlsurlMain = r2.replace('playlist.m3u8', 'chunks.m3u8')
        return hlsurlMain, headers
    