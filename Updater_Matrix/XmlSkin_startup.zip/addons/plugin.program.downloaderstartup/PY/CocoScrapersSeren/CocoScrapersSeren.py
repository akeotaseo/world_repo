import os, xbmc, xbmcvfs, xbmcgui


def CocoScrapersSeren():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7)
    call = xbmcgui.Dialog().select('[COLOR=orange]~ CocoScrapers/Seren ~[/COLOR]', 
['[COLOR=orange]Coco Scrapers[/COLOR]',
 '[COLOR=darkorange]Seren Providers[/COLOR]',
 '[COLOR=gold]HELP[/COLOR]',
 '[COLOR=silver]POV*[/COLOR]',
 '[COLOR=silver]Gears Scrapers[/COLOR]',
 '[I][COLOR=red]Magneto Module[/COLOR][/I]',
 '[I][COLOR=green]Viper Scrapers[/COLOR][/I]'
 ])



    if call:
        if call < 0:
            return
        func = funcs[call-7]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    if not xbmc.getCondVisibility('System.HasAddon({})'.format('script.module.cocoscrapers')):
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]Coco Scrapers[/COLOR][/B]', 'Για να λειτουργήσουν τα πρόσθετα [B][COLOR white]Umbrella, Fen κ.α[/COLOR][/B][CR]πρέπει να γίνει εγκατάσταση των[CR][B]Coco Scrapers[/B][CR]Για να συνεχίσετε πατήστε [B][COLOR orange]Coco Scrapers[/COLOR][/B][CR]',
                                        nolabel='[B][COLOR white]Πίσω[/COLOR][/B]',yeslabel='[B][COLOR orange]Coco Scrapers[/COLOR][/B]')

        if choice == 1: xbmc.executebuiltin('InstallAddon(script.module.cocoscrapers)')
                        # xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.module.cocoscrapers)')
        if choice == 0: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/CocoScrapersSeren/CocoScrapersSeren.py")'),]


    if xbmc.getCondVisibility('System.HasAddon({})'.format('script.module.cocoscrapers')):
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "script.module.cocoscrapers","enabled":true}}')
        xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.module.cocoscrapers/")')

def click_2():
    SerenProviders()
    # if not xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.seren')):
        #  (plugin.video.seren)')
        
        # xbmc.executebuiltin('SendClick(11)')
        # Serentxt()
        # SerenProviders()

    # if xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.seren')):
        # SerenProviders()




def click_3():
    xbmc.executebuiltin('ActivateWindow(10002,"special://home/media/Coco Scrapers/",)')


def click_4():
    POVntxt()


def click_5():
    if not xbmc.getCondVisibility('System.HasAddon({})'.format('script.module.gearsscrapers')):
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]Gears Scrapers[/COLOR][/B]', 'Προαιρετικά.. για τα Πρόσθετα [B][COLOR hotpink]POV[/COLOR][/B] [B][COLOR red]Umbrella[/COLOR][/B] κ.α?...[CR]μπορείτε να χρησιμοποιήσετε[CR]τούς [B][COLOR red]Gears Scrapers[/COLOR][/B][CR]Για να συνεχίσετε πατήστε [B][COLOR silver]Gears Scrapers[/COLOR][/B][CR]',
                                        nolabel='[B][COLOR white]Πίσω[/COLOR][/B]',yeslabel='[B][COLOR silver]Magneto Module[/COLOR][/B]')

        if choice == 1: xbmc.executebuiltin('InstallAddon(script.module.gearsscrapers)')
                        # xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.module.magneto/")')
        if choice == 0: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/CocoScrapersSeren/CocoScrapersSeren.py")'),]


    if xbmc.getCondVisibility('System.HasAddon({})'.format('script.module.gearsscrapers')):
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "script.module.gearsscrapers","enabled":true}}')
        xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.module.gearsscrapers/")')
        # xbmc.sleep(4000)


def click_6():
    if not xbmc.getCondVisibility('System.HasAddon({})'.format('script.module.magneto')):
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]Magneto Module[/COLOR][/B]', 'Προαιρετικά.. για τα Πρόσθετα [B][COLOR hotpink]POV[/COLOR][/B] [B][COLOR red]Umbrella[/COLOR][/B] κ.α?...[CR]μπορείτε να χρησιμοποιήσετε[CR]το [B][COLOR red]Magneto Module[/COLOR][/B][CR]Για να συνεχίσετε πατήστε [B][COLOR red]Magneto Module[/COLOR][/B][CR]',
                                        nolabel='[B][COLOR white]Πίσω[/COLOR][/B]',yeslabel='[B][COLOR red]Magneto Module[/COLOR][/B]')

        if choice == 1: xbmc.executebuiltin('InstallAddon(script.module.magneto)')
                        # xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.module.magneto/")')
        if choice == 0: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/CocoScrapersSeren/CocoScrapersSeren.py")'),]


    if xbmc.getCondVisibility('System.HasAddon({})'.format('script.module.magneto')):
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "script.module.magneto","enabled":true}}')
        xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.module.magneto/")')
        # xbmc.sleep(4000)


def click_7():
    if not xbmc.getCondVisibility('System.HasAddon({})'.format('script.module.viperscrapers')):
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]Magneto Module[/COLOR][/B]', 'Προαιρετικά.. για τα Πρόσθετα [B][COLOR silver]Fen/Fen Light[/COLOR][/B] [B][COLOR red]Umbrella[/COLOR][/B] κ.α?...[CR]μπορείτε να κάνετε χρήση των [B][COLOR green]Viper Scrapers[/COLOR][/B][CR][CR]Για να συνεχίσετε πατήστε [B][COLOR green]Viper Scrapers[/COLOR][/B][CR]',
                                        nolabel='[B][COLOR white]Πίσω[/COLOR][/B]',yeslabel='[B][COLOR green]Viper Scrapers[/COLOR][/B]')

        if choice == 1: xbmc.executebuiltin('InstallAddon(script.module.viperscrapers)')
                        # xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.module.viperscrapers/")')
        # if choice == 0: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/CocoScrapersSeren/CocoScrapersSeren.py")'),]


    if xbmc.getCondVisibility('System.HasAddon({})'.format('script.module.viperscrapers')):
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "script.module.magneto","enabled":true}}')
        xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.module.viperscrapers/")')
        # xbmc.sleep(4000)



def SerenProviders():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]SerenProviders[/COLOR][/B]', 'Για να λειτουργήσει τα πρόσθετο [B][COLOR white] Seren[/COLOR][/B][CR]πρέπει να γίνει εγκατάσταση των[CR][B]Seren Providers[/B][CR]Για να συνεχίσετε πατήστε [B][COLOR orange]Seren Providers[/COLOR][/B][CR]',
                                        nolabel='[B][COLOR white]Πίσω[/COLOR][/B]',yeslabel='[B][COLOR orange]Seren Providers[/COLOR][/B]')

        if choice == 1: Serentxt(), xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.downloader/seren_package_install")')
        if choice == 0: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/CocoScrapersSeren/CocoScrapersSeren.py")'),]



def textBox(heading, announce):
    class TextBox():

        def __init__(self, *args, **kwargs):
            self.WINDOW = 10147
            self.CONTROL_LABEL = 1
            self.CONTROL_TEXTBOX = 5
            xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, ))
            self.win = xbmcgui.Window(self.WINDOW)
            xbmc.sleep(100)
            self.setControls()

        def setControls(self):
            self.win.getControl(self.CONTROL_LABEL).setLabel(heading)
            try:
                f = open(announce)
                text = f.read()
            except:
                text = announce
            self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
            return

    TextBox()
    while xbmc.getCondVisibility('Window.IsVisible(10147)'):
        xbmc.sleep(100)

def Serentxt():
    changelog = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.program.downloaderstartup/PY/Changelog/Serentxt.txt'))
    heading = '[B][COLOR orange]*** Seren Providers ***[/COLOR][/B]'
    f = open(changelog, 'r', encoding='utf-8')
    lines = f.readlines()
    announce = ''
    for line in lines:
        if not line.strip():
            break

        announce += line
    f.close()
    textBox(heading, announce)



def POVntxt():
    changelog = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.program.downloaderstartup/PY/Changelog/POVtxt.txt'))
    heading = '[B][COLOR orange]*** POV Subs ***[/COLOR][/B]'
    f = open(changelog, 'r', encoding='utf-8')
    lines = f.readlines()
    announce = ''
    for line in lines:
        if not line.strip():
            break

        announce += line
    f.close()
    textBox(heading, announce)

CocoScrapersSeren()
