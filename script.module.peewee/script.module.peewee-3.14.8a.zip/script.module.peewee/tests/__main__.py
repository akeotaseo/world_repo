import sys
import unittest

from tests import *


if __name__ == '__main__':
    unittest.main(argv=sys.argv)
