if __name__ == '__main__':
    import xbmc
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.wltvhelper/switch)")