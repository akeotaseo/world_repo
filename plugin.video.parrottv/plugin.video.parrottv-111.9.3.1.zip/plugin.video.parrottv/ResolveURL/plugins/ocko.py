# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

from ..utils.browser import Firefox
from ..utils.resolve import Resolver


class Ocko(Resolver):
    def __init__(self):
        self.channels = {
            'ocko': 'https://ocko-live.ssl.cdn.cra.cz/channels/ocko/playlist.m3u8',
            'expres': 'https://ocko-live.ssl.cdn.cra.cz/channels/ocko_expres/playlist.m3u8',
            'star': 'https://ocko-live.ssl.cdn.cra.cz/channels/ocko_gold/playlist.m3u8'
        }

    def grab(self, channel):
        hlsurl = self.channels[channel]
        return hlsurl, Firefox().headers