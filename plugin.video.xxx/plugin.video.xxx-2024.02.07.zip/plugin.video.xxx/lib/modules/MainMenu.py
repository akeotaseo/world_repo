import xbmcaddon
from lib.modules import Common

OpenURL = Common.OpenURL
addDir= Common.addDir
addVideo= Common.addVideo
Play= Common.Play
Setting = xbmcaddon.Addon().getSetting
#TVSetting = xbmcaddon.Addon('plugin.program.rays.files').getSetting

def Menu():
	addDir('Recommendations', 'none', 5, 'special://home/addons/plugin.video.xxx/resources/art/recommendations.png')
	addDir('Yes Porn VIP', 'none', 170, 'special://home/addons/plugin.video.xxx/resources/art/yespornvip.png')
	addDir('GoodPorn', 'none', 70, 'special://home/addons/plugin.video.xxx/resources/art/goodporn.png')
	addDir('HQPorner', 'none', 120, 'special://home/addons/plugin.video.xxx/resources/art/hqporner.png')
	addDir('PornoHD', 'none', 20, 'special://home/addons/plugin.video.xxx/resources/art/pornohd.png')
	addDir('PornOne', 'none', 130, 'special://home/addons/plugin.video.xxx/resources/art/pornone.png')
	addDir('XHand', 'none', 90, 'special://home/addons/plugin.video.xxx/resources/art/xhand.png')
	addDir('XOZilla', 'none', 100, 'special://home/addons/plugin.video.xxx/resources/art/xozilla.png')
	addDir('XTits', 'none', 40, 'special://home/addons/plugin.video.xxx/resources/art/xtits.png')
	
	#addDir('XNXX', 'none', 160, 'special://home/addons/plugin.video.xxx/resources/art/xnxx.png')
	#addDir('PornHat', 'none', 60, 'special://home/addons/plugin.video.xxx/resources/art/pornhat.png')
	#addDir('XCum', 'none', 30,'special://home/addons/plugin.video.xxx/resources/art/xcum.png')
	#addDir('Hog.TV', 'none', 80,'special://home/addons/plugin.video.xxx/resources/art/hogtv.png' )
	#addDir('PornTrex', 'none', 150,'special://home/addons/plugin.video.xxx/resources/art/porntrex.png' )
	#addDir('XHamster', 'none', 110, 'special://home/addons/plugin.video.xxx/resources/art/xhamster.png')
	#addDir('ZBPorn', 'none', 50, 'special://home/addons/plugin.video.xxx/resources/art/zbporn.png')
	#addDir('MangoVideo', 'none', 10,'special://home/addons/plugin.video.xxx/resources/art/mangovideo.png')
	
	#if TVSetting('user') == 'Ray': addDir('Live TV','none', 2,'special://home/addons/plugin.video.xxx/resources/art/live.png')
	#Common.addTask('Favourites','none', 3,'none')