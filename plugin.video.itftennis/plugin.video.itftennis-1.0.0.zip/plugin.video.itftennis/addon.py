# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
#import base64
#import json
#import random
import time
import datetime
#from resources.lib import jsunpack
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.itftennis')

mode = addon.getSetting('mode')
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:103.0) Gecko/20100101 Firefox/103.0'
baseurl='https://live.itftennis.com'

def build_url(query):
    return base_url + '?' + urlencode(query)

def home():
    items=[
        ['Live NOW', 'liveEv'],
        ['Upcoming Events', 'upcomEv']
        #['Archive', 'archEv'],
    ]
    for i in items:
        li=xbmcgui.ListItem(i[0])
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': i[0],'sorttitle': i[0],'plot': ''})
        #li.setArt({'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': img})
        url = build_url({'mode':i[1]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)
    
def eventsArray(x,y):
    url='https://live.itftennis.com/en/live-streams/'
    hea={
        'User-Agent':UA
    }
    resp=requests.get(url,headers=hea).text
    resp1=resp.split(x)[1].split(y)[0]
    resp11=resp1.split('video_item')
    events=[]
    for r in resp11:
        if 'data-starttime' in r:
            link=re.compile('<a href=\"([^\"]+?)\"').findall(r)[0]
            img=re.compile('<img src=\"([^\"]+?)\"').findall(r)[0]
            comp=re.compile('tournament-name\'>([^<]+?)<').findall(r)[0]
            pla=re.compile('<span>([^<]+?)</span>').findall(r)[0]
            start=re.compile('data-starttime=\"([^"]+?)\"').findall(r)[0]
            events.append([link,img,comp,pla,start])
    return events

def eventList(x,y,isArch,m):
    events=eventsArray(x,y)
    def testArch(d,isA):
        if not isA:
            return True
        else:
            now=int(time.time())
            if int(d)>now:
                return False
            else:
                return True
    
    for e in events:
        if testArch(e[4],isArch):
            img=e[1]
            link=e[0]
            date=datetime.datetime.fromtimestamp(int(e[4])).strftime('%Y-%m-%d,%H:%M')
            title=e[2]+' | '+e[3]+ ' ['+date+']'
            
            li=xbmcgui.ListItem(title)
            if m=='upcomEv':
                li.setProperty("IsPlayable", 'false')
            else:
                li.setProperty("IsPlayable", 'true')
            li.setInfo(type='video', infoLabels={'title': title,'sorttitle': title,'plot': ''})
            li.setArt({'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': img})
            url = build_url({'mode':'playSource','link':link})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)


def playSource(u):
    url_stream=''
    hea={
        'User-Agent':UA,
        'Referer':baseurl+'/'
    }
    resp=requests.get(baseurl+u,headers=hea).text
    stream_url=re.compile('\"streamUrl\": \"([^\"]+?)\"').findall(resp)
    if len(stream_url)>0:
        url_stream=stream_url[0]+'|User-Agent='+UA+'&Referer='+baseurl+u      
        print(url_stream)
    '''
    if url_stream !='':
        play_item = xbmcgui.ListItem(path=url_stream)
        play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
        play_item.setProperty("IsPlayable", "true")
        
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    '''
    if url_stream !='':
        play_item = xbmcgui.ListItem(path=url_stream)
        play_item.setProperty("IsPlayable", "true")
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    
    
mode = params.get('mode', None)

if not mode:
    home()
else:
    if mode=='liveEv':
        eventList('video_archive live','video_archive upcoming',False,mode)
    if mode=='upcomEv':
        eventList('video_archive upcoming','</section>',False,mode)
    if mode=='archEv':
        eventList('video_archive upcoming','</section>',True,mode)
    if mode=='playSource':
        link=params.get('link')
        playSource(link)
