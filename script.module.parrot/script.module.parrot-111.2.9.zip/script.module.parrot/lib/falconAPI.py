from urllib.parse import urlencode
import random
import requests
import xbmcaddon
import xbmcgui
import os
import sys

class FalconAPI:
    def __init__(self, username="", password="") -> None:
        self.name = f"[COLOR cyan]Falcon API[/COLOR]"
        self._ADDON = xbmcaddon.Addon()
        self._FALCON_ADDON = xbmcaddon.Addon("plugin.video.parrottv")
        self.apis = {
            #"Falcon": "https://p.falconpanel.repl.co/api/",
            #"Falcon Load Balancer 1": "https://falconlb01.serverseveneight.repl.co/api/",
            #"Falcon Load Balancer 2": "https://falconlb02.serverseveneight.repl.co/api/",
            "Random": "https://heavenlywandrupal.cwdgdvxytvcpfbh.repl.co/api/"
        }

        #statuses = requests.get("https://stats.uptimerobot.com/api/getMonitorList/XPP2xF48QP?page=1").json()["psp"]["monitors"]
        #working = []
        #for status in statuses:
        #    if status["statusClass"] != "success": continue
        #    if status["name"] not in self.apis: continue
        #    working.append(self.apis[status["name"]])

        #self.api = random.choice(working)
        self.api = random.choice(list(self.apis.values()))
        self.username = username
        self.password = password

        device = "Mozilla/5.0 (Unknown; Unknown)"
        if os.name == "nt":
            device = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
        elif sys.platform == "linux":
            device = "Mozilla/5.0 (X11; Linux x86_64)"
        elif sys.platform == "darwin":
            device = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)"

        self.userAgent = f"{device} FalconModule/{self._ADDON.getAddonInfo('version') or '0.0.0'} Falcon/{self._FALCON_ADDON.getAddonInfo('version') or '0.0.0'}"
        self.basicHeaders = {
            "User-Agent": self.userAgent,
            "username": self.username,
            "password": self.password
        }

    def __request(self, method="get", url="", headers={}, data={}):
        try:
            response = requests.get(url, headers=headers, verify=False) if method == "get" else \
                       requests.post(url, headers=headers, data=data, verify=False)
            if "<title>Falcon | Login</title>" in response.text or "Forbidden" in response.text or "Endpoint not found" in response.text:
                xbmcgui.Dialog().notification(self.name, "Invalid login credentials", xbmcgui.NOTIFICATION_ERROR, 5000)
                exit()
        except Exception as e:
            xbmcgui.Dialog().notification(self.name, "Error occurred while sending request to API", xbmcgui.NOTIFICATION_INFO, 5000)
            exit()
        return response

    def __createURL(self, dir, **kwargs):
        if len(kwargs) == 0: return f"{self.api}{dir}"
        return f"{self.api}{dir}?{urlencode(kwargs)}"

    def login(self, extendedData={}):
        data = {
            "username": self.username,
            "password": self.password,
        }
        data.update(extendedData)
        return self.__request(method="post", url=self.__createURL("login"), headers=self.basicHeaders, data=data).json()

    def epg(self):
        return self.__request(url=self.__createURL("epg"), headers=self.basicHeaders).json()

    def news(self):
        return self.__request(url=self.__createURL("news"), headers=self.basicHeaders).json()

    def channels(self):
        return self.__request(url=self.__createURL("channels.json"), headers=self.basicHeaders).json()
    
    def history(self):
        return self.__request(url=self.__createURL("history"), headers=self.basicHeaders).json()
    
    def report(self, channelName, channelID, channelSource, country, countryAbb):
        return self.__request(method="post", url=self.__createURL("report"), headers=self.basicHeaders, data={
            "channelName": channelName,
            "channelID": channelID,
            "channelSource": channelSource,
            "country": country,
            "countryAbb": countryAbb
        })
    
    def request(self, channelName, country, countryAbb):
        return self.__request(method="post", url=self.__createURL("request"), headers=self.basicHeaders, data={
            "channelName": channelName,
            "country": country,
            "countryAbb": countryAbb
        })
    
    def addToHistory(self, channel):
        return self.__request(method="post", url=self.__createURL("addToHistory"), headers=self.basicHeaders, data={
            "channel": channel,
        })
