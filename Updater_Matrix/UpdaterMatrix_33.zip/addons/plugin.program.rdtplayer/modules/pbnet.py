# -*- coding: utf-8 -*-
import urllib.request
import xbmc
import random

MIRRORS = [
    "https://thepiratebay11.com",
    "https://thepiratebay.orgindex.net",
    "https://piratebayproxy.live",
    "https://piratebayproxy.info",
    "https://proxifiedpiratebay.org",
    "https://1027.thepiratebay10.org",
    "https://tpb15.ukpass.co",
]

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko)",
]

HEADERS = {
    "Accept-Language": "en-US,en;q=0.9",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}

def fetch_html(path):
    for mirror in MIRRORS:
        url = mirror + path
        ua = random.choice(USER_AGENTS)
        headers = HEADERS.copy()
        headers["User-Agent"] = ua
        try:
            req = urllib.request.Request(url, headers=headers)
            resp = urllib.request.urlopen(req, timeout=10)
            html = resp.read()
            if len(html) < 5000:
                continue
            xbmc.log(f"[PB] Mirror OK → {mirror}", xbmc.LOGINFO)
            return html
        except Exception as e:
            xbmc.log(f"[PB] Mirror fail: {mirror} → {e}", xbmc.LOGWARNING)
    return None
