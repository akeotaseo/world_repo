from codequick import Route, Listitem, Resolver, Script
from resources.lib.kedon import getlinkweb, getlink, __addonnoti__, quangcao, tb, stream, referer
from bs4 import BeautifulSoup
from time import gmtime
from calendar import timegm
from xbmcgui import DialogProgressBG
from urllib.parse import quote_plus
import re
randstam = timegm(gmtime())
@Route.register
def search_vgo(plugin, search_query=None, **kwargs):
	yield []
	if search_query is None:
		pass
	else:
		dialog = DialogProgressBG()
		dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
		search_query = quote_plus(search_query)
		url = f'https://vtvgo.vn/search?time={randstam}&search-keyword={search_query.replace(" ","+")}'
		r = getlinkweb(url, url, 900)
		if (r is not None) and ('news-slide-content-item' in r.text):
			soup = BeautifulSoup(r.content, 'html.parser')
			soups = soup.select('div.news-slide-content-item')
			length = len(soups)
			count = 0
			for episode in soups:
				count += 1
				dialog.update(int((count/length)*100))
				item = Listitem()
				tenm = episode.select_one('h2 a').get_text(strip=True)
				item.label = tenm
				linkphim = episode.select_one('h2 a')['href'].replace('.html','')
				finallink = f'{linkphim}?time={randstam}'
				item.art['thumb'] = item.art['fanart'] = episode.img['src']
				item.set_callback(Resolver.ref('/resources/lib/kedon:ifr_khomuc'), finallink, tenm)
				yield item
		else:
			Script.notify(__addonnoti__, 'Không tìm thấy kết quả')
			yield quangcao()
		dialog.close()
@Route.register
def index_vtvgo(plugin, **kwargs):
	yield Listitem.search(search_vgo)
	khovideo = {'label': 'KHO VIDEO',
	'info': {'plot': 'Kho Video'},
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/vtvgo.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/vtvgo.png'},
	'callback': index_khovd}
	tructuyenvtvgo = {'label': 'XEM TRỰC TUYẾN',
	'info': {'plot': 'Xem trực tuyến'},
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/vtvgo.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/vtvgo.png'},
	'callback': list_truyenhinhvtvgo}
	yield Listitem.from_dict(**tructuyenvtvgo)
	yield Listitem.from_dict(**khovideo)
@Route.register
def list_truyenhinhvtvgo(plugin, **kwargs):
	yield []
	kqf1 = getlinkweb(f'https://vtvgo.vn/xem-truc-tuyen?time={randstam}', 'https://vtvgo.vn', -1)
	if (kqf1 is not None):
		x = kqf1.cookies.get_dict()
		g = re.findall(r"var (time|token) = '(.*?)'", kqf1.text)
		sre = re.compile(r'\d+')
		timekenh = g[0][1]
		tokenkenh = g[1][1]
		soup = BeautifulSoup(kqf1.content, 'html.parser')
		soups = soup.select('div.list_channel a')
		for episode in soups:
			item = Listitem()
			linkkenh = episode['href']
			idkenh = sre.findall(linkkenh)[-1]
			anh = episode.img['src']
			item.label = episode['alt']
			item.info['plot'] = tb
			item.art['thumb'] = item.art['fanart'] = anh
			item.set_callback(Resolver.ref('/resources/lib/kedon:play_vtvgo'), timekenh, tokenkenh, idkenh, x, episode['alt'])
			yield item
@Route.register
def index_khovd(plugin, **kwargs):
	yield []
	url = f'https://vtvgo.vn/kho-video?time={randstam}'
	resp = getlinkweb(url, 'https://vtvgo.vn', -1)
	if (resp is not None):
		sre = re.compile(r'(\d+)\.')
		soup = BeautifulSoup(resp.content, 'html.parser')
		soups = soup.select('a.color-white')
		for episode in soups:
			item = Listitem()
			linkthumuc = episode['href']
			idthumuc = sre.search(linkthumuc)[1].replace('.', '')
			next_page = 1
			item.label = episode.get_text(strip=True)
			item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/vtvgo.png'
			item.set_callback(list_thumucvd, idthumuc, next_page)
			yield item
	else:
		yield quangcao()
@Route.register
def list_thumucvd(plugin, idthumuc=None, next_page=None, **kwargs):
	yield []
	if idthumuc is None or next_page is None:
		pass
	else:
		url = f'https://vtvgo.vn/ajax-get-more-item-playlist?next_page={next_page}&channel_id={idthumuc}'
		resp = getlinkweb(url, 'https://vtvgo.vn', -1)
		if (resp is not None) and ('http' in resp.text):
			soup = BeautifulSoup(resp.content, 'html.parser')
			soups = soup.select('div.swiper-slide')
			for episode in soups:
				item = Listitem()
				linkclip = episode.select_one('h2 a')['href'].replace('.html','')
				finallink = f'{linkclip}?time={randstam}'
				tenclip = episode.select_one('h2 a').get_text(strip=True)
				anhclip = episode.img['src']
				item.label = tenclip
				item.art['thumb'] = item.art['fanart'] = anhclip
				item.set_callback(Resolver.ref('/resources/lib/kedon:ifr_khomuc'), finallink, tenclip)
				yield item
			item = Listitem()
			item1 = Listitem()
			item1.label = f'Trang {next_page + 1}'
			item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
			item1.set_callback(list_thumucvd, idthumuc, next_page + 1)
			yield item1
		else:
			yield quangcao()