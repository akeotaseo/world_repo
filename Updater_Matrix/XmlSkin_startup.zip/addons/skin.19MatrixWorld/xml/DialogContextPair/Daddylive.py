import xbmc, xbmcgui, webbrowser


def daddyhd():
    dialog = xbmcgui.Dialog()
    funcs = (site1, site2)
    xbmcgui.Dialog().ok("[B][COLOR=orange]Daddylive[/COLOR][/B]", "Πατήστε Εντάξει για να μεταφερθείτε στο site[CR]dlhd.pk")
    call = dialog.select('[B][COLOR=orange]Daddylive[/COLOR][/B]',
    
['Μεταφερθείτε στο https://dlhd.pk/',
 '[B][COLOR=deepskyblue]Ελληνικά [COLOR=white]- [COLOR=yellow]Κυπριακά [COLOR=white]Κανάλια Browser[/COLOR][/B]',])

    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()


def site1():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://dlhd.pk/' ) )
    else: opensite = webbrowser . open('https://dlhd.pk/')

def site2():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/GreekChannels.py")')


daddyhd()
