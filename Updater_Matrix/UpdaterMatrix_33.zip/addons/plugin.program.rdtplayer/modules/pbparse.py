from bs4 import BeautifulSoup

def parse_torrents(html):
    soup = BeautifulSoup(html, "html.parser")
    items = []
    for row in soup.find_all("tr"):
        title = row.find("a", class_="detLink")
        magnet = row.find("a", href=lambda x: x and x.startswith("magnet"))
        if not title or not magnet:
            continue
        desc = row.find("font", class_="detDesc")
        size = ""
        if desc:
            parts = desc.text.split(",")
            for p in parts:
                if "Size" in p:
                    size = p.replace("Size", "").strip()
        stats = row.find_all("td", align="right")
        seeds = stats[0].text if len(stats) > 0 else "0"
        leech = stats[1].text if len(stats) > 1 else "0"
        items.append({
            "label": title.text,
            "magnet": magnet['href'],
            "size": size,
            "seeders": seeds,
            "leechers": leech,
        })
    return items
