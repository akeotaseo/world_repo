# Simple  plugin for Kodi mediacenter

This is a simple and fully functional  of a video plugin for [Kodi](http://kodi.tv) mediacenter.
Please read the comments in the plugin code for more details.

**Note**: the purpose of this example plugin is to show you how to organize and play your media content in Kodi.
The methods of obtaining such content, for example parsing websites or working with various APIs,
are beyond the scope of this example.

**Warning**: the "luc_kodi" video is only compatible with Kody 21.0 ("Omega") and above that uses Python 3
runtime for addons. 

## Licenses:

* Code: [GPL v.3](http://www.gnu.org/copyleft/gpl.html)
* Images: [Creative Commons Attribution-Share Alike 3.0](http://creativecommons.org/licenses/by-sa/3.0/us/). Genre images are borrowed from Kodi icon packs by Team-Kodi, Xzener and Gade.
