import xbmc, xbmcgui


def tainiesonline():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13, click_14,
             click_15, click_16, click_17, click_18, click_19, click_20, click_21)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]                                            Κατηγορίες [/COLOR][/B]', 
['[B][COLOR=white]                                                       Western[/COLOR][/B]',
 '[B][COLOR=white]                                                    Αστυνομική[/COLOR][/B]',
 '[B][COLOR=white]                                                         Δράμα[/COLOR][/B]',
 '[B][COLOR=white]                                                         Δράση[/COLOR][/B]',
 '[B][COLOR=white]                                                 Επ. Φαντασίας[/COLOR][/B]',
 '[B][COLOR=white]                                                        Θρίλερ[/COLOR][/B]',
 '[B][COLOR=white]                                                      Ιστορική[/COLOR][/B]',
 '[B][COLOR=white]                                              Κινούμενα σχέδια[/COLOR][/B]',
 '[B][COLOR=white]                                                       Κωμωδία[/COLOR][/B]',
 '[B][COLOR=white]                                            Action & Adventure[/COLOR][/B]',
 '[B][COLOR=white]                                                       Μουσική[/COLOR][/B]',
 '[B][COLOR=white]                                                     Μυστηρίου[/COLOR][/B]',
 '[B][COLOR=white]                                                   Ντοκιμαντέρ[/COLOR][/B]',
 '[B][COLOR=white]                                                  Οικογενειακή[/COLOR][/B]',
 '[B][COLOR=white]                                                    Περιπέτεια[/COLOR][/B]',
 '[B][COLOR=white]                                                      Πολεμική[/COLOR][/B]',
 '[B][COLOR=white]                                                     Ρομαντική[/COLOR][/B]',
 '[B][COLOR=white]                                                        Τρόμου[/COLOR][/B]',
 '[B][COLOR=white]                                                     Φαντασίας[/COLOR][/B]',
 '[B][COLOR=white]                                             Τηλεοπτική Ταινία[/COLOR][/B]',
 '[B][COLOR=white]                                            Χριστουγεννιάτικες[/COLOR][/B]'])

    if call:
        if call < 0:
            return
        func = funcs[call-21]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/western/,return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/astinomiki/,return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/drama/,return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/drasi/,return)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/epistimonikis-fantasias/,return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/thriler/,return)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/istoriki/,return)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/%ce%ba%ce%b9%ce%bd%ce%bf%cf%8d%ce%bc%ce%b5%ce%bd%ce%b1-%cf%83%cf%87%ce%ad%ce%b4%ce%b9%ce%b1/,return)')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/komodia/,return)')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/action-adventure/,return)')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/nousiki/,return)')

def click_12():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/mistiriou/,return)')

def click_13():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/ntokimanter/,return)')

def click_14():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/ikogeniaki/,return)')

def click_15():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/peripetia/,return)')

def click_16():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/polemiki/,return)')

def click_17():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/romantiki/,return)')

def click_18():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/tromou/,return)')

def click_19():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/fantasias/,return)')

def click_20():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/tileoptiki-tenia/,return)')

def click_21():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/christmas/,return)')

tainiesonline()
