import sys
import xbmc
import xbmcvfs

def translatePath(path):
    if sys.version_info[0] == 2:
        return xbmc.translatePath(path)
    else:
        return xbmcvfs.translatePath(path)