
ADDONS_REPOS = [('plugin.video.fmoviesto', 'repository.mbebe'),
                ('plugin.video.subsmovies', 'repository.mbebe'),
                ('plugin.video.cartoonsgr', 'repository.gkobu'),
                ('repository.NarcacistWizard', 'repository.NarcacistWizard'),
                ('plugin.video.Rising.Tides', 'repository.Rising.Tides'),
                ('repository.newdiamond', 'repository.newdiamond'),
                ('script.extendedinfo', 'repository.World')]
