﻿import xbmc

def last_played():
    xbmc.executebuiltin("Action(back)")

    xbmc.sleep(1000)
    xbmc.executebuiltin("Action(playlist)")


last_played()
