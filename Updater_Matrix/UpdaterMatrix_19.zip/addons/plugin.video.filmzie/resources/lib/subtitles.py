# subtitles.py
import os
import xbmc
import xbmcvfs
import requests
import xbmcaddon

addon = xbmcaddon.Addon()
profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
subs_path = os.path.join(profile_path, 'subs')

SUB_LANGUAGES = addon.getSetting('subs_languages') or 'ro'
SUB_FORMAT = addon.getSetting('subs_format') or 'srt'
SUB_ENCODING = addon.getSetting('subs_encoding') or 'utf-8'

BASE_URL = "https://sub.wyzie.ru/search"

if not os.path.exists(subs_path):
    os.makedirs(subs_path)

def search_subtitles(imdb_id, lang=SUB_LANGUAGES):

    try:
        params = {"id": imdb_id, "language": lang}
        response = requests.get(BASE_URL, params=params, timeout=10)
        response.raise_for_status()

        subtitles = response.json()
        filtered = [
            sub for sub in subtitles
            if sub.get("language", "").lower().startswith(lang.lower()) and sub.get("format") == "srt"
        ]

        if not filtered:
            filtered = [
                sub for sub in subtitles
                if sub.get("format") == "srt"
            ]

        return filtered

    except Exception as e:
        xbmc.log(f"[WyzieSub] ❌ Eroare căutare subtitrări: {e}", xbmc.LOGERROR)
        return []

def download_subtitle(sub, dest_folder=subs_path, index=0):
    try:
        sub_url = sub.get("url")
        media_title = sub.get("media", "subtitle").replace(" ", "_")
        language = sub.get("language", "und")
        encoding = sub.get("encoding", "utf-8").lower()

        if not os.path.exists(dest_folder):
            os.makedirs(dest_folder)

        filename = f"{media_title}.{language}"
        if index > 0:
            filename += f"_{index}"
        filename += ".srt"

        filepath = os.path.join(dest_folder, filename)

        response = requests.get(sub_url, timeout=10)
        response.raise_for_status()

        decoded = response.content.decode(encoding, errors="replace")
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(decoded)

        return filepath

    except Exception as e:
        xbmc.log(f"[WyzieSub] ❌ Eroare descărcare subtitrare: {e}", xbmc.LOGERROR)
        return None

