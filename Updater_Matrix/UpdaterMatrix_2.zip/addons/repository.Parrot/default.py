import sys
import xbmcgui
import xbmcplugin
import xbmcgui
import xbmc
import threading
import base64
import xbmcaddon
import time
import json
try:
    from urllib.request import urlopen
except ImportError:
    from urllib2 import urlopen

_URL = sys.argv[0]
_HANDLE = int(sys.argv[1])
_DBURL = "https://AccessCodes.parrotdevelopers.repl.co"
_ADDON = xbmcaddon.Addon()

def getQR(url):
    size = "512x512"
    return "https://api.qrserver.com/v1/create-qr-code/?size={}&data={}".format(size, url)

def genCode():
    resp = urlopen("{}/createKey".format(_DBURL)).read().decode('utf-8')
    resp = json.loads(resp)
    return resp["key"]

def checker(key):
    while True:
        url = "{}/checkKey?key={}".format(_DBURL, key)
        resp = urlopen(url).read().decode('utf-8')
        resp = json.loads(resp)
        if resp["status"] == "success":
            username = resp["username"]
            hash = resp["hash"]
            string = "{}-:-{}".format(username, hash)
            string = base64.b85encode(string.encode()).decode()
            #_ADDON.setSetting("data", string)
            _ADDON.setSetting("verified", "true")
            _ADDON.setSetting("username", username)
            _ADDON.setSetting("password", "HASH-{}".format(hash))
            break
        time.sleep(1)


def home():
    xbmcgui.Dialog().ok('QR', 'Scan QR and then open link. Everything else will happen automatically.')
    code = genCode()
    QRurl = getQR("https://parrot.rf.gd/activate?code={}".format(code))
    xbmc.executebuiltin('ShowPicture({})'.format(QRurl))
    threading.Thread(target=checker, args=(code,)).start()
    xbmcplugin.endOfDirectory(_HANDLE)

def router():
    try:
        action = sys.argv[2].replace("?", "").split("=")[1]
        if action == "qr": home()
    except IndexError:
        xbmcgui.Dialog().ok('Parrot Repo', 'No action specified.')
router()