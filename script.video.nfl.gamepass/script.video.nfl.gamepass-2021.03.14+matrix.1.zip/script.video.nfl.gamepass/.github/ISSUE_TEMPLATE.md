<!--- We do not support setups which attempt to circumvent region restrictions
      (proxies, etc) as it is against NFL Game Pass's Terms of Service. -->

<!--- If you are reporting a bug, please enable debugging and provide Kodi's log
      file. For instructions on how to do this, please read
      http://kodi.wiki/view/Log_file -->
