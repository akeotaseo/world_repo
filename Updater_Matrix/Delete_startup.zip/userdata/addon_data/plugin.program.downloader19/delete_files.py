﻿import os, glob, xbmc, xbmcgui, xbmcvfs, xbmcaddon, shutil
from updatervar import *


dialog.notification('Πραγματοποιείται διαγραφή αχρείαστων αρχείων...', '  ', icon_delete, sound=False)
xbmc.sleep(500)


### Oi δριαδρομές ειναι στο updatrvar.py ###

# home            = translatePath('special://home/')     home + 'cache'
# user_path       = os.path.join(home, 'userdata/')      user_path + 'profiles.xml'
# data_path       = os.path.join(user_path, 'addon_data/')
# db_path         = os.path.join(user_path, 'Database/')


                                     #files

#xbmcvfs.delete('special://home/userdata/playercorefactory.xml')
                                     #players
#xbmc.sleep(200)
#xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/players/atla_oipeirates.json')
# xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/players/gratis.json')
# xbmc.sleep(100)
# xbmcvfs.delete('special://home/addons/plugin.program.downloader19/check.py')






                                        #addons / addon_data
                                             
                                             
                                             
delete_files = ['repository.test1', 'repository.Parrot', 'plugin.video.pluginstreaming', 'plugin.video.xcodes', 'plugin.video.free99', 'plugin.video.senkutv', 'plugin.video.worldclient', 'plugin.video.worldclient', 'plugin.video.balkanclient', 'repository.test2']


base_path = xbmcvfs.translatePath('special://home/addons')

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.test"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)






                                             #folders

base_path = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')

dir_list = glob.iglob(os.path.join(base_path, "__pycache__"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)




#base_path = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.themoviedb.helper')

#dir_list = glob.iglob(os.path.join(base_path, "reconfigured_players"))
#for path in dir_list:
#    if os.path.isdir(path):
#        shutil.rmtree(path




# base_path = xbmcvfs.translatePath('special://home/userdata/addon_data')

#dir_list = glob.iglob(os.path.join(base_path, "json_list_files2"))
#for path in dir_list:
#    if os.path.isdir(path):
#        shutil.rmtree(path)


#base_path = xbmcvfs.translatePath('special://home/media/Downloads')

#dir_list = glob.iglob(os.path.join(base_path, "CartoonsGR"))
#for path in dir_list:
#    if os.path.isdir(path):
#        shutil.rmtree(path)




# base_path = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.mypreferences/Super Favourites/EX -Simple Favourites/NBA')

# dir_list = glob.iglob(os.path.join(base_path, "favourites OFF"))
# for path in dir_list:
   # if os.path.isdir(path):
       # shutil.rmtree(path)




                       # script.module.inputstreamhelper fix?
# base_path = xbmcvfs.translatePath('special://home/addons')

# dir_list = glob.iglob(os.path.join(base_path, "script.module.inputstreamhelper"))
# for path in dir_list:
   # if os.path.isdir(path):
       # shutil.rmtree(path)


def check_del_dir():
    for path_list in delete_files:
        if exists(addons_path + '%s' % path_list) or exists('%s' % path_list):
            path_list = path_list.replace(UpdaterMatrix, '[B][COLOR lime] * [/COLOR][/B]').replace(addons_path, '[B][COLOR lime] * [/COLOR][/B]').replace(user_path, '[B][COLOR lime] * [/COLOR][/B]').replace(home, '[B][COLOR lime] * [/COLOR][/B]')
            del_dir()
            #BG.create('[B]Διαγραφή αχρείαστων αρχείων...[/B]', path_list)
            #BG.update(29, '[B]Διαγραφή αχρείαστων αρχείων...[/B]', path_list)
            #xbmc.sleep(4000)
            #BG.close()



def del_dir():#addons #addon_data
    for ad in addons_data_path:
     for rr in delete_files:
       dir_list = glob.iglob(os.path.join(ad, rr))
       for path in dir_list:
           if os.path.isdir(path):
               shutil.rmtree(path)
           if os.path.isfile(path):
              os.remove(path)


check_del_dir()