plugin.video.playlistbee

- Forked from @Nux007 and translated to Python 3 for Kodi 19.x by @Publish3r

- EPG Support added by @Silhouette2022 (*.xml files only).

- List @bee

- Script changes @1X

- Help @Romy
 