import xbmc, xbmcgui, webbrowser


def Ertflix():
    dialog = xbmcgui.Dialog()
    funcs = (site1, site2, site3, site4, site5, site6, site7, site8, site9, site10, site11, site12)

    call = dialog.select('[B][COLOR=blue]ERT[/COLOR][COLOR=red]FLIX[/COLOR][/B]',
    
['[COLOR=blue]ERT[/COLOR][COLOR=red]FLIX[/COLOR]',
 '[COLOR=white]LIVE[/COLOR]',
 '[COLOR=white]ΣΕΙΡΕΣ[/COLOR]',
 '[COLOR=white]ΤΑΙΝΙΕΣ[/COLOR]',
 '[COLOR=white]ΠΑΙΔΙΚΑ[/COLOR]',
 '[COLOR=white]ΝΤΟΚΙΜΑΝΤΕΡ[/COLOR]',
 '[COLOR=white]ΕΚΠΟΜΠΕΣ[/COLOR]',
 '[COLOR=white]ΕΝΗΜΕΡΩΣΗ[/COLOR]',
 '[COLOR=white]ΑΘΛΗΤΙΚΑ[/COLOR]',
 '[COLOR=white]Η ΕΡΤ ΘΥΜΑΤΑΙ[/COLOR]',
 '[COLOR=white]ΑΝΑΖΗΤΗΣΗ[/COLOR]',
 '[COLOR=white]ΠΡΟΓΡΑΜΜΑ[/COLOR]'])

    if call:
        if call < 0:
            return
        func = funcs[call-12]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()


def site1():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.ertflix.gr/' ) )
    else: opensite = webbrowser . open('https://www.ertflix.gr/')

def site2():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.ertflix.gr/epg/now-on-tv' ) )
    else: opensite = webbrowser . open('https://www.ertflix.gr/epg/now-on-tv')

def site3():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.ertflix.gr/show/series' ) )
    else: opensite = webbrowser . open('https://www.ertflix.gr/show/series')

def site4():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.ertflix.gr/show/movies' ) )
    else: opensite = webbrowser . open('https://www.ertflix.gr/show/movies')
def site5():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.ertflix.gr/show/children' ) )
    else: opensite = webbrowser . open('https://www.ertflix.gr/show/children')

def site6():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.ertflix.gr/show/documentary' ) )
    else: opensite = webbrowser . open('https://www.ertflix.gr/show/documentary')

def site7():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.ertflix.gr/show/ekpompes' ) )
    else: opensite = webbrowser . open('https://www.ertflix.gr/show/ekpompes')

def site8():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.ertflix.gr/show/news' ) )
    else: opensite = webbrowser . open('https://www.ertflix.gr/show/news')     

def site9():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.ertflix.gr/show/sport' ) )
    else: opensite = webbrowser . open('https://www.ertflix.gr/show/sport') 

def site10():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.ertflix.gr/show/archives' ) )
    else: opensite = webbrowser . open('https://www.ertflix.gr/show/archives')

def site11():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.ertflix.gr/search' ) )
    else: opensite = webbrowser . open('https://www.ertflix.gr/search')

def site12():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.ertflix.gr/epg' ) )
    else: opensite = webbrowser . open('https://www.ertflix.gr/epg')


Ertflix()