# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import random

class PlutoTV:
    def __init__(self):
        self.ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36'
        self.IP = PlutoTV.genip()

    def genip(self):
        cityint = random.randint(0,10)
        ip = ""
        if cityint == 0:
            ip = "68.121.80." + str(random.randint(0,255))
        elif cityint == 1:
            ip = "24.218.158." + str(random.randint(0,255))
        elif cityint == 2:
            ip = "12.232.30." + str(random.randint(0,255))
        elif cityint == 3:
            ip = "12.2.95." + str(random.randint(0,255))
        elif cityint == 4:
            ip = "47.189.48." + str(random.randint(0,255))
        elif cityint == 5:
            ip = "66.90.40." + str(random.randint(0,255))
        elif cityint == 6:
            ip = "63.120.217." + str(random.randint(0,255))
        elif cityint == 7:
            ip = "24.239.182." + str(random.randint(0,255))
        elif cityint == 8:
            ip = "24.164.119." + str(random.randint(0,255))
        elif cityint == 9:
            ip = "67.1.17." + str(random.randint(0,255))
        elif cityint == 10:
            ip = "67.1.19." + str(random.randint(0,255))
        return ip

    def grab(self, channel):
        headers = {'User-Agent': self.ua}
        headers = {'X-Forwarded-For': self.IP}
        hlsurl = "https://service-stitcher.clusters.pluto.tv/stitch/hls/channel/{channel}/master.m3u8?deviceType=web&deviceMake=Chrome&deviceModel=Chrome&sid=0c9d9262-bcd4-4b33-a78f-afea1ee4a67e&deviceId=781d4c79-fb21-4162-97a4-9f543683f22a&deviceVersion=74.0.3729.131&appVersion=2.5.1-f9a6096b469cfe5e4f1cc92cc697e8500e57891c&deviceDNT=0&userId=&advertisingId=&deviceLat=38.8177&deviceLon=-77.1527&app_name=&appName=&appStoreUrl=&architecture=&serverSideAds=true".format(channel=channel)
        return hlsurl, headers

