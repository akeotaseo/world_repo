﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def RunDownloaderStartup():
        choice = xbmcgui.Dialog().yesno('[COLOR orange] Έναρξη downloader_startup[/COLOR]', 'Διορθώσεις του build.[CR][CR]Για να συνεχίσετε πατήστε [B][COLOR green]Select Matrix[/COLOR][/B][CR]και περιμένετε.',
                                        nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR green]Select Matrix[/COLOR][/B]')

        if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/service.downloaderstartup/PY/SelectMatrix.py")'),
                         #xbmcvfs.delete('special://home/addons/plugin.program.downloader19/downloader_startup.py'), 
                         #xbmc.sleep(1000),
                         #xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/settings.xml'),
                         #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/resources/PY/UpdaterMatrixDelFix.py")'),
                         #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/resources/PY/AutowidgetDelFix.py")'),
                         #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/resources/PY/InstallAutowidget.py")'),
                         #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/resources/PY/ThemoviedbhelperDel.py")'),
                         #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/resources/PY/temp_DeletelFix.py")'),
                         #xbmcgui.Dialog().notification("[B][COLOR orange]Διαγραφή με επιτυχία ![/COLOR][/B]", "[COLOR white]Αναμονή για Reload Profile...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/rp.png'),
                         #xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)'),
                         #xbmc.sleep(2000),
                         #service.downloaderstartup
                         #xbmcgui.Dialog().notification("[B][COLOR orange]Reload Profile[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", #icon='special://home/addons/plugin.program.downloader19/resources/media/reloadprofile.png'),
                         ]

RunDownloaderStartup()
