# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests
import re
from bs4 import BeautifulSoup
from datetime import datetime as dt
import xbmcgui
import xbmcplugin
import xbmc
import json
import time
import threading
import re



class ParrotChannel:
    def __init__(self):
        self.ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36"
        self.programmes = {
                            "2022-05-19-18-30-00": {"name":"Parrot TV","url":"http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4","start":"2022-05-19-16-30-00","end":"2022-05-19-17-00-00"},
                            "2022-05-19-19-00-00": {"name":"Parrot TV 2","url":"http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4","start":"2022-05-19-17-00-00","end":"2022-05-19-17-30-00"}
                        }

    def strftimeFix(self, dateString, arg):
        res = ""
        try: res=dt.strptime(dateString, arg)
        except TypeError: res=dt(*(time.strptime(dateString, arg)[0:6]))
        return res

    def prehrajto(self, id):
        url = "https://prehraj.to/{}".format(id)
        html = requests.get(url).text
        html = html.replace("\n", "")
        file = html.split('file: "')[1].replace("\\/", "/").split('"')[0]
        return file


    def getProgrammes(self):
        programmes = json.loads(requests.get("http://192.168.1.12:8080/programmes.json").text)
        queue = []
        main = {}
        pNow = ""
        now = dt.now()
        for pr in programmes:
            if programmes[pr]['start'] <= now.strftime("%Y-%m-%d-%H-%M-%S") <= programmes[pr]['end']:
                pNow = programmes[pr]
            if programmes[pr]['start'] > now.strftime("%Y-%m-%d-%H-%M-%S"):
                queue.append(programmes[pr])
        if pNow != "":
            length = self.strftimeFix(pNow['end'], "%Y-%m-%d-%H-%M-%S") - self.strftimeFix(pNow['start'], "%Y-%m-%d-%H-%M-%S")
            remaining = length - (now - self.strftimeFix(pNow['start'], "%Y-%m-%d-%H-%M-%S"))
            remainingLength = (remaining.total_seconds() / length.total_seconds() * 100)
            remainingLength = int(str(remainingLength).split('.')[0])
            played = 100 - remainingLength
            main = {"now": {"name": pNow['name'], "url": pNow['url'], "played": played}}
            for item in queue:
                main.update({
                    "queue": {
                        item['name']: {
                            "name": item['name'],
                            "url": item['url']
                        }
                    }
                })
            if queue == []:
                main.update({"queue": {}})
        else:
            main = {"now": {"name": "We'll be right back!", "url": "https://parrot-tv.pages.dev/Channel/WBRB.mp4", "played": "0"}}
            main.update({"queue": "empty"})
        return main

    def backgroundWorker(self, main, li, player):
            while True:
                if player.isPlaying():
                    now = dt.now()
                    endTime = main["now"]["end"]
                    if now.strftime("%Y-%m-%d-%H-%M-%S") > endTime:
                        main = self.getProgrammes()
                        li = xbmcgui.ListItem(path=main["now"]["url"])
                        li.setProperty('StartPercent', str(main["now"]["played"]))
                        player.stop()
                        player.play(main["now"]["url"], li)
                else:
                    break

    def grab(self, _HANDLE):
        _HANDLE = int(_HANDLE)
        resp = self.getProgrammes()
        li = xbmcgui.ListItem(path=resp["now"]["url"])
        li.setProperty('StartPercent', str(resp["now"]["played"]))
        li.setContentLookup(False)
        li.setProperty('IsPlayable', 'true')
        #li.setProperty('inputstreamaddon', 'inputstream.adaptive')
        li.setMimeType('video/mp4')
        player = xbmc.Player()
        player.play(resp["now"]["url"], li)

        if resp["queue"] != "empty":
            playlist = xbmc.PlayList(1)
            for item in resp["queue"]:
                li2 = xbmcgui.ListItem(resp["queue"][item]["name"])
                li2.setContentLookup(False)
                li2.setMimeType('video/mp4')
                playlist.add(resp["queue"][item]["url"], li2)
        