from conf.common import CommonResolver


class Starlive(CommonResolver):

    def set_servers(self):
        return ['starlive.xyz', 'cloudstream.to', "worlwidestream.net", 'wzcdn594.net', 'ragnarp.net',
                'smokelearned.net']

    def find_stream(self):
        return [r"var src=\"([^\"]+)\""]
