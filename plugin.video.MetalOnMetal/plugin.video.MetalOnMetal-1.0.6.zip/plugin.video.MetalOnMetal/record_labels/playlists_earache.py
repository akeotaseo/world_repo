import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_labels


setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="

arrayMenu = ([
            [ "New Earache Releases",  "PL6_qhP3eWX5Ob6yhBJlE9SHHqNbESeXpj"],           
            [ "Earache's New Breed",  "PL6_qhP3eWX5PI0LZnTEHunbT8iEAJiwF3"],           
            [ "Old School Earache Classics",  "PL6_qhP3eWX5NdlsoqZnbq6Qap39efPtNe"],           
            [ "Earache Bands Doing Covers (Official Audio)",  "PL6_qhP3eWX5OPHe5PoW80NtE73x3NLMaX"],           
            [ "Earache's 25th Anniversary playlist",  "PL6_qhP3eWX5N6V0b6WGcTSWI2AMUkHhmM"],           
            [ "Earache's Download 2015 playlist!",  "PL6_qhP3eWX5PtzG-76uqWQfCMJ2Lw4Ir1"],           
            [ "Earache Records #BlackFriday Playlist!",  "PL6_qhP3eWX5MXbC3IlD8u28OvnY3Eva66"],           
            [ "Brutal metal vocalists",  "PL6_qhP3eWX5NwlUSv7BBVPQeF-zl6Zhnb"],           
            [ "Earache Records Rare Tracks",  "PL6_qhP3eWX5M1NMmRPVpk1GoKqjDbBfq8"],           
            [ "My Top Videos",  "PL010748FE3CD1A062"],           
            [ "Friday 13th Playlist",  "PL6_qhP3eWX5O9eqQe_V3qziEg7fi6YyDf"],           
            [ "Earache Gods of Grind Tour 1992 Full Shows",  "PL6_qhP3eWX5MSLBkUPvyahNKJBaUQu5rV"], 
            [ "Earache's Modern Metal Massacre",  "PL6_qhP3eWX5MMc5l3p3OnxnW30iSxk_6m"],  
            [ "Metal Injection | 30 Years of Earache Records",  "PL6_qhP3eWX5O0OJxEp799cKrBsVtSt34e"],                    
            [ "Napalm Death Official Videos",  "PL6_qhP3eWX5P89SwQFZf1ZXZ7g9hCclxb"],           
            [ "Hate Eternal Official Videos",  "PL6_qhP3eWX5OvBxAD4JrBMaJ87uhxqMGa"],           
            [ "At the Gates Official Videos",  "PL6_qhP3eWX5PiYFT4orvfxCF9Iei631an"],           
            [ "Deicide Official Videos",  "PL6_qhP3eWX5MM0VwYFkD0fEs_oApHP3Z4"],           
            [ "Entombed Official Videos",  "PL6_qhP3eWX5OHrNwpJS-x9wz00sHBonzY"],           
            [ "Evile Official Videos",  "PL6_qhP3eWX5NkEBEVyWqIXFlLjViRxnfZ"],           
            [ "Municipal Waste Official Videos",  "PL6_qhP3eWX5OsQmX-PV75r-FeUprDW6qA"],           
            [ "Cathedral Official Videos",  "PL6_qhP3eWX5N29YeBAG8nF39-3L6BdhMS"],           
            [ "Morbid Angel Official Videos",  "PL6_qhP3eWX5MLcIdS6Woneidfyf5tWykC"]])

def playlists(params):
    logo=logos_labels.earache(params)

    for i in range(len(arrayMenu)):
        titulo = arrayMenu[i][0]
        id_canal = arrayMenu[i][1]
        if usa_duffyou:  ##Usamos plugin Duff You
            reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_canal)
            videos = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        else:  ##Usamos plugin YouTube
            videos = youtube.replace("MI-ID-PLAYLIST" , id_canal)
        
        plugintools.add_item( 
            title=titulo,
            url=videos,
            thumbnail=logo, folder=True )

