### epg.py
import os
import xbmcvfs
import xbmc
import xbmcaddon
import time
import requests
import gzip
import sqlite3
import xml.etree.ElementTree as ET
from io import BytesIO
import datetime as dt
from threading import Lock

EPG_URL = "http://epg.one/epg.xml.gz"
FILENAME = "epg.xml.gz"
DB_FILENAME = "epg.db"
REFRESH_INTERVAL = 48 * 3600  # 48 ore

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_DATA_PATH = xbmcvfs.translatePath(f"special://userdata/addon_data/{ADDON_ID}")
EPG_FILE_PATH = os.path.join(ADDON_DATA_PATH, FILENAME)
EPG_DB_PATH = os.path.join(ADDON_DATA_PATH, DB_FILENAME)

EPG_OFFSET_HOURS = int(ADDON.getSetting("epg_offset") or "0")

_epg_lock = Lock()

def ensure_db():
    if not xbmcvfs.exists(ADDON_DATA_PATH):
        try:
            xbmcvfs.mkdirs(ADDON_DATA_PATH)
            xbmc.log("[EPG] Folder creat cu xbmcvfs.", xbmc.LOGINFO)
        except Exception as ex:
            xbmc.log(f"[EPG] Eroare xbmcvfs.mkdirs: {ex}. Încearcă os.makedirs...", xbmc.LOGWARNING)
            try:
                os.makedirs(ADDON_DATA_PATH, exist_ok=True)
                xbmc.log("[EPG] Folder creat cu os.makedirs.", xbmc.LOGINFO)
            except Exception as ose:
                xbmc.log(f"[EPG] Eroare os.makedirs: {ose}", xbmc.LOGERROR)
    try:
        conn = sqlite3.connect(EPG_DB_PATH)
        c = conn.cursor()
        c.execute("""
            CREATE TABLE IF NOT EXISTS epg (
                channel TEXT,
                start TEXT,
                stop TEXT,
                title TEXT,
                desc TEXT
            )
        """)
        c.execute("CREATE INDEX IF NOT EXISTS idx_channel_time ON epg(channel, start, stop)")
        conn.commit()
        conn.close()
    except sqlite3.DatabaseError as e:
        xbmc.log(f"[EPG] Baza de date coruptă. Șterg fișierul: {e}", xbmc.LOGERROR)
        try:
            if os.path.exists(EPG_DB_PATH):
                os.remove(EPG_DB_PATH)
            xbmc.log("[EPG] Baza de date ștearsă. Se va recrea...", xbmc.LOGWARNING)
            ensure_db()
        except Exception as ex:
            xbmc.log(f"[EPG] Eroare la ștergerea bazei de date: {ex}", xbmc.LOGERROR)

def is_expired(path):
    if not os.path.exists(path):
        return True
    last_modified = os.path.getmtime(path)
    return time.time() - last_modified > REFRESH_INTERVAL

def get_epg_path(force=False):
    if force or is_expired(EPG_FILE_PATH) or not os.path.exists(EPG_DB_PATH):
        xbmc.log("[EPG] Fișier EPG expirat sau lipsă. Se descarcă din nou...", xbmc.LOGINFO)
        download_epg()

def download_epg():
    try:
        xbmc.log("[EPG] Începe descărcarea EPG...", xbmc.LOGDEBUG)
        response = requests.get(EPG_URL, stream=True, timeout=20)
        response.raise_for_status()
        with open(EPG_FILE_PATH, "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
        xbmc.log("[EPG] Descărcare completă.", xbmc.LOGINFO)
        parse_and_store_epg()
    except Exception as e:
        xbmc.log(f"[EPG] Eroare descărcare EPG: {e}", xbmc.LOGERROR)

def start_background_epg_load():
    try:
        get_epg_path(force=True)
    except Exception as e:
        xbmc.log(f"[EPG] Eroare la start_background_epg_load: {e}", xbmc.LOGERROR)

def parse_and_store_epg():
    try:
        ensure_db()
        conn = sqlite3.connect(EPG_DB_PATH)
        c = conn.cursor()

        c.execute("BEGIN TRANSACTION")
        c.execute("DELETE FROM epg")

        channel_names = {}
        with gzip.open(EPG_FILE_PATH, 'rb') as f:
            tree = ET.parse(f)
            for channel in tree.findall("channel"):
                channel_id = channel.attrib.get("id")
                display_name = channel.findtext("display-name")
                if channel_id and display_name:
                    channel_names[channel_id] = display_name

        with gzip.open(EPG_FILE_PATH, 'rb') as f:
            programme_total = sum(1 for event, elem in ET.iterparse(f, events=("end",)) if elem.tag == "programme")

        inserts = []
        with gzip.open(EPG_FILE_PATH, 'rb') as f:
            context = ET.iterparse(f, events=("end",))
            current_channel = None
            count = 0
            last_percent = -1
            display = ""

            for event, elem in context:
                if elem.tag == "programme":
                    channel = elem.attrib.get("channel")
                    if channel != current_channel:
                        current_channel = channel
                        display = channel_names.get(channel, channel)

                    count += 1
                    percent = int((count / programme_total) * 100)
                    if percent != last_percent and percent % 1 == 0:
                        xbmc.executebuiltin(f'Notification(OHATO, {display} - {percent}%, 1000)')
                        last_percent = percent

                    start = elem.attrib.get("start")[:14]
                    stop = elem.attrib.get("stop")[:14]
                    title = elem.findtext("title", "Emisiune necunoscută")
                    desc = elem.findtext("desc", "")
                    inserts.append((channel, start, stop, title, desc))
                    elem.clear()

        c.executemany("INSERT INTO epg (channel, start, stop, title, desc) VALUES (?, ?, ?, ?, ?)", inserts)

        conn.commit()
        conn.close()
        xbmc.log("[EPG] Salvare în DB completă.", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"[EPG] Eroare la salvare DB: {e}", xbmc.LOGERROR)

def get_epg_now_next(tvg_id):
    try:
        get_epg_path()
        ensure_db()
        conn = sqlite3.connect(EPG_DB_PATH)
        now = dt.datetime.now(dt.timezone.utc) + dt.timedelta(hours=EPG_OFFSET_HOURS)
        now_str = now.strftime("%Y%m%d%H%M%S")

        c = conn.cursor()
        c.execute("SELECT title, start, stop FROM epg WHERE channel=? AND start<=? AND stop>? ORDER BY start LIMIT 1",
                  (tvg_id, now_str, now_str))
        row = c.fetchone()
        current = None
        if row:
            title, start, stop = row
            current = {
                "title": title,
                "start": dt.datetime.strptime(start, "%Y%m%d%H%M%S").strftime("%H:%M"),
                "stop": dt.datetime.strptime(stop, "%Y%m%d%H%M%S").strftime("%H:%M")
            }

        next_prog = None
        if current:
            c.execute("SELECT title, start, stop FROM epg WHERE channel=? AND start>? ORDER BY start LIMIT 1",
                      (tvg_id, now_str))
            row = c.fetchone()
            if row:
                title, start, stop = row
                next_prog = {
                    "title": title,
                    "start": dt.datetime.strptime(start, "%Y%m%d%H%M%S").strftime("%H:%M"),
                    "stop": dt.datetime.strptime(stop, "%Y%m%d%H%M%S").strftime("%H:%M")
                }

        conn.close()

        if current:
            plot = f"[B]EPG[/B]\n• [COLOR gold]{current['start']} – {current['stop']}[/COLOR] {current['title']}"
            if next_prog:
                plot += f"\n\n[COLOR gray]urmează[/COLOR]\n➡️ {next_prog['start']} – {next_prog['stop']} {next_prog['title']}"
            return plot
        return None

    except Exception as e:
        xbmc.log(f"[EPG] Eroare interogare DB: {e}", xbmc.LOGERROR)
        return None

def get_epg_day_schedule(tvg_id):
    try:
        get_epg_path()
        ensure_db()
        conn = sqlite3.connect(EPG_DB_PATH)
        today = (dt.datetime.now(dt.timezone.utc) + dt.timedelta(hours=EPG_OFFSET_HOURS)).date()
        start_day = today.strftime("%Y%m%d") + "000000"
        end_day = today.strftime("%Y%m%d") + "235959"

        c = conn.cursor()
        c.execute("SELECT title, start FROM epg WHERE channel=? AND start BETWEEN ? AND ? ORDER BY start",
                  (tvg_id, start_day, end_day))
        rows = c.fetchall()
        conn.close()

        if not rows:
            return "Nicio emisiune programată pentru azi."

        schedule = []
        for title, start in rows:
            hour = dt.datetime.strptime(start, "%Y%m%d%H%M%S").strftime("%H:%M")
            schedule.append(f"[{hour}] {title}")

        return "\n".join(schedule)

    except Exception as e:
        xbmc.log(f"[EPG] Eroare interogare zi DB: {e}", xbmc.LOGERROR)
        return "Fără informații disponibile."
