# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

from ..utils.browser import Firefox
from ..utils.resolve import Resolver
import requests

class PlutoTV(Resolver):
    def __init__(self):
        self.firefox = Firefox()

    def grab(self, channel):
        resp = requests.get("https://i.mjh.nz/PlutoTV/app.json", headers=self.firefox.headers)
        data = resp.json()['regions']['us']
        channels = data['channels']
        self.firefox.addHeader("X-Forwarded-For", data['headers']['x-forwarded-for'])

        for k,v in channels.items():
            if str(v['name']).lower().replace(" ", "-") == str(channel).lower().replace(" ", "-"):
                return v['url'], self.firefox.headers
                break 

