# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

class TV247:
    def __init__(self):
        self.ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'
        self.base = "http://live.tv247.club/tv247/"
    
    def grab(self, channel):
        headers = {'User-Agent': self.ua}
        headers.update({'Referer': 'http://tv247us.com/'}) # Changing this even to self.base breaks everything
        hlsUrl = self.base + channel + ".m3u8"
        return hlsUrl, headers