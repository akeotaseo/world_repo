# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import re
import requests
from ..utils.browser import Firefox
from ..utils.resolve import Resolver

class HunterTV(Resolver):
    def __init__(self):
        self.home = "http://www.huntertv.cz/"

    def grab(self, channel):
        firefox = Firefox()
        hlsurl = ""
        html = requests.get(self.home, headers=firefox.headers).text
        match = re.search(r'(?<=sources\[0\].src = ").*?(?=";)', html)
        if match:
            hlsurl = match.group(0)
        return hlsurl, firefox.headers