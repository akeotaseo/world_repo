import re
import xbmcaddon
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

def Menu():
	addDir('Latest Videos',      'https://www.xfreehd.com/videos?o=mr&type=public', 141, 'special://home/addons/plugin.video.xxx/resources/art/pornone.png')
	#addDir('Most Viewed Videos', 'https://pornone.com/views/',      141, 'special://home/addons/plugin.video.xxx/resources/art/pornone.png')
	#addDir('Top Rated Videos',   'https://pornone.com/rating/',     141, 'special://home/addons/plugin.video.xxx/resources/art/pornone.png')
	#addDir('Categories',         'https://pornone.com/categories/', 142, 'special://home/addons/plugin.video.xxx/resources/art/pornone.png')

def Browse(url):
	r = OpenURL(url)
	m = re.compile('<a class="video-link" href="(.+?)">\n							<div class="thumb-overlay">\n																	<img src=".+?" data-src="(.+?)" title="(.+?)" alt=".+?" id=".+?" class=".+? />\n																																<div class="later" id=".+?"></div>\n								<div class="duration-new">\n									\n									(.+?)\n								</div>').findall(r)
	for url, thumb, title, time in m:
		import random
		random_id = random.randint(0,1000000)
		url = '%s&random_id=%s' % (url, str(random_id))
		if Setting('show_time') == 'true': title = '[B](%s)[/B] %s' % (time, title)
		addVideo(title, url, 143, thumb)
	n = re.compile('</a></li><li><a href="(.+?)" class="prevnext">&raquo;</a>').findall(r)
	for page in n:
		#addDir('Next page >', page.replace('amp;', ''), 141, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
		addDir(title, page.replace('amp;', ''), 141, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	Common.SetView()
		
def Categories(url):
	r = OpenURL(url)
	m = re.compile('<img src=".+?" alt="Video category (.+?)" data-src="/images/categories/(.+?)\.jpg" class="object-center object-cover" />').findall(r)
	for title, code in m:
		url   = 'https://pornone.com/%s/' % code
		thumb = 'https://pornone.com/images/categories/%s.jpg' % code
		addDir(title, url, 141, thumb)
	
def PlayStream(url):
	if 'random_id=' in url:
		url = re.compile('(.+?)&random_id').findall(url)[0]
	r = OpenURL(url)
	video = re.compile('<source src="(.+?)" ').findall(r)[0]
	Play(video)
