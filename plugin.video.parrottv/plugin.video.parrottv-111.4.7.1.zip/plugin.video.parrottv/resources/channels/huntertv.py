# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests
import re

class HunterTV:
    def __init__(self):
        self.ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'
        self.home = "http://www.huntertv.cz/"

    def grab(self, channel):
        headers = {'User-Agent': self.ua}
        hlsurl = ""
        html = requests.get(self.home, headers=headers).text
        match = re.search(r'(?<=sources\[0\].src = ").*?(?=";)', html)
        if match:
            hlsurl = match.group(0)
        return hlsurl, headers