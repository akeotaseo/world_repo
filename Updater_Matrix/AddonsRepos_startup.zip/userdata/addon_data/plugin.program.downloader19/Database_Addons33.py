﻿from updatervar import *
import db


def addon_database():
    db.addon_database(Database_Addons33, 1, True)

Database_Addons33 = [('repository.World', 'repository.World'),
                     ('repository.Worldolympic', 'repository.World'),
                     ('repository.Worldrepo', 'repository.World'),
                     ('repository.WorldNexus', 'repository.World'),
                     ('repository.WorldOmega', 'repository.WorldOmega'),


                     ('plugin.program.downloaderstartup', 'repository.Worldolympic'),
                     ('skin.19MatrixWorld', 'repository.Worldolympic'),
                     ('plugin.program.myselect', 'repository.Worldolympic'),
                     ('plugin.program.simple.favourites', 'repository.Worldolympic'),
                     ('service.autoexec', 'repository.Worldolympic'),


                     ('script.embuary.info', 'repository.Worldolympic'),
                     ('plugin.video.watchnixtoons2', 'repository.Worldolympic'),
                     
                     ('plugin.video.macvod', 'repository.Worldolympic'),
                     ('plugin.video.rumble', 'repository.Worldolympic'),
                     ('plugin.video.scrapee', 'repository.Worldolympic'),


                     ('plugin.video.cristalazul', 'repository.World'),
                     ('script.black.bars.never', 'repository.World'),
                     ('script.kelebek', 'repository.World'),
                     ('script.luar', 'repository.World'),
                     ('plugin.video.stalker', 'repository.World'),

                     ('repository.oliver', 'repository.Worldrepo'),


                                      # sportsdevil
                     ('plugin.video.sportsdevil', 'repository.World'),
                     ('script.module.streamlink', 'repository.World'),
                     ('script.module.slproxy', 'repository.World'),
                     ('script.module.pycountry', 'repository.World'),
                     ('script.module.isodate', 'repository.gkobu'),
                     ('script.module.pysocks', 'repository.xbmc.org'),




                     ('script.module.infotagger', 'repository.jurialmunkey'),

                                          # gkobu 
                     
                     ('plugin.video.youtube', 'repository.gkobu'),

                     ('plugin.video.duffyou', 'repository.gkobu'),
                     ('plugin.video.f4mTester', 'repository.gkobu'),
                     ('script.video.F4mProxy', 'repository.gkobu'),
                     ('plugin.video.live.streamspro', 'repository.gkobu'),
                     ('plugin.video.lookmovietomb', 'repository.gkobu'),
                     ('plugin.video.fmoviesto', 'repository.gkobu'),
                     #('plugin.video.sporthdme', 'repository.gkobu'),

                     ('plugin.video.cartoonsgr', 'repository.gkobu'),

                     ('plugin.video.gratis', 'repository.gkobu'),
                     ('plugin.video.lookmovietomb', 'repository.gkobu'),
                     ('plugin.video.thetvapp', 'repository.gkobu'),
                     ('service.subtitles.subscene', 'repository.gkobu'),
                     ('plugin.video.fen', 'repository.gkobu'),
                     


                                           # bugatsinho
                     #('plugin.video.cartoonsgr', 'repository.bugatsinho'),
                     ('plugin.video.sporthdme', 'repository.bugatsinho'),
                     ('script.module.t0mm0.common', 'repository.bugatsinho'),




                                           # twilight0
                     ('plugin.video.alphatv.gr', 'repository.twilight0'),
                     ('plugin.video.antenna.gr', 'repository.twilight0'),
                     ('plugin.video.fashiontv.com', 'repository.twilight0'),
                     ('plugin.video.skai.gr', 'repository.twilight0'),
                     ('plugin.video.star.gr', 'repository.twilight0'),




                                          # inputstreamhelper
                     #('script.module.inputstreamhelper', 'repository.xbmc.org'),
                     ('script.module.inputstreamhelper', 'repository.aliunde'),
                     #('script.module.inputstreamhelper', 'repository.slyguy.inputstreamhelper'),

                     ('repository.slyguy.inputstreamhelper', 'repository.slyguy'),



                                           # autowidget 
                     ('plugin.program.autowidget', 'repository.autowidget'),
                     ('repository.autowidget', 'repository.autowidget'),


                                           # zeltorix'
                     ('repository.zeltorix', 'repository.zeltorix'),
                     ('plugin.video.zeltorix.worldcams.tv', 'repository.zeltorix'),
                     ('script.module.zeltorix.packages', 'repository.zeltorix'),
                     ('script.module.zeltorix.utilitys', 'repository.zeltorix'),
                     #('script.module.zeltorix.utilitys', 'repository.World'),




                                       # vnmedia 
                     ('plugin.video.vnmedia', 'repovnmedia'),
                     ('repovnmedia', 'repovnmedia'),
                     ('script.module.htmlement', 'repovnmedia'),




                     ('plugin.video.90phuttv', 'kodivietnam'),
                     ('kodivietnam', 'kodivietnam'),
                     ('script.module.beautifulsoup4', 'kodivietnam'),
                     ('script.module.certifi', 'kodivietnam'),
                     ('script.module.chardet', 'kodivietnam'),
                     ('script.module.cloudscraperkd', 'kodivietnam'),
                     ('script.module.codequick', 'kodivietnam'),

                     ('script.module.idna', 'kodivietnam'),
                     ('script.module.pyparsing', 'kodivietnam'),
                     ('script.module.pyqrcode', 'kodivietnam'),
                     ('script.module.requests-toolbelt', 'kodivietnam'),
                     ('script.module.pysocks', 'kodivietnam'),
                     ('script.module.simplejson', 'kodivietnam'),
                     ('script.module.soupsieve', 'kodivietnam'),
                     ('script.module.urllib3', 'kodivietnam'),
                     ('script.module.websocket', 'kodivietnam'),



                                         # xbmc.org
                     #('plugin.video.youtube', 'repository.xbmc.org'),
                     #('script.module.infotagger', 'repository.xbmc.org')

                     ('plugin.audio.radio_de', 'repository.xbmc.org'),
                     ('weather.gismeteo', 'repository.xbmc.org'),

                     ('script.module.myconnpy', 'repository.xbmc.org'),
                     ('script.module.clouddrive.common', 'repository.xbmc.org'),
                     ('metadata.themoviedb.org.python', 'repository.xbmc.org'),



                                        # jurialmunkey
                     ('script.module.infotagger', 'repository.jurialmunkey'),



                                        # arrownegra
                     #('repository.arrownegra', 'repository.arrownegra'),
                     ('plugin.video.aguia_de_ouro', 'repository.arrownegra'),
                     ('plugin.video.fenix-mac', 'repository.arrownegra'),
                     ('repository.arrownegra', 'repository.Worldrepo'),





                                    # RD account  //  709
                     ('repository.709', 'repository.709'),
                     ('script.module.accountmgr', 'repository.709'),
                     ('script.module.acctview', 'repository.709'),



                                           # daddylive
                     ('plugin.video.daddylive', 'repository.Worldolympic'),
                     #('plugin.video.daddylive', 'repository.thecrew'),
                     #('plugin.video.daddylive', 'repository.aliunde'),
                     #('plugin.video.daddylive', 'repository.dexe'),



                                         # Netflix
                     ('repository.castagnait', 'repository.castagnait'),
                     ('plugin.video.netflix', 'repository.castagnait'),





                                         # dexe
                     ('repository.roooar', 'repository.roooar'),
                     ('repository.dexe', 'repository.roooar'),
                     ('plugin.video.BauBauVavoo', 'repository.dexe'),
                     ('plugin.video.GreenKlikPremium', 'repository.dexe'),
                     #('plugin.video.fen', 'repository.dexe'),

                     ('plugin.video.free99', 'repository.dexe'),
                     ('script.free99.artwork', 'repository.dexe'),


                                         # diggz
                     ('repository.diggz', 'repository.diggz'),
                     #('plugin.video.free99', 'repository.diggz'),
                     #('script.free99.artwork', 'repository.diggz'),



                                         # cMaNWizard
                     ('repository.cMaNWizard', 'repository.cMaNWizard'),
                     ('plugin.video.quicksilver', 'repository.cMaNWizard'),
                     ('script.module.quicksilverscrapers', 'repository.cMaNWizard'),
                     ('script.quicksilver.artwork', 'repository.cMaNWizard'),

                                        # homelander
                     ('repository.chainsrepo', 'repository.chainsrepo'),
                     ('plugin.video.homelander', 'repository.chainsrepo'),
                     ('script.module.homelanderscrapers', 'repository.chainsrepo'),
                     ('script.homelander.artwork', 'repository.chainsrepo'),




                                             # REST
                     ('script.module.jetextractors', 'repository.loop'),

                     ('plugin.video.torquelite', 'repository.gearheads2'),

                     ('repository.KODIvertiDO_TEAM', 'repository.KODIvertiDO_TEAM'),
                     ('plugin.video.KODIvertiDO', 'repository.KODIvertiDO_TEAM'),

                     ('plugin.video.vavooto', 'repository.michaz'),

                     ('repository.jellyfin.kodi', 'repository.jellyfin.kodi'),

                     ('plugin.video.thethunder', 'One.repo'),

                     ('repository.alado.tv', 'repository.alado.tv'),
                     ('plugin.video.train.mac.again', 'repository.alado.tv'),

                     ('repository.cocoscrapers', 'repository.cocoscrapers'),
                     ('script.module.cocoscrapers', 'repository.cocoscrapers'),

                     ('repository.lekma', 'repository.lekma'),
                     ('plugin.video.invidious', 'repository.lekma'),

                     ('repository.rays.files', 'repository.rays.files'),

                     ('repository.Parrot', 'repository.Parrot'),

                     ('repository.subskip', 'repository.subskip'),


                     ('repository.kodifitzwell', 'repository.kodifitzwell'),
                     ('repository.azzyaddons', 'repository.azzyaddons'),
                     ('plugin.video.rumble', 'repository.azzyaddons'),



                     ('skin.xonfluence', 'hellyrepo.kodi')


                     ]


addon_database()
