from codequick import Route, Listitem, Script, Resolver
from resources.lib.kedon import __addonnoti__, getlink, quangcao, tb, yttk, get_info_fs
from bs4 import BeautifulSoup
from xbmcgui import DialogProgress
from xbmcaddon import Addon
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import lru_cache
@lru_cache(maxsize=None)
def process_url(url):
	try:
		data = get_info_fs(url)
		return url, data
	except:
		return url, None
@Route.register
def index_hdo(plugin, **kwargs):
	dulieu = {
	'Đặc sắc': -1,
	'Hành động': 76,
	'Phiêu lưu': 86,
	'Hình sự': 77,
	'Trinh thám': 106,
	'Võ thuật': 111,
	'Rùng rợn': 98,
	'Huyền bí': 80,
	'Kinh dị': 81,
	'Viễn tưởng': 109,
	'Hài hước': 74,
	'Lãng mạn': 82,
	'Thần thoại': 100,
	'Cổ trang': 71,
	'Phim TVB': 108,
	'Phim bộ Hàn': 89,
	'Phim bộ Mỹ': 91,
	'Lồng tiếng': 84,
	'Hoạt hình': 78
	}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.info['plot'] = tb
		item.art['thumb'] = item.art['fanart'] = f'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/hdo.jpeg'
		item.set_callback(hdo_page, dulieu[k])
		yield item
@Route.register
def hdo_page(plugin, idp=None, **kwargs):
	yield []
	if idp is None:
		pass
	else:
		trangtiep = f'https://thuvienhd.com/?feed=rss&exclude_cats=250004&category={idp}&posts_per_page=100'
		resp = getlink(trangtiep, trangtiep, 1000)
		if (resp is not None):
			soup = BeautifulSoup(resp.content, 'html.parser')
			it = soup.select('item')
			for k in it:
				item = Listitem()
				item.label = k.select_one('title').get_text(strip=True)
				mota = k.select_one('description').get_text(strip=True)
				anh = k.select_one('enclosure')['url']
				kid = k.select_one('id').get_text(strip=True)
				item.info['plot'] = mota
				item.info['mediatype'] = 'movie'
				item.art['thumb'] = item.art['fanart'] = anh
				item.set_callback(hdo_link, kid, mota, anh)
				yield item
		else:
			yield quangcao()
@Route.register
def hdo_link(plugin, idk=None, mota=None, anh=None, **kwargs):
	yield []
	if idk is None or mota is None or anh is None:
		pass
	else:
		t = f'https://thuvienhd.com/?feed=rss&id={idk}'
		r = getlink(t, t, 1000)
		if (r is not None):
			dialog = DialogProgress()
			dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
			soup = BeautifulSoup(r.content, 'html.parser')
			soups = soup.select('item fshare link')
			urls =[k['url'] for k in soups]
			length = len(urls)
			if length>0:
				count = 0
				with ThreadPoolExecutor(length) as ex:
					future_to_url = (ex.submit(process_url, url) for url in urls)
					v = as_completed(future_to_url)
					for future in v:
						link, data = future.result()
						if data is not None:
							if (dialog.iscanceled()):
								break
							count += 1
							done = int((count/length)*100)
							dialog.update(done, f'Đang giải mã {length} dữ liệu...\nLoading... [COLOR yellow]{done} %[/COLOR]')
							item = Listitem()
							tenm = data[0]
							sz = data[1]
							item.label = tenm
							item.info['plot'] = mota
							item.info['mediatype'] = 'episode'
							item.info['rating'] = 10.0
							item.info['trailer'] = yttk(tenm)
							item.art['thumb'] = item.art['fanart'] = anh
							item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
							if 'folder' in link:
								item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link, 0)
							else:
								item.info['size'] = sz
								if Addon().getSetting('taifshare') == 'true':
									item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
								item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, tenm)
							yield item
			else:
				yield quangcao()
			dialog.close()
		else:
			yield quangcao()