import re
import xbmcaddon
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

BaseURL = 'https://yesporn.vip'
Thumb   = 'special://home/addons/plugin.video.xxx/resources/art/yespornvip.png'


def Menu():
	addDir('Latest Videos',      BaseURL + '/?filter=latest',      171, Thumb)
	addDir('Most Viewed Videos', BaseURL + '/?filter=most-viewed', 171, Thumb)
	addDir('Random Videos',      BaseURL + '/?filter=random',      171, Thumb)
	addDir('Tags',               BaseURL + '/tags-2/',             172, Thumb)
	#addDir('Sites',              BaseURL + '/sites/',          172, Thumb)
	#addDir('Channels',           BaseURL + '/channels/',       172, Thumb)

def Browse(url):
	if '/?filter=latest' in url: filter = '/?filter=latest'
	elif '/?filter=most-viewed' in url: filter = '/?filter=most-viewed'
	elif '/?filter=random' in url: filter = '/?filter=random'
	else: filter = ''
	r = OpenURL(url)
	m = re.compile('<a href="(.+?)" title="(.+?)">\n<div class="post-thumbnail">\n<div class="post-thumbnail-container video-with-trailer"><div class="video-debounce-bar"></div><div class="lds-dual-ring"></div><div class="video-preview"></div><img width="300" height="168.75" data-src="(.+?)" alt=".+?"></div>.+?<span class="duration"><i class="fa fa-clock-o"></i>(.+?)</span> </div>').findall(r)
	for url, title, thumb, time in m:
		if Setting('show_time') == 'true': title = '[B](%s)[/B] %s' % (time, title)
		url = '%s&random_id=%s' % (url, RandomID())
		addVideo(title, url, 173, thumb)
	n = re.compile('<link rel="next" href="(.+?)" />').findall(r)
	for NextPage in n:
		addDir('Next page >', NextPage + filter, 171, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	Common.SetView()

def Categories(url):
	r = OpenURL(url)
	m = re.compile('<a href="https://yesporn.vip/tag/(.+?)/"').findall(r)
	for tag in m:
		url = 'https://yesporn.vip/tag/%s/' % tag
		title = tag.replace('-', ' ')
		addDir(title, url, 171, Thumb)
	
def PlayStream(url):
	if 'random_id=' in url: url = re.compile('(.+?)&random_id').findall(url)[0]
	r = OpenURL(url)
	video = re.compile('<meta itemprop="contentURL" content="(.+?)" />').findall(r)[0]
	Play(video)

def RandomID():
	import random
	random_id = str(random.randint(0,1000000))
	return random_id