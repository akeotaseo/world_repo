import re
import xbmcaddon
import datetime
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

BaseURL = 'https://www.xhamster.com'
Thumb   = 'special://home/addons/plugin.video.xxx/resources/art/xhamster.png'

def Menu():
	addDir('Latest Videos',       BaseURL + '/newest',       111, Thumb)
	addDir('Top Rated Videos',    BaseURL + '/best',         111, Thumb)
	addDir('Most Watched Videos', BaseURL + '/most-viewed/', 111, Thumb)
	addDir('Popular Today',       BaseURL + '/best/daily',   111, Thumb)
	addDir('Popular This Week',   BaseURL + '/best/weekly',  111, Thumb)
	addDir('Popular This Month',  BaseURL + '/best/monthly', 111, Thumb)
	addDir('Categories',          BaseURL + '/categories',   112, Thumb)
	addDir('Channels',            BaseURL + '/channels',     112, Thumb)

def Browse(url):
	pageURL = url
	r = OpenURL(pageURL + '?min-duration=10&max-duration=40')
	r = r.replace('\\/', '/')
	m = re.compile('\{"modelName":"videoModel"(.+?)\}').findall(r)
	for i in m:
		url   = re.compile('"pageURL":"(.+?)"').findall(i)[0]
		thumb = re.compile('"thumbURL":"(.+?)"').findall(i)[0]
		title = re.compile('"title":"(.+?)"').findall(i)[0]
		time  = re.compile('"duration":(.+?),').findall(i)[0]
		time  = str(datetime.timedelta(seconds=int(time)))
		if Setting('show_time') == 'true': title = '[B](%s)[/B] %s' % (time, title)
		url = '%s&random_id=%s' % (url, RandomID())
		addVideo(title, url, 113, thumb)
	r = OpenURL(pageURL + '?min-duration=40')
	r = r.replace('\\/', '/')
	m = re.compile('\{"modelName":"videoModel"(.+?)\}').findall(r)
	for i in m:
		url   = re.compile('"pageURL":"(.+?)"').findall(i)[0]
		thumb = re.compile('"thumbURL":"(.+?)"').findall(i)[0]
		title = re.compile('"title":"(.+?)"').findall(i)[0]
		time  = re.compile('"duration":(.+?),').findall(i)[0]
		time  = str(datetime.timedelta(seconds=int(time)))
		if Setting('show_time') == 'true': title = '[B](%s)[/B] %s' % (time, title)
		url = '%s&random_id=%s' % (url, RandomID())
		addVideo(title, url, 113, thumb)
	
	n = re.compile('data-page="next" href="(.+?)"').findall(r)
	for NextPage in n:
		if '?' in NextPage:
			NextPage = '"%s"' % NextPage
			NextPage = re.compile('"(.+?)\?').findall(NextPage)[0]
		addDir('Next page >', NextPage, 111, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	Common.SetView()

def Categories(url):
	r = OpenURL(url)
	if 'categories' in url:
		m = re.compile('<a href="https://xhamster.com/tags/(.+?)"').findall(r)
		for url in m:
			title = url.replace('-', ' ')
			title = title.title()
			url   = 'https://xhamster.com/tags/' + url
			addDir(title, url, 111, Thumb)
	else:
		r = r.replace('\n', '')
		m = re.compile('<div class="channel-thumb-container__image-container">(.+?)</div>').findall(r, re.MULTILINE)
		for i in m:
			title = re.compile('alt="(.+?)"').findall(i)[0]
			url   = re.compile('<a href="(.+?)"').findall(i)[0]
			thumb = re.compile('src="(.+?)"').findall(i)[0]
			addDir(title, url, 111, thumb)
	
		n = re.compile('data-page="next" href="(.+?)"').findall(r)
		for NextPage in n:
			addDir('Next page >', NextPage, 112, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	
def PlayStream(url):
	if 'random_id=' in url: url = re.compile('(.+?)&random_id').findall(url)[0]
	r = OpenURL(url)
	r = r.replace('\\/', '/')
	video = re.compile('"mp4File":"(.+?)"').findall(r)[0]
	Play(video)

def RandomID():
	import random
	random_id = str(random.randint(0,1000000))
	return random_id