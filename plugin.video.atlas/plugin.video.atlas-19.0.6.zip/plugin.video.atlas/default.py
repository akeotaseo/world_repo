import sys, json
import xbmc, xbmcgui
import xbmcplugin
import xbmcvfs, xbmcaddon
import os, re
import json
import requests
import six

try:
    from sqlite3 import dbapi2 as database
except BaseException:
    from pysqlite2 import dbapi2 as database
from urllib.parse import unquote_plus
from resources.lib.modules import client
from resources.lib.modules import cache
from resources.lib.modules import control
from resources.lib.modules import init
from resources.lib.modules import views
from resources.lib.modules import domparser as dom
from resources.lib.modules.control import addDir
from resources.lib.modules import utils
from resources.lib.modules.params import p
from resources.lib.modules import yt_playlists
from resources.lib.modules.parser import Parser
from six.moves.urllib_parse import urlparse, urlencode, urljoin, unquote, unquote_plus, quote, quote_plus, parse_qsl

BASEURL = 'https://tenies-online1.gr/genre/kids/'  # 'https://paidikestainies.online/'
GAMATO = control.setting('gamato.domain') or 'http://gamatotv.info/'  # 'https://gamatokid.com/'
Teniesonline = control.setting('tenies.domain') or 'https://tenies-online1.gr/'
XRYSOI = control.setting('xrysoi.domain') or 'https://xrysoi.pro/'

ADDON = xbmcaddon.Addon()
ADDON_DATA = ADDON.getAddonInfo('profile')
ADDON_PATH = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART = ADDON.getAddonInfo('fanart')
ICON = ADDON.getAddonInfo('icon')
ID = ADDON.getAddonInfo('id')
NAME = ADDON.getAddonInfo('name')
VERSION = ADDON.getAddonInfo('version')
Lang = control.lang#ADDON.getLocalizedString
Dialog = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"

addon_id = xbmcaddon.Addon().getAddonInfo('id')
translatePath = xbmcvfs.translatePath
addon_id = xbmcaddon.Addon().getAddonInfo('id')
addon = xbmcaddon.Addon(addon_id)
addoninfo = addon.getAddonInfo
addon_version = addoninfo('version')
addon_name = addoninfo('name')
addon_icon = addoninfo("icon")
addon_fanart = addoninfo("fanart")
addon_profile = translatePath(addoninfo('profile'))
addon_path = translatePath(addoninfo('path'))
setting = addon.getSetting
setting_set = addon.setSetting
local_string = addon.getLocalizedString
home = translatePath('special://home/')
dialog = xbmcgui.Dialog()
dp = xbmcgui.DialogProgress()
addons_path = os.path.join(home, 'addons/')
user_path = os.path.join(home, 'userdata/')
data_path = os.path.join(user_path, 'addon_data/')
packages = os.path.join(addons_path, 'packages/')
resources = os.path.join(addon_path, 'resources/')
xml_folder = os.path.join(resources, 'xml/')
yt_xml = xml_folder + 'main.json'
yt1_xml = xml_folder + 'kids.json'
yt2_xml = xml_folder + 'doc.json'
yt3_xml = xml_folder + 'main3.json'
user_agent = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36'
headers = {'User-Agent': user_agent}
handle = int(sys.argv[1])
addDir2 = utils.addDir

xbmc.log(str(p.get_params()),xbmc.LOGDEBUG)


def Main_addDir():
    addDir('[B][COLOR white]' + Lang(32002) + ' ...[/COLOR][/B]', '', 6, ART + 'search.png', FANART, '')
    addDir('[B][COLOR white]Xrysoi[/COLOR][/B]', '', 42, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR white]Gamato[/COLOR][/B]', '', 20, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR white]Tenies-Online[/COLOR][/B]', '', 30, ART + 'tainiesonline.png', FANART, '')
    addDir('[B][COLOR white]Παιδική Χαρά[/COLOR][/B]', '', 80, 'http://i.imgur.com/T8NlaOf.png', FANART, '')
    addDir('[B][COLOR white]Ντοκιμαντέρ[/COLOR][/B]', '', 81, 'http://i.imgur.com/jTaJF0B.png', FANART, '')
    downloads = True if control.setting('downloads') == 'true' and (
            len(control.listDir(control.setting('movie.download.path'))[0]) > 0 or
            len(control.listDir(control.setting('tv.download.path'))[0]) > 0) else False
    if downloads:
        addDir(' [B][COLOR white] Downloads[/COLOR][/B]', '', 40, 'https://i.imgur.com/2cPUPkf.png', FANART, '')
    addDir('[B][COLOR white]' + Lang(32020) + '[/COLOR][/B]', '', 17, 'https://i.imgur.com/2cPUPkf.png', FANART, '')
    addDir('[B][COLOR white]' + Lang(32021) + '[/COLOR][/B]', '', 9, 'https://i.imgur.com/2cPUPkf.png', FANART, '')
    addDir('[B][COLOR white]' + Lang(32019) + ': [COLOR lime]%s[/COLOR][/B]' % vers, '', 'bug', ICON, FANART, '')
#    views.selectView('menu', 'menu-view')


def MainYoutube(_xml):
    xml = Parser(_xml)
    items = xml.get_list()
    video_ids = []
    for item in json.loads(items)['items']:
        link = item.get('link')
        if 'video/' in link or 'youtu.be/' in link:
            video_ids.append(link.split('/')[-1])
        elif link.endswith('.json'):
            if link.startswith('http'):
                addDir2(item.get('title','Unknown'), item.get('link',''), 56, item.get('icon', addon_icon), item.get('fanart', addon_fanart), item.get('summary','Playlists from Youtube'))
            else:
                addDir2(item.get('title','Unknown'),xml_folder+item.get('link',''), 56, item.get('icon', addon_icon), item.get('fanart', addon_fanart), item.get('summary','Playlists from Youtube'))
        else:
            addDir2(item.get('title','Unknown'),item.get('link',''), 59, item.get('icon', addon_icon), item.get('fanart', addon_fanart), item.get('summary','Playlists from Youtube'))
    video_list = yt_playlists.get_videos(video_ids)
    try:
        for title, video_id, icon, description, duration, date in video_list:
            yt_playlists.addDir2(title, 'plugin://plugin.video.youtube/play/?video_id=%s'%video_id,3,icon, icon, description, duration=duration, date='Date Published: '+str(date)+'\n', isFolder=False)
    except:
        pass
#xbmcplugin.setContent(handle, 'movies')


def gamato_menu():
    addDir('[COLOR white]' + Lang(32002) + '[/COLOR]', GAMATO, 18, ART + 'search.png', FANART, '')
    addDir('[COLOR white]Νέες 2022[/COLOR]', GAMATO + 'release/2022/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Ανά Έτος[/COLOR]', GAMATO + 'movies/', 22, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Κατηγορίες[/COLOR]', GAMATO + 'movies/', 23, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]Ξένες Σειρές[/COLOR]', GAMATO + 'tvshows/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]' + Lang(32004) + '[/COLOR]', GAMATO + 'genre/gamato/', 4, ART + 'gamato.png', FANART, '')
    addDir('[COLOR white]' + Lang(32010) + '[/COLOR]', GAMATO + 'genre/κινούμενα-σχέδια/', 4, ART + 'gamato.png', FANART, '')
#    views.selectView('menu', 'menu-view')


def kids_menu():
    addDir('[B][COLOR white]' + Lang(32002) + ' ...[/COLOR][/B]', '', 6, ART + 'search.png', FANART, '')
    addDir('[B][COLOR white]Παιδικά You[COLOR red]Tube[/COLOR][/B]', '', 61, 'https://i.imgur.com/6bEuWDo.png', FANART, '')
    addDir('[B][COLOR white]Παιδικά μεταγλωττισμένα[COLOR blue] Gamato[/COLOR][/B]', GAMATO + 'genre/gamato/', 4, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR white]Παιδικά με υπότιτλους[COLOR blue] Gamato[/COLOR][/B]', GAMATO + 'genre/κινούμενα-σχέδια/', 4, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR white]Παιδικά μεταγλωττισμένα[COLOR green] Tainiesonline[/COLOR][/B]', 'https://tenies-online1.gr/genre/kids/', 34, ART + 'tainiesonline.png', FANART, '')
    addDir('[B][COLOR white]Κινούμενα σχέδια[COLOR green] Tainiesonline[/COLOR][/B]', 'https://tenies-online1.gr/genre/κινούμενα-σχέδια/', 34, ART + 'tainiesonline.png', FANART, '')
    addDir('[B][COLOR white]Ταινίες Anime [COLOR gold]Xrysoi[/COLOR][/B]', 'https://xrysoi.pro/category/category/animemovies/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR white]Σειρές Anime [COLOR gold]Xrysoi[/COLOR][/B]', 'https://xrysoi.pro/category/category/anime/', 44, ART + 'xrysoi.png', FANART, '')
#    views.selectView('menu', 'menu-view')


def documentary_menu():
    addDir('[B][COLOR white]' + Lang(32002) + ' ...[/COLOR][/B]', '', 6, ART + 'search.png', FANART, '')
    addDir('[B][COLOR white]Ντοκιμαντέρ You[COLOR red]Tube[/COLOR][/B]', '', 62, 'http://i.imgur.com/kkFddcJ.png', FANART, '')
    addDir('[B][COLOR white]Ντοκιμαντέρ[COLOR blue] Gamato[/COLOR][/B]', GAMATO + 'genre/%ce%bd%cf%84%ce%bf%ce%ba%cf%85%ce%bc%ce%b1%ce%bd%cf%84%ce%ad%cf%81/', 4, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR white]Ντοκιμαντέρ[COLOR green] Tainiesonline[/COLOR][/B]', 'https://tenies-online1.gr/genre/ntokimanter/', 34, ART + 'tainiesonline.png', FANART, '')
#    views.selectView('menu', 'menu-view')


def yt_playlist(link):
    if link.startswith('http'):
        if 'list=' in link:
            link = link.split('list=')[-1]
    elif link.startswith('plugin'):
        link = link.split('playlist/')[-1].replace('/','')
    yt_playlists.get_playlist_items(link)

def yt_channel(_id):
    yt_playlists.ch_playlists(_id)

def play_video(title, link, iconimage):
    video = unquote_plus(link)
    liz = xbmcgui.ListItem(title)
    liz.setInfo('video', {'Title': title})
    liz.setArt({'thumb': iconimage, 'icon': iconimage})
    xbmc.Player().play(video,liz)


def Series():
    addDir('[B][COLOR orangered]' + Lang(32006) + '[/COLOR][/B]',
           BASEURL, 7, ART + 'genre.jpg', FANART, '')
    addDir('[B][COLOR orangered]' + Lang(32007) + '[/COLOR][/B]',
           BASEURL, 16, ART + 'etos.jpg', FANART, '')
    addDir('[B][COLOR orangered]' + Lang(32010) + '[/COLOR][/B]',
           BASEURL + 'tvshows-genre/κινούμενα-σχέδια/', 5, ART + 'tvshows.jpg', FANART, '')
    addDir('[B][COLOR orangered]' + Lang(32009) + '[/COLOR][/B]',
           BASEURL + 'tvshows/', 5, ART + 'tvshows.jpg', FANART, '')
#    views.selectView('menu', 'menu-view')


def year(url):
    r = cache.get(client.request, 120, url)
    r = client.parseDOM(r, 'div', attrs={'id': 'moviehome'})[0]
    r = client.parseDOM(r, 'div', attrs={'class': 'filtro_y'})[0]
    r = client.parseDOM(r, 'li')
    for post in r:
        try:
            url = client.parseDOM(post, 'a', ret='href')[0]
            year = client.parseDOM(post, 'a')[0].encode('utf-8')
        except IndexError:
            year = '[N/A]'

        addDir('[B][COLOR white]%s[/COLOR][/B]' % year, url, 5, ART + 'movies.jpg', FANART, '')
#    views.selectView('menu', 'menu-view')


def Get_TV_Genres(url):  # 7
    r = cache.get(client.request, 120, url)
    r = client.parseDOM(r, 'div', attrs={'id': 'serieshome'})[0]
    r = client.parseDOM(r, 'div', attrs={'class': 'categorias'})[0]
    r = client.parseDOM(r, 'li', attrs={'class': 'cat-item.+?'})
    for post in r:
        try:
            url = client.parseDOM(post, 'a', ret='href')[0]
            name = client.parseDOM(post, 'a')[0]
            name = re.sub(r'\d{4}', '', name)
            items = client.parseDOM(post, 'span')[0].encode('utf-8')
        except BaseException:
            pass
        name = clear_Title(name) + ' ([COLORlime]' + items + '[/COLOR])'
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 5, ART + 'tvshows.jpg', FANART, '')
#    views.selectView('menu', 'menu-view')


def year_TV(url):
    r = cache.get(client.request, 120, url)
    r = client.parseDOM(r, 'div', attrs={'id': 'serieshome'})[0]
    r = client.parseDOM(r, 'h3', attrs={'class': 'g1-gamma g1-gamma-1st entry-title'})[0]
    r = client.parseDOM(r, 'h3')
    for post in r:
        try:
            url = client.parseDOM(post, 'a', ret='href')[0]
            year = client.parseDOM(post, 'a')[0].encode('utf-8')
        except BaseException:
            pass
        addDir('[B][COLOR white]%s[/COLOR][/B]' % year, url, 5, ART + 'tvshows.jpg', FANART, '')
#    views.selectView('menu', 'menu-view')


def Get_random(url):  # 8
    r = client.request(url)
    r = client.parseDOM(r, 'div', attrs={'id': 'slider1'})[0]
    r = client.parseDOM(r, 'div', attrs={'class': 'item'})
    for post in r:
        try:
            url = client.parseDOM(post, 'a', ret='href')[0]
            icon = client.parseDOM(post, 'img', ret='src')[0]
            name = client.parseDOM(post, 'span', attrs={'class': 'ttps'})[0].encode('utf-8')
            name = re.sub('\d{4}', '', name)
        except BaseException:
            pass
        try:
            year = client.parseDOM(post, 'span', attrs={'class': 'ytps'})[0].encode('utf-8')
        except BaseException:
            year = 'N/A'

        name = clear_Title(name)
        if '/ ' in name:
            name = name.split('/ ')
            name = name[1] + ' ([COLOR lime]' + year + '[/COLOR])'
        elif '\ ' in name:
            name = name.split('\ ')
            name = name[1] + ' ([COLOR lime]' + year + '[/COLOR])'
        else:
            name = name + ' ([COLOR lime]' + year + '[/COLOR])'
        if 'tvshows' in url or 'syllogh' in url:
            addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 11, icon, FANART, '')
        else:
            addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 10, icon, FANART, '')
#    views.selectView('menu', 'menu-view')


def Get_epoxiakes(url):  # 19
    try:
        r = client.request(url)
        r = client.parseDOM(r, 'div', attrs={'id': 'slider2'})[0]
        if r is None:
            control.infoDialog('Δεν υπάρχουν διαθέσιμοι τίτλοι αυτήν την περίοδο', NAME, ICON, 7000)
        else:
            r = client.parseDOM(r, 'div', attrs={'class': 'item'})
    except BaseException:
        r = []

    for post in r:
        try:
            url = client.parseDOM(post, 'a', ret='href')[0]
            icon = client.parseDOM(post, 'img', ret='src')[0]
            name = client.parseDOM(post, 'span', attrs={'class': 'ttps'})[0].encode('utf-8')
            name = re.sub(r'\d{4}', '', name)
        except BaseException:
            pass
        try:
            year = client.parseDOM(post, 'span', attrs={'class': 'ytps'})[0].encode('utf-8')
        except BaseException:
            year = 'N/A'

        name = clear_Title(name)
        if '/ ' in name:
            name = name.split('/ ')
            name = name[1] + ' ([COLOR lime]' + year + '[/COLOR])'
        elif '\ ' in name:
            name = name.split('\ ')
            name = name[1] + ' ([COLOR lime]' + year + '[/COLOR])'
        else:
            name = name + ' ([COLOR lime]' + year + '[/COLOR])'
        if 'tvshows' in url or 'syllogh' in url:
            addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 11, icon, FANART, '')
        else:
            addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 10, icon, FANART, '')
#    views.selectView('menu', 'menu-view')


def Get_content(url):  # 5
    r = cache.get(client.request, 4, url)
    data = client.parseDOM(r, 'div', attrs={'id': 'mt-\d+'})
    for post in data:
        try:
            url = client.parseDOM(post, 'a', ret='href')[0]
            icon = client.parseDOM(post, 'img', ret='src')[0]
            name = client.parseDOM(post, 'span', attrs={'class': 'tt'})[0]
            name = re.sub(r'\d{4}', '', name)
            desc = client.parseDOM(post, 'span', attrs={'class': 'ttx'})[0]
        except BaseException:
            pass
        try:
            year = client.parseDOM(post, 'span', attrs={'class': 'year'})[0].encode('utf-8')
        except BaseException:
            year = 'N/A'
        try:
            calidad = client.parseDOM(post, 'span', attrs={'class': 'calidad2'})[0].encode('utf-8')
            calidad = calidad.replace('Μεταγλωτισμένο', 'Μετ').replace('Ελληνικοί Υπότιτλοι', 'Υποτ')
            if '/' in calidad:
                calidad = Lang(32014)
            elif 'Προσ' in calidad:
                calidad = Lang(32017)
            elif calidad == 'Μετ':
                calidad = Lang(32015)
            else:
                calidad = Lang(32016)
        except BaseException:
            calidad = 'N/A'

        desc = clear_Title(desc)
        name = clear_Title(name)
        if '/ ' in name:
            name = name.split('/ ')
            name = name[1] + ' ([COLORlime]' + year + '[/COLOR])'
        elif '\ ' in name:
            name = name.split('\ ')
            name = name[1] + ' ([COLORlime]' + year + '[/COLOR])'
        else:
            name = name + ' ([COLORlime]' + year + '[/COLOR])'
        if 'tvshows' in url or 'syllogh' in url:
            addDir('[B][COLOR white]{0} [{1}][/COLOR][/B]'.format(name, calidad), url, 11, icon, FANART, desc)
        else:
            addDir('[B][COLOR white]{0} [{1}][/COLOR][/B]'.format(name, calidad), url, 10, icon, FANART, desc)
    try:
        np = re.compile('class="pag_b"><a href="(.+?)"', re.DOTALL).findall(r)
        for url in np:
            page = re.compile('page/(\d+)/', re.DOTALL).findall(url)[0]
            page = '[B][COLOR lime]' + page + '[B][COLOR white])[/B][/COLOR]'
            addDir('[B][COLOR gold]>>>' + Lang(32011) + '[/COLOR] [COLOR white](%s' % page, url, 5,
                   ART + 'next.jpg', FANART, '')
    except BaseException:
        pass
#    views.selectView('menu', 'menu-view')


def get_tenies_online_links(url):
    urls = []

    headers = {'User-Agent': client.randomagent(),
               'Referer': url}
    #r = client.request(url)
    r = requests.get(url).text
    try:
        frames = client.parseDOM(r, 'div', {'id': 'playeroptions'})[0]
        frames = dom.parse_dom(frames, 'li', attrs={'class': 'dooplay_player_option'},
                               req=['data-post', 'data-nume', 'data-type'])
        for frame in frames:
            post = 'action=doo_player_ajax&post=%s&nume=%s&type=%s' % \
                   (frame.attrs['data-post'], frame.attrs['data-nume'], frame.attrs['data-type'])
            if '=trailer' in post: continue
            p_link = 'https://tenies-online1.gr/wp-admin/admin-ajax.php'

            #flink = client.request(p_link, post=post, headers=headers)
            flink = requests.post(p_link, data=post, headers=headers).text
            flink = client.parseDOM(flink, 'iframe', ret='src')[0]

            host = __top_domain(flink)
            urls.append((flink, host))
        # xbmc.log('FRAMES-LINKs: %s' % urls)
    except BaseException:
        pass

    try:
        extra = client.parseDOM(r, 'div', attrs={'class': 'links_table'})[0]
        extra = dom.parse_dom(extra, 'td')
        extra = [dom.parse_dom(i.content, 'img', req='src') for i in extra if i]
        extra = [(i[0].attrs['src'], dom.parse_dom(i[0].content, 'a', req='href')) for i in extra if i]
        extra = [(re.findall('domain=(.+?)$', i[0])[0], i[1][0].attrs['href']) for i in extra if i]
        for item in extra:
            url = item[1]
            if 'paidikestainies' in url:
                continue
            if 'tenies-online' in url:
                url = client.request(url, output='geturl', redirect=True)
            else:
                url = url

            host = item[0]

            urls.append((url, host))
        # xbmc.log('EXTRA-LINKs: %s' % urls)
    except BaseException:
        pass

    return urls


def __top_domain(url):
    elements = urlparse(url)
    domain = elements.netloc or elements.path
    domain = domain.split('@')[-1].split(':')[0]
    regex = "(?:www\.)?([\w\-]*\.[\w\-]{2,3}(?:\.[\w\-]{2,3})?)$"
    res = re.search(regex, domain)
    if res: domain = res.group(1)
    domain = domain.lower()
    return domain


# def Trailer(url):
#     lcookie = cache.get(_Login, 4, BASEURL)
#     OPEN = cache.get(client.request, 4, url, True, True, False, None, None, None, False, None, None, lcookie)
#     patron = 'class="youtube_id.+?src="([^"]+)".+?></iframe>'
#     trailer_link = find_single_match(OPEN, patron)
#     trailer_link = trailer_link.replace('//www.', 'http://')
#     return trailer_link


def search_menu():  # 6
    addDir(' Νέα αναζήτηση...', 'new', 26, ART + 'search.png', FANART, '')

    dbcon = database.connect(control.searchFile)
    dbcur = dbcon.cursor()

    try:
        dbcur.execute("""CREATE TABLE IF NOT EXISTS Search (url text, search text)""")
    except BaseException:
        pass

    dbcur.execute("SELECT * FROM Search ORDER BY search")

    lst = []

    delete_option = False
    for (url, search) in dbcur.fetchall():
        search = six.ensure_str(search, errors='replace')
        if 'xrysoi' in url:
            _url = XRYSOI + "?s={}".format(quote_plus(search))
            domain = '[COLOR gold]XRYSOI[/COLOR]'
        elif 'gamato' in url:
            _url = GAMATO + "?s={}".format(quote_plus(search))
            domain = '[COLOR green]GAMATO[/COLOR]'
        else:
            _url = Teniesonline + "?s={}".format(quote_plus(search))
            domain = '[COLOR blue]TENIES-ONLINE[/COLOR]'

        title = '[B]%s[/B] - [COLOR gold][B]%s[/COLOR][/B]' % (search, domain)
        delete_option = True
        addDir(title, _url, 26, ART + 'search.png', FANART, '')
        lst += [(search)]
    dbcur.close()

    if delete_option:
        addDir(Lang(32039), '', 29, ICON, FANART, '')
  #  views.selectView('movies', 'movie-view')


def Search(url):  # 26
    if url == 'new':
        keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
        keyb.doModal()
        if keyb.isConfirmed():
            search = quote_plus(keyb.getText())
            if six.PY2:
                term = unquote_plus(search).decode('utf-8')
            else:
                term = unquote_plus(search)

            dbcon = database.connect(control.searchFile)
            dbcur = dbcon.cursor()

            dp = xbmcgui.Dialog()
            select = dp.select('Επιλογή Ιστότοπου', ['[COLOR gold][B]Xrysoi[/COLOR][/B]', '[COLOR green][B]Gamato[/COLOR][/B]', '[COLOR blue][B]Tenies-Online[/COLOR][/B]'])

            if select == 0:
                from resources.lib.indexers import xrysoi
                url = XRYSOI + "?s={}".format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                xrysoi.search(url)


            elif select == 1:
                url = GAMATO + "?s={}".format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                Search_gamato(url)

            elif select == 2:
                from resources.lib.indexers import teniesonline
                url = Teniesonline + "?s={}".format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                teniesonline.search(url)

            else:
                return
        else:
            return

    else:
        if 'xrysoi' in url:
            from resources.lib.indexers import xrysoi
            xrysoi.search(url)
        elif 'gamato' in url:
            Search_gamato(url)
        elif 'teniesonline' in url:
            from resources.lib.indexers import teniesonline
            teniesonline.search(url)
#    views.selectView('menu', 'menu-view')


def Del_search(url):
    control.busy()
    search = url.split('s=')[1].decode('utf-8')

    dbcon = database.connect(control.searchFile)
    dbcur = dbcon.cursor()
    dbcur.execute("DELETE FROM Search WHERE search = ?", (search,))
    dbcon.commit()
    dbcur.close()
    xbmc.executebuiltin('Container.Refresh')
    control.idle()


def download(name, iconimage, url):
    from resources.lib.modules import control
    control.busy()
    import json
    if url is None:
        control.idle()
        return

    try:

        url = evaluate(url)
        # xbmc.log('URL-EVALUATE: %s' % url)
    except Exception:
        control.idle()
        xbmcgui.Dialog().ok(NAME, 'Download failed', 'Your service can\'t resolve this hoster', 'or Link is down')
        return
    try:
        headers = dict(parse_qsl(url.rsplit('|', 1)[1]))
    except BaseException:
        headers = dict('')
    control.idle()
    title = re.sub('\[.+?\]', '', name)
    content = re.compile('(.+?)\s+[\.|\(|\[]S(\d+)E\d+[\.|\)|\]]', re.I).findall(title)
    transname = title.translate(None, '\/:*?"<>|').strip('.')
    transname = re.sub('\[.+?\]', '', transname)
    levels = ['../../../..', '../../..', '../..', '..']
    if len(content) == 0:
        dest = control.setting('movie.download.path')
        dest = control.transPath(dest)
        for level in levels:
            try:
                control.makeFile(os.path.abspath(os.path.join(dest, level)))
            except:
                pass
        control.makeFile(dest)
        dest = os.path.join(dest, transname)
        control.makeFile(dest)
    else:
        dest = control.setting('tv.download.path')
        dest = control.transPath(dest)
        for level in levels:
            try:
                control.makeFile(os.path.abspath(os.path.join(dest, level)))
            except:
                pass
        control.makeFile(dest)
        tvtitle = re.sub('\[.+?\]', '', content[0])
        transtvshowtitle = tvtitle.translate(None, '\/:*?"<>|').strip('.')
        dest = os.path.join(dest, transtvshowtitle)
        control.makeFile(dest)
        dest = os.path.join(dest, 'Season %01d' % int(content[0][1]))
        control.makeFile(dest)
    control.idle()
    # ext = os.path.splitext(urlparse(url).path)[1]

    ext = os.path.splitext(urlparse(url).path)[1][1:]
    # xbmc.log('URL-EXT: %s' % ext)
    if not ext in ['mp4', 'mkv', 'flv', 'avi', 'mpg']: ext = 'mp4'
    dest = os.path.join(dest, transname + '.' + ext)
    headers = quote_plus(json.dumps(headers))
    # xbmc.log('URL-HEADERS: %s' % headers)

    from resources.lib.modules import downloader
    control.idle()
    downloader.doDownload(url, dest, name, iconimage, headers)


def downloads_root():
    movie_downloads = control.setting('movie.download.path')
    tv_downloads = control.setting('tv.download.path')
    cm = [(control.lang(32007),
           'RunPlugin(plugin://plugin.video.atlas/?mode=17)'),
          (control.lang(32008), 'RunPlugin(plugin://plugin.video.atlas/?mode=9)')]
    if len(control.listDir(movie_downloads)[0]) > 0:
        item = control.item(label='Movies')
        item.addContextMenuItems(cm)
        item.setArt({'icon': ART + 'movies.jpg', 'fanart': FANART})
        xbmcplugin.addDirectoryItem(int(sys.argv[1]), movie_downloads, item, True)

    if len(control.listDir(tv_downloads)[0]) > 0:
        item = control.item(label='Tv Shows')
        item.addContextMenuItems(cm)
        item.setArt({'icon': ART + 'tvshows.jpg', 'fanart': FANART})
        xbmcplugin.addDirectoryItem(int(sys.argv[1]), tv_downloads, item, True)

    control.content(int(sys.argv[1]), 'videos')
    control.directory(int(sys.argv[1]))
#    views.selectView('menu', 'menu-view')


######################
####  GAMATOKIDS  ####
######################

def get_gam_genres(url):  # 3
    try:

        r = requests.get(url).text
        r = client.parseDOM(r, 'li', attrs={'id': r'menu-item-\d+'})[1:]
        # xbmc.log('POSTs: {}'.format(r))
        # r = client.parseDOM(r, 'div', attrs={'class': 'categorias'})[0]
        # r = client.parseDOM(r, 'li', attrs={'class': 'cat-item.+?'})
        for post in r:
            try:
                # xbmc.log('POST: {}'.format(post))
                url = client.parseDOM(post, 'a', ret='href')[0]
                name = client.parseDOM(post, 'a')[0]
                name = clear_Title(name)
                if 'facebook' in url or 'imdb' in url:
                    continue
                # xbmc.log('NAME: {} | URL: {}'.format(name, url))
                addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 4, ART + 'movies.jpg', FANART, '')
            except BaseException:
                pass

    except BaseException:
        pass
#    views.selectView('menu', 'menu-view')


def Search_gamato(url):  # 18
    control.busy()
    data = r = requests.get(url).text
    posts = client.parseDOM(data, 'div', attrs={'class': 'result-item'})
    for post in posts:
        link = client.parseDOM(post, 'a', ret='href')[0]
        poster = client.parseDOM(post, 'img', ret='src')[0].encode('utf-8', 'ignore')
        title = client.parseDOM(post, 'img', ret='alt')[0]
        title = clear_Title(title)
        try:
            year = client.parseDOM(post, 'span', attrs={'class': 'year'})[0]
            desc = client.parseDOM(post, 'div', attrs={'class': 'contenido'})[0]
            desc = re.sub('<.+?>', '', desc)
            desc = clear_Title(desc)
        except IndexError:
            year = 'N/A'
            desc = 'N/A'

        addDir('[B][COLOR white]{0} [{1}][/COLOR][/B]'.format(title, year), link, 12, poster, FANART, str(desc))

    try:
        np = client.parseDOM(data, 'a', ret='href', attrs={'class': 'arrow_pag'})[-1]
        page = np.split('/')[-1]
        title = '[B][COLOR gold]>>>' + Lang(32011) + ' [COLOR white]([COLORlime]%s[/COLOR])[/COLOR][/B]' % page
        addDir(title, np, 4, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except IndexError:
        pass
    control.idle()
#    views.selectView('menu', 'menu-view')


def gamato_kids(url):  # 4
    data = requests.get(url).text
    posts = client.parseDOM(data, 'article', attrs={'id': 'post-\d+'})
    for post in posts:
        try:
            plot = re.findall('''texto["']>(.+?)</div> <div''', post, re.DOTALL)[0]
        except IndexError:
            plot = client.parseDOM(post, 'div', attrs={'class': 'texto'})[0]
        if len(plot) < 1:
            plot = 'N/A'
        desc = client.replaceHTMLCodes(plot)
        desc = six.ensure_str(desc, encoding='utf-8')
        try:
            title = client.parseDOM(post, 'h4')[0]
            year = re.findall(r'<span>.*?\s*(\d{4})</span>', post, re.DOTALL)[0]
            if not (len(year) == 4 and year.isdigit()):
                year = 'N/A'
        except IndexError:
            title = client.parseDOM(post, 'img', ret='alt')[0]
            year = 'N/A'
        year = '[COLORlime]{}[/COLOR]'.format(year)
        title = clear_Title(title)
        link = client.parseDOM(post, 'a', ret='href')[0]
        link = clear_Title(link)
        poster = client.parseDOM(post, 'img', ret='src')[0]
        poster = clear_Title(poster)

        addDir('[B][COLOR white]{0} [{1}][/COLOR][/B]'.format(title, year), link, 12, poster, FANART, desc)
    try:
        np = client.parseDOM(data, 'a', ret='href', attrs={'class': 'arrow_pag'})[-1]
        np = clear_Title(np)
        page = np[-2] if np.endswith('/') else re.findall(r'page/(\d+)/', np)[0]
        title = '[B][COLOR lime]>>>' + Lang(32011) + ' [COLOR white]([COLOR lime]%s[/COLOR])[/COLOR][/B]' % page
        addDir(title, np, 4, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except IndexError:
        pass
#    views.selectView('menu', 'menu-view')


def gamatokids_top(url):  # 21
    data = requests.get(url).text
    posts = client.parseDOM(data, 'article', attrs={'class': 'w_item_a'})
    for post in posts:
        try:
            title = client.parseDOM(post, 'h3')[0]
            title = clear_Title(title)
            link = client.parseDOM(post, 'a', ret='href')[0]
            poster = client.parseDOM(post, 'img', ret='src')[0]
            year = client.parseDOM(post, 'span', attrs={'class': 'wdate'})[0]

            addDir('[B][COLOR white]{0} [{1}][/COLOR][/B]'.format(title, year), link, 12, poster, FANART,
                   'Προτεινόμενα')
        except IndexError:
            pass
#    views.selectView('menu', 'menu-view')


def gamato_links(url, name, poster):  # 12
    # try:
        url = quote(url, ':/.')
        # xbmc.log('URLLLL2: {}'.format(url))

        data = six.ensure_text(client.request(url))
        # xbmc.log('DATA: {}'.format(str(data)))
        try:
            desc = client.parseDOM(data, 'div', attrs={'itemprop': 'description'})[0]
            desc = clear_Title(desc)
        except IndexError:
            desc = 'N/A'

        # try:
        #     # Playerjs({id:"playerjs14892",file:"https://gamato1.com/s/Aladdin%20and%20the%20King%20of%20Thieves%201996.mp4"})
        #     link = re.findall(r'''Playerjs\(\{.+?file\s*:\s*['"](.+?\.mp4)['"]\}''', data, re.DOTALL)[0]
        #     link = quote(link, ':/.')
        #     # link += '|User-Agent={}&Referer={}'.format(quote(client.agent()), quote(url))
        #     xbmc.log('FRAME1: {}'.format(str(link)))
        # except IndexError:
        # try:
        try:
            match = re.findall(r'''file\s*:\s*['"](.+?)['"],poster\s*:\s*['"](.+?)['"]\}''', data, re.DOTALL)[0]
            link, _poster = match[0], match[1]
        except IndexError:
            # 'http://gamatotv2.com/kids/jwplayer/?source=http%3A%2F%2F161.97.109.217%2FSonic%2520%2520%2520-%2520Gamato%2520%2520.mp4&id=16449&type=mp4
            link = re.findall(r'''/jwplayer/\?source=(.+?)&id=''', data, re.DOTALL)[0]

        # xbmc.log('FRAME2: {}'.format(str(link)))
        # except IndexError:
        #     frame = client.parseDOM(data, 'div', attrs={'id': r'option-\d+'})[0]
        #     frame = client.parseDOM(frame, 'iframe', ret='src')[0]
        #     xbmc.log('FRAME3: {}'.format(str(frame)))
        #
        #     if 'cloud' in frame:
        #         # sources: ["http://cloudb.me/4fogdt6l4qprgjzd2j6hymoifdsky3tfskthk76ewqbtgq4aml3ior7bdjda/v.mp4"],
        #         match = client.request(frame, referer=url)
        #         # xbmc.log('MATCH3: {}'.format(match))
        #         if 'meta name="robots"' in match:
        #             cloudid = frame.split('html?')[-1].split('=')[0]
        #             cloud = 'http://cloudb2.me/embed-{}.html?auto=1&referer={}'.format(cloudid, url)
        #             match = client.request(cloud)
        #         try:
        #             from resources.lib.modules import jsunpack
        #             if jsunpack.detect(match):
        #                 match = jsunpack.unpack(match)
        #             match = re.findall(r'sources:\s*\[[\'"](.+?)[\'"]\]', match, re.DOTALL)[0]
        #             # match += '|User-Agent=%s&Referer=%s' % (quote(client.agent()), frame)
        #         except IndexError:
        #             from resources.lib.modules import jsunpack as jsun
        #             if jsun.detect(match):
        #                 match = jsun.unpack(match)
        #                 match = re.findall(r'sources:\s*\[[\'"](.+?)[\'"]\]', match, re.DOTALL)[0]
        #                 # match += '|User-Agent=%s&Referer=%s' % (quote(client.agent()), frame)
        #     else:
        #         match = frame
        #     link, _poster = match, poster
        link = unquote_plus(link)
        # xbmc.log('Finally LINK: {}'.format(link))
        try:
            fanart = client.parseDOM(data, 'div', attrs={'class': 'g-item'})[0]
            fanart = client.parseDOM(fanart, 'a', ret='href')[0]
        except IndexError:
            fanart = FANART
        try:
            trailer = client.parseDOM(data, 'iframe', ret='src')
            trailer = [i for i in trailer if 'youtube' in i][0]
            addDir('[B][COLOR lime]Τρέιλερ[/COLOR][/B]', trailer, 100, iconimage, fanart, str(desc))
        except IndexError:
            pass

        addDir(name, link, 100, poster, fanart, str(desc))
    # except BaseException:
    #     return
#    views.selectView('menu', 'menu-view')


def get_links(name, url, iconimage, description):
    hdrs = {'Referer': GAMATO,
            'User-Agent': client.agent()}
    data = requests.get(url, headers=hdrs).text

    if 'Trailer' in data:
        try:
            flink = client.parseDOM(data, 'iframe', ret='src', attrs={'class': 'rptss'})[0]
        except IndexError:
            try:
                # http://gamatotv.info/wp-json/dooplayer/v1/post/45755?type=movie&source=trailer
                ylink = ' http://gamatotv.info/wp-json/dooplayer/v1/post/{}?type=movie&source=trailer'
                #li id='player-option-trailer'
                yid = client.parseDOM(data, 'li', ret='data-post', attrs={'id': 'player-option-trailer'})[0]
                flink = ylink.format(yid)
                flink = client.request(flink)
                flink = json.loads(flink)['embed_url']
            except IndexError:
                flink = ''

        if 'youtu' in flink:
            addDir('[B][COLOR lime]Τρέιλερ[/COLOR][/B]', flink, 100, iconimage, FANART, '')
        else:
            addDir('[B][COLOR orange]Δεν υπάρχει διαθέσιμο Τρέιλερ[/COLOR][/B]', '', 100, iconimage, FANART, '')

    else:
        addDir('[B][COLOR orange]Δεν υπάρχει διαθέσιμο Τρέιλερ[/COLOR][/B]', '', 100, iconimage, FANART, '')

    try:
        if 'tvshows' not in url:
            try:
                try:
                    frame = client.parseDOM(data, 'iframe', ret='src', attrs={'class': 'metaframe rptss'})[0]
                except IndexError:
                    get_vid = 'http://gamatotv.info/wp-json/dooplayer/v1/post/{}?type=movie&source=1'
                    id = client.parseDOM(data, 'li', ret='data-post', attrs={'id': 'player-option-1'})[0]
                    frame = client.request(get_vid.format(id))
                    frame = json.loads(frame)['embed_url']
                if 'coverapi' in frame:
                    html = requests.get(frame).text
                    post_url = 'https://coverapi.store/engine/ajax/controller.php'
                    postdata = re.findall(r'''data: \{mod: 'players', news_id: '(\d+)'\},''', html, re.DOTALL)[0]
                    # xbmc.log('POSR-DATA: {}'.format(str(postdata)))
                    postdata = {'mod': 'players',
                                'news_id': postdata}
                    hdrs = {'Origin': 'https://coverapi.store',
                            'Referer': frame,
                            'User-Agent': client.agent()}
                    post_html = requests.post(post_url, data=postdata, headers=hdrs).text.replace('\\', '')
                    # xbmc.log('POSR-HTML: {}'.format(str(post_html)))
                    frame = re.findall(r'''file:\s*['"](http.+?)['"]''', post_html, re.DOTALL)[0]
                    title = '{} | [B]{}[/B]'.format(name, 'Gamato')
                    addDir(title, frame, 100, iconimage, FANART, str(description))
                elif '/jwplayer/?source' in frame:
                    frame = re.findall(r'''/jwplayer/\?source=(.+?)&id=''', frame, re.DOTALL)[0]
                    # xbmc.log('FRAME-JWPLAYER: {}'.format(str(frame)))
                    # frame = unquote_plus(frame)
                    title = '{} | [B]{}[/B]'.format(name, 'Gamato')
                    addDir(title, frame, 100, iconimage, FANART, str(description))
                else:
                    host = GetDomain(frame)
                    title = '{} | [B]{}[/B]'.format(name, host.capitalize())
                    addDir(title, frame, 100, iconimage, FANART, str(description))
            except IndexError:
                pass
            try:
                frames = client.parseDOM(data, 'tr', {'id': r'link-\d+'})
                frames = [(client.parseDOM(i, 'a', ret='href', attrs={'target': '_blank'})[0],
                           client.parseDOM(i, 'img', ret='src')[0],
                           client.parseDOM(i, 'strong', {'class': 'quality'})[0]) for i in frames if frames]
                for frame, domain, quality in frames:
                    host = domain.split('=')[-1]
                    host = six.ensure_str(host, 'utf-8')
                    # if 'Μεταγλωτισμένο' in info.encode('utf-8', 'ignore'):
                    #     info = '[Μετ]'
                    # elif 'Ελληνικοί' in info.encode('utf-8', 'ignore'):
                    #     info = '[Υπο]'
                    # elif 'Χωρίς' in info.encode('utf-8', 'ignore'):
                    #     info = '[Χωρίς Υπ]'
                    # else:
                    #     info = '[N/A]'
                    quality = 'SD'
                    title = '{} | [B]{}[/B] | ({})'.format(name, host.capitalize(), quality)
                    addDir(title, frame, 100, iconimage, FANART, str(description))
            except BaseException:
                pass
        else:
            get_links2(name, url, iconimage, description)
           # data = client.parseDOM(data, 'table', attrs={'class': 'easySpoilerTable'})
           # seasons = [dom.parse_dom(i, 'a', {'target': '_blank'}, req='href') for i in str(data)[:-1] if i]
           # episodes = []
           # for season in seasons:
           #     for epi in season:
           #         title = clear_Title(epi.content.replace('&#215;', 'x'))
           #         frame = epi.attrs['href']
           #         episodes.append((title, frame))

           # for title, frame in episodes:
           #     addDir(title, frame, 100, iconimage, FANART, str(description))

    except BaseException:
        title = '[B][COLOR white]Δεν υπάρχει διαθέσιμο link[/COLOR][/B]'
        addDir(title, '', 'bug', iconimage, FANART, str(description))
#    views.selectView('menu', 'menu-view')


def get_links2(name, url, iconimage, description): #120
    p = client.request(url)
    m = re.compile('a href="(.+?)"').findall(p)
    link_list = ['streamzz', 'voe', 'aparat', 'flashx', 'hdvid', 'vidd','vidoza', 'vidlox', 'estream', 'clipwatching', 'thevideo', 'vidzi']
    for url in m:
        if any(x in url for x in link_list):
            name = url
            name = name.split('.')[0]
            name = name.replace('http://', ' [B]Πάροχος...[/B]')
            name = name.replace('https://', ' [B]Πάροχος...[/B]')
            if 'gamato' in name:
                continue
            addDir(name, url, 100, iconimage, FANART, str(description))

########################################

def find_single_match(data, patron, index=0):
    try:
        matches = re.findall(patron, data, flags=re.DOTALL)
        return matches[index]
    except IndexError:
        return ""


def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    return txt


def Open_settings():
    control.openSettings()


def cache_clear():
    cache.clear(withyes=False)


def search_clear():
    cache.delete(control.searchFile, withyes=False)
    control.refresh()
    control.idle()


def resolve(name, url, iconimage, description):
    liz = xbmcgui.ListItem(name)
    host = url
    if '/links/' in host:
        try:
            frame = client.request(host)
            host = client.parseDOM(frame, 'a', {'id': 'link'}, ret='href')[0]

        except BaseException:
            host = requests.get(host, allow_redirects=False).headers['Location']
    else:
        host = host

    # try resolveurl first:
    stream_url = evaluate(host)
    if not stream_url:
        if host.split('|')[0].endswith('.mp4') and 'clou' in host:
            stream_url = host + '|User-Agent=%s&Referer=%s' % (quote_plus(client.agent(), ':/'), GAMATO)
            name = name
        elif host.endswith('.mp4') and 'vidce.net' in host:
            stream_url = host + '|User-Agent={}'.format(quote_plus(client.agent()))
        elif host.endswith('.mp4'):
            stream_url = host + '|User-Agent=%s&Referer=%s' % (quote_plus(client.agent(), ':/'), GAMATO)
        # stream_url = requests.get(host, headers=hdr).url
        elif '/aparat.' in host:
            try:
                from resources.lib.resolvers import aparat
                stream_url = aparat.get_video(host)
                stream_url, sub = stream_url.split('|')
                liz.setSubtitles([sub])
            except BaseException:
                stream_url = evaluate(host)
        # elif '/clipwatching.' in host:
        #     xbmc.log('HOST: {}'.format(host))
        #     # try:
        #     data = requests.get(host).text
        #     xbmc.log('DATA: {}'.format(data))
        #     try:
        #         sub = client.parseDOM(data, 'track', ret='src', attrs={'label': 'Greek'})[0]
        #         xbmc.log('SUBS: {}'.format(sub))
        #         liz.setSubtitles([sub])
        #     except IndexError:
        #         pass
        #
        #     stream_url = re.findall(r'''sources:\s*\[\{src:\s*['"](.+?)['"]\,''', data, re.DOTALL)[0]
        #     xbmc.log('HOST111: {}'.format(stream_url))
        #
        #
        #     # except BaseException:
        #     #     stream_url = evaluate(stream_url)
        elif 'coverapi' in host:
            html = requests.get(host).text
            # xbmc.log('ΠΟΣΤ_html: {}'.format(html))
            postdata = re.findall(r'''['"]players['"], news_id: ['"](\d+)['"]}''', html, re.DOTALL)[0]
            # xbmc.log('ΠΟΣΤ_html: {}'.format(postdata))
            postdata = {'mod': 'players',
                        'news_id': str(postdata)}
            post_url = 'https://coverapi.store/engine/ajax/controller.php'
            post_html = requests.post(post_url, data=postdata).text.replace('\\', '')
            # xbmc.log('ΠΟΣΤ_ΔΑΤΑ: {}'.format(post_html))
            stream_url = re.findall(r'''file\s*:\s*['"](.+?)['"]''', post_html, re.DOTALL)[0]
            # xbmc.log('ΠΟΣΤ_URL: {}'.format(stream_url))
            if 'http' in stream_url:
                stream_url = stream_url + '|User-Agent=iPad&Referer={}&verifypeer=false'.format('https://coverapi.store/')
            else:
                playlist_url = 'https://coverapi.store/' + stream_url
                data = requests.get(playlist_url).json()
                # xbmc.log('ΠΟΣΤ_ΔΑΤΑ: {}'.format(data))
                comments = []
                streams = []

                data = data['playlist']
                for dat in data:
                    url = dat['file']
                    com = dat['comment']
                    comments.append(com)
                    streams.append(url)

                if len(comments) > 1:
                    dialog = xbmcgui.Dialog()
                    ret = dialog.select('[COLORgold][B]ΔΙΑΛΕΞΕ ΠΗΓΗ[/B][/COLOR]', comments)
                    if ret == -1:
                        return
                    elif ret > -1:
                        host = streams[ret]
                        # xbmc.log('@#@HDPRO:{}'.format(host))User-Agent=iPad&verifypeer=false
                        stream_url = host + '|User-Agent=iPad&Referer={}&verifypeer=false'.format('https://coverapi.store/')
                    else:
                        return

                else:
                    host = streams[0]
                    stream_url = host + '|User-Agent=iPad&Referer={}&verifypeer=false'.format('https://coverapi.store/')

    else:
        name = name.split(' [B]|')[0]
    try:
        liz.setArt({'icon': iconimage, 'fanart': FANART})
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
        liz.setProperty("IsPlayable", "true")
        liz.setPath(str(stream_url))
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except BaseException:
        control.infoDialog(Lang(32012), NAME)


def evaluate(host):
    import resolveurl
    try:
        url = None
        if 'openload' in host:
            try:
                from resources.lib.resolvers import openload
                oplink = openload.get_video_openload(host)
                url = resolveurl.resolve(oplink) if oplink == '' else oplink
            except BaseException:
                url = resolveurl.resolve(host)

        elif resolveurl.HostedMediaFile(host):
            url = resolveurl.resolve(host)

        return url
    except BaseException:
        return


def GetDomain(url):
    elements = urlparse(url)
    domain = elements.netloc or elements.path
    domain = domain.split('@')[-1].split(':')[0]
    regex = r"(?:www\.)?([\w\-]*\.[\w\-]{2,3}(?:\.[\w\-]{2,3})?)$"
    res = re.search(regex, domain)
    if res:
        domain = res.group(1)
    domain = domain.lower()
    return domain


#name = p.get_name()
#url = p.get_url()
#mode = p.get_mode()
icon = p.get_icon()
#fanart = p.get_fanart()
#description = p.get_description()


params = init.params
mode = params.get('mode')
name = params.get('name')
iconimage = params.get('iconimage')
fanart = params.get('fanart')
description = params.get('description')
url = params.get('url')

try:
    url = unquote_plus(params["url"])
except BaseException:
    pass
try:
    name = unquote_plus(params["name"])
except BaseException:
    pass
try:
    iconimage = unquote_plus(params["iconimage"])
except BaseException:
    pass
try:
    mode = int(params["mode"])
except BaseException:
    pass
try:
    fanart = unquote_plus(params["fanart"])
except BaseException:
    pass
try:
    description = unquote_plus(params["description"])
except BaseException:
    pass

xbmc.log('{}: {}'.format(str(ID), str(VERSION)))
xbmc.log('{}: {}'.format('Mode', str(mode)))
xbmc.log('{}: {}'.format('URL', str(url)))
xbmc.log('{}: {}'.format('Name', str(name)))
xbmc.log('{}: {}'.format('ICON', str(iconimage)))


#################################################


if mode is None:
    Main_addDir()


###############GAMATOKIDS#################
#elif mode == 3:
#    get_gam_genres(url)

elif mode == 4:
    gamato_kids(url)
   
elif mode == 12:
    get_links(name, url, iconimage, description)
    # gamato_links(url, name, iconimage)

elif mode == 120:
    get_links2(name, url, iconimage, description)
    # gamato_links

elif mode == 18:
    keyb = xbmc.Keyboard('', Lang(32002))
    keyb.doModal()
    if keyb.isConfirmed():
        search = quote_plus(keyb.getText())
        url = GAMATO + "?s={}".format(search)
        Search_gamato(url)
    else:
        pass

elif mode == 20:
    gamato_menu()

elif mode == 21:
    gamatokids_top(url)

elif mode == 22:
    from resources.lib.indexers import Gamato_year
    Gamato_year.gamato_year()

elif mode == 23:
    from resources.lib.indexers import Gamato_genre
    Gamato_genre.gamato_genre()

###############################################
elif mode == 5:
    Get_content(url)

elif mode == 6:
    search_menu()

elif mode == 7:
    Get_TV_Genres(url)

elif mode == 8:
    Get_random(url)

elif mode == 9:
    cache_clear()

#elif mode == 13:
#    Peliculas()

elif mode == 14:
    Series()

elif mode == 15:
    year(url)

elif mode == 16:
    year_TV(url)

elif mode == 17:
    Open_settings()

elif mode == 19:
    Get_epoxiakes(url)

elif mode == 26:
    Search(url)

elif mode == 28:
    Del_search(url)

elif mode == 29:
    search_clear()

###############METAGLOTISMENO#################

elif mode == 30:
    from resources.lib.indexers import teniesonline
    teniesonline.menu()

elif mode == 33:
    from resources.lib.indexers import teniesonline
    teniesonline.get_links(name, url, iconimage, description)

elif mode == 34:
    from resources.lib.indexers import teniesonline
    teniesonline.metaglotismeno(url)

elif mode == 35:
    from resources.lib.indexers import teniesonline

    keyb = xbmc.Keyboard('', Lang(32002))
    keyb.doModal()
    if keyb.isConfirmed():
        search = quote_plus(keyb.getText())
        url = Teniesonline + "?s={}".format(search)
        teniesonline.search(url)
    else:
        pass

elif mode == 36:
    from resources.lib.indexers import TainiesOnline_year
    TainiesOnline_year.tainiesonline_year()
    
elif mode == 37:
    from resources.lib.indexers import TainiesOnline_genre
    TainiesOnline_genre.tainiesonline_genre()

##############################################

elif mode == 40:
    downloads_root()

elif mode == 41:
    download(name, iconimage, url)

#######################XRYSOI#################

elif mode == 42:
    from resources.lib.indexers import xrysoi
    xrysoi.menu()

elif mode == 43:
    from resources.lib.indexers import xrysoi
    xrysoi.get_links(name, url, iconimage, description)

elif mode == 44:
    from resources.lib.indexers import xrysoi
    xrysoi.xrysoimovies(url)

elif mode == 45:
    from resources.lib.indexers import xrysoi
    xrysoi.search(url)

elif mode == 46:
    from resources.lib.indexers import Xrysoi_year
    Xrysoi_year.xrysoi_year()

elif mode == 47:
    from resources.lib.indexers import Xrysoi_genre
    Xrysoi_genre.xrysoi_genre()

elif mode == 48:
    from resources.lib.indexers import xrysoi
    xrysoi.get_hdvids(url)

elif mode == 49:
    from resources.lib.indexers import xrysoi
    xrysoi.xrysoiseries(url)

elif mode == 50:
    from resources.lib.indexers import xrysoi
    search_series()

elif mode == 51:
    from resources.lib.indexers import xrysoi
    xrysoi.menu_genre()

elif mode == 52:
    from resources.lib.indexers import xrysoi
    xrysoi.menu_year()

elif mode == 53:
    from resources.lib.indexers import xrysoi
    xrysoi.xrysoimovies_search(url)

####################YOUTUBE###################

elif mode==56:
    MainYoutube(url)

elif mode==3:
    play_video(name, url, icon)

elif mode==58:
    yt_channel(url)

elif mode==59:
    yt_playlist(url)

elif mode==60:
    MainYoutube(yt_xml)

elif mode==61:
    MainYoutube(yt1_xml)

elif mode==62:
    MainYoutube(yt2_xml)

elif mode==63:
    MainYoutube(yt3_xml)

###################################################

elif mode==80:
    kids_menu()

elif mode==81:
    documentary_menu()

#################################################

elif mode==419:
    from resources.lib.indexers import hermes

    hermes.hermes(url)
elif mode==420:
    from resources.lib.indexers import hermes

    hermes.hermesM(url)

###################OLDSERIES#####################

elif mode == 90000:
    from resources.lib.indexers import old
    old.menu_Old_series()

elif mode == 90001:
    from resources.lib.indexers import old
    old.mi(url)

elif mode == 90002:
    from resources.lib.indexers import old
    old.mi1(url)

elif mode == 90003:
    from resources.lib.indexers import old
    old.season_mi(url)

##############################################

elif mode == 100:
    resolve(name, url, iconimage, description)

##############################################

#xbmcplugin.endOfDirectory(int(sys.argv[1]))





xbmcplugin.endOfDirectory(handle)