﻿import xbmc, xbmcgui

def searchsubsettings():
    xbmc.executebuiltin("ActivateWindowAndFocus(OSDSubtitleSettings)")
    xbmc.executebuiltin("Action(Pause)")
    xbmcgui.Dialog().notification("[B][COLOR orange]Keep calm and just wait[/COLOR][/B]", "[COLOR green]Περιμένετε...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/Pleasewait.png')
    xbmc.sleep(500)
    xbmc.executebuiltin('SendClick(-177)')
    while xbmc.getCondVisibility("Window.IsVisible(OSDSubtitleSettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")

searchsubsettings()
