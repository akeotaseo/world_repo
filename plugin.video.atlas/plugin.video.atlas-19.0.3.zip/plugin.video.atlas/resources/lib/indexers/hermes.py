# -*- coding: utf-8 -*-

import xbmcplugin
import xbmcgui
import re
import sys
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir

ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"

def hermesM(url):
    addDir('LiveGreekTV', 'plugin://plugin.video.youtube/?action=play_video&videoid=p24B790GNMI', 'https://is3-ssl.mzstatic.com/image/thumb/Purple127/v4/e0/7e/fe/e07efe97-54b8-5004-eb75-fbe7905741ce/source/256x256bb.jpg')
    addDir('WorldIptv', 'https://raw.githubusercontent.com/HermesGR/WorldIptv/master/README.m3u', 'https://is3-ssl.mzstatic.com/image/thumb/Purple127/v4/e0/7e/fe/e07efe97-54b8-5004-eb75-fbe7905741ce/source/256x256bb.jpg')
    addDir('Greek Kids', 'https://raw.githubusercontent.com/HermesGR/Hermes-Kids-Videos/master/kids.m3u', 'https://static-s.aa-cdn.net/img/gp/20600001285232/Su-mF-6fkMDYu_8jbxPBltkAYqxuVO-QCpnzdqa1QNizoMbdtNOQS48ykotV3U1uh9E=w300')
    addDir('Greek History Documentaries', 'https://raw.githubusercontent.com/HermesGR/Hermes-Documentaries-Istorika/master/Documentaries%20Istorika.m3u', 'https://www.shareicon.net/download/2017/06/22/887549_video.ico')
    addDir('Greek Religious Documentaries', 'https://raw.githubusercontent.com/HermesGR/Hermes-Documentaries-Thriskeutika/master/Documentaries%20Thriskeutika.m3u', 'https://www.shareicon.net/download/2017/06/22/887549_video.ico')
    addDir('Greek Scientific Documentaries', 'https://raw.githubusercontent.com/HermesGR/Hermes-Documentaries-Epistimonika/master/Documentaries%20Epistimonika.m3u', 'https://www.shareicon.net/download/2017/06/22/887549_video.ico')
    addDir('Greek Various Documentaries', 'https://raw.githubusercontent.com/HermesGR/Hermes-Documentaries-Diafora/master/Documentaries%20Diafora.m3u', 'https://www.shareicon.net/download/2017/06/22/887549_video.ico')
    addDir('Karaoke', 'https://raw.githubusercontent.com/HermesGR/Karaoke/master/README.m3u', 'http://www.iconarchive.com/download/i60740/double-j-design/origami-colored-pencil/yellow-music.ico')
    addDir('Greek Concerts', 'https://raw.githubusercontent.com/HermesGR/Hermes-Synaulies/master/Greek%20Synaulies.m3u', 'http://www.iconarchive.com/download/i60740/double-j-design/origami-colored-pencil/yellow-music.ico')
    addDir('Greek Music Collections', 'https://raw.githubusercontent.com/HermesGR/Greek-Music-Collection/master/Greek%20Music%20Collection.m3u', 'http://www.iconarchive.com/download/i60740/double-j-design/origami-colored-pencil/yellow-music.ico')
    addDir('Greek Funny Moments', 'https://raw.githubusercontent.com/HermesGR/Hermes-Fun/master/Greek%20Fun.m3u', 'http://cdn.warer.com/media/hidden_emoticon_yahoo-logo.png')
    addDir('Greek Theater', 'https://raw.githubusercontent.com/HermesGR/Hermes-Epithewrisi/master/Greek%20Theater.m3u', 'https://pbs.twimg.com/profile_images/848319608062828544/A50dsvWj_400x400.jpg')
    addDir('Greek Sports Events - Full Matches', 'https://raw.githubusercontent.com/HermesGR/Hermes-Best-Greek-Moments/master/GreekMoments.m3u', 'https://is1-ssl.mzstatic.com/image/thumb/Purple60/v4/92/ae/e4/92aee442-6b32-0850-4f47-8c4f01792b29/source/256x256bb.jpg')
    addDir('Donation', 'https://raw.githubusercontent.com/HermesGR/Donation/master/README.m3u', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRBUHgNiWy--QLFIBfjiQ4FBuI1ZirVYuUVvZazlOPwi36_TiJdOQ')



def hermes(url):
    p = client.request(url)
    m = re.compile('#.+,(.+?)\n(.+?)\n').findall(p)
    for name, url in m:
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 250, icon, FANART, '')
        #openn.addLink('[B][COLOR white]%s[/COLOR][/B]'%name,url,'',addon.icon,addon.art,'')

        # if '.ts' in url:
        #     stype = 'TSDOWNLOADER'
        # elif '.m3u' in url:

    # addLink('LiveGreekTV','https://raw.githubusercontent.com/HermesGR/LiveGreekTV/master/README.m3u','https://is3-ssl.mzstatic.com/image/thumb/Purple127/v4/e0/7e/fe/e07efe97-54b8-5004-eb75-fbe7905741ce/source/256x256bb.jpg')
    # addLink('WorldIptv','https://raw.githubusercontent.com/HermesGR/WorldIptv/master/README.m3u','https://is3-ssl.mzstatic.com/image/thumb/Purple127/v4/e0/7e/fe/e07efe97-54b8-5004-eb75-fbe7905741ce/source/256x256bb.jpg')
    # addLink('Greek Kids','https://raw.githubusercontent.com/HermesGR/Hermes-Kids-Videos/master/kids.m3u','https://static-s.aa-cdn.net/img/gp/20600001285232/Su-mF-6fkMDYu_8jbxPBltkAYqxuVO-QCpnzdqa1QNizoMbdtNOQS48ykotV3U1uh9E=w300')
    # addLink('Greek History Documentaries','https://raw.githubusercontent.com/HermesGR/Hermes-Documentaries-Istorika/master/Documentaries%20Istorika.m3u','https://www.shareicon.net/download/2017/06/22/887549_video.ico')
    # addLink('Greek Religious Documentaries','https://raw.githubusercontent.com/HermesGR/Hermes-Documentaries-Thriskeutika/master/Documentaries%20Thriskeutika.m3u','https://www.shareicon.net/download/2017/06/22/887549_video.ico')
    # addLink('Greek Scientific Documentaries','https://raw.githubusercontent.com/HermesGR/Hermes-Documentaries-Epistimonika/master/Documentaries%20Epistimonika.m3u','https://www.shareicon.net/download/2017/06/22/887549_video.ico')
    # addLink('Greek Various Documentaries','https://raw.githubusercontent.com/HermesGR/Hermes-Documentaries-Diafora/master/Documentaries%20Diafora.m3u','https://www.shareicon.net/download/2017/06/22/887549_video.ico')
    # addLink('Karaoke','https://raw.githubusercontent.com/HermesGR/Karaoke/master/README.m3u','http://www.iconarchive.com/download/i60740/double-j-design/origami-colored-pencil/yellow-music.ico')
    # addLink('Greek Concerts','https://raw.githubusercontent.com/HermesGR/Hermes-Synaulies/master/Greek%20Synaulies.m3u','http://www.iconarchive.com/download/i60740/double-j-design/origami-colored-pencil/yellow-music.ico')
    # addLink('Greek Music Collections','https://raw.githubusercontent.com/HermesGR/Greek-Music-Collection/master/Greek%20Music%20Collection.m3u','http://www.iconarchive.com/download/i60740/double-j-design/origami-colored-pencil/yellow-music.ico')
    # addLink('Greek Funny Moments','https://raw.githubusercontent.com/HermesGR/Hermes-Fun/master/Greek%20Fun.m3u','http://cdn.warer.com/media/hidden_emoticon_yahoo-logo.png')
    # addLink('Greek Theater','https://raw.githubusercontent.com/HermesGR/Hermes-Epithewrisi/master/Greek%20Theater.m3u','https://pbs.twimg.com/profile_images/848319608062828544/A50dsvWj_400x400.jpg')
    # addLink('Greek Sports Events - Full Matches','https://raw.githubusercontent.com/HermesGR/Hermes-Best-Greek-Moments/master/GreekMoments.m3u','https://is1-ssl.mzstatic.com/image/thumb/Purple60/v4/92/ae/e4/92aee442-6b32-0850-4f47-8c4f01792b29/source/256x256bb.jpg')
    # addLink('Donation','https://raw.githubusercontent.com/HermesGR/Donation/master/README.m3u','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRBUHgNiWy--QLFIBfjiQ4FBuI1ZirVYuUVvZazlOPwi36_TiJdOQ')

# def function(url):
#     p = openn.Open_Url('https://raw.githubusercontent.com/HermesGR/LiveGreekTV/master/README.m3u')
#     m = re.compile('href="(.+?)"').findall(p)
#     for name,url in m:
#         addLink('[B][COLOR white]%s[/COLOR][/B]'%name,url,'',icon,'','')


# EXTINF:-1,.+?(.+?)\n(.+?)\n
def addLink(name, url, iconimage):
    ok = True
    liz = xbmcgui.ListItem(name, icon, FANART)
    liz.setInfo(type="Video", infoLabels={"Title": name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=liz)
    return ok
