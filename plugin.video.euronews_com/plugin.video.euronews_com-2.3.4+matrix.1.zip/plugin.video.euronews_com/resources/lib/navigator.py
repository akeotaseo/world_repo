﻿# -*- coding: utf-8 -*-

from .common import *


def mainMenu():
	debug_MS("(navigator.mainMenu) -------------------------------------------------- START = mainMenu --------------------------------------------------")
	addDir({'mode': 'listTimeline', 'link': f"{BASE_DROID}/pages/timeline"}, create_entries({'Title': translation(30607), 'Genre': 'Breaking News'}))
	UNWANTED, (COMBI_SINGLE, COMBI_FIRST) = ['livingit', 'joboffers', '/paidpost', 'partner', 'service', '/tag', '/video'], ([] for _ in range(2))
	RESULTS = getContent(f"{BASE_URL}/video", queries='TEXT', TYPE='text/html; charset=utf-8', ORG=BASE_URL, REF=f"{BASE_URL}/")
	CONTENT = fr"\{RESULTS}"
	DATA_ONE = re.findall(r'''<div id=["']adb-header-mainnav-3-sidebar["'](.*?)<span class=["']c-navigation-bar__link["']>''', CONTENT, re.S)
	for chtml in DATA_ONE:
		part = chtml.split('class="c-navigation-bar__linkandchevron"')
		for i in range(1 ,len(part), 1):
			entry = part[i] # <a class="c-navigation-bar__link" href="/my-europe" aria-label="Read more about Europa">Europa</a>
			ARTICLES = re.compile(r'''class=["']c-navigation-bar__link["'] href=["']([^"']*)["'] aria-label=[^>]*>(.*?)</a>''', re.S).findall(entry)
			for LINK, NAME in ARTICLES:
				NAME = cleaning(NAME.replace('\n', ''))
				if LINK and any(rs in LINK.lower() for rs in UNWANTED): continue
				debug_MS(f"(navigator.mainMenu[1]) ##### TITLE : {NAME} || URL : {LINK} || ARTICLES_CONTENT : {entry} #####")
				debug_MS("---------------------------------------------")
				COMBI_SINGLE.append(NAME.lower())
				COMBI_FIRST.append([NAME, LINK, entry])
	if COMBI_FIRST:
		for title_one, news_one, elem in COMBI_FIRST:
			addDir({'mode': 'SubTopics', 'link': f"{elem}</ul></div>", 'extras': news_one}, create_entries({'Title': f"[B]{title_one}[/B]", 'Genre': title_one}))
	DATA_TWO = re.compile(r'''<div class=["']c-navigation-bar__linkandchevron["']>\s*<span class=["']c-navigation-bar__link["']>(.*?)</ul></div>''', re.S).findall(CONTENT)
	if DATA_TWO: # <div class="c-navigation-bar__subitem__title">Programme</div>
		SUBART = re.compile(r'''<div class=["']c-navigation-bar__subitem__title["']>([^<]*)<''', re.S).findall(DATA_TWO[0])
		title_two = cleaning(SUBART[0].replace('\n', ''))
		if title_two.lower() not in COMBI_SINGLE:
			addDir({'mode': 'SubTopics', 'link': f"{DATA_TWO[0]}</ul></div>"}, create_entries({'Title': f"[B]{title_two}[/B]", 'Genre': title_two}))
			debug_MS(f"(navigator.mainMenu[2]) ##### TITLE : {title_two} || REST_CONTENT : {DATA_TWO[0]} #####")
	addDir({'mode': 'playLIVE'}, create_entries({'Title': translation(30608), 'Image': f"{artpic}livestream.png"}), False)
	if enableADJUSTMENT:
		addDir({'mode': 'aConfigs'}, create_entries({'Title': translation(30609), 'Image': f"{artpic}settings.png"}), False)
	debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def SubTopics(COMPACT, PHRASE):
	debug_MS("(navigator.SubTopics) -------------------------------------------------- START = SubTopics --------------------------------------------------")
	debug_MS(f"(navigator.SubTopics) ### COMPACT_LIST = {COMPACT} ### PHRASE = {PHRASE} ###")
	debug_MS("---------------------------------------------")
	UNWANTED, UNIKAT = ['livingit', 'joboffers', '/paidpost', 'partner', 'service', '/tag', '/video'], set()
	DATA_ONE = re.findall(r'''<div class=["']c-navigation-bar__subitem c-links-list[^>]*>(.*?)</ul></div>''', COMPACT, re.S)
	for chtml in DATA_ONE: # START === <div class="c-navigation-bar__subitem c-links-list"> +++ ENDE === </ul></div>
		if PHRASE not in ['', 'None', None]: # HEADLINE === <div class="c-navigation-bar__subitem__title">Programme</div>
			HEADLINES = re.compile(r'''<div class=["']c-navigation-bar__subitem__title["']>([^<]*)<''', re.S).findall(chtml)
			for HEAD in HEADLINES:
				FETCH_UNO = create_entries({'Title': f"[B][COLOR lime]≡ ≡ ≡ {HEAD} ≡ ≡ ≡[/COLOR][/B]"})
				addDir({'mode': 'blankFUNC'}, FETCH_UNO, False)
				debug_MS(f"(navigator.SubTopics[1]) >>>>> MAIN_CATEGORY : {HEAD} >>>>>")
		ENTRIES = re.compile(r'''<a href=["']([^"']*)["'].*?links-list__link[^>]*>(.*?)</a>''', re.S).findall(chtml)
		for LINK, NAME in ENTRIES: # URL+CATEGORY === <a href="//de.euronews.com/my-europe/meine-europa-serie" class="c-links-list__link" aria-label="Read more about Meine Europa-Serie">Meine Europa-Serie</a>
			if LINK in UNIKAT or any(ts in LINK.lower() for ts in UNWANTED):
				continue
			UNIKAT.add(LINK)
			NAME = cleaning(NAME.replace('\n', ''))
			addDir({'mode': 'listVideos', 'link': LINK, 'extras': NAME}, create_entries({'Title': NAME, 'Genre': NAME}))
			debug_MS(f"(navigator.SubTopics[2]) ##### SUB_CATEGORY : {NAME} || URL : {LINK} #####")
	debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listVideos(TARGET, CAT):
	debug_MS("(navigator.listVideos) -------------------------------------------------- START = listVideos --------------------------------------------------")
	debug_MS(f"(navigator.listVideos) ### START_URL = {TARGET} ### CATEGORY = {CAT} ###")
	(COMBI_FIRST, COMBI_LINKS, COMBI_SECOND, SENDING), UNIKAT, counter, API_SAFE = ([] for _ in range(4)), set(), 0, False
	URL_ONE = TARGET if TARGET.startswith('http') else f"https:{TARGET}" if TARGET.startswith('//') else BASE_URL+TARGET
	QUERY_ONE = getContent(URL_ONE, queries='TEXT', TYPE='text/html; charset=utf-8', ORG=BASE_URL, REF=f"{BASE_URL}/")
	CONTENT = fr"\{QUERY_ONE}"
	MATCH = re.findall(r'data-api-url="([^"]+)"', CONTENT, re.S)
	if MATCH: # https://de.euronews.com/internal/program/state-of-the-union?before=1519998565&&extra=1&offset=0&limit=20
		API_LINK, API_SAFE = MATCH[-1] if MATCH[-1].startswith('http') else f"{BASE_URL}{MATCH[-1]}", True
	elif not MATCH and TARGET.count('/') > 0: # WELT -> No Comment (url='/nocomment'/) + Euronews Witness (url='/programme/euronews-witness') === KEINE 'data-api-url' vorhanden !
		API_LINK, API_SAFE = f"{BASE_URL}/internal/program/{TARGET.split('/')[-1]}", True # NEW-JSON-FORMAT === https://de.euronews.com/internal/program/nocomment?extra=1
	if API_SAFE:
		URL_TWO = f"{API_LINK.split('?')[0]}?before={str(int(round(datetime.utcnow().timestamp())))}&extra=1&offset=0&limit=70"
		debug_MS(f"(navigator.listVideos[1]) ### URL_TWO : {URL_TWO} ###")
		QUERY_TWO = getContent(URL_TWO, ORG=BASE_URL, REF=f"{BASE_URL}/")
		DATA_ONE = QUERY_TWO['articles'] if isinstance(QUERY_TWO, (dict, list)) and QUERY_TWO.get('articles', '') else QUERY_TWO if isinstance(QUERY_TWO, (dict, list)) else []
		for article in DATA_ONE:
			(THUMB_1, NOTE_1), (startTIMES, AIRED_1, DATE_1, TIME_1, ENVID_1, YUIDD_1) = ("" for _ in range(2)), (None for _ in range(6))
			if isinstance(article, str):
				article = DATA[article]
			article = article['data'] if article.get('data', '') else article
			if len(article) == 0: continue
			debug_MS("---------------------------------------------")
			debug_MS(f"(navigator.listVideos[2]) xxxxx ARTICLE-02 : {article} xxxxx")
			ATIDD_1 = str(article['id']).replace('article-', '').replace('header-', '').strip() if article.get('id', '') else None
			if ATIDD_1 is None or ATIDD_1 in UNIKAT:
				continue
			UNIKAT.add(ATIDD_1)
			TITLE_1 = cleaning(article['title'])
			if article.get('images', '') and article.get('images', {})[0].get('url', ''):
				THUMB_1 = re.sub(r'/{{w}}x{{h}}', '/1280x720', article['images'][0]['url'])
			if str(article.get('publishedAt')).isdecimal():
				CIPHER = datetime(1970,1,1) + timedelta(seconds=TGM(time.localtime(article['publishedAt'])))
				startTIMES = CIPHER.strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('-', '•', ':')
				DATE_1 = CIPHER.strftime('%Y-%m-%dT%H:%M') if KODI_ov20 else CIPHER.strftime('%d.%m.%Y') # 2025-07-03T12:30:00 = NEWFORMAT // 03.07.2025 = OLDFORMAT
				AIRED_1 = CIPHER.strftime('%d.%m.%Y').format('.') # FirstAired
			if startTIMES: NOTE_1 = translation(30610).format(startTIMES)
			if article.get('videos', '') and len(article['videos']) > 0:
				TIME_1 = [int(vra.get('duration', 0)) // 1000 for vra in article.get('videos', {})][-1] if 'duration' in str(article['videos']) else None
				ENVID_1 = [vur.get('url', None) for vur in article.get('videos', {})][-1] if 'url' in str(article['videos']) else None
			if article.get('externalPartners', '') and article['externalPartners'].get('youtubeId', ''):
				YUIDD_1 = article['externalPartners']['youtubeId']
			if ENVID_1 is None and YUIDD_1 is None:
				continue
			counter += 1
			COMBI_FIRST.append([int(counter), ATIDD_1, TITLE_1, THUMB_1, DATE_1, AIRED_1, NOTE_1, TIME_1, ENVID_1, YUIDD_1])
			COMBI_LINKS.append([int(counter), f"{BASE_EIRIS}{ATIDD_1}?device=androidPhone"]) # https://www.euronews.com/iris/euronews/v7.3/de/articles/2812488?device=androidPhone // NEW at 03.07.25
	if COMBI_FIRST: # https://api.euronews.com/v2/apps/androidPhoneEuronews-6.3/languages/de/pages/article?id=2812488 // OLD before
		COMBI_SECOND = listSubstances(COMBI_LINKS)
	if COMBI_FIRST and COMBI_SECOND:
		RESULTS = [ae + be for ae in COMBI_FIRST for be in COMBI_SECOND if ae[1] == be[0]] # Zusammenführung von Liste1 und Liste2 - wenn die ID überein stimmt !!!
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.listVideos[4]) XXXXX RESULTS-04 : {RESULTS} XXXXX")
		for xev in sorted(RESULTS, key=lambda cr: int(cr[0])): # 0-9 = Liste1 || 10-18 = Liste2
			debug_MS("---------------------------------------------")
			debug_MS(f"(navigator.listVideos[4]) ### Anzahl = {len(xev)} || Eintrag : {xev} ###")
			EpisID, Name, Photo1, Begins, Aired, Note_1, Time1, Enlink1, Youid1 = xev[1], xev[2], xev[3], xev[4], xev[5], xev[6], xev[7], xev[8], xev[9]
			MarkID, Photo2, Tagline, Desc1, Desc2, Genre, Time2, Enlink2, Youid2 = xev[10], xev[11], xev[12], xev[13], xev[14], xev[15], xev[16], xev[17], xev[18]
			PLOT = Note_1+Desc2 if len(Desc2) > len(Desc1) else Note_1+Desc1
			DURATION = Time2 if Time2 else Time1
			THUMB = Photo2 if Photo2 != "" else Photo1
			EURO_VID, YOU_VID = Enlink1, Youid1 if Youid1 else Youid2
			debug_MS(f"(navigator.listVideos[4]) ##### TITLE : {Name} || IDD : {EpisID} || THUMB : {THUMB} #####")
			debug_MS(f"(navigator.listVideos[4]) ##### YOUTUBE : {YOU_VID} || EURO_VIDEO : {EURO_VID} || DATE : {Begins} #####")
			FETCH_UNO = create_entries({'Title': Name, 'Tagline': Tagline, 'Plot': PLOT, 'Duration': DURATION, 'Date': Begins, \
				'Aired': Aired, 'Genre': Genre, 'Mediatype': 'movie', 'Image': THUMB, 'Reference': 'Single'})
			addDir({'mode': 'playCODE', 'IDENTiTY': EpisID}, FETCH_UNO, False)
			SENDING.append({'filtrate': EpisID, 'name': Name, 'directLINK': EURO_VID, 'youtubeID': YOU_VID})
		preserve(WORKS_FILE, SENDING)
	else:
		debug_MS(f"(navigator.listVideos) ##### NO VIDEO-LIST - NO ENTRY FOR >{CAT}< FOUND #####")
		return dialog.notification(translation(30525).format('Videos'), translation(30526).format(CAT), icon, 10000)
	debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listTimeline(TARGET):
	debug_MS("(navigator.listTimeline) ------------------------------------------------ START = listTimeline -----------------------------------------------")
	debug_MS(f"(navigator.listTimeline) ### START_URL = {TARGET} ###")
	(COMBI_FIRST, COMBI_LINKS, COMBI_SECOND, SENDING), PAGE_NUMBER, counter, NEXT_PAGE = ([] for _ in range(4)), 1, 0, None
	while PAGE_NUMBER > 0:
		DATA_ONE = getContent(TARGET, MOBI=True) if PAGE_NUMBER == 1 else getContent(NEXT_PAGE, MOBI=True)
		if DATA_ONE is not None and DATA_ONE.get('pageContent', '') and len(DATA_ONE['pageContent']) > 0:
			for item in DATA_ONE.get('pageContent', []):
				if item.get('type', '') == 'justin' and item.get('content', '') and len(item['content']) > 0:
					for article in item.get('content', []):
						(THUMB_1, NOTE_1), (startTIMES, AIRED_1, DATE_1) = ("" for _ in range(2)), (None for _ in range(3))
						debug_MS(f"(navigator.listTimeline[2]) xxxxx ARTICLE-02 : {article} xxxxx")
						counter += 1
						ATIDD_1 = str(article['id']).replace('article-', '').replace('header-', '').strip() if article.get('id', '') else None
						TITLE_1 = cleaning(article['title'])
						if article.get('image', '') and article['image'].get('url', ''):
							THUMB_1 = re.sub(r'/{{w}}x{{h}}', '/1280x720', article['image']['url'])
						if str(article.get('uts')).isdecimal():
							CIPHER = datetime(1970,1,1) + timedelta(seconds=TGM(time.localtime(article['uts'])))
							startTIMES_1 = CIPHER.strftime('%d{0}%m{0}%Y {1} %H{2}%M').format('-', '•', ':')
							DATE_1 = CIPHER.strftime('%Y-%m-%dT%H:%M') if KODI_ov20 else CIPHER.strftime('%d.%m.%Y') # 2025-07-03T12:30:00 = NEWFORMAT // 03.07.2025 = OLDFORMAT
							AIRED_1 = CIPHER.strftime('%d.%m.%Y').format('.') # FirstAired
						if startTIMES_1: NOTE_1 = translation(30610).format(startTIMES_1)
						SHOW_1 = article.get('showVideo', False)
						COMBI_FIRST.append([int(counter), ATIDD_1, TITLE_1, THUMB_1, DATE_1, AIRED_1, NOTE_1, SHOW_1])
						if article.get('link', '') and article['link'].get('url', ''): # https://api.euronews.com/v2/apps/androidPhoneEuronews-6.3/languages/de/pages/article?id=2812488 // OLD before
							COMBI_LINKS.append([int(counter), f"{BASE_EIRIS}{article['link']['url'].split('?id=')[1]}?device=androidPhone"]) # https://www.euronews.com/iris/euronews/v7.3/de/articles/2812488?device=androidPhone // NEW at 03.07.25
		if DATA_ONE.get('pagination', '') and DATA_ONE['pagination'].get('next', '') and DATA_ONE['pagination']['next'].get('url', '') and \
			DATA_ONE['pagination']['next']['url'].startswith('/pages/timeline') and any(xnu in DATA_ONE['pagination']['next']['url'] for xnu in ['slide=2', 'slide=3', 'slide=4']):
			debug_MS("---------------------------------------------")
			PAGE_NUMBER, NEXT_PAGE = PAGE_NUMBER.__add__(1), f"{BASE_DROID}{DATA_ONE['pagination']['next']['url']}"
			debug_MS(f"(navigator.listTimeline[2]) PAGES ### NOW GET NEXTPAGE : {NEXT_PAGE} ###")
			if PAGE_NUMBER > 4:
				break
		else: 
			PAGE_NUMBER = 0
			break
	if COMBI_FIRST:
		COMBI_SECOND = listSubstances(COMBI_LINKS)
	if COMBI_FIRST and COMBI_SECOND:
		RESULTS = [ae + be for ae in COMBI_FIRST for be in COMBI_SECOND if ae[1] == be[0]] # Zusammenführung von Liste1 und Liste2 - wenn die ID überein stimmt !!!
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.listTimeline[4]) XXXXX RESULTS-04 : {RESULTS} XXXXX")
		for xev in sorted(RESULTS, key=lambda cr: int(cr[0])): # 0-7 = Liste1 || 8-16 = Liste2
			debug_MS("---------------------------------------------")
			debug_MS(f"(navigator.listTimeline[4]) ### Anzahl = {len(xev)} || Eintrag : {xev} ###")
			EpisID, Name, Photo1, Begins, Aired, Note_1, Show = xev[1], xev[2], xev[3], xev[4], xev[5], xev[6], xev[7]
			MarkID, Photo2, Tagline, Desc1, Desc2, Genre, Time, Enlink, Youid = xev[8], xev[9], xev[10], xev[11], xev[12], xev[13], xev[14], xev[15], xev[16]
			PLOT = Note_1+Desc2 if len(Desc2) > len(Desc1) else Note_1+Desc1
			THUMB = Photo2 if Photo2 != "" else Photo1
			debug_MS(f"(navigator.listTimeline[4]) ##### TITLE : {Name} || IDD : {EpisID} || THUMB : {THUMB} #####")
			debug_MS(f"(navigator.listTimeline[4]) ##### YOUTUBE : {Youid} || EURO_VIDEO : {Enlink} || DATE : {Begins} #####")
			FETCH_UNO = create_entries({'Title': Name, 'Tagline': Tagline, 'Plot': PLOT, 'Duration': Time, 'Date': Begins, \
				'Aired': Aired, 'Genre': Genre, 'Mediatype': 'movie', 'Image': THUMB, 'Reference': 'Single'})
			addDir({'mode': 'playCODE', 'IDENTiTY': EpisID}, FETCH_UNO, False)
			SENDING.append({'filtrate': EpisID, 'name': Name, 'directLINK': Enlink, 'youtubeID': Youid})
		preserve(WORKS_FILE, SENDING)
	else:
		debug_MS("(navigator.listTimeline) ##### NO TIMELINE-LIST - NO ENTRY FOR >NEWS – TICKER< FOUND #####")
		return dialog.notification(translation(30525).format('Videos'), translation(30526).format('NEWS – TICKER'), icon, 10000)
	debug_MS("+++++++++++++++++++++++++++++++++++++++++++++")
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSubstances(MURLS):
	debug_MS("(navigator.listSubstances) -------------------------------------------------- START = listSubstances --------------------------------------------------")
	COMBI_DETAILS, COMBI_THIRD = ([] for _ in range(2))
	COMBI_DETAILS = getMultiData(MURLS)
	if COMBI_DETAILS:
		DATA_RIDER = json.loads(COMBI_DETAILS)
		#log("++++++++++++++++++++++++")
		#log(f"(navigator.llistSubstances[3]) XXXXX CONTENT-03 : {DATA_RIDER} XXXXX")
		for elem in DATA_RIDER:
			if elem is not None and elem.get('pageContent', '') and elem.get('pageContent', {})[0].get('content', ''):
				(THUMB_2, DESC_1, DESC_2), (TAGS_2, GENRE_2, TIME_2, ENVID_2, YTIDD_2) = ("" for _ in range(3)), (None for _ in range(5))
				debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
				debug_MS(f"(navigator.listSubstances[3]) xxxxx POSITION : {elem.get('Position', 0)} || ELEMENT-03 : {elem['pageContent'][0]['content'][0]} xxxxx")
				SHORT = elem['pageContent'][0]['content'][0]
				ATIDD_2 = str(SHORT['id']).replace('article-', '').replace('header-', '').strip() if SHORT.get('id', '') else None
				DESC_1 = cleaning(SHORT.get('summary', ''), True)
				if SHORT.get('image', '') and SHORT['image'].get('url', ''):
					THUMB_2 = re.sub(r'/{{w}}x{{h}}', '/1280x720', SHORT['image']['url']) # OLD = 861x485
				BODIES = next(filter(lambda aco: aco.get('type', '') == 'article-body' and aco.get('content', []), elem['pageContent']), None)
				if VIDEO_META is True and BODIES and BODIES.get('content', {})[0].get('text', ''):
					STYLE = re.compile(r'</style></head>.+?<h[2/3]>(.*?)</h[2/3]>', re.S).findall(BODIES['content'][0]['text'])
					TAGS_2 = cleaning(re.sub(r'\<.*?\>', ' ', STYLE[0])) if STYLE else None
					TAGS_2 = f"{TAGS_2[:125]}..." if TAGS_2 and len(TAGS_2) > 125 else TAGS_2
					STORY = re.findall(r'<p[^>]*>(.*?)</p>', BODIES['content'][0]['text'], re.S)
					TEASER = 'breakone'.join([sto for sto in STORY if sto is not None]) if STORY and len(STORY[0]) > 10 else None
					DESC_2 = cleaning(re.sub(r'(>Related\<.*?</li></ul></div|View this post.*?www.instagram.com.*?</a>breakone)', 'breakone', TEASER), True) if TEASER else "" # Delete Related Text and Instagram-Posts
				CHIPS = next(filter(lambda cps: cps.get('type', '') == 'chipslist' and cps.get('content', []), elem['pageContent']), None)
				SPECS = [cleaning(og.get('title', '')) for og in CHIPS.get('content', [])] if CHIPS else []
				if SPECS: GENRE_2 = ' / '.join(sorted(SPECS[:2]))
				if SHORT.get('video', ''):
					if elem.get('tracking', '') and elem['tracking'].get('adobe', '') and elem['tracking']['adobe'].get('customParams', ''): # Is displayed in Seconds
						TIME_2 = next((tac.get('value') for tac in elem['tracking']['adobe'].get('customParams', []) if 'videoduration' in tac.get('key', '') and str(tac.get('value')).isdecimal()), None)
					ENVID_2 = SHORT['video'].get('url', None)
					YTIDD_2 = SHORT['video'].get('id', None) if SHORT['video'].get('type', '') == 'pfp' else None # 'pfp' Type is for YOUTUBE
					if SHORT['video'].get('videoFallback', ''):
						if ENVID_2 is None: ENVID_2 = SHORT['video']['videoFallback'].get('url', None)
						if YTIDD_2 is None and SHORT['video']['videoFallback'].get('type', '') == 'pfp': YTIDD_2 = SHORT['video']['videoFallback'].get('id', None) # 'pfp' Type is for YOUTUBE
					COMBI_THIRD.append([ATIDD_2, THUMB_2, TAGS_2, DESC_1, DESC_2, GENRE_2, TIME_2, ENVID_2, YTIDD_2])
	return COMBI_THIRD

def YouGetVideo(CODE):
	END_URL, MARK = (None for _ in range(2))
	TEST_URL = getContent(f"https://www.youtube.com/oembed?format=json&url=http://www.youtube.com/watch?v={CODE}", queries='TRACK', ORG='https://www.youtube.com', REF='https://www.youtube.com/', timeout=15)
	if TEST_URL.status_code in [200, 201, 202] and re.search(r'''["']provider_url["']:["']https://www.youtube.com/["']''', TEST_URL.text):
		END_URL, MARK = f"plugin://plugin.video.youtube/play/?video_id={CODE}", 'YOUTUBE'
	return (END_URL, MARK)

def playLIVE():
	debug_MS("(navigator.playLIVE) -------------------------------------------------- START = playLIVE --------------------------------------------------")
	LIVE_URL, STREAM, EURO_SIGN, YOUT_SIGN, YOUT_CIPHER = (False for _ in range(5))
	CHECK_ONE = getContent(f"{BASE_DROID.replace('/tr', '/de')}/livestream/{SHORTS_DROID.replace('tr', 'de')}", queries='TRACK', MOBI=True)
	if CHECK_ONE.status_code in [200, 201, 202]: # Available Languages: en, gr, fr, de, it, es, pt, hu, ru, pe / Turkish in german - Arabic in English
		ORIG_ONE = re.compile(r'''["']primary["']:["']([^"']*)["']''', re.S).findall(CHECK_ONE.text)
		ORIG_TWO = re.compile(r'''["']backup["']:["']([^"']*)["']''', re.S).findall(CHECK_ONE.text)
		EURO_SIGN = ORIG_ONE[0] if ORIG_ONE else ORIG_TWO[0] if ORIG_TWO else False
		if EURO_SIGN:
			debug_MS(f"(navigator.playLIVE[1]) ***** EURONEWS-DIRECT-STREAM FOUND : {EURO_SIGN} *****")
			LIVE_URL, STREAM = EURO_SIGN, 'DIRECT'
		else: log("(navigator.playLIVE[1]) XXXXX !!! EURONEWS-DIRECT-STREAM NOT FOUND - ACTION NOT SUCCESSFUL - SKIP !!! XXXXX")
	if not EURO_SIGN: # Available Languages: en, el, fr, de, it, es, pt, hu, ru, fa / Turkish in german - Arabic in English
		CHECK_TWO = getContent(f"https://www.euronews.com/api/live/data?locale={SHORTS_DROID.replace('gr', 'el').replace('pe', 'fa').replace('tr', 'de')}", queries='TRACK', ORG=BASE_URL, REF=f"{BASE_URL}/")
		if CHECK_TWO.status_code in [200, 201, 202]: # https://www.euronews.com/api/live/data?locale=en
			NUMERALS = re.compile(r'''["']videoId["']:["']([^"']*)["']''', re.S).findall(CHECK_TWO.text)
			YOUT_SIGN = NUMERALS[0] if NUMERALS else False
			debug_MS(f"(navigator.playLIVE[2]) ***** CHECKED YOUTUBE - ID IN CONTEXT : {YOUT_SIGN} *****")
		YOUT_CIPHER = YOUT_SIGN if YOUT_SIGN else CHANNEL_LIVE if CHANNEL_LIVE != '00' else False
		if YOUT_CIPHER:
			debug_MS(f"(navigator.playLIVE[3]) ***** TESTING - REDIRECTED : https://www.youtube.com/oembed?format=json&url=http://www.youtube.com/watch?v={YOUT_CIPHER} || (Youtube-Redirect-Test) *****")
			LIVE_URL, STREAM = YouGetVideo(YOUT_CIPHER)
		else: log("(navigator.playLIVE[3]) XXXXX !!! YOUTUBE - ID NOT FOUND - ACTION NOT SUCCESSFUL - SKIP !!! XXXXX")
	if LIVE_URL and STREAM in ['DIRECT', 'YOUTUBE']:
		debug_MS(f"(navigator.playLIVE) ### LIVE_URL : {LIVE_URL} ###")
		LTM = xbmcgui.ListItem(f"{translation(30611)}  ({SHORTS_DROID.upper()})", path=LIVE_URL)
		if STREAM == 'DIRECT':
			LTM.setArt({'icon': icon, 'thumb': f"{artpic}livestream.png", 'poster': f"{artpic}livestream.png"})
			MIME = 'video/mp4' if LIVE_URL.endswith('.mp4') else 'application/vnd.apple.mpegurl'
			LTM.setMimeType(MIME)
			if xbmc.getCondVisibility('System.HasAddon(inputstream.ffmpegdirect)') and MIME == 'application/vnd.apple.mpegurl':
				IA_NAME = 'inputstream.ffmpegdirect'
				LTM.setContentLookup(False), LTM.setProperty('inputstream', IA_NAME)
				LTM.setProperty('Seekable', 'false'), LTM.setProperty('SeekEnabled', 'false')
				LTM.setProperty(f'{IA_NAME}.open_mode', 'ffmpeg')
				LTM.setProperty(f'{IA_NAME}.manifest_type', 'hls')
				LTM.setProperty(f'{IA_NAME}.is_realtime_stream', 'false')
				LTM.setProperty('http-reconnect', 'true')
		xbmc.Player().play(item=LIVE_URL, listitem=LTM)
	else:
		failing("(navigator.playLIVE) ##### PLAYBACK OF THE >LIVE STREAM< NOT POSSIBLE #####\n ########## NO STREAM ENTRY FOUND ON THE *Euronews.com* WEBSITE !!! ##########")
		return dialog.notification(translation(30521).format('LIVE'), translation(30527), icon, 10000)

def playCODE(PLID):
	debug_MS("(navigator.playCODE) -------------------------------------------------- START = playCODE --------------------------------------------------")
	debug_MS(f"(navigator.playCODE) ### EURONEWS_IDD = {PLID} ###")
	FINAL_URL, DIRECT_STREAM, YOUT_CIPHER = (False for _ in range(3))
	for xrs in preserve(WORKS_FILE):
		if xrs['filtrate'] != '00' and xrs['filtrate'] == PLID:
			CLEAR_TITLE, DIRECT_STREAM, YOUT_CIPHER = xrs['name'], xrs['directLINK'], xrs['youtubeID']
			debug_MS(f"(navigator.playCODE[1]) ### WORKFILE-Line : {xrs} ###")
	if DIRECT_STREAM or YOUT_CIPHER:
		if DIRECT_STREAM: FINAL_URL = DIRECT_STREAM
		if PREFER_TUBE is True or not DIRECT_STREAM:
			if not YOUT_CIPHER:
				debug_MS(f"(navigator.playCODE[2]) ***** SEARCH FOR YOUTUBE - ID : {BASE_URL}/embed/{PLID} || (Youtube-Video-Search) *****")
				CHECK_ONE = getContent(f"{BASE_URL}/embed/{PLID}", queries='TEXT', TYPE='text/html; charset=utf-8', ORG=BASE_URL, REF=f"{BASE_URL}/").replace('\\', '').replace("&quot;", "\"")
				NUMERALS = re.compile(r'''["']videoid["']:["']([^"']*)["'],["']youtubevideoid["']:["']([^"']*)["'],''', re.S).findall(CHECK_ONE)
				YOUT_CIPHER = NUMERALS[0][1] if NUMERALS and NUMERALS[0][0] == PLID and NUMERALS[0][1] not in ['', 'none', 'None'] else False
			if YOUT_CIPHER:
				debug_MS(f"(navigator.playCODE[3]) ***** TESTING - REDIRECTED : https://www.youtube.com/oembed?format=json&url=http://www.youtube.com/watch?v={YOUT_CIPHER} || (Youtube-Redirect-Test) *****")
				VOD_URL, STREAM = YouGetVideo(YOUT_CIPHER)
				if VOD_URL and STREAM == 'YOUTUBE':
					FINAL_URL = VOD_URL
	if FINAL_URL:
		log(f"(navigator.playCODE) YTID : {YOUT_CIPHER} || StreamURL : {FINAL_URL}")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, xbmcgui.ListItem(path=FINAL_URL))
	else:
		failing(f"(navigator.playCODE) ##### PLAYBACK OF THE VOD-STREAM: >{PLID}< NOT POSSIBLE #####\n ########## NO STREAM ENTRY FOUND ON THE *Euronews.com* WEBSITE !!! ##########")
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem(path='https://realvito-nosupport.de'))
		xbmc.PlayList(1).clear()
		return dialog.notification(translation(30521).format('STREAM'), translation(30527), icon, 10000)

def addDir(params, listitem, folder=True):
	uws = build_mass(params)
	listitem.setPath(uws)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
