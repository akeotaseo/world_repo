
ADDONS_REPOS = [('plugin.video.fmoviesto', 'repository.mbebe'),
                ('plugin.video.subsmovies', 'repository.mbebe'),
                ('plugin.video.cartoonsgr', 'repository.gkobu'),
                ('plugin.video.microjen', 'repository.gkobu'),
                ('repository.NarcacistWizard', 'repository.NarcacistWizard'),
                ('plugin.video.Rising.Tides', 'repository.Rising.Tides'),
                ('repository.newdiamond', 'repository.newdiamond'),
                ('repository.arrownegra', 'repository.arrownegra'),
                ('plugin.program.autowidget', 'repository.World'),
                ('plugin.video.vavooto', 'repository.World'),
                ('plugin.video.hdtrailers_net.reloaded', 'repository.World'),
                ('skin.19MatrixWorld', 'repository.World'),
                ('script.extendedinfo', 'repository.World')]