from conf.common import CommonResolver


class WidevineLicense4me(CommonResolver):

    def set_servers(self):
        return ['widevine.licenses4.me']

    def set_referer(self, url):
        return self.resolver.find_hostname(self.resolver.stack[-1])
