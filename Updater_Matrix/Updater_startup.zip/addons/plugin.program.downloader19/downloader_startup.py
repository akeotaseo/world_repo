﻿import os, glob, xbmc, xbmcgui, xbmcvfs, xbmcaddon, shutil
from updatervar import *
#from resources.lib.modules.delete_addons import del_dir
from resources.lib.GUIcontrol import txt_updater
from resources.lib.modules import db, addonsEnable
from resources.lib.modules.addonsEnable import enable_addons
#from resources.lib.modules.installer_addons import installAddon
from resources.lib.GUIcontrol.txt_updater import get_skinshortcutsversion

skinshortcuts_version = get_skinshortcutsversion()

Database_Addons33 = [('plugin.video.fmoviesto', 'repository.gkobu'),
                     ('plugin.video.cartoonsgr', 'repository.gkobu'),
                     ('plugin.video.shadow', 'repository.gkobu'),
                     ('plugin.video.microjen', 'repository.gkobu'),
                     ('script.gkobu.pairwith', 'repository.gkobu'),
                     ('script.module.grs', 'repository.gkobu'),
                     ('plugin.program.downloader', 'repository.gkobu'),
                     ('script.module.resolveurl', 'repository.gkobu'),
                     ('script.module.oathscrapers', 'repository.gkobu'),
                     ('plugin.video.winner', 'repository.gkobu'),
                     ('plugin.video.duffyou', 'repository.gkobu'),
                     
                     ('repository.gknwiz', 'repository.gknwiz'),
                     ('plugin.program.G.K.N.Wizard', 'repository.gknwiz'),
                     
                     ('script.theoath.artwork', 'repository.encryptic'),
                     ('plugin.video.theoath', 'repository.encryptic'),
                     ('repository.encryptic', 'repository.encryptic'),
                     
                     ('plugin.video.subsmovies', 'repository.mbebe'),
                     ('plugin.video.darmowatv', 'repository.mbebe'),
                     ('plugin.video.sportliveevents', 'repository.mbebe'),
                     
                     ('plugin.video.mlbtv2', 'repository.World'),
                     ('plugin.program.mypreferences', 'repository.World'),
                     ('plugin.program.super.favourites', 'repository.World'),
                     ('service.World.Build', 'repository.World'),
                     ('plugin.program.downloader19', 'repository.World'),
                     ('plugin.program.autowidget', 'repository.World'),
                     ('plugin.video.uiiumovies', 'repository.World'),
                     ('plugin.image.World', 'repository.World'),
                     ('plugin.video.tvone', 'repository.World'),
                     ('plugin.video.tvone11', 'repository.World'),
                     ('plugin.video.tvone111', 'repository.World'),
                     ('plugin.video.tvone1111', 'repository.World'),
                     ('plugin.video.videodevil', 'repository.World'),
                     ('plugin.video.vidembed', 'repository.World'),
                     ('plugin.video.tc', 'repository.World'),
                     ('script.tc.artwork', 'repository.World'),
                     ('script.tc.metadata', 'repository.World'),
                     ('script.module.tc', 'repository.World'),
                     ('plugin.video.parrot', 'repository.World'),
                     ('script.module.parrot', 'repository.World'),
                     ('plugin.video.dramacool', 'repository.World'),
                     ('plugin.video.hdtrailers_net.reloaded', 'repository.World'),
                     ('plugin.video.themoviedb.helper', 'repository.World'),
                     
                     ('repository.jurialmunkey', 'repository.jurialmunkey'),
                     
                     ('plugin.video.ghosttv', 'repository.tc'),
                     
                     ('plugin.video.atlas', 'repository.atlas'),
                     ('repository.atlas', 'repository.atlas'),
                     
                     ('plugin.video.thegroove360', 'repository.thegroove'),
                     ('plugin.video.amazon-test', 'repository.sandmann79-py3.plugins'),
                     ('plugin.video.jetproxy', 'repository.Magnetic'),

                     ('script.module.slproxy', 'repository.gujal'),
                     ('repository.octopus', 'repository.octopus'),
                     ('repository.gsource', 'repository.gsource'),
                     ('repository.loonaticsasylum', 'repository.loonaticsasylum'),
                     ('repository.matrix', 'repository.matrix'),
                     ('repository.newdiamond', 'repository.newdiamond'),
                     ('repository.Rising.Tides', 'repository.Rising.Tides'),
                     ('plugin.video.viacom.mtv', 'repository.kodinerds'),
                     ('script.module.jetextractors', 'repository.loop'),
                     ('vkkodi.repo', 'vkkodi.repo')]


                         ### Προσθέτεις εντός της αγκύλης τα πρόσθετα που επιθυμείς [  ] ###

addon_list = ['plugin.video.live.streamspro', 'repository.gknwiz', 'plugin.program.autowidget', 'script.trakt', 'plugin.video.jetproxy', 'plugin.video.f4mTester']


         ### Προσθέτεις εντός της αγκύλης τα πρόσθετα ή τα αρχεία που επιθυμείς να αφαιρέσεις [  ] ###

delete_addons = ['repository.test', 'plugin.video.thegroove360', 'plugin.video.themoviedb.helper', 'repository.testt']



def Updater_Matrix():
    BG.create(Dialog_U1, Dialog_U2)
    xbmc.sleep(3000)
    BG.update(5, Dialog_U1, Dialog_U6)
    xbmc.sleep(5000)
    BG.update(25, Dialog_U1, Dialog_U6)


    xbmc.sleep(7000)
    BG.update(30, Dialog_U1, 'Delete UpdaterMatrix...')
    del_dir()                                      ### delete addons ands files ###
    if os.path.exists(UpdaterMatrix_path1): xbmcvfs.delete(UpdaterMatrix_path1), xbmc.sleep(1000)
    #if os.path.exists(UpdaterMatrix_path2): xbmcvfs.delete(UpdaterMatrix_path2), xbmc.sleep(1000)
    if os.path.exists(UpdaterMatrix_path3): xbmcvfs.delete(UpdaterMatrix_path3), xbmc.sleep(1000)
    if os.path.exists(UpdaterMatrix_path4): xbmcvfs.delete(UpdaterMatrix_path4), xbmc.sleep(1000)
    #if os.path.exists(UpdaterMatrix_path5): xbmcvfs.delete(UpdaterMatrix_path5), xbmc.sleep(1000)
    #if os.path.exists(UpdaterMatrix_path6): xbmcvfs.delete(UpdaterMatrix_path6), xbmc.sleep(1000)
    #if os.path.exists(UpdaterMatrix_path7): xbmcvfs.delete(UpdaterMatrix_path7), xbmc.sleep(1000)
    #if os.path.exists(UpdaterMatrix_path8): xbmcvfs.delete(UpdaterMatrix_path8), xbmc.sleep(1000)
    #if os.path.exists(UpdaterMatrix_path9): xbmcvfs.delete(UpdaterMatrix_path9), xbmc.sleep(1000)



###########################################################################



    if not os.path.exists(UpdaterMatrix_path):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_1)
        xbmc.sleep(5000)
        BG.update(43, Dialog_U1, 'TheMovieDb Helper players')
        xbmc.sleep(10000)
        BG.update(45, Dialog_U1, Dialog_U6)


    #if not os.path.exists(UpdaterMatrix_path2):
        #xbmc.sleep(1000)
        #BG.update(46, Dialog_U1, 'Εγκατάσταση νέων repository')
        #xbmc.sleep(5000)
        #xbmc.executebuiltin(UpdaterMatrix_2)
        #xbmc.sleep(10000)
        #BG.update(48, Dialog_U1, Dialog_U6)


    #if not os.path.exists(UpdaterMatrix_path3):
        #xbmc.sleep(1000)
        #BG.update(50, Dialog_U1, 'Εγκατάσταση addon_data')
        #xbmc.sleep(5000)
        #xbmc.executebuiltin(UpdaterMatrix_3)
        #xbmc.sleep(10000)
        #BG.update(52, Dialog_U1, Dialog_U6)


    #if not os.path.exists(UpdaterMatrix_path4):
        #xbmc.sleep(1000)
        #xbmc.executebuiltin(UpdaterMatrix_4)
        #xbmc.sleep(5000)
        #BG.update(55, Dialog_U1, Dialog_U6)


 #  if not os.path.exists(UpdaterMatrix_path5):
 #      xbmc.sleep(1000)
 #      xbmc.executebuiltin(UpdaterMatrix_5)
 #      xbmc.sleep(5000)
 #      BG.update(57, Dialog_U1, 'Εισαγωγή νέων διακομιστών του PvrStalker...')


 #  if not os.path.exists(UpdaterMatrix_path6):
 #      xbmc.sleep(1000)
 #      xbmc.executebuiltin(UpdaterMatrix_6)
 #      xbmc.sleep(5000)
 #      BG.update(60, Dialog_U1, Dialog_U6)

###fix sources... Install plugin.video.thegroove360 xml 3.4.0### 
    if not os.path.exists(UpdaterMatrix_path7):
        xbmc.sleep(5000)
        BG.update(65, Dialog_U1, Dialog_U6)
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_7)


 #  if not os.path.exists(UpdaterMatrix_path8):
 #      xbmc.sleep(1000)
 #      xbmc.executebuiltin(UpdaterMatrix_8)
 #      xbmc.sleep(5000)
 #      BG.update(70 , Dialog_U1, Dialog_U6)


### Το ενεργοποιείς όταν θέλεις να περάσεις πρόσθετα ###
    xbmc.sleep(5000)
    installAddon()
    BG.update(72, Dialog_U1, 'Εγκατάσταση πρόσθετων...')
    xbmc.sleep(7000)
    BG.update(75, Dialog_U1, Dialog_U6)
###########################################################################

    xbmc.sleep(5000)
    db.addon_database(Database_Addons33, 1, True)
    xbmc.sleep(7000)
    BG.update(70, Dialog_U1, 'Εισαγωγή αποθετηρίων στο Database/Addons33...')
    

    xbmc.sleep(5000)
    addonsEnable.enable_addons()
    BG.update(75, Dialog_U1, 'Ενεργοποίηση πρόσθετων...')
    xbmc.sleep(10000)
    BG.update(80, Dialog_U1, Dialog_U6)
    
    #xbmc.sleep(5000)
    #BG.update(82, Dialog_U1, 'Install all updates')
    #RunAddon()
    xbmc.sleep(5000)
    BG.update(86, Dialog_U1, 'Ακολουθεί ενημέρωση στο μενού του skin...')
    xbmc.sleep(20000)

    if skinshortcuts_version > int(setting('skinshortcutsversion')):
        BG.update(86, Dialog_U1, 'Παρακαλώ περιμένετε...')
        xbmc.executebuiltin(skinshortcuts_menu)
        xbmc.sleep(8000)
        BG.update(96, Dialog_U1, 'Ενημέρωση μενού skin...')
        setting_set('skinshortcutsversion', str(skinshortcuts_version))
        xbmc.sleep(5000)
        BG.update(100, Dialog_U4, 'Θα ακολουθήσει... επαναφόρτωση του προφίλ')
        xbmc.sleep(5000)
        BG.update(100, Dialog_U4, 'Θα ακολουθήσει... και πάγωμα της εικόνας')
        xbmc.sleep(5000)
        BG.update(100, Dialog_U4, Dialog_U5)
        xbmc.executebuiltin("LoadProfile(Master user)")
    xbmc.sleep(5000)
    BG.update(100, Dialog_U4, Dialog_U5)
    xbmc.sleep(5000)
    BG.update(100, Dialog_U4, Dialog_U5)


    BG.close()
    xbmcvfs.delete(downloader_startup_delete)

def installAddon():
    for addon_id in addon_list:
      xbmc.executebuiltin('InstallAddon(%s)' % (addon_id))
      xbmc.sleep(100)
      xbmc.executebuiltin('SendClick(11)')
      xbmc.sleep(100)


def del_dir():
    for ad in addons_data_path:
     for rr in delete_addons:
       dir_list = glob.iglob(os.path.join(ad, rr))
       for path in dir_list:
           if os.path.isdir(path):
               shutil.rmtree(path)
           if os.path.isfile(path):
              os.remove(path)
              


# xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"videoplayer.stretch43","value":0}}')

# xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"addons.updatemode","value":1}}')



Updater_Matrix()
