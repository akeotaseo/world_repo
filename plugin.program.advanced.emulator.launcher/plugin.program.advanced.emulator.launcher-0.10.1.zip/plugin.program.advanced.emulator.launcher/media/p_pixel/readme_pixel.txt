Theme 'pixel' v1.7 - 05-29-2016 by Rookervik

Thanks to muriani for the super-sexy Sega CD logo! 
Thanks to Omnija for helping me fix some code errors.


Updates:
- May 29th, 2016: Added AGS, Steam, and Desktop systems.
- April  3rd, 2016: Added support for Pipplware.











License

=======





ALLOWED:      	- Share and duplicate as it is

              		- Edit, alter, change it



REQUIREMENTS: 	- Attribution, give credit to the creator

              		- Indicate changes to it

              		- Publish the changes under the same license



PROHIBITED:   	- Commercial distribution





LOGO NOTICE:


The used logos and trademarks are copyright of their respective owners.
