################################################################################
#      Copyright (C) 2015 Surfacingx                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import os
import xbmc, xbmcgui, xbmcvfs
import re
import uservar
import time
from datetime import date, datetime, timedelta
from resources.libs import wizard as wiz


transPath  = xbmcvfs.translatePath
lognot = xbmc.LOGINFO
ADDON_ID       = uservar.ADDON_ID
ADDONTITLE     = uservar.ADDONTITLE
ADDON          = wiz.addonId(ADDON_ID)
DIALOG         = xbmcgui.Dialog()
HOME           = transPath('special://home/')
ADDONS         = os.path.join(HOME,      'addons')
USERDATA       = os.path.join(HOME,      'userdata')
PLUGIN         = os.path.join(ADDONS,    ADDON_ID)
PACKAGES       = os.path.join(ADDONS,    'packages')
ADDONDATA      = os.path.join(USERDATA,  'addon_data', ADDON_ID)
ADDOND         = os.path.join(USERDATA,  'addon_data')
REALFOLD       = os.path.join(ADDONDATA, 'debrid')
ICON           = os.path.join(PLUGIN,    'icon.png')
TODAY          = date.today()
TOMORROW       = TODAY + timedelta(days=1)
THREEDAYS      = TODAY + timedelta(days=3)
KEEPTRAKT      = wiz.getS('keepdebrid')
REALSAVE       = wiz.getS('debridlastsave')
COLOR1         = uservar.COLOR1
COLOR2         = uservar.COLOR2
ORDER          = ['resolveurl', 'resolveurlpm', 'resolveurlad', 'resolveurltb', 'serenrd', 'serenpm', 'serenad', 'incursionpm', 'destinyrd',
                  'myaccountsrd', 'myaccountspm', 'myaccountsad', 'fenrd', 'fenpm', 'fenad', 'povrd', 'povpm', 'povad', 'povtb', 'umbrellard', 'umbrellapm', 'umbrellaad', 'url', 'urlpm']

DEBRIDID = {
    'resolveurl': {
        'name'     : 'ResolveURL RD',
        'plugin'   : 'script.module.resolveurl',
        'saved'    : 'resolveurl',
        'path'     : os.path.join(ADDONS, 'script.module.resolveurl'),
        'icon'     : wiz.addonInfo('script.module.resolveurl', 'icon'),
        'fanart'   : wiz.addonInfo('script.module.resolveurl', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'resolveurl_debrid'),
        'settings' : os.path.join(ADDOND, 'script.module.resolveurl', 'settings.xml'),
        'default'  : 'RealDebridResolver_client_id',
        'data'     : ['RealDebridResolver_enabled', 'RealDebridResolver_priority', 'RealDebridResolver_login', 'RealDebridResolver_autopick', 'RealDebridResolver_token', 'RealDebridResolver_refresh', 'RealDebridResolver_client_id', 'RealDebridResolver_client_secret'],
        'activate' : 'RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)'},
    'resolveurlpm': {
        'name'     : 'ResolveURL PM',
        'plugin'   : 'script.module.resolveurl',
        'saved'    : 'resolveurlpm',
        'path'     : os.path.join(ADDONS, 'script.module.resolveurl'),
        'icon'     : wiz.addonInfo('script.module.resolveurl', 'icon'),
        'fanart'   : wiz.addonInfo('script.module.resolveurl', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'resolveurl_premiumize'),
        'settings' : os.path.join(ADDOND, 'script.module.resolveurl', 'settings.xml'),
        'default'  : 'PremiumizeMeResolver_username',
        'data'     : ['PremiumizeMeResolver_enabled', 'PremiumizeMeResolver_login', 'PremiumizeMeResolver_password', 'PremiumizeMeResolver_priority', 'PremiumizeMeResolver_use_https', 'PremiumizeMeResolver_username'],
        'activate' : 'RunPlugin(plugin://script.module.resolveurl/?mode=auth_pm)'},
    'resolveurlad': {
        'name'     : 'ResolveURL AD',
        'plugin'   : 'script.module.resolveurl',
        'saved'    : 'resolveurlad',
        'path'     : os.path.join(ADDONS, 'script.module.resolveurl'),
        'icon'     : wiz.addonInfo('script.module.resolveurl', 'icon'),
        'fanart'   : wiz.addonInfo('script.module.resolveurl', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'resolveurl_alldebrid'),
        'settings' : os.path.join(ADDOND, 'script.module.resolveurl', 'settings.xml'),
        'default'  : 'AllDebridResolver_client_id',
        'data'     : ['AllDebridResolver_enabled', 'AllDebridResolver_login', 'AllDebridResolver_priority', 'AllDebridResolver_token', 'AllDebridResolver_torrents', 'AllDebridResolver_cached_only'],
        'activate' : 'RunPlugin(plugin://script.module.resolveurl/?mode=auth_ad)'},
    'resolveurltb': {
        'name'     : 'ResolveURL TB',
        'plugin'   : 'script.module.resolveurl',
        'saved'    : 'resolveurltb',
        'path'     : os.path.join(ADDONS, 'script.module.resolveurl'),
        'icon'     : wiz.addonInfo('script.module.resolveurl', 'icon'),
        'fanart'   : wiz.addonInfo('script.module.resolveurl', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'resolveurl_torbox'),
        'settings' : os.path.join(ADDOND, 'script.module.resolveurl', 'settings.xml'),
        'default'  : 'TorBoxResolver_apikey',
        'data'     : ['TorBoxResolver_apikey'],
        'activate' : 'torboxapi'},
    'serenrd': {
        'name'     : 'Seren RD',
        'plugin'   : 'plugin.video.seren',
        'saved'    : 'serenrd',
        'path'     : os.path.join(ADDONS, 'plugin.video.seren'),
        'icon'     : wiz.addonInfo('plugin.video.seren', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.seren', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'seren_debrid'),
        'settings' : os.path.join(ADDOND, 'plugin.video.seren', 'settings.xml'),
        'default'  : 'rd.client_id',
        'data'     : ['realdebrid.enabled', 'rd.priority', 'rd.username', 'rd.auth', 'rd.refresh', 'rd.client_id', 'rd.secret', 'rd.cloudInspection'],
        'activate' : 'RunPlugin(plugin://plugin.video.seren/?action=authRealDebrid)'},
    'serenpm': {
        'name'     : 'Seren PM',
        'plugin'   : 'plugin.video.seren',
        'saved'    : 'serenpm',
        'path'     : os.path.join(ADDONS, 'plugin.video.seren'),
        'icon'     : wiz.addonInfo('plugin.video.seren', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.seren', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'seren_premiumize'),
        'settings' : os.path.join(ADDOND, 'plugin.video.seren', 'settings.xml'),
        'default'  : 'premiumize.username',
        'data'     : ['premiumize.username', 'premiumize.token', 'premiumize.threshold', 'premiumize.cloudInspection'],
        'activate' : 'RunPlugin(plugin://plugin.video.seren/?action=authPremiumize)'},
    'serenad': {
        'name'     : 'Seren AD',
        'plugin'   : 'plugin.video.seren',
        'saved'    : 'serenad',
        'path'     : os.path.join(ADDONS, 'plugin.video.seren'),
        'icon'     : wiz.addonInfo('plugin.video.seren', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.seren', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'seren_alldebrid'),
        'settings' : os.path.join(ADDOND, 'plugin.video.seren', 'settings.xml'),
        'default'  : 'alldebrid.username',
        'data'     : ['alldebrid.enabled', 'alldebrid.username', 'alldebrid.apikey'],
        'activate' : 'RunPlugin(plugin://plugin.video.seren/?action=authAllDebrid)'},
    'incursionpm': {
        'name'     : 'Incursion PM',
        'plugin'   : 'plugin.video.incursion',
        'saved'    : 'incursionpm',
        'path'     : os.path.join(ADDONS, 'plugin.video.incursion'),
        'icon'     : wiz.addonInfo('plugin.video.incursion', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.incursion', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'incursion_premiumize'),
        'settings' : os.path.join(ADDOND, 'plugin.video.incursion', 'settings.xml'),
        'default'  : 'pm.pin',
        'data'     : ['pm.pin'],
        'activate' : 'RunPlugin(plugin://plugin.video.incursion/?action=openSettings&query=3.1)'},
    'destinyrd': {
        'name'     : 'Destiny',
        'plugin'   : 'plugin.video.destiny',
        'saved'    : 'destinyrd',
        'path'     : os.path.join(ADDONS, 'plugin.video.destiny'),
        'icon'     : wiz.addonInfo('plugin.video.destiny', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.destiny', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'destiny_debrid'),
        'settings' : os.path.join(ADDOND, 'plugin.video.destiny', 'settings.xml'),
        'default'  : 'rd.client_id',
        'data'     : ['rd.username', 'rd.auth', 'rd.refresh', 'rd.client_id', 'rd.secret', 'rd_menu_enable', 'rdsource'],
        'activate' : 'RunPlugin(plugin://plugin.video.destiny?mode2=138&url=www)'},
    'myaccountsrd': {
        'name'     : 'My Accounts RealDebrid',
        'plugin'   : 'script.module.myaccounts',
        'saved'    : 'myaccountsrd',
        'path'     : os.path.join(ADDONS, 'script.module.myaccounts'),
        'icon'     : wiz.addonInfo('script.module.myaccounts', 'icon'),
        'fanart'   : wiz.addonInfo('script.module.myaccounts', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'myaccounts_realdebrid'),
        'settings' : os.path.join(ADDOND, 'script.module.myaccounts', 'settings.xml'),
        'default'  : 'realdebrid.username',
        'data'     : ['realdebrid.username', 'realdebrid.token', 'realdebrid.refresh', 'realdebrid.client_id', 'realdebrid.secret'],
        'activate' : 'RunScript(script.module.myaccounts, action=realdebridAuth)'},
    'myaccountspm': {
        'name'     : 'My Accounts Premiumize',
        'plugin'   : 'script.module.myaccounts',
        'saved'    : 'myaccountspm',
        'path'     : os.path.join(ADDONS, 'script.module.myaccounts'),
        'icon'     : wiz.addonInfo('script.module.myaccounts', 'icon'),
        'fanart'   : wiz.addonInfo('script.module.myaccounts', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'myaccounts_premiumize'),
        'settings' : os.path.join(ADDOND, 'script.module.myaccounts', 'settings.xml'),
        'default'  : 'premiumize.username',
        'data'     : ['premiumize.username', 'premiumize.token'],
        'activate' : 'RunScript(script.module.myaccounts, action=premiumizeAuth)'},
    'myaccountsad': {
        'name'     : 'My Accounts AllDebrid',
        'plugin'   : 'script.module.myaccounts',
        'saved'    : 'myaccountsad',
        'path'     : os.path.join(ADDONS, 'script.module.myaccounts'),
        'icon'     : wiz.addonInfo('script.module.myaccounts', 'icon'),
        'fanart'   : wiz.addonInfo('script.module.myaccounts', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'myaccounts_alldebrid'),
        'settings' : os.path.join(ADDOND, 'script.module.myaccounts', 'settings.xml'),
        'default'  : 'alldebrid.username',
        'data'     : ['alldebrid.username', 'alldebrid.token'],
        'activate' : 'RunScript(script.module.myaccounts, action=alldebridAuth)'},
    'fenrd': {
        'name'     : 'Fen RealDebrid',
        'plugin'   : 'plugin.video.fen',
        'saved'    : 'fenrd',
        'path'     : os.path.join(ADDONS, 'plugin.video.fen'),
        'icon'     : wiz.addonInfo('plugin.video.fen', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.fen', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'fen_realdebrid'),
        'settings' : os.path.join(ADDOND, 'plugin.video.fen', 'settings.xml'),
        'default'  : 'rd.account_id',
        'data'     : ['rd.account_id', 'rd.token', 'rd.client_id', 'rd.secret', 'rd.refresh'],
        'activate' : 'RunPlugin(plugin://plugin.video.fen/?mode=real_debrid.authenticate)'},
    'fenpm': {
        'name'     : 'Fen Premiumize',
        'plugin'   : 'plugin.video.fen',
        'saved'    : 'fenpm',
        'path'     : os.path.join(ADDONS, 'plugin.video.fen'),
        'icon'     : wiz.addonInfo('plugin.video.fen', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.fen', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'fen_premiumize'),
        'settings' : os.path.join(ADDOND, 'plugin.video.fen', 'settings.xml'),
        'default'  : 'pm.account_id',
        'data'     : ['pm.account_id', 'pm.token'],
        'activate' : 'RunPlugin(plugin://plugin.video.fen/?mode=premiumize.authenticate)'},
    'fenad': {
        'name'     : 'Fen AllDebrid',
        'plugin'   : 'plugin.video.fen',
        'saved'    : 'fenad',
        'path'     : os.path.join(ADDONS, 'plugin.video.fen'),
        'icon'     : wiz.addonInfo('plugin.video.fen', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.fen', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'fen_alldebrid'),
        'settings' : os.path.join(ADDOND, 'plugin.video.fen', 'settings.xml'),
        'default'  : 'ad.account_id',
        'data'     : ['ad.account_id', 'ad.token'],
        'activate' : 'RunPlugin(plugin://plugin.video.fen/?mode=alldebrid.authenticate)'},
    'povrd': {
        'name'     : 'POV RealDebrid',
        'plugin'   : 'plugin.video.pov',
        'saved'    : 'povrd',
        'path'     : os.path.join(ADDONS, 'plugin.video.pov'),
        'icon'     : wiz.addonInfo('plugin.video.pov', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.pov', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'pov_realdebrid'),
        'settings' : os.path.join(ADDOND, 'plugin.video.pov', 'settings.xml'),
        'default'  : 'rd.username',
        'data'     : ['rd.username', 'rd.token', 'rd.client_id', 'rd.secret', 'rd.refresh'],
        'activate' : 'RunPlugin(plugin://plugin.video.pov/?mode=real_debrid.rd_auth)'},
    'povpm': {
        'name'     : 'POV Premiumize',
        'plugin'   : 'plugin.video.pov',
        'saved'    : 'povpm',
        'path'     : os.path.join(ADDONS, 'plugin.video.pov'),
        'icon'     : wiz.addonInfo('plugin.video.pov', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.pov', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'pov_premiumize'),
        'settings' : os.path.join(ADDOND, 'plugin.video.pov', 'settings.xml'),
        'default'  : 'pm.account_id',
        'data'     : ['pm.account_id', 'pm.token'],
        'activate' : 'RunPlugin(plugin://plugin.video.pov/?mode=premiumize.pm_auth)'},
    'povad': {
        'name'     : 'POV AllDebrid',
        'plugin'   : 'plugin.video.pov',
        'saved'    : 'povad',
        'path'     : os.path.join(ADDONS, 'plugin.video.pov'),
        'icon'     : wiz.addonInfo('plugin.video.pov', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.pov', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'pov_alldebrid'),
        'settings' : os.path.join(ADDOND, 'plugin.video.pov', 'settings.xml'),
        'default'  : 'ad.account_id',
        'data'     : ['ad.account_id', 'ad.token'],
        'activate' : 'RunPlugin(plugin://plugin.video.pov/?mode=alldebrid.ad_auth)'},
    'povtb': {
        'name'     : 'POV TorBox',
        'plugin'   : 'plugin.video.pov',
        'saved'    : 'povtb',
        'path'     : os.path.join(ADDONS, 'plugin.video.pov'),
        'icon'     : wiz.addonInfo('plugin.video.pov', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.pov', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'pov_torbox'),
        'settings' : os.path.join(ADDOND, 'plugin.video.pov', 'settings.xml'),
        'default'  : 'tb.account_id',
        'data'     : ['tb.account_id', 'tb.token'],
        'activate' : 'RunPlugin(plugin://plugin.video.pov/?mode=torbox.tb_auth)'},
    'umbrellard': {
        'name'     : 'Umbrella RealDebrid',
        'plugin'   : 'plugin.video.umbrella',
        'saved'    : 'umbrellard',
        'path'     : os.path.join(ADDONS, 'plugin.video.umbrella'),
        'icon'     : wiz.addonInfo('plugin.video.umbrella', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.umbrella', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'umbrella_realdebrid'),
        'settings' : os.path.join(ADDOND, 'plugin.video.umbrella', 'settings.xml'),
        'default'  : 'realdebrid.clientid',
        'data'     : ['realdebridtoken', 'realdebridusername', 'realdebrid.clientid', 'realdebridrefresh', 'realdebridsecret'],
        'activate' : 'RunPlugin(plugin://plugin.video.umbrella/?action=rd_Authorize)'},
    'umbrellapm': {
        'name'     : 'Umbrella Premiumize',
        'plugin'   : 'plugin.video.umbrella',
        'saved'    : 'umbrellapm',
        'path'     : os.path.join(ADDONS, 'plugin.video.umbrella'),
        'icon'     : wiz.addonInfo('plugin.video.umbrella', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.umbrella', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'umbrella_premiumize'),
        'settings' : os.path.join(ADDOND, 'plugin.video.umbrella', 'settings.xml'),
        'default'  : 'premiumizeusername',
        'data'     : ['premiumizeusername', 'premiumizetoken'],
        'activate' : 'RunPlugin(plugin://plugin.video.umbrella/?action=pm_Authorize)'},
    'umbrellaad': {
        'name'     : 'Umbrella AllDebrid',
        'plugin'   : 'plugin.video.umbrella',
        'saved'    : 'umbrellaad',
        'path'     : os.path.join(ADDONS, 'plugin.video.umbrella'),
        'icon'     : wiz.addonInfo('plugin.video.umbrella', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.umbrella', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'umbrella_alldebrid'),
        'settings' : os.path.join(ADDOND, 'plugin.video.umbrella', 'settings.xml'),
        'default'  : 'alldebridusername',
        'data'     : ['alldebridusername', 'alldebridtoken'],
        'activate' : 'RunPlugin(plugin://plugin.video.umbrella/?action=ad_Authorize)'},
    'url': {
        'name'     : 'URL Resolver',
        'plugin'   : 'script.module.urlresolver',
        'saved'    : 'urlresolver',
        'path'     : os.path.join(ADDONS, 'script.module.urlresolver'),
        'icon'     : wiz.addonInfo('script.module.urlresolver', 'icon'),
        'fanart'   : wiz.addonInfo('script.module.urlresolver', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'url_debrid'),
        'settings' : os.path.join(ADDOND, 'script.module.urlresolver', 'settings.xml'),
        'default'  : 'RealDebridResolver_client_id',
        'data'     : ['RealDebridResolver_enabled', 'RealDebridResolver_priority', 'RealDebridResolver_login', 'RealDebridResolver_autopick', 'RealDebridResolver_token', 'RealDebridResolver_refresh', 'RealDebridResolver_client_id', 'RealDebridResolver_client_secret'],
        'activate' : 'RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)'},
    'urlpm': {
        'name'     : 'URLResolver PM',
        'plugin'   : 'script.module.urlresolver',
        'saved'    : 'urlresolverpm',
        'path'     : os.path.join(ADDONS, 'script.module.urlresolver'),
        'icon'     : wiz.addonInfo('script.module.urlresolver', 'icon'),
        'fanart'   : wiz.addonInfo('script.module.urlresolver', 'fanart'),
        'file'     : os.path.join(REALFOLD, 'url_premiumize'),
        'settings' : os.path.join(ADDOND, 'script.module.urlresolver', 'settings.xml'),
        'default'  : 'PremiumizeMeResolver_username',
        'data'     : ['PremiumizeMeResolver_enabled', 'PremiumizeMeResolver_login', 'PremiumizeMeResolver_password', 'PremiumizeMeResolver_priority', 'PremiumizeMeResolver_use_https', 'PremiumizeMeResolver_username'],
        'activate' : 'RunPlugin(plugin://script.module.urlresolver/?mode=auth_pm)'}
}

def debridUser(who):
    user=None
    if DEBRIDID[who]:
        if os.path.exists(DEBRIDID[who]['path']):
            try:
                add = wiz.addonId(DEBRIDID[who]['plugin'])
                user = add.getSetting(DEBRIDID[who]['default'])
            except:
                pass
    return user

def debridIt(do, who):
    if not os.path.exists(ADDONDATA): os.makedirs(ADDONDATA)
    if not os.path.exists(REALFOLD):  os.makedirs(REALFOLD)
    if who == 'all':
        for log in ORDER:
            if os.path.exists(DEBRIDID[log]['path']):
                try:
                    addonid   = wiz.addonId(DEBRIDID[log]['plugin'])
                    default   = DEBRIDID[log]['default']
                    user      = addonid.getSetting(default)
                    if user == '' and do == 'update': continue
                    updateDebrid(do, log)
                except: pass
            else: wiz.log('[Debrid Data] %s(%s) is not installed' % (DEBRIDID[log]['name'],DEBRIDID[log]['plugin']), xbmc.LOGERROR)
        wiz.setS('debridlastsave', str(THREEDAYS))
    else:
        if DEBRIDID[who]:
            if os.path.exists(DEBRIDID[who]['path']):
                updateDebrid(do, who)
        else: wiz.log('[Debrid Data] Invalid Entry: %s' % who, xbmc.LOGERROR)

def clearSaved(who, over=False):
    if who == 'all':
        for debrid in DEBRIDID:
            clearSaved(debrid,  True)
    elif DEBRIDID[who]:
        file = DEBRIDID[who]['file']
        if os.path.exists(file):
            xbmcvfs.delete(file)
            wiz.LogNotify('[COLOR %s]%s[/COLOR]' % (COLOR1, DEBRIDID[who]['name']),'[COLOR %s]Debrid Data: Removed![/COLOR]' % COLOR2, 2000, DEBRIDID[who]['icon'])
        wiz.setS(DEBRIDID[who]['saved'], '')
    if over == False: wiz.refresh()

def updateDebrid(do, who):
    file      = DEBRIDID[who]['file']
    settings  = DEBRIDID[who]['settings']
    data      = DEBRIDID[who]['data']
    addonid   = wiz.addonId(DEBRIDID[who]['plugin'])
    saved     = DEBRIDID[who]['saved']
    default   = DEBRIDID[who]['default']
    user      = addonid.getSetting(default)
    suser     = wiz.getS(saved)
    name      = DEBRIDID[who]['name']
    icon      = DEBRIDID[who]['icon']

    if do == 'update':
        if not user == '':
            try:
                with xbmcvfs.File(file, 'w') as f:
                    for debrid in data: 
                        f.write('<debrid>\n\t<id>%s</id>\n\t<value>%s</value>\n</debrid>\n' % (debrid, addonid.getSetting(debrid)))
                    # f.close()
                user = addonid.getSetting(default)
                wiz.setS(saved, user)
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name), '[COLOR %s]Debrid Data: Saved![/COLOR]' % COLOR2, 2000, icon)
            except Exception as e:
                wiz.log("[Debrid Data] Unable to Update %s (%s)" % (who, str(e)), xbmc.LOGERROR)
        else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name), '[COLOR %s]Debrid Data: Not Registered![/COLOR]' % COLOR2, 2000, icon)
    elif do == 'restore':
        if os.path.exists(file):
            f = xbmcvfs.File(file); g = f.read().replace('\n','').replace('\r','').replace('\t',''); f.close();
            match = re.compile('<debrid><id>(.+?)</id><value>(.+?)</value></debrid>').findall(g)
            try:
                if len(match) > 0:
                    for debrid, value in match:
                        addonid.setSetting(debrid, value)
                user = addonid.getSetting(default)
                wiz.setS(saved, user)
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name), '[COLOR %s]Debrid Accounts: Restored![/COLOR]' % COLOR2, 2000, icon)
            except Exception as e:
                wiz.log("[Debrid Data] Unable to Restore %s (%s)" % (who, str(e)), xbmc.LOGERROR)
        #else: wiz.LogNotify(name,'Debrid Data: [COLOR red]Not Found![/COLOR]', 2000, icon)
    elif do == 'clearaddon':
        wiz.log('%s SETTINGS: %s' % (name, settings), xbmc.LOGDEBUG)
        if os.path.exists(settings):
            try:
                f = open(settings, "r"); lines = f.readlines(); f.close()
                f = open(settings, "w")
                for line in lines:
                    match = wiz.parseDOM(line, 'setting', ret='id')
                    if len(match) == 0: f.write(line)
                    else:
                        if match[0] not in data: f.write(line)
                        else: wiz.log('Removing Line: %s' % line, lognot)
                f.close()
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name),'[COLOR %s]Addon Data: Cleared![/COLOR]' % COLOR2, 2000, icon)
            except Exception as e:
                wiz.log("[Trakt Data] Unable to Clear Addon %s (%s)" % (who, str(e)), xbmc.LOGERROR)
    wiz.refresh()

def autoUpdate(who):
    if who == 'all':
        for log in DEBRIDID:
            if os.path.exists(DEBRIDID[log]['path']):
                autoUpdate(log)
    elif DEBRIDID[who]:
        if os.path.exists(DEBRIDID[who]['path']):
            u  = debridUser(who)
            su = wiz.getS(DEBRIDID[who]['saved'])
            n = DEBRIDID[who]['name']
            if u == None or u == '': return
            elif su == '': debridIt('update', who)
            elif not u == su:
                if DIALOG.yesno(ADDONTITLE, ("[COLOR %s]Would you like to save the [COLOR %s]Debrid account[/COLOR] data for [COLOR %s]%s[/COLOR]?" % (COLOR2, COLOR1, COLOR1, n))+"[CR]"+("Addon: [COLOR green][B]%s[/B][/COLOR]" % u)+"[CR]"+("Saved:[/COLOR] [COLOR red][B]%s[/B][/COLOR]" % su if not su == '' else 'Saved:[/COLOR] [COLOR red][B]None[/B][/COLOR]'), yeslabel="[B][COLOR green]Save Data[/COLOR][/B]", nolabel="[B][COLOR red]No Cancel[/COLOR][/B]"):
                    debridIt('update', who)
            else: debridIt('update', who)

def importlist(who):
    if who == 'all':
        for log in DEBRIDID:
            if os.path.exists(DEBRIDID[log]['file']):
                importlist(log)
    elif DEBRIDID[who]:
        if os.path.exists(DEBRIDID[who]['file']):
            d  = DEBRIDID[who]['default']
            sa = DEBRIDID[who]['saved']
            su = wiz.getS(sa)
            n  = DEBRIDID[who]['name']
            f  = xbmcvfs.File(DEBRIDID[who]['file']); g = f.read().replace('\n','').replace('\r','').replace('\t',''); f.close();
            m  = re.compile('<debrid><id>%s</id><value>(.+?)</value></debrid>' % d).findall(g)
            if len(m) > 0:
                if not m[0] == su:
                    if DIALOG.yesno(ADDONTITLE, ("[COLOR %s]Would you like to import the [COLOR %s]Debrid account[/COLOR] data for [COLOR %s]%s[/COLOR]?" % (COLOR2, COLOR1, COLOR1, n))+"[CR]"+("File: [COLOR green][B]%s[/B][/COLOR]" % m[0])+"[CR]"+("Saved:[/COLOR] [COLOR red][B]%s[/B][/COLOR]" % su if not su == '' else 'Saved:[/COLOR] [COLOR red][B]None[/B][/COLOR]'), yeslabel="[B][COLOR green]Save Data[/COLOR][/B]", nolabel="[B][COLOR red]No Cancel[/COLOR][/B]"):
                        wiz.setS(sa, m[0])
                        wiz.log('[Import Data] %s: %s' % (who, str(m)), lognot)
                    else: wiz.log('[Import Data] Declined Import(%s): %s' % (who, str(m)), lognot)
                else: wiz.log('[Import Data] Duplicate Entry(%s): %s' % (who, str(m))), lognot
            else: wiz.log('[Import Data] No Match(%s): %s' % (who, str(m)), lognot)

def activateDebrid(who):
    if DEBRIDID[who]:
        if os.path.exists(DEBRIDID[who]['path']): 
            act     = DEBRIDID[who]['activate']
            addonid = wiz.addonId(DEBRIDID[who]['plugin'])
            if act == '': addonid.openSettings()
            elif act == 'torboxapi':
                tb_api = wiz.getKeyboard('', 'TorBox API Key:')
                if len(tb_api)>=32:
                    addonid.setSetting(DEBRIDID[who]['default'], tb_api)
                else:
                    DIALOG.ok(ADDONTITLE, 'Give a valid TorBox API Key for %s' % DEBRIDID[who]['name'])
            else: url = xbmc.executebuiltin(DEBRIDID[who]['activate'])
        else: DIALOG.ok(ADDONTITLE, '%s is not currently installed.' % DEBRIDID[who]['name'])
    else: 
        wiz.refresh()
        return
    check = 0
    while debridUser(who) == None:
        if check == 30: break
        check += 1
        time.sleep(10)
    wiz.refresh()
    
