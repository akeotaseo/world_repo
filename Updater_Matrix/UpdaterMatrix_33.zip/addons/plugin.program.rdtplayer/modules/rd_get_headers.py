# -*- coding: utf-8 -*-
# Thin wrapper so existing code can still `from modules.rd_get_headers import get_rd_headers`
from modules.rd_auth_unified import get_rd_headers
