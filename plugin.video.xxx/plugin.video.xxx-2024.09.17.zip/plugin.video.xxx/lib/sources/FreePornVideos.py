import re
import xbmcaddon
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

BaseURL = "https://www.freepornvideos.xxx"
Thumb   = 'special://home/addons/plugin.video.xxx/resources/art/freepornvideos.png'


def Menu():
	addDir('Latest Videos', BaseURL + '/latest-updates/1/', 31, Thumb)
	addDir('Most Viewed Videos', BaseURL + '/most-popular/1/', 31, Thumb)
	#addDir('Top Rated Videos', BaseURL + '/top-rated/1/', 31, Thumb)
	addDir('Categories', BaseURL + '/categories/', 32, Thumb)
	addDir('Porn Sites', BaseURL + '/sites/1/', 34, Thumb)

def Browse(url):
	page_url = url
	r = OpenURL(url)
	r = r.replace('\n', '')
	r = r.replace('	', '')
	m = re.compile('<div class="item"><a(.+?)<strong class="title">').findall(r)
	for i in m:
		try:
			title = re.compile('title="(.+?)"').findall(i)[0]
			time  = re.compile('<span class="duration">Full Video (.+?)</span>').findall(i)[0]
			url   = re.compile('href="(.+?)" target="').findall(i)[0]
			thumb = re.compile('data-src="(.+?)"').findall(i)[0]
			if Setting('show_time') == 'true': title = '[B](%s)[/B] %s' % (time, title)
			import random
			random_id = random.randint(0,1000000)
			url = '%s&random_id=%s' % (url, str(random_id))
			if 'trans' in title.lower(): pass
			elif 'gay' in title.lower(): pass
			elif 'tgirl' in title.lower(): pass
			else: addVideo(title, url, 33, thumb)
		except:
			pass
	
	if 'categories' in page_url or 'sites' in page_url: c_page = re.compile('//.+?/.+?/.+?/(.+?)/').findall(page_url)[0]
	else: c_page = re.compile('//.+?/.+?/(.+?)/').findall(page_url)[0]
	n_page = str(int(c_page) + 1)
	n_url = page_url.replace(c_page, n_page)
	addDir('Next page >', n_url, 31, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')

	Common.SetView()
	
def Sites(url):
	page_url = url
	r = OpenURL(url)
	r = r.replace('\n', '')
	r = r.replace('	', '')
	m = re.compile('<div class="headline">(.+?)</div>').findall(r)
	for i in m:
		try:
			title = re.compile('<h2>(.+?)</h2>').findall(i)[0]
			url = re.compile('<a class="more" href="(.+?)">').findall(i)[0]
			url = url + '1/'
			if 'trans' in title.lower(): pass
			elif 'gay' in title.lower(): pass
			elif 'tgirl' in title.lower(): pass
			else: addDir(title, url, 31, Thumb)
		except:
			pass
	
	c_page = re.compile('//.+?/.+?/(.+?)/').findall(page_url)[0]
	n_page = str(int(c_page) + 1)
	n_url = page_url.replace(c_page, n_page)
	addDir('Next page >', n_url, 34, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')

def Categories(url):
	r = OpenURL(url)
	m = re.compile('<a class="item" href="https://www\.freepornvideos\.xxx/categories/(.+?)/" title="(.+?)">').findall(r)
	for content_id, title in m:
		url = '%s/categories/%s/1/' % (BaseURL, content_id)
		addDir(title, url, 31, Thumb)

def PlayStream(url):
	if 'random_id=' in url:
		url = re.compile('(.+?)&random_id').findall(url)[0]
	r = OpenURL(url)
	m = re.compile("<source src='(.+?)' type='video/mp4'").findall(r)[0]
	Play(m)

	