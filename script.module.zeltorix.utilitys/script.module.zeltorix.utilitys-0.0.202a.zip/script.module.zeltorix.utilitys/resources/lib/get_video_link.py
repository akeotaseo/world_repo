# -*- coding: utf-8 -*-
# Module: get_video_link
# Author: Zeltorix
# Created on: 2023.10.04
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from json import loads, dumps
from re import findall
from random import choice

import yt_dlp


try:
    from web_api_request import WebApiRequest, headers
except ImportError:
    from source.release.utilitys.resources.lib.web_api_request import WebApiRequest, headers


class VideoLink:
    __slots__ = []

    def definition_links(self, link: str) -> (str, dict):
        if "vk.com" in link or findall(r"\d{5,}_\d{5,}", link) or (len(findall(r"\d{5,}", link)) == 2):
            return self.vk_link(link)
        elif "ok.ru" in link or findall(r"\d{12,}", link):
            return self.ok_link(link)
        elif "rutube.ru" in link or findall(r"(\d,\w){28,}", link):
            return self.rutube_link(link)
        elif "youtube" in link or "embed" in link or findall(r"(\d,-,\w){11}", link):
            return self.youtube_link(link)
        elif "mediavitrina" in link:
            return self.mediavitrina_links(link)
        else:
            raise ValueError(f"Неизвестная ссылка - {link}")

    @staticmethod
    def _vk_get_id(link: str) -> str:
        rex = findall(r'\d{5,}', link)
        if rex:
            return f"-{rex[0]}_{rex[1]}"
        else:
            raise ValueError(f"Неизвестная ссылка {link}")

    def vk_link(self, link: str) -> str:
        id_: str = self._vk_get_id(link)
        if id_:
            post = {"al": "1", "video": id_}

            headers["Referer"] = "moc.xednay//:sptth"[::-1]
            headers["x-requested-with"] = "XMLHttpRequest"

            response = WebApiRequest(headers).request_post("wohs=tca?php.oediv_la/moc.kv//:sptth"[::-1], post)
            if response and response is not int:
                data = response.json()["payload"][1][4]["player"]["params"][0]
                if data.get("hls"):
                    return data["hls"]
                elif data.get("hls_ondemand"):
                    return data["hls_ondemand"]
                else:
                    raise KeyError(f"Нету нудных ключей {dumps(data, indent=2)}")
        else:
            raise ValueError("Отсутствует данные")

    @staticmethod
    def _ok_get_id(link: str) -> str:
        if "video/" in link:
            return link.split("video/")[1]
        elif findall(r"\d{10,}", link):
            return findall(r"\d{10,}", link)[0]
        elif "/" not in link:
            return link
        else:
            raise ValueError(f"Неизвестная ссылка {link}")

    def ok_link(self, link: str) -> (str, dict):
        id_: str = self._ok_get_id(link)
        if id_:
            post: dict = {"st.vpl.id": id_, "st.vpl.bu": link}
            response = WebApiRequest().request_post("oediVreyaLpoP=dmc?kd/ur.ko//:sptth"[::-1], post)
            if response and response is not int:
                data_options: str = findall(
                    r'data-options=".*?"',
                    response.text
                )[0].split('"')[1].replace("&quot;", '"')
                hls: dict = loads(loads(data_options)["flashvars"]["metadata"])
                if hls.get("hlsMasterPlaylistUrl"):
                    video: str = hls["hlsMasterPlaylistUrl"]
                elif hls.get("hlsManifestUrl"):
                    video: str = hls["hlsManifestUrl"]
                else:
                    raise KeyError(f"Нужного ключа не найдено {link}")
                return video
        else:
            raise ValueError("Отсутствует данные")

    @staticmethod
    def _rutube_get_id(link: str) -> str:
        if "/" in link:
            if "?" in link:
                return link.split("?")[0].split("/")[-2]
            elif link.endswith("/"):
                return link.split("/")[-2]
            elif "rutube.ru/play/embed/" in link:
                return link.split("/")[-1]
        elif "/" not in link:
            return link
        else:
            raise ValueError(f"Неизвестная ссылка {link}")

    def rutube_link(self, link: str) -> (str, dict):
        id_: (str, int, dict, None) = self._rutube_get_id(link)
        if id_:
            vido_dict: dict = WebApiRequest().request_get("/snoitpo/yalp/ipa/ur.ebutur//:sptth"[::-1] + id_).json()

            # Если видео на портале
            if vido_dict["has_video"]:
                # Используется ли плеер портала
                if vido_dict["player"] == "rutube":
                    # Обычное видео
                    if vido_dict["video_balancer"]:
                        return vido_dict["video_balancer"]["m3u8"]
                    # Прямой эфир
                    elif vido_dict["live_streams"] and vido_dict["live_streams"].get("hls"):
                        return vido_dict["live_streams"]["hls"][0]["url"]

                    # При отсутствии потока проверить детали
                    elif vido_dict.get("detail"):
                        # Заглушка для стрима
                        if vido_dict["detail"]["name"] == "stream_access_fail":
                            return {
                                "title": vido_dict["detail"]["languages"][0]["title"],
                                "description": vido_dict["detail"]["languages"][0]["description"],
                                "router": "message",
                            }
                    else:
                        raise ValueError(f"Видео вроде как есть на портале, но логики на вынимания потока нет - "
                                         f"{'/snoitpo/yalp/ipa/ur.ebutur//:sptth'[::-1] + id_}")
                else:
                    raise ValueError(f"Видео вроде как есть, но логики на вынимания потока нет - "
                                     f"{'/snoitpo/yalp/ipa/ur.ebutur//:sptth'[::-1] + id_}")
            # Отсутствие видео на портале
            else:
                # Проверяет использоваться ли сторонний плеер
                if vido_dict["player"] == "iframe":
                    return {
                        "title": "Сторонний плеер",
                        "data": "https:" + vido_dict["iframe_url"],
                        "referer": vido_dict["referer"],
                        "router": "iframe",
                    }

                else:
                    raise ValueError(f"Не понятно от куда брать поток, требуется исследование - "
                                     f"{'/snoitpo/yalp/ipa/ur.ebutur//:sptth'[::-1] + id_}")
        else:
            raise ValueError("Отсутствует данные")

    @staticmethod
    def mediavitrina_links(link: str, one_link=False) -> dict:
        response = WebApiRequest().request_get(link)
        if response and response is not int:
            link_site = loads(findall(r"allowedDomains: .*?]", response.text)[0].split("allowedDomains: ")[1])
            refer_host_name: str = list(filter(lambda item: item if "*" not in item else False, link_site[::-1][:2]))[0]

            url_players: str = findall(r"url:.*'", response.text)[0].split("'")[1]

            link_players: str = url_players \
                .replace("{{APPLICATION_ID}}", "") \
                .replace("{{PLAYER_REFERER_HOSTNAME}}", refer_host_name) \
                .replace("{{CONFIG_CHECKSUM_SHA256}}", "")

            link_epg: str = findall(r"epg_url:.*'", response.text)[0].split("'")[1]

            headers["Referer"] = "/ur.anirtivaidem.reyalp//:sptth"[::-1]
            headers["Sec-Fetch-Dest"] = "empty"
            headers["Sec-Fetch-Mode"] = "cors"
            headers["Sec-Fetch-Site"] = "same-site"
            session = WebApiRequest(headers)
            players: dict = session.request_get(link_players).json()
            if one_link:
                return choice(players["hls"])
            else:
                epg: dict = session.request_get(link_epg).json()
                return {**players, **epg}

    @staticmethod
    def youtube_link(link: str) -> str:
        with yt_dlp.YoutubeDL({}) as ydl:
            for i in ydl.sanitize_info(ydl.extract_info(link, download=False))["formats"]:
                if i.get("fps") and i["fps"] and i.get("audio_channels") and i["audio_channels"] \
                        and i["format_note"] == "720p":
                    return i["url"]

