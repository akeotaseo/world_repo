import urllib
import xbmcaddon
import xbmc
import xbmcgui

try:
	setting = xbmcaddon.Addon('plugin.video.xxx')
	channel = xbmc.getInfoLabel('ListItem.ChannelName')
	channel = channel.decode("utf8")
	channel = channel.encode("utf8")
	remove = 'ch.%s' % channel.replace(' ', '.').replace('+', '_').replace('&', '_')
	remove = urllib.quote_plus(remove)
	setting.setSetting(remove, '')
	xbmcgui.Dialog().ok(channel, 'Default stream has been removed.')

except:
    pass