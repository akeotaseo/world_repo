import xbmc, xbmcgui



def Nba():
    funcs = (click_1, click_2,)
    call = xbmcgui.Dialog().select('[B][COLOR=blue]       NBA[/COLOR][/B]',
['[COLOR=blue]NBA[/COLOR] (The Loop)',

 '[COLOR=orange]NBA[/COLOR] (MyIPTV)'


 ])




    if call:
        if call < 1:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('RunScript("special://home/addons/skin.19MatrixWorld/xml/Dialog Spor/DialogLoopNBA.py")')
def click_2():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmcgui.Dialog().ok('[COLOR=orange]NBA[/COLOR] (MyIPTV)', '[COLOR lime]Επιλέγουμε URL και στη συνέχεια... στα [B][COLOR white]Ζωντανά Κανάλια[/COLOR][/B] ψάχνουμε την κατηγορία που μας ενδιαφέρει.[CR]Σε περίπτωση [COLOR white]Αποτυχίας Σύνδεσης[/COLOR], δοκιμάζουμε άλλο URL')
    xbmcgui.Dialog().notification("[B][COLOR darkorange]My Preferences[/COLOR][/B]", "My[COLOR orangered]IPTV[/COLOR] iLoader", sound=False, icon='https://styles.redditmedia.com/t5_28w7mp/styles/communityIcon_j5m34lvey9041.jpg')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/get_remote_xcodes/https%3A%2F%2Fraw.githubusercontent.com%2Fakeotaseo%2Fworld_repo%2Frefs%2Fheads%2Fmain%2FUpdater_Matrix%2FXML2%2FABN.txt",return)')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png')
    



Nba()
