################################################################################
#      Copyright (C) 2015 Surfacingx                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import os
import xbmc, xbmcgui, xbmcvfs

import re
import uservar
import time
from datetime import date, timedelta
from resources.libs import wizard as wiz

transPath  = xbmcvfs.translatePath
lognot = xbmc.LOGINFO


ADDON_ID       = uservar.ADDON_ID
ADDONTITLE     = uservar.ADDONTITLE
ADDON          = wiz.addonId(ADDON_ID)
DIALOG         = xbmcgui.Dialog()
HOME           = transPath('special://home/')
ADDONS         = os.path.join(HOME,      'addons')
USERDATA       = os.path.join(HOME,      'userdata')
PLUGIN         = os.path.join(ADDONS,    ADDON_ID)
PACKAGES       = os.path.join(ADDONS,    'packages')
ADDONDATA      = os.path.join(USERDATA,  'addon_data', ADDON_ID)
ADDOND         = os.path.join(USERDATA,  'addon_data')
TRAKTFOLD      = os.path.join(ADDONDATA, 'trakt')
ICON           = os.path.join(PLUGIN,    'icon.png')
TODAY          = date.today()
TOMORROW       = TODAY + timedelta(days=1)
THREEDAYS      = TODAY + timedelta(days=3)
KEEPTRAKT      = wiz.getS('keeptrakt')
TRAKTSAVE      = wiz.getS('traktlastsave')
COLOR1         = uservar.COLOR1
COLOR2         = uservar.COLOR2
ORDER          = ['atreides', 'chappaai', 'covenant', 'destiny', 'exodus', 'filmnet', 'incursion', 'marauder', 
                    'metalliq', 'myaccounts', 'fen', 'scrubsv2', 'umbrella', 'neptune', 'placenta', 'seren', 'shadow', 'tmdbhelper', 'tempest',
                    'thecrew', 'theoath', 'blacklodge', 'pov', 'trakt', 'uranus',
                    'yoda']

TRAKTID = { 
    'filmnet': {
        'name'     : 'Filmnet',
        'plugin'   : 'plugin.video.filmnet',
        'saved'    : 'filmnet',
        'path'     : os.path.join(ADDONS, 'plugin.video.filmnet'),
        'icon'     : wiz.addonInfo('plugin.video.filmnet', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.filmnet', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'filmnet_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.filmnet', 'settings.xml'),
        'default'  : 'trakt_user',
        'data'     : ['trakt.user', 'trakt_user', 'trakt.refresh', 'trakt.token'],
        'activate' : 'RunScript(script.trakt, action=auth_info)'},
    'exodus': {
        'name'     : 'Exodus Redux',
        'plugin'   : 'plugin.video.exodusredux',
        'saved'    : 'exodus',
        'path'     : os.path.join(ADDONS, 'plugin.video.exodusredux'),
        'icon'     : wiz.addonInfo('plugin.video.exodusredux', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.exodusredux', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'exodusredux_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.exodusredux', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.user', 'trakt.refresh', 'trakt.token'],
        'activate' : 'RunPlugin(plugin://plugin.video.exodusredux/?action=authTrakt)'},
    'incursion': {
        'name'     : 'Incursion',
        'plugin'   : 'plugin.video.incursion',
        'saved'    : 'incursion',
        'path'     : os.path.join(ADDONS, 'plugin.video.incursion'),
        'icon'     : wiz.addonInfo('plugin.video.incursion', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.incursion', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'incursion_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.incursion', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.user', 'trakt.refresh', 'trakt.token'],
        'activate' : 'RunPlugin(plugin://plugin.video.incursion/?action=authTrakt)'},
    'placenta': {
        'name'     : 'Placenta',
        'plugin'   : 'plugin.video.placenta',
        'saved'    : 'placenta',
        'path'     : os.path.join(ADDONS, 'plugin.video.placenta'),
        'icon'     : wiz.addonInfo('plugin.video.placenta', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.placenta', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'placenta_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.placenta', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.user', 'trakt.refresh', 'trakt.token'],
        'activate' : 'RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)'},
    'yoda': {
        'name'     : 'Yoda',
        'plugin'   : 'plugin.video.yoda',
        'saved'    : 'yoda',
        'path'     : os.path.join(ADDONS, 'plugin.video.yoda'),
        'icon'     : wiz.addonInfo('plugin.video.yoda', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.yoda', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'yoda_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.yoda', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.user', 'trakt.refresh', 'trakt.token'],
        'activate' : 'RunPlugin(plugin://plugin.video.yoda/?action=authTrakt)'},
    'uranus': {
        'name'     : 'Uranus',
        'plugin'   : 'plugin.video.uranus',
        'saved'    : 'uranus',
        'path'     : os.path.join(ADDONS, 'plugin.video.uranus'),
        'icon'     : wiz.addonInfo('plugin.video.uranus', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.uranus', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'uranus_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.uranus', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.user', 'trakt.refresh', 'trakt.token'],
        'activate' : 'RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)'},
    'metalliq': {
        'name'     : 'MetalliQ',
        'plugin'   : 'plugin.video.metalliq',
        'saved'    : 'metalliq',
        'path'     : os.path.join(ADDONS, 'plugin.video.metalliq'),
        'icon'     : wiz.addonInfo('plugin.video.metalliq', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.metalliq', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'metalliq_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.metalliq', 'settings.xml'),
        'default'  : 'trakt_access_token',
        'data'     : ['trakt_access_token', 'trakt_refresh_token', 'trakt_expires_at'],
        'activate' : 'RunPlugin(plugin://plugin.video.metalliq/authenticate_trakt)'},
    'myaccounts': {
        'name'     : 'My Accounts',
        'plugin'   : 'script.module.myaccounts',
        'saved'    : 'myaccounts',
        'path'     : os.path.join(ADDONS, 'script.module.myaccounts'),
        'icon'     : wiz.addonInfo('script.module.myaccounts', 'icon'),
        'fanart'   : wiz.addonInfo('script.module.myaccounts', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'myaccounts_trakt'),
        'settings' : os.path.join(ADDOND, 'script.module.myaccounts', 'settings.xml'),
        'default'  : 'trakt.username',
        'data'     : ['trakt.username', 'trakt.refresh', 'trakt.token'],
        'activate' : 'RunScript(script.module.myaccounts, action=traktAuth)'},
    'fen': {
        'name'     : 'Fen',
        'plugin'   : 'plugin.video.fen',
        'saved'    : 'fen',
        'path'     : os.path.join(ADDONS, 'plugin.video.fen'),
        'icon'     : wiz.addonInfo('plugin.video.fen', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.fen', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'fen_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.fen', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.user', 'trakt.refresh', 'trakt.token', 'trakt.expires', 'trakt.indicators_active', 'watched_indicators'],
        'activate' : 'RunPlugin(plugin://plugin.video.fen/?mode=trakt.trakt_authenticate)'},
    'scrubsv2': {
        'name'     : 'Scrubs v2',
        'plugin'   : 'plugin.video.scrubsv2',
        'saved'    : 'scrubsv2',
        'path'     : os.path.join(ADDONS, 'plugin.video.scrubsv2'),
        'icon'     : wiz.addonInfo('plugin.video.scrubsv2', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.scrubsv2', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'scrubsv2_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.scrubsv2', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.user', 'trakt.token', 'trakt.refresh', 'trakt.authed'],
        'activate' : 'RunPlugin(plugin://plugin.video.scrubsv2/?action=auth_trakt)'},
    'umbrella': {
        'name'     : 'Umbrella',
        'plugin'   : 'plugin.video.umbrella',
        'saved'    : 'umbrella',
        'path'     : os.path.join(ADDONS, 'plugin.video.umbrella'),
        'icon'     : wiz.addonInfo('plugin.video.umbrella', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.umbrella', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'umbrella_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.umbrella', 'settings.xml'),
        'default'  : 'trakt.user.name',
        'data'     : ['trakt.user.name', 'trakt.refreshtoken', 'trakt.user.token', 'trakt.token.expires'],
        'activate' : 'RunPlugin(plugin://plugin.video.umbrella/?action=traktAuth)'},
    'chappaai': {
        'name'     : 'Chappa-ai',
        'plugin'   : 'plugin.video.chappaai',
        'saved'    : 'chappaai',
        'path'     : os.path.join(ADDONS, 'plugin.video.chappaai'),
        'icon'     : wiz.addonInfo('plugin.video.chappaai', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.chappaai', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'chappaai_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.chappaai', 'settings.xml'),
        'default'  : 'trakt_access_token',
        'data'     : ['trakt_access_token', 'trakt_refresh_token', 'trakt_expires_at'],
        'activate' : 'RunPlugin(plugin://plugin.video.chappaai/authenticate_trakt)'},
    'trakt': {
        'name'     : 'Trakt',
        'plugin'   : 'script.trakt',
        'saved'    : 'trakt',
        'path'     : os.path.join(ADDONS, 'script.trakt'),
        'icon'     : wiz.addonInfo('script.trakt', 'icon'),
        'fanart'   : wiz.addonInfo('script.trakt', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'trakt_trakt'),
        'settings' : os.path.join(ADDOND, 'script.trakt', 'settings.xml'),
        'default'  : 'user',
        'data'     : ['user', 'Auth_Info', 'authorization'],
        'activate' : 'RunScript(script.trakt, action=auth_info)'},
    'covenant': {
        'name'     : 'Covenant',
        'plugin'   : 'plugin.video.covenant',
        'saved'    : 'covenant',
        'path'     : os.path.join(ADDONS, 'plugin.video.covenant'),
        'icon'     : wiz.addonInfo('plugin.video.covenant', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.covenant', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'covenant_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.covenant', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.user', 'trakt.refresh', 'trakt.token'],
        'activate' : 'RunPlugin(plugin://plugin.video.covenant/?action=authTrakt)'},
    'neptune': {
        'name'     : 'Neptune',
        'plugin'   : 'plugin.video.neptune',
        'saved'    : 'neptune',
        'path'     : os.path.join(ADDONS, 'plugin.video.neptune'),
        'icon'     : wiz.addonInfo('plugin.video.neptune', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.neptune', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'neptune_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.neptune', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.user', 'trakt.refresh', 'trakt.token'],
        'activate' : 'RunPlugin(plugin://plugin.video.neptune/?action=authTrakt)'},
    'seren': {
        'name'     : 'Seren',
        'plugin'   : 'plugin.video.seren',
        'saved'    : 'seren',
        'path'     : os.path.join(ADDONS, 'plugin.video.seren'),
        'icon'     : wiz.addonInfo('plugin.video.seren', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.seren', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'seren_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.seren', 'settings.xml'),
        'default'  : 'trakt.username',
        'data'     : ['trakt.auth', 'trakt.refresh', 'trakt.expires', 'trakt.username'],
        'activate' : 'RunPlugin(plugin://plugin.video.seren/?action=authTrakt)'},
    'destiny': {
        'name'     : 'Destiny',
        'plugin'   : 'plugin.video.destiny',
        'saved'    : 'destiny',
        'path'     : os.path.join(ADDONS, 'plugin.video.destiny'),
        'icon'     : wiz.addonInfo('plugin.video.destiny', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.destiny', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'destiny_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.destiny', 'settings.xml'),
        'default'  : 'trakt_access_token',
        'data'     : ['trakt_access_token', 'trakt_refresh_token', 'use_trak'],
        'activate' : 'RunPlugin(plugin://plugin.video.destiny?mode2=64&url=www)'},
    'shadow': {
        'name'     : 'Shadow',
        'plugin'   : 'plugin.video.shadow',
        'saved'    : 'shadow',
        'path'     : os.path.join(ADDONS, 'plugin.video.shadow'),
        'icon'     : wiz.addonInfo('plugin.video.shadow', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.shadow', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'shadow_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.shadow', 'settings.xml'),
        'default'  : 'trakt_access_token',
        'data'     : ['trakt_access_token', 'trakt_refresh_token'],
        'activate' : 'RunPlugin(plugin://plugin.video.shadow?mode=157&url=False)'},
    'tmdbhelper': {
        'name'     : 'TheMovieDb Helper',
        'plugin'   : 'plugin.video.themoviedb.helper',
        'saved'    : 'tmdbhelper',
        'path'     : os.path.join(ADDONS, 'plugin.video.themoviedb.helper'),
        'icon'     : wiz.addonInfo('plugin.video.themoviedb.helper', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.themoviedb.helper', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'tmdbhelper_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.themoviedb.helper', 'settings.xml'),
        'default'  : 'trakt_token',
        'data'     : ['trakt_token'],
        'activate' : 'RunScript(plugin.video.themoviedb.helper, authenticate_trakt)'},
    'atreides': {
        'name'     : 'Atreides',
        'plugin'   : 'plugin.video.atreides',
        'saved'    : 'atreides',
        'path'     : os.path.join(ADDONS, 'plugin.video.atreides'),
        'icon'     : wiz.addonInfo('plugin.video.atreides', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.atreides', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'atreides_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.atreides', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.user', 'trakt.refresh', 'trakt.token'],
        'activate' : 'RunPlugin(plugin://plugin.video.atreides/?action=authTrakt)'},
    'thecrew': {
        'name'     : 'The Crew',
        'plugin'   : 'plugin.video.thecrew',
        'saved'    : 'thecrew',
        'path'     : os.path.join(ADDONS, 'plugin.video.thecrew'),
        'icon'     : wiz.addonInfo('plugin.video.thecrew', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.thecrew', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'thecrew_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.thecrew', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.user', 'trakt.refresh', 'trakt.token'],
        'activate' : 'RunPlugin(plugin://plugin.video.thecrew/?action=authTrakt)'},
    'marauder': {
        'name'     : 'Marauder',
        'plugin'   : 'plugin.video.marauder',
        'saved'    : 'marauder',
        'path'     : os.path.join(ADDONS, 'plugin.video.marauder'),
        'icon'     : wiz.addonInfo('plugin.video.marauder', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.marauder', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'marauder_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.marauder', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.user', 'trakt.refresh', 'trakt.token', 'trakt.authed'],
        'activate' : 'RunPlugin(plugin://plugin.video.marauder/?action=authTrakt)'},
    'theoath': {
        'name'     : 'TheOath',
        'plugin'   : 'plugin.video.theoath',
        'saved'    : 'theoath',
        'path'     : os.path.join(ADDONS, 'plugin.video.theoath'),
        'icon'     : wiz.addonInfo('plugin.video.theoath', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.theoath', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'theoath_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.theoath', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.user', 'trakt.refresh', 'trakt.token', 'trakt.authed'],
        'activate' : 'RunPlugin(plugin://plugin.video.theoath/?action=authTrakt)'},
    'blacklodge': {
        'name'     : 'Blacklodge',
        'plugin'   : 'plugin.video.blacklodge',
        'saved'    : 'blacklodge',
        'path'     : os.path.join(ADDONS, 'plugin.video.blacklodge'),
        'icon'     : wiz.addonInfo('plugin.video.blacklodge', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.blacklodge', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'blacklodge_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.blacklodge', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.user', 'trakt.refresh', 'trakt.token', 'trakt.authed'],
        'activate' : 'RunPlugin(plugin://plugin.video.blacklodge/?action=authTrakt)'},
    'pov': {
        'name'     : 'POV',
        'plugin'   : 'plugin.video.pov',
        'saved'    : 'pov',
        'path'     : os.path.join(ADDONS, 'plugin.video.pov'),
        'icon'     : wiz.addonInfo('plugin.video.pov', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.pov', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'pov_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.pov', 'settings.xml'),
        'default'  : 'trakt_user',
        'data'     : ['trakt_user', 'trakt.refresh', 'trakt.token', 'trakt.expires', 'trakt_indicators_active', 'watched_indicators'],
        'activate' : 'RunPlugin(plugin://plugin.video.pov/?mode=trakt.trakt_auth)'},
    # 'venom': {
        # 'name'     : 'Venom',
        # 'plugin'   : 'plugin.video.venom',
        # 'saved'    : 'venom',
        # 'path'     : os.path.join(ADDONS, 'plugin.video.venom'),
        # 'icon'     : wiz.addonInfo('plugin.video.venom', 'icon'),
        # 'fanart'   : wiz.addonInfo('plugin.video.venom', 'fanart'),
        # 'file'     : os.path.join(TRAKTFOLD, 'venom_trakt'),
        # 'settings' : os.path.join(ADDOND, 'plugin.video.venom', 'settings.xml'),
        # 'default'  : 'trakt.user',
        # 'data'     : ['trakt.user', 'trakt.refresh', 'trakt.token', 'trakt.userHidden'],
        # 'activate' : 'RunPlugin(plugin://plugin.video.venom/?action=authTrakt)'},
    'tempest': {
        'name'     : 'Tempest',
        'plugin'   : 'plugin.video.tempest',
        'saved'    : 'tempest',
        'path'     : os.path.join(ADDONS, 'plugin.video.tempest'),
        'icon'     : wiz.addonInfo('plugin.video.tempest', 'icon'),
        'fanart'   : wiz.addonInfo('plugin.video.tempest', 'fanart'),
        'file'     : os.path.join(TRAKTFOLD, 'tempest_trakt'),
        'settings' : os.path.join(ADDOND, 'plugin.video.tempest', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.user', 'trakt.refresh', 'trakt.token'],
        'activate' : 'RunPlugin(plugin://plugin.video.tempest/?action=authTrakt)'}
}

def traktUser(who):
    user=None
    if TRAKTID[who]:
        if os.path.exists(TRAKTID[who]['path']):
            try:
                add = wiz.addonId(TRAKTID[who]['plugin'])
                user = add.getSetting(TRAKTID[who]['default'])
            except:
                return None
    return user

def traktIt(do, who):
    if not os.path.exists(ADDONDATA): os.makedirs(ADDONDATA)
    if not os.path.exists(TRAKTFOLD): os.makedirs(TRAKTFOLD)
    if who == 'all':
        for log in ORDER:
            if os.path.exists(TRAKTID[log]['path']):
                try:
                    addonid   = wiz.addonId(TRAKTID[log]['plugin'])
                    default   = TRAKTID[log]['default']
                    user      = addonid.getSetting(default)
                    if user == '' and do == 'update': continue
                    updateTrakt(do, log)
                except: pass
            else: wiz.log('[Trakt Data] %s(%s) is not installed' % (TRAKTID[log]['name'],TRAKTID[log]['plugin']), xbmc.LOGERROR)
        wiz.setS('traktlastsave', str(THREEDAYS))
    else:
        if TRAKTID[who]:
            if os.path.exists(TRAKTID[who]['path']):
                updateTrakt(do, who)
        else: wiz.log('[Trakt Data] Invalid Entry: %s' % who, xbmc.LOGERROR)

def clearSaved(who, over=False):
    if who == 'all':
        for trakt in TRAKTID:
            clearSaved(trakt,  True)
    elif TRAKTID[who]:
        file = TRAKTID[who]['file']
        if os.path.exists(file):
            xbmcvfs.delete(file)
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, TRAKTID[who]['name']),'[COLOR %s]Trakt Data: Removed![/COLOR]' % COLOR2, 2000, TRAKTID[who]['icon'])
        wiz.setS(TRAKTID[who]['saved'], '')
    if over == False: wiz.refresh()

def updateTrakt(do, who):
    file      = TRAKTID[who]['file']
    settings  = TRAKTID[who]['settings']
    data      = TRAKTID[who]['data']
    addonid   = wiz.addonId(TRAKTID[who]['plugin'])
    saved     = TRAKTID[who]['saved']
    default   = TRAKTID[who]['default']
    user      = addonid.getSetting(default)
    suser     = wiz.getS(saved)
    name      = TRAKTID[who]['name']
    icon      = TRAKTID[who]['icon']

    if do == 'update':
        if not user == '':
            try:
                with xbmcvfs.File(file, 'w') as f:
                    for trakt in data: 
                        f.write('<trakt>\n\t<id>%s</id>\n\t<value>%s</value>\n</trakt>\n' % (trakt, addonid.getSetting(trakt)))
                    # f.close()
                user = addonid.getSetting(default)
                wiz.setS(saved, user)
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name), '[COLOR %s]Trakt Data: Saved![/COLOR]' % COLOR2, 2000, icon)
            except Exception as e:
                wiz.log("[Trakt Data] Unable to Update %s (%s)" % (who, str(e)), xbmc.LOGERROR)
        else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name), '[COLOR %s]Trakt Data: Not Registered![/COLOR]' % COLOR2, 2000, icon)
    elif do == 'restore':
        if os.path.exists(file):
            f = xbmcvfs.File(file); g = f.read().replace('\n','').replace('\r','').replace('\t',''); f.close();
            match = re.compile('<trakt><id>(.+?)</id><value>(.+?)</value></trakt>').findall(g)
            try:
                if len(match) > 0:
                    for trakt, value in match:
                        addonid.setSetting(trakt, value)
                user = addonid.getSetting(default)
                wiz.setS(saved, user)
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name), '[COLOR %s]Trakt: Restored![/COLOR]' % COLOR2, 2000, icon)
            except Exception as e:
                wiz.log("[Trakt Data] Unable to Restore %s (%s)" % (who, str(e)), xbmc.LOGERROR)
        #else: wiz.LogNotify(name,'Trakt Data: [COLOR red]Not Found![/COLOR]', 2000, icon)
    elif do == 'clearaddon':
        wiz.log('%s SETTINGS: %s' % (name, settings), xbmc.LOGDEBUG)
        if os.path.exists(settings):
            try:
                f = open(settings, "r"); lines = f.readlines(); f.close()
                f = open(settings, "w")
                for line in lines:
                    match = wiz.parseDOM(line, 'setting', ret='id')
                    if len(match) == 0: f.write(line)
                    else:
                        if match[0] not in data: f.write(line)
                        else: wiz.log('Removing Line: %s' % line, lognot)
                f.close()
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name),'[COLOR %s]Addon Data: Cleared![/COLOR]' % COLOR2, 2000, icon)
            except Exception as e:
                wiz.log("[Trakt Data] Unable to Clear Addon %s (%s)" % (who, str(e)), xbmc.LOGERROR)
    wiz.refresh()

def autoUpdate(who):
    if who == 'all':
        for log in TRAKTID:
            if os.path.exists(TRAKTID[log]['path']):
                autoUpdate(log)
    elif TRAKTID[who]:
        if os.path.exists(TRAKTID[who]['path']):
            u  = traktUser(who)
            su = wiz.getS(TRAKTID[who]['saved'])
            n = TRAKTID[who]['name']
            if u == None or u == '': return
            elif su == '': traktIt('update', who)
            elif not u == su:
                if DIALOG.yesno(ADDONTITLE, ("[COLOR %s]Would you like to save the [COLOR %s]Trakt[/COLOR] data for [COLOR %s]%s[/COLOR]?" % (COLOR2, COLOR1, COLOR1, n))+"[CR]"+("Addon: [COLOR green][B]%s[/B][/COLOR]" % u)+"[CR]"+("Saved:[/COLOR] [COLOR red][B]%s[/B][/COLOR]" % su if not su == '' else 'Saved:[/COLOR] [COLOR red][B]None[/B][/COLOR]'), yeslabel="[B][COLOR green]Save Data[/COLOR][/B]", nolabel="[B][COLOR red]No Cancel[/COLOR][/B]"):
                    traktIt('update', who)
            else: traktIt('update', who)

def importlist(who):
    if who == 'all':
        for log in TRAKTID:
            if os.path.exists(TRAKTID[log]['file']):
                importlist(log)
    elif TRAKTID[who]:
        if os.path.exists(TRAKTID[who]['file']):
            d  = TRAKTID[who]['default']
            sa = TRAKTID[who]['saved']
            su = wiz.getS(sa)
            n  = TRAKTID[who]['name']
            f  = xbmcvfs.File(TRAKTID[who]['file']); g = f.read().replace('\n','').replace('\r','').replace('\t',''); f.close();
            m  = re.compile('<trakt><id>%s</id><value>(.+?)</value></trakt>' % d).findall(g)
            if len(m) > 0:
                if not m[0] == su:
                    if DIALOG.yesno(ADDONTITLE, ("[COLOR %s]Would you like to import the [COLOR %s]Trakt[/COLOR] data for [COLOR %s]%s[/COLOR]?" % (COLOR2, COLOR1, COLOR1, n))+"[CR]"+("File: [COLOR green][B]%s[/B][/COLOR]" % m[0])+"[CR]"+("Saved:[/COLOR] [COLOR red][B]%s[/B][/COLOR]" % su if not su == '' else 'Saved:[/COLOR] [COLOR red][B]None[/B][/COLOR]'), yeslabel="[B]Save Data[/B]", nolabel="[B]No Cancel[/B]"):
                        wiz.setS(sa, m[0])
                        wiz.log('[Import Data] %s: %s' % (who, str(m)), lognot)
                    else: wiz.log('[Import Data] Declined Import(%s): %s' % (who, str(m)), lognot)
                else: wiz.log('[Import Data] Duplicate Entry(%s): %s' % (who, str(m)), lognot)
            else: wiz.log('[Import Data] No Match(%s): %s' % (who, str(m)), lognot)

def activateTrakt(who):
    if TRAKTID[who]:
        if os.path.exists(TRAKTID[who]['path']): 
            act     = TRAKTID[who]['activate']
            addonid = wiz.addonId(TRAKTID[who]['plugin'])
            if act == '': addonid.openSettings()
            else: url = xbmc.executebuiltin(TRAKTID[who]['activate'])
        else: DIALOG.ok(ADDONTITLE, '%s is not currently installed.' % TRAKTID[who]['name'])
    else: 
        wiz.refresh()
        return
    check = 0
    while traktUser(who) == None:
        if check == 30: break
        check += 1
        time.sleep(10)
    wiz.refresh()