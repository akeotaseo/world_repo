#filmzie.py
import requests

BASE_URL = "https://filmzie.com/api/v1"
POSTER_BASE = "https://img.filmzie.com/cdn/v7/https://d3qxhvuywdalwo.cloudfront.net"

def get_categories():
    try:
        response = requests.get(f"{BASE_URL}/category", timeout=10)
        response.raise_for_status()
        raw = response.json().get("data", [])
        return [{"id": cat["id"], "name": cat["name"]} for cat in raw if "id" in cat and "name" in cat]
    except Exception as e:
        print(f"[Filmzie] ❌ Eroare categorii: {e}")
        return []

def get_movies_by_category(category, limit=30, offset=0):
    try:
        url = f"{BASE_URL}/content"
        params = {
            "limit": limit,
            "offset": offset,
            "category": category,
            "comingSoonSupported": "true"
        }
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        raw = response.json().get("data", {}).get("data", [])
        return [parse_movie_data(item) for item in raw]
    except Exception as e:
        print(f"[Filmzie] ❌ Eroare filme: {e}")
        return []

def parse_movie_data(item):
    title = item.get("title", "Fără titlu")
    plot = item.get("description", "")
    imdb = item.get("externalIds", {}).get("imdb", "")
    poster_key = item.get("images", {}).get("poster", {}).get("amazonKey", "")
    fanart_key = item.get("images", {}).get("featured2", {}).get("amazonKey", "")
    logo_key = item.get("images", {}).get("logo", {}).get("amazonKey", "")
    poster = f"{POSTER_BASE}/{poster_key}?w=200&q=70" if poster_key else ""
    logo = f"{POSTER_BASE}/{logo_key}?w=200&q=70" if logo_key else ""
    fanart = f"{POSTER_BASE}/{fanart_key}" if fanart_key else ""
    video_id = item.get("mainVideoId", "")
    trailer_ids = item.get("trailerVideoIds", [])
    year = item.get("releaseYear")
    duration = item.get("duration", 0)
    genres = [genre["name"] for genre in item.get("genres", [])]

    return {
        "title": title,
        "plot": plot,
        "imdb_id": imdb,
        "poster": poster,
        "fanart": fanart,
        "logo": logo,
        "video_id": video_id,
        "trailer_id": trailer_ids[0] if trailer_ids else None,
        "year": year,
        "duration": duration,
        "genres": genres
    }

def get_movies(category, page=1, per_page=30):
    offset = (page - 1) * per_page
    url = f"{BASE_URL}/content"
    params = {
        "genre": category,
        "limit": per_page,
        "offset": offset,
        "comingSoonSupported": "true"
    }
    try:
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        raw_movies = response.json().get("data", {}).get("data", [])
        return [parse_movie_data(movie) for movie in raw_movies]
    except Exception as e:
        print(f"[Filmzie] ❌ Eroare la extragere filme: {e}")
        return []

def get_stream_url(video_id):
    try:
        url = f"{BASE_URL}/video/stream/{video_id}"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json().get("data", {})
        return data.get("source", {}).get("hlsV2", "")
    except Exception as e:
        print(f"[Filmzie] ❌ Eroare stream: {e}")
        return ""

def search_movies(query, limit=5, offset=0):
    try:
        url = f"{BASE_URL}/content"
        params = {
            "keyword": query,
            "limit": limit,
            "offset": offset,
            "comingSoonSupported": "true"
        }
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        print("[Filmzie] 🔍 Răspuns căutare:", response.text)
        raw = response.json().get("data", {}).get("data", [])
        return raw
    except Exception as e:
        print(f"[Filmzie] ❌ Eroare căutare: {e}")
        return []
