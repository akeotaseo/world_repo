import re
import xbmcaddon
from lib.modules import Common

OpenURL  = Common.OpenURL
addDir   = Common.addDir
addVideo = Common.addVideo
Play     = Common.Play
Setting  = xbmcaddon.Addon().getSetting

def Menu():
	addDir('Latest Videos',      'https://pornone.com/newest/',     131, 'special://home/addons/plugin.video.xxx/resources/art/pornone.png')
	addDir('Most Viewed Videos', 'https://pornone.com/views/',      131, 'special://home/addons/plugin.video.xxx/resources/art/pornone.png')
	addDir('Top Rated Videos',   'https://pornone.com/rating/',     131, 'special://home/addons/plugin.video.xxx/resources/art/pornone.png')
	addDir('Categories',         'https://pornone.com/categories/', 132, 'special://home/addons/plugin.video.xxx/resources/art/pornone.png')

def Browse(url):
	r = OpenURL(url)
	
	m = re.compile('<a href="(.+?)".+?>\n<.+?>\n<.+?></div>\n<.+?>\n<.+?><.+?>(.+?)\n</span><.+?><.+?><.+?>\n<.+?>\n<.+?>\nAdd to Queue</span>\n<.+?>\nAdd to Favorites</span>\n<.+?>\nAdd to Playlist</span>\n</span>\n</span></span></span><img src data-src="(.+?)" alt="(.+?)" width').findall(r)
	for url, time, thumb, title in m:
		import random
		random_id = random.randint(0,1000000)
		url = '%s&random_id=%s' % (url, str(random_id))
		if Setting('show_time') == 'true': title = '[B](%s)[/B] %s' % (time, title)
		
		from urllib.parse import unquote
		clean_title = unquote(title) #title.replace('&#x27;', "'").replace('&#8217;', "'").replace('&apos;', "'").replace('amp;', "")
		
		if 'piss' in title.lower(): pass
		else:
		
			if time.startswith('19:'): pass
			elif time.startswith('18:'): pass
			elif time.startswith('17:'): pass
			elif time.startswith('16:'): pass
			elif time.startswith('15:'): pass
			elif time.startswith('14:'): pass
			elif time.startswith('13:'): pass
			elif time.startswith('12:'): pass
			elif time.startswith('11:'): pass
			elif time.startswith('10:') and len(time) < 6: pass
			elif time.startswith('09:') and len(time) < 6: pass
			elif time.startswith('08:') and len(time) < 6: pass
			elif time.startswith('07:') and len(time) < 6: pass
			elif time.startswith('06:') and len(time) < 6: pass
			elif time.startswith('05:') and len(time) < 6: pass
			elif time.startswith('04:') and len(time) < 6: pass
			elif time.startswith('03:') and len(time) < 6: pass
			elif time.startswith('02:') and len(time) < 6: pass
			elif time.startswith('01:') and len(time) < 6: pass
			elif time.startswith('00:'): pass
			else: addVideo(clean_title, url, 133, thumb)
			
	n = re.compile('</ul><a href="(.+?)" title="Next Page"').findall(r)
	for page in n:
		addDir('Next page >', page, 131, 'special://home/addons/plugin.video.xxx/resources/art/next_page.png')
	Common.SetView()
		
def Categories(url):
	r = OpenURL(url)
	m = re.compile('<a href="(.+?)" class=".+?">\n<img src=".+?" alt="Video category (.+?)" data-src="(.+?)" class=".+?" />').findall(r)
	for url, title, thumb in m:
		url   = 'https://pornone.com/%s/2/' % url
		addDir(title, url, 131, thumb)
	
def PlayStream(url):
	if 'random_id=' in url:
		url = re.compile('(.+?)&random_id').findall(url)[0]
	r = OpenURL(url)
	video = re.compile('<source src="(.+?)" ').findall(r)[0]
	Play(video)
