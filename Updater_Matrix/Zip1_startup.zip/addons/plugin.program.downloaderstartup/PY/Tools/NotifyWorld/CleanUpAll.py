import xbmc, xbmcgui


def CleanUpAll():
    funcs = (click_1, click_2, click_3, click_4, click_5)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ CleanUp.All ~[/COLOR][/B]', 
['[B][COLOR green] Γενικός καθαρισμός[/COLOR][/B]',
 '[COLOR dodgerblue]Total Clean Up:[/COLOR]',
 '[COLOR grey]Καθαρισμός Παρόχων[/COLOR]',
 '[COLOR=white]Προσωρινά αρχεία[/COLOR]',
 '[B][COLOR=orange]CLOSE[/COLOR][/B]'])
 #'[B][COLOR=white]TvOne112[/COLOR][/B]


    if call:
        if call < 0:
            return
        func = funcs[call-5]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/NotifyWorld/TotalCleanUpAll.py")')



def click_2():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=fullclean")')
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/NotifyWorld/CleanUpAll.py")')

def click_3():
    xbmcgui.Dialog().notification("[B][COLOR orange]Παρακαλώ περιμένετε...[/COLOR][/B]", "[COLOR white]Πραγματοποιείται Καθαρισμός Παρόχων[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png')
    xbmc.sleep(1000)
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.downloader19/?url=&mode=23&name=%5BB%5D%5BCOLOR+white%5D%CE%9A%CE%B1%CE%B8%CE%B1%CF%81%CE%B9%CF%83%CE%BC%CF%8C%CF%82+%CE%A0%CE%B1%CF%81%CF%8C%CF%87%CF%89%CE%BD%5B%2FCOLOR%5D%5B%2FB%5D&icon=special%3A%2F%2Fhome%2Faddons%2Fplugin.program.downloader19%2Fresources%2Fmedia%2FWorld.png&fanart=C%3A%5CPortableApps%5Ckodi%5Ckodi+World+20%5CKodi%5Cportable_data%5Caddons%5Cplugin.program.downloader19%5Cfanart.jpg&description=&name2=&version=")')
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/NotifyWorld/CleanUpAll.py")')

def click_4():
    xbmcgui.Dialog().notification("[B][COLOR orange]Παρακαλώ περιμένετε...[/COLOR][/B]", "[COLOR white]Πραγματοποιείται διαγραφή Προσωρινών αρχείων[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png')
    xbmc.sleep(500)
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/NotifyWorld/TotalCleanUp.py")')
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/NotifyWorld/CleanUpAll.py")')
    xbmc.sleep(10000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Αυτο ήταν...[/COLOR][/B]", "[COLOR white]ok[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/ok2.png')

def click_5():
    xbmcgui.Dialog().notification("[B][COLOR orange]Για να συνεχίσετε πατήστε[/COLOR][/B]", "[COLOR white]CLOSE[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/Notify.png')

def click_6():
    xbmc.executebuiltin('.....')

CleanUpAll()
